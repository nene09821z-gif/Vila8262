/**
 * Chess.com-inspired UX helpers for Cờ Vua.
 * Pure functions only — safe for Node tests and browser.
 */

import { winChance, MOVE_QUALITY_LABELS } from './game-review.js';

/* ---------- 3. Post-game accuracy (Chess.com-style expected points) ---------- */

/**
 * Map a judgement key to expected-points weight (0–1) used for accuracy %.
 * Matches the spirit of Chess.com / Lichess game review scoring.
 */
export const JUDGEMENT_ACCURACY_WEIGHT = Object.freeze({
  brilliant: 1,
  great: 1,
  best: 1,
  excellent: 0.95,
  good: 0.85,
  book: 1,
  inaccuracy: 0.6,
  mistake: 0.3,
  'missed-win': 0.2,
  blunder: 0,
  unrated: null
});

/**
 * Compute side accuracy from review rows.
 * @param {Array<{ color?: string, judgement?: { key?: string } }>} rows
 * @returns {{ white: number|null, black: number|null, combined: number|null, counts: object }}
 */
export function computeGameAccuracy(rows = []) {
  const buckets = { w: [], b: [] };
  const counts = Object.create(null);
  for (const row of rows) {
    const key = row?.judgement?.key || 'unrated';
    counts[key] = (counts[key] || 0) + 1;
    const weight = JUDGEMENT_ACCURACY_WEIGHT[key];
    if (weight == null) continue;
    const color = row.color === 'b' ? 'b' : row.color === 'w' ? 'w' : null;
    if (!color) continue;
    buckets[color].push(weight);
  }
  const avg = list => (list.length ? Math.round((list.reduce((a, b) => a + b, 0) / list.length) * 100) : null);
  const white = avg(buckets.w);
  const black = avg(buckets.b);
  const all = [...buckets.w, ...buckets.b];
  const combined = avg(all);
  return { white, black, combined, counts };
}

/**
 * Build a compact review summary for the post-game dashboard.
 */
export function buildReviewDashboard(rows = [], meta = {}) {
  const accuracy = computeGameAccuracy(rows);
  const classified = rows.filter(r => r?.judgement?.key && r.judgement.key !== 'unrated');
  const brilliant = classified.filter(r => r.judgement.key === 'brilliant').length;
  const blunders = classified.filter(r => r.judgement.key === 'blunder').length;
  const mistakes = classified.filter(r => r.judgement.key === 'mistake').length;
  const book = classified.filter(r => r.judgement.key === 'book').length;
  return {
    accuracy,
    moveCount: classified.length,
    brilliant,
    blunders,
    mistakes,
    book,
    title: meta.title || 'Phân tích ván đấu',
    opening: meta.opening || null,
    result: meta.result || null
  };
}

/* ---------- 4. Bot Elo presets + think delay ---------- */

export const BOT_ELO_PRESETS = Object.freeze([
  { id: 'beginner', label: 'Người mới', elo: 400, skill: 0, thinkMs: [400, 900], hint: 'Chơi chậm, hay sai' },
  { id: 'casual', label: 'Nghiệp dư', elo: 800, skill: 3, thinkMs: [350, 800], hint: 'Phù hợp học khai cuộc' },
  { id: 'club', label: 'Câu lạc bộ', elo: 1200, skill: 8, thinkMs: [300, 700], hint: 'Áp lực nhẹ' },
  { id: 'strong', label: 'Cao cấp', elo: 1600, skill: 12, thinkMs: [250, 650], hint: 'Ít blunder' },
  { id: 'expert', label: 'Chuyên gia', elo: 2000, skill: 16, thinkMs: [200, 550], hint: 'Rất mạnh' },
  { id: 'master', label: 'Kiện tướng', elo: 2400, skill: 19, thinkMs: [150, 450], hint: 'Gần tối đa' },
  { id: 'max', label: 'Tối đa', elo: 2800, skill: 20, thinkMs: [80, 280], hint: 'Stockfish gần full' }
]);

export function resolveBotEloPreset(idOrElo) {
  if (typeof idOrElo === 'string') {
    const byId = BOT_ELO_PRESETS.find(p => p.id === idOrElo);
    if (byId) return byId;
  }
  const elo = Number(idOrElo);
  if (!Number.isFinite(elo)) return BOT_ELO_PRESETS[2];
  let best = BOT_ELO_PRESETS[0];
  let bestDist = Infinity;
  for (const p of BOT_ELO_PRESETS) {
    const d = Math.abs(p.elo - elo);
    if (d < bestDist) { best = p; bestDist = d; }
  }
  return best;
}

/** Human-like delay before the bot replies (ms). */
export function botThinkDelayMs(presetOrElo, random = Math.random) {
  const preset = typeof presetOrElo === 'object' && presetOrElo?.thinkMs
    ? presetOrElo
    : resolveBotEloPreset(presetOrElo);
  const [lo, hi] = preset.thinkMs || [200, 600];
  const t = lo + (hi - lo) * (typeof random === 'function' ? random() : 0.5);
  return Math.round(t);
}

/* ---------- 2. Match action bar (draw / resign / menu) ---------- */

export function matchActionBarEnabled(state = {}) {
  const { gameStarted, gameOver, clockFlagged, manualResult } = state;
  return Boolean(gameStarted) && !gameOver && !clockFlagged && !manualResult;
}

export function matchActionBarMarkup(state = {}) {
  const enabled = matchActionBarEnabled(state);
  const disabled = enabled ? '' : 'disabled';
  return `<nav class="match-action-bar" aria-label="Hành động ván đấu">
  <button type="button" class="match-action-btn" id="offerDrawBtn" ${disabled} title="Xin hòa"><span aria-hidden="true">½</span><small>Xin hòa</small></button>
  <button type="button" class="match-action-btn match-action-danger" id="resignBtn" ${disabled} title="Đầu hàng"><span aria-hidden="true">⚑</span><small>Đầu hàng</small></button>
  <button type="button" class="match-action-btn" id="matchMenuBtn" title="Menu ván"><span aria-hidden="true">☰</span><small>Menu</small></button>
  <button type="button" class="match-action-btn" id="cancelPremoveBtn" title="Hủy premove"><span aria-hidden="true">✕</span><small>Hủy PM</small></button>
</nav>`;
}

/* ---------- 5. Puzzle streak / daily helpers ---------- */

export function puzzleStreakLabel(streak = 0, best = 0) {
  const s = Math.max(0, Number(streak) || 0);
  const b = Math.max(0, Number(best) || 0);
  if (s <= 0) return b > 0 ? `Streak 0 · kỷ lục ${b}` : 'Bắt đầu chuỗi thắng';
  return s >= b && s > 0 ? `🔥 Streak ${s} · kỷ lục mới` : `🔥 Streak ${s} · kỷ lục ${b}`;
}

export function puzzleNextButtonLabel(playMode = 'practice') {
  if (playMode === 'daily') return 'Luyện lại đề hôm nay';
  if (playMode === 'rush') return 'Puzzle tiếp · Rush';
  return 'Puzzle tiếp theo';
}

/* ---------- 6. Board / sound theme catalog ---------- */

export const BOARD_THEME_CATALOG = Object.freeze([
  { id: 'classic-green', label: 'Xanh cổ điển', light: '#eed7b0', dark: '#b58863' },
  { id: 'ice', label: 'Băng giá', light: '#dce6f2', dark: '#6b8caf' },
  { id: 'tournament', label: 'Giải đấu', light: '#f0d9b5', dark: '#b58863' },
  { id: 'midnight', label: 'Nửa đêm', light: '#4a5568', dark: '#1a202c' },
  { id: 'coral', label: 'San hô', light: '#f7cac9', dark: '#c06c84' },
  { id: 'forest', label: 'Rừng', light: '#e8f0d8', dark: '#769656' },
  { id: 'slate', label: 'Đá phiến', light: '#c5cdd8', dark: '#5c6b7a' },
  { id: 'sunset', label: 'Hoàng hôn', light: '#f5e0c3', dark: '#c07850' }
]);

export const SOUND_THEME_CATALOG = Object.freeze([
  { id: 'soft', label: 'Êm · mặc định' },
  { id: 'wood', label: 'Gỗ · click rõ' },
  { id: 'neon', label: 'Neon · hiện đại' },
  { id: 'mute', label: 'Tắt tiếng' }
]);

export function resolveBoardTheme(id) {
  return BOARD_THEME_CATALOG.find(t => t.id === id) || BOARD_THEME_CATALOG[0];
}

export function resolveSoundTheme(id) {
  return SOUND_THEME_CATALOG.find(t => t.id === id) || SOUND_THEME_CATALOG[0];
}

/* ---------- 7. Ranked / matchmaking copy ---------- */

export function matchmakingStatusText(state = {}) {
  const { searching = false, elo = null, queueSeconds = 0, mode = 'ranked' } = state;
  if (!searching) {
    return elo != null
      ? `Sẵn sàng · Elo ${Math.round(elo)} · chọn đồng hồ rồi tìm đối thủ`
      : 'Sẵn sàng xếp hạng · chọn đồng hồ rồi bắt đầu';
  }
  const wait = Math.max(0, Math.round(queueSeconds));
  return `Đang tìm đối thủ${elo != null ? ` · Elo ${Math.round(elo)}` : ''} · ${wait}s${mode === 'friendly' ? ' · phòng bạn bè' : ''}`;
}

/* ---------- 8. Opening explorer ---------- */

/**
 * Rank continuations from a SAN-prefix map or opening list.
 * @param {string[]} historySan moves played so far
 * @param {Array<{ san?: string[], name?: string, eco?: string }>} openings
 * @param {number} limit
 */
export function openingExplorerContinuations(historySan = [], openings = [], limit = 6) {
  const prefix = (Array.isArray(historySan) ? historySan : []).map(s => String(s).trim()).filter(Boolean);
  const prefixKey = prefix.join(' ');
  const nextCounts = new Map();
  let named = null;
  for (const opening of openings) {
    const line = Array.isArray(opening?.san) ? opening.san.map(s => String(s).trim()) : [];
    if (line.length < prefix.length) continue;
    let match = true;
    for (let i = 0; i < prefix.length; i++) {
      if (line[i] !== prefix[i]) { match = false; break; }
    }
    if (!match) continue;
    if (line.length === prefix.length) {
      named = { name: opening.name || opening.eco || 'Khai cuộc', eco: opening.eco || null };
      continue;
    }
    const next = line[prefix.length];
    if (!next) continue;
    const entry = nextCounts.get(next) || { san: next, count: 0, sampleName: opening.name || null };
    entry.count += 1;
    if (!entry.sampleName && opening.name) entry.sampleName = opening.name;
    nextCounts.set(next, entry);
  }
  const total = [...nextCounts.values()].reduce((a, e) => a + e.count, 0) || 1;
  const continuations = [...nextCounts.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, Math.max(1, limit))
    .map(e => ({
      san: e.san,
      count: e.count,
      pct: Math.round((e.count / total) * 100),
      name: e.sampleName
    }));
  return { prefix: prefixKey, named, continuations, totalGames: total };
}

export function openingExplorerMarkup(result) {
  if (!result) return '';
  const title = result.named?.name
    ? `<div class="open-exp-title"><b>${escapeHtml(result.named.name)}</b>${result.named.eco ? ` <span class="open-exp-eco">${escapeHtml(result.named.eco)}</span>` : ''}</div>`
    : `<div class="open-exp-title"><b>Khai cuộc</b> <span class="open-exp-eco">khám phá</span></div>`;
  if (!result.continuations?.length) {
    return `<aside class="opening-explorer" aria-label="Opening explorer">${title}<p class="open-exp-empty">Hết dữ liệu tiếp tục trong sách khai cuộc cục bộ.</p></aside>`;
  }
  const rows = result.continuations.map(c =>
    `<button type="button" class="open-exp-row" data-san="${escapeAttr(c.san)}"><span class="open-exp-san">${escapeHtml(c.san)}</span><span class="open-exp-pct">${c.pct}%</span><span class="open-exp-name">${escapeHtml(c.name || '')}</span></button>`
  ).join('');
  return `<aside class="opening-explorer" aria-label="Opening explorer">${title}<div class="open-exp-list">${rows}</div></aside>`;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function escapeAttr(value) {
  return escapeHtml(value).replace(/'/g, '&#39;');
}

/* ---------- 9–11. Live / lessons / club (UI data + pure helpers) ---------- */

export const LESSON_CATALOG = Object.freeze([
  {
    id: 'rules-basics',
    title: 'Luật cơ bản',
    chapters: [
      { id: 'king', title: 'Vua & chiếu', minutes: 4 },
      { id: 'pieces', title: 'Cách đi từng quân', minutes: 8 },
      { id: 'checkmate', title: 'Chiếu hết đơn giản', minutes: 6 }
    ]
  },
  {
    id: 'tactics-1',
    title: 'Chiến thuật nền',
    chapters: [
      { id: 'fork', title: 'Đòn đôi', minutes: 5 },
      { id: 'pin', title: 'Ghim', minutes: 5 },
      { id: 'skewer', title: 'Xiên', minutes: 5 }
    ]
  },
  {
    id: 'endgame-1',
    title: 'Tàn cuộc cơ bản',
    chapters: [
      { id: 'kq-mate', title: 'Vua + Hậu chiếu hết', minutes: 6 },
      { id: 'kr-mate', title: 'Vua + Xe chiếu hết', minutes: 7 },
      { id: 'opposition', title: 'Đối mặt vua', minutes: 6 }
    ]
  }
]);

export function lessonProgressSummary(progress = {}) {
  let total = 0;
  let done = 0;
  for (const lesson of LESSON_CATALOG) {
    for (const ch of lesson.chapters) {
      total += 1;
      if (progress[`${lesson.id}/${ch.id}`]) done += 1;
    }
  }
  const pct = total ? Math.round((done / total) * 100) : 0;
  return { total, done, pct, label: `${done}/${total} chương · ${pct}%` };
}

export function clubHomeMarkup(club = {}) {
  const name = club.name || 'Câu lạc bộ ViLa';
  const members = Number(club.members) || 0;
  const activity = club.activity || 'Thách đấu bạn bè · xem bảng xếp hạng · phòng xem';
  return `<section class="club-home panel" aria-label="Câu lạc bộ">
  <div class="panel-heading"><div><small class="eyebrow">CLUB</small><h2>${escapeHtml(name)}</h2></div><span class="context-icon">♖</span></div>
  <p class="club-meta">${members ? `${members} thành viên` : 'Câu lạc bộ cục bộ'} · ${escapeHtml(activity)}</p>
  <div class="button-row club-actions">
    <button type="button" class="primary-btn" id="clubChallengeBtn">Thách đấu bạn</button>
    <button type="button" class="secondary-btn" id="clubSpectateBtn">Phòng xem</button>
    <button type="button" class="secondary-btn" id="clubLeaderboardBtn">BXH câu lạc bộ</button>
  </div>
</section>`;
}

export function friendChallengePayload({ from, to, timeControl = '3+2', rated = false } = {}) {
  if (!from || !to || from === to) return null;
  return {
    type: 'friend-challenge',
    from: String(from),
    to: String(to),
    timeControl: String(timeControl),
    rated: Boolean(rated),
    createdAt: new Date().toISOString()
  };
}

export function spectatorRoomLabel({ white = 'Trắng', black = 'Đen', viewers = 0 } = {}) {
  const v = Math.max(0, Number(viewers) || 0);
  return `Đang xem · ${white} vs ${black}${v ? ` · ${v} người xem` : ''}`;
}

/** Board animation CSS class helpers */
export function boardSquareClasses({
  isLastFrom = false,
  isLastTo = false,
  isCheck = false,
  isSelected = false,
  isTarget = false,
  isPremoveFrom = false,
  isPremoveTo = false,
  smooth = true
} = {}) {
  return [
    isLastFrom ? 'last-from' : '',
    isLastTo ? 'last-to' : '',
    isCheck ? 'in-check' : '',
    isSelected ? 'selected' : '',
    isTarget ? 'legal-target' : '',
    isPremoveFrom ? 'premove-from' : '',
    isPremoveTo ? 'premove-to' : '',
    smooth ? 'anim-ready' : ''
  ].filter(Boolean).join(' ');
}
