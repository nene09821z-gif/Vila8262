import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { randomBytes, randomUUID, randomInt, scrypt as scryptCallback, createHmac, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { Chess } from 'chess.js';
import { calculateRankedEloChange, chooseRandomOpponent, hasRankedPresenceExpired, rankedResultFromChess, settleRankedClock } from './ranked-chess.js';
import { parseClockPreset, RANKED_CLOCK_PRESETS } from '../src/clock.js';

const scrypt = promisify(scryptCallback);
const USERNAME_RE = /^[a-zA-Z0-9_.-]{3,24}$/;
const TOKEN_TTL_SECONDS = 30 * 24 * 60 * 60;
const TOKEN_REFRESH_AFTER_SECONDS = 7 * 24 * 60 * 60;
const MIN_PASSWORD_LENGTH = 8;
const asText = (value, max = 120) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const safeEqual = (a, b) => {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && timingSafeEqual(aa, bb);
};
function maskedAddress(req) {
  const value = String(req.ip || req.socket?.remoteAddress || '').replace(/^::ffff:/, '');
  if (value.includes('.')) return value.split('.').slice(0, 3).join('.') + '.x';
  return value.includes(':') ? value.split(':').slice(0, 4).join(':') + ':…' : 'unknown';
}
function hashAddress(req) {
  return createHash('sha256').update(maskedAddress(req)).digest('hex').slice(0, 16);
}
function ensureCategoryRatings(user) {
  const fallback = Math.max(100, Math.min(4000, Math.round(Number(user?.elo) || 1200)));
  const stored = user?.ratingsByCategory && typeof user.ratingsByCategory === 'object' ? user.ratingsByCategory : {};
  const ratings = {};
  for (const category of ['bullet', 'blitz', 'rapid', 'daily']) {
    const value = Number(stored[category]);
    ratings[category] = Number.isFinite(value) && value >= 100 && value <= 4000 ? Math.round(value) : fallback;
  }
  if (user) user.ratingsByCategory = ratings;
  return ratings;
}
function publicUser(user) {
  const ratingsByCategory = ensureCategoryRatings(user);
  const elo = Math.round((ratingsByCategory.bullet + ratingsByCategory.blitz + ratingsByCategory.rapid) / 3);
  const avatarId = Number.isInteger(user.avatarId) && user.avatarId >= 0 && user.avatarId < 1000 ? user.avatarId : (parseInt(createHash('sha256').update(String(user.id || user.username || 'vila')).digest('hex').slice(0, 8), 16) % 1000);
  return {
    id: user.id, username: user.username, displayName: user.displayName, avatarId,
    bio: user.bio || '', role: user.role === 'admin' ? 'admin' : 'player',
    elo, ratingsByCategory, games: Number(user.games) || 0,
    wins: Number(user.wins) || 0, draws: Number(user.draws) || 0, losses: Number(user.losses) || 0,
    createdAt: user.createdAt, lastSeenAt: user.lastSeenAt || null,
    online: Boolean(user.lastSeenAt && Date.now() - new Date(user.lastSeenAt).getTime() < 90_000),
    banned: Boolean(user.banned)
  };
}

export async function createSocialRouter({ dataDir }) {
  const router = express.Router();
  const dbPath = path.join(dataDir, 'social-store.json');
  await fs.mkdir(dataDir, { recursive: true });
  let db;
  try {
    db = JSON.parse(await fs.readFile(dbPath, 'utf8'));
  } catch (error) {
    if (error?.code === 'ENOENT') {
      db = {};
    } else {
      // Fail closed on corrupted/unreadable data. Never overwrite the only copy
      // of account data with an empty store during automatic startup recovery.
      throw new Error(`[VILA social] Cannot read ${dbPath}; refusing to replace potentially recoverable account data. Restore a verified backup or repair the JSON file. Cause: ${error.message}`);
    }
  }
  if (!db || typeof db !== 'object' || Array.isArray(db)) {
    throw new Error(`[VILA social] Invalid store structure at ${dbPath}; refusing to reset account data automatically.`);
  }
  db.users = Array.isArray(db.users) ? db.users : [];
  db.friendRequests = Array.isArray(db.friendRequests) ? db.friendRequests : [];
  db.audit = Array.isArray(db.audit) ? db.audit : [];
  db.matches = Array.isArray(db.matches) ? db.matches : [];
  db.rankedQueue = Array.isArray(db.rankedQueue) ? db.rankedQueue : [];
  db.announcements = Array.isArray(db.announcements) ? db.announcements : [];
  db.announcementReads = db.announcementReads && typeof db.announcementReads === 'object' ? db.announcementReads : {};
  const externalTokenSecret = String(process.env.SOCIAL_TOKEN_SECRET || '');
  if (externalTokenSecret && (Buffer.byteLength(externalTokenSecret, 'utf8') < 32 || externalTokenSecret.startsWith('REPLACE_'))) {
    throw new Error('[VILA social] SOCIAL_TOKEN_SECRET must be a real random secret of at least 32 bytes, not the sample placeholder. Configure it in private server secrets.');
  }
  if (externalTokenSecret) {
    // Keep environment-provided secrets out of the persisted JSON account store.
    delete db.tokenSecret;
  } else if (typeof db.tokenSecret !== 'string' || Buffer.byteLength(db.tokenSecret, 'utf8') < 32) {
    db.tokenSecret = randomBytes(48).toString('base64url');
  }
  const tokenSecret = externalTokenSecret || db.tokenSecret;
  let writeQueue = Promise.resolve();
  const persist = () => {
    const snapshot = JSON.stringify(db, null, 2);
    writeQueue = writeQueue.catch(() => {}).then(async () => {
      const tempPath = `${dbPath}.${process.pid}.tmp`;
      await fs.writeFile(tempPath, snapshot, { mode: 0o600 });
      await fs.rename(tempPath, dbPath);
      try { await fs.chmod(dbPath, 0o600); } catch {}
    });
    return writeQueue;
  };
  const audit = async (req, actor, action, target = '', detail = '') => {
    db.audit.push({ id: randomUUID(), at: new Date().toISOString(), actor: actor || 'system', action, target: String(target).slice(0, 100), detail: String(detail).slice(0, 300), source: hashAddress(req) });
    db.audit = db.audit.slice(-2000);
    await persist();
  };

  // Bootstrap an administrator only from private deployment environment variables.
  // Never ship a default password or promote a user based on a client-supplied role.
  const adminUsername = asText(process.env.ADMIN_USERNAME, 24).toLowerCase();
  const adminPassword = String(process.env.ADMIN_PASSWORD || '');
  const adminEmail = asText(process.env.ADMIN_EMAIL, 254).toLowerCase();
  const requestedAdminElo = Number(process.env.ADMIN_INITIAL_ELO ?? 3200);
  const adminInitialElo = Number.isFinite(requestedAdminElo) ? Math.max(100, Math.min(4000, Math.round(requestedAdminElo))) : 3200;
  const seedAdminElo = admin => {
    if (!admin || admin.role !== 'admin' || admin.adminEloSeedApplied) return false;
    const noRatedGames = (Number(admin.games) || 0) === 0;
    if (noRatedGames) {
      admin.elo = adminInitialElo;
      admin.ratingsByCategory = { bullet: adminInitialElo, blitz: adminInitialElo, rapid: adminInitialElo };
    }
    admin.adminEloSeedApplied = true;
    return noRatedGames;
  };
  if (adminUsername && adminPassword) {
    if (!USERNAME_RE.test(adminUsername) || adminPassword.length < 14) {
      console.error('[VILA social] Admin bootstrap skipped: ADMIN_USERNAME must be 3–24 valid characters and ADMIN_PASSWORD must be at least 14 characters.');
    } else {
      let admin = db.users.find(u => u.username.toLowerCase() === adminUsername);
      if (!admin) {
        const salt = randomBytes(16).toString('hex');
        const hash = await scrypt(adminPassword, salt, 64);
        admin = { id: randomUUID(), username: adminUsername, displayName: 'VILA Admin', email: emailPattern.test(adminEmail) ? adminEmail : '', bio: 'Quản trị viên nền tảng', salt, passwordHash: Buffer.from(hash).toString('hex'), role: 'admin', elo: adminInitialElo, ratingsByCategory: { bullet: adminInitialElo, blitz: adminInitialElo, rapid: adminInitialElo }, adminEloSeedApplied: true, games: 0, wins: 0, draws: 0, losses: 0, banned: false, createdAt: new Date().toISOString(), lastSeenAt: null, lastSeenPersistedAt: 0 };
        db.users.push(admin);
        await audit({ ip: 'system' }, 'system', 'admin_bootstrap_created', admin.id, `username=${adminUsername}`);
        console.log(`[VILA social] Bootstrap administrator created: ${adminUsername}. Password is not logged.`);
      } else if (admin.role === 'admin') {
        const seeded = seedAdminElo(admin);
        if (seeded) await audit({ ip: 'system' }, 'system', 'admin_initial_elo_seeded', admin.id, `elo=${adminInitialElo}`);
      } else {
        // Never elevate a pre-existing username blindly: an attacker could have
        // registered it before deployment secrets were configured.
        let matchesConfiguredPassword = false;
        if (admin.salt && admin.passwordHash) {
          const configuredHash = Buffer.from(await scrypt(adminPassword, admin.salt, 64)).toString('hex');
          matchesConfiguredPassword = safeEqual(configuredHash, admin.passwordHash);
        }
        if (matchesConfiguredPassword) {
          admin.role = 'admin';
          admin.banned = false;
          admin.banReason = '';
          if (emailPattern.test(adminEmail)) admin.email = adminEmail;
          const seeded = seedAdminElo(admin);
          await audit({ ip: 'system' }, 'system', 'admin_bootstrap_promoted', admin.id, `username=${adminUsername}`);
          if (seeded) await audit({ ip: 'system' }, 'system', 'admin_initial_elo_seeded', admin.id, `elo=${adminInitialElo}`);
        } else {
          console.error(`[VILA social] Admin bootstrap refused: username ${adminUsername} already exists with a different password. Choose a new ADMIN_USERNAME or perform an authenticated admin recovery.`);
        }
      }
    }
  } else if (!db.users.some(u => u.role === 'admin')) {
    console.warn('[VILA social] No admin exists. Set ADMIN_USERNAME and ADMIN_PASSWORD (14+ chars) in private server environment to bootstrap one.');
  }
  await persist();

  const limits = new Map();
  function rateLimit({ name, max, windowMs }) {
    return (req, res, next) => {
      const key = `${name}:${req.ip || req.socket?.remoteAddress || 'unknown'}`;
      const now = Date.now();
      let item = limits.get(key);
      if (!item || now - item.start >= windowMs) item = { start: now, count: 0 };
      item.count += 1; limits.set(key, item);
      if (limits.size > 5000) for (const [k, v] of limits) if (now - v.start > windowMs) limits.delete(k);
      if (item.count > max) {
        res.setHeader('Retry-After', String(Math.max(1, Math.ceil((windowMs - (now - item.start)) / 1000))));
        return res.status(429).json({ error: 'Quá nhiều yêu cầu. Hãy chờ một chút rồi thử lại.' });
      }
      next();
    };
  }
  router.use(rateLimit({ name: 'all', max: 300, windowMs: 60_000 }));
  router.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    next();
  });

  function signToken(user) {
    const now = Math.floor(Date.now() / 1000);
    const payload = Buffer.from(JSON.stringify({ sub: user.id, ver: Number(user.sessionVersion) || 0, iat: now, exp: now + TOKEN_TTL_SECONDS })).toString('base64url');
    const sig = createHmac('sha256', tokenSecret).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }
  function verifyToken(token) {
    const [payload, sig, extra] = String(token || '').split('.');
    if (!payload || !sig || extra) return null;
    const expected = createHmac('sha256', tokenSecret).update(payload).digest('base64url');
    if (!safeEqual(sig, expected)) return null;
    try {
      const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
      if (!data.sub || !Number.isFinite(data.exp) || data.exp <= Date.now() / 1000) return null;
      return data;
    } catch { return null; }
  }
  async function requireAuth(req, res, next) {
    const token = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const payload = verifyToken(token);
    if (!payload) return res.status(401).json({ error: 'Phiên đăng nhập hết hạn hoặc không hợp lệ. Hãy đăng nhập lại.' });
    const user = db.users.find(u => u.id === payload.sub);
    if (!user || user.banned) return res.status(403).json({ error: user?.banned ? 'Tài khoản đã bị khóa. Liên hệ quản trị viên để khiếu nại.' : 'Không tìm thấy tài khoản.' });
    if ((Number(payload.ver) || 0) !== (Number(user.sessionVersion) || 0)) return res.status(401).json({ error: 'Phiên đăng nhập đã bị thu hồi. Hãy đăng nhập lại.' });
    req.socialUser = user;
    req.tokenPayload = payload;
    user.lastSeenAt = new Date().toISOString();
    if (Date.now() - Number(user.lastSeenPersistedAt || 0) > 60_000) {
      user.lastSeenPersistedAt = Date.now();
      persist().catch(error => console.error('[VILA social] presence persistence error:', error.message));
    }
    next();
  }
  const requireAdmin = (req, res, next) => {
    if (req.socialUser?.role !== 'admin') return res.status(403).json({ error: 'Chỉ quản trị viên mới được truy cập khu vực này.' });
    next();
  };
  const findUser = username => db.users.find(u => u.username.toLowerCase() === String(username).toLowerCase());
  function usernameFromNickname(nickname) {
    let base = String(nickname || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_.-]/g, '').toLowerCase().slice(0, 18);
    if (base.length < 3) base = 'player';
    let candidate = base;
    while (findUser(candidate)) {
      const suffix = randomBytes(2).toString('hex');
      candidate = `${base.slice(0, 18)}${suffix}`.slice(0, 24);
    }
    return candidate;
  }
  function chooseAvatarId() {
    // Use every profile design at most once until all 1,000 designs have been assigned.
    // Legacy users without avatarId are included via the same stable fallback used in publicUser().
    const used = new Set(db.users.map(user => Number.isInteger(user.avatarId) && user.avatarId >= 0 && user.avatarId < 1000
      ? user.avatarId
      : parseInt(createHash('sha256').update(String(user.id || user.username || 'vila')).digest('hex').slice(0, 8), 16) % 1000));
    const available = [];
    for (let id = 0; id < 1000; id += 1) if (!used.has(id)) available.push(id);
    return available.length ? available[randomInt(0, available.length)] : randomInt(0, 1000);
  }
  function emailCodeHash(userId, code) {
    return createHash('sha256').update(`${userId}:${code}:${tokenSecret}`).digest('hex');
  }
  async function deliverPasswordReset(email, code) {
    const apiKey = String(process.env.RESEND_API_KEY || '').trim();
    const from = String(process.env.RESET_EMAIL_FROM || '').trim();
    if (!apiKey || !from || !emailPattern.test(from.replace(/^.*<([^>]+)>.*$/, '$1'))) {
      throw new Error('Khôi phục email chưa được cấu hình. Máy chủ cần RESEND_API_KEY và RESET_EMAIL_FROM hợp lệ.');
    }
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [email],
        subject: 'Mã khôi phục tài khoản Cờ Vua ViLa',
        text: `Mã khôi phục tài khoản Cờ Vua ViLa của bạn là ${code}. Mã có hiệu lực trong 10 phút. Không chia sẻ mã này cho bất kỳ ai. Nếu bạn không yêu cầu, hãy bỏ qua email này.`,
        html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:24px;color:#1b2b39"><h2>Cờ Vua ViLa</h2><p>Mã khôi phục tài khoản của bạn:</p><div style="font-size:34px;font-weight:800;letter-spacing:8px;padding:18px;background:#eff6ff;border-radius:12px;text-align:center">${code}</div><p>Mã có hiệu lực trong <b>10 phút</b>. Không chia sẻ mã này cho bất kỳ ai.</p><p>Nếu bạn không yêu cầu khôi phục mật khẩu, hãy bỏ qua email này.</p></div>`
      }),
      signal: AbortSignal.timeout(15000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(`Dịch vụ email từ chối gửi mã (HTTP ${response.status}). Kiểm tra cấu hình Resend và tên miền người gửi.`);
    return data;
  }


  router.get('/health', (_req, res) => {
    res.json({ ok: true, service: 'Cờ Vua ViLa social', status: 'online', timestamp: new Date().toISOString() });
  });

  router.post('/auth/register', rateLimit({ name: 'register', max: 20, windowMs: 60 * 60_000 }), async (req, res) => {
    const username = asText(req.body?.username, 24).toLowerCase();
    const displayName = asText(req.body?.displayName || username, 40);
    const email = asText(req.body?.email, 254).toLowerCase();
    const password = String(req.body?.password || '');
    if (!USERNAME_RE.test(username)) return res.status(400).json({ error: 'Tên tài khoản dài 3–24 ký tự, chỉ gồm chữ, số, dấu chấm, gạch dưới hoặc gạch ngang.' });
    if (displayName.length < 2) return res.status(400).json({ error: 'Tên hiển thị cần ít nhất 2 ký tự.' });
    if (password.length < MIN_PASSWORD_LENGTH || password.length > 256) return res.status(400).json({ error: `Mật khẩu cần dài từ ${MIN_PASSWORD_LENGTH} đến 256 ký tự.` });
    if (email && !emailPattern.test(email)) return res.status(400).json({ error: 'Email không hợp lệ (có thể bỏ trống).' });
    const conflict = () => {
      if (findUser(username)) return 'Tên tài khoản đã được sử dụng.';
      if (email && db.users.some(u => String(u.email || '').toLowerCase() === email)) return 'Email này đã được dùng cho tài khoản khác.';
      if (db.users.some(u => String(u.displayName || '').trim().toLowerCase() === displayName.toLowerCase())) return 'Biệt danh này đã được dùng. Hãy chọn biệt danh khác.';
      return '';
    };
    const before = conflict();
    if (before) return res.status(409).json({ error: before });
    const eloChoices = [600, 900, 1200, 1600, 2000, 2600];
    const initialElo = eloChoices.includes(Number(req.body?.initialElo)) ? Number(req.body.initialElo) : 1200;
    const salt = randomBytes(16).toString('hex');
    const hash = await scrypt(password, salt, 64);
    // Re-check after the async hash: two concurrent sign-ups must not create duplicate usernames.
    const after = conflict();
    if (after) return res.status(409).json({ error: after });
    const user = { id: randomUUID(), username, displayName, email, avatarId: chooseAvatarId(), skillTierElo: initialElo, ratingsByCategory: { bullet: initialElo, blitz: initialElo, rapid: initialElo, daily: initialElo }, bio: '', salt, passwordHash: Buffer.from(hash).toString('hex'), role: 'player', elo: initialElo, games: 0, wins: 0, draws: 0, losses: 0, banned: false, createdAt: new Date().toISOString(), lastSeenAt: new Date().toISOString(), lastSeenPersistedAt: Date.now() };
    db.users.push(user);
    await audit(req, user.id, 'account_registered', user.id, 'local password account');
    res.status(201).json({ token: signToken(user), user: publicUser(user) });
  });

  router.post('/auth/login', rateLimit({ name: 'login', max: 40, windowMs: 15 * 60_000 }), async (req, res) => {
    const username = asText(req.body?.username, 254).toLowerCase();
    const password = String(req.body?.password || '');
    if (!username || !password || password.length > 256) return res.status(400).json({ error: 'Nhập tên đăng nhập và mật khẩu.' });
    const user = findUser(username) || db.users.find(u => u.email && u.email.toLowerCase() === username) || db.users.find(u => String(u.displayName || '').trim().toLowerCase() === username);
    if (!user || !user.salt || !user.passwordHash) {
      // Keep failed-login response generic to avoid exposing registered usernames.
      await audit(req, 'anonymous', 'login_failed', username, 'invalid credentials');
      return res.status(401).json({ error: 'Tên đăng nhập/email hoặc mật khẩu không đúng.' });
    }
    const candidate = Buffer.from(await scrypt(password, user.salt, 64)).toString('hex');
    if (!safeEqual(candidate, user.passwordHash)) {
      await audit(req, 'anonymous', 'login_failed', user.id, 'invalid credentials');
      return res.status(401).json({ error: 'Tên đăng nhập/email hoặc mật khẩu không đúng.' });
    }
    if (user.banned) return res.status(403).json({ error: 'Tài khoản đã bị khóa. Liên hệ quản trị viên để khiếu nại.' });
    user.lastSeenAt = new Date().toISOString();
    user.lastSeenPersistedAt = Date.now();
    await audit(req, user.id, 'login_success', user.id, 'password login');
    res.json({ token: signToken(user), user: publicUser(user) });
  });

  // Password recovery uses a cryptographically random six-digit, one-time code.
  // The code is only stored as a keyed hash and expires after ten minutes.
  router.post('/auth/forgot-password', rateLimit({ name: 'forgot-password', max: 4, windowMs: 60 * 60_000 }), async (req, res) => {
    const email = asText(req.body?.email, 254).toLowerCase();
    if (!emailPattern.test(email)) return res.status(400).json({ error: 'Nhập địa chỉ email hợp lệ.' });
    if (!process.env.RESEND_API_KEY || !process.env.RESET_EMAIL_FROM) return res.status(503).json({ error: 'Máy chủ chưa cấu hình gửi email. Admin cần thiết lập RESEND_API_KEY và RESET_EMAIL_FROM trong Termux.' });
    const user = db.users.find(item => String(item.email || '').toLowerCase() === email && item.salt && item.passwordHash);
    // Do not disclose whether a given address has an account.
    if (!user || user.banned) return res.json({ ok: true, message: 'Nếu email có tài khoản hợp lệ, mã khôi phục sẽ được gửi trong ít phút.' });
    const code = String(randomInt(100000, 1000000));
    user.passwordReset = { codeHash: emailCodeHash(user.id, code), expiresAt: Date.now() + 10 * 60_000, attempts: 0 };
    await persist();
    try {
      await deliverPasswordReset(email, code);
      await audit(req, user.id, 'password_reset_code_sent', user.id, 'six-digit code');
      res.json({ ok: true, message: 'Nếu email có tài khoản hợp lệ, mã khôi phục sẽ được gửi trong ít phút.' });
    } catch (error) {
      delete user.passwordReset;
      await persist();
      res.status(502).json({ error: String(error?.message || error).slice(0, 220) });
    }
  });

  router.post('/auth/reset-password', rateLimit({ name: 'reset-password', max: 8, windowMs: 15 * 60_000 }), async (req, res) => {
    const email = asText(req.body?.email, 254).toLowerCase();
    const code = asText(req.body?.code, 6);
    const password = String(req.body?.password || '');
    if (!emailPattern.test(email) || !/^\d{6}$/.test(code)) return res.status(400).json({ error: 'Email hoặc mã 6 chữ số không hợp lệ.' });
    if (password.length < MIN_PASSWORD_LENGTH || password.length > 256) return res.status(400).json({ error: `Mật khẩu mới cần dài từ ${MIN_PASSWORD_LENGTH} đến 256 ký tự.` });
    const user = db.users.find(item => String(item.email || '').toLowerCase() === email && item.passwordReset);
    if (!user || user.passwordReset.expiresAt < Date.now()) {
      if (user) { delete user.passwordReset; await persist(); }
      return res.status(400).json({ error: 'Mã không đúng hoặc đã hết hạn. Hãy yêu cầu mã mới.' });
    }
    user.passwordReset.attempts = (Number(user.passwordReset.attempts) || 0) + 1;
    if (user.passwordReset.attempts > 5) {
      delete user.passwordReset;
      await persist();
      return res.status(429).json({ error: 'Bạn đã nhập sai mã quá nhiều lần. Hãy yêu cầu mã mới.' });
    }
    const candidateHash = emailCodeHash(user.id, code);
    if (!safeEqual(candidateHash, user.passwordReset.codeHash)) {
      await persist();
      return res.status(400).json({ error: 'Mã không đúng hoặc đã hết hạn. Hãy kiểm tra email và thử lại.' });
    }
    const salt = randomBytes(16).toString('hex');
    const hash = await scrypt(password, salt, 64);
    user.salt = salt;
    user.passwordHash = Buffer.from(hash).toString('hex');
    user.sessionVersion = (Number(user.sessionVersion) || 0) + 1;
    delete user.passwordReset;
    await audit(req, user.id, 'password_reset_success', user.id, 'password reset with email code');
    res.json({ ok: true, message: 'Đã đổi mật khẩu. Hãy đăng nhập lại bằng mật khẩu mới.' });
  });

  router.get('/inbox', requireAuth, (req, res) => {
    const reads = new Set(Array.isArray(db.announcementReads[req.socialUser.id]) ? db.announcementReads[req.socialUser.id] : []);
    const announcements = db.announcements.slice(-100).reverse().map(item => ({ ...item, read: reads.has(item.id) }));
    res.json({ announcements, unread: announcements.filter(item => !item.read).length });
  });
  router.post('/inbox/:announcementId/read', requireAuth, async (req, res) => {
    const announcement = db.announcements.find(item => item.id === req.params.announcementId);
    if (!announcement) return res.status(404).json({ error: 'Không tìm thấy thông báo.' });
    const userId = req.socialUser.id;
    const reads = Array.isArray(db.announcementReads[userId]) ? db.announcementReads[userId] : [];
    if (!reads.includes(announcement.id)) reads.push(announcement.id);
    db.announcementReads[userId] = reads.slice(-500);
    await persist();
    res.json({ ok: true });
  });
  router.post('/inbox/read-all', requireAuth, async (req, res) => {
    db.announcementReads[req.socialUser.id] = db.announcements.slice(-500).map(item => item.id);
    await persist();
    res.json({ ok: true });
  });

  router.post('/history/sync', requireAuth, async (req, res) => {
    const clientGames = Array.isArray(req.body?.games) ? req.body.games : [];
    if (!db.userHistory || typeof db.userHistory !== 'object') db.userHistory = {};
    const existing = Array.isArray(db.userHistory[req.socialUser.id]) ? db.userHistory[req.socialUser.id] : [];
    const signatures = new Set(existing.map(g => g.signature || g.id));
    for (const g of clientGames) {
      if (!g || typeof g !== 'object') continue;
      const key = g.signature || g.id;
      if (!key || signatures.has(key)) continue;
      signatures.add(key);
      existing.push(g);
    }
    existing.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    db.userHistory[req.socialUser.id] = existing.slice(0, 150);
    await persist();
    res.json({ ok: true, syncedCount: db.userHistory[req.socialUser.id].length, games: db.userHistory[req.socialUser.id] });
  });

  router.get('/history', requireAuth, (req, res) => {
    if (!db.userHistory || typeof db.userHistory !== 'object') db.userHistory = {};
    const games = Array.isArray(db.userHistory[req.socialUser.id]) ? db.userHistory[req.socialUser.id] : [];
    res.json({ ok: true, games });
  });

  // Sliding session: a still-valid token older than a week is exchanged for a fresh 30-day one,
  // so an account that is opened at least monthly never has to sign in again.
  router.get('/auth/me', requireAuth, (req, res) => {
    const body = { user: publicUser(req.socialUser) };
    const issuedAt = Number(req.tokenPayload?.iat) || 0;
    if (Math.floor(Date.now() / 1000) - issuedAt > TOKEN_REFRESH_AFTER_SECONDS) body.token = signToken(req.socialUser);
    res.json(body);
  });
  router.post('/auth/logout', requireAuth, async (req, res) => {
    // Revokes every token previously issued for this account.
    req.socialUser.sessionVersion = (Number(req.socialUser.sessionVersion) || 0) + 1;
    await persist();
    res.json({ ok: true });
  });
  router.patch('/profile', requireAuth, async (req, res) => {
    const displayName = asText(req.body?.displayName, 40);
    const bio = asText(req.body?.bio, 180);
    if (displayName.length < 2) return res.status(400).json({ error: 'Tên hiển thị cần ít nhất 2 ký tự.' });
    if (db.users.some(u => u.id !== req.socialUser.id && String(u.displayName || '').trim().toLowerCase() === displayName.toLowerCase())) return res.status(409).json({ error: 'Biệt danh này đã được người khác sử dụng.' });
    req.socialUser.displayName = displayName;
    req.socialUser.bio = bio;
    await persist();
    res.json({ user: publicUser(req.socialUser) });
  });

  router.get('/users/search', requireAuth, (req, res) => {
    const q = asText(req.query.q, 30).toLowerCase();
    if (q.length < 2) return res.status(400).json({ error: 'Nhập ít nhất 2 ký tự để tìm người chơi.' });
    const results = db.users.filter(u => !u.banned && u.id !== req.socialUser.id && (u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q))).slice(0, 20).map(publicUser);
    res.json({ users: results });
  });

  router.get('/friends', requireAuth, (req, res) => {
    const userId = req.socialUser.id;
    const accepted = db.friendRequests.filter(r => r.status === 'accepted' && (r.from === userId || r.to === userId));
    const incoming = db.friendRequests.filter(r => r.status === 'pending' && r.to === userId).map(r => ({ id: r.id, createdAt: r.createdAt, user: publicUser(db.users.find(u => u.id === r.from) || { id: '', username: 'unknown', displayName: 'Tài khoản không tồn tại' }) }));
    const outgoing = db.friendRequests.filter(r => r.status === 'pending' && r.from === userId).map(r => ({ id: r.id, createdAt: r.createdAt, user: publicUser(db.users.find(u => u.id === r.to) || { id: '', username: 'unknown', displayName: 'Tài khoản không tồn tại' }) }));
    const friends = accepted.map(r => db.users.find(u => u.id === (r.from === userId ? r.to : r.from))).filter(Boolean).filter(u => !u.banned).map(publicUser).sort((a, b) => Number(b.online) - Number(a.online) || a.displayName.localeCompare(b.displayName));
    res.json({ friends, incoming, outgoing });
  });

  router.post('/friends/request', requireAuth, async (req, res) => {
    const username = asText(req.body?.username, 24).toLowerCase();
    const target = findUser(username);
    if (!target || target.banned) return res.status(404).json({ error: 'Không tìm thấy người chơi này.' });
    if (target.id === req.socialUser.id) return res.status(400).json({ error: 'Bạn không thể tự kết bạn với mình.' });
    let existing = db.friendRequests.find(r => (r.from === req.socialUser.id && r.to === target.id) || (r.from === target.id && r.to === req.socialUser.id));
    if (existing?.status === 'accepted') return res.status(409).json({ error: 'Hai bạn đã là bạn bè.' });
    if (existing?.status === 'pending' && existing.from === target.id) {
      existing.status = 'accepted'; existing.updatedAt = new Date().toISOString();
      await audit(req, req.socialUser.id, 'friend_request_auto_accepted', target.id, 'reciprocal request');
      return res.json({ message: 'Đã chấp nhận lời mời đang chờ; hai bạn đã là bạn bè.' });
    }
    if (existing?.status === 'pending') return res.status(409).json({ error: 'Lời mời kết bạn đã được gửi.' });
    existing = { id: randomUUID(), from: req.socialUser.id, to: target.id, status: 'pending', createdAt: new Date().toISOString(), updatedAt: null };
    db.friendRequests.push(existing);
    await audit(req, req.socialUser.id, 'friend_request_sent', target.id, 'pending');
    res.status(201).json({ message: `Đã gửi lời mời kết bạn tới @${target.username}.` });
  });

  router.post('/friends/:requestId/accept', requireAuth, async (req, res) => {
    const item = db.friendRequests.find(r => r.id === req.params.requestId && r.to === req.socialUser.id && r.status === 'pending');
    if (!item) return res.status(404).json({ error: 'Không tìm thấy lời mời đang chờ.' });
    item.status = 'accepted'; item.updatedAt = new Date().toISOString();
    await audit(req, req.socialUser.id, 'friend_request_accepted', item.from, 'accepted');
    res.json({ message: 'Đã thêm bạn bè.' });
  });

  router.delete('/friends/:friendId', requireAuth, async (req, res) => {
    const userId = req.socialUser.id;
    const before = db.friendRequests.length;
    db.friendRequests = db.friendRequests.filter(r => !((r.from === userId && r.to === req.params.friendId) || (r.from === req.params.friendId && r.to === userId)));
    if (before === db.friendRequests.length) return res.status(404).json({ error: 'Không tìm thấy bạn bè/lời mời tương ứng.' });
    await audit(req, userId, 'friend_relation_removed', req.params.friendId, 'removed relationship or request');
    res.json({ message: 'Đã cập nhật danh sách bạn bè.' });
  });

  // Server-authoritative ranked 1v1. This implementation is intended for one
  // persistent backend instance; use a transactional shared database before horizontal scaling.
  const rankedMatchById = id => db.matches.find(match => match?.ranked === true && match.id === id);
  const rankedMatchPayload = (match, userId) => {
    const color = match.players?.w === userId ? 'w' : 'b';
    const opponentId = color === 'w' ? match.players.b : match.players.w;
    const opponent = db.users.find(user => user.id === opponentId);
    return {
      match: {
        id: match.id, ranked: true, status: match.status, startFen: match.startFen,
        fen: match.fen, moves: match.moves || [], currentPly: (match.moves || []).length,
        players: { w: publicUser(db.users.find(user => user.id === match.players.w) || {}), b: publicUser(db.users.find(user => user.id === match.players.b) || {}) },
        color, opponent: opponent ? publicUser(opponent) : null, result: match.result || null,
        resultReason: match.resultReason || '', finishedAt: match.finishedAt || null,
        eloChanges: match.eloChanges?.[userId] || null,
        lastMoveAt: match.lastMoveAt || match.createdAt, timeControl: match.timeControl || '3+2',
        timeCategory: match.timeCategory || 'blitz', clockEnabled: Boolean(match.clockEnabled),
        clockRemainingMs: match.clockRemainingMs || null, clockIncrementMs: Number(match.clockIncrementMs) || 0,
        clockUpdatedAt: Number(match.clockUpdatedAt) || Date.now()
      }
    };
  };
  const activeRankedMatchFor = userId => db.matches.find(match => match?.ranked === true && match.status === 'active' && (match.players?.w === userId || match.players?.b === userId));
  const rankedJoinPayload = (userId) => {
    const match = activeRankedMatchFor(userId);
    if (match) return { queued: false, ...rankedMatchPayload(match, userId) };
    const queueItem = db.rankedQueue.find(entry => entry.userId === userId);
    return { queued: Boolean(queueItem), joinedAt: queueItem?.joinedAt || null, waitMs: queueItem ? Math.max(0, Date.now() - queueItem.joinedAt) : 0, rating: Number(db.users.find(user => user.id === userId)?.elo) || 1200 };
  };
  async function finishRankedMatch(match, result, reason = 'game_over', quitterId = '') {
    if (!match || match.status !== 'active') return;
    const white = db.users.find(user => user.id === match.players.w);
    const black = db.users.find(user => user.id === match.players.b);
    if (!white || !black) {
      match.status = 'aborted'; match.resultReason = 'player_missing'; match.finishedAt = new Date().toISOString();
      await persist();
      return;
    }
    const whiteScore = result === '1-0' ? 1 : result === '0-1' ? 0 : 0.5;
    const category = ['bullet', 'blitz', 'rapid'].includes(match.timeCategory) ? match.timeCategory : 'blitz';
    const whiteRatings = ensureCategoryRatings(white);
    const blackRatings = ensureCategoryRatings(black);
    const whiteBefore = whiteRatings[category];
    const blackBefore = blackRatings[category];
    // Use a fixed K-factor so ratings reflect only pre-game ratings and the actual result.
    // Random winner bonuses made identical results produce inconsistent rating changes.
    const kFactor = 24;
    const whiteCalc = calculateRankedEloChange(whiteBefore, blackBefore, whiteScore, kFactor);
    const blackCalc = calculateRankedEloChange(blackBefore, whiteBefore, 1 - whiteScore, kFactor);
    const whitePenalty = quitterId === white.id ? 15 : 0;
    const blackPenalty = quitterId === black.id ? 15 : 0;
    whiteRatings[category] = Math.max(100, whiteCalc.after - whitePenalty);
    blackRatings[category] = Math.max(100, blackCalc.after - blackPenalty);
    white.ratingsByCategory = whiteRatings; black.ratingsByCategory = blackRatings;
    white.elo = Math.round((whiteRatings.bullet + whiteRatings.blitz + whiteRatings.rapid) / 3);
    black.elo = Math.round((blackRatings.bullet + blackRatings.blitz + blackRatings.rapid) / 3);
    white.games = (Number(white.games) || 0) + 1; black.games = (Number(black.games) || 0) + 1;
    if (whiteScore === 1) { white.wins = (Number(white.wins) || 0) + 1; black.losses = (Number(black.losses) || 0) + 1; }
    else if (whiteScore === 0) { black.wins = (Number(black.wins) || 0) + 1; white.losses = (Number(white.losses) || 0) + 1; }
    else { white.draws = (Number(white.draws) || 0) + 1; black.draws = (Number(black.draws) || 0) + 1; }
    white.rankedLastChange = whiteRatings[category] - whiteBefore;
    black.rankedLastChange = blackRatings[category] - blackBefore;
    match.status = 'finished'; match.result = result; match.resultReason = reason; match.finishedAt = new Date().toISOString();
    match.eloChanges = {
      [white.id]: { category, before: whiteBefore, after: whiteRatings[category], delta: whiteRatings[category] - whiteBefore },
      [black.id]: { category, before: blackBefore, after: blackRatings[category], delta: blackRatings[category] - blackBefore }
    };
    db.rankedQueue = db.rankedQueue.filter(entry => entry.userId !== white.id && entry.userId !== black.id);
    await persist();
  }
  // A foreground client refreshes presence through /ranked/status every 1.8s.
  // Explicit in-app exit resigns immediately; this server fallback catches a
  // closed tab/network drop after a 90s grace period. Persisted epoch times also
  // survive a backend restart without silently resetting the timer.
  const RANKED_PRESENCE_TIMEOUT_MS = 90_000;
  async function expireInactiveRankedMatch(match, now = Date.now()) {
    if (!match || match.status !== 'active') return false;
    const players = [match.players?.w, match.players?.b].filter(Boolean);
    if (players.length !== 2) return false;
    match.presence = match.presence && typeof match.presence === 'object' ? match.presence : {};
    const createdAt = Date.parse(match.createdAt || '') || now;
    const stale = players.map(userId => ({
      userId,
      lastSeen: Number(match.presence[userId]) || createdAt
    })).filter(item => hasRankedPresenceExpired(item.lastSeen, now, RANKED_PRESENCE_TIMEOUT_MS))
      .sort((a, b) => a.lastSeen - b.lastSeen);
    if (!stale.length) return false;
    const quitterId = stale[0].userId;
    const winnerId = players.find(userId => userId !== quitterId);
    await finishRankedMatch(match, winnerId === match.players.w ? '1-0' : '0-1', 'disconnect_timeout', quitterId);
    return true;
  }
  const rankedLimiter = rateLimit({ name: 'ranked', max: 120, windowMs: 60_000 });
  router.post('/ranked/queue', rankedLimiter, requireAuth, async (req, res) => {
    const user = req.socialUser;
    if (activeRankedMatchFor(user.id)) return res.json(rankedJoinPayload(user.id));
    const requestedTimeControl = asText(req.body?.timeControl, 16) || '3+2';
    if (!RANKED_CLOCK_PRESETS.some(preset => preset.value === requestedTimeControl)) {
      return res.status(400).json({ error: 'Mốc thời gian không được hỗ trợ.' });
    }
    const clock = parseClockPreset(requestedTimeControl);
    if (!clock.enabled || !['bullet', 'blitz', 'rapid', 'daily'].includes(clock.category)) {
      return res.status(400).json({ error: 'Đấu trực tuyến cần chọn một mốc thời gian hợp lệ.' });
    }
    const timeControl = clock.preset;
    const timeCategory = clock.category;
    const now = Date.now();
    db.rankedQueue = db.rankedQueue.filter(entry => now - Number(entry.joinedAt || 0) < 180_000 && db.users.some(candidate => candidate.id === entry.userId && !candidate.banned) && !activeRankedMatchFor(entry.userId));
    const selfEntry = db.rankedQueue.find(entry => entry.userId === user.id);
    if (selfEntry) {
      if (selfEntry.timeControl === timeControl) return res.json(rankedJoinPayload(user.id));
      db.rankedQueue = db.rankedQueue.filter(entry => entry.userId !== user.id);
    }
    const ownRatings = ensureCategoryRatings(user);
    const ownElo = ownRatings[timeCategory];
    const eligibleQueue = db.rankedQueue.filter(entry => entry.timeControl === timeControl && entry.timeCategory === timeCategory);
    const candidate = chooseRandomOpponent(eligibleQueue, user.id, ownElo, now, () => Math.random());
    if (!candidate) {
      db.rankedQueue.push({ userId: user.id, elo: ownElo, timeControl, timeCategory, joinedAt: now });
      await persist();
      return res.status(202).json({ ...rankedJoinPayload(user.id), rating: ownElo, timeControl, timeCategory });
    }
    db.rankedQueue = db.rankedQueue.filter(entry => entry.userId !== candidate.userId && entry.userId !== user.id);
    const opponent = db.users.find(item => item.id === candidate.userId);
    if (!opponent || opponent.banned) {
      db.rankedQueue.push({ userId: user.id, elo: ownElo, timeControl, timeCategory, joinedAt: now });
      await persist();
      return res.status(202).json({ ...rankedJoinPayload(user.id), rating: ownElo, timeControl, timeCategory });
    }
    const opponentElo = ensureCategoryRatings(opponent)[timeCategory];
    const whiteId = randomBytes(1)[0] % 2 ? user.id : opponent.id;
    const blackId = whiteId === user.id ? opponent.id : user.id;
    const chess = new Chess();
    const match = {
      id: randomUUID(), ranked: true, status: 'active', players: { w: whiteId, b: blackId },
      startFen: chess.fen(), fen: chess.fen(), moves: [], result: null, resultReason: '',
      createdAt: new Date().toISOString(), lastMoveAt: new Date().toISOString(), eloChanges: {},
      timeControl, timeCategory, clockEnabled: true,
      clockRemainingMs: { w: clock.baseMs, b: clock.baseMs },
      clockIncrementMs: clock.incrementMs, clockUpdatedAt: now,
      presence: { [whiteId]: now, [blackId]: now }
    };
    db.matches.push(match); db.matches = db.matches.slice(-500);
    await persist();
    await audit(req, user.id, 'ranked_match_created', match.id, `versus=${opponent.username}; ${timeCategory} ${timeControl}; ratings=${ownElo}:${opponentElo}`);
    res.status(201).json({ queued: false, ...rankedMatchPayload(match, user.id) });
  });
  router.get('/ranked/status', rankedLimiter, requireAuth, async (req, res) => {
    const now = Date.now();
    db.rankedQueue = db.rankedQueue.filter(entry => now - Number(entry.joinedAt || 0) < 180_000 && db.users.some(user => user.id === entry.userId && !user.banned) && !activeRankedMatchFor(entry.userId));
    const active = activeRankedMatchFor(req.socialUser.id);
    if (active) {
      const turn = new Chess(active.fen || active.startFen || new Chess().fen()).turn();
      const timedOutColor = settleRankedClock(active, now, turn);
      if (timedOutColor) {
        await finishRankedMatch(active, timedOutColor === 'w' ? '0-1' : '1-0', 'time_forfeit');
        return res.json({ queued: false, ...rankedMatchPayload(active, req.socialUser.id) });
      }
      const expired = await expireInactiveRankedMatch(active, now);
      if (expired) return res.json({ queued: false, ...rankedMatchPayload(active, req.socialUser.id) });
      active.presence = active.presence && typeof active.presence === 'object' ? active.presence : {};
      active.presence[req.socialUser.id] = now;
      if (now - Number(active.presencePersistedAt || 0) >= 5_000) {
        active.presencePersistedAt = now;
        await persist();
      }
      return res.json({ queued: false, ...rankedMatchPayload(active, req.socialUser.id) });
    }
    const queueItem = db.rankedQueue.find(entry => entry.userId === req.socialUser.id);
    if (queueItem) { await persist(); return res.json(rankedJoinPayload(req.socialUser.id)); }
    // A finished result stays visible for a short period so the opponent's next
    // poll receives the same result panel and their own Elo delta.
    const recentFinished = db.matches.filter(match => match?.ranked === true && match.status === 'finished' &&
      (match.players?.w === req.socialUser.id || match.players?.b === req.socialUser.id) &&
      now - (Date.parse(match.finishedAt || '') || 0) < 15 * 60_000)
      .sort((a, b) => (Date.parse(b.finishedAt || '') || 0) - (Date.parse(a.finishedAt || '') || 0))[0];
    if (recentFinished) return res.json({ queued: false, ...rankedMatchPayload(recentFinished, req.socialUser.id) });
    return res.json({ queued: false, rating: Number(req.socialUser.elo) || 1200, ratingsByCategory: ensureCategoryRatings(req.socialUser), waitMs: 0 });
  });
  router.post('/ranked/cancel-queue', rankedLimiter, requireAuth, async (req, res) => {
    const before = db.rankedQueue.length;
    db.rankedQueue = db.rankedQueue.filter(entry => entry.userId !== req.socialUser.id);
    if (before !== db.rankedQueue.length) await persist();
    res.json({ queued: false, cancelled: before !== db.rankedQueue.length });
  });
  router.post('/ranked/matches/:matchId/move', rankedLimiter, requireAuth, async (req, res) => {
    const match = rankedMatchById(req.params.matchId);
    if (!match || match.status !== 'active') return res.status(404).json({ error: 'Không tìm thấy trận xếp hạng đang hoạt động.' });
    const userId = req.socialUser.id;
    const color = match.players.w === userId ? 'w' : match.players.b === userId ? 'b' : '';
    if (!color) return res.status(403).json({ error: 'Bạn không thuộc trận đấu này.' });
    const clockNow = Date.now();
    const clockTurn = new Chess(match.fen || match.startFen || new Chess().fen()).turn();
    const timedOutColor = settleRankedClock(match, clockNow, clockTurn);
    if (timedOutColor) {
      await finishRankedMatch(match, timedOutColor === 'w' ? '0-1' : '1-0', 'time_forfeit');
      return res.status(409).json({ error: 'Hết giờ. Máy chủ đã xác nhận kết quả.', match: rankedMatchPayload(match, userId).match });
    }
    if (await expireInactiveRankedMatch(match)) return res.status(409).json({ error: 'Trận đã kết thúc vì người chơi mất kết nối quá lâu.', match: rankedMatchPayload(match, userId).match });
    match.presence = match.presence && typeof match.presence === 'object' ? match.presence : {};
    match.presence[userId] = Date.now();
    if (Number(req.body?.expectedPly) !== (match.moves || []).length) return res.status(409).json({ error: 'Bàn cờ đã được cập nhật bởi đối thủ. Đang đồng bộ lại.', match: rankedMatchPayload(match, userId).match });
    const chess = new Chess(match.fen);
    if (chess.turn() !== color) return res.status(409).json({ error: 'Chưa đến lượt của bạn.', match: rankedMatchPayload(match, userId).match });
    const from = asText(req.body?.from, 2); const to = asText(req.body?.to, 2); const promotion = asText(req.body?.promotion, 1).toLowerCase();
    if (!/^[a-h][1-8]$/.test(from) || !/^[a-h][1-8]$/.test(to) || (promotion && !/^[qrbn]$/.test(promotion))) return res.status(400).json({ error: 'Nước đi không hợp lệ.' });
    let move;
    try { move = chess.move({ from, to, ...(promotion ? { promotion } : {}) }); } catch { move = null; }
    if (!move) return res.status(400).json({ error: 'Nước đi không hợp lệ theo luật cờ vua.' });
    match.moves.push({ from: move.from, to: move.to, promotion: move.promotion || '', san: move.san, flags: move.flags });
    match.fen = chess.fen(); match.lastMoveAt = new Date().toISOString();
    if (match.clockEnabled && match.clockRemainingMs) match.clockRemainingMs[color] = Math.max(0, Number(match.clockRemainingMs[color]) || 0) + Math.max(0, Number(match.clockIncrementMs) || 0);
    match.clockUpdatedAt = Date.now();
    const result = rankedResultFromChess(chess);
    if (result) await finishRankedMatch(match, result, chess.isCheckmate() ? 'checkmate' : 'draw');
    else await persist();
    res.json(rankedMatchPayload(match, userId));
  });
  router.post('/ranked/matches/:matchId/resign', rankedLimiter, requireAuth, async (req, res) => {
    const match = rankedMatchById(req.params.matchId);
    if (!match || match.status !== 'active') return res.status(404).json({ error: 'Trận đấu đã kết thúc hoặc không tồn tại.' });
    const userId = req.socialUser.id;
    const color = match.players.w === userId ? 'w' : match.players.b === userId ? 'b' : '';
    if (!color) return res.status(403).json({ error: 'Bạn không thuộc trận đấu này.' });
    await finishRankedMatch(match, color === 'w' ? '0-1' : '1-0', 'resignation', userId);
    await audit(req, userId, 'ranked_match_resigned', match.id, 'rating penalty applied');
    res.json(rankedMatchPayload(match, userId));
  });
  router.post('/ranked/matches/:matchId/abandon', rankedLimiter, requireAuth, async (req, res) => {
    const match = rankedMatchById(req.params.matchId);
    if (!match || match.status !== 'active') return res.json({ abandoned: false });
    const userId = req.socialUser.id;
    if (match.players.w !== userId && match.players.b !== userId) return res.status(403).json({ error: 'Bạn không thuộc trận đấu này.' });
    const color = match.players.w === userId ? 'w' : 'b';
    await finishRankedMatch(match, color === 'w' ? '0-1' : '1-0', 'abandoned', userId);
    await audit(req, userId, 'ranked_match_abandoned', match.id, 'rating penalty applied');
    res.json({ abandoned: true, ...rankedMatchPayload(match, userId) });
  });

  router.get('/leaderboard', (req, res) => {
    const limit = Math.max(1, Math.min(100, Number(req.query.limit) || 100));
    const users = db.users.filter(u => !u.banned).sort((a, b) => (Number(b.elo) || 1200) - (Number(a.elo) || 1200) || (Number(b.games) || 0) - (Number(a.games) || 0) || a.createdAt.localeCompare(b.createdAt));
    res.json({ users: users.slice(0, limit).map((u, index) => ({ rank: index + 1, ...publicUser(u) })), totalPlayers: users.length, generatedAt: new Date().toISOString(), source: 'server' });
  });

  router.get('/admin/overview', requireAuth, requireAdmin, (_req, res) => {
    const mem = process.memoryUsage();
    res.json({ users: db.users.length, activeUsers: db.users.filter(u => !u.banned && u.lastSeenAt && Date.now() - new Date(u.lastSeenAt).getTime() < 90_000).length, bannedUsers: db.users.filter(u => u.banned).length, admins: db.users.filter(u => u.role === 'admin' && !u.banned).length, pendingFriendRequests: db.friendRequests.filter(r => r.status === 'pending').length, uptimeSeconds: Math.floor(process.uptime()), node: process.version, platform: process.platform, arch: process.arch, cpus: os.cpus().length, loadAverage: os.loadavg().map(n => Number(n.toFixed(2))), memory: { rssMb: Math.round(mem.rss / 1048576), heapUsedMb: Math.round(mem.heapUsed / 1048576), heapTotalMb: Math.round(mem.heapTotal / 1048576), systemFreeMb: Math.round(os.freemem() / 1048576), systemTotalMb: Math.round(os.totalmem() / 1048576) }, db: { users: db.users.length, friendRequests: db.friendRequests.length, auditEvents: db.audit.length } });
  });

  router.get('/admin/users', requireAuth, requireAdmin, (req, res) => {
    const q = asText(req.query.q, 80).toLowerCase();
    const users = db.users.filter(u => !q || u.username.toLowerCase().includes(q) || u.displayName.toLowerCase().includes(q) || String(u.email || '').toLowerCase().includes(q)).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 200).map(u => ({ ...publicUser(u), email: u.email || '' }));
    res.json({ users, total: db.users.length });
  });

  router.patch('/admin/users/:id', requireAuth, requireAdmin, async (req, res) => {
    const target = db.users.find(u => u.id === req.params.id);
    if (!target) return res.status(404).json({ error: 'Không tìm thấy tài khoản.' });
    if (target.id === req.socialUser.id) return res.status(400).json({ error: 'Không thể khóa hoặc đổi quyền tài khoản đang đăng nhập.' });
    if (target.role === 'admin') return res.status(403).json({ error: 'Không thể tác động tài khoản admin khác qua bảng quản lý người dùng.' });
    const action = asText(req.body?.action, 20);
    if (action === 'ban') {
      target.sessionVersion = (Number(target.sessionVersion) || 0) + 1;
      target.banned = true;
      target.banReason = asText(req.body?.reason || 'Vi phạm quy định cộng đồng', 180);
      target.bannedAt = new Date().toISOString();
    } else if (action === 'unban') {
      target.banned = false; target.banReason = ''; target.bannedAt = null;
    } else return res.status(400).json({ error: 'Hành động chỉ được là ban hoặc unban.' });
    await audit(req, req.socialUser.id, `user_${action}ned`, target.id, target.banReason || 'unbanned');
    res.json({ user: publicUser(target), message: action === 'ban' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.' });
  });

  router.post('/admin/announcements', requireAuth, requireAdmin, async (req, res) => {
    const title = asText(req.body?.title, 100);
    const message = asText(req.body?.message, 1200);
    if (title.length < 3 || message.length < 5) return res.status(400).json({ error: 'Tiêu đề cần ít nhất 3 ký tự, nội dung ít nhất 5 ký tự.' });
    const announcement = { id: randomUUID(), title, message, author: req.socialUser.username, createdAt: new Date().toISOString() };
    db.announcements.push(announcement);
    db.announcements = db.announcements.slice(-500);
    await audit(req, req.socialUser.id, 'announcement_published', announcement.id, title);
    await persist();
    res.status(201).json({ announcement, message: 'Đã gửi thông báo tới hộp thư trong app.' });
  });

  router.get('/admin/audit', requireAuth, requireAdmin, (req, res) => {
    const limit = Math.max(1, Math.min(200, Number(req.query.limit) || 100));
    res.json({ events: db.audit.slice(-limit).reverse() });
  });

  return router;
}
