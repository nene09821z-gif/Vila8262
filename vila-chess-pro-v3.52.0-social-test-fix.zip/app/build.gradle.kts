import org.gradle.api.tasks.Copy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.secrets)
}


// `public/` is the canonical source for static WebView assets. The GitHub-sized source ZIP
// omits duplicate copies under app/src/main/assets; restore them before Android resource tasks.
val stagePublicAssetsForAndroid = tasks.register<Copy>("stagePublicAssetsForAndroid") {
  val publicDir = rootProject.file("public")
  from(publicDir)
  into(layout.projectDirectory.dir("src/main/assets"))
  doFirst {
    val requiredFiles = listOf(
      "engine/stockfish-10.js",
      "engine/stockfish-19-lite-single.js",
      "engine/stockfish-19-lite-single.wasm",
      "engine/stockfish-19-asm.js",
      "engine/engine-manifest.json"
    )
    val missing = requiredFiles.filterNot { publicDir.resolve(it).isFile }
    require(missing.isEmpty()) {
      "Required public WebView assets are missing: ${missing.joinToString()}."
    }
    val nativeStockfish = layout.projectDirectory.file("src/main/jniLibs/arm64-v8a/libstockfish.so").asFile
    require(nativeStockfish.isFile && nativeStockfish.length() > 10_000_000L) {
      "Native Stockfish ARM64 is missing. Run scripts/fetch-native-stockfish-android.sh before building."
    }
    require(layout.projectDirectory.file("src/main/assets/STOCKFISH-COPYING.txt").asFile.isFile) {
      "Stockfish GPL license is missing. Run scripts/fetch-native-stockfish-android.sh before building."
    }
    require(publicDir.resolve("assets/aistudio").listFiles()?.any { it.isFile && it.extension.equals("zip", true) } == true) {
      "AI Studio release ZIP missing from public/assets/aistudio; refusing to build an app with a broken download link."
    }
  }
}
// Package the fresh Vite output instead of a checked-in hashed bundle. This prevents Android
// builds from accidentally retaining old login flows or stale layout assets. Run npm run build first.
val stageBuiltWebAssetsForAndroid = tasks.register<Copy>("stageBuiltWebAssetsForAndroid") {
  dependsOn(stagePublicAssetsForAndroid)
  val webDist = rootProject.file("dist")
  from(webDist)
  into(layout.projectDirectory.dir("src/main/assets"))
  doFirst {
    require(webDist.resolve("index.html").isFile) {
      "Fresh web assets are missing. Run 'npm ci && npm run build' in the repository root before building :app."
    }
  }
}
tasks.named("preBuild") { dependsOn(stageBuiltWebAssetsForAndroid) }

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.covuavila.vzrk"
    minSdk = 24
    targetSdk = 36
    versionCode = 8
    versionName = "3.52.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }
  // Stockfish is an executable packaged with the ARM64 native-library payload so Android
  // extracts it into nativeLibraryDir (an executable location) rather than writable app files.
  packaging {
    jniLibs {
      useLegacyPackaging = true
      keepDebugSymbols += setOf("**/libstockfish.so")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("ADMIN_USERNAME")
  ignoreList.add("ADMIN_PASSWORD")
  ignoreList.add("ADMIN_EMAIL")
  ignoreList.add("ADMIN_INITIAL_ELO")
  ignoreList.add("TUBOR_ACCESS_TOKEN")
  ignoreList.add("NODE_ENV")
  ignoreList.add("HOST")
  ignoreList.add("PORT")
  ignoreList.add("TRUST_PROXY")
  ignoreList.add("CORS_ORIGIN")
}


// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  // implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation("androidx.webkit:webkit:1.12.1")
  // implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  // Uncomment to use Firestore:

  // Sign-In via Credential Manager:
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}
