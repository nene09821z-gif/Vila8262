# Cờ Vua ViLa v3.51.0 — Commercial UI

## Mới
- Skin thương mại `src/vila-commercial.css` (nền tối, accent cyan/vàng, card, nút, bàn, home)
- Home one-tap bot Elo, puzzle, review
- Opening explorer trên bàn
- Native Stockfish ARM64 + GitHub SDK workflow
- Tests 17/17 (chesscom + native + commercial)

## GitHub
Push toàn bộ → Actions → Cờ Vua ViLa Android build → covua-vila-debug-apk

## Test
```bash
npm install
node --test tests/chesscom-ux.test.js tests/chesscom-integration.test.js tests/native-stockfish-android.test.js
```
