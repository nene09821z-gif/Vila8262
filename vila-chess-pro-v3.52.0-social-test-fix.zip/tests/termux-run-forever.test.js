import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const script = fs.readFileSync(new URL('../scripts/vila-run.sh', import.meta.url), 'utf8');

test('long-running Termux supervisor script is valid bash and covers the keep-alive essentials', () => {
  const check = spawnSync('bash', ['-n', new URL('../scripts/vila-run.sh', import.meta.url).pathname], { encoding: 'utf8' });
  assert.equal(check.status, 0, check.stderr);
  assert.match(script, /termux-wake-lock/);
  assert.match(script, /supervise server logs\/server\.log bash scripts\/start-termux\.sh/);
  assert.match(script, /cloudflared tunnel --url/);
  assert.match(script, /CF_TUNNEL_NAME/);
  assert.match(script, /--install-boot/);
  assert.match(script, /\.termux\/boot\/vila\.sh/);
  assert.match(script, /delay \* 2 > 60 \? 60/, 'crash loops back off to at most 60 seconds');
  assert.match(script, /trap stop_all INT TERM HUP/);
  assert.doesNotMatch(script, /TUBOR_ACCESS_TOKEN=|SOCIAL_TOKEN_SECRET=|ADMIN_PASSWORD=/, 'no secrets in the script');
});
