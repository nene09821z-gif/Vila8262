import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const pieces = fs.readFileSync(new URL('../src/pieces.js', import.meta.url), 'utf8');
const worker = fs.readFileSync(new URL('../src/puzzle-worker.js', import.meta.url), 'utf8');
const cosmetics = fs.readFileSync(new URL('../src/daily-progress.js', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('v3.31 wires persisted board preferences, undo clock snapshots, and bot profiles', () => {
  assert.equal(pkg.version, '3.52.0');
  for (const id of ['showLegalMovesSetting', 'highlightLastMoveSetting', 'smoothAnimationsSetting']) assert.ok(main.includes(id));
  assert.match(main, /VISUAL_SETTINGS_KEY/);
  assert.match(main, /normalizeVisualSettings/);
  assert.match(main, /visualSettings\.showLegalMoves && legalTargetSet\.has/);
  assert.match(main, /visualSettings\.highlightLastMove && lastMove/);
  assert.match(css, /html\[data-board-motion="off"\]/);
});

test('all nineteen local/online piece styles and eight board palettes have settings previews', () => {
  for (const style of ['flat', 'royal', 'neon', 'wood', 'pearl', 'jade', 'ruby', 'graphite', 'emerald', 'gold', 'ice', 'rose', 'obsidian', 'copper', 'amethyst', 'sapphire', 'bronze', 'fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx', 'kiwen-suwi', 'firi', 'totoy', 'shapes']) assert.match(pieces, new RegExp(`id: '${style}'`));
  for (const theme of ['classic', 'ocean', 'walnut', 'midnight', 'violet', 'rose', 'ice', 'forest']) assert.match(cosmetics, new RegExp(`id: '${theme}'`), `Missing board theme ${theme}`);
  assert.match(main, /appearance-preview-pieces/);
  assert.match(css, /\.appearance-preview-board/);
});

test('puzzle board has pointer drag support, cleanup, tap selection and legal-answer filtering', () => {
  assert.match(main, /function wirePuzzleBoardPointer\(board\)/);
  assert.match(main, /pointerdown/);
  assert.match(main, /pointermove/);
  assert.match(main, /pointerup/);
  assert.match(main, /pointercancel/);
  assert.match(main, /submitPuzzleAnswer\(candidate\)/);
  assert.match(main, /legalTargets: new Set\(legalMoves\.map\(move => move\.to\)\)/);
  assert.match(main, /state\.legalMoves\.find\(move => move\.to === targetSquare\)/);
  assert.match(main, /selectPuzzleSquare\(state\.from\)/);
  assert.match(css, /\.puzzle-board\{touch-action:none/);
  assert.match(worker, /generateOfflinePuzzle/);
});

test('review requests use a bounded configurable search duration and no redundant stop before a fresh go', () => {
  assert.match(main, /resolveReviewMoveTimeMs\(settings\)/);
  const start = main.indexOf('function beginReviewPosition()');
  const end = main.indexOf('\nfunction receiveReviewInfo', start);
  const review = main.slice(start, end);
  assert.match(review, /go movetime \$\{reviewMoveTimeMs\}/);
  assert.doesNotMatch(review, /postMessage\('stop'\)/);
  const uciStart = main.indexOf('async function requestStockfishUci(');
  const uciEnd = main.indexOf('\nfunction ', uciStart + 10);
  const uci = main.slice(uciStart, uciEnd);
  assert.doesNotMatch(uci, /postMessage\('stop'\)/);
  const analysisStart = main.indexOf('function toggleAnalysis()');
  const analysisEnd = main.indexOf('function analyzeLocallyForCoach()', analysisStart);
  const analysis = main.slice(analysisStart, analysisEnd);
  assert.doesNotMatch(analysis, /postMessage\('stop'\)/);
  assert.match(analysis, /postMessage\(`go movetime \$\{budget\}`\)/);
  const coachStart = main.indexOf('function analyzeLocallyForCoach()');
  const coachEnd = main.indexOf('function receiveCoachAnalysisInfo', coachStart);
  assert.doesNotMatch(main.slice(coachStart, coachEnd), /postMessage\('stop'\)/);
  const hintStart = main.indexOf('async function requestHint()');
  const hintEnd = main.indexOf('async function queryOpeningExplorer', hintStart);
  const hint = main.slice(hintStart, hintEnd);
  assert.doesNotMatch(hint, /postMessage\('stop'\)/);
});
