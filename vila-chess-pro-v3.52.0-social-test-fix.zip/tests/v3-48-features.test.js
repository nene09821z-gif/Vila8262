import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { classifyMoveQuality, winChance, reviewSymbolForJudgement } from '../src/game-review.js';
import { detectSacrifice } from '../src/review-brilliance.js';
import { resolveReviewMoveTimeMs } from '../src/engine-budgets.js';
import { normalizeSettings, DEFAULTS } from '../src/settings-schema.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const main = read('../src/main.js');
const css = read('../src/vila-polish.css');

test('win chance is symmetric and saturates', () => {
  assert.equal(Math.round(winChance(0)), 50);
  assert.ok(Math.abs(winChance(200) + winChance(-200) - 100) < 1e-9);
  assert.ok(winChance(5000) > 99 && winChance(-5000) < 1);
});

test('chess.com-style labels come from the drop in winning chance', () => {
  const q = input => classifyMoveQuality(input).key;
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: 25, isBest: true }), 'best');
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: 5 }), 'excellent');
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: -40 }), 'inaccuracy');
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: -150 }), 'mistake');
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: -400 }), 'blunder');
  assert.equal(q({ moverBeforeCp: 600, moverAfterCp: 20 }), 'missed-win');
  assert.equal(q({ moverBeforeCp: 20, moverAfterCp: 20, bookMove: true }), 'book');
  assert.equal(q({ moverBeforeCp: null, moverAfterCp: 20 }), 'unrated');
});

test('brilliant needs a real sacrifice, great needs an only move or a turnaround', () => {
  assert.equal(classifyMoveQuality({ moverBeforeCp: 20, moverAfterCp: 30, isBest: true, sacrifice: true }).key, 'brilliant');
  assert.notEqual(classifyMoveQuality({ moverBeforeCp: 20, moverAfterCp: 30, isBest: true }).key, 'brilliant');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 900, moverAfterCp: 900, isBest: true, sacrifice: true }).key, 'best', 'already winning is not brilliant');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 20, moverAfterCp: 30, isBest: true, secondGapPct: 25 }).key, 'great');
  assert.equal(classifyMoveQuality({ moverBeforeCp: -300, moverAfterCp: -10, isBest: true }).key, 'great');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 20, moverAfterCp: 30, isBest: true, sacrifice: true }).label, 'Thiên tài');
  assert.equal(reviewSymbolForJudgement('brilliant'), '!!');
  assert.equal(reviewSymbolForJudgement('great'), '!');
});

test('sacrifice detection compares material after the engine line', () => {
  const fen = '3r2k1/8/3p4/8/8/8/5PPP/3R2K1 w - - 0 1';
  assert.equal(detectSacrifice({ fenBefore: fen, playedUci: 'd1d6', pvAfterUci: ['d8d6', 'g1f1', 'g8f8', 'f1e2'], mover: 'w', ChessConstructor: Chess }), true);
  assert.equal(detectSacrifice({ fenBefore: fen, playedUci: 'g2g3', pvAfterUci: ['g8f8', 'g1g2'], mover: 'w', ChessConstructor: Chess }), false);
  assert.equal(detectSacrifice({ fenBefore: fen, playedUci: 'zzzz', pvAfterUci: [], mover: 'w', ChessConstructor: Chess }), false);
});

test('review quality defaults to the strongest Stockfish 19 setting', () => {
  assert.equal(DEFAULTS.reviewQuality, 'max');
  assert.equal(normalizeSettings({}).reviewQuality, 'max');
  assert.equal(normalizeSettings({ reviewQuality: 'bogus' }).reviewQuality, 'max');
  assert.equal(resolveReviewMoveTimeMs({ reviewQuality: 'max' }), 8000);
  assert.ok(resolveReviewMoveTimeMs({ reviewQuality: 'deep', analysisMoveTimeMs: 2600 }) <= 6000);
  assert.ok(resolveReviewMoveTimeMs({}) <= 4200, 'legacy callers keep the standard budget');
  assert.match(main, /setoption name MultiPV value|configureStockfishForAnalysis\(reviewLaneCount\(\)\)/);
  assert.match(main, /classifyMoveQuality\(\{ moverBeforeCp, moverAfterCp, isBest: moveWasBest/);
});

test('your move gets a blue ring and the opponent move a red ring', () => {
  assert.match(main, /'last-mine' : 'last-opp'/);
  assert.match(css, /\.square\.last-mine \{ box-shadow: inset 0 0 0 4px var\(--vp-mine\)/);
  assert.match(css, /\.square\.last-opp \{ box-shadow: inset 0 0 0 4px var\(--vp-opp\)/);
  assert.match(css, /--vp-mine: #2563eb/);
  assert.match(css, /--vp-opp: #e5484d/);
});
