import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_VISUAL_SETTINGS, normalizeVisualSettings } from '../src/visual-settings.js';

test('appearance defaults enable useful board guidance with subtle animation', () => {
  assert.deepEqual(normalizeVisualSettings(), DEFAULT_VISUAL_SETTINGS);
  assert.deepEqual(normalizeVisualSettings(null), DEFAULT_VISUAL_SETTINGS);
  assert.deepEqual(normalizeVisualSettings('not-settings'), DEFAULT_VISUAL_SETTINGS);
});

test('appearance settings normalize partial values and do not persist unknown keys', () => {
  assert.deepEqual(normalizeVisualSettings({ showLegalMoves: false, smoothAnimations: false, surprise: true }), {
    showLegalMoves: false, highlightLastMove: true, smoothAnimations: false, autoQueen: false, announceMoves: true
  });
  assert.deepEqual(normalizeVisualSettings({ showLegalMoves: 0, highlightLastMove: null, smoothAnimations: true }), {
    showLegalMoves: true, highlightLastMove: true, smoothAnimations: true, autoQueen: false, announceMoves: true
  });
});


test('visual settings intentionally normalize only supported board guidance preferences', () => {
  const normalized = normalizeVisualSettings({
    showLegalMoves: false,
    highlightLastMove: false,
    smoothAnimations: false,
    pieceStyle: 'fantasy',
    pieceSet: 'fantasy',
    surprise: true
  });
  assert.deepEqual(normalized, {
    showLegalMoves: false,
    highlightLastMove: false,
    smoothAnimations: false,
    autoQueen: false,
    announceMoves: true
  });
  assert.equal(Object.hasOwn(normalized, 'pieceStyle'), false);
});
