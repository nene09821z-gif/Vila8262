#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v node >/dev/null 2>&1; then echo 'Chưa có Node.js. Chạy: pkg update && pkg install nodejs-lts'; exit 1; fi
if [ ! -d node_modules ]; then npm install --omit=dev; fi
mkdir -p data
if [ -f .env ]; then
  # Node.js 20+ reads private deployment variables from .env without extra packages.
  NODE_ENV=production HOST=0.0.0.0 PORT="${PORT:-8787}" node --env-file=.env server/index.js
else
  echo 'Thiếu tệp .env. Hãy cp .env.example .env rồi đặt SOCIAL_TOKEN_SECRET, TUBOR_ACCESS_TOKEN và mật khẩu admin mạnh.'
  exit 1
fi
