const DIFFICULTIES = new Set(['easiest', 'easier', 'normal', 'harder', 'hardest']);

/** Creates a small in-memory proxy/cache for public Lichess puzzles. No keys are needed. */
export function createPuzzleService({ fetchImpl = globalThis.fetch, now = () => Date.now(), recentLimit = 500, dailyTtlMs = 6 * 60 * 60 * 1000 } = {}) {
  const recentIds = new Set();
  const recentOrder = [];
  const dailyCache = new Map();
  async function readJson(url) {
    const response = await fetchImpl(url, { headers: { Accept: 'application/json', 'User-Agent': 'VILA-Chess/3.56.0 puzzle-proxy' }, signal: AbortSignal.timeout(9000) });
    if (!response?.ok) throw new Error(`Lichess returned HTTP ${response?.status || 502}`);
    const payload = await response.json();
    if (!payload || typeof payload !== 'object' || !payload.puzzle?.id || !payload.game?.pgn || !Array.isArray(payload.puzzle?.solution)) {
      throw new Error('Lichess returned an incomplete puzzle payload.');
    }
    return payload;
  }
  function remember(id) {
    recentIds.add(id); recentOrder.push(id);
    while (recentOrder.length > Math.max(1, recentLimit)) recentIds.delete(recentOrder.shift());
  }
  return {
    async next(difficulty = 'normal') {
      const band = DIFFICULTIES.has(String(difficulty)) ? String(difficulty) : 'normal';
      let last = null;
      // Lichess returns randomized puzzles. Reject repeated IDs for a bounded number of attempts.
      for (let attempt = 0; attempt < 4; attempt += 1) {
        const payload = await readJson(`https://lichess.org/api/puzzle/next?difficulty=${encodeURIComponent(band)}`);
        last = payload;
        if (!recentIds.has(payload.puzzle.id)) { remember(payload.puzzle.id); return payload; }
      }
      if (last) throw new Error('Lichess repeatedly returned a recently seen puzzle; try again in a moment.');
      throw new Error('No fresh puzzle was returned.');
    },
    async daily() {
      const key = new Date(now()).toISOString().slice(0, 10);
      const cached = dailyCache.get(key);
      if (cached && now() - cached.at < dailyTtlMs) return cached.payload;
      const payload = await readJson('https://lichess.org/api/puzzle/daily');
      dailyCache.set(key, { at: now(), payload });
      for (const storedKey of dailyCache.keys()) if (storedKey !== key) dailyCache.delete(storedKey);
      return payload;
    },
    getRecentIds() { return [...recentOrder]; }
  };
}
