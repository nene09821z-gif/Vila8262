/**
 * Plans and entitlements (v3.56). Pure functions, shared by the app and the Node server.
 *
 *  - free    : may run the full-game review ONCE (that one game stays viewable afterwards)
 *  - pro     : full review access for 365 days from the grant; renewing while active stacks the time
 *  - premium : full review access for life
 *
 * An entitlement is plain JSON: { plan, proExpiresAt, premium, freeReviewsUsed, freeReviewGameId }.
 * Money never changes engine strength or Elo (see MONETIZATION.md); plans only unlock review/analysis access.
 */
export const DAY_MS = 24 * 60 * 60 * 1000;
export const PRO_DURATION_DAYS = 365;
export const FREE_REVIEW_LIMIT = 1;
/** Free accounts may open this many puzzles in total; Pro and Premium are unlimited. */
export const FREE_PUZZLE_LIMIT = 3;

/** Pure puzzle quota check. `used` is how many puzzles the free player has already opened. */
export function puzzleAccess(entitlement, used = 0, now = Date.now()) {
  const plan = effectivePlan(entitlement, now);
  if (plan === 'premium' || plan === 'pro') return { allowed: true, plan, unlimited: true, remaining: null };
  const remaining = Math.max(0, FREE_PUZZLE_LIMIT - Math.max(0, Math.floor(Number(used) || 0)));
  return { allowed: remaining > 0, plan, unlimited: false, remaining };
}

export const PLAN_CATALOG = Object.freeze({
  free: Object.freeze({ id: 'free', name: 'Miễn phí', tagline: 'Xem lại phân tích 1 lần', perks: ['1 lần phân tích toàn ván (ván đó xem lại được mãi)', 'Câu đố: 3 câu miễn phí', 'Chơi cờ và bài học không giới hạn'] }),
  pro: Object.freeze({ id: 'pro', name: 'Pro', tagline: '1 năm xem toàn bộ phân tích', durationDays: PRO_DURATION_DAYS, perks: ['Phân tích toàn ván không giới hạn trong 365 ngày', 'Câu đố không giới hạn trong 365 ngày', 'Mọi mức chất lượng phân tích', 'Gia hạn khi còn hạn sẽ cộng dồn thời gian'] }),
  premium: Object.freeze({ id: 'premium', name: 'Premium', tagline: 'Gói trọn đời', lifetime: true, perks: ['Phân tích toàn ván không giới hạn trọn đời', 'Câu đố không giới hạn trọn đời', 'Mọi mức chất lượng phân tích', 'Không bao giờ hết hạn'] })
});

const toMs = value => {
  if (value == null || value === '') return null;
  const ms = typeof value === 'number' ? value : Date.parse(String(value));
  return Number.isFinite(ms) && ms > 0 ? ms : null;
};

export function normalizeEntitlement(raw) {
  const src = raw && typeof raw === 'object' ? raw : {};
  return {
    premium: src.premium === true || src.plan === 'premium',
    proExpiresAt: toMs(src.proExpiresAt),
    freeReviewsUsed: Math.max(0, Math.min(1000, Math.floor(Number(src.freeReviewsUsed) || 0))),
    freeReviewGameId: typeof src.freeReviewGameId === 'string' ? src.freeReviewGameId.slice(0, 120) : ''
  };
}

/** Plan in force right now: premium > active pro > free. An expired Pro silently becomes free. */
export function effectivePlan(entitlement, now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  if (ent.premium) return 'premium';
  if (ent.proExpiresAt != null && ent.proExpiresAt > now) return 'pro';
  return 'free';
}

/**
 * May this player start (or re-open) a full-game review?
 * `gameId` lets the one free review stay viewable for the same game.
 */
export function reviewAccess(entitlement, gameId = '', now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  const plan = effectivePlan(ent, now);
  if (plan === 'premium' || plan === 'pro') return { allowed: true, plan, reason: plan, consumesFree: false, remainingFree: null };
  const remainingFree = Math.max(0, FREE_REVIEW_LIMIT - ent.freeReviewsUsed);
  if (gameId && ent.freeReviewGameId && ent.freeReviewGameId === String(gameId)) {
    return { allowed: true, plan, reason: 'free-same-game', consumesFree: false, remainingFree };
  }
  if (remainingFree > 0) return { allowed: true, plan, reason: 'free-trial', consumesFree: true, remainingFree };
  return { allowed: false, plan, reason: 'limit', consumesFree: false, remainingFree: 0 };
}

/** Record the use of the free review (idempotent per game). Returns a new entitlement. */
export function consumeFreeReview(entitlement, gameId = '') {
  const ent = normalizeEntitlement(entitlement);
  if (gameId && ent.freeReviewGameId === String(gameId)) return ent;
  return { ...ent, freeReviewsUsed: Math.min(FREE_REVIEW_LIMIT, ent.freeReviewsUsed + 1), freeReviewGameId: String(gameId || ent.freeReviewGameId || '') };
}

/** Grant a plan. Premium is permanent and is never downgraded by a later Pro grant. Returns a new entitlement. */
export function grantPlan(entitlement, planId, now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  if (planId === 'premium') return { ...ent, premium: true };
  if (planId === 'pro') {
    const base = ent.proExpiresAt != null && ent.proExpiresAt > now ? ent.proExpiresAt : now;
    return { ...ent, proExpiresAt: base + PRO_DURATION_DAYS * DAY_MS };
  }
  throw new Error('Gói không hợp lệ: chỉ có "pro" hoặc "premium".');
}

/** Revoke paid access (refund / chargeback). Free-review usage is kept so it cannot be replayed. */
export function revokePlan(entitlement, planId) {
  const ent = normalizeEntitlement(entitlement);
  if (planId === 'premium') return { ...ent, premium: false };
  if (planId === 'pro') return { ...ent, proExpiresAt: null };
  if (planId === 'all') return { ...ent, premium: false, proExpiresAt: null };
  throw new Error('Gói không hợp lệ.');
}

/**
 * Undo ONE paid purchase after a refund/chargeback. Pro removes the 365 days that purchase added (other paid years
 * stay); Premium switches off. Free-review usage is kept so it cannot be replayed.
 */
export function refundPurchase(entitlement, planId, now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  if (planId === 'premium') return { ...ent, premium: false };
  if (planId === 'pro') {
    if (ent.proExpiresAt == null) return ent;
    const next = ent.proExpiresAt - PRO_DURATION_DAYS * DAY_MS;
    return { ...ent, proExpiresAt: next > now ? next : null };
  }
  throw new Error('Gói không hợp lệ.');
}

export function daysLeft(entitlement, now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  if (ent.proExpiresAt == null || ent.proExpiresAt <= now) return 0;
  return Math.ceil((ent.proExpiresAt - now) / DAY_MS);
}

export function planStatusLabel(entitlement, now = Date.now()) {
  const plan = effectivePlan(entitlement, now);
  if (plan === 'premium') return 'Premium · trọn đời';
  if (plan === 'pro') return `Pro · còn ${daysLeft(entitlement, now)} ngày`;
  const access = reviewAccess(entitlement, '', now);
  return access.remainingFree > 0 ? 'Miễn phí · còn 1 lần phân tích' : 'Miễn phí · đã dùng lượt phân tích';
}

/** Server-safe projection for API responses. */
export function entitlementForClient(entitlement, now = Date.now()) {
  const ent = normalizeEntitlement(entitlement);
  return { ...ent, plan: effectivePlan(ent, now), daysLeft: daysLeft(ent, now), label: planStatusLabel(ent, now) };
}
