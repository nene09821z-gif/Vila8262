/**
 * Achievements (v3.58): a catalogue of exactly 10,000 achievements generated from 15 lifetime counters.
 * Each counter has a dense ladder of milestones (1, 2, 3 ... then wider steps), so there is always a next goal in reach
 * and a very long tail for dedicated players. Pure functions; the app supplies the counters.
 */
export const ACHIEVEMENT_TOTAL = 10000;

/** @type {ReadonlyArray<{id:string,category:string,icon:string,count:number,spread:number,unit:string,verb:string}>} */
export const ACHIEVEMENT_METRICS = Object.freeze([
  { id: 'solve_puzzle', category: 'Câu đố', icon: '🧩', count: 1800, spread: 8, unit: 'câu đố', verb: 'Giải' },
  { id: 'puzzle_best_streak', category: 'Câu đố', icon: '🔥', count: 300, spread: 3, unit: 'câu đố liên tiếp', verb: 'Giải đúng' },
  { id: 'rush_best', category: 'Câu đố', icon: '⏱', count: 300, spread: 4, unit: 'câu trong một lượt Rush', verb: 'Đạt' },
  { id: 'make_move', category: 'Thi đấu', icon: '♞', count: 1500, spread: 10, unit: 'nước đi', verb: 'Đi' },
  { id: 'complete_game', category: 'Thi đấu', icon: '♟', count: 1200, spread: 8, unit: 'ván cờ', verb: 'Hoàn thành' },
  { id: 'win_game', category: 'Thi đấu', icon: '🏆', count: 1000, spread: 8, unit: 'trận thắng', verb: 'Giành' },
  { id: 'draw_game', category: 'Thi đấu', icon: '🤝', count: 300, spread: 5, unit: 'ván hòa', verb: 'Kết thúc' },
  { id: 'capture_piece', category: 'Kỹ năng', icon: '✦', count: 900, spread: 10, unit: 'nước bắt quân', verb: 'Thực hiện' },
  { id: 'check_king', category: 'Kỹ năng', icon: '⚡', count: 700, spread: 8, unit: 'lần chiếu vua', verb: 'Chiếu vua' },
  { id: 'castle', category: 'Kỹ năng', icon: '🏰', count: 400, spread: 5, unit: 'lần nhập thành', verb: 'Nhập thành' },
  { id: 'promote', category: 'Kỹ năng', icon: '♛', count: 300, spread: 4, unit: 'lần phong cấp', verb: 'Phong cấp' },
  { id: 'analyze_game', category: 'Học tập', icon: '📊', count: 300, spread: 4, unit: 'lần phân tích ván', verb: 'Phân tích' },
  { id: 'lesson_done', category: 'Học tập', icon: '📖', count: 200, spread: 3, unit: 'bài học', verb: 'Hoàn thành' },
  { id: 'checkin', category: 'Thói quen', icon: '☀', count: 365, spread: 1, unit: 'ngày điểm danh', verb: 'Điểm danh' },
  { id: 'claim_mission', category: 'Thói quen', icon: '🎯', count: 200, spread: 3, unit: 'nhiệm vụ', verb: 'Hoàn thành' },
  { id: 'play_mini_game', category: 'Giải trí', icon: '🎮', count: 235, spread: 4, unit: 'lượt mini-game', verb: 'Chơi' }
]);

export const ACHIEVEMENT_CATEGORIES = Object.freeze([...new Set(ACHIEVEMENT_METRICS.map(metric => metric.category))]);

export const ACHIEVEMENT_TIERS = Object.freeze([
  { id: 'rookie', label: 'Tân binh', until: 0.1, points: 5 },
  { id: 'bronze', label: 'Đồng', until: 0.25, points: 10 },
  { id: 'silver', label: 'Bạc', until: 0.45, points: 20 },
  { id: 'gold', label: 'Vàng', until: 0.65, points: 35 },
  { id: 'platinum', label: 'Bạch kim', until: 0.8, points: 50 },
  { id: 'diamond', label: 'Kim cương', until: 0.92, points: 75 },
  { id: 'grandmaster', label: 'Đại kiện tướng', until: 1.01, points: 100 }
]);

const ladderCache = new Map();
/** Strictly increasing thresholds: step starts at 1 and grows by 1 every `spread` milestones. */
export function milestoneLadder(count, spread) {
  const key = `${count}:${spread}`;
  const hit = ladderCache.get(key);
  if (hit) return hit;
  const out = new Array(count);
  let value = 0;
  for (let i = 0; i < count; i += 1) {
    value += 1 + Math.floor(i / spread);
    out[i] = value;
  }
  Object.freeze(out);
  ladderCache.set(key, out);
  return out;
}

function tierFor(index, count) {
  const fraction = (index + 1) / count;
  return ACHIEVEMENT_TIERS.find(tier => fraction <= tier.until) || ACHIEVEMENT_TIERS[ACHIEVEMENT_TIERS.length - 1];
}

const nf = new Intl.NumberFormat('vi-VN');
export const formatCount = value => nf.format(value);

function build(metric, index) {
  const ladder = milestoneLadder(metric.count, metric.spread);
  const target = ladder[index];
  const tier = tierFor(index, metric.count);
  return {
    id: `${metric.id}:${index + 1}`,
    metric: metric.id,
    index: index + 1,
    category: metric.category,
    icon: metric.icon,
    tier: tier.id,
    tierLabel: tier.label,
    points: tier.points,
    target,
    title: `${metric.verb} ${formatCount(target)} ${metric.unit}`
  };
}

/** The full catalogue (10,000 entries), built once on first use. */
let catalogue = null;
export function achievementCatalogue() {
  if (catalogue) return catalogue;
  catalogue = [];
  for (const metric of ACHIEVEMENT_METRICS) for (let i = 0; i < metric.count; i += 1) catalogue.push(build(metric, i));
  return catalogue;
}

const toCount = value => Math.max(0, Math.floor(Number(value) || 0));

/** Number of milestones of `metric` reached with counter value `value`. */
export function reachedMilestones(metricId, value) {
  const metric = ACHIEVEMENT_METRICS.find(item => item.id === metricId);
  if (!metric) return 0;
  const v = toCount(value);
  const ladder = milestoneLadder(metric.count, metric.spread);
  let lo = 0, hi = ladder.length;
  while (lo < hi) { const mid = (lo + hi) >> 1; if (ladder[mid] <= v) lo = mid + 1; else hi = mid; }
  return lo;
}

/**
 * @param {Record<string, number>} stats counter values keyed by metric id (missing = 0)
 */
export function summarizeAchievements(stats = {}) {
  let unlocked = 0, points = 0;
  const byCategory = Object.fromEntries(ACHIEVEMENT_CATEGORIES.map(category => [category, { unlocked: 0, total: 0 }]));
  for (const metric of ACHIEVEMENT_METRICS) {
    const reached = reachedMilestones(metric.id, stats[metric.id]);
    unlocked += reached;
    byCategory[metric.category].unlocked += reached;
    byCategory[metric.category].total += metric.count;
    for (let i = 0; i < reached; i += 1) points += tierFor(i, metric.count).points;
  }
  return { unlocked, total: ACHIEVEMENT_TOTAL, points, percent: Math.round((unlocked / ACHIEVEMENT_TOTAL) * 1000) / 10, byCategory };
}

/**
 * Page of achievements. status: 'all' | 'unlocked' | 'locked'. Locked ones are ordered by how close the player is
 * (the next milestone of each counter first), unlocked ones by newest.
 */
export function listAchievements(stats = {}, { category = 'all', status = 'all', offset = 0, limit = 40 } = {}) {
  const items = [];
  for (const metric of ACHIEVEMENT_METRICS) {
    if (category !== 'all' && metric.category !== category) continue;
    const value = toCount(stats[metric.id]);
    const reached = reachedMilestones(metric.id, value);
    const ladder = milestoneLadder(metric.count, metric.spread);
    if (status !== 'locked') for (let i = reached - 1; i >= 0 && items.length < 20000; i -= 1) items.push({ ...build(metric, i), unlocked: true, value, progress: 1 });
    if (status !== 'unlocked') for (let i = reached; i < metric.count; i += 1) {
      const previous = i === 0 ? 0 : ladder[i - 1];
      const progress = Math.max(0, Math.min(1, (value - previous) / (ladder[i] - previous)));
      items.push({ ...build(metric, i), unlocked: false, value, progress, rank: i - reached });
    }
  }
  const unlockedFirst = items.filter(item => item.unlocked);
  const locked = items.filter(item => !item.unlocked).sort((a, b) => a.rank - b.rank || b.progress - a.progress);
  const ordered = status === 'locked' ? locked : status === 'unlocked' ? unlockedFirst : [...locked, ...unlockedFirst];
  return { total: ordered.length, items: ordered.slice(offset, offset + limit) };
}

/** Achievements newly unlocked between two counter snapshots (highest tier first). */
export function newlyUnlocked(before = {}, after = {}) {
  const found = [];
  for (const metric of ACHIEVEMENT_METRICS) {
    const from = reachedMilestones(metric.id, before[metric.id]);
    const to = reachedMilestones(metric.id, after[metric.id]);
    for (let i = from; i < to; i += 1) found.push(build(metric, i));
  }
  return found.sort((a, b) => b.points - a.points);
}
