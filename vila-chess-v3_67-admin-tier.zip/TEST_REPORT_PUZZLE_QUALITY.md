# Báo cáo rà soát chất lượng câu đố — 21/10/2026

## Đã thay đổi
- Nhánh Stockfish dự phòng yêu cầu ít nhất hai biến MultiPV khác nhau, độ sâu tối thiểu, chênh lệch độ sâu không quá 2, điểm đánh giá tối thiểu 80 cp và khoảng cách với biến tiếp theo tối thiểu 180 cp.
- Nước ứng viên phải hợp lệ theo luật cờ và có yếu tố chiến thuật nhìn thấy được (ăn quân, phong cấp, chiếu hoặc chiếu hết). Nếu không đạt tiêu chí, hệ thống thử thế cờ khác thay vì chấp nhận mọi nước ăn quân/chiếu.
- Chủ đề Lichess `mateIn1` cho phép người chơi giải bằng nước chiếu hết hợp lệ khác với nước chính trong dòng mẫu.
- Huy hiệu trạng thái đề dùng độ khó/chủ đề, không hiển thị số nửa nước đi ngẫu nhiên như một cấp độ.
- Gỡ trường UCI làm lộ đáp án khỏi thẻ trạng thái trước khi người chơi giải; Việt hóa nhãn chủ đề Lichess thông dụng.

## Kiểm tra đã chạy trong môi trường này
- `node --check src/main.js`: đạt.
- `node --check src/puzzle-quality.js`: đạt.
- `node --test tests/puzzle-quality.test.js tests/puzzle-worker.test.js tests/puzzle-pool.test.js tests/puzzle-history.test.js`: 17/17 test đạt.

## Giới hạn chưa xác minh
- Không chạy toàn bộ `npm test`, Vite production build hoặc Gradle/APK build tại đây: môi trường không hoàn tất việc cài dependencies trong thời gian công cụ cho phép.
- Chưa chạy thử trên OPPO A17k/WebView thật và chưa đo Elo/độ chính xác engine thực tế. Các kiểm tra trên là kiểm thử mã và helper, không phải xác nhận hiệu năng trên điện thoại.
