# VILA Chess v3.67.0 — QA & Release Report

## Delivered in this source update

1. **Analysis/review:** preserves FEN before/after analyzed moves and surfaces personal mistakes from reviewed move rows. Existing review arrows/replay controls remain present.
2. **Bot strength:** adds a bounded practice budget for beginner presets. Target 500 uses at most 260 ms and depth 5 in the main engine search; offline rescue is capped with the same beginner-practice profile. A legal alternative may be selected as a deliberate handicap. These settings are difficulty heuristics, not an empirically calibrated 500 Elo rating.
3. **Puzzles/openings:** preserves the prior online Lichess puzzle batch and opening-explorer paths; existing de-duplication/storage limits remain. This release does not embed the full remote puzzle database in the ZIP.
4. **Mobile UX:** adds a touch-first responsive personal-training board with tap-to-select/tap-to-move, legal-move validation, promotion selection, hint/retry/next controls, and responsive layout styling.
5. **Pro/Premium safety:** retains the existing server-side trial-code verification and plan expiry model; this release does not bypass server validation or grant plans from the UI.
6. **Test/release gates:** registers the new training regressions in `test:static`, updates current release metadata to 3.67.0, and keeps older release regression checks aligned.
7. **Personal Mistake Training:** imports own analyzed inaccuracies, mistakes, blunders, and missed wins; validates FEN/UCI shapes and legal replacement moves; stores up to 500 records locally; records attempts; and schedules repetitions with due dates (1, 3, 7, 14, 30 days). Wrong attempts become retryable after five minutes. Mastery is marked after three correct spaced responses. Data is local to that browser/device.

## Test results in this environment

- Focused release/test batch: **40 passed, 0 failed, 0 skipped**.
- JavaScript/MJS syntax checks: **8/8 passed**.
- Professional CSS aggregate rebuild: **passed** (`src/vila-professional.css` rebuilt from 12 owned layers).
- Full `node --test`: **462 discovered; 447 passed, 12 failed to load, 3 skipped**.
- The 12 full-suite failures are environment/dependency blockers, not assertions: Node cannot load `express` or `chess.js` from `node_modules` for account-auth, alternate-engine, chess rules, Cloudflare backend/billing/routes/plans, premove, purchase requests, social, and older feature suites. `npm ci` previously timed out while fetching registry packages, leaving incomplete dependency directories.

## Not yet verified

- A clean `npm run build` / Android APK build was not confirmed because the environment does not have a complete installed dependency tree.
- Real browser/device E2E for engine moves, remote Lichess APIs, Cloudflare deployment, or trial-code activation/expiry was not run.
- Beginner strength is not tournament-calibrated; use a batch of games against benchmark opponents to adjust the presets.
- Training progress uses browser local storage and does not synchronize between devices or accounts.

## Reproduction commands

```bash
npm install
npm test
npm run build:professional-css
npm run build
```

Run the commands from the project root. A registry/dependency error must be fixed before considering the complete suite or a production build verified.
