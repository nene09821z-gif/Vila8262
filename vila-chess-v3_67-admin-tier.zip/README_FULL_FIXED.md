# Cờ Vua ViLa v3.50.4 COMPLETE

GitHub + Native Stockfish ARM64 + Chess.com UX + Home one-tap + Opening explorer on board.

## GitHub
Push repo, run Actions: Cờ Vua ViLa Android build, download covua-vila-debug-apk.

## Test
npm install && node --test tests/chesscom-ux.test.js tests/chesscom-integration.test.js tests/native-stockfish-android.test.js
