# Stockfish Android ARM64 integration

## What the Android build now does

- The source ZIP stays small: it does not contain the large native executable or its compressed release archive.
- Both GitHub Actions workflows call `scripts/fetch-native-stockfish-android.sh` during the build.
- That script fetches the official Stockfish Android ARM64 universal release, verifies the ELF AArch64 machine type, and stages the upstream `Copying.txt` license.
- After `npx cap sync android`, `scripts/install-native-stockfish-android.mjs android` modifies the **actual generated Capacitor module** at `android/app/`: it copies the executable to `android/app/src/main/jniLibs/arm64-v8a/libstockfish.so`, places the license in app assets, patches the generated `MainActivity`, and adds the Java UCI bridge class.
- Android's native-library packaging extracts the executable under `nativeLibraryDir`; the app starts it as a UCI child process. The WebView bridge forwards UCI commands/output to the existing engine interface. Existing JS/WASM/ASM-JS engines remain the fallback if native mode is unavailable or fails to start.

## Runtime behavior and compatibility

- Native mode requires ARM64 (`arm64-v8a`) and Android 10/API 29 or newer, matching the upstream universal executable build target.
- Unsupported ABIs, missing native assets, and a native startup failure use the existing JavaScript/WebAssembly fallback.
- The native engine responds to the same UCI flow (`uci`, options, `isready`, `position`, `go`, `stop`, and `quit`), so the existing search queue, analysis, hints, and engine-driven games continue to use the same event path.
- The APK is expected to become substantially larger because the full NNUE native engine is bundled. Only the GitHub-uploadable source ZIP is kept under 25 MB; APK/artifacts are not constrained by that source ZIP guard.

## Validation

Static tests check the Android bridge, UCI worker adapter, generated-Capacitor installer, workflow ordering, archive verification and Gradle packaging. A fixture test confirmed that the installer puts the executable and bridge into the generated module. A real Android APK build and device run must still be confirmed by a GitHub Actions run; this environment has no Android SDK and cannot truthfully claim an APK/device test.

## License

Stockfish is distributed under GPL. The build includes the upstream `stockfish/Copying.txt` as `app/src/main/assets/STOCKFISH-COPYING.txt`; retain this notice when redistributing the APK/source.
