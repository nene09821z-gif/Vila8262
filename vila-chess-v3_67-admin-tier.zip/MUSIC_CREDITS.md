# Music source and release note

## Current release (v3.46.4; music behavior introduced in v3.46.0)

The bundled chess-music themes are generated at runtime with the Web Audio API. They are designed for this app and require no external audio file, download, or network connection. The old streamed “Gymnopedie No. 1” track is **not used by the current release**.

Users can still choose to paste a YouTube video or playlist URL. That is an optional external source controlled by the user; it is not bundled or re-hosted by the app, and playback requires an internet connection and YouTube embedding permissions.

## Historical attribution (v3.45.0 and earlier)

Previous releases included optional streaming of “Gymnopedie No. 1 (ISRC USUAN1100787)”, performed by Kevin MacLeod. The recording was hosted at Wikimedia Commons under the Creative Commons Attribution 3.0 Unported (CC BY 3.0) license. It is documented here for historical release records only; the current release does not reference the recording.

- Source page: https://commons.wikimedia.org/wiki/File:Gymnopedie_No._1_(ISRC_USUAN1100787).mp3
- Streaming file: https://upload.wikimedia.org/wikipedia/commons/2/2a/Gymnopedie_No._1_%28ISRC_USUAN1100787%29.mp3
- Attribution: “Gymnopedie No. 1” by Kevin MacLeod, licensed under CC BY 3.0.
- License: https://creativecommons.org/licenses/by/3.0/
