# VILA Chess v3.66.0 — QA report

## Implemented
- SVG overlay for the played move and the Stockfish best continuation on the replay board.
- Saved per-position best continuation separate from best move before the played move.
- ArrowLeft/ArrowRight/Home/End replay shortcuts, disabled when an input is focused.
- Redemption form changed to mobile text input; no full-view re-render occurs before the request, so focus/keyboard are not dismissed on submit. Input remains disabled only while a request is pending.
- Online opening explorer lookup in the coach page through `/api/openings/explorer`.
- Lichess puzzle cache cap raised from 200 to 500; batch download raised to 50, retaining a delay between requests.
- Approximate Elo-500 play uses Skill Level 0, reduced time/depth and a 14% controlled chance of choosing another legal move. Other Elo presets are unaffected by this injected handicap.

## Tests run
- Focused regression set: 40/40 passed (including Elo 500, puzzle pool, review/UI, and adjacent version checks).
- `npm run test:static`: 351 passed, 5 failed to load because the environment does not contain `express` and/or `chess.js`; these are dependency-loading blockers, not passes.
- Syntax checks: `node --check src/main.js`, `node --check src/beginner-strength.js`.
- `node scripts/build-professional-css.mjs` completed and generated `src/vila-professional.css` from the project's 12 owned CSS layers.

## Limitations
- A full `npm test` baseline previously showed missing `chess.js`/`express`/`vite` dependencies in this environment. This release does not claim a successful full application build or phone E2E run.
- Lichess exploration needs working internet and a reachable backend proxy. If the backend deployment is missing/outdated, the panel reports the error instead of presenting fabricated stats.
- Puzzle download uses 50 separate throttled requests (~50 seconds worst-case) to add up to 50 new puzzles; duplicates/invalid puzzles may mean fewer are added. The 500-item cap is a storage/cache limit, not a bundled 500-puzzle data file.
- Stockfish Skill Level 0 is not Elo-calibrated; the error policy is a visible training handicap, not a verified 500 rating.
