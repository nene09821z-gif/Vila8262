# Báo cáo kiểm thử Cờ Vua ViLa v3.46.1

Ngày rà soát: 20/10/2026. Phạm vi: đối chiếu các phát hiện trong ảnh người dùng cung cấp với ZIP v3.46.0, sửa các lỗi có thể xác minh tại mã nguồn và chạy lại bộ test khả dụng.

## Các điểm đã sửa

1. **Phiên bản và cache biểu tượng:** nâng phiên bản nguồn lên `3.46.1`; đồng bộ `package.json`, tiêu đề HTML, API health, User-Agent của dịch vụ và Service Worker. Cache-bust favicon đồng bộ ở `index.html` và `public/sw.js` thành `v=347`.
2. **Changelog/README:** bỏ phần v3.45.0 tiếng Anh bị lặp ở cuối changelog; đưa ghi chú v3.44.0 về đúng thứ tự; chuyển phần v3.37.2 lên gần lịch sử v3.37.1 trong README; cập nhật liên kết báo cáo QA mới nhất.
3. **Tài liệu câu đố:** đổi tiêu đề `PUZZLES_SOURCE.md` sang v3.46.1 và bỏ số liệu cũ gắn với bản v3.38.0.
4. **Dữ liệu khai cuộc:** thay `public/openings-eco.json` rỗng bằng **338 dòng dự phòng đã loại biến trùng** lấy từ bộ khai cuộc đã có trong mã nguồn. Tệp ghi rõ đây là dữ liệu dự phòng của dự án, không mạo nhận là kho Lichess CC0 hay là bộ đầy đủ 3.000 biến.
5. **Chẩn đoán thiếu dữ liệu:** sửa `loadExternalOpeningCatalog()` để không âm thầm thoát khi JSON chỉ gồm các biến đã có sẵn; số lượng thực tế và cảnh báo thiếu kho đầy đủ vẫn được cập nhật.
6. **Chặn phát hành khi thiếu dữ liệu:** thêm bước chạy `scripts/verify-opening-catalog.mjs` sau build web ở cả hai workflow Android. Build phát hành vẫn yêu cầu ít nhất 3.000 dòng khai cuộc hợp lệ trong tệp nguồn và thư mục `dist`.
7. **Rà ảnh:** kiểm tra 34 ảnh PNG/WebP trong `public/` và `resources/`; tất cả đều đọc được và có kích thước hợp lệ. Kiểm tra hiện diện đủ 12 PNG quân cờ cùng các biểu tượng được tham chiếu trong HTML.
8. **Test hồi quy mới:** thêm `tests/release-audit.test.js` vào `npm run test:static`, gồm kiểm tra version/cache, catalog dự phòng, cổng phát hành, nhánh dữ liệu trùng, thứ tự changelog, tài liệu và tài nguyên biểu tượng.

## Kết quả kiểm tra

| Kiểm tra | Kết quả thực tế |
|---|---:|
| `npm run test:static` | **261/261 đạt** |
| `node --check` trên JS/MJS trong `src`, `server`, `scripts`, `tests` | **130/130 đạt** |
| `npm test` | **263/267 đạt; 4 test không khởi chạy** |
| PNG/WebP trong `public/` và `resources/` | **34/34 đọc được** |
| Test bổ sung `tests/release-audit.test.js` | **7/7 đạt** |
| `npm install --ignore-scripts --no-audit --no-fund --fetch-timeout=5000 --fetch-retries=0` | **Không cài được:** DNS `EAI_AGAIN` với `registry.npmjs.org` |
| `npm run build` | **Bị chặn trước Vite:** thiếu package `chess.js` ở bước `prebuild` |
| `node scripts/verify-opening-catalog.mjs` trong cây nguồn hiện tại | **Chủ động từ chối phát hành:** chỉ có 338 dòng dự phòng, chưa đủ 3.000; chưa có `dist` để kiểm tra |

Bốn test của `npm test` bị chặn lúc khởi tạo module do thiếu dependency: `tests/alternate-engine.test.js`, `tests/chess.test.js` và `tests/v3-25-features.test.js` cần `chess.js`; `tests/social.test.js` cần `express`. Trong 263 bài có thể chạy, không có assertion nào thất bại.

## Giới hạn chưa thể xác nhận

- **Chưa xác nhận production build hoặc APK.** Việc cài package bị lỗi DNS và `node_modules` không có, nên build Vite dừng tại bước `prebuild`. Chưa có APK artifact trong gói này.
- **Kho khai cuộc 3.000 dòng chưa được tạo trong môi trường này.** Bản ZIP chỉ mang 338 dòng dự phòng; workflow đã có cổng bắt buộc và sẽ dừng nếu không thể tải, xác thực và copy kho đầy đủ. Muốn xác nhận release cần chạy workflow trên runner có mạng và kiểm tra artifact sau build.
- Kiểm tra luật SAN đầy đủ của bộ dự phòng bị giới hạn vì test tích hợp dùng `chess.js` không thể khởi chạy trong môi trường này. Đã kiểm tra cấu trúc, ECO, độ dài và trùng dòng; không tuyên bố đã chạy xác thực nước đi bằng `chess.js`.
- Chưa thử thao tác thực tế trên OPPO/Android WebView; các bước đó vẫn cần build thành công và test thiết bị.

**Kết luận:** các lỗi tài liệu/cache và tình trạng tệp khai cuộc rỗng đã được sửa; bộ test tĩnh đạt. Bản nguồn hiện vẫn chưa đủ điều kiện để tuyên bố build phát hành/APK thành công cho đến khi cài được dependencies và workflow tạo, xác minh kho khai cuộc đầy đủ.
