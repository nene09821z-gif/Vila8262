# Báo cáo kiểm tra ViLa Chess v3.61.0

## Kết quả đã xác minh trong môi trường làm việc

- **56/56 kiểm thử mục tiêu đạt**: xếp hạng/time control, khôi phục lựa chọn sau khi tải lại, fair-play signal, giao diện admin báo cáo, metadata phát hành, màn hình thiết lập trận, các kiểm tra hồi quy giao diện và nguồn.
- `node --check` đạt với `src/main.js`, `src/ranked-fair-play.js`, `server/social.js` và `cloudflare/src/index.js`.
- Các bài test fair-play xác nhận một nước đi nhanh đơn lẻ không bị coi là gian lận; tín hiệu cần mẫu lặp; telemetry được giới hạn 12 lượt gần đây; luật không tự động cấm/khóa tài khoản.
- Dashboard admin hiển thị các sự kiện trả về bởi API `/admin/fair-play` và tiếp tục tải các mục khác khi endpoint này không có ở backend cũ.

## Chưa xác minh — không được hiểu là đã chạy thành công

- `npm ci` đã timeout trong môi trường này và phụ thuộc cần cho một số bài test tích hợp (`chess.js`, `express`) không hoàn chỉnh. Do đó, chưa xác nhận toàn bộ `npm test`, `npm run build`, Vite production build hoặc APK Gradle.
- Cloudflare Worker chưa được triển khai kiểm chứng từ môi trường này. Chưa thử ghép trận giữa hai tài khoản/thiết bị qua Internet, đồng hồ thực khi mất mạng, hoặc persistence sau khi Worker khởi động lại.
- Anti-cheat hiện tạo **tín hiệu rà soát từ thời gian do server đo và độ phức tạp nước đi**; không thể chứng minh dùng engine từ các tín hiệu này một mình. Việc xử phạt cần xem xét thủ công và/hoặc thêm phân tích chất lượng nước đi, dữ liệu nhiều ván và cơ chế kháng nghị.
- Chưa chạy kiểm thử tương tác bằng Android emulator hoặc OPPO A17k.

## Lệnh có thể chạy trong môi trường có npm registry

```bash
npm ci
npm run test:static
npm test
npm run build
```

Để xác nhận online, deploy Worker/Durable Object theo `ONLINE_MATCHMAKING_DEPLOYMENT.md`, rồi kiểm tra hai tài khoản thật và xác thực đồng hồ, kết quả Elo, báo cáo fair-play sau khi tải lại ứng dụng.
