# Build APK Cờ Vua ViLa v3.52.0 bằng GitHub Actions

ZIP `vila-chess-pro-v3.52.0-github-source.zip` chứa mã nguồn web/Capacitor và workflow Android; **không phải APK**. Giải nén thẳng vào repository để `.github/workflows/` và `package.json` nằm ngay ở thư mục gốc.

## Các bước

1. Giải nén ZIP, tạo repository GitHub rồi đẩy toàn bộ nội dung bên trong lên repository. Không bỏ thư mục `.github/workflows/`.
2. Mở tab **Actions**, chọn **Cờ Vua ViLa Android build**, bấm **Run workflow**; workflow này cũng tự chạy trên push/PR.
3. Runner dùng Node.js 22 và Java 21, cài dependencies, kiểm tra cú pháp, chạy toàn bộ `npm test`, tạo kho khai cuộc, tải bộ quân, kiểm tra Stockfish 19 Lite/Full NNUE/ASM-JS và Stockfish 10 cổ điển cùng giấy phép GPL, build web, sync Capacitor và build `assembleDebug`.
4. Nếu tất cả bước bắt buộc đạt, tải artifact **`covua-vila-debug-apk`** để lấy `app-debug.apk`. `test-report` chứa đầu ra test; `covua-vila-android-gradle-source` là gói nguồn Gradle được sinh khi build.

## Nếu workflow thất bại

- Mở step lỗi đầu tiên và tải artifact `test-report`; không tắt test để ép đóng gói APK.
- Nếu thiếu Stockfish 19 hoặc Stockfish 10/giấy phép GPL, xem log của `scripts/copy-engine.mjs` và tên file trong `public/engine/engine-manifest.json`.
- Nếu lỗi bộ quân/kho khai cuộc, kiểm tra runner có thể lấy dữ liệu từ các URL nguồn được ghi trong mã và `public/piece-sets/CREDITS.md`.
- Nếu lỗi Gradle, xem log các bước `cap sync android`, `verify-android-project.mjs` và `assembleDebug`.

## Build cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

Cần Node 22, Java/Android SDK phù hợp và kết nối mạng để tải package/data khi chưa có cache. Full Stockfish NNUE làm APK lớn hơn Lite đáng kể; auto fallback vẫn được giữ cho WebView không khởi tạo được Full.

## Giới hạn xác minh của bản ZIP

Báo cáo kiểm thử mới nhất nằm ở `TEST_REPORT_V3_50_0.md`; các báo cáo phiên bản cũ và `TEST_REPORT_V3_45_0.md` được giữ để tham chiếu lịch sử. Build phát hành yêu cầu dữ liệu khai cuộc đầy đủ (tối thiểu 3.000 dòng hợp lệ) và sẽ dừng nếu tải/kiểm tra không đạt. APK chỉ được coi là đã build thành công sau khi GitHub Actions hoàn tất build Gradle và tạo artifact APK; cần kiểm tra thêm trên thiết bị Android thật.

## Native Stockfish Android ARM64

Both GitHub workflows download and verify the official Stockfish Android ARM64 universal executable during the build (`scripts/fetch-native-stockfish-android.sh`). After Capacitor generates `android/`, `scripts/install-native-stockfish-android.mjs android` integrates the executable and Java bridge into the actual `android/app/` module and includes the GPL notice. Do not put the 77 MiB release archive or the ~100 MB executable into the source ZIP; the packager excludes it and fails if the ZIP exceeds 25,000,000 bytes. The built APK can be much larger. On Android ARM64/API 29+, Auto/Full tries native Stockfish via UCI. Explicit Lite and Stockfish 10 choices remain on their respective JS workers; unsupported devices or failed native startup fall back to JS/WASM/ASM-JS.
