# ViLa Chess — Social/profile update

- Reworked the player profile into a responsive, Chess.com-inspired layout with rating cards, public bio, W/D/L statistics, and profile actions.
- Player search results and Top 100 entries open profiles by username. Public profile responses do not expose email or account secrets.
- Added one-to-one private messaging with conversation list, read history, text-length limits, and server-side rate limiting.
- Added player reports and an admin moderation queue. A report does not automatically ban someone; an admin must review and confirm a ban. Admin accounts cannot be banned through this flow.
- Admin accounts get server-controlled Premium entitlements and skip the server review quota. Admin role assignment remains a server configuration responsibility.
- Registration initial Elo choices are now 200 / 500 / 1000 / 1500. Bot games no longer adjust Elo or add ranked-Elo history; Elo updates come from server-verified ranked online games.
- Styled profile, chat, report and selection panels for responsive phone use.

## Verification notes

`node --check` passed for the changed JavaScript files. The static tests for the account gate, admin Elo setup, profile navigation, rated-online UI, Elo helpers, and billing wiring passed in this environment. Full integration/runtime and production build checks could not be completed because dependency installation timed out and left required npm packages incomplete (`express` and `chess.js` are missing entry files in the local `node_modules`). The archive does not include `node_modules`; run `npm ci` in an environment with working npm registry access, then `npm test` and `npm run build` before deploying.
