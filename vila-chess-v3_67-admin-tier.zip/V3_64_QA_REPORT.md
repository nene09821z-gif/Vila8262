# VILA Chess v3.64.0 — QA report

## Phạm vi thay đổi
- Redesign Cài đặt theo nhóm; thiết lập gameplay, bot/engine, đồng hồ, âm thanh và trợ năng.
- Bộ chọn Elo bot với preset; tile 3D cyan mới cho ghép trận online.
- Modal xác nhận đầu hàng/thoát trận theo thương hiệu VILA; bổ sung thương hiệu VILA vào bảng tổng kết.
- Chuẩn hóa SAN cho nhận diện khai cuộc, gồm dấu chiếu/đánh giá và ký hiệu nhập thành.
- Luồng Pro/Premium vẫn gửi yêu cầu lên backend rồi mở Messenger admin; không tự xác nhận thanh toán hay tự cấp Premium.

## Kiểm thử đã chạy
- Cú pháp JavaScript: `node --check` với `src/main.js`, `src/sound.js`, `src/opening-recognition.js`, `src/settings-schema.js` — đạt.
- Bộ test mục tiêu liên quan đến cài đặt, mobile, nhận diện khai cuộc, yêu cầu gói và release audit — 37/37 đạt.
- `npm run test:static`: 343/348 đạt; 5 bài không khởi tạo được do dependency thiếu (`express` cho `account-auth-e2e`, `chess.js` cho `cloudflare-billing`, `cloudflare-external-routes`, `cloudflare-plans`, `premove`). Đây là bài bị chặn khi nạp module, không phải lỗi được tính thành pass.

## Giới hạn cần biết
- `npm run build` hiện không hoàn tất vì package `chess.js` chưa có trong môi trường. Cần cài dependencies đầy đủ rồi chạy lại build/test trên môi trường có mạng.
- Chưa tạo/kiểm tra APK, chưa triển khai Cloudflare/Node backend từ đây và chưa kiểm thử ghép trận giữa hai tài khoản thật.
- `public/openings-eco.json` vẫn là dữ liệu dự phòng và chưa đạt yêu cầu kho đầy đủ tối thiểu 3.000 dòng. Bản này cải thiện chuẩn hóa nhận diện SAN, không tuyên bố đã nhập bộ khai cuộc đầy đủ.
- Thiết lập bot/engine được lưu phía giao diện. Mức sức mạnh thực tế phụ thuộc engine được chọn, khả năng engine sẵn có và cấu hình build; không thể bảo đảm mọi engine hoạt động nếu thiếu tài nguyên/dependencies.
