# VILA Chess v3.65.0 — thiết lập mã dùng thử

Màn nhập mã chỉ gửi mã tới API. Mã không được nhúng trong giao diện: máy chủ so sánh HMAC-SHA-256 bằng một secret riêng, giới hạn thử 5 lần mỗi 15 phút theo IP, yêu cầu đăng nhập, và lưu loại mã đã dùng trên tài khoản. Mỗi loại chỉ được đổi một lần cho mỗi tài khoản.

## Quyền được cấp

- `AdminVila`: Pro dùng thử 5 ngày.
- `99vila`: Premium Preview 60 giây; sau khi hết hạn ứng dụng trở lại gói Pro nếu Pro vẫn còn hạn, nếu không thì về Free.

Đây là mã dùng thử dùng chung theo yêu cầu. Nếu được công khai cho nhiều người, bất kỳ ai biết mã có thể dùng nó cho tài khoản của họ một lần; các mã này không phải mã thanh toán hay mã riêng theo từng người.

## 1. Tạo HMAC cho Node server hoặc Cloudflare Worker

Trong thư mục gốc dự án, dùng Node.js 20+ và tạo một secret ngẫu nhiên. Không đưa secret vào Git, APK, mã frontend hoặc tin nhắn công khai.

```bash
export VILA_TRIAL_CODE_SECRET="$(openssl rand -hex 32)"
export VILA_PRO_TRIAL_CODE_HMAC="$(node scripts/trial-code-hash.mjs AdminVila)"
export VILA_PREMIUM_TRIAL_CODE_HMAC="$(node scripts/trial-code-hash.mjs 99vila)"
```

Ba biến môi trường này phải tồn tại cùng lúc trên backend. Không tự thay secret mà quên tính lại hai HMAC. Script chỉ in digest; không in mã/secret.

## 2A. Chạy Node backend tại máy đang thử

Trong cùng phiên Termux đã export biến ở bước 1:

```bash
npm run dev
```

Không cần thêm cấu hình frontend. Nếu đóng Termux, thiết lập lại ba biến trong phiên mới hoặc lưu chúng vào bộ quản lý secret riêng tư trên máy chủ. Đừng đẩy `.env.trial-codes` lên GitHub.

## 2B. Cấu hình Cloudflare Worker online

Cần chạy lệnh trong thư mục dự án và đã đăng nhập Wrangler. Thực hiện lần lượt trong cùng phiên shell sau bước 1:

```bash
printf '%s' "$VILA_TRIAL_CODE_SECRET" | npx wrangler secret put VILA_TRIAL_CODE_SECRET
printf '%s' "$VILA_PRO_TRIAL_CODE_HMAC" | npx wrangler secret put VILA_PRO_TRIAL_CODE_HMAC
printf '%s' "$VILA_PREMIUM_TRIAL_CODE_HMAC" | npx wrangler secret put VILA_PREMIUM_TRIAL_CODE_HMAC
npx wrangler deploy
```

Worker đang được ứng dụng dùng phải được triển khai bản v3.65.0 và có đủ ba secret trên. ZIP chỉ bao gồm mã nguồn; không tự cập nhật dịch vụ Worker đang chạy.

## Ghi chú bảo mật

Không có cách giấu mã dùng chung tuyệt đối nếu mã được trao cho người dùng. HMAC bảo vệ mã khỏi bị trích xuất từ bundle frontend; xác thực người dùng, rate limit và đánh dấu đã đổi mã phía máy chủ ngăn việc sửa localStorage hoặc gửi lại mã từ cùng tài khoản. Đây vẫn là cơ chế quyền dùng thử, không phải DRM tuyệt đối. Dịch vụ sẽ trả `503` nếu thiếu secret, thay vì tự cấp gói khi backend chưa cấu hình.
