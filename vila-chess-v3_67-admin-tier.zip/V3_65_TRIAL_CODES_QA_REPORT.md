# VILA Chess v3.65.0 — QA report

This report covers the trial-code and first-launch brand-intro additions. See `TRIAL_CODES_SETUP_V3_65.md` before deploying; the ZIP does not configure production secrets automatically.

## Phạm vi thay đổi
- Thêm tab/trang nhập mã riêng và lời nhắc đăng nhập; giao diện gửi mã tới `POST /api/social/me/redeem-code`.
- `AdminVila` cấp Pro dùng thử 5 ngày; `99vila` cấp Premium Preview 60 giây. Hạn dùng được tính từ timestamp máy chủ; Premium hết hạn sẽ rơi về Pro nếu Pro còn hạn, nếu không về Free.
- Mã được kiểm tra bằng HMAC-SHA-256 với secret chỉ ở Node server/Cloudflare Worker; không nhúng các mã vào JS/CSS frontend. Có xác thực, giới hạn 5 lần/15 phút và dấu đã dùng theo tài khoản/loại mã.
- Intro thương hiệu dùng SVG nội tuyến tự vẽ (không tải ảnh từ URL), CSS hoạt ảnh 3D, tổng thời lượng 5 giây, hiển thị một lần cho mỗi trình duyệt/app storage.
- Nâng Android `versionCode` lên 13 và `versionName` lên `3.65.0`.

## Kiểm thử đã chạy cho thay đổi này
- Bộ test mục tiêu: **36/36 đạt** (`trial-codes-v365`, release audit, smoke, schema settings, Pro/Premium UI).
- Bộ `npm run test:static`: **346/351 đạt**; 5 bài không khởi chạy vì dependency chưa cài đầy đủ (`express` cho `account-auth-e2e`, `chess.js` cho `cloudflare-billing`, `cloudflare-external-routes`, `cloudflare-plans`, `premove`). Những bài bị chặn không được tính là pass.
- `node --check`: **7/7 tệp JS/MJS đã chỉnh sửa đạt cú pháp**. Không chạy được bộ phân tích CSS PostCSS vì package PostCSS trong môi trường bị thiếu/không hoàn chỉnh.
- Các test mục tiêu xác minh thời hạn 5 ngày/60 giây, trở về Free sau hết hạn, cấp Pro sau khi Premium preview hết hạn, sử dụng HMAC ở backend, route API và sự hiện diện của trang nhập mã/intro. Đây là test logic/pattern; chưa xác minh bằng request tích hợp chạy trên server thật.

## Giới hạn và triển khai
- `npm install` bị timeout trong môi trường này; gói `chess.js` và `express` chưa sẵn sàng. Vì vậy chưa xác nhận tích hợp API thực tế, build Vite, APK hay triển khai Worker.
- Trước khi mã hoạt động online cần đặt `VILA_TRIAL_CODE_SECRET`, `VILA_PRO_TRIAL_CODE_HMAC`, `VILA_PREMIUM_TRIAL_CODE_HMAC` trong secrets của backend và deploy phiên bản đã chỉnh sửa. Nếu không, API cố ý trả `503` thay vì tự cấp gói.
- Đây là mã dùng chung: người biết mã có thể đổi một lần trên tài khoản của họ. HMAC ngăn việc đọc mã từ bundle frontend nhưng không biến một mã dùng chung thành bí mật riêng từng người.
- Danh mục khai cuộc vẫn là bộ dự phòng, chưa đạt ngưỡng 3.000 dòng; chưa thay đổi điều đó trong phiên bản này.
- Chưa kiểm thử trên điện thoại thật hoặc 2 tài khoản online thực tế.
