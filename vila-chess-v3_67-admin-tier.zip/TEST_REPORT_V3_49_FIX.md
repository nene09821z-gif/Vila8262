# Báo cáo sửa lỗi — VILA Chess v3.49

## Đã chỉnh
- Sửa test hồi quy trong `tests/premove.test.js`: test trước đó chỉ chấp nhận biểu thức `botDepth: Math.max(...)` và báo lỗi dù mã đã có nhánh giới hạn sức mạnh theo Elo.
- Tách `rescueDepth` trong `src/main.js`: Elo/skill có mục tiêu dùng giới hạn dự phòng; chế độ sức mạnh tối đa giữ ngân sách tìm kiếm sâu hơn nhưng vẫn qua `resolveOfflineSearchBudget` giới hạn theo thiết bị.
- Bổ sung kiểm tra tĩnh cho đường cứu hộ: tìm kiếm offline trước, kiểm tra nước đi hợp lệ, cập nhật đồng hồ, và chỉ dùng nước khẩn cấp khi tìm kiếm thất bại.

## Đã xác minh trong môi trường này
- Kiểm tra cú pháp `node --check` cho tất cả tệp `.js` và `.mjs` trong `src/`, `server/`, `scripts/`, `tests/`: đạt.
- Bộ test được chọn về ngân sách engine, Elo, cấu hình, đồng hồ, bố cục, khai cuộc, câu đố, thông báo và tình trạng engine: **74/74 đạt**.
- 8 kiểm tra tĩnh riêng cho luồng cứu hộ Stockfish: đạt.

## Chưa xác minh
- Chưa chạy toàn bộ `npm test`, bài test premove tích hợp hoặc build Vite/Gradle/APK trong môi trường này: cài dependency bị treo và các gói `chess.js`, `vite`, `express`, Stockfish chưa có sẵn.
- Chưa chạy trên OPPO A17k hay thiết bị Android thật. Không có tuyên bố rằng thao tác hoặc tốc độ trên thiết bị đã được đo.
