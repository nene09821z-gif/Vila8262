# VILA Chess v3.67.0 — Test 292 correction

## Root cause

The failed test `Stockfish failure uses a strength-aware bounded offline search before the basic emergency move` required the previous `rescueDepth` ternary:

- old pattern: branch only on `rescueStrength`
- current implementation: first uses `beginnerRescueBudget` for `skill-level-floor` targets, then falls back to bounded 12-ply strength-aware search or the configured unrestricted maximum.

The implementation had evolved to include a dedicated low-Elo budget, but the source-regex test had not been updated. Thus the test failed on a stale textual expectation rather than a missing strength-aware branch.

## Fix

Updated `tests/premove.test.js` to assert the actual contract:

- low-skill targets resolve `resolveBeginnerSearchBudget(...)`;
- beginner rescue uses `beginnerRescueBudget.depth`;
- other strength-constrained rescue remains capped at 12 plies;
- unrestricted mode retains its configured hard cap;
- the beginner time/node budget is passed into `resolveOfflineSearchBudget`;
- the offline search is tried before the emergency move;
- returned UCI is checked against legal moves and current-game/clock guards remain present.

No production-code change was needed for this failure, and the regression assertions were not removed or loosened.

## Validation

- Direct source-contract checks: **8/8 passed**.
- `tests/elo-500-bot.test.js`, `tests/engine-budgets.test.js`, `tests/engine-profile.test.js`: **13/13 passed**.
- Full `tests/premove.test.js`: **not executed in this environment** because `npm install --ignore-scripts --no-audit --no-fund` timed out and `node_modules/chess.js` is incomplete. Do not treat this as a passing run; rerun after dependencies are installed:

```bash
npm install
node --test tests/premove.test.js
```
