package com.example

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import android.webkit.WebView
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * Google Play Billing for the one-time products (Pro 1 year = consumable, Premium = non-consumable).
 *
 * This class only talks to Google Play and reports back to the web app through a `vila-native-billing` DOM event.
 * It never decides that a purchase is valid: the Worker verifies the token with Google, and only after the server
 * accepts it does the web app call [finish] (consume Pro so it can be bought again, acknowledge Premium).
 */
class PlayBilling(private val context: Context, private val webView: WebView) : PurchasesUpdatedListener {
  private val details = ConcurrentHashMap<String, ProductDetails>()
  @Volatile private var productIds: List<String> = emptyList()
  private val client: BillingClient = BillingClient.newBuilder(context)
    .setListener(this)
    .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
    .build()

  private fun activity(): Activity? {
    var current: Context? = context
    while (current is ContextWrapper) {
      if (current is Activity) return current
      current = current.baseContext
    }
    return null
  }

  /** Runs [block] once the billing service is connected (reconnects if Play Store was restarted). */
  private fun withConnection(onFail: (BillingResult?) -> Unit = {}, block: () -> Unit) {
    if (client.isReady) { block(); return }
    client.startConnection(object : BillingClientStateListener {
      override fun onBillingSetupFinished(result: BillingResult) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK) block() else onFail(result)
      }
      override fun onBillingServiceDisconnected() { /* reconnected lazily on the next call */ }
    })
  }

  fun available(): Boolean = true

  /** Loads product details (localized prices) and reports them to the web app. */
  fun init(ids: List<String>) {
    productIds = ids.filter { it.isNotBlank() }.distinct()
    if (productIds.isEmpty()) return
    withConnection(onFail = { emit(JSONObject().put("type", "error").put("message", "Google Play Billing không khả dụng trên thiết bị này.")) }) {
      val products = productIds.map {
        QueryProductDetailsParams.Product.newBuilder().setProductId(it).setProductType(BillingClient.ProductType.INAPP).build()
      }
      client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build()) { result, list ->
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
          Log.w(TAG, "queryProductDetails failed: ${result.debugMessage}")
          return@queryProductDetailsAsync
        }
        val prices = JSONObject()
        list.forEach { detail ->
          details[detail.productId] = detail
          detail.oneTimePurchaseOfferDetails?.formattedPrice?.let { prices.put(detail.productId, it) }
        }
        emit(JSONObject().put("type", "prices").put("prices", prices))
      }
    }
  }

  /** [accountId] is the server-issued binding id: Google echoes it back so the server can match token -> account. */
  fun start(productId: String, accountId: String): Boolean {
    val host = activity() ?: return false
    val detail = details[productId]
    if (detail == null) {
      emit(JSONObject().put("type", "error").put("message", "Sản phẩm chưa sẵn sàng trên Google Play. Hãy thử lại sau ít giây."))
      if (productIds.isNotEmpty()) init(productIds)
      return false
    }
    if (accountId.isBlank()) return false
    withConnection(onFail = { emit(JSONObject().put("type", "error").put("message", "Không kết nối được Google Play.")) }) {
      val params = BillingFlowParams.newBuilder()
        .setProductDetailsParamsList(listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(detail).build()))
        .setObfuscatedAccountId(accountId)
        .build()
      webView.post {
        val result = client.launchBillingFlow(host, params)
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
          emit(JSONObject().put("type", "error").put("message", "Không mở được màn hình thanh toán (${result.responseCode})."))
        }
      }
    }
    return true
  }

  /** Re-reports every purchase Google still shows as owned, so a paid-but-unverified purchase is never lost. */
  fun queryOwned() {
    withConnection {
      client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build()) { result, purchases ->
        if (result.responseCode == BillingClient.BillingResponseCode.OK) report(purchases)
      }
    }
  }

  /** Called only after the server accepted the purchase. Pro is consumed (re-buyable); Premium is acknowledged. */
  fun finish(purchaseToken: String, consume: Boolean) {
    withConnection {
      if (consume) {
        client.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(purchaseToken).build()) { result, _ ->
          if (result.responseCode != BillingClient.BillingResponseCode.OK) Log.w(TAG, "consume: ${result.debugMessage}")
        }
      } else {
        client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchaseToken).build()) { result ->
          // The server already acknowledges; an "already acknowledged" answer here is expected and harmless.
          Log.d(TAG, "acknowledge: ${result.responseCode}")
        }
      }
    }
  }

  override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
    when (result.responseCode) {
      BillingClient.BillingResponseCode.OK -> report(purchases.orEmpty())
      BillingClient.BillingResponseCode.USER_CANCELED -> emit(JSONObject().put("type", "cancelled"))
      BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
        emit(JSONObject().put("type", "error").put("message", "Bạn đang sở hữu mục này. Đang khôi phục…"))
        queryOwned()
      }
      else -> emit(JSONObject().put("type", "error").put("message", "Thanh toán không thành công (${result.responseCode})."))
    }
  }

  private fun report(purchases: List<Purchase>) {
    purchases.forEach { purchase ->
      val productId = purchase.products.firstOrNull() ?: return@forEach
      when (purchase.purchaseState) {
        Purchase.PurchaseState.PURCHASED ->
          emit(JSONObject().put("type", "purchased").put("productId", productId).put("purchaseToken", purchase.purchaseToken))
        Purchase.PurchaseState.PENDING ->
          emit(JSONObject().put("type", "pending").put("productId", productId))
        else -> Unit
      }
    }
  }

  private fun emit(detail: JSONObject) {
    val quoted = JSONObject.quote(detail.toString())
    webView.post {
      webView.evaluateJavascript(
        "window.dispatchEvent(new CustomEvent('vila-native-billing',{detail:JSON.parse($quoted)}));",
        null
      )
    }
  }

  companion object {
    private const val TAG = "VILA-Billing"

    fun parseIds(json: String): List<String> = try {
      val array = JSONArray(json)
      (0 until array.length()).map { array.optString(it) }
    } catch (_: Exception) { emptyList() }
  }
}
