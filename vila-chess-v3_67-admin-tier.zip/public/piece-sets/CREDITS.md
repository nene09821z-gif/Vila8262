# Cờ Vua ViLa — piece-set notices

These nine SVG sets are optional open artwork used under their stated licenses. They are fetched from the upstream Lichess public piece directory during a release build; the app loads the resulting copies locally and caches them for offline use. Do not remove these notices when redistributing the assets.

| Set | Author | License | Source |
|---|---|---|---|
| fantasy | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/fantasy |
| spatial | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/spatial |
| celtic | Maurizio Monge | MIT | https://github.com/lichess-org/lila/tree/master/public/piece/celtic |
| chessnut | Alexis Luengas | Apache-2.0 | https://github.com/lichess-org/lila/tree/master/public/piece/chessnut |
| rhosgfx | RhosGFX | CC0-1.0 | https://github.com/lichess-org/lila/tree/master/public/piece/rhosgfx |
| kiwen-suwi | neverRare | CC-BY-4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/kiwen-suwi |
| firi | James Faure | CC-BY-4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/firi |
| totoy | Kosal Sen | CC-BY-4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/totoy |
| shapes | flugsio | CC-BY-SA-4.0 | https://github.com/lichess-org/lila/tree/master/public/piece/shapes |

Upstream license mapping: https://github.com/lichess-org/lila/blob/master/COPYING.md. Cờ Vua ViLa is not affiliated with or endorsed by Lichess. These are piece artwork only; the project does not copy the Chess.com piece assets.
