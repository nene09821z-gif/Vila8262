#!/usr/bin/env node
import { createHmac } from 'node:crypto';

const code = String(process.argv[2] || '').trim().toLowerCase();
const secret = String(process.env.VILA_TRIAL_CODE_SECRET || '');
if (!code || !/^[a-z0-9-]{4,80}$/.test(code)) {
  console.error('Usage: VILA_TRIAL_CODE_SECRET=<secret> node scripts/trial-code-hash.mjs <code>');
  process.exit(2);
}
if (Buffer.byteLength(secret, 'utf8') < 32) {
  console.error('VILA_TRIAL_CODE_SECRET is required and must contain at least 32 bytes.');
  process.exit(2);
}
// Print only the keyed digest; never print the submitted code or secret.
process.stdout.write(createHmac('sha256', secret).update(code, 'utf8').digest('hex') + '\n');
