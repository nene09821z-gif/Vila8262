#!/usr/bin/env bash
set -euo pipefail

# Official Stockfish Android ARM64 universal release. Downloaded during CI so the
# GitHub-uploadable source ZIP does not need to contain a ~70-80 MiB engine archive.
# Ensure ELF inspection tools exist on minimal runners.
command -v readelf >/dev/null 2>&1 || { echo "readelf missing; install binutils" >&2; exit 1; }
command -v file >/dev/null 2>&1 || { echo "file missing" >&2; exit 1; }

readonly STOCKFISH_URL="https://github.com/official-stockfish/Stockfish/releases/latest/download/stockfish-android-arm64-universal.tar.gz"
readonly TMP_DIR="$(mktemp -d)"
readonly ARCHIVE="$TMP_DIR/stockfish-android-arm64-universal.tar.gz"
readonly DEST="app/src/main/jniLibs/arm64-v8a/libstockfish.so"
readonly LICENSE_DEST="app/src/main/assets/STOCKFISH-COPYING.txt"
trap 'rm -rf "$TMP_DIR"' EXIT

mkdir -p "$(dirname "$DEST")" "$(dirname "$LICENSE_DEST")"
if [[ -n "${STOCKFISH_ARCHIVE:-}" ]]; then
  # Optional local validation path; GitHub Actions leaves STOCKFISH_ARCHIVE unset and downloads upstream.
  cp "$STOCKFISH_ARCHIVE" "$ARCHIVE"
else
  curl --fail --location --retry 4 --retry-all-errors --connect-timeout 20 \
    "$STOCKFISH_URL" -o "$ARCHIVE"
fi
tar -tzf "$ARCHIVE" > "$TMP_DIR/archive-files.txt"
# Accommodate both GitHub release tarballs (files at archive root) and source/artifact
# tarballs (files beneath a stockfish/ directory), without extracting arbitrary paths.
BINARY_ENTRY="$(awk '/(^|\/)stockfish-android-arm64-universal$/ && !found { print; found=1 }' "$TMP_DIR/archive-files.txt")"
LICENSE_ENTRY="$(awk '/(^|\/)Copying[.]txt$/ && !found { print; found=1 }' "$TMP_DIR/archive-files.txt")"
[[ -n "$BINARY_ENTRY" ]] || { echo 'Stockfish Android ARM64 executable is missing from archive.' >&2; exit 1; }
[[ -n "$LICENSE_ENTRY" ]] || { echo 'Stockfish GPL Copying.txt is missing from archive.' >&2; exit 1; }
tar -xOzf "$ARCHIVE" -- "$BINARY_ENTRY" > "$TMP_DIR/stockfish-engine"
tar -xOzf "$ARCHIVE" -- "$LICENSE_ENTRY" > "$TMP_DIR/Copying.txt"

install -m 0755 "$TMP_DIR/stockfish-engine" "$DEST"
install -m 0644 "$TMP_DIR/Copying.txt" "$LICENSE_DEST"

file "$DEST"
readelf -h "$DEST" | grep -Eq 'Machine:[[:space:]]+AArch64' || {
  echo 'Downloaded Stockfish binary is not an AArch64 executable.' >&2
  exit 1
}
[[ -s "$LICENSE_DEST" ]] || { echo 'Stockfish GPL license file is missing.' >&2; exit 1; }
sha256sum "$DEST"
echo "Native Stockfish prepared at $DEST ($(du -h "$DEST" | cut -f1))."
if [[ -n "${GITHUB_STEP_SUMMARY:-}" ]]; then
  {
    echo '### Native Stockfish Android ARM64'
    echo '- Downloaded the official universal ARM64 engine during build.'
    echo '- Verified the binary ELF machine type is AArch64 and included its GPL license.'
    echo "- Binary SHA-256: $(sha256sum "$DEST" | awk '{print $1}')"
    echo "- Binary size: $(stat -c '%s' "$DEST") bytes"
  } >> "$GITHUB_STEP_SUMMARY"
fi
