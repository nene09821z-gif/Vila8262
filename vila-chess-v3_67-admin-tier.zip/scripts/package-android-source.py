#!/usr/bin/env python3
"""Package a generated Capacitor Android Gradle project as a portable source ZIP.

Run only after npm install, npm run build, `npx cap add android` (if missing),
`npx cap sync android`, and branding application. The source ZIP excludes build caches and most dependencies, but includes the native
@capacitor/android Gradle module referenced by settings.gradle.
"""
from pathlib import Path
import io
import os
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(os.environ.get('RUNNER_TEMP', '/tmp')) / 'covua-vila-android-gradle-source.zip'
android = root / 'android'
# Require Gradle's settings/build files and the real wrapper JAR, not just a shell stub.
missing = []
for alternatives in [
    [android / 'settings.gradle', android / 'settings.gradle.kts'],
    [android / 'gradlew'],
    [android / 'gradle' / 'wrapper' / 'gradle-wrapper.jar'],
    [android / 'gradle' / 'wrapper' / 'gradle-wrapper.properties'],
    [android / 'app' / 'build.gradle', android / 'app' / 'build.gradle.kts'],
    [android / 'app' / 'src' / 'main' / 'AndroidManifest.xml'],
    [root / 'node_modules' / '@capacitor' / 'android' / 'capacitor' / 'build.gradle'],
]:
    if not any(p.is_file() for p in alternatives):
        missing.append(' or '.join(str(p.relative_to(root)) for p in alternatives))
if missing:
    raise SystemExit('Android Gradle project is incomplete; refusing to package. Missing: ' + '; '.join(missing))

excluded_dirs = {
    '.git', 'dist', '.gradle', '__pycache__', '.idea',
}
excluded_names = {'.env', '.DS_Store'}
excluded_suffixes = {'.zip', '.apk', '.aab'}

def should_skip(path: Path) -> bool:
    rel = path.relative_to(root)
    parts = rel.parts
    if any(part in excluded_dirs for part in parts):
        return True
    if 'node_modules' in parts:
        # The generated settings.gradle references this Capacitor Android native
        # module directly. Include only that package so the exported ZIP builds
        # with Gradle without requiring an npm install first.
        allowed = parts[:3] == ('node_modules', '@capacitor', 'android')
        if not allowed:
            return True
    if any(part == 'build' for part in parts):
        return True
    if parts[:2] == ('public', 'engine'):
        # Only exclude the root web copy; the built Android asset copy must remain.
        return True
    if path.name in excluded_names or path.suffix.lower() in excluded_suffixes:
        return True
    return False

out.parent.mkdir(parents=True, exist_ok=True)
if out.exists():
    out.unlink()
count = 0
with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or should_skip(path):
            continue
        # Do not recursively add the artifact if callers place it under project root.
        if path.resolve() == out:
            continue
        zf.write(path, path.relative_to(root).as_posix())
        count += 1

# Verify key Gradle files really made it into the archive.
with zipfile.ZipFile(out) as zf:
    names = set(zf.namelist())
    must_include = {
        'android/gradlew',
        'android/gradle/wrapper/gradle-wrapper.jar',
        'android/gradle/wrapper/gradle-wrapper.properties',
        'android/app/src/main/AndroidManifest.xml',
        'node_modules/@capacitor/android/capacitor/build.gradle',
    }
    if not any(x in names for x in ('android/settings.gradle', 'android/settings.gradle.kts')):
        raise SystemExit('Output ZIP verification failed: settings.gradle is missing.')
    if not any(x in names for x in ('android/app/build.gradle', 'android/app/build.gradle.kts')):
        raise SystemExit('Output ZIP verification failed: app build.gradle is missing.')
    absent = must_include - names
    if absent:
        raise SystemExit('Output ZIP verification failed. Missing: ' + ', '.join(sorted(absent)))
    wrapper_bytes = zf.read('android/gradle/wrapper/gradle-wrapper.jar')
    if not wrapper_bytes.startswith(b'PK\x03\x04'):
        raise SystemExit('Output ZIP verification failed: gradle-wrapper.jar is not a valid ZIP/JAR container.')
    try:
        with zipfile.ZipFile(io.BytesIO(wrapper_bytes)) as wrapper_jar:
            if 'org/gradle/wrapper/GradleWrapperMain.class' not in wrapper_jar.namelist():
                raise SystemExit('Output ZIP verification failed: Gradle wrapper main class is missing.')
            if wrapper_jar.testzip():
                raise SystemExit('Output ZIP verification failed: Gradle wrapper JAR CRC check failed.')
    except zipfile.BadZipFile as error:
        raise SystemExit(f'Output ZIP verification failed: Gradle wrapper JAR is corrupt: {error}')
    capacitor_build = zf.read('node_modules/@capacitor/android/capacitor/build.gradle')
    if not capacitor_build.strip():
        raise SystemExit('Output ZIP verification failed: Capacitor Android Gradle module is empty.')
    bad = zf.testzip()
    if bad:
        raise SystemExit(f'Output ZIP failed CRC verification: {bad}')
print(f'Packaged {count} files into {out}')
