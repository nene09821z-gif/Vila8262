# Test report — Cờ Vua ViLa v3.49.5

## Thay đổi chính

- Bỏ thanh bút/phân tích dạng nổi cố định trên bàn cờ.
- Dùng duy nhất một widget công cụ, có thể đặt trong bảng Chuột ảo hoặc trong tab **Phân tích** của menu trận đấu (☰); chuyển vị trí bằng nút mở tương ứng, không tạo bản sao.
- Bố trí công cụ theo hàng có thể xuống dòng, với cuộn nội bộ trên màn hình hẹp.
- Đóng menu phân tích và thu gọn bảng chuột ảo khi mở menu trận đấu để tránh hai bảng tranh chỗ.
- Chế độ di chuyển quân vẫn là chế độ mặc định; đổi công cụ sẽ giải phóng thao tác giữ chuột đang dang dở.
- Phiên bản app: `versionName 3.49.5`, `versionCode 5`.

## Kiểm tra đã chạy trong môi trường hiện tại

- `tests/annotation-toolbar-layout.test.js`, `tests/piece-artwork.test.js`, `tests/v3-49-4-upgrade.test.js`: **16/16 passed**.
- Kiểm tra cú pháp JavaScript bằng `node --check` cho `src/main.js`: đạt.
- Kiểm tra ZIP được thực hiện sau khi đóng gói; SHA-256 có trong tệp `.sha256` kèm theo.

## Chưa xác minh

- `npm ci`/`npm install` và Vite build không hoàn tất trong môi trường hiện tại vì truy cập registry npm gặp lỗi mạng/DNS (`EAI_AGAIN`). Do đó không khẳng định đã hoàn tất build APK Android trong môi trường này.
- Cần chạy workflow **Cờ Vua ViLa Android build** trên GitHub Actions để cài đầy đủ dependency, chạy toàn bộ bộ test và dựng APK. Chỉ coi APK đạt sau khi workflow tạo artifact thành công.
- Chưa có kiểm thử trên thiết bị thật; cần xác nhận thao tác kéo trên Android/OPPO A17k và kích thước bảng menu ở màn hình thực tế.
