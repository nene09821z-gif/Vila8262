# v3.54 (from 3.53)
- Performance: chess.js is wrapped by `src/cached-chess.js`. `history()`, `pgn()` and `isGameOver()/isCheck()/...` are cached per position and invalidated on every mutating call. Before, each board render and each 100 ms clock tick replayed the whole game, so the match (and premoves in particular) got slower with game length.
- Move list is not rebuilt when only the selection / premove queue changed.
- Settings page rewritten: new Account section (display name, link/unlink email, change password, log out). Removed the Stockfish version picker, Skill/Depth/Time/Elo/review-quality controls, bot-style default, Elo presets, community-backend panel and engine info. Stockfish keeps loading silently at start-up; its status chip is only shown when it fails (tap to retry).
- Backend (Cloudflare Durable Object + Node server): `PATCH /api/social/account/password` and `PATCH /api/social/account/email` (both require the current password; password change revokes other devices and returns a fresh token). `/auth/me`, login, register and `/profile` return the player's own `email`; other players never see it.
- Email is linked as a login identifier only; there is no verification mail or mail-based recovery (needs an email provider such as Resend configured on the server).
- Tests: tests/v3-54-account-settings.test.js; older tests updated for the removed controls.
