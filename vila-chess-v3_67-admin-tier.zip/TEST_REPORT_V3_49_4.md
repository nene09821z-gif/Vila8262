# QA report — Cờ Vua ViLa v3.49.4

Date: 2026-10-22

## Changes included

- Board interaction: drag movement is rendered through `requestAnimationFrame`; mouse drag intent uses a 2 px threshold and touch uses 3 px. Legal moves are generated only after a drag crosses its threshold.
- Analysis palette: explicit normal-move mode, straight arrow, freehand pencil, knight-L route, circle/mark tools, and per-color marks. Switching tools releases an active virtual-mouse hold.
- Virtual mouse: touchpad tap/hold/drag continues to use the board's Pointer Events path, with separate status copy for moving a cursor, drawing, and releasing a held drag.
- Review screen: tighter spacing for the evaluation graph, move review and replay actions.
- Mini-games: offline coordinate-recognition trainer with scoring, current streak and a stored best streak.
- Branding/version: add an offline-local SVG VILA Chess avatar; precache it in the service worker; update release metadata to 3.49.4 and Android `versionName`/`versionCode` to 3.49.4/4.
- Engine: keep the bundled Stockfish 19 NNUE Lite, ASM-JS fallback and Stockfish 10 assets. GitHub Actions requests Stockfish 19 Full NNUE and checks for both its JavaScript/WASM assets before APK packaging.

## Checks run

- Syntax checks: `node --check src/main.js`, `node --check public/sw.js`, `node --check scripts/copy-engine.mjs` — pass.
- Focused regression suite for annotation toolbar, virtual mouse, review, mini-games, mobile performance, engine profile, release metadata, board input and related regressions — **80/80 pass**.
- Arena search-policy, release/cache, Android setup flow and new v3.49.4 regression tests — **18/18 pass**.
- Full `node --test` run — **312/318 pass**. Six test files fail to load `chess.js` because the local install is incomplete; npm package fetching previously failed with `EAI_AGAIN` from `registry.npmjs.org`. The code tests that can run without that package pass. The full result is not a fully green run.
- ZIP output validation checks are performed at packaging time: required source/engine files, CRC integrity, and exclusion of `node_modules`.

## Not verified in this environment

- `npm install` could not fetch/complete dependencies because the registry was unreachable (`EAI_AGAIN`); therefore Vite/Capacitor/Gradle build and complete dependency-backed test execution could not be completed here.
- No Android device/WebView session was available. Drag latency, virtual mouse interaction on OPPO A17k, engine startup and the finished APK remain to be verified on-device or in GitHub Actions.
- Stockfish 19 Full NNUE is fetched/copied by the GitHub Actions workflow when it runs with `INCLUDE_STOCKFISH_FULL=1`; the source ZIP itself does not include the 94 MB Full binary. Do not treat this as a successful APK build or physical-device test.
