# Báo cáo kiểm thử — Elo 500, bot VILA, Đấu trường AI

## Đã kiểm tra (chạy được trong môi trường này)
- Toàn bộ bộ test: 295/301 đạt; 6 mục còn lại là test cần `chess.js`/`express` (không cài được vì không có mạng): alternate-engine, chess, premove, social, v3-25-features, v3-48-features.
- Test mới: `elo-500-bot` (ép Elo 500, dự phòng yếu, hồi quy dispatch), `arena-tournament` (lịch đấu, đổi màu, khai cuộc ghép cặp, loại trực tiếp, bảng xếp hạng, Elo tương đối, xử ván), `virtual-mouse-touchpad`.
- `node --check` toàn bộ src/scripts/tests đạt.

## Chưa xác minh
- Không chạy được engine (thiếu chess.js/Stockfish trong môi trường), nên **chưa đo được độ mạnh thật** của bot VILA sau khi nâng; chưa chạy giải đấu thật hay build Vite/APK.
- Thời gian mỗi ván trên điện thoại sẽ lâu hơn do ngân sách tìm kiếm lớn hơn; cần thử trên máy thật.
