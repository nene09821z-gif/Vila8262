# ViLa Chess — triển khai ghép trận Internet

## Trải nghiệm người chơi
App được cấu hình sẵn backend `https://bitter-sun-751a.nene09821z.workers.dev`. Người chơi mở ViLa Chess, đăng nhập và chọn **Tìm đối thủ ngẫu nhiên**; không phải nhập URL Worker, API key hay mã phòng.

## Triển khai backend một lần
Thư mục `cloudflare/` là backend Worker dùng Durable Object SQLite. Đưa source dự án lên repository GitHub, giữ nguyên thư mục `cloudflare/` ở cấp gốc. Trong Cloudflare Workers Builds, kết nối repository/branch và đặt root directory là `cloudflare`; deploy command `npm run deploy`. Tên Worker trong `wrangler.toml` là `bitter-sun-751a` và cần khớp địa chỉ backend đã đóng gói trong app.

Tài liệu chính thức: https://developers.cloudflare.com/workers/ci-cd/builds/

## Kiểm tra sau khi triển khai
1. Mở `https://bitter-sun-751a.nene09821z.workers.dev/api/health`; phải trả JSON có `ok: true`.
2. Mở `https://bitter-sun-751a.nene09821z.workers.dev/api/social/health`; phải báo dịch vụ online.
3. Dùng hai tài khoản trên hai thiết bị và hai mạng riêng để thử ghép trận, đồng bộ nước đi, hủy hàng chờ, đầu hàng, hết giờ và Elo.

## Giới hạn hiện tại
Worker chưa được triển khai bởi môi trường tạo ZIP và chưa được xác minh ghép trận qua hai thiết bị thật. Worker cũ đang Active không đồng nghĩa nó đã chứa mã này. Chỉ coi ghép trận Internet hoạt động sau khi deploy thành công và hoàn tất các bài thử trên. Khôi phục mật khẩu email chưa hoạt động cho đến khi cấu hình nhà cung cấp gửi email thật.
