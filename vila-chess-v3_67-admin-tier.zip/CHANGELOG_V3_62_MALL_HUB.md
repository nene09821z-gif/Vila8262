# ViLa Chess v3.62 — Trung tâm VILA (home hub)

- Trang chủ có khu "Trung tâm VILA": 5 tầng (Sảnh thi đấu, Học viện, Cộng đồng, Quầy ưu đãi, Dịch vụ) gom 22 gian hàng dẫn tới mọi màn hình có sẵn.
- Dải ưu đãi: Gói Pro/Premium, ví xu + cửa hàng giao diện, nhiệm vụ hằng ngày.
- Chỉ thêm `renderHomeMall()` và CSS cuối `vila-professional-theme.css` (bundle `vila-professional.css` đã tái tạo). Không đổi logic cờ, engine, tài khoản, thanh toán.
- Chưa kiểm tra trên thiết bị/Chromium; xem phần kiểm thử trong phản hồi.

- Icon: thay emoji bằng bộ SVG khối 3D (src/ui-icons.js + CSS "Icon 3D") ở khu Trung tâm, thanh chế độ nhanh và thẻ chế độ trang chủ.

## Cửa hàng xu mới + icon 3D toàn app
- Bỏ bán màu bàn cờ trong cửa hàng; các màu bàn cờ giờ miễn phí, chọn ở Cài đặt.
- Cửa hàng bán bằng xu: lượt phân tích (x1, x3, x10), Dùng thử Pro 1 giờ (cộng dồn tối đa 24 giờ), thêm câu đố (x5, x20), Bảo vệ chuỗi ngày, Nhân đôi xu.
- Logic nằm ở `src/daily-progress.js` (`purchaseShopItem`, `spendReviewCredit`, `spendPuzzleCredit`, `proTrialActive`); khớp với `requestReviewAccess` và hạn mức câu đố trong `src/main.js`. Vật phẩm lưu trên máy, không cho lợi thế khi đấu.
- Icon: `src/ui-icons.js` có ~75 icon SVG; thanh menu, nhiệm vụ, thành tựu dùng icon 3D trực tiếp, còn emoji/ký hiệu thô trong chữ được thay tự động (quân cờ, mũi tên, avatar, tin nhắn giữ nguyên).
- Test mới: `tests/ui-icons-shop.test.js`; `tests/daily-progress.test.js` viết lại phần cửa hàng.
