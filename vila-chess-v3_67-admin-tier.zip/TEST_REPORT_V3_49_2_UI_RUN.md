# Test report — chạy giao diện thật (Chromium 390×844, Stockfish wasm thật)

## Lỗi tìm thấy khi chạy UI và đã sửa
1. `drawArenaSides is not defined` → nút **Đấu trận** hỏng. Đã thêm hàm.
2. `LOCAL_GAME_RECOVERY_KEY` chưa khai báo → khôi phục ván không bao giờ hoạt động (lỗi bị try/catch nuốt). Đã khai báo.
3. Thanh đầu ván: 4 nút trên lưới 3 cột → nút Menu đè lên avatar đối thủ. Đã sửa lưới.

## Cải thiện giao diện
- Đấu trường: gọn phần giới thiệu, nút “Chọn bot & tùy chỉnh”, Tạm dừng/Dừng cùng hàng, chữ nút 12,5px, xóa ghi chú cũ khi hết ván, hộp kết quả không lặp.
- Câu đố: giới thiệu 1 dòng + mục “Cách hoạt động”.

## Đã xác minh bằng trình duyệt
- 18/18 màn hình tải không lỗi JS, không tràn ngang (trừ 2px ở màn Chơi khi đang thiết lập).
- Ván vs Stockfish: đi e4 bằng cảm ứng, bot đáp c5.
- Trận Đấu trường Stockfish 19 vs Tactical chạy hết 80 nửa nước, hiện kết quả.
- Câu đố ngoại tuyến tạo thế “Chiếu hết trong 1”, Gợi ý tô sáng ô.

## Test tự động
- 342/343 đạt. `social.test.js` cần `express` (môi trường làm việc không có mạng để cài).
- Dùng bản thay thế `chess.js` (đã qua perft 8902 / 97862 / 43238) chỉ trong môi trường test; không nằm trong gói.

## Chưa xác minh
- Build Vite/APK thật, chạy trên OPPO A17k, kho khai cuộc ≥ 3.000 dòng (cần bước prepare-openings có mạng), YouTube/Lichess/backend online.
