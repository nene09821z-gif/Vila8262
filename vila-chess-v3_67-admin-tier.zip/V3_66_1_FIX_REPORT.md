# VILA Chess v3.66.1 — Test-failure fixes

## Fixes
- Updated the board-motion regression to check the canonical consolidated stylesheet entrypoint (`vila-professional.css`), which contains the board-motion rules.
- Updated the entitlement normalization expectation to include `premiumExpiresAt`, required for timed Premium trials.
- Added the explicit unlimited-puzzle perk to Pro and Premium plan catalog entries.
- Updated the puzzle-source release-audit expectation to the current v3.66.0 documentation heading.

## Verification
- Focused regression set: 26 passed, 0 failed, 3 skipped (the skipped tests require `chess.js`, which is not installed in this environment).
- Full `npm test` against the packaged source before these fixes: 454 tests, 435 passed, 16 failed, 3 skipped. Of the 16 failures, 12 were blocked by missing installed dependencies (`express` / `chess.js`); the remaining 4 were the regression/documentation/catalog mismatches listed above and have now been corrected.
- Full suite was not rerun successfully because `node_modules` is absent and dependency registry access is unavailable in this environment. Run `npm install` then `npm test` in Termux or CI to verify dependency-backed tests.
