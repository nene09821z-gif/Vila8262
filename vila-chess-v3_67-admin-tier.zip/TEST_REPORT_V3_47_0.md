# ViLa Chess Pro v3.47.0 — báo cáo thay đổi

## Đã cập nhật
- Thêm mốc 1 ngày và 2 ngày vào nhóm đồng hồ trực tuyến; các mốc này không nằm trong danh sách đồng hồ chơi cục bộ.
- Thêm phân loại `daily` cho hàng đợi đấu trực tuyến và xếp hạng riêng cho cờ ngày.
- Thêm chế độ luyện người mới sử dụng Stockfish với Skill Level thấp (mục tiêu cấu hình 500, không phải Elo đã benchmark).
- Làm sáng giao diện câu đố/xem lại; tăng độ ưu tiên tương tác chạm cho nút Đấu trường AI.
- Cập nhật phiên bản/cache lên v3.47.0 và đồng bộ CSS giao diện sáng vào stylesheet Android có sẵn.
- Giữ lại Stockfish 19 Lite WASM và Stockfish 10 ASM.js đã có trong dự án.

## Kiểm thử
- `node --check src/main.js`, `node --check src/clock.js`, `node --check server/social.js`: đạt.
- Nhóm test mục tiêu: 65/65 đạt. Bộ `npm run test:static`: 266/266 đạt.
- Chưa thể build Vite/Gradle hoặc chạy toàn bộ integration test trong môi trường này vì `node_modules` không có và môi trường không có mạng.

## Giới hạn cần biết
- Gói hiện có Stockfish 19 Lite WASM; `public/engine/engine-manifest.json` xác nhận bản Full NNUE chưa được đóng gói. Không đổi nhãn Lite thành Full.
- Gói Android có JS build sẵn từ bản trước; stylesheet đã được cập nhật nhưng JavaScript Android cần được build lại bằng Vite để nhận các thay đổi JS. Vì thế bản ZIP là mã nguồn nâng cấp, không phải APK đã build/test trên thiết bị.
- Đấu cờ ngày cần backend được triển khai bản mới và ít nhất một người chơi khác cùng chọn 1d/2d.
