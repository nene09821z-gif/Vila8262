const UCI_MOVE_PATTERN = /^[a-h][1-8][a-h][1-8][qrbn]?$/;

const LICHESS_PUZZLE_DIFFICULTIES = ['easiest', 'easier', 'normal', 'harder', 'hardest'];

/** Gradually step through Lichess difficulty buckets as the player solves more puzzles. */
export function lichessDifficultyForProgress(solvedCount) {
  const solved = Math.max(0, Math.floor(Number(solvedCount) || 0));
  return LICHESS_PUZZLE_DIFFICULTIES[Math.min(LICHESS_PUZZLE_DIFFICULTIES.length - 1, Math.floor(solved / 5))];
}

/** Official public API endpoints; no credentials are embedded in the app. */
export function lichessPuzzleUrlForDifficulty(difficulty = 'normal') {
  const safeDifficulty = LICHESS_PUZZLE_DIFFICULTIES.includes(String(difficulty)) ? String(difficulty) : 'normal';
  return `https://lichess.org/api/puzzle/next?difficulty=${encodeURIComponent(safeDifficulty)}`;
}

export function lichessDailyPuzzleUrl() {
  return 'https://lichess.org/api/puzzle/daily';
}

/** Validate the public Lichess puzzle-of-the-day response without trusting remote text. */
export function normalizeLichessPuzzlePayload(payload) {
  const puzzle = payload?.puzzle;
  const game = payload?.game;
  if (!puzzle || !game || typeof game.pgn !== 'string' || game.pgn.length < 10 || game.pgn.length > 250_000) {
    throw new Error('Phản hồi Lichess thiếu PGN hợp lệ.');
  }
  const rawMoves = puzzle.solution?.moves;
  if (!Array.isArray(rawMoves) || rawMoves.length < 1 || rawMoves.length > 40) {
    throw new Error('Lichess không trả về dòng lời giải hợp lệ.');
  }
  const moves = rawMoves.map(move => String(move).trim().toLowerCase());
  if (moves.some(move => !UCI_MOVE_PATTERN.test(move))) throw new Error('Dòng lời giải Lichess chứa nước đi không hợp lệ.');
  const initialPly = Number(puzzle.initialPly);
  if (!Number.isInteger(initialPly) || initialPly < 0 || initialPly > 500) throw new Error('Số nửa nước của câu đố không hợp lệ.');
  const id = String(puzzle.id || '').trim();
  if (!/^[a-zA-Z0-9_-]{3,32}$/.test(id)) throw new Error('Mã câu đố Lichess không hợp lệ.');
  return {
    id,
    rating: Number.isFinite(Number(puzzle.rating)) ? Math.max(0, Number(puzzle.rating)) : null,
    plays: Number.isFinite(Number(puzzle.plays)) ? Math.max(0, Number(puzzle.plays)) : 0,
    themes: Array.isArray(puzzle.themes) ? puzzle.themes.map(theme => String(theme).slice(0, 48)).slice(0, 12) : [],
    initialPly,
    moves,
    pgn: game.pgn,
    gameId: String(game.id || '').trim(),
    url: `https://lichess.org/training/${encodeURIComponent(id)}`,
  };
}

export function uciToMove(uci) {
  const value = String(uci || '').trim().toLowerCase();
  if (!UCI_MOVE_PATTERN.test(value)) throw new Error('Mã nước đi UCI không hợp lệ.');
  return { from: value.slice(0, 2), to: value.slice(2, 4), ...(value[4] ? { promotion: value[4] } : {}) };
}

export function puzzlePlyCandidates(initialPly, totalPlies) {
  const start = Number(initialPly);
  const total = Number(totalPlies);
  if (!Number.isInteger(start) || !Number.isInteger(total) || total < 0) return [];
  return [...new Set([start, start - 1, start + 1, start - 2, start + 2])]
    .filter(ply => ply >= 0 && ply <= total);
}

/** Build and verify a full line from the PGN using the app's chess.js constructor. */
export function prepareLichessDailyPuzzle(payload, ChessClass) {
  if (typeof ChessClass !== 'function') throw new TypeError('Thiếu bộ luật cờ để kiểm tra câu đố.');
  const normalized = normalizeLichessPuzzlePayload(payload);
  const completeGame = new ChessClass();
  completeGame.loadPgn(normalized.pgn);
  const history = completeGame.history();
  const headers = completeGame.getHeaders?.() || {};
  const startFen = typeof headers.FEN === 'string' && headers.FEN.trim() ? headers.FEN.trim() : new ChessClass().fen();

  for (const ply of puzzlePlyCandidates(normalized.initialPly, history.length)) {
    try {
      const board = new ChessClass(startFen);
      for (const san of history.slice(0, ply)) {
        if (!board.move(san)) throw new Error('PGN có nước không hợp lệ trước thế đố.');
      }
      const fen = board.fen();
      const solutionBoard = new ChessClass(fen);
      const sanLine = [];
      let valid = true;
      for (const uci of normalized.moves) {
        const move = solutionBoard.move(uciToMove(uci));
        if (!move) { valid = false; break; }
        sanLine.push(move.san);
      }
      if (!valid) continue;
      return {
        id: normalized.id,
        fen,
        moves: normalized.moves,
        sanLine,
        firstMove: normalized.moves[0],
        rating: normalized.rating,
        plays: normalized.plays,
        themes: normalized.themes,
        initialPly: ply,
        gameUrl: normalized.url,
        source: 'lichess',
      };
    } catch {
      // Try the documented ply index and adjacent indexes to tolerate API/PGN edge cases.
    }
  }
  throw new Error('Không xác minh được thế cờ và dòng lời giải Lichess bằng luật cờ vua.');
}

/** Re-validate a persisted offline cache before using it. */
export function validateCachedPuzzleLine(cached, ChessClass) {
  if (!cached || typeof cached.fen !== 'string' || !Array.isArray(cached.moves) || !cached.moves.length) return false;
  try {
    const board = new ChessClass(cached.fen);
    for (const uci of cached.moves) {
      const move = board.move(uciToMove(uci));
      if (!move) return false;
    }
    return true;
  } catch {
    return false;
  }
}
