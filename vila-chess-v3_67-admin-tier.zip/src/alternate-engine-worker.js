import { analyzeAlternateMove } from './alternate-engine-core.js';

self.addEventListener('message', event => {
  const { id, fen, options } = event.data || {};
  if (!Number.isInteger(id)) return;
  try {
    const result = analyzeAlternateMove(fen, options || {});
    self.postMessage({ id, uci: result?.uci || null, stats: result ? { depth: result.depth, nodes: result.nodes, elapsedMs: result.elapsedMs, nps: result.nps, score: result.score } : null });
  } catch (error) {
    self.postMessage({ id, error: String(error?.message || 'Không thể tính nước đi.') });
  }
});
