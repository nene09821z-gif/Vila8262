// VILA Mini Games: offline-first Rubik sticker model and 2048 logic.
// Rubik turns use facelet coordinates so four quarter-turns and inverse turns are exact.
const FACE_DEFS = {
  U: { normal: [0, 1, 0], color: 'white', coord: (r, c) => [c - 1, 1, r - 1] },
  D: { normal: [0, -1, 0], color: 'yellow', coord: (r, c) => [c - 1, -1, 1 - r] },
  F: { normal: [0, 0, 1], color: 'green', coord: (r, c) => [c - 1, 1 - r, 1] },
  B: { normal: [0, 0, -1], color: 'blue', coord: (r, c) => [1 - c, 1 - r, -1] },
  R: { normal: [1, 0, 0], color: 'red', coord: (r, c) => [1, 1 - r, 1 - c] },
  L: { normal: [-1, 0, 0], color: 'orange', coord: (r, c) => [-1, 1 - r, c - 1] },
};
const FACE_ORDER = ['U', 'D', 'F', 'B', 'R', 'L'];
const sameVector = (a, b) => a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
const cloneStickers = stickers => stickers.map(s => ({ p: [...s.p], n: [...s.n], color: s.color }));

export function createSolvedRubikCube() {
  const stickers = [];
  for (const face of FACE_ORDER) {
    const def = FACE_DEFS[face];
    for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) {
      stickers.push({ p: def.coord(row, col), n: [...def.normal], color: def.color });
    }
  }
  return stickers;
}

function rotateVector(vector, axis, quarterTurns) {
  let result = [...vector];
  const turns = ((quarterTurns % 4) + 4) % 4;
  for (let i = 0; i < turns; i++) {
    const [x, y, z] = result;
    if (axis === 0) result = [x, -z, y];
    else if (axis === 1) result = [z, y, -x];
    else result = [-y, x, z];
  }
  return result;
}

export function parseRubikMove(notation) {
  const value = String(notation || '').trim();
  const match = /^([UDFBRL])(['2]?)$/.exec(value);
  if (!match) throw new Error(`Nước Rubik không hợp lệ: ${value}`);
  return { face: match[1], amount: match[2] === '2' ? 2 : match[2] === "'" ? -1 : 1 };
}

export function applyRubikMove(stickers, notation) {
  const { face, amount } = parseRubikMove(notation);
  const next = cloneStickers(stickers);
  const def = FACE_DEFS[face];
  const axis = def.normal.findIndex(value => value !== 0);
  const sign = def.normal[axis];
  // Clockwise from outside the selected face is a negative turn around its outward normal.
  const quarterTurns = amount === 2 ? 2 : amount * -sign;
  for (const sticker of next) {
    if (sticker.p[axis] !== sign) continue;
    sticker.p = rotateVector(sticker.p, axis, quarterTurns);
    sticker.n = rotateVector(sticker.n, axis, quarterTurns);
  }
  return next;
}

export function invertRubikMove(notation) {
  const { face, amount } = parseRubikMove(notation);
  if (amount === 2) return `${face}2`;
  return amount === 1 ? `${face}'` : face;
}

export function scrambleRubikMoves(count = 25, random = Math.random) {
  const faces = ['U', 'D', 'F', 'B', 'R', 'L'];
  const axes = { U: 'y', D: 'y', F: 'z', B: 'z', R: 'x', L: 'x' };
  const suffixes = ['', "'", '2'];
  const moves = [];
  while (moves.length < Math.max(1, Math.min(80, Number(count) || 25))) {
    const face = faces[Math.floor(random() * faces.length)];
    if (moves.length && axes[moves[moves.length - 1][0]] === axes[face]) continue;
    moves.push(face + suffixes[Math.floor(random() * suffixes.length)]);
  }
  return moves;
}

export function getRubikFaceStickers(stickers, face) {
  const def = FACE_DEFS[face];
  if (!def) throw new Error(`Mặt Rubik không hợp lệ: ${face}`);
  const facelets = [];
  for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) {
    const p = def.coord(row, col);
    const sticker = stickers.find(s => sameVector(s.p, p) && sameVector(s.n, def.normal));
    facelets.push(sticker ? sticker.color : 'black');
  }
  return facelets;
}

export function isRubikSolved(stickers) {
  return FACE_ORDER.every(face => {
    const colors = getRubikFaceStickers(stickers, face);
    return colors.length === 9 && colors.every(color => color === colors[0]);
  });
}

export function create2048Board(random = Math.random) {
  const board = Array(16).fill(0);
  add2048Tile(board, random);
  add2048Tile(board, random);
  return board;
}

export function add2048Tile(board, random = Math.random) {
  const empty = [];
  for (let i = 0; i < board.length; i++) if (!board[i]) empty.push(i);
  if (!empty.length) return board;
  const index = empty[Math.min(empty.length - 1, Math.floor(random() * empty.length))];
  board[index] = random() < 0.9 ? 2 : 4;
  return board;
}

function collapse2048Line(line) {
  const values = line.filter(Boolean);
  const output = [];
  let score = 0;
  for (let i = 0; i < values.length; i++) {
    if (values[i] === values[i + 1]) {
      const merged = values[i] * 2;
      output.push(merged); score += merged; i++;
    } else output.push(values[i]);
  }
  while (output.length < 4) output.push(0);
  return { line: output, score };
}

export function has2048Moves(board) {
  if (board.some(value => value === 0)) return true;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 4; col++) {
    const value = board[row * 4 + col];
    if (col < 3 && value === board[row * 4 + col + 1]) return true;
    if (row < 3 && value === board[(row + 1) * 4 + col]) return true;
  }
  return false;
}

export function move2048(board, direction, random = Math.random) {
  if (!['left', 'right', 'up', 'down'].includes(direction)) throw new Error(`Hướng 2048 không hợp lệ: ${direction}`);
  const next = [...board];
  let score = 0;
  const lines = [];
  for (let index = 0; index < 4; index++) {
    const line = [];
    for (let offset = 0; offset < 4; offset++) {
      let row; let col;
      if (direction === 'left' || direction === 'right') {
        row = index; col = direction === 'left' ? offset : 3 - offset;
      } else {
        row = direction === 'up' ? offset : 3 - offset; col = index;
      }
      line.push(board[row * 4 + col]);
    }
    const collapsed = collapse2048Line(line);
    score += collapsed.score;
    lines.push(collapsed.line);
  }
  for (let index = 0; index < 4; index++) for (let offset = 0; offset < 4; offset++) {
    let row; let col;
    if (direction === 'left' || direction === 'right') {
      row = index; col = direction === 'left' ? offset : 3 - offset;
    } else {
      row = direction === 'up' ? offset : 3 - offset; col = index;
    }
    next[row * 4 + col] = lines[index][offset];
  }
  const changed = next.some((value, index) => value !== board[index]);
  if (changed) add2048Tile(next, random);
  return { board: next, score, changed, won: next.some(value => value >= 2048), over: !has2048Moves(next) };
}

/** Create a solvable 15-puzzle by walking legal moves from the solved state. */
export function createScrambledSlidingPuzzle(count = 100, random = Math.random) {
  let board = Array.from({ length: 16 }, (_, index) => index === 15 ? 0 : index + 1);
  let blank = 15;
  let previousBlank = -1;
  const steps = Math.max(1, Math.min(1000, Math.floor(Number(count) || 100)));
  for (let step = 0; step < steps; step += 1) {
    const row = Math.floor(blank / 4), col = blank % 4;
    const adjacent = [];
    if (row > 0) adjacent.push(blank - 4);
    if (row < 3) adjacent.push(blank + 4);
    if (col > 0) adjacent.push(blank - 1);
    if (col < 3) adjacent.push(blank + 1);
    const preferred = adjacent.filter(index => index !== previousBlank);
    const choices = preferred.length ? preferred : adjacent;
    const rawRandom = Number(random());
    const unitRandom = Number.isFinite(rawRandom) ? Math.max(0, Math.min(.999999999, rawRandom)) : 0;
    const tileIndex = choices[Math.min(choices.length - 1, Math.floor(unitRandom * choices.length))];
    const oldBlank = blank;
    board[blank] = board[tileIndex];
    board[tileIndex] = 0;
    previousBlank = oldBlank;
    blank = tileIndex;
  }
  if (isSlidingPuzzleSolved(board)) {
    const row = Math.floor(blank / 4), col = blank % 4;
    const legal = [];
    if (row > 0) legal.push(blank - 4);
    if (row < 3) legal.push(blank + 4);
    if (col > 0) legal.push(blank - 1);
    if (col < 3) legal.push(blank + 1);
    const tileIndex = legal[0];
    [board[blank], board[tileIndex]] = [board[tileIndex], board[blank]];
  }
  return board;
}

/** Move a tapped tile into the adjacent blank square; invalid taps do nothing. */
export function moveSlidingPuzzleTile(board, tileIndex) {
  if (!Array.isArray(board) || board.length !== 16 || !board.every(value => Number.isInteger(value) && value >= 0 && value <= 15) || new Set(board).size !== 16) {
    throw new Error('Bàn trượt số không hợp lệ.');
  }
  const target = Number(tileIndex);
  const blank = board.indexOf(0);
  if (!Number.isInteger(target) || target < 0 || target >= 16 || target === blank) return { board: [...board], changed: false, solved: isSlidingPuzzleSolved(board) };
  const adjacent = Math.abs(Math.floor(target / 4) - Math.floor(blank / 4)) + Math.abs((target % 4) - (blank % 4)) === 1;
  if (!adjacent) return { board: [...board], changed: false, solved: isSlidingPuzzleSolved(board) };
  const next = [...board];
  [next[blank], next[target]] = [next[target], next[blank]];
  return { board: next, changed: true, solved: isSlidingPuzzleSolved(next) };
}

export function isSlidingPuzzleSolved(board) {
  return Array.isArray(board) && board.length === 16 && board.every((value, index) => value === (index === 15 ? 0 : index + 1));
}
