// Persistent, bounded history for the endless offline puzzle lab.
export const PUZZLE_HISTORY_KEY = 'vila.chess.puzzles.history.v1';
export const PUZZLE_HISTORY_LIMIT = 15000;

export function puzzleHistoryKey(fen) {
  // Ignore halfmove/fullmove counters: the board, side to move and castling/en-passant
  // rights define whether a puzzle position is effectively the same.
  return String(fen || '').trim().split(/\s+/).slice(0, 4).join(' ');
}

export function loadPuzzleHistory(storage = globalThis.localStorage, limit = PUZZLE_HISTORY_LIMIT) {
  try {
    const parsed = JSON.parse(storage?.getItem(PUZZLE_HISTORY_KEY) || '[]');
    if (!Array.isArray(parsed)) return [];
    return [...new Set(parsed.filter(item => typeof item === 'string' && item.trim()).map(puzzleHistoryKey))].slice(-Math.max(1, limit));
  } catch { return []; }
}

export function rememberPuzzle(fen, storage = globalThis.localStorage, limit = PUZZLE_HISTORY_LIMIT) {
  const key = puzzleHistoryKey(fen);
  if (!key) return loadPuzzleHistory(storage, limit);
  const next = loadPuzzleHistory(storage, limit).filter(item => item !== key);
  next.push(key);
  const bounded = next.slice(-Math.max(1, limit));
  try { storage?.setItem(PUZZLE_HISTORY_KEY, JSON.stringify(bounded)); } catch {}
  return bounded;
}
