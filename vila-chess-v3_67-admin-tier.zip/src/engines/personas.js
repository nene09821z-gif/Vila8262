import { PIECE_VALUE, centerValue, kingPosition, materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore, isAttacked } from './evaluation-utils.js';

// Five more independent VILA personalities. They share the same search kernel as the other
// offline engines but weigh the position differently and vary their choices (randomTop > 1).
// Scores are in centipawns from White's point of view, like every other evaluator.

/** Gambit: pays a pawn for development, open lines and pressure near the enemy king. */
export const GAMBIT = Object.freeze({ id: 'gambit', name: 'VILA Gambit', defaultDepth: 5, maxNodes: 45000, maxTimeMs: 1040, multipv: 1, style: 'gambit', lateMoveReduction: true, randomTop: 3 });
export function evaluateGambit(chess) {
  const board = chess.board();
  let score = materialScore(board) * 0.82 + pawnStructureScore(board) * 0.25 + kingSafetyScore(board) * 0.6;
  score += pieceActivityScore(board, { knight: 7, bishop: 7, rook: 2.2, queen: 2.2, pawnAdvance: 3.4 });
  for (const color of ['w', 'b']) {
    const king = kingPosition(board, color); if (!king) continue;
    const sign = color === 'w' ? -1 : 1; // pressure on `color`'s king is good for the other side
    const enemy = color === 'w' ? 'b' : 'w';
    let pressure = 0;
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const p = board[row][col]; if (!p || p.color !== enemy || p.type === 'k' || p.type === 'p') continue;
      if (Math.abs(king.row - row) + Math.abs(king.col - col) <= 4) pressure += p.type === 'q' ? 3 : 2;
    }
    score += sign * Math.min(34, pressure * 3.5);
  }
  return score;
}

/** Hypermodern: controls the centre from the flanks, loves fianchettoed bishops and knights. */
export const HYPERMODERN = Object.freeze({ id: 'hyper', name: 'VILA Hypermodern', defaultDepth: 6, maxNodes: 48000, maxTimeMs: 1100, multipv: 1, style: 'hypermodern', lateMoveReduction: true, randomTop: 2 });
export function evaluateHypermodern(chess) {
  const board = chess.board();
  let score = materialScore(board) + pawnStructureScore(board) * 0.9 + kingSafetyScore(board) * 1.2;
  score += pieceActivityScore(board, { knight: 6, bishop: 6, rook: 1.2, queen: 0.5, pawnAdvance: 1.8 });
  // Bishops on the long diagonals (b2/g2/b7/g7) and knights near, not in, the centre.
  const longDiagonal = { '6,1': 'w', '6,6': 'w', '1,1': 'b', '1,6': 'b' };
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p) continue;
    const sign = p.color === 'w' ? 1 : -1;
    if (p.type === 'b' && longDiagonal[`${row},${col}`] === p.color) score += sign * 18;
    if (p.type === 'n' && centerValue(row, col) >= 3 && centerValue(row, col) < 5.5) score += sign * 6;
  }
  return score;
}

/** Strangler: space and restriction; keeps pieces protected and squeezes enemy mobility. */
export const STRANGLER = Object.freeze({ id: 'strangler', name: 'VILA Strangler', defaultDepth: 6, maxNodes: 51000, maxTimeMs: 1170, multipv: 1, style: 'positional-squeeze', lateMoveReduction: true, randomTop: 1 });
export function evaluateStrangler(chess) {
  const board = chess.board();
  let score = materialScore(board) + pawnStructureScore(board) * 1.35 + kingSafetyScore(board) * 1.2;
  score += pieceActivityScore(board, { knight: 7, bishop: 6, rook: 1.5, queen: 0.4, pawnAdvance: 3.6 });
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type !== 'p') continue;
    // Space: advanced pawns on the centre files restrict the opponent.
    const advance = p.color === 'w' ? 6 - row : row - 1;
    if (col >= 2 && col <= 5 && advance >= 2) score += (p.color === 'w' ? 1 : -1) * advance * 3;
  }
  return score;
}

/** Trickster: sets traps; likes loaded positions and gives the opponent chances to go wrong. */
export const TRICKSTER = Object.freeze({ id: 'trickster', name: 'VILA Trickster', defaultDepth: 5, maxNodes: 39000, maxTimeMs: 980, multipv: 1, style: 'swindler', lateMoveReduction: true, randomTop: 4 });
export function evaluateTrickster(chess) {
  const board = chess.board();
  let score = materialScore(board) + pawnStructureScore(board) * 0.5 + kingSafetyScore(board) * 0.8;
  score += pieceActivityScore(board, { knight: 6, bishop: 5, rook: 1.5, queen: 2.8, pawnAdvance: 2.6 });
  // Reward enemy pieces that are attacked: more ways for the opponent to slip.
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p || p.type === 'k' || p.type === 'p') continue;
    const enemy = p.color === 'w' ? 'b' : 'w';
    if (isAttacked(board, row, col, enemy)) score += (p.color === 'w' ? -1 : 1) * Math.min(14, (PIECE_VALUE[p.type] || 0) / 45);
  }
  return score;
}

/** Rookie: friendly beginner. Shallow, sloppy and varied, for practice and for fun. */
export const ROOKIE = Object.freeze({ id: 'rookie', name: 'VILA Rookie', defaultDepth: 3, maxNodes: 5000, maxTimeMs: 210, multipv: 1, style: 'beginner', lateMoveReduction: false, randomTop: 6, varietyCp: 90 });
export function evaluateRookie(chess) {
  const board = chess.board();
  return materialScore(board) + pieceActivityScore(board, { knight: 3, bishop: 2, rook: 0.5, queen: 0.5, pawnAdvance: 1.2 });
}
