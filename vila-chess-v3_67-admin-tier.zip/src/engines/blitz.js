import { materialScore, pawnStructureScore, kingSafetyScore, pieceActivityScore } from './evaluation-utils.js';

// Very fast, shallow profile for bullet-style games and slow phones. This is a VILA engine.
export const BLITZ = Object.freeze({ id: 'blitz', name: 'VILA Blitz', defaultDepth: 4, maxNodes: 14000, maxTimeMs: 340, multipv: 1, style: 'fast', lateMoveReduction: true, randomTop: 2 });

export function evaluateBlitz(chess) {
  const board = chess.board();
  return materialScore(board) + pawnStructureScore(board) * 0.6 + kingSafetyScore(board) * 0.9 +
    pieceActivityScore(board, { knight: 5, bishop: 4, rook: 1, queen: 0.5, pawnAdvance: 2.4 });
}
