// Position-analysis primitives shared by VILA's independent offline engines.
// Scores are expressed from White's point of view in centipawns.
export const PIECE_VALUE = Object.freeze({ p: 100, n: 325, b: 335, r: 500, q: 950, k: 0 });

export function centerValue(row, col) {
  return 7 - (Math.abs(3.5 - row) + Math.abs(3.5 - col));
}

export function kingPosition(board, color) {
  for (let row = 0; row < 8; row += 1) {
    for (let col = 0; col < 8; col += 1) {
      const piece = board[row][col];
      if (piece?.color === color && piece.type === 'k') return { row, col };
    }
  }
  return null;
}

// Does `byColor` attack a square? This is a board-geometry test, not a move
// legality test; pinned attackers still count for king-safety heuristics.
export function isAttacked(board, targetRow, targetCol, byColor) {
  const pawnSourceRow = targetRow + (byColor === 'w' ? 1 : -1);
  for (const dc of [-1, 1]) {
    const col = targetCol + dc;
    if (pawnSourceRow >= 0 && pawnSourceRow < 8 && col >= 0 && col < 8 &&
        board[pawnSourceRow][col]?.color === byColor && board[pawnSourceRow][col]?.type === 'p') return true;
  }
  for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const row = targetRow + dr; const col = targetCol + dc;
    const p = row >= 0 && row < 8 && col >= 0 && col < 8 ? board[row][col] : null;
    if (p?.color === byColor && p.type === 'n') return true;
  }
  for (const [dr, dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
    let row = targetRow + dr; let col = targetCol + dc; let distance = 1;
    while (row >= 0 && row < 8 && col >= 0 && col < 8) {
      const p = board[row][col];
      if (p) {
        if (p.color === byColor) {
          if (p.type === 'q' || (distance === 1 && p.type === 'k') ||
              (dr === 0 || dc === 0 ? p.type === 'r' : p.type === 'b')) return true;
        }
        break;
      }
      row += dr; col += dc; distance += 1;
    }
  }
  return false;
}

export function countAttackers(board, targetRow, targetCol, byColor) {
  let count = 0;
  const pawnSourceRow = targetRow + (byColor === 'w' ? 1 : -1);
  for (const dc of [-1, 1]) {
    const col = targetCol + dc;
    if (pawnSourceRow >= 0 && pawnSourceRow < 8 && col >= 0 && col < 8 &&
        board[pawnSourceRow][col]?.color === byColor && board[pawnSourceRow][col]?.type === 'p') count += 1;
  }
  for (const [dr, dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) {
    const row = targetRow + dr; const col = targetCol + dc;
    const p = row >= 0 && row < 8 && col >= 0 && col < 8 ? board[row][col] : null;
    if (p?.color === byColor && p.type === 'n') count += 1;
  }
  for (const [dr, dc] of [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]]) {
    let row = targetRow + dr; let col = targetCol + dc; let distance = 1;
    while (row >= 0 && row < 8 && col >= 0 && col < 8) {
      const p = board[row][col];
      if (p) {
        if (p.color === byColor && (p.type === 'q' || (distance === 1 && p.type === 'k') ||
            (dr === 0 || dc === 0 ? p.type === 'r' : p.type === 'b'))) count += 1;
        break;
      }
      row += dr; col += dc; distance += 1;
    }
  }
  return count;
}

export function materialScore(board) {
  let score = 0;
  for (const row of board) for (const piece of row) {
    if (piece) score += (piece.color === 'w' ? 1 : -1) * (PIECE_VALUE[piece.type] || 0);
  }
  return score;
}

export function pawnStructureScore(board) {
  let score = 0;
  for (const color of ['w', 'b']) {
    const sign = color === 'w' ? 1 : -1;
    const pawnsByFile = Array(8).fill(0);
    const pawnSquares = [];
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const p = board[row][col];
      if (p?.color === color && p.type === 'p') {
        pawnsByFile[col] += 1;
        pawnSquares.push({ row, col });
      }
    }
    for (let col = 0; col < 8; col += 1) {
      if (pawnsByFile[col] > 1) score -= sign * 13 * (pawnsByFile[col] - 1); // doubled pawns
      if (pawnsByFile[col] && !(pawnsByFile[col - 1] || 0) && !(pawnsByFile[col + 1] || 0)) score -= sign * 11; // isolated
    }
    for (const pawn of pawnSquares) {
      let passed = true;
      for (let row = 0; row < 8 && passed; row += 1) for (let col = Math.max(0, pawn.col - 1); col <= Math.min(7, pawn.col + 1); col += 1) {
        const enemy = board[row][col];
        if (enemy?.color !== (color === 'w' ? 'b' : 'w') || enemy.type !== 'p') continue;
        if (color === 'w' ? row < pawn.row : row > pawn.row) { passed = false; break; }
      }
      if (passed) score += sign * (8 + (color === 'w' ? 6 - pawn.row : pawn.row - 1) * 7);
    }
  }
  return score;
}

export function kingSafetyScore(board) {
  let score = 0;
  for (const color of ['w', 'b']) {
    const sign = color === 'w' ? 1 : -1;
    const king = kingPosition(board, color);
    if (!king) continue;
    const enemy = color === 'w' ? 'b' : 'w';
    let attackedNeighbors = 0;
    let friendlyShield = 0;
    for (let dr = -1; dr <= 1; dr += 1) for (let dc = -1; dc <= 1; dc += 1) {
      if (!dr && !dc) continue;
      const row = king.row + dr; const col = king.col + dc;
      if (row < 0 || row > 7 || col < 0 || col > 7) continue;
      if (isAttacked(board, row, col, enemy)) attackedNeighbors += 1;
      const p = board[row][col];
      if (p?.color === color && p.type === 'p') friendlyShield += 1;
    }
    score += sign * (friendlyShield * 5 - attackedNeighbors * 11);
  }
  return score;
}

export function pieceActivityScore(board, options = {}) {
  const scoreByPiece = { n: options.knight ?? 5, b: options.bishop ?? 3, r: options.rook ?? 1, q: options.queen ?? 0, p: options.pawn ?? 0, k: options.king ?? -1 };
  let score = 0;
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col];
    if (!p) continue;
    const sign = p.color === 'w' ? 1 : -1;
    const center = centerValue(row, col);
    const advance = p.color === 'w' ? 6 - row : row - 1;
    score += sign * (center * (scoreByPiece[p.type] || 0) + (p.type === 'p' ? advance * (options.pawnAdvance ?? 0) : 0));
  }
  return score;
}


// ---- v3.25: piece-square tables (white's view, row 0 = rank 8), bishop pair, rook files, tempo ----
const PST = {
  p: [[0,0,0,0,0,0,0,0],[50,50,50,50,50,50,50,50],[10,10,20,30,30,20,10,10],[5,5,10,25,25,10,5,5],[0,0,0,20,20,0,0,0],[5,-5,-10,0,0,-10,-5,5],[5,10,10,-20,-20,10,10,5],[0,0,0,0,0,0,0,0]],
  n: [[-50,-40,-30,-30,-30,-30,-40,-50],[-40,-20,0,0,0,0,-20,-40],[-30,0,10,15,15,10,0,-30],[-30,5,15,20,20,15,5,-30],[-30,0,15,20,20,15,0,-30],[-30,5,10,15,15,10,5,-30],[-40,-20,0,5,5,0,-20,-40],[-50,-40,-30,-30,-30,-30,-40,-50]],
  b: [[-20,-10,-10,-10,-10,-10,-10,-20],[-10,0,0,0,0,0,0,-10],[-10,0,5,10,10,5,0,-10],[-10,5,5,10,10,5,5,-10],[-10,0,10,10,10,10,0,-10],[-10,10,10,10,10,10,10,-10],[-10,5,0,0,0,0,5,-10],[-20,-10,-10,-10,-10,-10,-10,-20]],
  r: [[0,0,0,0,0,0,0,0],[5,10,10,10,10,10,10,5],[-5,0,0,0,0,0,0,-5],[-5,0,0,0,0,0,0,-5],[-5,0,0,0,0,0,0,-5],[-5,0,0,0,0,0,0,-5],[-5,0,0,0,0,0,0,-5],[0,0,0,5,5,0,0,0]],
  q: [[-20,-10,-10,-5,-5,-10,-10,-20],[-10,0,0,0,0,0,0,-10],[-10,0,5,5,5,5,0,-10],[-5,0,5,5,5,5,0,-5],[0,0,5,5,5,5,0,-5],[-10,5,5,5,5,5,0,-10],[-10,0,5,0,0,0,0,-10],[-20,-10,-10,-5,-5,-10,-10,-20]],
  k: [[-30,-40,-40,-50,-50,-40,-40,-30],[-30,-40,-40,-50,-50,-40,-40,-30],[-30,-40,-40,-50,-50,-40,-40,-30],[-30,-40,-40,-50,-50,-40,-40,-30],[-20,-30,-30,-40,-40,-30,-30,-20],[-10,-20,-20,-20,-20,-20,-20,-10],[20,20,0,0,0,0,20,20],[20,30,10,0,0,10,30,20]]
};
const KING_END = [[-50,-40,-30,-20,-20,-30,-40,-50],[-30,-20,-10,0,0,-10,-20,-30],[-30,-10,20,30,30,20,-10,-30],[-30,-10,30,40,40,30,-10,-30],[-30,-10,30,40,40,30,-10,-30],[-30,-10,20,30,30,20,-10,-30],[-30,-30,0,0,0,0,-30,-30],[-50,-30,-30,-30,-30,-30,-30,-50]];

/** Tapered positional score (centipawns, White's view). `weight` scales the whole term per persona. */
export function positionalScore(board, weight = 1) {
  let score = 0; let nonPawn = 0;
  const bishops = { w: 0, b: 0 };
  const pawnFiles = { w: Array(8).fill(0), b: Array(8).fill(0) };
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p) continue;
    if (p.type === 'p') pawnFiles[p.color][col] += 1;
    else if (p.type !== 'k') nonPawn += PIECE_VALUE[p.type] || 0;
    if (p.type === 'b') bishops[p.color] += 1;
  }
  const endgame = nonPawn <= 2600; // both sides combined, roughly ≤ queen+2 rooks+minor
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const p = board[row][col]; if (!p) continue;
    const sign = p.color === 'w' ? 1 : -1;
    const r = p.color === 'w' ? row : 7 - row;
    const table = p.type === 'k' && endgame ? KING_END : PST[p.type];
    score += sign * table[r][col];
    if (p.type === 'r') {
      const own = pawnFiles[p.color][col]; const opp = pawnFiles[p.color === 'w' ? 'b' : 'w'][col];
      if (!own && !opp) score += sign * 14; else if (!own) score += sign * 7;
    }
  }
  // Mating technique: with a clear material lead in an ending, drive the enemy king to the edge
  // and bring our king closer (lets the engine convert KQ/KR vs K instead of shuffling).
  if (endgame) {
    let mat = 0; let wk = null; let bk = null;
    for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
      const p = board[row][col]; if (!p) continue;
      if (p.type === 'k') { if (p.color === 'w') wk = { row, col }; else bk = { row, col }; }
      else mat += (p.color === 'w' ? 1 : -1) * (PIECE_VALUE[p.type] || 0);
    }
    if (wk && bk && Math.abs(mat) >= 300) {
      const lead = mat > 0 ? 1 : -1; const loser = lead > 0 ? bk : wk; const winner = lead > 0 ? wk : bk;
      const edge = Math.abs(3.5 - loser.row) + Math.abs(3.5 - loser.col);
      const dist = Math.abs(loser.row - winner.row) + Math.abs(loser.col - winner.col);
      score += lead * (edge * 14 + (14 - dist) * 5);
    }
  }
  if (bishops.w >= 2) score += 28;
  if (bishops.b >= 2) score -= 28;
  return score * weight;
}
