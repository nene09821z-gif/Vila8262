const SUPPORTED_MODES = new Set(['local', 'stockfish', 'vila', 'enginehub']);
const MAX_RECOVERY_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_RECOVERY_PLIES = 1000;
const SQUARE_RE = /^[a-h][1-8]$/;

function checksumPayload(snapshot) {
  const payload = { ...snapshot };
  delete payload.checksum;
  const text = JSON.stringify(payload);
  let hash = 0x811c9dc5;
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/** Seal a recovery record so truncated/tampered localStorage records fail closed. */
export function sealLocalGameRecoverySnapshot(snapshot) {
  const sealed = { ...snapshot, version: 3 };
  delete sealed.checksum;
  sealed.checksum = checksumPayload(sealed);
  return sealed;
}

/** Validate the snapshot envelope before prompting or replaying any moves. */
export function validateLocalGameRecoverySnapshot(snapshot, now = Date.now()) {
  const fail = reason => ({ ok: false, reason });
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) return fail('invalid-record');
  if (![2, 3].includes(snapshot.version)) return fail('unsupported-version');
  if (snapshot.version === 3) {
    if (typeof snapshot.checksum !== 'string' || !/^[a-f0-9]{8}$/.test(snapshot.checksum)) return fail('missing-checksum');
    if (checksumPayload(snapshot) !== snapshot.checksum) return fail('checksum-mismatch');
  }
  if (snapshot.gameStarted !== true || snapshot.result) return fail('game-not-active');
  if (!SUPPORTED_MODES.has(snapshot.mode)) return fail('unsupported-mode');
  if (!Number.isFinite(Number(snapshot.savedAt))) return fail('invalid-timestamp');
  const savedAt = Number(snapshot.savedAt);
  if (savedAt > now + 60_000) return fail('timestamp-in-future');
  if (now - savedAt > MAX_RECOVERY_AGE_MS) return fail('snapshot-expired');
  if (typeof snapshot.startFen !== 'string' || snapshot.startFen.length > 160 || typeof snapshot.fen !== 'string' || snapshot.fen.length > 160) return fail('invalid-fen');
  if (!Array.isArray(snapshot.moves) || snapshot.moves.length > MAX_RECOVERY_PLIES) return fail('invalid-move-list');
  for (const move of snapshot.moves) {
    if (!move || !SQUARE_RE.test(move.from || '') || !SQUARE_RE.test(move.to || '') ||
        (move.promotion != null && !/^[qrbn]$/.test(move.promotion))) return fail('invalid-move');
  }
  if (snapshot.clockHistory != null && (!Array.isArray(snapshot.clockHistory) || snapshot.clockHistory.length > MAX_RECOVERY_PLIES)) return fail('invalid-clock-history');
  if (snapshot.clockState != null) {
    const clock = snapshot.clockState;
    if (typeof clock !== 'object' || (clock.remaining != null && typeof clock.remaining !== 'object')) return fail('invalid-clock-state');
    for (const color of ['w', 'b']) {
      const remaining = Number(clock.remaining?.[color] ?? 0);
      if (!Number.isFinite(remaining) || remaining < 0 || remaining > 24 * 60 * 60 * 1000) return fail('invalid-clock-time');
    }
    const increment = Number(clock.incrementMs ?? 0);
    if (!Number.isFinite(increment) || increment < 0 || increment > 60_000) return fail('invalid-clock-increment');
  }
  if (!['w', 'b'].includes(snapshot.orientation) || !['w', 'b'].includes(snapshot.humanColor)) return fail('invalid-player-orientation');
  return { ok: true, legacy: snapshot.version === 2 };
}
