/**
 * Chess.com-inspired UX helpers for Cờ Vua.
 * Pure functions only — safe for Node tests and browser.
 */

import { winChance, MOVE_QUALITY_LABELS, computeWinPercentAccuracy } from './game-review.js';

/* ---------- 3. Post-game accuracy (Chess.com-style expected points) ---------- */

/**
 * Map a judgement key to expected-points weight (0–1) used for accuracy %.
 * Matches the spirit of Chess.com / Lichess game review scoring.
 */
export const JUDGEMENT_ACCURACY_WEIGHT = Object.freeze({
  brilliant: 1,
  great: 1,
  best: 1,
  excellent: 0.95,
  good: 0.85,
  book: 1,
  inaccuracy: 0.6,
  mistake: 0.3,
  'missed-win': 0.2,
  blunder: 0,
  unrated: null
});

/**
 * Compute side accuracy from review rows.
 * @param {Array<{ color?: string, judgement?: { key?: string } }>} rows
 * @returns {{ white: number|null, black: number|null, combined: number|null, counts: object }}
 */
export function computeGameAccuracy(rows = []) {
  const buckets = { w: [], b: [] };
  const counts = Object.create(null);
  for (const row of rows) {
    const key = row?.judgement?.key || 'unrated';
    counts[key] = (counts[key] || 0) + 1;
    const weight = JUDGEMENT_ACCURACY_WEIGHT[key];
    if (weight == null) continue;
    // Review rows carry `mover` ('w'/'b'); older callers pass `color`. Reading only `color` made every accuracy card show "—".
    const side = row.color || row.mover;
    const color = side === 'b' ? 'b' : side === 'w' ? 'w' : null;
    if (!color) continue;
    buckets[color].push(weight);
  }
  const avg = list => (list.length ? Math.round((list.reduce((a, b) => a + b, 0) / list.length) * 100) : null);
  const white = avg(buckets.w);
  const black = avg(buckets.b);
  const all = [...buckets.w, ...buckets.b];
  const combined = avg(all);
  return { white, black, combined, counts };
}

/**
 * Build a compact review summary for the post-game dashboard.
 */
export function buildReviewDashboard(rows = [], meta = {}) {
  const labelAccuracy = computeGameAccuracy(rows);
  // Prefer the win-percent model whenever the rows carry engine scores; fall back to label weights otherwise.
  const precise = computeWinPercentAccuracy(rows);
  const accuracy = precise.white != null || precise.black != null
    ? { ...labelAccuracy, white: precise.white, black: precise.black, combined: precise.combined, method: 'win-percent' }
    : { ...labelAccuracy, method: 'label-weights' };
  const classified = rows.filter(r => r?.judgement?.key && r.judgement.key !== 'unrated');
  const brilliant = classified.filter(r => r.judgement.key === 'brilliant').length;
  const blunders = classified.filter(r => r.judgement.key === 'blunder').length;
  const mistakes = classified.filter(r => r.judgement.key === 'mistake').length;
  const book = classified.filter(r => r.judgement.key === 'book').length;
  return {
    accuracy,
    moveCount: classified.length,
    brilliant,
    blunders,
    mistakes,
    book,
    title: meta.title || 'Phân tích ván đấu',
    opening: meta.opening || null,
    result: meta.result || null
  };
}

/* ---------- 4. Bot Elo presets + think delay ---------- */

export const BOT_ELO_PRESETS = Object.freeze([
  { id: 'beginner', label: 'Người mới', elo: 400, skill: 0, thinkMs: [400, 900], hint: 'Chơi chậm, hay sai' },
  { id: 'casual', label: 'Nghiệp dư', elo: 800, skill: 3, thinkMs: [350, 800], hint: 'Phù hợp học khai cuộc' },
  { id: 'club', label: 'Câu lạc bộ', elo: 1200, skill: 8, thinkMs: [300, 700], hint: 'Áp lực nhẹ' },
  { id: 'strong', label: 'Cao cấp', elo: 1600, skill: 12, thinkMs: [250, 650], hint: 'Ít blunder' },
  { id: 'expert', label: 'Chuyên gia', elo: 2000, skill: 16, thinkMs: [200, 550], hint: 'Rất mạnh' },
  { id: 'master', label: 'Kiện tướng', elo: 2400, skill: 19, thinkMs: [150, 450], hint: 'Gần tối đa' },
  { id: 'max', label: 'Tối đa', elo: 2800, skill: 20, thinkMs: [80, 280], hint: 'Stockfish gần full' }
]);

export function resolveBotEloPreset(idOrElo) {
  if (typeof idOrElo === 'string') {
    const byId = BOT_ELO_PRESETS.find(p => p.id === idOrElo);
    if (byId) return byId;
  }
  const elo = Number(idOrElo);
  if (!Number.isFinite(elo)) return BOT_ELO_PRESETS[2];
  let best = BOT_ELO_PRESETS[0];
  let bestDist = Infinity;
  for (const p of BOT_ELO_PRESETS) {
    const d = Math.abs(p.elo - elo);
    if (d < bestDist) { best = p; bestDist = d; }
  }
  return best;
}

/** Human-like delay before the bot replies (ms). */
export function botThinkDelayMs(presetOrElo, random = Math.random) {
  const preset = typeof presetOrElo === 'object' && presetOrElo?.thinkMs
    ? presetOrElo
    : resolveBotEloPreset(presetOrElo);
  const [lo, hi] = preset.thinkMs || [200, 600];
  const t = lo + (hi - lo) * (typeof random === 'function' ? random() : 0.5);
  return Math.round(t);
}

/* ---------- 2. Match action bar (draw / resign / menu) ---------- */

export function matchActionBarEnabled(state = {}) {
  const { gameStarted, gameOver, clockFlagged, manualResult } = state;
  return Boolean(gameStarted) && !gameOver && !clockFlagged && !manualResult;
}

export function matchActionBarMarkup(state = {}) {
  const enabled = matchActionBarEnabled(state);
  const disabled = enabled ? '' : 'disabled';
  return `<nav class="match-action-bar" aria-label="Hành động ván đấu">
  <button type="button" class="match-action-btn" id="offerDrawBtn" ${disabled} title="Xin hòa"><span aria-hidden="true">½</span><small>Xin hòa</small></button>
  <button type="button" class="match-action-btn match-action-danger" id="resignBtn" ${disabled} title="Đầu hàng"><span aria-hidden="true">⚑</span><small>Đầu hàng</small></button>
  <button type="button" class="match-action-btn" id="matchMenuBtn" title="Menu ván"><span aria-hidden="true">☰</span><small>Menu</small></button>
  <button type="button" class="match-action-btn" id="cancelPremoveBtn" title="Hủy premove"><span aria-hidden="true">✕</span><small>Hủy PM</small></button>
</nav>`;
}

/* ---------- 5. Puzzle streak / daily helpers ---------- */

export function puzzleStreakLabel(streak = 0, best = 0) {
  const s = Math.max(0, Number(streak) || 0);
  const b = Math.max(0, Number(best) || 0);
  if (s <= 0) return b > 0 ? `Streak 0 · kỷ lục ${b}` : 'Bắt đầu chuỗi thắng';
  return s >= b && s > 0 ? `🔥 Streak ${s} · kỷ lục mới` : `🔥 Streak ${s} · kỷ lục ${b}`;
}

export function puzzleNextButtonLabel(playMode = 'practice') {
  if (playMode === 'daily') return 'Luyện lại đề hôm nay';
  if (playMode === 'rush') return 'Puzzle tiếp · Rush';
  return 'Puzzle tiếp theo';
}

/* ---------- 6. Board / sound theme catalog ---------- */

export const BOARD_THEME_CATALOG = Object.freeze([
  { id: 'classic-green', label: 'Xanh cổ điển', light: '#eed7b0', dark: '#b58863' },
  { id: 'ice', label: 'Băng giá', light: '#dce6f2', dark: '#6b8caf' },
  { id: 'tournament', label: 'Giải đấu', light: '#f0d9b5', dark: '#b58863' },
  { id: 'midnight', label: 'Nửa đêm', light: '#4a5568', dark: '#1a202c' },
  { id: 'coral', label: 'San hô', light: '#f7cac9', dark: '#c06c84' },
  { id: 'forest', label: 'Rừng', light: '#e8f0d8', dark: '#769656' },
  { id: 'slate', label: 'Đá phiến', light: '#c5cdd8', dark: '#5c6b7a' },
  { id: 'sunset', label: 'Hoàng hôn', light: '#f5e0c3', dark: '#c07850' }
]);

export const SOUND_THEME_CATALOG = Object.freeze([
  { id: 'soft', label: 'Êm · mặc định' },
  { id: 'wood', label: 'Gỗ · click rõ' },
  { id: 'neon', label: 'Neon · hiện đại' },
  { id: 'mute', label: 'Tắt tiếng' }
]);

export function resolveBoardTheme(id) {
  return BOARD_THEME_CATALOG.find(t => t.id === id) || BOARD_THEME_CATALOG[0];
}

export function resolveSoundTheme(id) {
  return SOUND_THEME_CATALOG.find(t => t.id === id) || SOUND_THEME_CATALOG[0];
}

/* ---------- 7. Ranked / matchmaking copy ---------- */

export function matchmakingStatusText(state = {}) {
  const { searching = false, elo = null, queueSeconds = 0, mode = 'ranked' } = state;
  if (!searching) {
    return elo != null
      ? `Sẵn sàng · Elo ${Math.round(elo)} · chọn đồng hồ rồi tìm đối thủ`
      : 'Sẵn sàng xếp hạng · chọn đồng hồ rồi bắt đầu';
  }
  const wait = Math.max(0, Math.round(queueSeconds));
  return `Đang tìm đối thủ${elo != null ? ` · Elo ${Math.round(elo)}` : ''} · ${wait}s${mode === 'friendly' ? ' · phòng bạn bè' : ''}`;
}

/* ---------- 8. Opening explorer ---------- */

/**
 * Rank continuations from a SAN-prefix map or opening list.
 * @param {string[]} historySan moves played so far
 * @param {Array<{ san?: string[], name?: string, eco?: string }>} openings
 * @param {number} limit
 */
export function openingExplorerContinuations(historySan = [], openings = [], limit = 6) {
  const prefix = (Array.isArray(historySan) ? historySan : []).map(s => String(s).trim()).filter(Boolean);
  const prefixKey = prefix.join(' ');
  const nextCounts = new Map();
  let named = null;
  for (const opening of openings) {
    const line = Array.isArray(opening?.san) ? opening.san.map(s => String(s).trim()) : [];
    if (line.length < prefix.length) continue;
    let match = true;
    for (let i = 0; i < prefix.length; i++) {
      if (line[i] !== prefix[i]) { match = false; break; }
    }
    if (!match) continue;
    if (line.length === prefix.length) {
      named = { name: opening.name || opening.eco || 'Khai cuộc', eco: opening.eco || null };
      continue;
    }
    const next = line[prefix.length];
    if (!next) continue;
    const entry = nextCounts.get(next) || { san: next, count: 0, sampleName: opening.name || null };
    entry.count += 1;
    if (!entry.sampleName && opening.name) entry.sampleName = opening.name;
    nextCounts.set(next, entry);
  }
  const total = [...nextCounts.values()].reduce((a, e) => a + e.count, 0) || 1;
  const continuations = [...nextCounts.values()]
    .sort((a, b) => b.count - a.count)
    .slice(0, Math.max(1, limit))
    .map(e => ({
      san: e.san,
      count: e.count,
      pct: Math.round((e.count / total) * 100),
      name: e.sampleName
    }));
  return { prefix: prefixKey, named, continuations, totalGames: total };
}

export function openingExplorerMarkup(result) {
  if (!result) return '';
  const title = result.named?.name
    ? `<div class="open-exp-title"><b>${escapeHtml(result.named.name)}</b>${result.named.eco ? ` <span class="open-exp-eco">${escapeHtml(result.named.eco)}</span>` : ''}</div>`
    : `<div class="open-exp-title"><b>Khai cuộc</b> <span class="open-exp-eco">khám phá</span></div>`;
  if (!result.continuations?.length) {
    return `<aside class="opening-explorer" aria-label="Opening explorer">${title}<p class="open-exp-empty">Hết dữ liệu tiếp tục trong sách khai cuộc cục bộ.</p></aside>`;
  }
  const rows = result.continuations.map(c =>
    `<button type="button" class="open-exp-row" data-san="${escapeAttr(c.san)}"><span class="open-exp-san">${escapeHtml(c.san)}</span><span class="open-exp-pct">${c.pct}%</span><span class="open-exp-name">${escapeHtml(c.name || '')}</span></button>`
  ).join('');
  return `<aside class="opening-explorer" aria-label="Opening explorer">${title}<div class="open-exp-list">${rows}</div></aside>`;
}

function escapeHtml(value) {
  return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function escapeAttr(value) {
  return escapeHtml(value).replace(/'/g, '&#39;');
}

/* ---------- 9–11. Live / lessons / club (UI data + pure helpers) ---------- */

export const LESSON_CATALOG = Object.freeze([
  {
    id: 'rules-basics',
    title: 'Luật cơ bản',
    chapters: [
      { id: 'king', title: 'Vua & chiếu', minutes: 4 },
      { id: 'pieces', title: 'Cách đi từng quân', minutes: 8 },
      { id: 'checkmate', title: 'Chiếu hết đơn giản', minutes: 6 }
    ]
  },
  {
    id: 'tactics-1',
    title: 'Chiến thuật nền',
    chapters: [
      { id: 'fork', title: 'Đòn đôi', minutes: 5 },
      { id: 'pin', title: 'Ghim', minutes: 5 },
      { id: 'skewer', title: 'Xiên', minutes: 5 }
    ]
  },
  {
    id: 'endgame-1',
    title: 'Tàn cuộc cơ bản',
    chapters: [
      { id: 'kq-mate', title: 'Vua + Hậu chiếu hết', minutes: 6 },
      { id: 'kr-mate', title: 'Vua + Xe chiếu hết', minutes: 7 },
      { id: 'opposition', title: 'Đối mặt vua', minutes: 6 }
    ]
  }
]);

export function lessonProgressSummary(progress = {}) {
  let total = 0;
  let done = 0;
  for (const lesson of LESSON_CATALOG) {
    for (const ch of lesson.chapters) {
      total += 1;
      if (progress[`${lesson.id}/${ch.id}`]) done += 1;
    }
  }
  const pct = total ? Math.round((done / total) * 100) : 0;
  return { total, done, pct, label: `${done}/${total} chương · ${pct}%` };
}

export function clubHomeMarkup(club = {}) {
  const name = club.name || 'Câu lạc bộ ViLa';
  const members = Number(club.members) || 0;
  const activity = club.activity || 'Thách đấu bạn bè · xem bảng xếp hạng · phòng xem';
  return `<section class="club-home panel" aria-label="Câu lạc bộ">
  <div class="panel-heading"><div><small class="eyebrow">CLUB</small><h2>${escapeHtml(name)}</h2></div><span class="context-icon">♖</span></div>
  <p class="club-meta">${members ? `${members} thành viên` : 'Câu lạc bộ cục bộ'} · ${escapeHtml(activity)}</p>
  <div class="button-row club-actions">
    <button type="button" class="primary-btn" id="clubChallengeBtn">Thách đấu bạn</button>
    <button type="button" class="secondary-btn" id="clubSpectateBtn">Phòng xem</button>
    <button type="button" class="secondary-btn" id="clubLeaderboardBtn">BXH câu lạc bộ</button>
  </div>
</section>`;
}

export function friendChallengePayload({ from, to, timeControl = '3+2', rated = false } = {}) {
  if (!from || !to || from === to) return null;
  return {
    type: 'friend-challenge',
    from: String(from),
    to: String(to),
    timeControl: String(timeControl),
    rated: Boolean(rated),
    createdAt: new Date().toISOString()
  };
}

export function spectatorRoomLabel({ white = 'Trắng', black = 'Đen', viewers = 0 } = {}) {
  const v = Math.max(0, Number(viewers) || 0);
  return `Đang xem · ${white} vs ${black}${v ? ` · ${v} người xem` : ''}`;
}

/** Board animation CSS class helpers */
export function boardSquareClasses({
  isLastFrom = false,
  isLastTo = false,
  isCheck = false,
  isSelected = false,
  isTarget = false,
  isPremoveFrom = false,
  isPremoveTo = false,
  smooth = true
} = {}) {
  return [
    isLastFrom ? 'last-from' : '',
    isLastTo ? 'last-to' : '',
    isCheck ? 'in-check' : '',
    isSelected ? 'selected' : '',
    isTarget ? 'legal-target' : '',
    isPremoveFrom ? 'premove-from' : '',
    isPremoveTo ? 'premove-to' : '',
    smooth ? 'anim-ready' : ''
  ].filter(Boolean).join(' ');
}

/* ---------- Lessons: real content + diagram helpers (v3.56) ---------- */

/**
 * Static lesson content. Every chapter has a short explanation, a few key points,
 * and one diagram position (FEN). The text was checked against the FEN by hand and
 * by tests/v3-56-lessons-club.test.js (structure + piece counts).
 */
export const LESSON_CONTENT = Object.freeze({
  'rules-basics/king': {
    intro: 'Vua là quân quan trọng nhất: mất vua là thua ván. Khi vua bị tấn công, ta nói vua đang bị chiếu.',
    points: [
      'Vua đi một ô theo mọi hướng, nhưng không được đi vào ô đang bị đối phương tấn công.',
      'Khi bị chiếu bạn bắt buộc phải thoát: di chuyển vua, bắt quân đang chiếu, hoặc chặn đường chiếu.',
      'Hai vua không bao giờ được đứng cạnh nhau.'
    ],
    fen: '4k3/4R3/8/8/8/8/8/4K3 b - - 0 1',
    caption: 'Xe trắng e7 chiếu vua đen. Vua đen có thể bắt xe vì xe không được bảo vệ (Kxe7).'
  },
  'rules-basics/pieces': {
    intro: 'Mỗi bên có 16 quân. Học cách đi của từng loại quân là bước đầu tiên để chơi tốt.',
    points: [
      'Xe đi thẳng theo hàng/cột; Tượng đi chéo; Hậu kết hợp cả hai.',
      'Mã đi hình chữ L và là quân duy nhất nhảy qua được quân khác.',
      'Tốt đi thẳng một ô (hai ô ở nước đầu), bắt chéo, và phong cấp khi tới hàng cuối.'
    ],
    fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    caption: 'Thế cờ ban đầu. Hậu luôn đứng trên ô cùng màu với nó (hậu trắng trên ô trắng).'
  },
  'rules-basics/checkmate': {
    intro: 'Chiếu hết là khi vua bị chiếu và không có cách nào thoát. Đây là cách duy nhất để thắng bằng quân cờ.',
    points: [
      'Kiểm tra theo thứ tự: vua có chạy được không, có bắt được quân chiếu không, có chặn được không.',
      'Chiếu hết hàng cuối (back-rank) rất hay gặp: vua bị chính các tốt của mình chặn đường.',
      'Luôn kiểm tra vua mình có an toàn không trước khi tấn công.'
    ],
    fen: '6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1',
    caption: 'Trắng đi Ra8 là chiếu hết: vua đen bị ba tốt của mình chặn lối thoát.'
  },
  'tactics-1/fork': {
    intro: 'Đòn đôi (fork) là một quân tấn công hai mục tiêu cùng lúc, đối phương chỉ cứu được một.',
    points: [
      'Mã là quân chơi đòn đôi giỏi nhất vì nó tấn công theo kiểu chữ L mà ít quân phòng thủ được.',
      'Đòn đôi mạnh nhất khi một trong hai mục tiêu là vua (chiếu đôi vua + quân).',
      'Trước mỗi nước, hãy tìm ô mà quân bạn tấn công được hai quân đối phương không được bảo vệ.'
    ],
    fen: 'r3k3/8/8/3N4/8/8/8/4K3 w - - 0 1',
    caption: 'Mã d5 đi Nc7+ chiếu vua e8 và đồng thời tấn công xe a8; sau đó Trắng ăn xe.'
  },
  'tactics-1/pin': {
    intro: 'Ghim (pin) là khi một quân không thể (hoặc không nên) di chuyển vì sẽ để lộ quân quan trọng hơn phía sau.',
    points: [
      'Ghim tuyệt đối: quân bị ghim che vua, di chuyển nó là nước đi phạm luật.',
      'Ghim tương đối: quân phía sau là quân giá trị (như Hậu); di chuyển được nhưng sẽ mất quân.',
      'Hãy tấn công thêm vào quân bị ghim — nó không thể chạy.'
    ],
    fen: '4k3/8/8/8/1b6/8/3N4/4K3 w - - 0 1',
    caption: 'Tượng đen b4 ghim mã d2 vào vua e1: mã trắng không thể rời d2.'
  },
  'tactics-1/skewer': {
    intro: 'Xiên (skewer) giống ghim ngược: quân giá trị bị tấn công trước, khi nó chạy đi thì quân phía sau bị mất.',
    points: [
      'Chỉ quân đi theo đường dài (Xe, Tượng, Hậu) mới xiên được.',
      'Thường bắt đầu bằng nước chiếu vua, vua buộc phải di chuyển và để lộ quân phía sau.',
      'Tìm các quân cùng nằm trên một hàng, cột hoặc đường chéo.'
    ],
    fen: '4q3/8/8/4k3/8/8/K7/R7 w - - 0 1',
    caption: 'Re1+ chiếu vua e5; vua phải rời cột e, rồi Trắng ăn Hậu đen ở e8 (Rxe8).'
  },
  'endgame-1/kq-mate': {
    intro: 'Vua + Hậu thắng Vua là bài tàn cuộc cơ bản. Mục tiêu: dồn vua đối phương vào mép bàn rồi chiếu hết.',
    points: [
      'Dùng Hậu thu hẹp không gian của vua đối phương, giữ khoảng cách một nước đi của mã.',
      'Đưa vua của bạn lại gần để hỗ trợ cú chiếu hết.',
      'Cẩn thận hòa pat (stalemate): đừng để vua đối phương hết nước đi mà không bị chiếu.'
    ],
    fen: '7k/8/5KQ1/8/8/8/8/8 w - - 0 1',
    caption: 'Qg7 là chiếu hết: Hậu được vua f6 bảo vệ nên vua đen h8 không bắt được.'
  },
  'endgame-1/kr-mate': {
    intro: 'Vua + Xe thắng Vua cũng cần kỹ thuật: dùng Xe cắt vua đối phương theo từng hàng cho tới mép bàn.',
    points: [
      'Đưa vua của bạn đối mặt với vua đối phương để ép nó lùi, rồi dùng Xe chiếu hết ở hàng cuối.',
      'Giữ Xe ở xa vua đối phương để không bị bắt.',
      'Mẫu chiếu hết: vua đen ở góc, vua trắng chặn hàng kề, Xe chiếu dọc hàng cuối.'
    ],
    fen: '7k/8/6K1/8/8/8/8/R7 w - - 0 1',
    caption: 'Ra8 là chiếu hết: vua g6 khóa g7 và h7, xe khóa hàng thứ tám.'
  },
  'endgame-1/opposition': {
    intro: 'Đối mặt vua (opposition) là khi hai vua đứng cùng cột hoặc hàng, cách nhau đúng một ô. Bên phải đi thường phải nhường đường.',
    points: [
      'Trong tàn cuộc tốt, giữ được thế đối mặt thường quyết định ai thắng.',
      'Bên không phải đi (đang giữ đối mặt) buộc vua đối phương lùi hoặc đi ngang.',
      'Đếm nước đi cẩn thận: thêm hoặc bớt một nước tempo có thể đảo ngược kết quả.'
    ],
    fen: '8/8/8/4k3/8/4K3/8/8 w - - 0 1',
    caption: 'Hai vua đối mặt trên cột e, cách nhau ô e4. Trắng đến lượt nên phải nhường đối mặt.'
  }
});

const PIECE_GLYPHS = Object.freeze({
  K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
  k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟'
});

/** Parse the board part of a FEN into 8 rows of 8 cells ('' for empty). Returns null when invalid. */
export function parseFenBoard(fen) {
  const board = String(fen || '').trim().split(/\s+/)[0] || '';
  const rows = board.split('/');
  if (rows.length !== 8) return null;
  const out = [];
  for (const row of rows) {
    const cells = [];
    for (const ch of row) {
      if (/[1-8]/.test(ch)) { for (let i = 0; i < Number(ch); i += 1) cells.push(''); }
      else if (PIECE_GLYPHS[ch]) cells.push(ch);
      else return null;
    }
    if (cells.length !== 8) return null;
    out.push(cells);
  }
  return out;
}

/** Static, accessible diagram of a FEN. Pure HTML string (no listeners needed). */
export function fenToDiagramMarkup(fen, label = 'Thế cờ minh họa') {
  const board = parseFenBoard(fen);
  if (!board) return '';
  const cells = board.map((row, r) => row.map((piece, c) => {
    const dark = (r + c) % 2 === 1;
    const side = piece ? (piece === piece.toUpperCase() ? 'w' : 'b') : '';
    return `<span class="lesson-sq ${dark ? 'dark' : 'light'}${side ? ` p-${side}` : ''}">${piece ? PIECE_GLYPHS[piece] : ''}</span>`;
  }).join('')).join('');
  return `<div class="lesson-diagram" role="img" aria-label="${escapeHtml(label)}">${cells}</div>`;
}

export function findLessonChapter(key) {
  const [lessonId, chapterId] = String(key || '').split('/');
  const lesson = LESSON_CATALOG.find(item => item.id === lessonId);
  const chapter = lesson?.chapters.find(item => item.id === chapterId);
  if (!lesson || !chapter) return null;
  return { lesson, chapter, content: LESSON_CONTENT[`${lessonId}/${chapterId}`] || null };
}

export function lessonReaderMarkup(key, done = false) {
  const found = findLessonChapter(key);
  if (!found || !found.content) return '';
  const { lesson, chapter, content } = found;
  return `<section class="page lessons-page lesson-reader" aria-label="${escapeHtml(chapter.title)}">
  <div class="panel-heading"><div><small class="eyebrow">${escapeHtml(lesson.title)}</small><h2>${escapeHtml(chapter.title)}</h2></div><span class="context-icon">📖</span></div>
  <p class="lesson-intro">${escapeHtml(content.intro)}</p>
  ${fenToDiagramMarkup(content.fen, content.caption)}
  <p class="field-hint lesson-caption">${escapeHtml(content.caption)}</p>
  <ul class="lesson-points">${content.points.map(point => `<li>${escapeHtml(point)}</li>`).join('')}</ul>
  <div class="button-row">
    <button type="button" class="primary-btn" id="lessonDoneBtn" data-lesson-key="${escapeHtml(key)}">${done ? '✓ Đã hoàn thành' : 'Đánh dấu hoàn thành'}</button>
    <button type="button" class="secondary-btn" id="lessonBackBtn">Quay lại danh sách</button>
  </div>
</section>`;
}
