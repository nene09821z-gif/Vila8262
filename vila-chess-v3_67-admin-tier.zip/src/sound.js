import { MUSIC_LIBRARY, DEFAULT_MUSIC_ID, musicEntryById, musicEntrySource } from './music-library.js';
import { playYoutube, stopYoutube, resumeYoutube, onYoutubeError } from './youtube-music.js';
let audioContext = null;
function getAudioContext() {
  if (typeof window === 'undefined') return null;
  const Ctor = window.AudioContext || window.webkitAudioContext;
  if (!Ctor) return null;
  try { audioContext ||= new Ctor(); return audioContext; } catch { return null; }
}
export function unlockBoardSound() {
  const ctx = getAudioContext();
  if (!ctx) return false;
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return true;
}
/** Pure classifier (unit-testable): which sound a move should make. */
export function soundKindForMove(move, chess) {
  if (!move) return null;
  const flags = String(move.flags || '');
  if (chess?.isCheckmate?.()) return 'checkmate';
  if (chess?.isCheck?.()) return 'check';
  if (move.promotion || flags.includes('p')) return 'promote';
  if (flags.includes('k') || flags.includes('q')) return 'castle';
  if (move.captured || flags.includes('c') || flags.includes('e')) return 'capture';
  return 'move';
}

let noiseBuffer = null;
function getNoiseBuffer(ctx) {
  if (noiseBuffer && noiseBuffer.sampleRate === ctx.sampleRate) return noiseBuffer;
  const length = Math.floor(ctx.sampleRate * 0.12);
  noiseBuffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  for (let i = 0; i < length; i += 1) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
  return noiseBuffer;
}
// A short filtered-noise "wood tap" plus a low sine thump: reads like a piece set on a board.
function woodTap(ctx, at, { volume = 0.16, pitch = 170, brightness = 1400 } = {}) {
  const noise = ctx.createBufferSource();
  noise.buffer = getNoiseBuffer(ctx);
  const filter = ctx.createBiquadFilter();
  filter.type = 'bandpass'; filter.frequency.setValueAtTime(brightness, at); filter.Q.setValueAtTime(0.9, at);
  const noiseGain = ctx.createGain();
  noiseGain.gain.setValueAtTime(volume, at);
  noiseGain.gain.exponentialRampToValueAtTime(0.0001, at + 0.07);
  noise.connect(filter); filter.connect(noiseGain); noiseGain.connect(ctx.destination);
  noise.start(at); noise.stop(at + 0.09);
  const thump = ctx.createOscillator();
  const thumpGain = ctx.createGain();
  thump.type = 'sine';
  thump.frequency.setValueAtTime(pitch * 1.6, at);
  thump.frequency.exponentialRampToValueAtTime(pitch, at + 0.05);
  thumpGain.gain.setValueAtTime(volume * 0.9, at);
  thumpGain.gain.exponentialRampToValueAtTime(0.0001, at + 0.09);
  thump.connect(thumpGain); thumpGain.connect(ctx.destination);
  thump.start(at); thump.stop(at + 0.1);
}
function tone(ctx, at, hz, { duration = 0.16, volume = 0.07, type = 'sine' } = {}) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type; osc.frequency.setValueAtTime(hz, at);
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.exponentialRampToValueAtTime(volume, at + 0.012);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + duration);
  osc.connect(gain); gain.connect(ctx.destination);
  osc.start(at); osc.stop(at + duration + 0.02);
}
function withContext(play) {
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    play(ctx, ctx.currentTime);
    return true;
  } catch { return false; }
}

export function playBoardSound(move, chess, enabled = true, theme = 'soft') {
  if (!enabled || !move || theme === 'mute') return false;
  const profile = theme === 'wood' ? { volume: 1.22, brightness: 1900, pitch: 0.92 } : theme === 'neon' ? { volume: 0.82, brightness: 2800, pitch: 1.22 } : { volume: 1, brightness: 1400, pitch: 1 };
  const kind = soundKindForMove(move, chess);
  try {
    if (typeof window !== 'undefined' && window.AndroidBridge && typeof window.AndroidBridge.vibrate === 'function') {
      if (kind === 'checkmate' || kind === 'check') window.AndroidBridge.vibrate(60);
      else if (kind === 'capture') window.AndroidBridge.vibrate(35);
      else window.AndroidBridge.vibrate(18);
    }
  } catch {}
  return withContext((ctx, now) => {
    if (kind === 'checkmate') {
      woodTap(ctx, now, { volume: 0.2 * profile.volume, pitch: 120 * profile.pitch, brightness: profile.brightness });
      [659, 523, 392, 262].forEach((hz, i) => tone(ctx, now + 0.12 + i * 0.1, hz * profile.pitch, { duration: 0.22, volume: 0.06 * profile.volume, type: 'triangle' }));
    } else if (kind === 'check') {
      woodTap(ctx, now, { volume: 0.17 * profile.volume, pitch: 150 * profile.pitch, brightness: profile.brightness });
      tone(ctx, now + 0.07, 880 * profile.pitch, { duration: 0.14, volume: 0.06 * profile.volume });
      tone(ctx, now + 0.16, 1175 * profile.pitch, { duration: 0.2, volume: 0.055 * profile.volume });
    } else if (kind === 'promote') {
      woodTap(ctx, now, { volume: 0.14 * profile.volume, brightness: profile.brightness });
      [523, 659, 784, 1047].forEach((hz, i) => tone(ctx, now + 0.05 + i * 0.06, hz * profile.pitch, { duration: 0.16, volume: 0.05 * profile.volume }));
    } else if (kind === 'castle') {
      woodTap(ctx, now, { volume: 0.13 * profile.volume, pitch: 190 * profile.pitch, brightness: profile.brightness });
      woodTap(ctx, now + 0.11, { volume: 0.15 * profile.volume, pitch: 160 * profile.pitch, brightness: profile.brightness });
    } else if (kind === 'capture') {
      woodTap(ctx, now, { volume: 0.24 * profile.volume, pitch: 135 * profile.pitch, brightness: Math.max(700, profile.brightness - 300) });
      woodTap(ctx, now + 0.045, { volume: 0.12 * profile.volume, pitch: 210 * profile.pitch, brightness: profile.brightness + 300 });
    } else {
      woodTap(ctx, now, { volume: 0.15 * profile.volume, pitch: 170 * profile.pitch, brightness: profile.brightness });
    }
  });
}

/** Non-move sounds: game start/end, flag, illegal move, low-time tick, notification. Fully synthesized (works offline). */
export function playGameSound(kind, enabled = true) {
  if (!enabled || !kind) return false;
  return withContext((ctx, now) => {
    switch (kind) {
      case 'start': [392, 523, 659].forEach((hz, i) => tone(ctx, now + i * 0.09, hz, { duration: 0.2, volume: 0.055 })); break;
      case 'win': [523, 659, 784, 1047].forEach((hz, i) => tone(ctx, now + i * 0.12, hz, { duration: 0.3, volume: 0.06, type: 'triangle' })); break;
      case 'lose': [392, 349, 311, 262].forEach((hz, i) => tone(ctx, now + i * 0.14, hz, { duration: 0.32, volume: 0.055, type: 'triangle' })); break;
      case 'draw': [440, 440].forEach((hz, i) => tone(ctx, now + i * 0.16, hz, { duration: 0.24, volume: 0.05 })); break;
      case 'flag': tone(ctx, now, 220, { duration: 0.5, volume: 0.07, type: 'sawtooth' }); tone(ctx, now + 0.02, 330, { duration: 0.5, volume: 0.03, type: 'square' }); break;
      case 'illegal': tone(ctx, now, 160, { duration: 0.12, volume: 0.06, type: 'square' }); tone(ctx, now + 0.1, 140, { duration: 0.16, volume: 0.05, type: 'square' }); break;
      case 'lowtime': tone(ctx, now, 1000, { duration: 0.07, volume: 0.04 }); break;
      case 'notify': tone(ctx, now, 740, { duration: 0.12, volume: 0.045 }); tone(ctx, now + 0.1, 988, { duration: 0.16, volume: 0.045 }); break;
      default: break;
    }
  });
}


// Background music is streamed online (YouTube IFrame). There is no offline/synth music any more.
let musicEnabled = false;
let musicSkips = 0;
const MUSIC_TRACK_KEY = 'vila.chess.music-track.v2';
let selectedMusicTrack = (() => { try { const saved = localStorage.getItem(MUSIC_TRACK_KEY); return musicEntryById(saved) ? saved : DEFAULT_MUSIC_ID; } catch { return DEFAULT_MUSIC_ID; } })();
let youtubeSource = null; // a custom link pasted by the user; null = use the library
let youtubeFailureHandler = null;
function currentEntry() { return musicEntryById(selectedMusicTrack) || MUSIC_LIBRARY[0]; }
function notifyMusicChange() { try { window.dispatchEvent(new CustomEvent('vila:music-changed', { detail: { id: selectedMusicTrack, custom: Boolean(youtubeSource) } })); } catch {} }
/** Choose a custom YouTube source ({videoId,listId}) or null to go back to the built-in online library. */
export function setChessMusicYoutube(source, { onFailure } = {}) {
  youtubeSource = source && (source.videoId || source.listId) ? { videoId: source.videoId || '', listId: source.listId || '' } : null;
  youtubeFailureHandler = typeof onFailure === 'function' ? onFailure : null;
  musicSkips = 0;
  if (musicEnabled) void startChessMusic(); else if (!youtubeSource) stopYoutube();
  notifyMusicChange();
}
export function getChessMusicYoutube() { return youtubeSource; }
export function getChessMusicTrack() { return selectedMusicTrack; }
export function getChessMusicTitle() { return youtubeSource ? 'Nhạc từ link của bạn' : currentEntry().name; }
export function setChessMusicTrack(track, { keepSkips = false } = {}) {
  const next = musicEntryById(String(track)) ? String(track) : DEFAULT_MUSIC_ID;
  selectedMusicTrack = next;
  youtubeSource = null;
  if (!keepSkips) musicSkips = 0;
  try { localStorage.setItem(MUSIC_TRACK_KEY, next); } catch {}
  if (musicEnabled) void startChessMusic();
  notifyMusicChange();
  return selectedMusicTrack;
}
/** Skip to the next (dir = 1) or previous (dir = -1) library track. */
export function stepChessMusicTrack(dir = 1, opts = {}) {
  const index = MUSIC_LIBRARY.findIndex(item => item.id === selectedMusicTrack);
  const next = MUSIC_LIBRARY[(index + (dir < 0 ? -1 : 1) + MUSIC_LIBRARY.length) % MUSIC_LIBRARY.length];
  return setChessMusicTrack(next.id, opts);
}
export function listChessMusicTracks() { return MUSIC_LIBRARY.map(item => ({ id: item.id, name: item.name, mood: item.mood, external: true })); }
onYoutubeError(error => {
  if (youtubeSource) { youtubeSource = null; try { youtubeFailureHandler?.(error); } catch {} }
  stopYoutube();
  if (!musicEnabled) return;
  // This video is blocked / unavailable → try the next one in the library (at most one full lap).
  if (++musicSkips <= MUSIC_LIBRARY.length) stepChessMusicTrack(1, { keepSkips: true }); else musicEnabled = false;
  notifyMusicChange();
});
if (typeof window !== 'undefined') window.addEventListener('vila:music-prev', () => { if (!musicEnabled) setChessMusicPlaying(true); stepChessMusicTrack(-1); });
if (typeof window !== 'undefined') window.addEventListener('vila:music-next', () => { if (!musicEnabled) setChessMusicPlaying(true); stepChessMusicTrack(1); });
if (typeof window !== 'undefined') window.addEventListener('vila:youtube-ended', () => { if (musicEnabled && !youtubeSource) stepChessMusicTrack(1); });

async function startChessMusic() {
  if (!musicEnabled) return;
  const source = youtubeSource || musicEntrySource(currentEntry());
  try {
    await playYoutube(source, { title: getChessMusicTitle() });
  } catch (error) {
    if (youtubeSource) { youtubeSource = null; try { youtubeFailureHandler?.(error); } catch {} }
    // YouTube unreachable (offline / blocked): stop trying instead of pretending music is on.
    if (/internet|YouTube/i.test(String(error?.message || ''))) {
      musicEnabled = false; notifyMusicChange();
      try { window.dispatchEvent(new CustomEvent('vila:music-error', { detail: { message: error.message } })); } catch {}
    }
  }
}
export function isChessMusicPlaying() { return musicEnabled; }
/** True when the player was asked to start but the browser blocked autoplay (needs a tap). */
export function nudgeChessMusic() { return musicEnabled ? resumeYoutube() : false; }
export function setChessMusicPlaying(enabled) {
  musicEnabled = Boolean(enabled);
  if (!musicEnabled) { stopYoutube(); notifyMusicChange(); return false; }
  unlockBoardSound();
  void startChessMusic();
  notifyMusicChange();
  return true;
}
