/** Pure diagnostics helpers; results reflect observed app state, never simulated success. */
export const REQUIRED_OPENING_COUNT = 3000;

export function buildSystemChecks({
  engineReady = false,
  engineFailed = false,
  workerSupported = true,
  storageAvailable = true,
  openingCount = 0,
  backendStatus = 'unknown',
  backendConfigured = false
} = {}) {
  const checks = [];
  if (engineReady) checks.push({ id: 'engine', label: 'Stockfish engine', status: 'ok', detail: 'Engine đã trả lời tín hiệu sẵn sàng.' });
  else if (engineFailed) checks.push({ id: 'engine', label: 'Stockfish engine', status: 'error', detail: 'Engine chưa sẵn sàng. Chạm nút thử tải lại engine.' });
  else checks.push({ id: 'engine', label: 'Stockfish engine', status: 'pending', detail: 'Engine đang khởi tạo; nếu quá thời gian, xem thông báo lỗi.' });

  if (!workerSupported) checks.push({ id: 'worker', label: 'Web Worker', status: 'error', detail: 'WebView không hỗ trợ Worker; cần cập nhật Android System WebView.' });
  else checks.push({ id: 'worker', label: 'Web Worker', status: 'ok', detail: 'Trình duyệt hỗ trợ Worker để chạy engine tách khỏi giao diện.' });

  const count = Math.max(0, Math.floor(Number(openingCount) || 0));
  if (count >= REQUIRED_OPENING_COUNT) checks.push({ id: 'openings', label: 'Kho khai cuộc', status: 'ok', detail: `${count.toLocaleString()} biến khai cuộc đang nạp.` });
  else checks.push({ id: 'openings', label: 'Kho khai cuộc', status: 'error', detail: `Hiện chỉ có ${count.toLocaleString()} biến. Bản phát hành yêu cầu ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()}; không được tuyên bố đã đủ 3.000 khi chưa nạp dữ liệu.` });

  checks.push(storageAvailable
    ? { id: 'storage', label: 'Lưu dữ liệu thiết bị', status: 'ok', detail: 'Bộ nhớ cục bộ có thể đọc/ghi.' }
    : { id: 'storage', label: 'Lưu dữ liệu thiết bị', status: 'error', detail: 'Không thể ghi bộ nhớ cục bộ; cài đặt và hộp thư có thể không được lưu.' });

  if (!backendConfigured) checks.push({ id: 'backend', label: 'Máy chủ tài khoản', status: 'warning', detail: 'Chưa cấu hình URL backend. Đăng nhập, bạn bè và Top 100 online chưa thể xác minh.' });
  else if (backendStatus === 'online') checks.push({ id: 'backend', label: 'Máy chủ tài khoản', status: 'ok', detail: 'Endpoint health của backend phản hồi thành công.' });
  else if (backendStatus === 'checking' || backendStatus === 'unknown') checks.push({ id: 'backend', label: 'Máy chủ tài khoản', status: 'pending', detail: 'Chưa kiểm tra kết nối trong lần mở trang này.' });
  else checks.push({ id: 'backend', label: 'Máy chủ tài khoản', status: 'error', detail: `Không xác minh được backend (${String(backendStatus).slice(0, 160)}). Kiểm tra URL, HTTPS, CORS và máy chủ.` });
  return checks;
}
