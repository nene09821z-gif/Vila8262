/** Strength mapping for Stockfish UCI. UCI_Elo is supported from about 1320;
 * lower training targets map to native Skill Level 0–7 instead of choosing random or
 * material-only moves. These low presets are not advertised as calibrated Elo ratings. */
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

export function clampTargetElo(value, fallback = 2600) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? n : fallback;
  return Math.round(clamp(safe, 500, 3200));
}

export function resolveStockfishStrength(value) {
  const targetElo = clampTargetElo(value);
  if (targetElo < 1320) {
    // A progressive, native engine skill preset; no scripted blunders or random legal moves.
    const skillLevel = Math.round(((targetElo - 500) / (1320 - 500)) * 7);
    return { targetElo, limitStrength: false, uciElo: null, skillLevel: clamp(skillLevel, 0, 7), mode: 'skill-level-floor' };
  }
  return { targetElo, limitStrength: true, uciElo: Math.min(3190, targetElo), skillLevel: 20, mode: 'uci-elo' };
}

export const BEGINNER_BOT_ELO = 500;
export const STOCKFISH_BOT_MODES = Object.freeze(['stockfish', 'stockfish-beginner']);

/** True for both Stockfish bot modes (normal and the 500-Elo "luyện người mới" mode). */
export function isStockfishBotMode(mode) { return STOCKFISH_BOT_MODES.includes(mode); }

/**
 * The strength a Stockfish bot must really use. The beginner mode is ALWAYS Elo 500, whatever the
 * saved settings say (a restored game or a stale `botStrengthMode: 'max'` used to make it full strength).
 * Returns null when the bot should play at full strength.
 */
export function resolveBotStrength(mode, settings = {}) {
  if (mode === 'stockfish-beginner') return resolveStockfishStrength(BEGINNER_BOT_ELO);
  if (settings.botStrengthMode === 'elo') return resolveStockfishStrength(settings.botElo);
  return null;
}

/** Offline rescue profile: a weak target must never be rescued by a strong engine. */
export function rescueProfileForStrength(strength, preferredProfile = 'ethereal') {
  if (!strength) return preferredProfile;
  if (strength.mode === 'skill-level-floor') return strength.targetElo <= 800 ? 'rookie' : 'mentor';
  if (strength.targetElo < 1700) return 'mentor';
  return preferredProfile;
}
