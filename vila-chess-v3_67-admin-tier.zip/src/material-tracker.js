/** Chess.com-style captured-material summary built only from legal move history. */
export const PIECE_MATERIAL_VALUE = Object.freeze({ p: 1, n: 3, b: 3, r: 5, q: 9 });
const PIECE_ORDER = Object.freeze(['q', 'r', 'b', 'n', 'p']);

export function summarizeCapturedMaterial(history = []) {
  const captured = { w: [], b: [] };
  const points = { w: 0, b: 0 };
  for (const move of Array.isArray(history) ? history : []) {
    const color = move?.color;
    const piece = String(move?.captured || '').toLowerCase();
    if (!['w', 'b'].includes(color) || !Object.hasOwn(PIECE_MATERIAL_VALUE, piece)) continue;
    captured[color].push(piece);
    points[color] += PIECE_MATERIAL_VALUE[piece];
  }
  for (const color of ['w', 'b']) {
    captured[color].sort((a, b) => PIECE_ORDER.indexOf(a) - PIECE_ORDER.indexOf(b));
  }
  const difference = points.w - points.b;
  return {
    captured,
    points,
    difference,
    advantage: { w: Math.max(0, difference), b: Math.max(0, -difference) }
  };
}
