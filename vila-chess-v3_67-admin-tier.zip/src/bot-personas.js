import { findOpeningBookMove } from './opening-book.js';

/**
 * Each VILA arena persona keeps exactly four curated, named opening lines.
 * The repertoires are personal to the bot; they are not all drawn from one
 * shared arena book. Search depth/time remain equal, so the book changes style
 * and variety without adding engine-thinking budget to one contestant.
 * Names must exist in src/openings.js / the bundled ECO catalogue.
 */
export const BOT_REPERTOIRES = Object.freeze({
  lc0:       { openingNames: ['Queen’s Gambit Orthodox', 'English Symmetrical', 'Réti Opening', 'Catalan'], plies: 12 },
  ethereal:  { openingNames: ['Khai cuộc Ý', 'Ruy Lopez', 'Khai cuộc Scotch', 'Italian Giuoco Pianissimo'], plies: 12 },
  berserk:   { openingNames: ['Gambit Evans', 'Gambit Vua', 'Danish Gambit', 'Latvian Gambit'], plies: 12 },
  fortress:  { openingNames: ['London System', 'Queen’s Gambit Orthodox', 'Caro–Kann', 'Phòng thủ Petrov'], plies: 12 },
  endgame:   { openingNames: ['Petrov Defense · Classical', 'Caro-Kann · Classical', 'Queen’s Gambit Orthodox', 'Four Knights'], plies: 12 },
  dynamic:   { openingNames: ['Najdorf Sicilian', 'Scotch Game · Classical', 'King’s Indian', 'Dragon Sicilian'], plies: 12 },
  blitz:     { openingNames: ['Vienna Game', 'English Reversed Sicilian', 'Scotch Gambit', 'Four Knights Game'], plies: 12 },
  gambit:    { openingNames: ['Gambit Evans', 'King\'s Gambit', 'Danish Gambit', 'Budapest Gambit'], plies: 12 },
  hyper:     { openingNames: ['King’s Indian', 'Grünfeld Defense', 'Réti Opening', 'Modern Defense'], plies: 12 },
  strangler: { openingNames: ['Sicilian Alapin', 'Pháp Advance', 'Queen’s Gambit Tarrasch', 'Catalan'], plies: 12 },
  trickster: { openingNames: ['Latvian Gambit', 'Queen\'s Pawn · Englund Gambit', 'Budapest Gambit', 'Scandinavian · Portuguese Gambit'], plies: 12 },
  rookie:    { openingNames: ['Khai cuộc Ý', 'Queen’s Gambit Orthodox', 'Khai cuộc Anh', 'Caro–Kann'], plies: 12 },
  mentor:    { openingNames: ['Italian Giuoco Pianissimo', 'London System', 'Caro-Kann · Classical', 'Queen’s Gambit Orthodox'], plies: 12 },
  hunter:    { openingNames: ['Scotch Gambit', 'Evans Gambit · Main Line', 'Dragon Sicilian', 'Vienna Gambit'], plies: 12 },
  sentinel:  { openingNames: ['London System', 'Caro–Kann', 'Queen’s Gambit Orthodox', 'Petrov Defense'], plies: 12 },
  strategist:{ openingNames: ['Catalan', 'Ruy Lopez', 'Queen’s Gambit Tarrasch', 'English Botvinnik'], plies: 12 },
  longgame:  { openingNames: ['Petrov Defense · Classical', 'Ruy Lopez · Berlin Defense', 'Queen’s Gambit Orthodox', 'Caro-Kann · Classical'], plies: 12 },
  chaos:     { openingNames: ['King\'s Gambit', 'Latvian Gambit', 'Budapest Gambit', 'Albin Countergambit'], plies: 12 },
  classic:   { openingNames: ['Khai cuộc Ý', 'Queen’s Gambit Orthodox', 'Phòng thủ Sicilian', 'King’s Indian'], plies: 12 },
  stockfish: { openingNames: ['Ruy Lopez · Berlin Defense', 'Najdorf Sicilian', 'Queen’s Gambit Orthodox', 'King\'s Indian Defense'], plies: 12 },
  stockfish10:{ openingNames: ['Phòng thủ Petrov', 'Phòng thủ Slav', 'Khai cuộc Scotch', 'King’s Indian Sämisch'], plies: 12 },
});

const poolCache = new WeakMap();

/** Return the four curated lines assigned to this bot from the opening catalogue. */
export function repertoireLines(openings, botId, _color) {
  const id = BOT_REPERTOIRES[botId] ? botId : 'classic';
  const repertoire = BOT_REPERTOIRES[id];
  if (!Array.isArray(openings)) return [];
  let perBot = poolCache.get(openings);
  if (!perBot || perBot.length !== openings.length) {
    perBot = { length: openings.length, map: new Map() };
    poolCache.set(openings, perBot);
  }
  if (perBot.map.has(id)) return perBot.map.get(id);
  const wanted = new Set(repertoire.openingNames.map(name => name.toLocaleLowerCase()));
  const pool = openings.filter(opening => wanted.has(String(opening?.name || '').trim().toLocaleLowerCase()));
  perBot.map.set(id, pool);
  return pool;
}

/** The four stored opening names, useful for arena labels and diagnostics. */
export function getPersonaOpeningNames(botId) {
  const id = BOT_REPERTOIRES[botId] ? botId : 'classic';
  return [...BOT_REPERTOIRES[id].openingNames];
}

/** A legal next move from this bot's own four-line book, or null after a deviation. */
export function pickPersonaBookMove(chess, botId, openings, options = {}) {
  const id = BOT_REPERTOIRES[botId] ? botId : 'classic';
  const repertoire = BOT_REPERTOIRES[id];
  const pool = repertoireLines(openings, id, chess?.turn?.());
  if (pool.length === 0) return null;
  return findOpeningBookMove(chess, pool, {
    maxPlies: repertoire.plies,
    recentChoices: options.recentChoices,
    random: options.random,
  });
}
