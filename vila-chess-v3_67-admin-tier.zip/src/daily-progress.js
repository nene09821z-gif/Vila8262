/** Daily missions and coin shop. Virtual coins have no cash value; shop items never change engine strength, Elo or match results. */
export const DAILY_MISSIONS = Object.freeze([
  { id: 'checkin', title: 'Điểm danh hôm nay', description: 'Mở Cờ Vua mỗi ngày để giữ chuỗi hoạt động.', event: 'checkin', goal: 1, reward: 10, icon: 'sun', category: 'Thói quen' },
  { id: 'finish_game', title: 'Hoàn thành một ván', description: 'Chơi hết một ván với Stockfish hoặc AI.', event: 'complete_game', goal: 1, reward: 35, icon: 'pawn', category: 'Thi đấu' },
  { id: 'play_three', title: 'Tập luyện đều đặn', description: 'Hoàn thành 3 ván cờ trong ngày.', event: 'complete_game', goal: 3, reward: 60, icon: 'sword', category: 'Thi đấu' },
  { id: 'win_game', title: 'Chiến thắng trong ngày', description: 'Đánh bại đối thủ AI ít nhất một lần.', event: 'win_game', goal: 1, reward: 70, icon: 'trophy', category: 'Thi đấu' },
  { id: 'draw_game', title: 'Biết khi nào nên hòa', description: 'Kết thúc một ván cờ hòa.', event: 'draw_game', goal: 1, reward: 30, icon: 'handshake', category: 'Thi đấu' },
  { id: 'play_moves', title: 'Luyện từng nước', description: 'Đi ít nhất 20 nước hợp lệ trong ngày.', event: 'make_move', goal: 20, reward: 35, icon: 'pawn', category: 'Kỹ năng' },
  { id: 'capture_pieces', title: 'Trao đổi quân', description: 'Thực hiện 5 nước bắt quân.', event: 'capture_piece', goal: 5, reward: 35, icon: 'sparkle', category: 'Kỹ năng' },
  { id: 'castle_once', title: 'Đưa vua vào an toàn', description: 'Nhập thành ít nhất một lần.', event: 'castle', goal: 1, reward: 20, icon: 'castle', category: 'Kỹ năng' },
  { id: 'promote_once', title: 'Biến tốt thành hậu', description: 'Phong cấp một quân tốt.', event: 'promote', goal: 1, reward: 45, icon: 'crown', category: 'Kỹ năng' },
  { id: 'check_king', title: 'Tạo sức ép', description: 'Chiếu vua đối phương 3 lần.', event: 'check_king', goal: 3, reward: 25, icon: 'bolt', category: 'Kỹ năng' },
  { id: 'opening_visit', title: 'Học một khai cuộc', description: 'Mở thư viện khai cuộc và xem các biến mở đầu.', event: 'visit_openings', goal: 1, reward: 20, icon: 'crown', category: 'Học tập' },
  { id: 'coach_visit', title: 'Mở phòng phân tích', description: 'Mở công cụ phân tích và huấn luyện cờ vua.', event: 'visit_coach', goal: 1, reward: 20, icon: 'sparkle', category: 'Học tập' },
  { id: 'analyze_game', title: 'Xem lại ván đấu', description: 'Chạy phân tích Stockfish sau ván đấu.', event: 'analyze_game', goal: 1, reward: 35, icon: 'search', category: 'Học tập' },
  { id: 'finish_lesson', title: 'Hoàn thành một bài học', description: 'Đọc xong một chương trong mục Bài học.', event: 'lesson_done', goal: 1, reward: 25, icon: 'book', category: 'Học tập' },
  { id: 'open_history', title: 'Nhìn lại tiến bộ', description: 'Mở lịch sử và xem lại một ván đã lưu.', event: 'open_history', goal: 1, reward: 15, icon: 'history', category: 'Học tập' },
  { id: 'visit_puzzles', title: 'Thử sức với chiến thuật', description: 'Mở phòng câu đố cờ vua.', event: 'visit_puzzles', goal: 1, reward: 20, icon: 'puzzle', category: 'Học tập' },
  { id: 'solve_puzzles', title: 'Giải 3 câu đố', description: 'Tìm nước mạnh nhất trong ba thế cờ ngẫu nhiên.', event: 'solve_puzzle', goal: 3, reward: 55, icon: 'brain', category: 'Thử thách' },
  { id: 'streak_bonus', title: 'Chuỗi nhiệm vụ', description: 'Hoàn thành 5 mục tiêu nhiệm vụ bất kỳ.', event: 'claim_mission', goal: 5, reward: 80, icon: 'flame', category: 'Thử thách' },
  { id: 'win_twice', title: 'Thắng hai trận', description: 'Đánh bại AI hai lần trong ngày.', event: 'win_game', goal: 2, reward: 80, icon: 'trophy', category: 'Thi đấu' },
  { id: 'solve_five_puzzles', title: 'Thợ săn chiến thuật', description: 'Giải đúng 5 câu đố; đề được xác minh bằng luật cờ.', event: 'solve_puzzle', goal: 5, reward: 75, icon: 'brain', category: 'Thử thách' },
  { id: 'solve_ten_puzzles', title: 'Bậc thầy chiến thuật', description: 'Giải đúng 10 câu đố trong ngày.', event: 'solve_puzzle', goal: 10, reward: 120, icon: 'crown', category: 'Thử thách' },
  { id: 'visit_arena', title: 'Thăm đấu trường', description: 'Mở khu vực đấu bot và khám phá các cặp đấu.', event: 'visit_arena', goal: 1, reward: 15, icon: 'robot', category: 'Đấu trường' },
  { id: 'complete_arena', title: 'Tranh cúp ViLa', description: 'Hoàn thành ít nhất một giải đấu bot hợp lệ.', event: 'complete_arena', goal: 1, reward: 100, icon: 'trophy', category: 'Đấu trường' },
  { id: 'visit_games', title: 'Giải lao có ích', description: 'Khám phá góc mini-game ngoại tuyến.', event: 'visit_games', goal: 1, reward: 10, icon: 'gamepad', category: 'Giải trí' },
  { id: 'play_mini_game', title: 'Thử thách nhanh', description: 'Thực hiện ít nhất một lượt chơi trong mini-game.', event: 'play_mini_game', goal: 1, reward: 20, icon: 'target', category: 'Giải trí' },
  { id: 'download_puzzle_pack', title: 'Chuẩn bị khi mất mạng', description: 'Tải và lưu ít nhất một câu đố Lichess để luyện offline.', event: 'download_puzzle_pack', goal: 1, reward: 30, icon: 'download', category: 'Học tập' },
  { id: 'analyze_three_games', title: 'Nhà phân tích', description: 'Phân tích toàn ván ba lần.', event: 'analyze_game', goal: 3, reward: 65, icon: 'chart', category: 'Học tập' }
]);

/** Board colours are free settings now (no longer sold in the shop). */
export const COSMETICS = Object.freeze([
  { id: 'classic', name: 'Xanh lá & kem', description: 'Bàn cờ 2D xanh lá và kem, phong cách cờ vua trực tuyến cổ điển.', cost: 0, icon: 'pawn', colors: ['#eeeed2', '#769656'], defaultOwned: true },
  { id: 'ocean', name: 'Đại dương', description: 'Bàn cờ xanh biển dịu mắt.', cost: 0, icon: 'pawn', colors: ['#d8eaf0', '#4d8298'] },
  { id: 'walnut', name: 'Gỗ óc chó', description: 'Tông gỗ ấm, cổ điển.', cost: 0, icon: 'pawn', colors: ['#ead5b7', '#986543'] },
  { id: 'midnight', name: 'Nửa đêm', description: 'Bàn cờ than chì và bạc.', cost: 0, icon: 'pawn', colors: ['#cbd4df', '#475568'] },
  { id: 'violet', name: 'Tím hoàng hôn', description: 'Tông tím trầm, dễ nhìn trong phòng tối.', cost: 0, icon: 'pawn', colors: ['#e4d9ef', '#84689b'] },
  { id: 'rose', name: 'Hồng đất', description: 'Bàn cờ tông hồng bụi nhẹ nhàng.', cost: 0, icon: 'pawn', colors: ['#f0dcd7', '#bc8f91'] },
  { id: 'ice', name: 'Băng giá', description: 'Xanh lạnh và xám thép.', cost: 0, icon: 'pawn', colors: ['#e5eff4', '#7096ab'] },
  { id: 'forest', name: 'Rừng sâu', description: 'Hai sắc xanh rừng đậm.', cost: 0, icon: 'pawn', colors: ['#d5e1cf', '#4f7153'] },
  { id: 'emerald', name: 'Ngọc lục bảo', description: 'Xanh ngọc và bạc hà sáng, tương phản rõ.', cost: 0, icon: 'pawn', colors: ['#dcf5e5', '#4e9a78'] },
  { id: 'sunset', name: 'Hoàng hôn', description: 'Kem ấm và cam đất dịu mắt.', cost: 0, icon: 'pawn', colors: ['#f8e3c5', '#c37c59'] },
  { id: 'slate', name: 'Đá phiến', description: 'Ghi sáng và xanh xám chuyên nghiệp.', cost: 0, icon: 'pawn', colors: ['#e0e7ee', '#637c90'] },
  { id: 'sand', name: 'Cát sa mạc', description: 'Cát nhạt phối nâu ô liu.', cost: 0, icon: 'pawn', colors: ['#f4e8c9', '#a68b59'] },
  { id: 'ruby', name: 'Hồng ngọc', description: 'Hồng ngà và đỏ mận trầm.', cost: 0, icon: 'pawn', colors: ['#f5dfe4', '#a75970'] }
]);

const own = value => value && typeof value === 'object' && !Array.isArray(value);
const clampInt = (value, min = 0, max = 1_000_000) => Math.max(min, Math.min(max, Math.floor(Number(value) || 0)));
export const HOUR_MS = 60 * 60 * 1000;
export const PRO_TRIAL_MAX_MS = 24 * HOUR_MS;
/** Coin shop catalogue. `grant` is what the item adds to the on-device inventory. */
export const SHOP_ITEMS = Object.freeze([
  { id: 'review_1', group: 'analysis', icon: 'chart', name: 'Lượt phân tích ×1', description: 'Mở phân tích toàn ván thêm 1 lần (ván đó xem lại được mãi).', cost: 120, grant: { reviewCredits: 1 } },
  { id: 'review_3', group: 'analysis', icon: 'chart', name: 'Gói phân tích ×3', description: 'Ba lượt phân tích toàn ván, rẻ hơn mua lẻ.', cost: 300, grant: { reviewCredits: 3 }, badge: 'Tiết kiệm' },
  { id: 'review_10', group: 'analysis', icon: 'chart', name: 'Gói phân tích ×10', description: 'Mười lượt phân tích cho người luyện nhiều.', cost: 900, grant: { reviewCredits: 10 }, badge: 'Hot' },
  { id: 'pro_trial_3h', group: 'trial', icon: 'gem', name: 'Dùng thử Pro 3 giờ', description: 'Mở khóa Pro dùng thử trong 3 giờ. Chi phí xu cao; thời hạn cộng dồn tối đa 24 giờ trên thiết bị này.', cost: 50000, grant: { proTrialMs: 3 * HOUR_MS }, badge: '50K xu' },
  { id: 'puzzle_5', group: 'puzzle', icon: 'puzzle', name: 'Thêm 5 câu đố', description: 'Cộng 5 lượt mở câu đố khi hết suất miễn phí.', cost: 80, grant: { puzzleCredits: 5 } },
  { id: 'puzzle_20', group: 'puzzle', icon: 'puzzle', name: 'Thêm 20 câu đố', description: 'Cộng 20 lượt mở câu đố.', cost: 260, grant: { puzzleCredits: 20 }, badge: 'Tiết kiệm' },
  { id: 'streak_freeze', group: 'boost', icon: 'shield', name: 'Bảo vệ chuỗi ngày', description: 'Nếu lỡ một ngày, chuỗi hoạt động không bị mất. Dùng tự động.', cost: 150, grant: { streakFreezes: 1 } },
  { id: 'coin_boost', group: 'boost', icon: 'bolt', name: 'Nhân đôi xu', description: 'Phần thưởng nhiệm vụ kế tiếp bạn nhận được sẽ x2 xu.', cost: 100, grant: { coinBoosts: 1 } }
]);
export const SHOP_GROUPS = Object.freeze([
  { id: 'analysis', title: 'Lượt phân tích', icon: 'chart' },
  { id: 'trial', title: 'Dùng thử Pro', icon: 'gem' },
  { id: 'puzzle', title: 'Câu đố', icon: 'puzzle' },
  { id: 'boost', title: 'Tiện ích', icon: 'bolt' }
]);
const INVENTORY_LIMITS = Object.freeze({ reviewCredits: 99, puzzleCredits: 500, streakFreezes: 5, coinBoosts: 10 });
export function createInventory() { return { reviewCredits: 0, puzzleCredits: 0, proTrialUntil: 0, streakFreezes: 0, coinBoosts: 0, creditGames: [] }; }
export function normalizeInventory(input, now = Date.now()) {
  const src = own(input) ? input : {};
  const inv = createInventory();
  for (const [key, max] of Object.entries(INVENTORY_LIMITS)) inv[key] = clampInt(src[key], 0, max);
  const until = Math.floor(Number(src.proTrialUntil) || 0);
  inv.proTrialUntil = until > now && until <= now + PRO_TRIAL_MAX_MS ? until : (until > now ? now + PRO_TRIAL_MAX_MS : 0);
  inv.creditGames = Array.isArray(src.creditGames) ? src.creditGames.map(id => String(id).slice(0, 120)).filter(Boolean).slice(-60) : [];
  return inv;
}
export function localDayKey(date = new Date()) {
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function previousDayKey(key) {
  const [year, month, day] = String(key).split('-').map(Number);
  const d = new Date(year, month - 1, day);
  d.setDate(d.getDate() - 1);
  return localDayKey(d);
}
export function createDailyState(date = new Date()) {
  const day = localDayKey(date);
  return { version: 2, day, lastVisitDay: day, streak: 1, coins: 0, missionProgress: { checkin: 1 }, claimed: [], stats: { gamesCompleted: 0, openingsVisited: 0, coachVisited: 0, moves: 0, captures: 0, wins: 0, puzzlesVisited: 0, puzzlesSolved: 0 }, activeCosmetic: 'classic', inventory: createInventory() };
}
export function normalizeDailyState(input, date = new Date()) {
  const base = createDailyState(date);
  if (!own(input)) return base;
  const state = {
    ...base, ...input, version: 2,
    day: typeof input.day === 'string' ? input.day : base.day,
    lastVisitDay: typeof input.lastVisitDay === 'string' ? input.lastVisitDay : '',
    streak: clampInt(input.streak), coins: clampInt(input.coins),
    missionProgress: own(input.missionProgress) ? { ...input.missionProgress } : {},
    claimed: Array.isArray(input.claimed) ? input.claimed.filter(id => DAILY_MISSIONS.some(m => m.id === id)) : [],
    stats: own(input.stats) ? { ...base.stats, ...input.stats } : { ...base.stats },
    inventory: normalizeInventory(input.inventory, date.getTime ? date.getTime() : Date.now()),
    activeCosmetic: COSMETICS.some(c => c.id === input.activeCosmetic) ? input.activeCosmetic : 'classic'
  };
  state.stats = Object.fromEntries(Object.entries(state.stats).map(([key, value]) => [key, clampInt(value)]));
  if (state.day !== localDayKey(date)) {
    const today = localDayKey(date);
    if (state.lastVisitDay !== today) {
      if (state.lastVisitDay === previousDayKey(today)) state.streak += 1;
      else if (state.inventory.streakFreezes > 0 && state.lastVisitDay === previousDayKey(previousDayKey(today))) { state.inventory.streakFreezes -= 1; state.streak += 1; }
      else state.streak = 1;
    }
    state.day = today; state.lastVisitDay = today; state.missionProgress = { checkin: 1 }; state.claimed = [];
  }
  state.missionProgress.checkin = 1;
  for (const mission of DAILY_MISSIONS) state.missionProgress[mission.id] = Math.min(mission.goal, clampInt(state.missionProgress[mission.id]));
  return state;
}
export function recordMissionEvent(input, event, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const missions = DAILY_MISSIONS.filter(item => item.event === event);
  if (!missions.length) return state;
  for (const mission of missions) state.missionProgress[mission.id] = Math.min(mission.goal, (state.missionProgress[mission.id] || 0) + 1);
  if (event === 'complete_game') state.stats.gamesCompleted = clampInt(state.stats.gamesCompleted + 1);
  if (event === 'visit_openings') state.stats.openingsVisited = clampInt(state.stats.openingsVisited + 1);
  if (event === 'visit_coach') state.stats.coachVisited = clampInt(state.stats.coachVisited + 1);
  if (event === 'make_move') state.stats.moves = clampInt(state.stats.moves + 1);
  if (event === 'capture_piece') state.stats.captures = clampInt(state.stats.captures + 1);
  if (event === 'win_game') state.stats.wins = clampInt(state.stats.wins + 1);
  if (event === 'visit_puzzles') state.stats.puzzlesVisited = clampInt(state.stats.puzzlesVisited + 1);
  if (event === 'solve_puzzle') state.stats.puzzlesSolved = clampInt(state.stats.puzzlesSolved + 1);
  return state;
}
export function claimMissionReward(input, missionId, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const mission = DAILY_MISSIONS.find(item => item.id === missionId);
  if (!mission) return { state, ok: false, reason: 'unknown_mission', reward: 0 };
  if ((state.missionProgress[mission.id] || 0) < mission.goal) return { state, ok: false, reason: 'not_completed', reward: 0 };
  if (state.claimed.includes(mission.id)) return { state, ok: false, reason: 'already_claimed', reward: 0 };
  state.claimed.push(mission.id);
  const boosted = state.inventory.coinBoosts > 0;
  const reward = boosted ? mission.reward * 2 : mission.reward;
  if (boosted) state.inventory.coinBoosts -= 1;
  state.coins = clampInt(state.coins + reward);
  // "Chuỗi nhiệm vụ" means claiming five distinct rewards, not merely finishing games.
  // Claiming the streak reward itself must not satisfy its own progress.
  if (mission.id !== 'streak_bonus') {
    const streakMission = DAILY_MISSIONS.find(item => item.id === 'streak_bonus');
    if (streakMission) {
      state.missionProgress.streak_bonus = Math.min(
        streakMission.goal,
        clampInt(state.missionProgress.streak_bonus) + 1
      );
    }
  }
  return { state, ok: true, reason: '', reward, boosted };
}
export function purchaseShopItem(input, itemId, date = new Date()) {
  const state = normalizeDailyState(input, date); const item = SHOP_ITEMS.find(c => c.id === itemId);
  if (!item) return { state, ok: false, reason: 'unknown_item' };
  if (state.coins < item.cost) return { state, ok: false, reason: 'not_enough_coins' };
  const now = date.getTime ? date.getTime() : Date.now();
  const inv = state.inventory;
  for (const [key, amount] of Object.entries(item.grant)) {
    if (key === 'proTrialMs') {
      const base = Math.max(now, inv.proTrialUntil || 0);
      if (base + amount > now + PRO_TRIAL_MAX_MS) return { state, ok: false, reason: 'at_limit' };
      inv.proTrialUntil = base + amount;
    } else {
      if (inv[key] + amount > INVENTORY_LIMITS[key]) return { state, ok: false, reason: 'at_limit' };
      inv[key] += amount;
    }
  }
  state.coins -= item.cost;
  return { state, ok: true, reason: '', item };
}
export function proTrialActive(input, now = Date.now()) { return normalizeInventory(own(input) ? input.inventory : null, now).proTrialUntil > now; }
export function proTrialLeftMs(input, now = Date.now()) { return Math.max(0, normalizeInventory(own(input) ? input.inventory : null, now).proTrialUntil - now); }
/** Use a purchased review credit. The same game is never charged twice. Pro trial makes reviews free while it lasts. */
export function spendReviewCredit(input, gameId = '', date = new Date()) {
  const state = normalizeDailyState(input, date);
  const now = date.getTime ? date.getTime() : Date.now();
  const inv = state.inventory;
  if (inv.proTrialUntil > now) return { state, ok: true, via: 'trial' };
  const id = String(gameId || '');
  if (id && inv.creditGames.includes(id)) return { state, ok: true, via: 'same-game' };
  if (inv.reviewCredits <= 0) return { state, ok: false, via: 'none' };
  inv.reviewCredits -= 1;
  if (id) inv.creditGames = [...inv.creditGames, id].slice(-60);
  return { state, ok: true, via: 'credit', left: inv.reviewCredits };
}
export function spendPuzzleCredit(input, date = new Date()) {
  const state = normalizeDailyState(input, date);
  if (state.inventory.puzzleCredits <= 0) return { state, ok: false };
  state.inventory.puzzleCredits -= 1;
  return { state, ok: true, left: state.inventory.puzzleCredits };
}
export function getMissionSummary(input, date = new Date()) {
  const state = normalizeDailyState(input, date);
  const completed = DAILY_MISSIONS.filter(m => (state.missionProgress[m.id] || 0) >= m.goal).length;
  return { coins: state.coins, streak: state.streak, completed, total: DAILY_MISSIONS.length, claimed: state.claimed.length };
}
