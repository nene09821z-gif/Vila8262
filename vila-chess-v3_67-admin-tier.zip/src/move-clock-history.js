/**
 * Clock snapshots for undo/redo. A snapshot represents the clock immediately
 * before a ply; lastTickAt is deliberately refreshed on restore to avoid the
 * restored player losing time for the period spent thinking/using the menu.
 */
export function captureClockSnapshot(clockState, clockFlagged = null) {
  const state = clockState && typeof clockState === 'object' ? clockState : {};
  return {
    enabled: Boolean(state.enabled),
    running: Boolean(state.running),
    remaining: {
      w: clampTime(state.remaining?.w),
      b: clampTime(state.remaining?.b)
    },
    incrementMs: clampTime(state.incrementMs, 60_000),
    clockFlagged: clockFlagged === 'w' || clockFlagged === 'b' ? clockFlagged : null
  };
}

export function recordClockSnapshot(history, ply, snapshot) {
  if (!Array.isArray(history) || !Number.isInteger(ply) || ply < 0 || !snapshot) return false;
  history[ply] = captureClockSnapshot(snapshot, snapshot.clockFlagged ?? null);
  return true;
}

export function restoreClockSnapshot(snapshot, now = 0) {
  if (!snapshot || typeof snapshot !== 'object' || !snapshot.remaining) return null;
  return {
    enabled: Boolean(snapshot.enabled),
    running: Boolean(snapshot.running),
    remaining: {
      w: clampTime(snapshot.remaining.w),
      b: clampTime(snapshot.remaining.b)
    },
    incrementMs: clampTime(snapshot.incrementMs, 60_000),
    lastTickAt: Number.isFinite(Number(now)) ? Number(now) : 0,
    clockFlagged: snapshot.clockFlagged === 'w' || snapshot.clockFlagged === 'b' ? snapshot.clockFlagged : null
  };
}

export function cloneClockHistoryRange(history, start, end) {
  if (!Array.isArray(history)) return [];
  return history.slice(Math.max(0, start | 0), Math.max(0, end | 0)).map(item => item ? captureClockSnapshot(item, item.clockFlagged ?? null) : null);
}

function clampTime(value, max = 24 * 60 * 60 * 1000) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(max, n));
}
