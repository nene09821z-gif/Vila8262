import { Chess as BaseChess } from 'chess.js';
import { uiIcon, uiTile, hydrateIcons, startIconObserver } from './ui-icons.js';
import { createCachedChess } from './cached-chess.js';
// chess.js recomputes history()/pgn()/isGameOver() from scratch on each call; cache them per position.
const Chess = createCachedChess(BaseChess);
import { resolveEngineProfile, nextEngineFallback, engineAssetFile } from './engine-profile.js';
import { createEngineHealthState, observeEngineLine, failEngineHealth, describeEngineHealth, engineStartupDurationMs, splitUciOutput } from './engine-health.js';
import { sealLocalGameRecoverySnapshot, validateLocalGameRecoverySnapshot } from './game-recovery.js';
import { LegacyUciEngine } from './legacy-uci-engine.js';
import { formatUciScore, parseUciInfoLine } from './analysis-utils.js';
import { isCurrentAnalysisSession, mergeAnalysisVariation } from './analysis-session.js';
import { calculateBoardFrameMaxWidth, calculateChessSquareSize } from './board-layout.js';
import { CLOCK_PRESETS, RANKED_CLOCK_PRESETS, classifyTimeControl, formatClockTime, parseClockPreset, consumeClockTick } from './clock.js';
import { OPENINGS } from './openings.js';
import { mergeOpeningEntries } from './opening-catalog.js';
import { findOpeningBookMove } from './opening-book.js';
import { generateOfflinePuzzleInWorker as generateOfflinePuzzle, generateDailyPuzzleInWorker, isPuzzleAnswerLegal } from './puzzle-worker-client.js';
import { loadPuzzleHistory, rememberPuzzle } from './puzzle-history.js';
import { pickBankPuzzle } from './puzzle-bank.js';
import { prepareLichessDailyPuzzle, validateCachedPuzzleLine, uciToMove, lichessDifficultyForProgress, lichessPuzzleUrlForDifficulty, lichessDailyPuzzleUrl } from './lichess-puzzle.js';
import { LICHESS_PUZZLE_POOL_LIMIT, normalizePuzzlePool, upsertPuzzlePool, chooseUnusedPuzzle, puzzlePoolKey } from './puzzle-pool.js';
import { selectVerifiedTacticalCandidate, isMateInOneTheme, localizePuzzleTheme, localizePuzzleThemes } from './puzzle-quality.js';
import { summarizeCapturedMaterial } from './material-tracker.js';
import { getPremoveLegalMoves, appendPremove, buildPremovePosition, takeNextPremove, premoveSquares, isPremoveSquare, describePremoveQueue } from './premove.js';
import { slideDurationMs, SLIDE_EASING, premoveGhostPieces, slideKeyframes } from './board-motion.js';
import { attachBoardDrag, slideBoardPiece, slideFromMove } from './board-interact.js';
import { getPersonaOpeningNames, pickPersonaBookMove } from './bot-personas.js';
import { recognizeOpening } from './opening-recognition.js';
import { classifyMoveQuality, winChance } from './game-review.js';
import { buildMistakeTrainingItems, loadMistakeTrainingItems, saveMistakeTrainingItems, upsertMistakeTrainingItems, recordMistakeAttempt, selectNextMistake, summarizeMistakeTraining } from './mistake-training.js';
import {
  computeGameAccuracy,
  buildReviewDashboard,
  BOT_ELO_PRESETS,
  resolveBotEloPreset,
  botThinkDelayMs,
  matchActionBarMarkup,
  puzzleStreakLabel,
  puzzleNextButtonLabel,
  BOARD_THEME_CATALOG,
  SOUND_THEME_CATALOG,
  resolveBoardTheme,
  matchmakingStatusText,
  openingExplorerContinuations,
  openingExplorerMarkup,
  LESSON_CATALOG,
  lessonProgressSummary,
  lessonReaderMarkup,
  findLessonChapter,
  clubHomeMarkup,
  friendChallengePayload,
  spectatorRoomLabel,
  boardSquareClasses
} from './chesscom-ux.js';

import { detectSacrifice } from './review-brilliance.js';
import { ACHIEVEMENT_CATEGORIES, ACHIEVEMENT_TOTAL, summarizeAchievements, listAchievements, newlyUnlocked, formatCount } from './achievements.js';
import { PLAN_CATALOG, FREE_PUZZLE_LIMIT, puzzleAccess, normalizeEntitlement, effectivePlan, reviewAccess, consumeFreeReview, planStatusLabel, daysLeft } from './plans.js';
import { BILLING_EVENT, nativeBillingBridge, planPurchaseUi, createPurchaseQueue, billingErrorMessage } from './billing-client.js';
import { buildOpeningBookPrefixes, classifyReviewedMove, estimateMoveLoss, scoreSideToWhiteCentipawns, reviewSymbolForJudgement, reviewSymbolDescription } from './game-review.js';
import { groupReviewedMoves, summarizeReviewSide } from './review-list.js';
import {
  ARENA_FORMATS, ARENA_MAX_PLAYERS, ARENA_GAMES_PER_PAIR_OPTIONS, isValidArenaFormat, pickArenaOpenings, buildArenaSchedule, countArenaGames,
  knockoutRound, knockoutTieWinner, createArenaStandings, recordArenaResult, rankArenaStandings, arenaCrosstable, formatPoints,
  adjudicateAtPlyLimit, formatArenaDuration, estimateArenaRemaining
} from './arena-tournament.js';
import { resolveStockfishStrength, resolveBotStrength, rescueProfileForStrength, isStockfishBotMode } from './elo-strength.js';
import { chooseBeginnerMove, resolveBeginnerSearchBudget } from './beginner-strength.js';
import { resolveArenaMoveTimeMs, resolveArenaSearchSettings, resolveArenaStyleTolerance } from './arena-strength.js';
import { resolveOfflineSearchBudget, resolveReviewMoveTimeMs } from './engine-budgets.js';
import { DEFAULT_VISUAL_SETTINGS, normalizeVisualSettings } from './visual-settings.js';
import { captureClockSnapshot, recordClockSnapshot, restoreClockSnapshot, cloneClockHistoryRange } from './move-clock-history.js';
import { isMoveContextCurrent } from './move-input.js';
import { chooseAlternateMoveAsync, getLastOfflineEngineStats, OFFLINE_ENGINE_CATALOG, OFFLINE_ENGINE_IDS, offlineEngineShortName } from './alternate-engine.js';
import { pieceSvgMarkup, ensurePieceSprite, PIECE_STYLES, getPieceStyle, setPieceStyle } from './pieces.js';
import { playBoardSound, playGameSound, unlockBoardSound, isChessMusicPlaying, setChessMusicPlaying, setChessMusicYoutube, getChessMusicYoutube, getChessMusicTrack, getChessMusicTitle, setChessMusicTrack, listChessMusicTracks, nudgeChessMusic } from './sound.js';
import { parseYoutubeUrl } from './youtube-music.js';
import { applyEloResult } from './elo.js';
import { DEFAULTS, DEFAULT_BACKEND_URL, normalizeSettings } from './settings-schema.js';
import { DAILY_MISSIONS, COSMETICS, SHOP_ITEMS, SHOP_GROUPS, normalizeDailyState, recordMissionEvent, claimMissionReward, purchaseShopItem, spendReviewCredit, spendPuzzleCredit, proTrialActive, proTrialLeftMs, getMissionSummary } from './daily-progress.js';
import { addNotification, clearReadNotifications, markAllNotificationsRead, markNotificationRead, normalizeNotifications, unreadNotificationCount } from './notifications.js';
import { buildSystemChecks, REQUIRED_OPENING_COUNT } from './system-health.js';
import {
  createSolvedRubikCube, applyRubikMove, invertRubikMove, scrambleRubikMoves,
  getRubikFaceStickers, isRubikSolved, create2048Board, move2048, has2048Moves,
  createScrambledSlidingPuzzle, moveSlidingPuzzleTile, isSlidingPuzzleSolved,
} from './mini-games.js';
import { chooseTicTacToeMove, ticTacToeOutcome } from './tic-tac-toe.js';
/* One canonical CSS entrypoint: component rules remain ordered inside the consolidated bundle. */
import './vila-professional.css';
import { syncHistoryToCloud } from './cloud-sync.js';
import { showVilaIntro } from './vila-intro.js';
import './vila-intro.css';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const STORAGE_KEY = 'tubor.chess.settings.v1';
const lichessTokenKey = 'tubor.chess.lichessToken.session';
const RATING_KEY = 'chessbot.local.rating.v1';
const RATING_HISTORY_KEY = 'chessbot.local.rating.history.v1';
const GAME_HISTORY_KEY = 'vila.chess.saved-games.v1';
const LOCAL_GAME_RECOVERY_KEY = 'vila.chess.local-game-recovery.v1';
const SOCIAL_SESSION_KEY = 'vila.chess.social.session.v1';
const SOCIAL_USER_KEY = 'vila.chess.social.user.v1';
const OFFLINE_GUEST_MODE_KEY = 'vila.chess.offline-guest.v1';
const DAILY_PROGRESS_KEY = 'vila.chess.daily-progress.v1';
const NOTIFICATIONS_KEY = 'vila.chess.notifications.v1';
const MUSIC_AUTOSTART_KEY = 'vila.chess.music-autostart.v1';
const BOARD_THEME_KEY = 'vila.chess.board-theme.v1';
const VISUAL_SETTINGS_KEY = 'vila.chess.visual-settings.v1';

export const BOT_DIFFICULTY_LEVELS = Object.freeze([
  { level: 1, name: 'Người mới (Dễ)', elo: 600, badge: 'Dễ', depth: 8, timeMs: 800, desc: 'Nước đi cơ bản, ít bẫy chiến thuật' },
  { level: 2, name: 'Tập sự (Căn bản)', elo: 1000, badge: 'Tập sự', depth: 10, timeMs: 1200, desc: 'Phát triển quân đều, phù hợp luyện tập' },
  { level: 3, name: 'Kỳ thủ (Khá)', elo: 1500, badge: 'Khá', depth: 14, timeMs: 1600, desc: 'Chiến thuật nhạy bén, kiểm soát trung tâm' },
  { level: 4, name: 'Kiện tướng (Nâng cao)', elo: 2000, badge: 'Kiện tướng', depth: 18, timeMs: 2200, desc: 'Đòn phối hợp sâu, tấn công chính xác' },
  { level: 5, name: 'Đại kiện tướng (Bậc thầy)', elo: 2600, badge: 'Bậc thầy', depth: 24, timeMs: 3000, desc: 'Thế cờ đỉnh cao, tính toán đa tầng' },
  { level: 6, name: 'Stockfish Tối đa (Vô địch)', elo: 3200, badge: 'Vô địch', depth: 30, timeMs: 4000, desc: 'Sức mạnh tối đa không giới hạn' }
]);

function getBotDifficultyBadge(elo = 2600, mode = 'elo') {
  if (mode !== 'elo') return 'Vô địch · 3200+';
  const val = Number(elo) || 2600;
  if (val <= 700) return 'Dễ · Elo 600';
  if (val <= 1200) return 'Tập sự · Elo 1000';
  if (val <= 1700) return 'Khá · Elo 1500';
  if (val <= 2200) return 'Kiện tướng · Elo 2000';
  if (val <= 2800) return 'Bậc thầy · Elo 2600';
  return 'Vô địch · Elo 3200';
}

function getCurrentBotLevel() {
  if (settings.botStrengthMode !== 'elo') return BOT_DIFFICULTY_LEVELS[5];
  const elo = Number(settings.botElo) || 2600;
  if (elo <= 700) return BOT_DIFFICULTY_LEVELS[0];
  if (elo <= 1200) return BOT_DIFFICULTY_LEVELS[1];
  if (elo <= 1700) return BOT_DIFFICULTY_LEVELS[2];
  if (elo <= 2200) return BOT_DIFFICULTY_LEVELS[3];
  if (elo <= 2800) return BOT_DIFFICULTY_LEVELS[4];
  return BOT_DIFFICULTY_LEVELS[5];
}

function applyBotDifficultyLevel(lvlNum) {
  const target = BOT_DIFFICULTY_LEVELS[lvlNum - 1] || BOT_DIFFICULTY_LEVELS[4];
  if (target.level === 6) {
    settings.botStrengthMode = 'max';
    settings.botSkill = 20;
    settings.botDepth = target.depth;
    settings.botMoveTimeMs = target.timeMs;
  } else {
    settings.botStrengthMode = 'elo';
    settings.botElo = target.elo;
    settings.botSkill = Math.max(1, Math.min(20, Math.round(target.elo / 160)));
    settings.botDepth = target.depth;
    settings.botMoveTimeMs = target.timeMs;
  }
  saveSettings();
  renderView();
  toast(`Đã chọn cấp độ bot: ${target.name} (Elo ${target.level === 6 ? '3200+' : target.elo})`, 'success');
}
let musicAutostart = (() => { try { return localStorage.getItem(MUSIC_AUTOSTART_KEY) !== 'false'; } catch { return true; } })();
let musicAutostartHandled = false;
function readSocialCache(key, fallback = null) { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; } }
function syncMusicControls() {
  const active = isChessMusicPlaying();
  const appToggle = $('#appMusicToggle');
  const homeToggle = $('#homeToggleChessMusic');
  const playToggle = $('#toggleChessMusic');
  for (const button of [appToggle, homeToggle]) {
    if (!button) continue;
    button.setAttribute('aria-pressed', String(active));
    button.setAttribute('aria-label', active ? 'Tắt nhạc nền' : 'Bật nhạc nền');
    button.title = active ? 'Nhạc nền đang phát · chạm để tắt' : 'Bật/tắt nhạc nền cờ vua';
    button.classList.toggle('music-is-playing', active);
  }
  if (homeToggle) homeToggle.textContent = active ? '🎧 Đang phát · Tắt nhạc' : '🎧 Bật nhạc nền';
  if (playToggle) {
    playToggle.textContent = active ? '🎧 Nhạc · Đang phát' : '🎧 Nhạc';
    playToggle.setAttribute('aria-pressed', String(active));
  }
}
const YOUTUBE_MUSIC_KEY = 'vila.chess.music-youtube.v1';
function savedYoutubeMusicUrl() { try { return localStorage.getItem(YOUTUBE_MUSIC_KEY) || ''; } catch { return ''; } }
function musicLibraryMarkup({ compact = false } = {}) {
  const active = getChessMusicTrack();
  const custom = Boolean(getChessMusicYoutube());
  const saved = savedYoutubeMusicUrl();
  return `<section class="music-library ${compact ? 'is-compact' : ''}" aria-label="Nhạc nền trực tuyến"><div class="music-library-head"><div><small class="eyebrow">NHẠC NỀN · TRỰC TUYẾN</small><h3>Remix & nhạc buồn TikTok</h3></div><button type="button" class="music-master-btn" data-music-master aria-pressed="${isChessMusicPlaying()}">${isChessMusicPlaying() ? '⏸ Tắt nhạc' : '▶ Phát nhạc'}</button></div>
    <ul class="music-track-list" role="list">${listChessMusicTracks().map((track, index) => `<li><button type="button" class="music-track ${!custom && active === track.id ? 'is-active' : ''}" data-music-track="${esc(track.id)}"><span class="music-track-index">${String(index + 1).padStart(2, '0')}</span><span class="music-track-copy"><b>${esc(track.name)}</b><small>${esc(track.mood)}</small></span><span class="music-track-play" aria-hidden="true">${!custom && active === track.id && isChessMusicPlaying() ? '♫' : '▶'}</span></button></li>`).join('')}</ul>
    <div class="yt-music-form"><label class="field-label" for="ytMusicUrl">Dán link YouTube</label><div class="yt-music-row"><input id="ytMusicUrl" class="field" inputmode="url" autocomplete="off" placeholder="Dán link YouTube vào đây…" value="${esc(saved)}"/><button id="ytMusicPlay" type="button" class="primary-btn">▶ Phát</button></div></div></section>`;
}
function playYoutubeMusicFromUi(rawUrl) {
  const parsed = parseYoutubeUrl(rawUrl);
  if (!parsed) { toast('Link YouTube không hợp lệ.'); return; }
  try { localStorage.setItem(YOUTUBE_MUSIC_KEY, String(rawUrl).trim()); } catch {}
  musicAutostartHandled = true;
  setChessMusicYoutube(parsed, { onFailure: error => { toast(`${error?.message || 'YouTube không phát được.'} Đã chuyển về danh sách nhạc của app.`); refreshMusicLibraryUi(); } });
  if (!isChessMusicPlaying()) setChessMusicPlaying(true);
  syncMusicControls();
  toast('Đang mở nhạc từ YouTube…');
}
function refreshMusicLibraryUi() {
  syncMusicControls();
  const active = getChessMusicTrack(); const custom = Boolean(getChessMusicYoutube()); const playing = isChessMusicPlaying();
  $$('[data-music-track]').forEach(button => {
    const on = !custom && button.dataset.musicTrack === active;
    button.classList.toggle('is-active', on);
    const icon = button.querySelector('.music-track-play'); if (icon) icon.textContent = on && playing ? '♫' : '▶';
  });
  $$('[data-music-master]').forEach(button => { button.setAttribute('aria-pressed', String(playing)); button.textContent = playing ? '⏸ Tắt nhạc' : '▶ Phát nhạc'; });
}
function wireYoutubeMusicControls() {
  const input = $('#ytMusicUrl');
  $('#ytMusicPlay')?.addEventListener('click', () => playYoutubeMusicFromUi(input?.value || ''));
  input?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); playYoutubeMusicFromUi(input.value); } });
  $$('[data-music-track]').forEach(button => button.addEventListener('click', () => {
    musicAutostartHandled = true;
    try { localStorage.removeItem(YOUTUBE_MUSIC_KEY); } catch {}
    setChessMusicTrack(button.dataset.musicTrack);
    if (!isChessMusicPlaying()) setChessMusicPlaying(true);
    refreshMusicLibraryUi();
  }));
  $$('[data-music-master]').forEach(button => button.addEventListener('click', () => { toggleChessMusicFromUi(); refreshMusicLibraryUi(); }));
  $('#homeToggleChessMusic')?.addEventListener('click', toggleChessMusicFromUi);
}
function toggleChessMusicFromUi() {
  musicAutostartHandled = true;
  const enabled = setChessMusicPlaying(!isChessMusicPlaying());
  syncMusicControls();
  if (!enabled) toast('Đã tắt nhạc nền.');
}
function handleMusicAutostartGesture(event) {
  if (isChessMusicPlaying()) { nudgeChessMusic(); return; }
  if (!musicAutostart || musicAutostartHandled) return;
  const target = event.target;
  if (target?.closest?.('#appMusicToggle, #toggleChessMusic, #homeToggleChessMusic, #musicAutostartSetting, .music-library, #vilaYtCard')) return;
  musicAutostartHandled = true;
  setChessMusicPlaying(true);
  syncMusicControls();
}
function readDailyProgress() {
  let raw = null;
  try { raw = localStorage.getItem(DAILY_PROGRESS_KEY); } catch {}
  const stored = raw ? (() => { try { return JSON.parse(raw); } catch { return null; } })() : null;
  const state = normalizeDailyState(stored, new Date());
  const normalized = JSON.stringify(state);
  if (raw !== normalized) { try { localStorage.setItem(DAILY_PROGRESS_KEY, normalized); } catch { /* Progress remains best-effort when storage is disabled. */ } }
  applyBoardCosmetic(state.activeCosmetic);
  return state;
}
function persistDailyProgress(state) {
  try { localStorage.setItem(DAILY_PROGRESS_KEY, JSON.stringify(state)); } catch { /* Local progression is optional; chess stays playable if storage is unavailable. */ }
  applyBoardCosmetic(state?.activeCosmetic || 'classic');
}
function getSelectedBoardTheme(fallback = 'classic') {
  let saved = '';
  try { saved = localStorage.getItem(BOARD_THEME_KEY) || ''; } catch {}
  if (COSMETICS.some(item => item.id === saved)) return saved;
  return COSMETICS.some(item => item.id === fallback) ? fallback : 'classic';
}
function applyBoardCosmetic(id) {
  if (typeof document === 'undefined') return;
  document.documentElement.dataset.boardTheme = getSelectedBoardTheme(id);
}
function selectBoardTheme(id) {
  if (!COSMETICS.some(item => item.id === id)) return false;
  try { localStorage.setItem(BOARD_THEME_KEY, id); } catch {}
  applyBoardCosmetic(id);
  return true;
}
const LIFETIME_KEY = 'vila.chess.lifetime.v1';
const LIFETIME_EVENTS = new Set(['solve_puzzle', 'make_move', 'complete_game', 'win_game', 'draw_game', 'capture_piece', 'check_king', 'castle', 'promote', 'analyze_game', 'lesson_done', 'checkin', 'claim_mission', 'play_mini_game']);
function readLifetime() {
  try { const v = JSON.parse(localStorage.getItem(LIFETIME_KEY) || '{}'); return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; } catch { return {}; }
}
/** Counter values for every achievement metric (lifetime counters + the puzzle records kept elsewhere). */
function achievementStats() {
  const life = readLifetime();
  const num = key => { try { return Math.max(0, Math.floor(Number(localStorage.getItem(key)) || 0)); } catch { return 0; } };
  return {
    ...life,
    solve_puzzle: Math.max(Number(life.solve_puzzle) || 0, num('vila.chess.puzzles.solved.v1')),
    puzzle_best_streak: num('vila.chess.puzzles.bestStreak.v1'),
    rush_best: num('vila.chess.puzzles.rush-best.v1')
  };
}
let lastAchievementToastAt = 0;
function trackLifetimeEvent(event) {
  if (!LIFETIME_EVENTS.has(event)) return;
  try {
    const before = achievementStats();
    const life = readLifetime();
    life[event] = Math.min(10_000_000, (Number(life[event]) || 0) + 1);
    localStorage.setItem(LIFETIME_KEY, JSON.stringify(life));
    const fresh = newlyUnlocked(before, achievementStats()).filter(item => item.points >= 10);
    if (fresh.length && Date.now() - lastAchievementToastAt > 2500) {
      lastAchievementToastAt = Date.now();
      toast(`🏅 Thành tựu mới: ${fresh[0].title} · ${fresh[0].tierLabel}${fresh.length > 1 ? ` (+${fresh.length - 1} nữa)` : ''}`, 'success');
    }
  } catch { /* storage unavailable: achievements simply do not advance */ }
}
function recordDailyEvent(event) {
  trackLifetimeEvent(event);
  const before = readDailyProgress();
  const priorStreak = Number(getMissionSummary(before).streak || 0);
  const state = recordMissionEvent(before, event, new Date());
  persistDailyProgress(state);
  const nextStreak = Number(getMissionSummary(state).streak || 0);
  if (nextStreak > priorStreak && nextStreak > 1) addAppNotification({ title: `🔥 Chuỗi ${nextStreak} ngày`, message: `Bạn đã duy trì hoạt động ${nextStreak} ngày liên tiếp. Tiếp tục luyện cờ mỗi ngày nhé!`, type: 'success', sourceKey: `streak:${state.day}:${nextStreak}` });
  return state;
}
const persistedSocialToken = (() => { try { return localStorage.getItem(SOCIAL_SESSION_KEY) || ''; } catch { return ''; } })();
let offlineGuestMode = (() => { try { return localStorage.getItem(OFFLINE_GUEST_MODE_KEY) === '1'; } catch { return false; } })();
let socialState = { token: persistedSocialToken, user: persistedSocialToken ? readSocialCache(SOCIAL_USER_KEY) : null, friends: [], incoming: [], outgoing: [], searchResults: [], leaderboard: [], adminOverview: null, adminUsers: [], adminReports: [], auditEvents: [], error: '', loading: false };
let appNotifications = (() => { try { return normalizeNotifications(JSON.parse(localStorage.getItem(NOTIFICATIONS_KEY) || '[]')); } catch { return []; } })();
let healthBackendStatus = 'unknown';
function saveSocialSession(token, user) {
  const nextToken = String(token || '').trim();
  if (nextToken) {
    offlineGuestMode = false;
    try { localStorage.removeItem(OFFLINE_GUEST_MODE_KEY); } catch {}
  }
  socialState.token = nextToken;
  socialState.user = user && typeof user === 'object' ? user : null;
  let saved = true;
  try {
    if (nextToken) localStorage.setItem(SOCIAL_SESSION_KEY, nextToken);
    else localStorage.removeItem(SOCIAL_SESSION_KEY);
    if (socialState.user) localStorage.setItem(SOCIAL_USER_KEY, JSON.stringify(socialState.user));
    else localStorage.removeItem(SOCIAL_USER_KEY);
  } catch (error) {
    saved = false;
    console.warn('[Cờ Vua] Account session could not be persisted on this device:', error?.message || error);
  }
  if (!nextToken) {
    socialState.friends = [];
    socialState.incoming = [];
    socialState.outgoing = [];
    socialState.searchResults = [];
    socialState.leaderboard = [];
    socialState.adminOverview = null;
    socialState.adminUsers = [];
    socialState.auditEvents = [];
  }
  syncSocialNav();
  return saved;
}
function persistNotifications() {
  try { localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(appNotifications)); return true; }
  catch (error) { console.warn('[Cờ Vua] Notification inbox could not be saved:', error?.message || error); return false; }
}
function syncInboxBadge() {
  const badge = $('#inboxBadge');
  if (!badge) return;
  const count = unreadNotificationCount(appNotifications);
  badge.textContent = count > 99 ? '99+' : String(count);
  badge.hidden = count < 1;
  $('#openInbox')?.setAttribute('aria-label', count ? `Hộp thư, ${count} thông báo chưa đọc` : 'Mở hộp thư');
}
function addAppNotification(payload) {
  const result = addNotification(appNotifications, payload);
  if (!result.added) return result.notification;
  appNotifications = result.items;
  persistNotifications();
  syncInboxBadge();
  return result.notification;
}
function syncSocialNav() {
  const adminTab = $('[data-view="admin"]');
  if (adminTab) adminTab.hidden = socialState.user?.role !== 'admin';
  const user = socialState.user;
  const avatar = $('#accountAvatar');
  const label = $('#accountShortcutLabel');
  const shortcut = $('#accountShortcut');
  if (avatar) { avatar.textContent = user ? avatarEmoji(user) : '♙'; avatar.style.background = user ? avatarBackground(user) : ''; avatar.title = user ? `Avatar ${Number(user.avatarId || 0) + 1}/1000` : 'Tài khoản'; }
  if (label) label.textContent = user ? String(user.displayName || user.username || 'Tài khoản').slice(0, 14) : 'Tài khoản';
  if (shortcut) {
    shortcut.title = user ? `${user.displayName || user.username} · mở hồ sơ` : 'Đăng nhập hoặc tạo tài khoản';
    shortcut.setAttribute('aria-label', shortcut.title);
  }
  syncInboxBadge();
}
function socialBackendBase() {
  const configured = String(settings.backendUrl || DEFAULT_BACKEND_URL).trim().replace(/\/$/, '');
  // During Vite local development, send community requests through the same-origin
  // /api proxy to the paired Express server. This keeps chat/account testing on the
  // backend that `npm run dev` actually starts, instead of silently hitting the live Worker.
  const isLocalDev = import.meta.env?.DEV === true
    && ['localhost', '127.0.0.1', '::1'].includes(String(location.hostname || '').toLowerCase());
  if (isLocalDev && (!configured || configured === DEFAULT_BACKEND_URL)) return '';
  if (configured) return configured;
  if (location.protocol === 'http:' || location.protocol === 'https:') return '';
  throw new Error('Không thể xác định máy chủ online mặc định. Chơi cờ với bot ngoại tuyến vẫn dùng được; chủ dự án cần kiểm tra cấu hình bản phát hành.');
}
async function socialApi(path, options = {}) {
  const base = socialBackendBase();
  const headers = { ...(options.headers || {}) };
  if (socialState.token) headers.Authorization = `Bearer ${socialState.token}`;
  if (options.body && typeof options.body === 'string') headers['Content-Type'] = 'application/json';
  let response;
  try { response = await fetch(`${base}/api/social${path}`, { ...options, headers, signal: options.signal || AbortSignal.timeout(15000) }); }
  catch (networkError) { throw new Error(networkError?.name === 'TimeoutError' || networkError?.name === 'AbortError' ? 'Dịch vụ online phản hồi quá chậm. Kiểm tra mạng và thử lại.' : 'Không kết nối được máy chủ online mặc định. Kiểm tra mạng hoặc thử lại sau; chủ dự án cần kiểm tra triển khai backend.'); }
  const type = response.headers.get('content-type') || '';
  const data = type.includes('application/json') ? await response.json().catch(() => ({})) : await response.text().catch(() => '');
  if (!response.ok) {
    const failure = new Error(data?.error || data?.message || (typeof data === 'string' && !/^\s*</.test(data) ? data : '') || `HTTP ${response.status}`);
    failure.status = response.status;
    throw failure;
  }
  // Sliding session: the server swaps an aging token for a fresh one on /auth/me.
  if (path === '/auth/me' && data?.token && data?.user && socialState.token && headers.Authorization === `Bearer ${socialState.token}`) saveSocialSession(data.token, data.user);
  return data;
}
function isSessionRejected(error) {
  const status = Number(error?.status);
  if (status === 401) return true;
  return status === 403 && /khóa|Không tìm thấy tài khoản/i.test(String(error?.message || ''));
}
const AVATAR_EMOJIS = ['🐼','🐱','🐰','🦊','🐻','🐨','🐯','🦁','🐸','🐵','🐧','🐤','🦄','🐙','🦋','🐢','🐳','🦖','🐥','🐹','🐣','🦉','🦝','🦦','🐺','🐮','🐷','🐶','🐴','🦓','🐬','🦚','🦩','🦔','🐝','🐞','🦀','🦕','🐲','👾'];
const AVATAR_BACKGROUNDS = ['#ffe4e6','#fce7f3','#fae8ff','#ede9fe','#e0e7ff','#dbeafe','#cffafe','#ccfbf1','#d1fae5','#dcfce7','#ecfccb','#fef9c3','#fef3c7','#ffedd5','#fed7aa','#e5e7eb','#e2e8f0','#e0f2fe','#f3e8ff','#c7d2fe','#fde68a','#fecaca','#bbf7d0','#bae6fd','#ddd6fe'];
function avatarParts(user) {
  const raw = Number(user?.avatarId);
  const id = Number.isInteger(raw) && raw >= 0 && raw < 1000 ? raw : (parseInt(String(user?.id || user?.username || 'vila').replace(/[^a-f0-9]/gi, '').slice(0, 8) || '0', 16) % 1000);
  return { id, emoji: AVATAR_EMOJIS[id % AVATAR_EMOJIS.length], background: AVATAR_BACKGROUNDS[Math.floor(id / AVATAR_EMOJIS.length) % AVATAR_BACKGROUNDS.length] };
}
function avatarEmoji(user) { return avatarParts(user).emoji; }
function avatarBackground(user) { return avatarParts(user).background; }
function avatarStyle(user) { const part = avatarParts(user); return `background:${part.background};color:#25334a;border-color:${part.background};` ; }

function hideAccountGate() {
  $('#vilaAccountGate')?.remove();
  document.body.classList.remove('account-gated');
  const appRoot = $('#app');
  if (appRoot) appRoot.hidden = false;
}
function showAccountGate(mode = 'login', notice = '') {
  const allowed = ['login', 'register', 'forgot', 'reset'];
  const active = allowed.includes(mode) ? mode : 'login';
  document.body.classList.add('account-gated');
  const appRoot = $('#app');
  if (appRoot) appRoot.hidden = true;
  let gate = $('#vilaAccountGate');
  if (!gate) { gate = document.createElement('div'); gate.id = 'vilaAccountGate'; gate.className = 'vila-account-gate'; document.body.appendChild(gate); }
  const notices = notice ? `<p class="vila-auth-status" role="status">${esc(notice)}</p>` : '';
  const switcher = `<div class="vila-auth-switch"><button type="button" data-auth-mode="login" class="${active === 'login' ? 'active' : ''}">Đăng nhập</button><button type="button" data-auth-mode="register" class="${active === 'register' ? 'active' : ''}">Tạo tài khoản</button></div>`;
  let content = '';
  if (active === 'login') content = `${switcher}<form data-auth-submit="login"><label>Tên tài khoản</label><input name="identity" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required maxlength="254" placeholder="Tên tài khoản"/><label>Mật khẩu</label><input name="password" type="password" autocomplete="current-password" required maxlength="256" placeholder="Mật khẩu"/><button class="vila-auth-primary" type="submit">Đăng nhập vào app</button></form>`;
  else if (active === 'register') content = `${switcher}<form data-auth-submit="register"><label>Tên tài khoản</label><input name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required minlength="3" maxlength="24" pattern="[A-Za-z0-9_.\-]{3,24}" placeholder="3–24 ký tự: chữ, số, . _ -"/><label>Mật khẩu</label><input name="password" type="password" autocomplete="new-password" required minlength="8" maxlength="256" placeholder="Ít nhất 8 ký tự"/><label>Elo khởi đầu · tự đánh giá</label><select name="initialElo"><option value="200">🌱 Mới bắt đầu · 200</option><option value="500" selected>♟ Cơ bản · 500</option><option value="1000">📘 Trung cấp · 1000</option><option value="1500">🔥 Khá · 1500</option></select><button class="vila-auth-primary" type="submit">Tạo tài khoản VILA</button><p class="vila-auth-hint">Mỗi tài khoản được gán ngẫu nhiên 1 trong 1.000 avatar cute. Chỉ cần tên tài khoản và mật khẩu. Tài khoản được lưu trên máy chủ nên đăng nhập lại được ở máy khác.</p></form>`;
  else if (active === 'forgot') content = `<div class="vila-auth-switch"><button type="button" data-auth-mode="login">← Quay lại đăng nhập</button></div><form data-auth-submit="forgot"><label>Email tài khoản</label><input name="email" type="email" autocomplete="email" required maxlength="254" placeholder="Email đã đăng ký"/><button class="vila-auth-primary" type="submit">Gửi mã 6 chữ số</button><p class="vila-auth-hint">Mã được gửi qua email và hết hạn sau 10 phút. Máy chủ cần được cấu hình dịch vụ gửi thư.</p></form>`;
  else content = `<div class="vila-auth-switch"><button type="button" data-auth-mode="login">← Quay lại đăng nhập</button></div><form data-auth-submit="reset"><label>Email tài khoản</label><input name="email" type="email" autocomplete="email" required maxlength="254" placeholder="Email đã nhận mã"/><label>Mã xác minh 6 chữ số</label><input name="code" inputmode="numeric" pattern="[0-9]{6}" minlength="6" maxlength="6" required placeholder="000000"/><label>Mật khẩu mới</label><input name="password" type="password" autocomplete="new-password" minlength="12" maxlength="256" required placeholder="Ít nhất 12 ký tự"/><button class="vila-auth-primary" type="submit">Đổi mật khẩu</button></form>`;
  const serverPanel = `<section class="vila-auth-server"><p class="vila-auth-hint"><b>Dịch vụ online tích hợp sẵn</b><br/>ViLa tự kết nối đến máy chủ cộng đồng. Người chơi không cần nhập Worker URL, API key hay mã phòng.</p><button type="button" class="vila-auth-primary vila-auth-server-save" data-check-default-backend>Kiểm tra kết nối online</button><p class="vila-auth-hint" id="vilaAuthBackendStatus" role="status"></p></section>`;
  gate.innerHTML = `<main class="vila-auth-card"><div class="vila-auth-brand"><span class="vila-auth-logo">♞</span><div><b>CỜ VUA</b><small>CHƠI · LUYỆN · THI ĐẤU</small></div></div><div class="vila-auth-welcome"><span class="vila-auth-eyebrow">VILA CHESS CLUB</span><h1>${active === 'register' ? 'Tạo hồ sơ của bạn' : active === 'forgot' ? 'Khôi phục tài khoản' : active === 'reset' ? 'Đặt mật khẩu mới' : 'Chào mừng trở lại'}</h1><p>${active === 'register' ? 'Chọn mức Elo khởi đầu gần với trình độ bạn tự đánh giá. Chỉ đấu xếp hạng online mới tăng/giảm Elo; đấu bot không tính Elo.' : active === 'forgot' || active === 'reset' ? 'Bảo vệ tài khoản bằng mã xác minh gửi tới email.' : 'Đăng nhập một lần, app sẽ nhớ phiên của bạn.'}</p></div>${notices}${content}${serverPanel}<button type="button" class="vila-auth-offline" data-offline-guest>Vào chơi ngoại tuyến · không cần tài khoản</button><p class="vila-auth-footnote">Elo xếp hạng online chỉ thay đổi ở trận xếp hạng đã xác minh · ván bot không tính Elo</p></main>`;
  gate.querySelectorAll('[data-auth-mode]').forEach(button => button.addEventListener('click', () => showAccountGate(button.dataset.authMode)));
  gate.querySelector('[data-offline-guest]')?.addEventListener('click', () => {
    offlineGuestMode = true;
    try { localStorage.setItem(OFFLINE_GUEST_MODE_KEY, '1'); } catch {}
    hideAccountGate();
    currentView = 'home';
    renderView();
    toast('Đang chơi ngoại tuyến. Ghép trận người thật cần đăng nhập và backend online.');
  });
  gate.querySelector('[data-check-default-backend]')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    const status = $('#vilaAuthBackendStatus', gate);
    const previous = button.textContent;
    button.disabled = true;
    button.textContent = 'Đang kiểm tra…';
    try {
      const response = await fetch(`${DEFAULT_BACKEND_URL}/api/social/health`, { signal: AbortSignal.timeout(6000), headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`Máy chủ trả HTTP ${response.status}`);
      const data = await response.json();
      if (data?.service !== 'Cờ Vua ViLa social' || data?.status !== 'online') throw new Error('Worker chưa được triển khai mã nguồn cộng đồng của ViLa Chess.');
      if (status) status.textContent = 'Máy chủ online đang phản hồi tốt. Bro có thể đăng nhập hoặc tạo tài khoản.';
    } catch (error) {
      if (status) status.textContent = `Chưa kết nối được máy chủ mặc định: ${String(error?.message || error)}. Chủ dự án cần triển khai backend Cloudflare một lần; người chơi không cần nhập URL.`;
    } finally { button.disabled = false; button.textContent = previous; }
  });
  gate.querySelector('form[data-auth-submit]')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('[type="submit"]');
    const values = new FormData(form);
    if (button) { button.disabled = true; button.textContent = 'Đang xử lý…'; }
    try {
      const action = form.dataset.authSubmit;
      if (action === 'login') {
        const data = await socialApi('/auth/login', { method: 'POST', body: JSON.stringify({ username: String(values.get('identity') || '').trim(), password: String(values.get('password') || '') }) });
        if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ.');
        saveSocialSession(data.token, data.user);
        addAppNotification({ title: 'Đăng nhập thành công', message: `Xin chào ${data.user.displayName || data.user.username}.`, type: 'success', sourceKey: `login:${data.user.id}:${new Date().toISOString().slice(0,10)}` });
        hideAccountGate(); currentView = 'home'; renderView(); void pollSocialInbox(); toast('Đăng nhập thành công.', 'success');
      } else if (action === 'register') {
        const data = await socialApi('/auth/register', { method: 'POST', body: JSON.stringify({ username: String(values.get('username') || '').trim(), password: String(values.get('password') || ''), initialElo: Number(values.get('initialElo') || 500) }) });
        if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ.');
        saveSocialSession(data.token, data.user);
        addAppNotification({ title: 'Tài khoản đã tạo', message: `Chào mừng ${data.user.displayName || data.user.username}! Avatar của bạn đã được cấp ngẫu nhiên.`, type: 'success', sourceKey: `register:${data.user.id}` });
        hideAccountGate(); currentView = 'home'; renderView(); toast('Đã tạo tài khoản VILA.', 'success');
      } else if (action === 'forgot') {
        const data = await socialApi('/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email: String(values.get('email') || '') }) });
        showAccountGate('reset', data.message || 'Nếu email đã đăng ký, mã khôi phục sẽ được gửi trong ít phút.');
      } else {
        const data = await socialApi('/auth/reset-password', { method: 'POST', body: JSON.stringify({ email: String(values.get('email') || ''), code: String(values.get('code') || ''), password: String(values.get('password') || '') }) });
        showAccountGate('login', data.message || 'Đã đổi mật khẩu. Hãy đăng nhập lại.');
      }
    } catch (error) {
      const message = String(error?.message || error || 'Không thể hoàn thành thao tác.');
      showAccountGate(actionModeForError(form.dataset.authSubmit), message);
    } finally { if (button?.isConnected) button.disabled = false; }
  });
}
function actionModeForError(action) { return ['login','register','forgot','reset'].includes(action) ? action : 'login'; }
function initializeRequiredAccountGate() {
  if (!socialState.token || !socialState.user) { if (!offlineGuestMode) showAccountGate('login'); return; }
  const token = socialState.token;
  socialApi('/auth/me').then(data => {
    if (!socialState.token || !data?.user) return;
    saveSocialSession(socialState.token, data.user);
  }).catch(error => {
    // Only a definite rejection from the server ends the session; being offline keeps the user signed in.
    if (isSessionRejected(error)) {
      saveSocialSession('', null);
      showAccountGate('login', 'Phiên đăng nhập hết hạn. Đăng nhập lại để tiếp tục.');
    }
  });
}

function captureIncomingFriendNotifications(incoming) {
  if (!Array.isArray(incoming)) return;
  for (const request of incoming) {
    const name = request?.user?.displayName || request?.user?.username;
    if (!request?.id || !name) continue;
    addAppNotification({
      title: 'Lời mời kết bạn mới',
      message: `@${request.user.username || name} muốn kết bạn với bạn. Mở mục Bạn bè để phản hồi.`,
      type: 'info',
      sourceKey: `friend-request:${request.id}`
    });
  }
}
function socialHandleError(error, fallback = 'Không thể kết nối máy chủ cộng đồng.') {
  const message = String(error?.message || error || fallback);
  if (isSessionRejected(error) && socialState.token) { saveSocialSession('', null); showAccountGate('login', 'Phiên đăng nhập đã hết hạn. Hãy đăng nhập lại.'); return message; }
  toast(message);
  return message;
}
function adoptSocialCallback() { try { const hash = new URLSearchParams(location.hash.replace(/^#/, '')); const token = hash.get('social_token'); const error = hash.get('social_error'); if (token) { saveSocialSession(token, null); history.replaceState(null, '', location.pathname + location.search); socialApi('/auth/me').then(data => { saveSocialSession(token, data.user); toast('Đăng nhập thành công.');
if (currentView === 'friends' || currentView === 'admin') renderView(); }).catch(socialHandleError); } else if (error) { history.replaceState(null, '', location.pathname + location.search); toast(error); } } catch {} }
let ratedGameSignature = '';
function readRatingProfile() { try { const p = JSON.parse(localStorage.getItem(RATING_KEY) || '{}'); return { elo: Number(p.elo) || 1200, games: Number(p.games) || 0, wins: Number(p.wins) || 0, draws: Number(p.draws) || 0, losses: Number(p.losses) || 0, lastChange: Number(p.lastChange) || 0, processedGameIds: Array.isArray(p.processedGameIds) ? p.processedGameIds.filter(id => typeof id === 'string').slice(-200) : [] }; } catch { return { elo: 1200, games: 0, wins: 0, draws: 0, losses: 0, lastChange: 0, processedGameIds: [] }; } }
function readRatingHistory() { try { const h = JSON.parse(localStorage.getItem(RATING_HISTORY_KEY) || '[]'); return Array.isArray(h) ? h.slice(-100) : []; } catch { return []; } }
function maybeRecordRatedGame() {
  if (!gameStarted || !['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = String(currentGameId || '');
  if (!signature || signature === ratedGameSignature) return;
  // Bot matches are training only. They must never update a rating or create a rated-history row.
  // Online Elo is changed exclusively by server-verified ranked matches.
  ratedGameSignature = signature;
  const humanScore = result.token === '1/2-1/2' ? 0.5 : ((result.token === '1-0') === (humanColor === 'w') ? 1 : 0);
  recordDailyEvent('complete_game');
  recordDailyEvent(humanScore === 1 ? 'win_game' : humanScore === 0.5 ? 'draw_game' : 'lose_game');
}

function safeSessionGet(key) {
  try { return sessionStorage.getItem(key) || ''; } catch { return ''; }
}
function safeSessionSet(key, value) {
  try { sessionStorage.setItem(key, String(value ?? '')); return true; } catch { return false; }
}
function safeSessionRemove(key) {
  try { sessionStorage.removeItem(key); return true; } catch { return false; }
}
function getLichessToken() {
  return String($('#lichessToken')?.value?.trim() || activeLichessToken || safeSessionGet(lichessTokenKey) || '').trim();
}

let settings = loadSettings();
let visualSettings = loadVisualSettings();
applyVisualSettings(visualSettings);
let currentView = 'home';
let game = new Chess();
let gameStartFen = game.fen();
let currentGameId = '';
let reviewStatus = '';
let gameStarted = false; // New launches always wait for explicit Start.
let manualGameResult = null; // Resign/agree-draw result; does not falsify chess.js move history.
let reviewSession = null;
let completedReviewRows = [];
let reviewReplayState = null;
let mistakeTrainingItems = loadMistakeTrainingItems();
let activeMistakeTraining = null;
let historyRestoreSignature = '';
let dragState = null;
let dragGhost = null;
let dragMoveFrame = 0;
let dragLatestPoint = null;
let boardSquareMap = new Map();
// Only revisit squares whose selection/legal-target state changed; this keeps taps responsive on low-end WebViews.
let boardHighlightedSquares = new Set();
let suppressSquareClick = null;
let mode = 'stockfish'; // stockfish, vila, enginehub, local
let humanColor = 'w';
let arenaRandomSides = true;
let colorChoice = 'random'; // default: random side each game (Trắng/Đen)
let orientation = 'w';
let selected = null;
let selectedTargets = [];
let premoveQueue = []; // Chess.com-style premoves: an unlimited ordered queue entered while the opponent is thinking.
let premoveViewCache = { key: '', chess: null };
const puzzleRecentThemes = [];
let premoveFiringUntil = 0; // short window after a bot reply where queued premoves stay painted until they fire
const PREMOVE_FIRE_DELAY_MS = 170;
function isPremoveShown() { return isPremoveWindow() || (premoveFiringUntil > Date.now() && premoveQueue.length > 0 && gameStarted && !game.isGameOver()); }
let botThinking = false;
let currentOpening = null;
let openingPageLimit = 48;
let openingCatalogLoadPromise = null;
let lastHintMove = null;
let boardAnnotations = [];
let annotationPreview = null;
let annotationPreviewRaf = 0;
const ANNOTATION_COLORS = ['green', 'red', 'yellow', 'blue'];
let annotationTool = null; // null = normal chess movement; 'arrow'/'circle' = touch drawing mode.
let annotationColor = 'green';
let annotationCollapsed = true;
let annotationWidgetHidden = false;
let annotationPointer = null;
// Virtual PC-style mouse: a compact touchpad drives one small cursor without camera/model overhead.
let beginnerSettingsBackup = null;
let virtualMouseEnabled = false;
let virtualMouseCollapsed = false;
let virtualMouseHeld = false;
let virtualMousePosition = { x: 0, y: 0 };
let virtualMousePadPoint = null;
let virtualMousePendingPoint = null;
let virtualMouseMoveRaf = 0;
let virtualMousePanelPosition = null;
let handMouseStream = null;
let handMouseVideo = null;
let handMouseWorker = null;
let handMouseFrameRaf = 0;
let handMouseFrameBusy = false;
let handMouseWorkerReady = false;
let handMouseLastVideoTime = -1;
let handMouseLastSubmitAt = 0;
let handMouseLastSeenAt = 0;
let handMouseSmoothPoint = null;
let handMousePinching = false;
let handMousePinchStart = null;
let handMouseClickCandidate = null;
const HAND_MOUSE_PINCH_DOWN = 0.047;
const HAND_MOUSE_PINCH_UP = 0.075;
const VIRTUAL_MOUSE_POINTER_ID = 7419;
const VIRTUAL_MOUSE_SENSITIVITY = 2.35;
const VIRTUAL_MOUSE_ACCEL_MAX = 2.4;      // extra gain for fast swipes; slow moves stay precise
const VIRTUAL_MOUSE_TAP_MS = 230;
const VIRTUAL_MOUSE_TAP_SLOP = 7;
const VIRTUAL_MOUSE_DOUBLE_TAP_MS = 320;
let virtualMouseTapState = null;
let virtualMouseLastTapAt = 0;
let virtualMousePadHeld = false;
let randomBotEloEnabled = false;
let experienceLevel = readSocialCache('vila.chess.experience.v1', '');
if (!['beginner', 'experienced'].includes(experienceLevel)) experienceLevel = '';
let selectedRankedTimeControl = '1d';
if (!RANKED_CLOCK_PRESETS.some(item => item.value === selectedRankedTimeControl)) selectedRankedTimeControl = '1d';
const recentOpeningChoices = new Map();
// Arena repertoire choices are isolated from casual games and reset for every match.
let arenaOpeningChoices = new Map();
let pendingCoachAnalysis = null;
let lastMove = null;
let engineWorker = null;
let engineInitTimeout = null;
let engineHealthState = createEngineHealthState('unknown');
let stockfishWarmupTimer = null;
let waitingForStockfishMove = null;
let engineInitFallbacksTried = new Set();
let engineReady = false;
let engineUciInitialized = false;
let engineFailed = false;
let boardResizeObserver = null;
let boardResizeRaf = 0;
let engineQueue = [];
let engineSearchActive = false;
let pendingEngineRequest = null;
let pendingHintRequest = null;
let apiMoveAbortController = null;
let mainEngineTimer = null;
let mainBotKickTimer = null;
let gameEpoch = 0;
let mainEngineSearchEpoch = -1;
let mainEngineSearchFen = '';
let queuedMainEngineMove = false;
let clockState = { enabled: false, running: false, remaining: { w: 0, b: 0 }, incrementMs: 0, lastTickAt: 0 };
// One pre-ply clock snapshot per real move makes undo/redo restore time rather than reinitialize it.
let moveClockSnapshots = [];
let redoStack = [];
let clockFlagged = null;
let clockInterval = null;
let analysisActive = false;
let analysisVisible = false;
let analysisFen = '';
let analysisEpoch = -1;
let analysisVariants = [];
let analysisTimeout = null;
let engineStopTimeout = null;
let engineStopPending = false;
let analysisLastPaintAt = 0;
let arenaGame = new Chess();
let legacyArenaEngine = null;
let arenaRunning = false;
let arenaPaused = false;
let arenaLiveRanked = [];
let arenaGameMeta = null;
let arenaProgress = null;
let arenaStopRequested = false;
let arenaAbortController = null;
let arenaLastMove = null;
let arenaPgnHeaders = {};
let arenaLastPgnResult = '*';
let arenaPgnArchive = [];
let arenaLastResult = '';
let arenaCurrentPlayers = { w: null, b: null };
let arenaGameCounter = 0;
let gamesMode = 'rubik';
let ticTacToeBoard = Array(9).fill('');
let ticTacToeResult = '';
let ticTacToeThinking = false;
let arenaCupStandings = readSocialCache('vila.chess.arena-cup-standings.v1', []);
if (!Array.isArray(arenaCupStandings)) arenaCupStandings = [];
arenaCupStandings = arenaCupStandings.filter(item => item && typeof item.name === 'string').slice(0, ARENA_MAX_PLAYERS);
let rubikCube = createSolvedRubikCube();
let rubikMoveHistory = [];
let rubikMoveCount = 0;
let rubikViewMode = 'turn';
let rubikTimerStart = 0, rubikTimerElapsed = 0, rubikTimerId = null, rubikTimerArmed = false;
let rubikBestMs = (() => { try { return Number(localStorage.getItem('vila.rubik.best') || 0) || 0; } catch { return 0; } })();
let rubikRotationX = -22;
let rubikRotationY = -32;
let game2048Board = create2048Board();
let game2048Score = 0;
let game2048Best = 0;
const CHESS_FILES = 'abcdefgh';
function randomCoordinateSquare(exclude = '') {
  let square = exclude;
  for (let i = 0; i < 16 && square === exclude; i++) square = `${CHESS_FILES[Math.floor(Math.random() * 8)]}${1 + Math.floor(Math.random() * 8)}`;
  return square || 'e4';
}
let coordinateTargetSquare = randomCoordinateSquare();
let coordinateScore = 0;
let coordinateStreak = 0;
let coordinateBest = 0;
try { coordinateBest = Math.max(0, Number(localStorage.getItem('vila.coordinate.best')) || 0); } catch {}
let coordinateFeedback = 'Chạm đúng ô được gọi tên để ghi điểm.';
let slidingPuzzleBoard = createScrambledSlidingPuzzle(100);
let slidingPuzzleMoves = 0;
let gamesKeyHandler = null;
let memoryDeck = [];
let memorySelected = [];
let memoryMatched = new Set();
let memoryMoves = 0;
let memoryLock = false;
let arenaLastNote = '';
let arenaEngineWarning = '';
let arenaTournamentSummary = '';
let arenaSelectedLeague = new Set(['stockfish', 'offline-ethereal']);
let arenaFallbackMoves = new Map();
let activeOnlineGame = null;
let activeLichessUsername = safeSessionGet('tubor.chess.lichessUsername');
let activeLichessToken = safeSessionGet(lichessTokenKey);
let onlineStreamController = null;
let lastExplorerData = null;
let explorerRequestId = 0;
let toastTimer = null;

function loadSettings() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    const normalized = normalizeSettings(raw);
    // The whitelist migration removes legacy provider keys/endpoints/profiles from this record.
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    return normalized;
  } catch {
    return normalizeSettings(DEFAULTS);
  }
}
function saveSettings() {
  try {
    const normalized = normalizeSettings(settings);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(normalized));
    settings = normalized;
    return true;
  } catch (error) {
    console.warn('[Cờ Vua] Settings could not be stored:', error);
    toast('Không lưu được cài đặt trên thiết bị này. Hãy kiểm tra dung lượng hoặc quyền lưu trữ.');
    return false;
  }
}
function loadVisualSettings() {
  try { return normalizeVisualSettings(JSON.parse(localStorage.getItem(VISUAL_SETTINGS_KEY) || '{}')); }
  catch { return { ...DEFAULT_VISUAL_SETTINGS }; }
}
function applyVisualSettings(next) {
  visualSettings = normalizeVisualSettings(next);
  if (typeof document !== 'undefined') {
    document.documentElement.dataset.boardMotion = visualSettings.smoothAnimations ? 'on' : 'off';
  }
  return visualSettings;
}
function saveVisualSettings(next) {
  const normalized = applyVisualSettings(next);
  try { localStorage.setItem(VISUAL_SETTINGS_KEY, JSON.stringify(normalized)); }
  catch { toast('Không lưu được tùy chọn giao diện; thiết lập chỉ có hiệu lực trong phiên này.'); }
  if (currentView === 'play') renderBoard();
  return normalized;
}
function apiUrl(path) {
  const base = String(settings.backendUrl || DEFAULT_BACKEND_URL).trim().replace(/\/$/, '');
  return `${base}${path}`;
}
function backendAuthorizationHeaders(headerName = 'Authorization') {
  const base = String(settings.backendUrl || DEFAULT_BACKEND_URL).trim().replace(/\/+$/, '');
  // The bundled public Cloudflare endpoint has no shared client secret; never leak a
  // previous self-hosted backend token to it. Custom/self-hosted backends keep support.
  if (base === DEFAULT_BACKEND_URL || !settings.backendAccessToken) return {};
  return { [headerName]: headerName.toLowerCase() === 'authorization' ? `Bearer ${settings.backendAccessToken}` : settings.backendAccessToken };
}
function isSafeHttpEndpoint(value) {
  try {
    const parsed = new URL(String(value || '').trim());
    return ['http:', 'https:'].includes(parsed.protocol) && Boolean(parsed.hostname) &&
      !parsed.username && !parsed.password && !parsed.search && !parsed.hash;
  } catch {
    return false;
  }
}
function safeLichessUrl(value, gameId) {
  const cleanId = String(gameId || '').trim();
  const fallback = cleanId ? `https://lichess.org/${encodeURIComponent(cleanId)}` : 'https://lichess.org/';
  try {
    const parsed = new URL(String(value || fallback));
    return parsed.protocol === 'https:' && parsed.hostname === 'lichess.org' && !parsed.username && !parsed.password && !parsed.port ? parsed.href : fallback;
  } catch {
    return fallback;
  }
}
async function apiFetch(path, options = {}) {
  // Bound ordinary API requests so a broken backend/network cannot leave chat,
  // settings or arena controls in a permanent loading state.
  const controller = new AbortController();
  const callerSignal = options.signal;
  let timedOut = false;
  const abortFromCaller = () => controller.abort();
  if (callerSignal?.aborted) controller.abort();
  else callerSignal?.addEventListener('abort', abortFromCaller, { once: true });
  const timeoutMs = Math.max(1000, Math.min(90_000, Number(options.timeoutMs) || 90_000));
  const timeout = setTimeout(() => { timedOut = true; controller.abort(); }, timeoutMs);
  try {
    const { signal: _callerSignal, timeoutMs: _timeoutMs, ...fetchOptions } = options;
    let response;
    try {
      response = await fetch(apiUrl(path), {
        ...fetchOptions,
        signal: controller.signal,
        headers: {
          ...(options.headers || {}),
          ...backendAuthorizationHeaders(),
          ...(options.body && typeof options.body === 'string' ? { 'Content-Type': 'application/json' } : {})
        }
      });
    } catch (fetchError) {
      if (fetchError instanceof TypeError || /failed to fetch|networkerror|load failed|invalid url/i.test(String(fetchError?.message || ''))) {
        const target = String(settings.backendUrl || '').trim().replace(/\/$/, '') || ((location.protocol === 'http:' || location.protocol === 'https:') ? location.origin : 'chưa cấu hình');
        throw new Error(`Không kết nối được backend API tại ${target}. Kiểm tra máy chủ cloud và CORS. Chủ dự án cần triển khai backend; người chơi không phải nhập URL hay API key.`);
      }
      throw fetchError;
    }
    const type = response.headers.get('content-type') || '';
    const raw = await response.text().catch(() => '');
    let data = raw;
    if (/application\/(?:[\w.+-]*\+)?json/i.test(type)) {
      try { data = raw ? JSON.parse(raw) : {}; } catch { data = { error: 'Backend trả JSON không hợp lệ.' }; }
    }
    const looksLikeHtml = /text\/html/i.test(type) || /^\s*(?:<!doctype html|<html[\s>])/i.test(raw);
    if (looksLikeHtml) {
      throw new Error('Máy chủ mặc định đang trả về trang web thay vì API Cờ Vua. Chủ dự án cần triển khai đúng backend cloud; người chơi không cần tự nhập URL.');
    }
    if (!response.ok) throw new Error(data?.error || data?.message || (typeof data === 'string' ? data : '') || `HTTP ${response.status}`);
    return data;
  } catch (error) {
    if (timedOut) throw new Error(`Yêu cầu quá thời gian chờ ${Math.round(timeoutMs / 1000)} giây. Hãy kiểm tra mạng/model rồi thử lại.`);
    throw error;
  } finally {
    clearTimeout(timeout);
    callerSignal?.removeEventListener('abort', abortFromCaller);
  }
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function makeMessageId() {
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  } catch { /* Some embedded WebViews restrict crypto APIs outside secure contexts. */ }
  return `message-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
function toast(message, type = '') {
  const element = $('#toast');
  if (!element) return;
  element.textContent = message;
  element.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { element.className = 'toast'; }, 3300);
}
function setHintSuggestion(move, source = 'Stockfish') {
  if (!move) return;
  lastHintMove = { fen: game.fen(), from: move.from, to: move.to, promotion: move.promotion || null, san: move.san, source };
  renderHintArrow();
  toast(`Gợi ý: ${move.san} · ${move.from} → ${move.to}. Mũi tên đã đánh dấu trên bàn cờ.`);
}
function speakTextVietnamese(text) {
  const clean = String(text || '').trim();
  if (!clean) return;
  if (!('speechSynthesis' in window) || typeof SpeechSynthesisUtterance === 'undefined') {
    toast('Thiết bị/WebView chưa hỗ trợ đọc chỉ dẫn bằng giọng nói.'); return;
  }
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'vi-VN'; utterance.rate = 0.94; utterance.pitch = 1;
    const voice = window.speechSynthesis.getVoices().find(item => /^vi(-|_)/i.test(item.lang));
    if (voice) utterance.voice = voice;
    utterance.onerror = () => toast('Không thể phát giọng đọc trên thiết bị này.');
    window.speechSynthesis.speak(utterance);
  } catch { toast('Không thể khởi chạy giọng đọc trên WebView này.'); }
}
function speakCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Hãy lấy gợi ý mới cho thế cờ hiện tại trước.'); return; }
  speakTextVietnamese(`Gợi ý ${lastHintMove.source}. Đi nước ${lastHintMove.san}. Di chuyển quân từ ô ${lastHintMove.from} đến ô ${lastHintMove.to}.`);
}
function applyCurrentHint() {
  if (!lastHintMove || lastHintMove.fen !== game.fen()) { toast('Gợi ý đã cũ. Hãy tính lại ở thế cờ hiện tại.'); return; }
  if (arenaRunning || game.isGameOver() || botThinking || clockFlagged) { toast('Chưa thể áp dụng gợi ý trong trạng thái hiện tại.'); return; }
  if (mode !== 'local' && game.turn() !== humanColor) { toast('Chỉ áp dụng gợi ý khi đến lượt của bạn.'); return; }
  const move = game.moves({ verbose: true }).find(candidate => candidate.from === lastHintMove.from && candidate.to === lastHintMove.to && (candidate.promotion || null) === (lastHintMove.promotion || null));
  if (!move) { toast('Nước gợi ý không còn hợp lệ ở vị trí hiện tại.'); return; }
  playMove(move.from, move.to, move.promotion);
}
function clockPlayerName(color) {
  if (mode === 'lichess') return color === humanColor ? 'Bạn' : 'Đối thủ';
  if (mode === 'local') return color === 'w' ? 'Trắng' : 'Đen';
  return color === humanColor ? 'Bạn' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish');
}
function resetClock(preset = settings.clockPreset) {
  const parsed = parseClockPreset(preset);
  const enabled = parsed.enabled && mode !== 'lichess';
  clockFlagged = null;
  clockState = {
    enabled,
    running: enabled && gameStarted && !game.isGameOver() && !manualGameResult,
    remaining: { w: parsed.baseMs, b: parsed.baseMs },
    incrementMs: parsed.incrementMs,
    lastTickAt: typeof performance !== 'undefined' ? performance.now() : Date.now()
  };
  renderClockDisplay();
}
function captureMoveClockSnapshot() {
  return captureClockSnapshot(clockState, clockFlagged);
}
function restoreMoveClockSnapshot(snapshot) {
  if (!snapshot) return false;
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const restored = restoreClockSnapshot(snapshot, now);
  if (!restored) return false;
  clockFlagged = restored.clockFlagged;
  delete restored.clockFlagged;
  clockState = restored;
  // Do not revive a stopped clock after a terminal chess/result state.
  if (!gameStarted || game.isGameOver() || manualGameResult || clockFlagged) clockState.running = false;
  else if (clockState.enabled) clockState.running = Boolean(snapshot.running);
  clockState.lastTickAt = now;
  renderClockDisplay();
  return true;
}
function rebaseClockAfterUndoWithoutSnapshot() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  clockFlagged = null;
  clockState.running = Boolean(clockState.enabled && gameStarted && !game.isGameOver() && !manualGameResult);
  clockState.lastTickAt = now;
  renderClockDisplay();
}
function stopClock() {
  clockState.running = false;
  renderClockDisplay();
}
function renderClockDisplay() {
  const white = $('#clockWhite');
  const black = $('#clockBlack');
  if (!white || !black) return;
  for (const [color, element] of [['w', white], ['b', black]]) {
    const value = clockState.enabled ? formatClockTime(clockState.remaining[color], true) : (mode === 'lichess' ? 'Lichess' : '∞');
    // The clock ticks every 100 ms: only touch the DOM when something actually changed
    // (avoids needless style recalculation while a piece is being dragged on phones).
    if (element.textContent !== value) {
      element.textContent = value;
      element.setAttribute('aria-label', `${clockPlayerName(color)}: ${value}`);
    }
    const active = clockState.enabled && clockState.running && game.turn() === color && !clockFlagged;
    if (element.classList.contains('is-active') !== active) element.classList.toggle('is-active', active);
    const flagged = clockFlagged === color;
    if (element.classList.contains('is-flagged') !== flagged) element.classList.toggle('is-flagged', flagged);
  }
  const whiteName = $('#clockWhiteName');
  const blackName = $('#clockBlackName');
  if (whiteName && whiteName.textContent !== clockPlayerName('w')) whiteName.textContent = clockPlayerName('w');
  if (blackName && blackName.textContent !== clockPlayerName('b')) blackName.textContent = clockPlayerName('b');
  const hint = $('#clockHint');
  if (hint) hint.textContent = clockFlagged ? `${clockPlayerName(clockFlagged)} đã hết giờ` : clockState.enabled ? `Thời gian + ${Math.round(clockState.incrementMs / 1000)} giây cộng mỗi nước` : (mode === 'lichess' ? 'Đồng hồ do Lichess quản lý' : 'Đồng hồ không giới hạn');
}
let lastLowTimeSecond = -1;
function tickClock() {
  const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
  if (arenaRunning) { clockState.lastTickAt = now; return; }
  if (!clockState.enabled || !clockState.running || clockFlagged || mode === 'lichess') return;
  // A restored or externally-ended game must never leave an active clock running.
  if (!gameStarted || game.isGameOver() || manualGameResult) {
    clockState.running = false;
    clockState.lastTickAt = now;
    renderClockDisplay();
    return;
  }
  const side = game.turn();
  const tick = consumeClockTick(clockState, side, now);
  if (!tick.valid) return;
  clockState.remaining[side] = tick.remainingMs;
  clockState.lastTickAt = now;
  if (tick.flagged) {
    clockFlagged = side;
    clockState.running = false;
    botThinking = false;
    premoveQueue = []; selected = null; selectedTargets = [];
    cancelScheduledBotMove();
    cancelPendingHint();
    stopAnalysis(true);
    cancelMainEngineSearch();
    if (currentView === 'play') renderView();
    playGameSound('flag', settings.soundEnabled);
    toast(`${clockPlayerName(side)} hết giờ. Ván cờ kết thúc.`, 'success');
    return;
  }
  if (side === humanColor && clockState.remaining[side] <= 10000 && mode !== 'local') {
    const second = Math.ceil(clockState.remaining[side] / 1000);
    if (second !== lastLowTimeSecond) { lastLowTimeSecond = second; playGameSound('lowtime', settings.soundEnabled); }
  } else lastLowTimeSecond = -1;
  renderClockDisplay();
}
function creditClockForMove(mover) {
  if (!clockState.enabled || clockFlagged) return;
  clockState.remaining[mover] += clockState.incrementMs;
  clockState.lastTickAt = typeof performance !== 'undefined' ? performance.now() : Date.now();
  renderClockDisplay();
}
function requestEngineStop() {
  if (engineStopPending) return;
  // Do not wait for a terminal line when the previous search has already ended.
  if (!engineWorker || engineFailed || !engineSearchActive) { engineSearchActive = false; return; }
  // UCI does not tag `bestmove` with a request ID. Lock the shared worker until
  // the cancelled job emits its terminal line; all new searches stay queued.
  engineStopPending = true;
  engineSearchActive = true;
  try {
    engineWorker.postMessage('stop');
    engineWorker.postMessage('setoption name MultiPV value 1');
  } catch {
    retireStockfishWorker('Không thể gửi lệnh dừng Stockfish an toàn.');
    return;
  }
  if (engineStopTimeout) clearTimeout(engineStopTimeout);
  engineStopTimeout = setTimeout(() => {
    if (!engineStopPending) return;
    const resumeBot = queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged;
    queuedMainEngineMove = false;
    engineStopTimeout = null;
    retireStockfishWorker('Stockfish không xác nhận dừng tác vụ đúng hạn.');
    if (resumeBot) scheduleBotMove(0);
  }, 2500);
}
function stopAnalysis(clearResults = true) {
  const wasActive = analysisActive;
  analysisActive = false;
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  if (wasActive) requestEngineStop();
  if (clearResults) analysisVisible = false;
  analysisFen = '';
  analysisEpoch = -1;
  if (clearResults) analysisVariants = [];
  renderAnalysisPanel();
}
function uciPvToSan(fen, pv) {
  const clone = new Chess(fen);
  const san = [];
  for (const uci of pv) {
    try {
      const move = clone.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!move) break;
      san.push(move.san);
    } catch { break; }
  }
  return san;
}
function renderAnalysisPanel() {
  const panel = $('#analysisPanel');
  const lines = $('#analysisLines');
  const button = $('#analyzePosition');
  if (!panel || !lines) return;
  panel.hidden = !(analysisVisible || analysisActive || analysisVariants.length);
  if (button) {
    button.disabled = engineStopPending;
    button.textContent = analysisActive ? '■ Dừng phân tích' : engineStopPending ? 'Đang dừng…' : '♙ Phân tích 3 biến';
    button.setAttribute('aria-busy', String(analysisActive || engineStopPending));
  }
  if (!analysisVariants.length) {
    const emptyText = analysisActive
      ? 'Stockfish đang phân tích nhiều phương án…'
      : engineStopPending
        ? 'Đang yêu cầu Stockfish kết thúc lượt phân tích an toàn…'
        : analysisVisible
          ? 'Chưa nhận được biến thể hợp lệ từ Stockfish. Kiểm tra trạng thái engine rồi thử phân tích lại.'
          : 'Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.';
    lines.innerHTML = `<div class="analysis-empty">${emptyText}</div>`;
    renderHintArrow();
    return;
  }
  const expectedFen = analysisVariants[0]?.fen || game.fen();
  lines.innerHTML = analysisVariants.sort((a, b) => a.multipv - b.multipv).map(variation => {
    const san = uciPvToSan(expectedFen, variation.pv).slice(0, 8).join(' ');
    return `<div class="analysis-line"><b>${variation.multipv}</b><strong>${esc(formatUciScore(variation))}</strong><span>Độ sâu ${variation.depth}</span><small>${esc(san || 'Đang tìm biến…')}</small></div>`;
  }).join('');
  renderHintArrow();
}
function receiveAnalysisInfo(line) {
  if (!analysisActive) return;
  if (!isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch })) {
    stopAnalysis(true);
    return;
  }
  const parsed = parseUciInfoLine(line);
  if (!parsed) return;
  analysisVariants = mergeAnalysisVariation(analysisVariants, parsed, analysisFen);
  const now = Date.now();
  if (now - analysisLastPaintAt >= 180) {
    analysisLastPaintAt = now;
    renderAnalysisPanel();
  }
}
/** Always give training analysis the engine's full available strength, independent of the bot Elo chosen for the current game. */
function configureStockfishForAnalysis(multiPv = 1) {
  if (!engineWorker || engineFailed) return false;
  const lanes = Math.max(1, Math.min(5, Math.round(Number(multiPv) || 1)));
  engineWorker.postMessage('setoption name UCI_LimitStrength value false');
  engineWorker.postMessage('setoption name Skill Level value 20');
  engineWorker.postMessage(`setoption name MultiPV value ${lanes}`);
  return true;
}

function rankedFairPlayLocked() { return rankedMatchState?.match?.status === 'active'; }
/** While a ranked game is live, block copy/paste/context-menu/drag so positions cannot be exported to an engine. */
function installRankedFairPlayGuards() {
  if (typeof document === 'undefined' || window.__vilaFairPlayGuards) return;
  window.__vilaFairPlayGuards = true;
  const block = event => { if (rankedFairPlayLocked()) event.preventDefault(); };
  for (const type of ['copy', 'cut', 'paste', 'contextmenu', 'dragstart', 'selectstart']) document.addEventListener(type, block, true);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && rankedFairPlayLocked()) rankedLeftAppCount = (rankedLeftAppCount || 0) + 1;
    else if (!document.hidden && rankedFairPlayLocked() && rankedLeftAppCount) toast('Bạn vừa rời màn hình trận đấu. Trận xếp hạng chỉ cho phép bàn cờ, nước đi và nhận diện khai cuộc.');
  });
  const sync = () => document.body.classList.toggle('ranked-fairplay', rankedFairPlayLocked());
  setInterval(sync, 700);
}
let rankedLeftAppCount = 0;
function rankedFairPlayNotice() { toast('Trong trận xếp hạng online, VILA chỉ cho phép đi nước hợp lệ và nhận diện khai cuộc; engine, gợi ý và phân tích bị tắt.'); }
function toggleAnalysis() {
  if (rankedFairPlayLocked()) { rankedFairPlayNotice(); return; }
  if (!gameStarted) { toast('Bắt đầu ván trước khi phân tích.'); return; }
  if (analysisActive) { stopAnalysis(false); toast('Đã dừng phân tích.'); return; }
  if (engineStopPending) { toast('Stockfish đang kết thúc lượt phân tích trước; thử lại sau giây lát.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi phân tích bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) { toast('Ván cờ đã kết thúc; hãy bắt đầu ván mới để phân tích tiếp.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng. Kiểm tra engine rồi thử lại.'); return; }
  if (botThinking || engineSearchActive || pendingEngineRequest || pendingHintRequest) { toast('Đợi Stockfish hoàn tất nước đi hoặc gợi ý trước khi phân tích.'); return; }
  analysisActive = true;
  analysisVisible = true;
  analysisFen = game.fen();
  analysisEpoch = gameEpoch;
  analysisVariants = [];
  analysisLastPaintAt = 0;
  engineSearchActive = true;
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  renderAnalysisPanel();
  try {
    configureStockfishForAnalysis(3);
    engineWorker.postMessage(`position fen ${analysisFen}`);
    const budget = Math.max(1000, Math.min(8000, Number(settings.analysisMoveTimeMs) || 2600));
    engineWorker.postMessage(`go movetime ${budget}`);
    analysisTimeout = setTimeout(() => {
      if (!analysisActive) return;
      stopAnalysis(false);
      retireStockfishWorker('Stockfish không hoàn tất phân tích đúng hạn.');
      reviewStatus = 'Đã dừng phân tích vì Stockfish quá thời gian.';
      updateReviewPanel();
      toast('Stockfish quá thời gian phân tích; chạm trạng thái engine ở đầu trang để thử tải lại.');
    }, budget + 3500);
  } catch (error) {
    stopAnalysis(true);
    toast(`Không thể khởi chạy phân tích: ${error.message || error}`);
  }
}
function analyzeLocallyForCoach() {
  return new Promise((resolve, reject) => {
    if (rankedFairPlayLocked()) return reject(new Error('Engine và phân tích bị tắt trong trận xếp hạng online.'));
    if (!engineWorker || !engineReady || engineFailed) return reject(new Error('Stockfish chưa sẵn sàng. Hãy chờ trạng thái engine sẵn sàng rồi thử lại.'));
    if (botThinking || engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || analysisActive || pendingCoachAnalysis) {
      return reject(new Error('Engine đang bận. Đợi nước đi hoặc phân tích hiện tại kết thúc rồi thử lại.'));
    }
    const request = { fen: game.fen(), epoch: gameEpoch, variants: new Map(), resolve, reject, timeout: null };
    pendingCoachAnalysis = request;
    engineSearchActive = true;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    const budget = Math.max(1200, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600));
    request.timeout = setTimeout(() => {
      if (pendingCoachAnalysis !== request) return;
      pendingCoachAnalysis = null;
      engineSearchActive = false;
      retireStockfishWorker('Stockfish quá thời gian phân tích.');
      reject(new Error('Stockfish quá thời gian phân tích. Engine đã dừng để bỏ qua kết quả cũ; hãy chạm trạng thái engine để thử lại.'));
    }, budget + 3000);
    try {
      configureStockfishForAnalysis(3);
      engineWorker.postMessage(`position fen ${request.fen}`);
      engineWorker.postMessage(`go movetime ${budget}`);
    } catch (error) {
      clearTimeout(request.timeout); pendingCoachAnalysis = null; engineSearchActive = false;
      try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
      reject(error);
    }
  });
}
function receiveCoachAnalysisInfo(line) {
  const request = pendingCoachAnalysis;
  if (!request || request.epoch !== gameEpoch || request.fen !== game.fen()) return;
  const parsed = parseUciInfoLine(line);
  if (!parsed || !parsed.pv?.length) return;
  const old = request.variants.get(parsed.multipv);
  if (!old || parsed.depth >= old.depth) request.variants.set(parsed.multipv, { ...parsed, fen: request.fen });
}
function ensureClockTicker() {
  if (clockInterval) return;
  clockInterval = setInterval(tickClock, 100);
}
function preferredHashMb() {
  const memory = Number(navigator?.deviceMemory || 0);
  // Unknown WebView memory should take the safer allocation on low-RAM phones.
  return memory >= 4 ? 32 : 16;
}
function cancelScheduledBotMove() {
  if (mainBotKickTimer) {
    clearTimeout(mainBotKickTimer);
    mainBotKickTimer = null;
  }
}
function cancelApiMoveRequest() {
  if (!apiMoveAbortController) return;
  const controller = apiMoveAbortController;
  apiMoveAbortController = null;
  try { controller.abort(); } catch {}
}
function cancelMainEngineWatchdog() {
  if (mainEngineTimer) {
    clearTimeout(mainEngineTimer);
    mainEngineTimer = null;
  }
}

function renderOpeningExplorerPanel() {
  try {
    const history = typeof game?.history === 'function' ? game.history() : [];
    const catalog = typeof mergeOpeningEntries === 'function' ? mergeOpeningEntries(OPENINGS || []) : (OPENINGS || []);
    const result = openingExplorerContinuations(history, catalog, 6);
    const panel = document.getElementById('openingExplorerPanel');
    const html = openingExplorerMarkup(result);
    if (panel) {
      panel.innerHTML = html;
      panel.querySelectorAll('[data-san]').forEach(btn => {
        btn.addEventListener('click', () => {
          const san = btn.getAttribute('data-san');
          if (!san || !game || game.isGameOver()) return;
          try {
            const move = game.move(san);
            if (!move) { toast('Nước khai cuộc không còn hợp lệ trên thế hiện tại.'); return; }
            lastMove = { from: move.from, to: move.to };
            currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 3 })?.name || currentOpening;
            renderView();
            renderOpeningExplorerPanel();
          } catch {
            toast('Không thể đi nước từ explorer.');
          }
        });
      });
    }
    const chip = document.getElementById('openingChip');
    if (chip) {
      const name = result?.named?.name || currentOpening;
      if (name) {
        chip.hidden = false;
        chip.textContent = name;
      } else {
        chip.hidden = true;
        chip.textContent = '';
      }
    }
    return html;
  } catch { return ''; }
}

function scheduleBotMove(delay = 220) {
  cancelScheduledBotMove();
  const expectedEpoch = gameEpoch;
  const expectedFen = game.fen();
  const expectedMode = mode;
  // Chess.com-style humanized think time for Stockfish bots (Elo preset aware).
  let wait = delay;
  if (delay === 0 || delay == null) {
    const preset = resolveBotEloPreset(settings.botTargetElo || settings.botSkill || 1200);
    wait = botThinkDelayMs(preset);
  } else if (isStockfishBotMode?.(mode) || ['stockfish', 'stockfish-beginner'].includes(mode)) {
    const preset = resolveBotEloPreset(settings.botTargetElo || settings.botSkill || 1200);
    wait = Math.max(delay, Math.round(botThinkDelayMs(preset) * 0.65));
  }
  mainBotKickTimer = setTimeout(() => {
    mainBotKickTimer = null;
    if (expectedEpoch !== gameEpoch || expectedFen !== game.fen() || expectedMode !== mode ||
        !botThinking || game.isGameOver() || game.turn() === humanColor) return;
    if (isStockfishBotMode(expectedMode)) askStockfishMove();
    else if (expectedMode === 'vila') askVilaMove();
    else if (expectedMode === 'enginehub') void askEngineHubMove();
  }, Math.max(0, Math.min(5000, Number(wait) || 0)));
}
function cancelPendingHint() {
  if (!pendingHintRequest) return false;
  clearTimeout(pendingHintRequest.timeout);
  pendingHintRequest = null;
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  return true;
}
function cancelMainEngineSearch() {
  cancelMainEngineWatchdog();
  // A new game may start while the current worker is cancelling; keep it locked
  // until the terminal line arrives, then resume only a still-current bot turn.
  if (engineStopPending) {
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    queuedMainEngineMove = false;
    engineSearchActive = true;
    return;
  }
  if (engineSearchActive && !pendingEngineRequest) requestEngineStop();
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
}
document.addEventListener('visibilitychange', () => { if (document.hidden) { pausePuzzleRushTimer(); if (handMouseStream) stopHandMouse(); if (virtualMouseHeld) virtualMouseSetHeld(false); } else if (currentView === 'puzzles') resumePuzzleRushTimer(); });

function setView(view) {
  if (!socialState.token && ['ranked', 'admin'].includes(view)) {
    showAccountGate('login', 'Ghép trận xếp hạng và quản trị cần tài khoản cùng backend online đã triển khai. Bạn vẫn có thể vào chơi ngoại tuyến.');
    return;
  }
  if (!socialState.token && view !== 'friends' && !offlineGuestMode) { showAccountGate('login'); return; }
  const previousView = currentView;
  if (previousView === 'chat' && view !== 'chat' && chatRefreshTimer) { clearInterval(chatRefreshTimer); chatRefreshTimer = null; }
  if (previousView === 'play' && view !== 'play') {
    if (handMouseStream) stopHandMouse();
    if (virtualMouseHeld) virtualMouseSetHeld(false);
  }
  if (currentView === 'puzzles' && view !== 'puzzles') pausePuzzleRushTimer();
  closeResultModal();
  if (currentView === 'ranked' && view !== 'ranked') void quitRankedMatch(true);
  if (view === 'openings') recordDailyEvent('visit_openings');
  if (view === 'coach') recordDailyEvent('visit_coach');
  if (view === 'history') recordDailyEvent('open_history');
  if (view === 'puzzles') recordDailyEvent('visit_puzzles');
  if (view === 'arena') recordDailyEvent('visit_arena');
  if (view === 'games') recordDailyEvent('visit_games');
  if (view !== 'profile') profileTargetUser = null;
  currentView = view;
  $$('.tab').forEach(tab => {
    const active = tab.dataset.view === view;
    tab.classList.toggle('active', active);
    if (active) tab.setAttribute('aria-current', 'page');
    else tab.removeAttribute('aria-current');
  });
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  $('#bottomMore')?.setAttribute('aria-expanded', 'false');
  renderView();
  // A sticky header can cover the top card when the previous screen was scrolled.
  // Navigation should always show the new view from its true top on mobile WebView.
  if (view !== previousView) window.scrollTo(0, 0);
  if (view === 'puzzles') resumePuzzleRushTimer();
}

// ---- Engine speed chip: depth, nodes/second and search time for the engine that just moved ----
let engineSpeed = null;
let engineSpeedInfoAt = 0;
function formatNps(nps) {
  const value = Number(nps) || 0;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(value >= 1e5 ? 0 : 1)}k`;
  return String(Math.round(value));
}
function engineSpeedText() {
  if (!engineSpeed) return '⚡ Tốc độ engine: chờ nước đầu tiên';
  const parts = [`⚡ ${engineSpeed.name}`];
  if (engineSpeed.depth) parts.push(`d${engineSpeed.depth}`);
  if (engineSpeed.nps) parts.push(`${formatNps(engineSpeed.nps)} nút/giây`);
  if (engineSpeed.ms) parts.push(`${(engineSpeed.ms / 1000).toFixed(engineSpeed.ms >= 10000 ? 0 : 1)}s`);
  return parts.join(' · ');
}
function updateEngineSpeedChip() {
  const text = engineSpeedText();
  document.querySelectorAll('[data-engine-speed]').forEach(node => { if (node.textContent !== text) node.textContent = text; });
}
function recordEngineSpeed(name, stats) {
  if (!stats) return;
  engineSpeed = {
    name,
    depth: Number(stats.depth) || 0,
    nps: Number(stats.nps) || (stats.nodes && stats.elapsedMs ? Math.round(stats.nodes * 1000 / stats.elapsedMs) : 0),
    ms: Number(stats.elapsedMs) || 0
  };
  updateEngineSpeedChip();
}
function recordStockfishSpeed(line) {
  // Throttled: Stockfish can print dozens of info lines per second.
  const now = Date.now();
  if (now - engineSpeedInfoAt < 250) return;
  const depth = Number(line.match(/\bdepth (\d+)/)?.[1]);
  const nps = Number(line.match(/\bnps (\d+)/)?.[1]);
  const time = Number(line.match(/\btime (\d+)/)?.[1]);
  if (!depth && !nps) return;
  engineSpeedInfoAt = now;
  engineSpeed = { name: 'Stockfish', depth: depth || engineSpeed?.depth || 0, nps: nps || engineSpeed?.nps || 0, ms: time || engineSpeed?.ms || 0 };
  updateEngineSpeedChip();
}
function engineSpeedChipMarkup() {
  return `<span class="engine-speed-chip" data-engine-speed aria-live="off">${esc(engineSpeedText())}</span>`;
}

function pieceGlyph(piece) {
  // VILA "Royal" set (src/pieces.js): one renderer shared by every board, drag ghost and dialog.
  return pieceSvgMarkup(piece);
}
function squareColor(square) {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1 ? 'dark' : 'light';
}
function syncBoardLayout() {
  const board = $('#board');
  const frame = board?.closest('.board-frame');
  const column = board?.closest('.board-column');
  if (!board || !frame || !column) return;

  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: column.getBoundingClientRect().width,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';

  // Derive piece scale from the actual inner board width rather than vw/DPI
  // heuristics; this survives Android WebView inset and split-screen changes.
  const boardWidth = board.getBoundingClientRect().width;
  const squareSize = calculateChessSquareSize(boardWidth);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function syncArenaBoardLayout() {
  const board = $('#arenaBoard');
  const frame = board?.closest('.arena-board-frame');
  const container = frame?.parentElement;
  if (!board || !frame || !container) return;
  const viewportWidth = Number(window.visualViewport?.width || window.innerWidth || document.documentElement.clientWidth);
  const viewportHeight = Number(window.visualViewport?.height || window.innerHeight || document.documentElement.clientHeight);
  const maxWidth = calculateBoardFrameMaxWidth({
    containerWidth: container.clientWidth,
    viewportWidth,
    viewportHeight
  });
  frame.style.maxWidth = maxWidth > 0 ? `${maxWidth}px` : '100%';
  frame.style.marginInline = 'auto';
  const squareSize = calculateChessSquareSize(board.getBoundingClientRect().width);
  if (squareSize > 0) board.style.setProperty('--square-size', `${squareSize}px`);
}
function scheduleBoardLayoutSync() {
  if (boardResizeRaf) cancelAnimationFrame(boardResizeRaf);
  boardResizeRaf = requestAnimationFrame(() => { boardResizeRaf = 0; syncBoardLayout(); syncArenaBoardLayout(); });
}
function watchBoardLayout() {
  boardResizeObserver?.disconnect();
  boardResizeObserver = null;
  const column = $('.board-column');
  if (column && typeof ResizeObserver !== 'undefined') {
    boardResizeObserver = new ResizeObserver(scheduleBoardLayoutSync);
    boardResizeObserver.observe(column);
  }
  scheduleBoardLayoutSync();
}

function squareToOverlayPoint(square) {
  if (!/^[a-h][1-8]$/.test(String(square || ''))) return null;
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const x = files.indexOf(square[0]); const y = ranks.indexOf(Number(square[1]));
  return x < 0 || y < 0 ? null : { x: x + .5, y: y + .5 };
}
// Chess.com-style arrows: thin shaft, wide triangular head, knight moves drawn as an L,
// one translucent layer per arrow so overlaps never double the opacity.
function arrowMarkup(fromSquare, toSquare, cls, forceKnightL = false) {
  const a = squareToOverlayPoint(fromSquare);
  const b = squareToOverlayPoint(toSquare);
  if (!a || !b || fromSquare === toSquare) return '';
  const adx = Math.abs(b.x - a.x), ady = Math.abs(b.y - a.y);
  const isKnightMove = (Math.round(adx) === 1 && Math.round(ady) === 2) || (Math.round(adx) === 2 && Math.round(ady) === 1);
  const knight = forceKnightL || isKnightMove;
  const bend = isKnightMove
    ? (Math.round(adx) === 2 ? { x: b.x, y: a.y } : { x: a.x, y: b.y })
    : (adx >= ady ? { x: b.x, y: a.y } : { x: a.x, y: b.y });
  const waypoints = knight ? [a, bend, b] : [a, b];
  const headLength = .38, headWidth = .44, startGap = .1, tipGap = .05;
  const last = waypoints[waypoints.length - 1], prev = waypoints[waypoints.length - 2];
  const len = Math.hypot(last.x - prev.x, last.y - prev.y) || 1;
  const ux = (last.x - prev.x) / len, uy = (last.y - prev.y) / len;
  const tip = { x: last.x - ux * tipGap, y: last.y - uy * tipGap };
  const base = { x: tip.x - ux * headLength, y: tip.y - uy * headLength };
  const nx = -uy, ny = ux;
  const first = waypoints[0], second = waypoints[1];
  const firstLen = Math.hypot(second.x - first.x, second.y - first.y) || 1;
  const start = { x: first.x + (second.x - first.x) / firstLen * startGap, y: first.y + (second.y - first.y) / firstLen * startGap };
  const path = [start, ...waypoints.slice(1, -1), base].map(point => `${point.x.toFixed(3)},${point.y.toFixed(3)}`).join(' ');
  const head = [
    tip,
    { x: base.x + nx * headWidth / 2, y: base.y + ny * headWidth / 2 },
    { x: base.x - nx * headWidth / 2, y: base.y - ny * headWidth / 2 }
  ].map(point => `${point.x.toFixed(3)},${point.y.toFixed(3)}`).join(' ');
  return `<g class="${cls}"><polyline class="arrow-shaft" points="${path}"/><polygon class="arrow-head" points="${head}"/></g>`;
}
function renderHintArrow() {
  const svg = $('#boardArrows');
  const hintGroup = $('#hintArrowLine');
  const manualGroup = $('#manualAnnotationLines');
  if (!svg || !hintGroup || !manualGroup) return;
  let hintHtml = '';
  if (lastHintMove && lastHintMove.fen === game.fen()) {
    hintHtml = arrowMarkup(lastHintMove.from, lastHintMove.to, 'board-arrow hint-arrow-line');
  } else if (analysisVariants.length && analysisVariants[0]?.fen === game.fen()) {
    // Show up to three engine lines; the best one is the strongest arrow.
    hintHtml = [...analysisVariants].sort((x, y) => x.multipv - y.multipv).slice(0, 3).map((variant, index) => {
      const uci = variant?.pv?.[0];
      if (variant.fen !== game.fen() || !uci || !/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) return '';
      return arrowMarkup(uci.slice(0, 2), uci.slice(2, 4), `board-arrow hint-arrow-line analysis-arrow analysis-arrow-${index + 1}`);
    }).join('');
  }
  const markFor = (mark, extra = '') => {
    const cls = `manual-${mark.type} manual-${mark.type}-${mark.color || 'green'}${extra}`;
    if (mark.type === 'pencil') {
      const points = Array.isArray(mark.points) ? mark.points.filter(point => Number.isFinite(point?.x) && Number.isFinite(point?.y)) : [];
      if (points.length < 2) return '';
      const list = points.map(point => `${Math.max(0, Math.min(8, point.x)).toFixed(3)},${Math.max(0, Math.min(8, point.y)).toFixed(3)}`).join(' ');
      return `<polyline class="${cls}" points="${list}"/>`;
    }
    const from = squareToOverlayPoint(mark.from);
    const to = squareToOverlayPoint(mark.to || mark.from);
    if (!from || !to) return '';
    if (mark.type === 'square') return `<rect class="manual-square manual-square-${mark.color || 'green'}${extra}" x="${(to.x - .5).toFixed(3)}" y="${(to.y - .5).toFixed(3)}" width="1" height="1"/>`;
    if (mark.type === 'circle' || (mark.from === mark.to && mark.type !== 'knight')) return `<circle class="${cls}" cx="${to.x}" cy="${to.y}" r=".45"/>`;
    return arrowMarkup(mark.from, mark.to, `board-arrow ${cls}`, mark.type === 'knight');
  };
  const items = [...boardAnnotations.slice(-48)].sort((x, y) => (y.type === 'square') - (x.type === 'square')).map(mark => markFor(mark)).join('');
  const preview = annotationPreview ? markFor({ ...annotationPreview, type: annotationPreview.type || (annotationPreview.from === annotationPreview.to ? (annotationPointer?.rightButton ? 'square' : 'circle') : 'arrow') }, ' is-preview') : '';
  hintGroup.innerHTML = hintHtml;
  manualGroup.innerHTML = items + preview;
  svg.hidden = !hintHtml && boardAnnotations.length === 0 && !preview;
}
function toggleBoardAnnotation(mark) {
  // Same arrow/circle again removes it (as on Chess.com); a different colour replaces it.
  const index = boardAnnotations.findIndex(item => item.type === mark.type && item.from === mark.from && item.to === mark.to);
  if (index >= 0) {
    const same = boardAnnotations[index].color === mark.color;
    boardAnnotations.splice(index, 1);
    if (same) return;
  }
  boardAnnotations.push(mark);
}
function annotationColorFromEvent(event) {
  if (event.shiftKey) return 'red';
  if (event.ctrlKey || event.metaKey) return 'yellow';
  if (event.altKey) return 'blue';
  return annotationColor;
}
function scheduleAnnotationPreview() {
  if (annotationPreviewRaf) return;
  annotationPreviewRaf = requestAnimationFrame(() => { annotationPreviewRaf = 0; renderHintArrow(); });
}
function canAnnotateBoard() {
  return Boolean(['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && !arenaRunning); // analysis marks stay available before, during and after a game
}
function syncAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget) return;
  const allowed = canAnnotateBoard();
  widget.classList.add('annotation-tool-docked');
  widget.hidden = !allowed || annotationWidgetHidden;
  const mouseDock = $('#annotationToolsDockMouse');
  const menuDock = $('#annotationToolsDockMenu');
  const mouseToggle = $('#virtualMouseToolsToggle');
  const menuToggle = $('#openDrawingTools');
  if (!allowed) {
    if (mouseDock) mouseDock.hidden = true;
    if (menuDock) menuDock.hidden = true;
  }
  const inMouseDock = Boolean(mouseDock && widget.parentElement === mouseDock && !mouseDock.hidden && allowed && !annotationWidgetHidden);
  const inMenuDock = Boolean(menuDock && widget.parentElement === menuDock && !menuDock.hidden && allowed && !annotationWidgetHidden);
  $('#virtualMousePanel')?.classList.toggle('has-annotation-tools', inMouseDock);
  mouseToggle?.setAttribute('aria-expanded', String(inMouseDock));
  menuToggle?.setAttribute('aria-expanded', String(inMenuDock));
  widget.classList.toggle('is-collapsed', annotationCollapsed);
  const tools = $('#boardAnnotationTools');
  if (tools) tools.hidden = annotationCollapsed;
  const toggle = $('#annotationWidgetToggle');
  if (toggle) {
    toggle.setAttribute('aria-expanded', String(!annotationCollapsed));
    toggle.setAttribute('aria-label', annotationCollapsed ? 'Mở công cụ vẽ phân tích' : 'Thu gọn công cụ vẽ phân tích');
  }
  const labels = { green: 'xanh lá', red: 'đỏ', yellow: 'vàng', blue: 'xanh dương' };
  const colorButton = $('#annotationColorCycle', widget);
  if (colorButton) {
    colorButton.classList.remove('color-green', 'color-red', 'color-yellow', 'color-blue');
    colorButton.classList.add(`color-${annotationColor}`);
    colorButton.setAttribute('aria-label', `Đổi màu nét (hiện tại: ${labels[annotationColor] || labels.green})`);
    colorButton.title = `Đổi màu nét (hiện tại: ${labels[annotationColor] || labels.green})`;
  }
  $$('[data-annotation-color]', widget).forEach(button => {
    const active = button.dataset.annotationColor === annotationColor;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
    button.title = `Màu ${labels[button.dataset.annotationColor] || button.dataset.annotationColor}`;
  });
  $$('[data-annotation-tool]', widget).forEach(button => {
    const active = button.dataset.annotationTool === (annotationTool || 'move');
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
}
function toggleAnnotationToolsDock(location = 'mouse') {
  const widget = $('#boardAnnotationWidget');
  const mouseDock = $('#annotationToolsDockMouse');
  const menuDock = $('#annotationToolsDockMenu');
  const target = location === 'menu' ? menuDock : mouseDock;
  if (!widget || !target) return;
  if (!canAnnotateBoard()) {
    toast('Bút vẽ phân tích dùng trong ván solo với Stockfish hoặc bot VILA.');
    return;
  }
  const alreadyOpen = widget.parentElement === target && !target.hidden && !annotationWidgetHidden;
  if (mouseDock) mouseDock.hidden = true;
  if (menuDock) menuDock.hidden = true;
  if (alreadyOpen) {
    syncAnnotationWidget();
    return;
  }
  target.append(widget);
  target.hidden = false;
  annotationWidgetHidden = false;
  annotationCollapsed = false;
  syncAnnotationWidget();
}

function normalizedBoardPoint(clientX, clientY, rect) {
  if (!rect?.width || !rect?.height) return null;
  return {
    x: Math.max(0, Math.min(8, (clientX - rect.left) / rect.width * 8)),
    y: Math.max(0, Math.min(8, (clientY - rect.top) / rect.height * 8))
  };
}
function squareAtBoardPoint(clientX, clientY, rect) {
  if (!rect?.width || !rect?.height || clientX < rect.left || clientY < rect.top || clientX >= rect.right || clientY >= rect.bottom) return '';
  const col = Math.max(0, Math.min(7, Math.floor((clientX - rect.left) / rect.width * 8)));
  const row = Math.max(0, Math.min(7, Math.floor((clientY - rect.top) / rect.height * 8)));
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const ranks = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  return `${files[col]}${ranks[row]}`;
}
function finishAnnotationPointer(event, board, cancelled = false) {
  const state = annotationPointer;
  if (!state || state.pointerId !== event.pointerId) return false;
  annotationPointer = null;
  annotationPreview = null;
  if (!cancelled && canAnnotateBoard() && state.epoch === gameEpoch && state.fen === game.fen()) {
    const to = squareAtBoardPoint(event.clientX, event.clientY, state.rect) || state.from;
    const color = state.color || annotationColor;
    // Right-button drags mirror Chess.com: drag = arrow, click one square = square mark.
    const tool = state.rightButton ? (to === state.from ? 'square' : 'arrow') : state.tool;
    if (tool === 'pencil') {
      const finalPoint = normalizedBoardPoint(event.clientX, event.clientY, state.rect);
      const points = [...(state.points || [])];
      if (finalPoint) {
        const prev = points[points.length - 1];
        if (!prev || Math.hypot(finalPoint.x - prev.x, finalPoint.y - prev.y) > .025) points.push(finalPoint);
      }
      if (points.length >= 2) toggleBoardAnnotation({ type: 'pencil', color, from: state.from, to, points });
    } else if ((tool === 'arrow' || tool === 'knight') && to !== state.from) toggleBoardAnnotation({ type: tool, color, from: state.from, to });
    else if (tool === 'circle') toggleBoardAnnotation({ type: 'circle', color, from: to, to });
    else if (tool === 'square') toggleBoardAnnotation({ type: 'square', color, from: state.from, to: state.from });
    boardAnnotations = boardAnnotations.slice(-48);
  }
  try { board.releasePointerCapture(event.pointerId); } catch {}
  event.preventDefault?.();
  renderHintArrow();
  return true;
}
function wireAnnotationWidget() {
  const widget = $('#boardAnnotationWidget');
  if (!widget || widget.dataset.wired === 'true') return;
  widget.dataset.wired = 'true';
  syncAnnotationWidget();
  $('#annotationWidgetToggle', widget)?.addEventListener('click', () => {
    annotationCollapsed = !annotationCollapsed;
    syncAnnotationWidget();
  });
  $('#annotationWidgetHide', widget)?.addEventListener('click', () => {
    annotationWidgetHidden = true;
    annotationTool = null;
    const dock = widget.closest('.annotation-tools-dock');
    if (dock) dock.hidden = true;
    syncAnnotationWidget();
  });
  $$('[data-annotation-tool]', widget).forEach(button => button.addEventListener('click', () => {
    const requested = button.dataset.annotationTool;
    if (virtualMouseHeld) virtualMouseSetHeld(false);
    if (requested === 'move') annotationTool = null;
    else annotationTool = annotationTool === requested ? null : requested;
    syncAnnotationWidget();
    const messages = {
      arrow: 'Kéo từ ô xuất phát đến ô đích để vẽ mũi tên thẳng.',
      knight: 'Kéo từ ô đầu tới ô cuối để vẽ đường chữ L kiểu quân Mã.',
      pencil: 'Giữ và kéo trên bàn cờ để vẽ nét tự do. Chọn ♟ để quay lại kéo quân.',
      circle: 'Chạm hoặc kéo tới ô cần khoanh.',
    };
    toast(annotationTool ? `${messages[annotationTool] || 'Chế độ vẽ đã bật'} Chọn “Di chuyển quân” để quay lại chơi cờ.` : 'Đã bật chế độ di chuyển quân.');
  }));
  $$('[data-annotation-color]', widget).forEach(button => button.addEventListener('click', () => {
    const color = button.dataset.annotationColor;
    if (ANNOTATION_COLORS.includes(color)) { annotationColor = color; syncAnnotationWidget(); }
  }));
  $('#annotationClear', widget)?.addEventListener('click', () => {
    boardAnnotations = [];
    annotationPreview = null;
    annotationTool = null;
    renderHintArrow();
    syncAnnotationWidget();
  });
  $('#annotationColorCycle', widget)?.addEventListener('click', () => {
    annotationColor = ANNOTATION_COLORS[(ANNOTATION_COLORS.indexOf(annotationColor) + 1) % ANNOTATION_COLORS.length];
    syncAnnotationWidget();
  });
}

// Velocity-based pointer gain: slow finger = precise (base sensitivity), fast swipe = up to ACCEL_MAX x further.
function virtualMousePointerGain(distance, elapsedMs) {
  const speed = distance / Math.max(4, elapsedMs || 16); // px per ms
  const boost = Math.min(1, Math.max(0, (speed - 0.25) / 1.6));
  return VIRTUAL_MOUSE_SENSITIVITY * (1 + (VIRTUAL_MOUSE_ACCEL_MAX - 1) * boost);
}
function virtualMouseSetPosition(x, y) {
  const pad = 3;
  virtualMousePosition = {
    x: Math.max(pad, Math.min((window.innerWidth || 360) - pad, Number(x) || pad)),
    y: Math.max(pad, Math.min((window.innerHeight || 640) - pad, Number(y) || pad))
  };
  virtualMousePendingPoint = { ...virtualMousePosition };
  if (!virtualMouseMoveRaf) virtualMouseMoveRaf = requestAnimationFrame(() => {
    virtualMouseMoveRaf = 0;
    const point = virtualMousePendingPoint;
    virtualMousePendingPoint = null;
    const cursor = $('#virtualMouseCursor');
    if (cursor && point) cursor.style.transform = `translate3d(${point.x}px, ${point.y}px, 0)`;
    if (virtualMouseHeld && point) virtualMouseDispatchPointer('pointermove', point.x, point.y);
  });
}
function virtualMouseDispatchPointer(type, x = virtualMousePosition.x, y = virtualMousePosition.y) {
  const board = $('#board');
  let target = document.elementFromPoint(x, y);
  const overMouseUi = target?.closest?.('#virtualMousePanel, #virtualMouseCursor, #virtualMouseToggle, #virtualMouseReopen');
  if (overMouseUi && !(virtualMouseHeld && (type === 'pointermove' || type === 'pointerup'))) return false;
  if (type === 'pointermove' && virtualMouseHeld && board) target = board;
  if (type === 'pointerup' && virtualMouseHeld && board) target = board;
  if (!target) return false;
  const event = new PointerEvent(type, {
    bubbles: true, cancelable: true, composed: true,
    pointerId: VIRTUAL_MOUSE_POINTER_ID, pointerType: 'mouse', isPrimary: true,
    clientX: x, clientY: y, button: 0, buttons: type === 'pointerup' ? 0 : (virtualMouseHeld ? 1 : 0),
    pressure: virtualMouseHeld && type !== 'pointerup' ? 0.5 : 0
  });
  target.dispatchEvent(event);
  return true;
}
function virtualMouseClick() {
  const x = virtualMousePosition.x, y = virtualMousePosition.y;
  const target = document.elementFromPoint(x, y);
  if (!target || target.closest?.('#virtualMousePanel, #virtualMouseCursor, #virtualMouseToggle, #virtualMouseReopen')) {
    toast('Đưa con trỏ tới nút hoặc ô cờ trước khi nhấn.'); return;
  }
  const square = target.closest?.('#board .square[data-square]');
  if (square && annotationTool && canAnnotateBoard()) {
    // Synthetic taps need the same annotation path as finger input; .click() alone is suppressed by drawing mode.
    virtualMouseDispatchPointer('pointerdown', x, y);
    virtualMouseDispatchPointer('pointerup', x, y);
    return;
  }
  if (square) {
    // Dispatch an actual click to the delegated square handler; synthetic pointer events
    // alone do not make the browser generate a trusted click event.
    square.click();
  } else if (target.closest?.('#board')) {
    toast('Đưa con trỏ vào một ô cờ cụ thể rồi nhấn.');
  } else {
    const clickable = target.closest?.('button, a, input, select, summary, [role="button"]') || target;
    if (typeof clickable.click === 'function') clickable.click();
  }
}
function virtualMouseSetHeld(held) {
  if (held === virtualMouseHeld) return;
  if (held) {
    const target = document.elementFromPoint(virtualMousePosition.x, virtualMousePosition.y);
    const square = target?.closest?.('#board .square[data-square]');
    const drawing = Boolean(annotationTool && canAnnotateBoard());
    if (!square || (!drawing && !square.querySelector?.('.piece'))) {
      toast(drawing ? 'Đặt con trỏ trên bàn cờ rồi giữ để vẽ.' : 'Đặt con trỏ lên quân cờ muốn di chuyển, rồi giữ để kéo.'); return;
    }
    virtualMouseHeld = true;
    virtualMouseDispatchPointer('pointerdown', virtualMousePosition.x, virtualMousePosition.y);
  } else {
    virtualMouseDispatchPointer('pointerup', virtualMousePosition.x, virtualMousePosition.y);
    virtualMouseHeld = false;
  }
  const button = $('#virtualMouseHold');
  if (button) {
    button.classList.toggle('is-held', virtualMouseHeld);
    button.textContent = virtualMouseHeld ? '⬇ Thả quân' : '↘ Giữ / kéo';
    button.setAttribute('aria-pressed', String(virtualMouseHeld));
  }
  const status = $('#virtualMouseStatus');
  if (status) status.textContent = virtualMouseHeld ? (annotationTool && canAnnotateBoard() ? 'Đang giữ để vẽ · trượt bàn di rồi chạm “Thả quân”.' : 'Đang giữ chuột · di chuyển bàn di rồi chạm “Thả quân”.') : 'Trượt để di chuyển · chạm nhanh để nhấn · chạm 2 lần rồi kéo để giữ quân.';
}
function handMouseSetStatus(message) {
  const status = $('#virtualMouseStatus');
  if (status && status.textContent !== message) status.textContent = message;
}
function handMouseStopFrameLoop() {
  if (handMouseFrameRaf) cancelAnimationFrame(handMouseFrameRaf);
  handMouseFrameRaf = 0;
}
function stopHandMouse(options = {}) {
  handMouseStopFrameLoop();
  if (handMousePinching) {
    if (virtualMouseHeld) virtualMouseSetHeld(false);
    handMousePinching = false;
    handMouseClickCandidate = null;
    handMousePinchStart = null;
  }
  try { handMouseWorker?.terminate(); } catch {}
  handMouseWorker = null;
  handMouseWorkerReady = false;
  handMouseFrameBusy = false;
  handMouseStream?.getTracks?.().forEach(track => { try { track.stop(); } catch {} });
  handMouseStream = null;
  const video = handMouseVideo || $('#virtualMouseVideo');
  if (video) { try { video.pause(); } catch {} video.srcObject = null; video.hidden = true; }
  handMouseVideo = null;
  handMouseLastVideoTime = -1;
  handMouseLastSubmitAt = 0;
  handMouseLastSeenAt = 0;
  handMouseSmoothPoint = null;
  const button = $('#virtualMouseCamera');
  if (button) { button.disabled = false; button.textContent = '✋ Điều khiển bằng tay'; button.classList.remove('is-active'); button.setAttribute('aria-pressed', 'false'); }
  if (virtualMouseHeld) virtualMouseSetHeld(false);
  if (options.status !== false) handMouseSetStatus('Camera đã tắt. Vùng trượt cảm ứng vẫn dùng được, kể cả ngoại tuyến.');
}
function handleHandMouseLandmarks(data) {
  if (!data?.point) {
    if (handMousePinching && Date.now() - handMouseLastSeenAt > 320) {
      if (virtualMouseHeld) virtualMouseSetHeld(false);
      handMousePinching = false; handMouseClickCandidate = null; handMousePinchStart = null;
    }
    handMouseSetStatus('Đưa một bàn tay vào khung hình để điều khiển con trỏ.');
    return;
  }
  handMouseLastSeenAt = Date.now();
  // Front-camera mirror mapping with a light low-pass filter; inference itself runs in a worker.
  const targetX = 14 + (1 - Math.max(0, Math.min(1, Number(data.point.x) || 0))) * Math.max(1, window.innerWidth - 28);
  const targetY = 24 + Math.max(0, Math.min(1, Number(data.point.y) || 0)) * Math.max(1, window.innerHeight - 48);
  const delta = handMouseSmoothPoint ? Math.hypot(targetX - handMouseSmoothPoint.x, targetY - handMouseSmoothPoint.y) : 999;
  const alpha = delta > 70 ? 0.72 : delta < 3 ? 0.34 : 0.54;
  handMouseSmoothPoint = handMouseSmoothPoint
    ? { x: handMouseSmoothPoint.x + (targetX - handMouseSmoothPoint.x) * alpha, y: handMouseSmoothPoint.y + (targetY - handMouseSmoothPoint.y) * alpha }
    : { x: targetX, y: targetY };
  virtualMouseSetPosition(handMouseSmoothPoint.x, handMouseSmoothPoint.y);
  const pinchDistance = Number(data.pinchDistance);
  if (!handMousePinching && pinchDistance > 0 && pinchDistance < HAND_MOUSE_PINCH_DOWN) {
    handMousePinching = true;
    handMousePinchStart = { x: virtualMousePosition.x, y: virtualMousePosition.y };
    const target = document.elementFromPoint(virtualMousePosition.x, virtualMousePosition.y);
    const square = target?.closest?.('#board .square[data-square]');
    if (square?.querySelector?.('.piece')) {
      virtualMouseSetHeld(true);
      handMouseClickCandidate = virtualMouseHeld ? null : square;
      handMouseSetStatus(virtualMouseHeld ? 'Đang giữ quân · di chuyển ngón trỏ và tách hai ngón để thả.' : 'Đang nhấn · tách hai ngón để chọn ô.');
    } else if (square) {
      handMouseClickCandidate = square;
      handMouseSetStatus('Đang nhấn ô cờ · tách hai ngón để chọn.');
    } else {
      handMouseClickCandidate = target?.closest?.('button, a, input, select, summary, [role="button"]') || null;
      handMouseSetStatus('Đang nhấn · tách ngón cái và ngón trỏ để thả.');
    }
  } else if (handMousePinching && pinchDistance > HAND_MOUSE_PINCH_UP) {
    if (virtualMouseHeld) virtualMouseSetHeld(false);
    else if (handMouseClickCandidate && handMousePinchStart && Math.hypot(virtualMousePosition.x - handMousePinchStart.x, virtualMousePosition.y - handMousePinchStart.y) < 22) {
      try { handMouseClickCandidate.click(); } catch {}
    }
    handMousePinching = false;
    handMouseClickCandidate = null;
    handMousePinchStart = null;
    handMouseSetStatus('Tách ngón tay để thả · chụm lại để nhấn hoặc kéo.');
  } else if (!handMousePinching) {
    handMouseSetStatus('Ngón trỏ di chuyển con trỏ · chụm cái + trỏ để nhấn/giữ.');
  }
}
function pumpHandMouseFrames() {
  if (!handMouseStream || !handMouseVideo || !handMouseWorker || !handMouseWorkerReady) return;
  const video = handMouseVideo;
  const now = performance.now();
  if (video.readyState >= 2 && video.currentTime !== handMouseLastVideoTime && !handMouseFrameBusy && now - handMouseLastSubmitAt >= 48) {
    handMouseFrameBusy = true;
    handMouseLastSubmitAt = now;
    handMouseLastVideoTime = video.currentTime;
    const makeBitmap = () => createImageBitmap(video, { resizeWidth: 320, resizeHeight: 240 }).catch(() => createImageBitmap(video));
    makeBitmap().then(bitmap => {
      if (!handMouseWorker || !handMouseStream) { bitmap.close?.(); handMouseFrameBusy = false; return; }
      handMouseWorker.postMessage({ type: 'frame', bitmap, timestamp: now }, [bitmap]);
    }).catch(() => { handMouseFrameBusy = false; });
  }
  handMouseFrameRaf = requestAnimationFrame(pumpHandMouseFrames);
}
async function startHandMouse() {
  if (handMouseStream) { stopHandMouse(); return; }
  const button = $('#virtualMouseCamera');
  if (!navigator.mediaDevices?.getUserMedia || typeof Worker === 'undefined' || typeof createImageBitmap !== 'function') {
    handMouseSetStatus('Thiết bị chưa hỗ trợ camera/worker cần thiết. Dùng vùng trượt cảm ứng thay thế.');
    toast('Không hỗ trợ nhận diện tay trên WebView này; chuột cảm ứng vẫn dùng được.');
    return;
  }
  if (!virtualMouseEnabled) {
    virtualMouseEnabled = true; virtualMouseCollapsed = false;
    if (!virtualMousePosition.x || !virtualMousePosition.y) {
      const rect = $('#board')?.getBoundingClientRect();
      virtualMouseSetPosition(rect ? rect.left + rect.width / 2 : window.innerWidth / 2, rect ? rect.top + rect.height / 2 : window.innerHeight / 2);
    }
    syncVirtualMouse();
  }
  handMouseSetStatus('Đang xin quyền camera…');
  if (button) { button.disabled = true; button.textContent = '⌛ Đang bật camera…'; }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { facingMode: 'user', width: { ideal: 320 }, height: { ideal: 240 }, frameRate: { ideal: 24, max: 30 } }
    });
    handMouseStream = stream;
    const video = $('#virtualMouseVideo');
    if (!video) throw new Error('Không tìm thấy phần tử video cho camera.');
    handMouseVideo = video;
    video.srcObject = stream;
    video.hidden = false;
    await video.play();
    handMouseWorker = new Worker(new URL('./hand-mouse-worker.js', import.meta.url), { type: 'module', name: 'vila-hand-cursor' });
    handMouseWorker.onmessage = event => {
      const data = event.data || {};
      if (data.type === 'ready') {
        handMouseWorkerReady = true;
        if (button) { button.disabled = false; button.textContent = '✋ Tắt camera tay'; button.classList.add('is-active'); button.setAttribute('aria-pressed', 'true'); }
        handMouseSetStatus('Camera đang chạy · trỏ bằng ngón trỏ, chụm cái + trỏ để kéo quân.');
        if (!handMouseFrameRaf) handMouseFrameRaf = requestAnimationFrame(pumpHandMouseFrames);
      } else if (data.type === 'landmarks') {
        handMouseFrameBusy = false;
        handleHandMouseLandmarks(data);
      } else if (data.type === 'no-hand') {
        handMouseFrameBusy = false;
        handleHandMouseLandmarks(null);
      } else if (data.type === 'frame-error') {
        handMouseFrameBusy = false;
      } else if (data.type === 'fatal') {
        const message = String(data.error || 'Không tải được mô hình nhận diện tay.');
        stopHandMouse({ status: false });
        handMouseSetStatus(`Không mở được nhận diện tay: ${message.slice(0, 90)}. Vùng trượt vẫn hoạt động.`);
        toast('Không tải được mô hình tay; có thể tiếp tục dùng chuột cảm ứng.');
      }
    };
    handMouseWorker.onerror = () => {
      stopHandMouse({ status: false });
      handMouseSetStatus('Lỗi bộ nhận diện tay. Vùng trượt cảm ứng vẫn sử dụng được.');
      toast('Bộ nhận diện tay gặp lỗi; chuột cảm ứng vẫn hoạt động.');
    };
    handMouseSetStatus('Đang tải thư viện/mô hình nhận diện tay · cần internet; hình ảnh được xử lý trên thiết bị.');
    handMouseWorker.postMessage({ type: 'init' });
  } catch (error) {
    stopHandMouse({ status: false });
    const message = String(error?.message || error || 'Không thể bật camera.');
    handMouseSetStatus(`Camera chưa bật: ${message.slice(0, 110)}. Dùng vùng trượt cảm ứng thay thế.`);
    toast('Camera chưa bật được. Kiểm tra quyền camera hoặc dùng chuột cảm ứng.');
  } finally {
    if (button && !handMouseStream) button.disabled = false;
  }
}

function syncVirtualMouse() {
  const panel = $('#virtualMousePanel');
  const cursor = $('#virtualMouseCursor');
  const reopen = $('#virtualMouseReopen');
  if (panel) {
    panel.hidden = !virtualMouseEnabled || virtualMouseCollapsed;
    if (virtualMousePanelPosition) {
      panel.style.left = `${virtualMousePanelPosition.left}px`;
      panel.style.top = `${virtualMousePanelPosition.top}px`;
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
    }
  }
  if (cursor) {
    cursor.hidden = !virtualMouseEnabled;
    cursor.style.transform = `translate3d(${virtualMousePosition.x}px, ${virtualMousePosition.y}px, 0)`;
  }
  if (reopen) reopen.hidden = !virtualMouseEnabled || !virtualMouseCollapsed || document.body.classList.contains('match-sheet-open');
  const toggle = $('#virtualMouseToggle');
  if (toggle) { toggle.classList.toggle('is-active', virtualMouseEnabled); toggle.setAttribute('aria-pressed', String(virtualMouseEnabled)); }
  const hold = $('#virtualMouseHold');
  if (hold) { hold.classList.toggle('is-held', virtualMouseHeld); hold.textContent = virtualMouseHeld ? '⬇ Thả quân' : '↘ Giữ / kéo'; hold.setAttribute('aria-pressed', String(virtualMouseHeld)); }
  const cameraButton = $('#virtualMouseCamera');
  if (cameraButton && handMouseStream) { cameraButton.textContent = '✋ Tắt camera tay'; cameraButton.classList.add('is-active'); cameraButton.setAttribute('aria-pressed', 'true'); }
}
function wireVirtualMouse() {
  const panel = $('#virtualMousePanel');
  if (!panel || panel.dataset.wired === 'true') return;
  panel.dataset.wired = 'true';
  const open = () => {
    virtualMouseEnabled = true; virtualMouseCollapsed = false;
    if (!virtualMousePosition.x || !virtualMousePosition.y) {
      const rect = $('#board')?.getBoundingClientRect();
      virtualMouseSetPosition(rect ? rect.left + rect.width / 2 : window.innerWidth / 2, rect ? rect.top + rect.height / 2 : window.innerHeight / 2);
    }
    syncVirtualMouse();
    toast('Chuột ảo bật · trượt vùng cảm ứng để di chuyển con trỏ.');
  };
  const close = () => {
    if (handMouseStream) stopHandMouse();
    if (virtualMouseHeld) virtualMouseSetHeld(false);
    virtualMouseEnabled = false; virtualMouseCollapsed = false;
    syncVirtualMouse();
  };
  $('#virtualMouseToggle')?.addEventListener('click', () => virtualMouseEnabled ? close() : open());
  $('#virtualMouseClose')?.addEventListener('click', close);
  $('#virtualMouseMinimize')?.addEventListener('click', () => { virtualMouseCollapsed = true; syncVirtualMouse(); });
  $('#virtualMouseReopen')?.addEventListener('click', () => { virtualMouseCollapsed = false; syncVirtualMouse(); });
  $('#virtualMouseClick')?.addEventListener('click', virtualMouseClick);
  $('#virtualMouseHold')?.addEventListener('click', () => virtualMouseSetHeld(!virtualMouseHeld));
  $('#virtualMouseCamera')?.addEventListener('click', () => { if (handMouseStream) stopHandMouse(); else startHandMouse(); });
  const pad = $('#virtualMousePad');
  pad?.addEventListener('pointerdown', event => {
    if (!virtualMouseEnabled || virtualMouseCollapsed) return;
    if (virtualMousePadPoint && virtualMousePadPoint.id !== event.pointerId) return; // ignore a second finger
    const now = performance.now();
    virtualMousePadPoint = { id: event.pointerId, x: event.clientX, y: event.clientY, t: now };
    virtualMouseTapState = { startX: event.clientX, startY: event.clientY, t: now, moved: false };
    // Double-tap then keep the finger down = hold/drag, like a laptop touchpad.
    if (now - virtualMouseLastTapAt < VIRTUAL_MOUSE_DOUBLE_TAP_MS && !virtualMouseHeld) {
      virtualMouseSetHeld(true);
      virtualMousePadHeld = virtualMouseHeld;
      virtualMouseTapState.dragTap = true;
    }
    try { pad.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault();
  }, { passive: false });
  pad?.addEventListener('pointermove', event => {
    if (!virtualMousePadPoint || virtualMousePadPoint.id !== event.pointerId) return;
    const prev = virtualMousePadPoint;
    const now = performance.now();
    const dx = event.clientX - prev.x;
    const dy = event.clientY - prev.y;
    virtualMousePadPoint = { id: event.pointerId, x: event.clientX, y: event.clientY, t: now };
    if (virtualMouseTapState && Math.hypot(event.clientX - virtualMouseTapState.startX, event.clientY - virtualMouseTapState.startY) > VIRTUAL_MOUSE_TAP_SLOP) virtualMouseTapState.moved = true;
    const gain = virtualMousePointerGain(Math.hypot(dx, dy), now - (prev.t || now));
    virtualMouseSetPosition(virtualMousePosition.x + dx * gain, virtualMousePosition.y + dy * gain);
    event.preventDefault();
  }, { passive: false });
  const finishPad = event => {
    if (virtualMousePadPoint?.id !== event.pointerId) return;
    const tap = virtualMouseTapState;
    virtualMousePadPoint = null;
    virtualMouseTapState = null;
    try { pad?.releasePointerCapture(event.pointerId); } catch {}
    event.preventDefault?.();
    if (virtualMousePadHeld) {
      virtualMousePadHeld = false;
      if (virtualMouseHeld) virtualMouseSetHeld(false);
      virtualMouseLastTapAt = 0;
      return;
    }
    if (event.type === 'pointerup' && tap && !tap.moved && performance.now() - tap.t <= VIRTUAL_MOUSE_TAP_MS) {
      virtualMouseLastTapAt = performance.now();
      if (!virtualMouseHeld) virtualMouseClick();
    } else {
      virtualMouseLastTapAt = 0;
    }
  };
  pad?.addEventListener('pointerup', finishPad, { passive: false });
  pad?.addEventListener('pointercancel', finishPad, { passive: true });
  window.addEventListener('resize', () => { if (virtualMouseEnabled) virtualMouseSetPosition(virtualMousePosition.x, virtualMousePosition.y); }, { passive: true });
  // The header doubles as a drag grip so the pad can be parked outside the board area.
  const grip = $('#virtualMouseGrip');
  let panelDrag = null;
  grip?.addEventListener('pointerdown', event => {
    if (event.button !== undefined && event.button !== 0) return;
    const rect = panel.getBoundingClientRect();
    panelDrag = { id: event.pointerId, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top };
    try { grip.setPointerCapture(event.pointerId); } catch {}
    event.preventDefault();
  }, { passive: false });
  grip?.addEventListener('pointermove', event => {
    if (!panelDrag || panelDrag.id !== event.pointerId) return;
    const rect = panel.getBoundingClientRect();
    const left = Math.max(4, Math.min(window.innerWidth - rect.width - 4, panelDrag.left + event.clientX - panelDrag.x));
    const top = Math.max(4, Math.min(window.innerHeight - rect.height - 4, panelDrag.top + event.clientY - panelDrag.y));
    virtualMousePanelPosition = { left, top };
    panel.style.left = `${left}px`; panel.style.top = `${top}px`; panel.style.right = 'auto'; panel.style.bottom = 'auto';
    event.preventDefault();
  }, { passive: false });
  const finishPanelDrag = event => {
    if (!panelDrag || panelDrag.id !== event.pointerId) return;
    panelDrag = null;
    try { grip?.releasePointerCapture(event.pointerId); } catch {}
    event.preventDefault?.();
  };
  grip?.addEventListener('pointerup', finishPanelDrag, { passive: false });
  grip?.addEventListener('pointercancel', finishPanelDrag, { passive: true });
  syncVirtualMouse();
}

function canStartBoardDrag(piece) {
  if (!gameStarted || manualGameResult || !piece || arenaRunning || game.isGameOver() || clockFlagged) return false;
  if (isPremoveWindow()) return piece.color === humanColor;
  return Boolean(!botThinking && (mode === 'local' ? piece.color === game.turn() : game.turn() === humanColor && piece.color === humanColor) && piece.color === game.turn());
}
function clearDragGhost() {
  for (const cell of boardSquareMap.values()) cell.classList.remove('drag-over');
  if (dragMoveFrame) cancelAnimationFrame(dragMoveFrame);
  dragMoveFrame = 0;
  dragLatestPoint = null;
  dragGhost?.remove(); dragGhost = null;
  document.body.classList.remove('board-dragging');
}
function updateDragSelection(board, from, legal) {
  selected = from;
  selectedTargets = legal;
  const targetsBySquare = new Map();
  const nextHighlightedSquares = new Set();
  if (from) nextHighlightedSquares.add(from);
  for (const move of legal) {
    if (!targetsBySquare.has(move.to)) targetsBySquare.set(move.to, []);
    targetsBySquare.get(move.to).push(move);
    if (visualSettings.showLegalMoves) nextHighlightedSquares.add(move.to);
  }
  // Do not query and mutate all 64 squares on every tap. Only touch cells which
  // were previously highlighted or are highlighted in the new selection.
  const affectedSquares = new Set([...boardHighlightedSquares, ...nextHighlightedSquares]);
  for (const squareName of affectedSquares) {
    const cell = boardSquareMap.get(squareName);
    if (!cell) continue;
    const targetMoves = targetsBySquare.get(squareName) || [];
    const occupied = Boolean(game.get(squareName));
    cell.classList.toggle('selected', squareName === from);
    const showTargets = visualSettings.showLegalMoves && targetMoves.length > 0;
    cell.classList.toggle('legal-target', showTargets && !occupied);
    cell.classList.toggle('capture-target', showTargets && occupied);
    const dot = cell.querySelector('.move-dot');
    if (showTargets && !occupied && !dot) cell.insertAdjacentHTML('beforeend', '<span class="move-dot"></span>');
    else if ((!showTargets || occupied) && dot) dot.remove();
  }
  boardHighlightedSquares = nextHighlightedSquares;
}
function wireBoardSquareClicks(board) {
  if (!board || board.dataset.clickWired === 'true') return;
  board.dataset.clickWired = 'true';
  // One delegated listener survives board redraws; do not allocate 64 listeners after every move.
  board.addEventListener('click', event => {
    if (annotationTool && canAnnotateBoard()) { event.preventDefault(); return; }
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const suppress = suppressSquareClick;
    if (suppress && Date.now() <= suppress.until && square.dataset.square === suppress.square) {
      suppressSquareClick = null; event.preventDefault(); return;
    }
    if (suppress && Date.now() > suppress.until) suppressSquareClick = null;
    handleSquareClick(square.dataset.square);
  });
}
function wireBoardPointerDrag(board) {
  if (!board || board.dataset.dragWired === 'true') return;
  board.dataset.dragWired = 'true';
  board.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button === 2 && premoveQueue.length && isPremoveWindow()) {
      // Like chess.com: a right click cancels every queued premove.
      clearPendingPremove({ repaint: true, silent: false });
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const rightDraw = event.pointerType === 'mouse' && event.button === 2 && canAnnotateBoard();
    if ((annotationTool && canAnnotateBoard()) || rightDraw) {
      const square = event.target?.closest?.('.square[data-square]');
      if (!square || !board.contains(square)) return;
      const rect = board.getBoundingClientRect();
      const tool = rightDraw ? 'arrow' : annotationTool;
      const point = normalizedBoardPoint(event.clientX, event.clientY, rect);
      annotationPointer = { pointerId: event.pointerId, from: square.dataset.square, rect, epoch: gameEpoch, fen: game.fen(), rightButton: rightDraw, tool, points: tool === 'pencil' && point ? [point] : [], color: rightDraw ? annotationColorFromEvent(event) : annotationColor };
      try { board.setPointerCapture(event.pointerId); } catch {}
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    if (event.pointerType === 'mouse' && boardAnnotations.length && !annotationTool) { boardAnnotations = []; renderHintArrow(); }
    const square = event.target?.closest?.('.square[data-square]');
    if (!square || !board.contains(square)) return;
    const from = square.dataset.square;
    const piece = boardPositionForInput().get(from);
    if (!canStartBoardDrag(piece)) return;
    const isPremove = isPremoveWindow();
    const surface = board.closest('.board-surface') || board;
    const rect = surface.getBoundingClientRect();
    dragState = {
      from, pointerId: event.pointerId, x: event.clientX, y: event.clientY,
      epoch: gameEpoch, fen: game.fen(), moved: false, legal: null, piece, isPremove, sourcePiece: square.querySelector('.piece'),
      surface, rect: { left: rect.left, top: rect.top },
      boardRect: board.getBoundingClientRect(), hoverSquare: ''
    };
    // Pointer capture preserves drop/up events when the finger briefly leaves the board.
    // Legal moves are still deferred until drag intent is confirmed.
    try { board.setPointerCapture(event.pointerId); } catch {}
  }, { passive: false });

  board.addEventListener('pointermove', event => {
    if (annotationPointer && annotationPointer.pointerId === event.pointerId) {
      event.preventDefault();
      const state = annotationPointer;
      const target = squareAtBoardPoint(event.clientX, event.clientY, state.rect);
      if (state.tool === 'pencil') {
        const samples = typeof event.getCoalescedEvents === 'function' ? event.getCoalescedEvents() : [event];
        let added = false;
        for (const sample of (samples?.length ? samples : [event])) {
          const point = normalizedBoardPoint(sample.clientX, sample.clientY, state.rect);
          const previous = state.points[state.points.length - 1];
          if (point && (!previous || Math.hypot(point.x - previous.x, point.y - previous.y) > .035)) { state.points.push(point); added = true; }
        }
        if (added) {
          annotationPreview = { type: 'pencil', color: state.color || annotationColor, from: state.from, to: target || state.from, points: [...state.points] };
          scheduleAnnotationPreview();
        }
      } else if (target && (state.tool === 'arrow' || state.tool === 'knight' || state.rightButton || state.tool === 'circle')) {
        const next = { type: state.rightButton ? (target === state.from ? 'square' : 'arrow') : state.tool, color: state.color || annotationColor, from: state.from, to: target };
        if (!annotationPreview || annotationPreview.to !== next.to || annotationPreview.type !== next.type) { annotationPreview = next; scheduleAnnotationPreview(); }
      }
      return;
    }
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (!state.moved && Math.hypot(event.clientX - state.x, event.clientY - state.y) < (event.pointerType === 'mouse' ? 2 : 3)) return;
    if (!state.moved) {
      // Generate legal targets only after crossing the drag threshold, not on every tap.
      state.legal = state.isPremove ? getPremoveLegalMoves(game, humanColor, Chess, state.from, premoveQueue) : game.moves({ square: state.from, verbose: true });
      if (!state.legal.length) return;
      state.moved = true;
      try { board.setPointerCapture(event.pointerId); } catch {}
      event.preventDefault?.();
      updateDragSelection(board, state.from, state.legal);
      if (state.piece) {
        dragGhost = document.createElement('span');
        dragGhost.className = `drag-ghost piece ${state.piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
        dragGhost.innerHTML = pieceGlyph(state.piece);
        // One square wide, measured once at pointer-down, so the piece never changes size mid-drag.
        dragGhost.style.setProperty('--drag-size', `${(state.boardRect.width / 8).toFixed(2)}px`);
        // Place it under the finger before the first paint to avoid a one-frame jump from the corner.
        dragGhost.style.transform = `translate3d(${event.clientX - state.rect.left}px, ${event.clientY - state.rect.top}px, 0) translate(-50%, -62%) scale(1.08)`;
        state.surface.appendChild(dragGhost);
        document.body.classList.add('board-dragging');
      }
      if (state.sourcePiece) state.sourcePiece.style.opacity = '.22';
    }
    // Pointer events can fire faster than the display refresh. Coalesce DOM writes to one RAF
    // and use a cached board rectangle, avoiding a forced layout read on every touch event.
    if (!state.moved) return;
    event.preventDefault?.();
    dragLatestPoint = { x: event.clientX, y: event.clientY };
    if (!dragMoveFrame) dragMoveFrame = requestAnimationFrame(() => {
      dragMoveFrame = 0;
      const current = dragState;
      const point = dragLatestPoint;
      if (!current || !current.moved || !dragGhost || !point) return;
      // On touch screens lift the piece a little above the fingertip so it stays visible.
      dragGhost.style.transform = `translate3d(${point.x - current.rect.left}px, ${point.y - current.rect.top}px, 0) translate(-50%, -62%) scale(1.08)`;
      const hover = squareAtBoardPoint(point.x, point.y, current.boardRect);
      if (hover !== current.hoverSquare) {
        boardSquareMap.get(current.hoverSquare)?.classList.remove('drag-over');
        current.hoverSquare = hover;
        if (hover && current.legal.some(move => move.to === hover)) boardSquareMap.get(hover)?.classList.add('drag-over');
      }
    });
  }, { passive: false });

  const finish = async event => {
    if (finishAnnotationPointer(event, board)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    dragState = null;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    clearDragGhost();
    // A game can be reset or restored while a finger is still down. A tap/up from the old
    // board must never select a piece in the new position (even when the release was not a drag).
    if (!isMoveContextCurrent(state, { epoch: gameEpoch, fen: game.fen() })) {
      suppressSquareClick = null;
      if (boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets);
      else renderBoard();
      return;
    }
    if (!state.moved) {
      // Pointer capture on Android WebView may retarget the following click to the board itself.
      // Handle taps explicitly, then suppress the synthetic click to prevent double moves.
      suppressSquareClick = { square: state.from, until: Date.now() + 160 };
      handleSquareClick(state.from);
      return;
    }
    event.preventDefault?.();
    // Resolve the drop from the cached board rectangle. elementFromPoint() can
    // return the drag ghost / overlay in Android WebView and adds another DOM hit-test.
    const to = squareAtBoardPoint(event.clientX, event.clientY, state.boardRect);
    // Suppress only a synthetic click for this exact drop square; never block the next real tap.
    suppressSquareClick = { square: to || state.from, until: Date.now() + 160 };
    const choices = to ? state.legal.filter(move => move.to === to) : [];
    if (!choices.length) { updateDragSelection(board, state.from, state.legal); return; }
    let promotion = choices.find(move => move.promotion === 'q')?.promotion || choices.find(move => move.promotion)?.promotion || null;
    if (choices.some(move => move.promotion)) promotion = visualSettings.autoQueen ? 'q' : await choosePromotion(state.isPremove ? humanColor : game.turn());
    if (choices.some(move => move.promotion) && !promotion) { updateDragSelection(board, state.from, state.legal); return; }
    // A promotion chooser can stay open while the player starts a new game or the position changes.
    // Do not apply a drag originating from a stale board state.
    if (state.epoch !== gameEpoch || state.fen !== game.fen()) return;
    if (state.isPremove) queuePremove(state.from, to, promotion);
    else if (promotion || !choices.some(move => move.promotion)) playMove(state.from, to, promotion, { slide: false });
  };
  board.addEventListener('contextmenu', event => { if (canAnnotateBoard()) event.preventDefault(); });
  board.addEventListener('pointerup', finish, { passive: false });
  const cancelDrag = event => {
    if (finishAnnotationPointer(event, board, true)) return;
    const state = dragState;
    if (!state || state.pointerId !== event.pointerId) return;
    if (state.sourcePiece) state.sourcePiece.style.opacity = '';
    dragState = null; clearDragGhost();
    if (boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets); else renderBoard();
  };
  board.addEventListener('pointercancel', cancelDrag, { passive: true });
  board.addEventListener('lostpointercapture', cancelDrag, { passive: true });
}

function getGameResult() {
  if (!gameStarted) return { token: '*', title: 'Chưa bắt đầu', detail: 'Bắt đầu ván để chơi và ghi lại kết quả.' };
  if (manualGameResult) return { ...manualGameResult };
  if (clockFlagged) {
    const winner = clockFlagged === 'w' ? 'Đen' : 'Trắng';
    const token = clockFlagged === 'w' ? '0-1' : '1-0';
    return { token, title: `${winner} thắng do hết giờ`, detail: `${clockPlayerName(clockFlagged)} đã hết thời gian.` };
  }
  if (game.isCheckmate()) {
    const winner = game.turn() === 'w' ? 'Đen' : 'Trắng';
    return { token: winner === 'Trắng' ? '1-0' : '0-1', title: `Chiếu hết — ${winner} thắng`, detail: 'Vua bên thua không còn nước đi hợp lệ để thoát chiếu.' };
  }
  if (game.isStalemate()) return { token: '1/2-1/2', title: 'Hòa do hết nước đi', detail: 'Bên tới lượt không bị chiếu nhưng không có nước đi hợp lệ.' };
  if (game.isThreefoldRepetition()) return { token: '1/2-1/2', title: 'Hòa do lặp thế cờ', detail: 'Thế cờ đã lặp lại ba lần.' };
  if (game.isInsufficientMaterial()) return { token: '1/2-1/2', title: 'Hòa do không đủ quân chiếu hết', detail: 'Không còn đủ lực lượng để chiếu hết theo luật cờ.' };
  if (game.isDraw()) return { token: '1/2-1/2', title: 'Ván cờ hòa', detail: 'Ván đấu kết thúc theo luật cờ vua.' };
  return { token: '*', title: 'Ván cờ đang diễn ra', detail: '' };
}
function reviewMoveLabel(row) {
  const number = Math.max(1, Number(row?.moveNumber) || Math.ceil(Number(row?.ply || 1) / 2));
  return row?.mover === 'w' ? `${number}. ${row?.san || '—'}` : `${number}... ${row?.san || '—'}`;
}
function reviewMoveNotationLabel(row) {
  const notation = reviewMoveLabel(row);
  const symbol = reviewSymbolForJudgement(row?.judgement);
  return symbol ? `${notation} ${symbol}` : notation;
}
function readSavedGames() {
  try {
    const stored = JSON.parse(localStorage.getItem(GAME_HISTORY_KEY) || '[]');
    return Array.isArray(stored) ? stored.filter(item => item && item.id && item.pgn && item.signature).slice(0, 100) : [];
  } catch { return []; }
}
function writeSavedGames(items) {
  try { localStorage.setItem(GAME_HISTORY_KEY, JSON.stringify(items.slice(0, 100))); return true; }
  catch { return false; }
}
function currentGameHistorySignature(result = getGameResult()) {
  return `${currentGameId || 'legacy'}|${mode}|${gameStartFen}|${game.pgn()}|${result.token}|${manualGameResult?.reason || ''}|${clockFlagged || ''}`;
}
function maybeArchiveCompletedGame() {
  if (!gameStarted || mode === 'lichess' || (!game.isGameOver() && !clockFlagged && !manualGameResult)) return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const signature = historyRestoreSignature || currentGameHistorySignature(result);
  const games = readSavedGames();
  const existing = games.findIndex(item => item.signature === signature);
  const reviewRows = completedReviewRows.filter(row => row.ply > 0);
  if (existing >= 0) {
    if (reviewRows.length && reviewRows.length >= (games[existing].reviewRows?.length || 0)) {
      games[existing] = { ...games[existing], reviewRows, reviewStatus: reviewStatus || `Đã phân tích ${reviewRows.length} nửa nước.` };
      writeSavedGames(games);
    }
    return;
  }
  const pgn = gamePgnWithResult();
  const record = {
    id: `g${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    signature, date: new Date().toISOString(), resultToken: result.token, title: result.title,
    detail: result.detail || '', mode, plies: game.history().length,
    opening: recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định',
    opponent: mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? `VILA Offline AI · ${settings.alternativeEngine}` : ['stockfish', 'stockfish-beginner'].includes(mode) ? 'Stockfish' : 'Hai người chơi',
    pgn, startFen: gameStartFen, reviewRows, reviewStatus: reviewStatus || ''
  };
  games.unshift(record);
  writeSavedGames(games.slice(0, 100));
}
function syncArchivedGameReview() {
  const signature = historyRestoreSignature || currentGameHistorySignature(getGameResult());
  const games = readSavedGames();
  const index = games.findIndex(item => item.signature === signature);
  if (index < 0) return;
  games[index] = { ...games[index], reviewRows: completedReviewRows.filter(row => row.ply > 0), reviewStatus: reviewStatus || '' };
  writeSavedGames(games);
}
function getReviewReplayState() {
  const signature = `${gameStartFen}|${game.pgn()}`;
  if (reviewReplayState?.signature === signature) return reviewReplayState;
  const replay = new Chess(gameStartFen);
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '' }];
  const history = game.history({ verbose: true });
  for (let index = 0; index < history.length; index += 1) {
    const move = history[index];
    let made;
    try { made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); }
    catch { made = null; }
    if (!made) break;
    positions.push({ fen: replay.fen(), ply: index + 1, san: made.san, mover: made.color, uci: uciForMove(made), from: made.from, to: made.to, promotion: made.promotion || '' });
  }
  reviewReplayState = { signature, positions, ply: positions.length - 1 };
  return reviewReplayState;
}
function renderReplayBoardMarkup(fen, lastMove = null, judgement = null) {
  let snapshot;
  try { snapshot = new Chess(fen).board(); } catch { snapshot = new Chess().board(); }
  const html = [];
  const symbol = reviewSymbolForJudgement(judgement);
  const tone = judgement?.key || 'neutral';
  const label = judgement?.label || '';
  // Keep the white-at-bottom orientation while pinning the judgement to the moved piece's destination.
  for (let row = 0; row < 8; row += 1) {
    const rank = 8 - row;
    for (let file = 0; file < 8; file += 1) {
      const piece = snapshot[row][file];
      const square = `${String.fromCharCode(97 + file)}${rank}`;
      const light = (row + file) % 2 === 0;
      const fromClass = lastMove?.from === square ? ' review-last-from' : '';
      const toClass = lastMove?.to === square ? ' review-last-to' : '';
      const annotation = lastMove?.to === square && symbol ? `<span class="review-piece-annotation annotation-${esc(tone)}" title="${esc(label)}" aria-label="${esc(label)}">${esc(symbol)}</span>` : '';
      html.push(`<div class="review-replay-square ${light ? 'review-light' : 'review-dark'}${fromClass}${toClass}" role="gridcell" aria-label="${square}${lastMove?.to === square && label ? `, ${esc(label)}` : ''}">${piece ? `<span class="review-replay-piece ${piece.color === 'w' ? 'piece-white' : 'piece-black'}">${pieceGlyph(piece)}</span>` : ''}${annotation}</div>`);
    }
  }
  return html.join('');
}
function reviewArrowLine(uci, kind, label, fen = '') {
  const move = String(uci || '').toLowerCase();
  if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)) return '';
  if (kind === 'best' && fen) {
    try {
      const chess = new Chess(fen);
      const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
      if (!legal.has(move)) return '';
    } catch { return ''; }
  }
  const x1 = move.charCodeAt(0) - 96 - 0.5;
  const y1 = 8.5 - Number(move[1]);
  const x2 = move.charCodeAt(2) - 96 - 0.5;
  const y2 = 8.5 - Number(move[3]);
  const dx = x2 - x1, dy = y2 - y1, length = Math.hypot(dx, dy) || 1;
  const sx = x1 + dx / length * 0.18, sy = y1 + dy / length * 0.18;
  const ex = x2 - dx / length * 0.28, ey = y2 - dy / length * 0.28;
  return `<line class="review-arrow review-arrow-${kind}" x1="${sx.toFixed(3)}" y1="${sy.toFixed(3)}" x2="${ex.toFixed(3)}" y2="${ey.toFixed(3)}" marker-end="url(#reviewArrowHead-${kind})"><title>${esc(label)}</title></line>`;
}
function renderReviewArrowOverlay(fen, lastMove, ply) {
  const row = completedReviewRows.find(item => item.ply === Number(ply));
  const bestUci = row?.nextBestMoveUci || (Number(ply) === 0 ? row?.bestMoveUci : null);
  const playedUci = lastMove ? uciForMove(lastMove) : '';
  const actual = playedUci ? reviewArrowLine(playedUci, 'played', `Nước đã đi: ${lastMove.san || playedUci}`) : '';
  const best = bestUci ? reviewArrowLine(bestUci, 'best', `Nước Stockfish đề xuất: ${bestUci}`, fen) : '';
  if (!actual && !best) return '';
  return `<svg class="review-replay-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" role="img" aria-label="${esc([actual ? 'Mũi tên nước đã đi' : '', best ? 'Mũi tên nước Stockfish đề xuất' : ''].filter(Boolean).join(' và '))}"><defs><marker id="reviewArrowHead-played" markerWidth="0.55" markerHeight="0.55" refX="3.5" refY="2" orient="auto" markerUnits="userSpaceOnUse" viewBox="0 0 4 4"><path d="M0 0 L4 2 L0 4 z" fill="#f5c451"/></marker><marker id="reviewArrowHead-best" markerWidth="0.55" markerHeight="0.55" refX="3.5" refY="2" orient="auto" markerUnits="userSpaceOnUse" viewBox="0 0 4 4"><path d="M0 0 L4 2 L0 4 z" fill="#52e5ca"/></marker></defs>${actual}${best}</svg>`;
}
function updateReviewReplay() {
  const board = $('#reviewReplayBoard');
  if (!board) return;
  const state = getReviewReplayState();
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(state.ply) || 0));
  const position = state.positions[state.ply] || state.positions[0];
  const replayMoves = game.history({ verbose: true });
  const lastMove = state.ply > 0 ? replayMoves[state.ply - 1] : null;
  const judgedPosition = completedReviewRows.find(row => row.ply === state.ply);
  board.innerHTML = renderReplayBoardMarkup(position.fen, lastMove, judgedPosition?.judgement) + renderReviewArrowOverlay(position.fen, lastMove, state.ply);
  const label = $('#reviewReplayPosition');
  if (label) {
    const shownMove = judgedPosition ? reviewMoveNotationLabel(judgedPosition) : reviewMoveLabel(position);
    label.textContent = state.ply === 0 ? 'Vị trí bắt đầu' : `Sau ${shownMove} · ${state.ply}/${state.positions.length - 1}`;
  }
  $$('[data-review-step]').forEach(button => {
    const step = button.dataset.reviewStep;
    button.disabled = (step === 'first' || step === 'prev') ? state.ply === 0 : (step === 'next' || step === 'last') ? state.ply >= state.positions.length - 1 : false;
  });
  $$('[data-review-ply]').forEach(button => {
    const active = Number(button.dataset.reviewPly) === state.ply;
    button.classList.toggle('review-move-active', active);
    if (active) button.setAttribute('aria-current', 'step'); else button.removeAttribute('aria-current');
  });
  updateReviewMoveDetail();
}
function setReviewReplayPly(value) {
  const state = getReviewReplayState();
  const next = typeof value === 'function' ? value(state.ply, state.positions.length - 1) : value;
  state.ply = Math.max(0, Math.min(state.positions.length - 1, Number(next) || 0));
  updateReviewReplay();
}
function restoreSavedGame(record, analyze = false) {
  if (!record) return;
  try {
    cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopFullGameReview(false); stopAnalysis(true); cancelMainEngineSearch(); stopClock();
    const restored = new Chess();
    let archivedPgn = String(record.pgn || '');
    const archivedStartFen = record.startFen || new Chess().fen();
    if (archivedStartFen !== new Chess().fen() && !/\[FEN\s+"/i.test(archivedPgn)) {
      // Backward-compatibility for records saved before custom-FEN PGN headers
      // were added; reconstruct them from the separate archive field.
      const headerEnd = archivedPgn.indexOf('\n\n');
      const fenTags = `[SetUp "1"]\n[FEN "${pgnEscape(archivedStartFen)}"]`;
      archivedPgn = headerEnd >= 0
        ? `${archivedPgn.slice(0, headerEnd)}\n${fenTags}${archivedPgn.slice(headerEnd)}`
        : `${fenTags}\n\n${archivedPgn}`;
    }
    restored.loadPgn(archivedPgn);
    game = restored;
    moveClockSnapshots = []; redoStack = [];
    gameStartFen = archivedStartFen;
    mode = 'local'; humanColor = 'w'; orientation = 'w'; gameStarted = true;
    clockFlagged = null;
    manualGameResult = { token: record.resultToken || '*', title: record.title || 'Ván đã lưu', detail: record.detail || 'Đang xem lại ván đã lưu.', reason: 'saved-replay' };
    completedReviewRows = Array.isArray(record.reviewRows) ? record.reviewRows : [];
    reviewStatus = record.reviewStatus || (completedReviewRows.length ? `Đã tải ${completedReviewRows.length} đánh giá đã lưu.` : 'Ván đã lưu. Có thể phân tích lại bằng Stockfish.');
    historyRestoreSignature = record.signature;
    reviewReplayState = null; selected = null; selectedTargets = []; premoveQueue = []; lastMove = null; botThinking = false;
    resetClock('untimed');
    setView('review');
    if (analyze) setTimeout(() => startFullGameReview(), 120);
  } catch (error) { toast(`Không mở được PGN đã lưu: ${error.message || error}`); }
}
function renderHistoryView() {
  const games = readSavedGames();
  const items = games.map(record => {
    const date = Number.isFinite(Date.parse(record.date)) ? new Date(record.date).toLocaleString('vi-VN') : 'Ngày không rõ';
    const reviewed = record.reviewRows?.length || 0;
    return `<article class="saved-game-card"><div class="saved-game-top"><span class="saved-result ${record.resultToken === '1/2-1/2' ? 'draw' : ''}">${esc(record.resultToken)}</span><div><h3>${esc(record.title || 'Ván đã lưu')}</h3><small>${esc(date)} · ${Number(record.plies) || 0} nửa nước</small></div></div><p>${esc(record.opponent || 'Đối thủ') } · Khai cuộc: ${esc(record.opening || 'Chưa xác định')}</p><div class="saved-game-meta"><span>${reviewed ? `${reviewed} nước đã phân tích` : 'Chưa có phân tích'}</span><span>${esc(record.mode || 'local')}</span></div><div class="saved-game-actions"><button class="primary-btn" type="button" data-history-review="${esc(record.id)}">↶ Xem lại</button><button class="secondary-btn" type="button" data-history-analyze="${esc(record.id)}">♞ Phân tích</button><button class="secondary-btn" type="button" data-history-pgn="${esc(record.id)}">Tải PGN</button><button class="text-btn" type="button" data-history-delete="${esc(record.id)}">Xóa</button></div></article>`;
  }).join('');
  return `<section class="history-view"><header class="page-heading"><div><small class="eyebrow">VÁN ĐẤU CỦA BẠN</small><h1>Lịch sử & xem lại</h1><p>Các ván kết thúc được lưu cục bộ trên thiết bị này. Chọn xem lại, phân tích bằng Stockfish hoặc xuất PGN.</p></div><div class="history-header-actions"><button type="button" class="secondary-btn" id="historyCloudSyncBtn">☁ Đồng bộ đám mây</button><span class="history-count">${games.length}/100 ván</span></div></header><div class="saved-games-list">${items || '<div class="panel empty-state"><b>Chưa có ván đã lưu</b><p>Chơi và kết thúc một ván để nó tự xuất hiện ở đây.</p><button class="primary-btn" type="button" data-history-start>♟ Chơi ván mới</button></div>'}</div><p class="field-hint history-privacy-note">Lịch sử chỉ lưu trong bộ nhớ cục bộ của trình duyệt/WebView này; xóa dữ liệu ứng dụng có thể xóa lịch sử.</p></section>`;
}
function wireHistoryActions() {
  const find = id => readSavedGames().find(record => record.id === id);
  $('#historyCloudSyncBtn')?.addEventListener('click', async () => {
    toast('Đang đồng bộ lịch sử ván cờ với đám mây...');
    const result = await syncHistoryToCloud(settings.backendUrl || '', socialState.token || '', readSavedGames());
    toast(result.message, result.ok ? 'success' : 'info');
  });
  $$('[data-history-review]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyReview), false)));
  $$('[data-history-analyze]').forEach(button => button.addEventListener('click', () => restoreSavedGame(find(button.dataset.historyAnalyze), true)));
  $$('[data-history-pgn]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyPgn);
    if (record) downloadTextFile(record.pgn, `vila-chess-${String(record.date || '').slice(0, 10) || 'game'}.pgn`, 'application/x-chess-pgn;charset=utf-8');
  }));
  $$('[data-history-delete]').forEach(button => button.addEventListener('click', () => {
    const record = find(button.dataset.historyDelete);
    if (!record || (typeof window.confirm === 'function' && !window.confirm('Xóa ván đã lưu này khỏi thiết bị?'))) return;
    writeSavedGames(readSavedGames().filter(item => item.id !== record.id)); renderView();
  }));
  $('[data-history-start]')?.addEventListener('click', () => { mode = 'stockfish'; historyRestoreSignature = ''; openMatchSetup(); });
}
function renderEvaluationGraphMarkup() {
  const rows = completedReviewRows.filter(row => row.ply > 0 && Number.isFinite(row.scoreWhiteCp)).sort((a, b) => a.ply - b.ply);
  if (rows.length < 2) return '<div class="evaluation-graph-empty">Biểu đồ sẽ xuất hiện sau khi Stockfish phân tích ít nhất hai thế cờ.</div>';
  const width = 600, height = 150, padX = 8, padY = 12;
  const points = rows.map((row, index) => {
    const x = padX + (width - padX * 2) * index / (rows.length - 1);
    const cp = Math.max(-1000, Math.min(1000, row.scoreWhiteCp));
    const y = padY + (1000 - cp) / 2000 * (height - padY * 2);
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const centerY = height / 2;
  return `<svg class="evaluation-graph-svg" viewBox="0 0 ${width} ${height}" role="img" aria-label="Biểu đồ lợi thế theo từng thế cờ, góc nhìn Trắng"><line class="evaluation-graph-zero" x1="0" y1="${centerY}" x2="${width}" y2="${centerY}"/><polyline class="evaluation-graph-line" points="${points}"/><text x="8" y="10" class="evaluation-graph-label">Trắng +10</text><text x="8" y="${height - 3}" class="evaluation-graph-label">Đen −10</text></svg><div class="evaluation-graph-caption">${rows.length} thế cờ đã phân tích · điểm quy về góc nhìn Trắng, giới hạn hiển thị ±10 tốt (1000 centipawn).</div>`;
}
function updateEvaluationGraph() {
  const graph = $('#evaluationGraph');
  if (graph) graph.innerHTML = renderEvaluationGraphMarkup();
}
function formatReviewEval(row) {
  if (!row || !Number.isFinite(row.scoreWhiteCp)) return '—';
  if (row.scoreType === 'mate' || Math.abs(row.scoreWhiteCp) >= 9900) {
    const sign = row.scoreWhiteCp < 0 ? '−' : '+';
    const mateIn = Number.isFinite(row.mateWhite) ? Math.abs(row.mateWhite) : 0;
    return `${sign}M${mateIn}`;
  }
  return `${row.scoreWhiteCp >= 0 ? '+' : '−'}${(Math.abs(row.scoreWhiteCp) / 100).toFixed(1)}`;
}
function renderReviewMoveButtonMarkup(row) {
  if (!row) return '<span class="review-empty-move" aria-hidden="true">—</span>';
  const tone = row.judgement?.key || 'neutral';
  const symbol = reviewSymbolForJudgement(row.judgement);
  const description = reviewSymbolDescription(row.judgement);
  const evalText = formatReviewEval(row);
  const lossText = Number.isFinite(row.lossCp) ? `−${(row.lossCp / 100).toFixed(1)}` : '—';
  const spoken = `${reviewMoveLabel(row)} · ${description} · đánh giá ${evalText} · mất ${lossText} tốt`;
  return `<button type="button" class="review-ply-move ${row.mover === 'b' ? 'review-black-move' : 'review-white-move'}" data-review-ply="${Number(row.ply)}" title="${esc(spoken)}" aria-label="${esc(spoken)}"><span class="review-ply-san">${esc(row.san || '—')}</span>${symbol ? `<span class="review-move-symbol symbol-${esc(tone)}" aria-hidden="true">${esc(symbol)}</span>` : ''}<small class="review-ply-eval">${esc(evalText)} · ${esc(lossText)}</small></button>`;
}
function renderReviewMoveListMarkup(rows) {
  const groups = groupReviewedMoves(rows);
  if (!groups.length) return '<div class="empty-state small-empty">Khi phân tích xong, nước đi và nhãn đánh giá sẽ xuất hiện theo cặp Trắng/Đen.</div>';
  return `<div class="review-move-header"><span>#</span><span>Trắng</span><span>Đen</span></div><div class="review-move-pairs">${groups.map(group => `<div class="review-move-pair"><span class="review-move-number">${group.moveNumber}.</span>${renderReviewMoveButtonMarkup(group.white)}${renderReviewMoveButtonMarkup(group.black)}</div>`).join('')}</div>`;
}
function renderReviewSideStatsMarkup(rows) {
  const categoryMeta = [
    ['brilliant', '!!', 'Thiên tài'], ['great', '!', 'Tuyệt vời'], ['book', 'BK', 'Khai cuộc'], ['best', '★', 'Tốt nhất'], ['excellent', '✓', 'Xuất sắc'], ['good', '·', 'Tốt'],
    ['inaccuracy', '?!', 'Thiếu chính xác'], ['mistake', '?', 'Sai lầm'], ['blunder', '??', 'Sai lầm nghiêm trọng'],
    ['missed-win', '⊘', 'Bỏ lỡ']
  ];
  return `<div class="review-side-stats-grid">${[['w', 'Trắng', '♙'], ['b', 'Đen', '♟']].map(([side, label, glyph]) => {
    const summary = summarizeReviewSide(rows, side);
    const chips = categoryMeta.map(([key, symbol, title]) => summary.counts[key]
      ? `<span class="review-count-chip symbol-${key}" title="${esc(title)}"><b>${esc(symbol)}</b>${summary.counts[key]}</span>` : '').join('');
    return `<article class="review-side-stat-card review-side-${side}"><div class="review-side-stat-head"><span class="review-side-glyph" aria-hidden="true">${glyph}</span><div><b>${label}</b><small>${summary.rated}/${summary.total} nước đã đánh giá</small></div></div><div class="review-count-chips">${chips || '<small>Chưa có nhãn đánh giá</small>'}</div></article>`;
  }).join('')}</div>`;
}
function renderReviewMoveDetailMarkup(ply) {
  const safePly = Math.max(0, Number(ply) || 0);
  if (!safePly) return '<div class="review-move-detail-empty">Chọn một nước đi để xem điểm engine, mức mất điểm, biến chính và nước thay thế Stockfish đề xuất.</div>'; 
  const row = completedReviewRows.find(item => item.ply === safePly);
  if (!row) return `<div class="review-move-detail-empty">Nước ${safePly} chưa được phân tích. Chạy “Phân tích toàn ván” để lấy đánh giá và nước gợi ý.</div>`;
  const played = `${esc(reviewMoveLabel(row))}`;
  const best = row.bestMoveSan ? esc(row.bestMoveSan) : '';
  const bestLine = Array.isArray(row.bestLineSan) ? row.bestLineSan.filter(Boolean).slice(0, 8).map(esc).join(' ') : '';
  const isBest = row.moveWasBest === true;
  const suggestion = best
    ? `<span>${isBest ? 'Bạn đã đi nước đầu tiên của biến chính.' : `Nước thay thế: <strong>${best}</strong>`}${Number(row.bestMoveDepth) ? ` <small>(độ sâu ${Number(row.bestMoveDepth)})</small>` : ''}</span>${bestLine ? `<div class="review-best-line"><small>BIẾN ENGINE</small><b>${bestLine}</b></div>` : ''}`
    : 'Engine chưa lưu được biến chính cho thế trước; hãy phân tích lại để có gợi ý nước thay thế.';
  const evalText = formatReviewEval(row);
  const lossText = Number.isFinite(row.lossCp) ? `${(row.lossCp / 100).toFixed(2)} tốt` : 'chưa đủ dữ liệu';
  return `<div class="review-move-detail-top"><div><small>PHÂN TÍCH NƯỚC ĐI</small><b>${played}</b></div><span class="review-detail-eval">${esc(evalText)}</span></div><div class="review-move-detail-grid"><div><small>Đánh giá</small><b class="verdict-${esc(row.judgement?.key || 'neutral')}">${esc(row.judgement?.label || 'Chưa đánh giá')}</b></div><div><small>Điểm đã mất</small><b>${esc(lossText)}</b></div><div><small>Độ sâu</small><b>${Number(row.engineDepth) || '—'}</b></div></div><div class="review-move-suggestion">${suggestion}</div>`;
}
function updateReviewMoveDetail() {
  const detail = $('#reviewMoveDetail');
  if (!detail) return;
  detail.innerHTML = renderReviewMoveDetailMarkup(getReviewReplayState().ply);
}

function renderFullGameResultPanel() {
  const result = getGameResult();
  const reviewRows = completedReviewRows.slice(-160);
  const done = reviewRows.filter(row => row.ply > 0).length;
  const blunders = reviewRows.filter(row => row.judgement?.key === 'blunder').length;
  const mistakes = reviewRows.filter(row => row.judgement?.key === 'mistake').length;
  const rowHtml = renderReviewMoveListMarkup(reviewRows);
  const reviewing = Boolean(reviewSession);
  const reviewSummary = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish 19 NNUE…`
    : reviewStatus || (done ? `Đã phân tích ${done} nửa nước · ${mistakes} sai lầm · ${blunders} blunder.` : 'Chưa phân tích ván. Bấm “Phân tích toàn ván” để đánh giá từng nửa nước bằng Stockfish 19 NNUE nội bộ.');
  const ratingProfile = readRatingProfile();
  const ratingStrip = ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && ['1-0', '0-1', '1/2-1/2'].includes(result.token)
    ? `<div class="rating-result-strip"><span>Elo hiện tại <b>${ratingProfile.elo}</b></span><span>Biến động gần nhất <b class="${ratingProfile.lastChange > 0 ? 'positive' : ratingProfile.lastChange < 0 ? 'negative' : ''}">${ratingProfile.lastChange > 0 ? '+' : ''}${ratingProfile.lastChange}</b></span><small>Điểm Elo ước lượng lưu trên thiết bị</small></div>` : '';
  const replayNow = getReviewReplayState();
  const replayMoveNow = replayNow.ply > 0 ? game.history({ verbose: true })[replayNow.ply - 1] : null;
  const replayJudgementNow = completedReviewRows.find(row => row.ply === replayNow.ply)?.judgement;
  return `<section class="panel full-game-result" id="fullGameResult">
    <div class="panel-heading"><div><small class="eyebrow">KẾT QUẢ & ĐÁNH GIÁ</small><h2>${esc(result.title)}</h2></div><span class="result-token">${esc(result.token)}</span></div>
    <p class="result-detail">${esc(result.detail)}</p>${ratingStrip}
    <div class="result-stats"><span><small>Số nửa nước</small><b>${game.history().length}</b></span><span><small>Khai cuộc</small><b>${esc(recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening || 'Chưa xác định')}</b></span><span><small>Engine</small><b>Stockfish 19 NNUE</b></span></div>
    <div class="review-upper-grid">
      <div class="review-upper-left">
        <section class="evaluation-graph-panel"><div class="review-replay-head"><b>Biểu đồ lợi thế</b><span>Trắng ↔ Đen</span></div><div id="evaluationGraph">${renderEvaluationGraphMarkup()}</div></section>
        <section class="review-side-stats" id="reviewSideStats" aria-label="Tổng hợp chất lượng nước đi theo bên">${renderReviewSideStatsMarkup(reviewRows)}</section>
        ${(() => {
          const dash = buildReviewDashboard(reviewRows || [], { opening: currentOpening?.name, result: manualGameResult?.token || null });
          const w = dash.accuracy.white != null ? dash.accuracy.white + '%' : '—';
          const b = dash.accuracy.black != null ? dash.accuracy.black + '%' : '—';
          return `<div class="review-dashboard" aria-label="Độ chính xác"><div class="review-accuracy-card"><b>${w}</b><span>Độ chính xác Trắng</span></div><div class="review-accuracy-card"><b>${b}</b><span>Độ chính xác Đen</span></div></div><div class="review-stat-row"><span class="review-stat-chip brilliant">!! ${dash.brilliant}</span><span class="review-stat-chip">? ${dash.mistakes}</span><span class="review-stat-chip blunder">?? ${dash.blunders}</span><span class="review-stat-chip">BK ${dash.book}</span></div>`;
        })()}
        <div class="review-symbol-legend" aria-label="Chú giải ký hiệu đánh giá"><span><b class="symbol-brilliant">!!</b> Thiên tài</span><span><b class="symbol-great">!</b> Tuyệt vời</span><span><b class="symbol-best">★</b> Tốt nhất</span><span><b class="symbol-excellent">✓</b> Xuất sắc</span><span><b class="symbol-good">·</b> Tốt</span><span><b class="symbol-book">BK</b> Khai cuộc</span><span><b class="symbol-inaccuracy">?!</b> Thiếu chính xác</span><span><b class="symbol-mistake">?</b> Sai lầm</span><span><b class="symbol-missed-win">⊘</b> Bỏ lỡ</span><span><b class="symbol-blunder">??</b> Sai lầm nghiêm trọng</span></div>
        <p class="review-classification-note">★, ✓ và · là nhãn giao diện cho Tốt nhất/Xuất sắc/Tốt; ?!, ? và ?? là dấu chú giải quen thuộc cho Chưa chuẩn/Sai lầm/Blunder. Phân loại do VILA ước lượng bằng mức mất centipawn, phụ thuộc phiên bản Stockfish, độ sâu và thời gian tìm kiếm; không phải điểm CAPS2 hay thuật toán nội bộ của Chess.com, và không tự chèn các huy hiệu giao diện vào PGN.</p>
        <div class="review-move-list" id="reviewMoveAnalysis">${rowHtml || '<div class="empty-state small-empty">Khi phân tích xong, đánh giá từng nước sẽ hiện ở đây.</div>'}</div>
      </div>
      <div class="review-upper-right">
        <section class="review-replay-panel"><div class="review-replay-head"><b>♟ Xem lại từng nước</b><span id="reviewReplayPosition">Đang ở nước cuối</span></div><div id="reviewReplayBoard" class="review-replay-board" role="grid" aria-label="Bàn cờ xem lại">${renderReplayBoardMarkup(replayNow.positions[replayNow.ply]?.fen || game.fen(), replayMoveNow, replayJudgementNow)}${renderReviewArrowOverlay(replayNow.positions[replayNow.ply]?.fen || game.fen(), replayMoveNow, replayNow.ply)}</div><div class="review-replay-controls"><button type="button" class="secondary-btn" data-review-step="first" aria-label="Về đầu">|◀</button><button type="button" class="secondary-btn" data-review-step="prev" aria-label="Nước trước">‹ Trước</button><button type="button" class="secondary-btn" data-review-step="next" aria-label="Nước sau">Sau ›</button><button type="button" class="secondary-btn" data-review-step="last" aria-label="Đến cuối">▶|</button></div><p class="review-replay-caption">Vàng = nước đã đi · xanh cyan = nước Stockfish đề xuất. Dùng ←/→ để tua, Home/End để về đầu/cuối; chạm biên bản để nhảy tới nước đó.</p></section>
        <section id="reviewMoveDetail" class="review-move-detail" aria-live="polite">${renderReviewMoveDetailMarkup(replayNow.ply)}</section>
        <div class="review-progress" id="reviewProgress">${esc(reviewSummary)}</div>
      </div>
    </div>
    <div class="review-actions"><button id="resultPlayAgain" type="button" class="primary-btn">↻ Chơi lại</button><button id="reviewGameBtn" type="button" class="primary-btn" ${reviewing ? 'disabled' : ''}>♞ Phân tích toàn ván</button><button id="reviewMistakeTrainingBtn" type="button" class="primary-btn">🎯 Luyện theo lỗi của bạn</button><button id="stopReviewBtn" type="button" class="secondary-btn" ${reviewing ? '' : 'disabled'}>Dừng</button><button id="reviewDownloadPGN" type="button" class="secondary-btn">Tải PGN</button></div>
    <section id="mistakeTrainingPanel" class="mistake-training-panel" hidden aria-live="polite"></section>
  </section>`;
}

function collectMistakeTrainingCandidates() {
  const replay = getReviewReplayState();
  const enrichedRows = completedReviewRows.map(row => {
    if (!row || Number(row.ply) < 1) return row;
    const previous = replay.positions[Math.max(0, Number(row.ply) - 1)];
    return { ...row, fenBefore: row.fenBefore || previous?.fen || '', fenAfter: row.fenAfter || replay.positions[Number(row.ply)]?.fen || '' };
  });
  const replayId = historyRestoreSignature || `${gameStartFen}|${game.pgn()}`;
  const playerColor = manualGameResult?.reason === 'saved-replay' || mode === 'local' ? 'both' : humanColor;
  return buildMistakeTrainingItems(enrichedRows, {
    gameId: replayId || 'vila-game', playerColor, now: Date.now(),
    isLegalSolution: ({ fen, uci }) => {
      try { return new Chess(fen).moves({ verbose: true }).some(move => uciForMove(move) === uci); }
      catch { return false; }
    }
  });
}

function renderMistakeTrainingBoard() {
  const training = activeMistakeTraining;
  if (!training?.chess) return '<div class="mistake-training-board-empty">Chọn một lỗi để luyện lại.</div>';
  let board;
  try { board = training.chess.board(); } catch { return '<div class="mistake-training-board-empty">Không thể đọc vị trí cờ của bài luyện này.</div>'; }
  const html = [];
  const orientationSide = training.item?.mover === 'b' ? 'b' : 'w';
  for (let row = 0; row < 8; row += 1) {
    const rank = orientationSide === 'w' ? 8 - row : row + 1;
    for (let col = 0; col < 8; col += 1) {
      const file = String.fromCharCode((orientationSide === 'w' ? 97 + col : 104 - col));
      const square = `${file}${rank}`;
      const piece = board[8 - rank]?.[file.charCodeAt(0) - 97] || null;
      const isSelected = training.selectedSquare === square;
      const last = training.lastMove;
      const isLast = last && (last.from === square || last.to === square);
      const light = squareColor(square) === 'light';
      html.push(`<button type="button" class="mistake-training-square ${light ? 'light' : 'dark'}${isSelected ? ' selected' : ''}${isLast ? ' last-move' : ''}" data-training-square="${square}" aria-label="Ô ${square}${piece ? `, ${piece.color === 'w' ? 'trắng' : 'đen'} ${piece.type}` : ''}">${piece ? `<span class="mistake-training-piece">${pieceGlyph(piece)}</span>` : ''}${row === 7 ? `<small class="train-file">${file}</small>` : ''}${col === 0 ? `<small class="train-rank">${rank}</small>` : ''}</button>`);
    }
  }
  return html.join('');
}

function renderMistakeTrainingPanel() {
  const panel = $('#mistakeTrainingPanel');
  if (!panel) return;
  const training = activeMistakeTraining;
  if (!training?.item) {
    const stats = summarizeMistakeTraining(mistakeTrainingItems);
    const hasScheduled = stats.pending > 0;
    panel.innerHTML = `<div class="mistake-training-head"><div><small class="eyebrow">VILA · PERSONAL COACH</small><h3>Huấn luyện theo lỗi của bạn</h3><p>Hệ thống lấy lại các thế cờ bạn từng đi chưa chuẩn để bạn tự tìm phương án tốt hơn.</p></div><button type="button" class="secondary-btn" data-training-close>Đóng</button></div><div class="mistake-training-empty"><b>${hasScheduled ? 'Đã hoàn thành các bài đến hạn' : 'Chưa có bài luyện phù hợp'}</b><p>${hasScheduled ? 'Các bài còn lại đang nghỉ theo lịch ôn cách quãng. Hãy quay lại khi đến hạn hoặc phân tích ván mới để thêm bài.' : 'Hãy hoàn tất “Phân tích toàn ván”. VILA chỉ tạo bài từ nước sai lầm đã có FEN và nước thay thế hợp lệ của engine.'}</p><div class="mistake-training-stats"><span><b>${stats.total}</b><small>Bài đã lưu</small></span><span><b>${stats.pending}</b><small>Chưa thành thạo</small></span><span><b>${stats.mastered}</b><small>Đã thành thạo</small></span></div></div>`;
    panel.hidden = false;
    return;
  }
  const item = training.item;
  const stats = summarizeMistakeTraining(mistakeTrainingItems);
  const label = ({ blunder: 'Sai lầm nghiêm trọng', 'missed-win': 'Bỏ lỡ cơ hội thắng', mistake: 'Sai lầm', inaccuracy: 'Chưa chính xác' })[item.judgement] || 'Cần luyện lại';
  const correct = training.solved;
  const line = training.hintShown ? uciPvToSan(item.fenBefore, item.bestLineUci || [item.solutionUci]).filter(Boolean).slice(0, 6).join(' ') : '';
  panel.innerHTML = `<div class="mistake-training-head"><div><small class="eyebrow">VILA · PERSONAL COACH</small><h3>Huấn luyện theo lỗi của bạn</h3><p>Hãy tìm nước tốt nhất cho ${item.mover === 'w' ? 'Trắng' : 'Đen'} ở thế cờ này. Bạn cần tự chọn nước đi trên bàn.</p></div><button type="button" class="secondary-btn" data-training-close>Đóng</button></div>
    <div class="mistake-training-layout"><div class="mistake-training-board" role="grid" aria-label="Bàn cờ bài luyện từ lỗi của bạn">${renderMistakeTrainingBoard()}</div><div class="mistake-training-side"><div class="mistake-training-problem-tag">${label} · nước ${item.moveNumber}${item.mover === 'b' ? '…' : '.'}</div><div class="mistake-training-meta"><span><small>Nước bạn đã đi</small><b>${esc(item.playedSan || item.playedUci)}</b></span><span><small>Đánh giá</small><b>−${(item.lossCp / 100).toFixed(2)} tốt</b></span></div><div class="mistake-training-feedback ${correct ? 'correct' : training.feedback ? 'incorrect' : ''}" role="status">${esc(training.feedback || 'Chọn quân cần đi rồi chạm vào ô đến.')}</div>${line ? `<div class="mistake-training-line"><small>BIẾN GỢI Ý</small><b>${esc(line)}</b></div>` : ''}${training.pendingPromotion ? `<div class="mistake-training-promotion" aria-label="Chọn quân phong cấp"><small>CHỌN QUÂN PHONG CẤP</small>${[['q','Hậu'],['r','Xe'],['b','Tượng'],['n','Mã']].map(([piece,label]) => `<button type="button" class="secondary-btn" data-training-promotion="${piece}">${label}</button>`).join('')}</div>` : ''}<div class="mistake-training-controls"><button type="button" class="secondary-btn" data-training-reset>Thử lại vị trí</button><button type="button" class="secondary-btn" data-training-hint ${training.hintShown ? 'disabled' : ''}>Gợi ý</button><button type="button" class="primary-btn" data-training-next ${correct ? '' : 'disabled'}>Câu tiếp theo →</button></div><div class="mistake-training-stats"><span><b>${stats.total}</b><small>Bài đã lưu</small></span><span><b>${stats.pending}</b><small>Chưa thành thạo</small></span><span><b>${stats.mastered}</b><small>Thành thạo</small></span></div><small class="mistake-training-note">Một bài được coi là thành thạo sau 3 lần trả lời đúng liên tiếp ở các lượt ôn tập. Điểm và tiến độ được lưu trên thiết bị này.</small></div></div>`;
  panel.hidden = false;
}

function openMistakeTraining() {
  const panel = $('#mistakeTrainingPanel');
  if (!panel) return;
  panel.onclick = handleMistakeTrainingClick;
  const fresh = collectMistakeTrainingCandidates();
  mistakeTrainingItems = upsertMistakeTrainingItems(mistakeTrainingItems, fresh);
  saveMistakeTrainingItems(mistakeTrainingItems);
  const item = selectNextMistake(mistakeTrainingItems);
  if (!item) {
    activeMistakeTraining = null;
    renderMistakeTrainingPanel();
    panel.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
    return;
  }
  activeMistakeTraining = { item, chess: new Chess(item.fenBefore), selectedSquare: '', lastMove: null, feedback: '', solved: false, hintShown: false, pendingPromotion: null };
  renderMistakeTrainingPanel();
  panel.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
}

function handleMistakeTrainingClick(event) {
  const panel = $('#mistakeTrainingPanel');
  const button = event.target.closest('button');
  if (!panel || !button) return;
  if (button.matches('[data-training-close]')) {
    panel.hidden = true;
    activeMistakeTraining = null;
    return;
  }
  const training = activeMistakeTraining;
  if (!training?.item) return;
  if (button.matches('[data-training-promotion]')) {
    const pending = training.pendingPromotion;
    if (pending) { training.pendingPromotion = null; finishMistakeTrainingMove(pending.from, pending.to, button.dataset.trainingPromotion); }
    return;
  }
  if (button.matches('[data-training-reset]')) {
    training.chess = new Chess(training.item.fenBefore);
    training.selectedSquare = ''; training.lastMove = null; training.feedback = ''; training.solved = false; training.hintShown = false; training.pendingPromotion = null;
    renderMistakeTrainingPanel(); return;
  }
  if (button.matches('[data-training-hint]')) {
    training.hintShown = true;
    training.feedback = training.item.solutionSan ? `Gợi ý: ${training.item.solutionSan} — hãy thử tự tìm đường đi.` : 'Đã mở biến engine trong bảng gợi ý.';
    renderMistakeTrainingPanel(); return;
  }
  if (button.matches('[data-training-next]')) {
    if (!training.solved) return;
    const next = selectNextMistake(mistakeTrainingItems, Date.now(), [training.item.id]);
    if (!next) {
      activeMistakeTraining = null;
      renderMistakeTrainingPanel();
      panel.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
      toast('Bạn đã luyện hết các lỗi đang chờ. Chơi thêm ván và phân tích lại để bổ sung bài mới.', 'success');
      return;
    }
    activeMistakeTraining = { item: next, chess: new Chess(next.fenBefore), selectedSquare: '', lastMove: null, feedback: '', solved: false, hintShown: false, pendingPromotion: null };
    renderMistakeTrainingPanel(); return;
  }
  const squareButton = button.closest('[data-training-square]');
  if (!squareButton) return;
  const square = squareButton.dataset.trainingSquare;
  if (training.solved) return;
  const piece = training.chess.get(square);
  if (!training.selectedSquare) {
    if (piece?.color === training.item.mover) {
      training.selectedSquare = square;
      training.feedback = `Đã chọn quân ở ${square}. Chọn ô đến.`;
    } else training.feedback = `Hãy chọn quân ${training.item.mover === 'w' ? 'Trắng' : 'Đen'} để đi.`;
    renderMistakeTrainingPanel(); return;
  }
  if (piece?.color === training.item.mover) {
    training.selectedSquare = square;
    training.feedback = `Đã chọn quân ở ${square}. Chọn ô đến.`;
    renderMistakeTrainingPanel(); return;
  }
  const fromPiece = training.chess.get(training.selectedSquare);
  if (fromPiece?.type === 'p' && ['1', '8'].includes(square[1])) {
    training.pendingPromotion = { from: training.selectedSquare, to: square };
    training.selectedSquare = '';
    training.feedback = 'Chọn quân phong cấp để hoàn tất nước đi.';
    renderMistakeTrainingPanel(); return;
  }
  finishMistakeTrainingMove(training.selectedSquare, square, 'q');
}

function finishMistakeTrainingMove(from, to, promotion = 'q') {
  const training = activeMistakeTraining;
  if (!training?.item || training.solved) return;
  let move = null;
  try { move = training.chess.move({ from, to, promotion }); } catch {}
  if (!move) {
    training.feedback = 'Nước này không hợp lệ. Hãy chọn lại ô đi hoặc quân của bạn.';
    renderMistakeTrainingPanel(); return;
  }
  const playedUci = uciForMove(move).toLowerCase();
  training.selectedSquare = '';
  training.lastMove = { from: move.from, to: move.to };
  if (playedUci === training.item.solutionUci) {
    training.solved = true;
    const updated = mistakeTrainingItems.find(item => item.id === training.item.id);
    const isSpaced = !updated || updated.attempts === 0 || Date.now() >= updated.dueAt;
    training.feedback = isSpaced
      ? `Chính xác! ${move.san} là nước thay thế của engine.`
      : `Đúng nước ${move.san}! Lượt này quá sớm để tăng chuỗi thành thạo; bài sẽ được đưa lại vào lịch ôn.`;
    const result = recordMistakeAttempt(mistakeTrainingItems, training.item.id, true);
    if (result.updated) { mistakeTrainingItems = result.items; saveMistakeTrainingItems(mistakeTrainingItems); }
    else training.feedback += ' Tiến độ không lưu được vì bài luyện đã bị thay đổi.';
  } else {
    const result = recordMistakeAttempt(mistakeTrainingItems, training.item.id, false);
    if (result.updated) { mistakeTrainingItems = result.items; saveMistakeTrainingItems(mistakeTrainingItems); }
    training.feedback = 'Nước hợp lệ, nhưng chưa phải phương án tốt nhất. Hãy thử lại và chú ý các đòn chiến thuật.';
    training.chess = new Chess(training.item.fenBefore);
    training.lastMove = null;
  }
  renderMistakeTrainingPanel();
}

function renderReviewView() {
  const result = getGameResult();
  const opponent = manualGameResult?.reason === 'saved-replay' ? (manualGameResult?.title || 'Ván đã lưu') : isStockfishBotMode(mode) ? 'Stockfish 19' : mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : mode === 'local' ? 'Hai người chơi' : 'Ván đã lưu';
  const currentReviewCount = completedReviewRows.filter(row => row.ply > 0).length;
  return `<section class="content-page game-review-page">
    <header class="game-review-header"><div class="game-review-heading-copy"><span class="eyebrow">CỜ VUA · GAME REVIEW</span><h1>Xem lại ván đấu</h1><p>Phân tích nước đi, lợi thế và các phương án thay thế bằng Stockfish. Đây là đánh giá của engine, không phải điểm CAPS2 của Chess.com.</p></div><div class="game-review-header-actions"><button id="reviewBackHome" type="button" class="secondary-btn">← Trang chủ</button><button id="reviewPlayAgainTop" type="button" class="primary-btn">↻ Ván mới</button></div></header>
    <section class="game-review-summary panel"><div class="game-review-result-badge ${result.token === '1/2-1/2' ? 'is-draw' : 'is-result'}">${esc(result.token)}</div><div class="game-review-summary-main"><small>KẾT QUẢ · ${esc(opponent)}</small><h2>${esc(result.title)}</h2><p>${esc(result.detail || 'Ván đấu đã kết thúc. Có thể phân tích lại từng nửa nước.')}</p></div><div class="game-review-summary-stats"><span><small>Nửa nước</small><b>${game.history().length}</b></span><span><small>Đã đánh giá</small><b id="reviewSummaryAnalyzed">${currentReviewCount}</b></span><span><small>Engine</small><b>${engineReady && !engineFailed ? 'Sẵn sàng' : 'Chưa sẵn sàng'}</b></span></div></section>
    <div class="game-review-workspace">${renderFullGameResultPanel()}</div>
    <p class="game-review-footnote">Lưu ý: nhãn chất lượng phụ thuộc phiên bản engine, độ sâu, thời gian tìm kiếm và bộ quy tắc VILA. Mức độ chính xác không được quảng bá là thuật toán nội bộ của Chess.com.</p>
  </section>`;
}
let reviewKeyboardShortcutsBound = false;
function wireReviewActions() {
  if (!reviewKeyboardShortcutsBound) {
    reviewKeyboardShortcutsBound = true;
    document.addEventListener('keydown', event => {
      if (currentView !== 'review' || event.altKey || event.ctrlKey || event.metaKey) return;
      const active = document.activeElement;
      if (active && (active.matches('input,textarea,select,[contenteditable="true"]') || active.isContentEditable)) return;
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      setReviewReplayPly((ply, last) => event.key === 'ArrowLeft' ? ply - 1 : event.key === 'ArrowRight' ? ply + 1 : event.key === 'Home' ? 0 : last);
    });
  }
  $('#reviewBackHome')?.addEventListener('click', () => setView('home'));
  $('#reviewPlayAgainTop')?.addEventListener('click', () => freshGame());
  $('#resultPlayAgain')?.addEventListener('click', openMatchSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#reviewMistakeTrainingBtn')?.addEventListener('click', openMistakeTraining);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $$('[data-review-step]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.reviewStep;
    setReviewReplayPly((ply, last) => action === 'first' ? 0 : action === 'prev' ? ply - 1 : action === 'next' ? ply + 1 : action === 'last' ? last : ply);
  }));
  $('#reviewMoveAnalysis')?.addEventListener('click', event => {
    const row = event.target.closest('[data-review-ply]');
    if (row) setReviewReplayPly(Number(row.dataset.reviewPly));
  });
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  updateReviewReplay();
}

function updateReviewPanel() {
  const progress = $('#reviewProgress');
  const list = $('#reviewMoveAnalysis');
  if (!progress || !list) { if (currentView === 'review') renderView(); return; }
  const rows = completedReviewRows.filter(row => row.ply > 0);
  const reviewedCount = $('#reviewSummaryAnalyzed');
  if (reviewedCount) reviewedCount.textContent = String(rows.length);
  const reviewing = Boolean(reviewSession);
  progress.textContent = reviewing
    ? `Đang phân tích ${Math.min(reviewSession.index + 1, reviewSession.positions.length)}/${reviewSession.positions.length} thế cờ bằng Stockfish 19 NNUE…`
    : reviewStatus || `Đã phân tích ${rows.length} nửa nước.`;
  list.innerHTML = renderReviewMoveListMarkup(rows);
  const sideStats = $('#reviewSideStats');
  if (sideStats) sideStats.innerHTML = renderReviewSideStatsMarkup(rows);
  updateEvaluationGraph();
  updateReviewReplay();
}
function stopFullGameReview(announce = false) {
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  const wasReviewing = Boolean(reviewSession);
  reviewSession = null;
  if (wasReviewing) {
    requestEngineStop();
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
  }
  if (announce && wasReviewing) { reviewStatus = 'Đã dừng phân tích theo yêu cầu.'; updateReviewPanel(); }
}
/** Stockfish lines used in a review: MultiPV 2 lets us recognise only-moves (Tuyệt vời). */
function reviewLaneCount() { return (settings.reviewQuality === 'standard' || settings.reviewQuality === 'fast') ? 1 : 2; }
function beginReviewPosition() {
  if (rankedFairPlayLocked()) {
    stopFullGameReview(false);
    reviewStatus = 'Phân tích bị khóa trong khi trận xếp hạng online đang diễn ra.';
    updateReviewPanel();
    return;
  }
  if (!reviewSession) return;
  if (reviewSession.index >= reviewSession.positions.length) {
    {
      const depths = completedReviewRows.filter(row => row.ply > 0 && row.engineDepth > 0).map(row => row.engineDepth);
      const avgDepth = depths.length ? Math.round(depths.reduce((a, b) => a + b, 0) / depths.length) : 0;
      reviewStatus = `Hoàn tất phân tích ${completedReviewRows.filter(row => row.ply > 0).length} nửa nước${avgDepth ? ` · Stockfish độ sâu trung bình ${avgDepth}` : ''}.`;
    }
    reviewSession = null;
    engineSearchActive = false;
    try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
    syncArchivedGameReview();
    updateReviewPanel();
    return;
  }
  if (!engineWorker || !engineReady || engineFailed) {
    reviewStatus = 'Không thể tiếp tục: Stockfish chưa sẵn sàng.';
    reviewSession = null; engineSearchActive = false; updateReviewPanel(); return;
  }
  const position = reviewSession.positions[reviewSession.index];
  reviewSession.currentScoreWhite = Number.isFinite(position.terminalScoreWhiteCp) ? position.terminalScoreWhiteCp : null;
  reviewSession.currentDepth = 0;
  reviewSession.currentSecondWhite = null;
  reviewSession.currentSecondDepth = 0;
  reviewSession.currentScoreType = position.terminalScoreWhiteCp != null && Math.abs(position.terminalScoreWhiteCp) >= 9900 ? 'mate' : 'cp';
  reviewSession.currentMateWhite = position.terminalScoreWhiteCp != null && Math.abs(position.terminalScoreWhiteCp) >= 9900 ? (position.terminalScoreWhiteCp < 0 ? -0 : 0) : null;
  reviewSession.currentBestUci = null;
  reviewSession.currentPvUci = [];
  reviewSession.waiting = true;
  if (position.terminalScoreWhiteCp != null) {
    // Terminal checkmate/draw positions are known exactly; Stockfish may return no PV for them.
    engineSearchActive = false;
    finishReviewPosition(false, null);
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = -3;
  mainEngineSearchFen = position.fen;
  try {
    configureStockfishForAnalysis(reviewLaneCount());
    engineWorker.postMessage('setoption name Hash value 64');
    engineWorker.postMessage(`position fen ${position.fen}`);
    const reviewMoveTimeMs = position.bookMove ? Math.min(resolveReviewMoveTimeMs(settings), 450) : resolveReviewMoveTimeMs(settings);
    engineWorker.postMessage(`go movetime ${reviewMoveTimeMs}`);
    reviewSession.timeout = setTimeout(() => finishReviewPosition(true), reviewMoveTimeMs + 4500);
    updateReviewPanel();
  } catch {
    finishReviewPosition(true);
  }
}
function receiveReviewInfo(line) {
  if (!reviewSession?.waiting) return;
  // Aspiration-window fail lines are only bounds, not real scores; a late one at a higher depth would overwrite the exact score.
  if (/\b(?:lowerbound|upperbound)\b/.test(line)) return;
  const match = line.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
  if (!match) return;
  const depth = Number(line.match(/\bdepth\s+(\d+)/)?.[1] || 0);
  const lane = Number(line.match(/\bmultipv\s+(\d+)/)?.[1] || 1);
  const position = reviewSession.positions[reviewSession.index];
  const turn = String(position.fen).split(/\s+/)[1] || 'w';
  if (lane === 2) {
    // Second-best line: used only to detect "only moves" for the Tuyệt vời label.
    if (depth >= (reviewSession.currentSecondDepth || 0)) {
      reviewSession.currentSecondDepth = depth;
      reviewSession.currentSecondWhite = scoreSideToWhiteCentipawns(Number(match[2]), turn, match[1]);
    }
    return;
  }
  if (lane !== 1) return;
  if (depth < reviewSession.currentDepth) return;
  const rawScore = Number(match[2]);
  reviewSession.currentDepth = depth;
  reviewSession.currentScoreType = match[1];
  reviewSession.currentMateWhite = match[1] === 'mate'
    ? (rawScore === 0 ? (turn === 'w' ? -0 : 0) : rawScore * (turn === 'b' ? -1 : 1))
    : null;
  reviewSession.currentScoreWhite = scoreSideToWhiteCentipawns(rawScore, turn, match[1]);
  const pv = line.match(/\bpv\s+((?:[a-h][1-8][a-h][1-8][qrbn]?\s*)+)/i);
  if (pv) {
    const moves = pv[1].trim().toLowerCase().split(/\s+/).filter(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move)).slice(0, 8);
    if (moves.length) { reviewSession.currentPvUci = moves; reviewSession.currentBestUci = moves[0]; }
  }
}
function finishReviewPosition(timedOut = false, engineBestUci = null) {
  if (!reviewSession?.waiting) return;
  const session = reviewSession;
  if (session.timeout) clearTimeout(session.timeout);
  session.timeout = null;
  session.waiting = false;
  const position = session.positions[session.index];
  const scoreWhiteCp = Number.isFinite(session.currentScoreWhite) ? session.currentScoreWhite : null;
  const bestUciPattern = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;
  const currentBestUci = bestUciPattern.test(String(engineBestUci || ''))
    ? String(engineBestUci).toLowerCase()
    : bestUciPattern.test(String(session.currentBestUci || '')) ? session.currentBestUci : null;
  const currentBestPvUci = currentBestUci
    ? (session.currentPvUci?.[0] === currentBestUci ? session.currentPvUci.slice(0, 8) : [currentBestUci, ...(session.currentPvUci || []).filter(move => move !== currentBestUci).slice(0, 7)])
    : [];
  if (timedOut) {
    reviewStatus = `Đã dừng tại ${session.index}/${session.positions.length}: Stockfish không phản hồi kịp. Các kết quả đã có vẫn được giữ; kiểm tra engine rồi chạy lại phần còn thiếu.`;
    reviewSession = null;
    engineSearchActive = false;
    mainEngineSearchEpoch = -1;
    mainEngineSearchFen = '';
    waitingForStockfishMove = null;
    retireStockfishWorker(reviewStatus);
    updateReviewPanel();
    return;
  }
  if (session.index === 0) {
    completedReviewRows = [{
      ply: 0, san: '', mover: '', scoreWhiteCp, scoreType: session.currentScoreType || (position.terminalScoreWhiteCp != null ? 'mate' : 'cp'),
      mateWhite: session.currentMateWhite, lossCp: null, judgement: null,
      bestMoveUci: currentBestUci, bestMoveSan: currentBestUci ? (uciPvToSan(position.fen, [currentBestUci])[0] || null) : null,
      nextBestMoveUci: currentBestUci, nextBestMoveSan: currentBestUci ? (uciPvToSan(position.fen, [currentBestUci])[0] || null) : null,
      nextBestLineUci: currentBestPvUci, nextBestLineSan: uciPvToSan(position.fen, currentBestPvUci),
      bestLineUci: currentBestPvUci,
      bestLineSan: uciPvToSan(position.fen, currentBestPvUci),
      engineDepth: session.currentDepth || 0
    }];
  } else {
    const beforePosition = session.positions[session.index - 1];
    const bestMoveUci = session.lastBestUci;
    const bestMoveSan = bestMoveUci ? (uciPvToSan(beforePosition.fen, [bestMoveUci])[0] || null) : null;
    const bestLineUci = (session.lastBestPvUci?.length ? session.lastBestPvUci : bestMoveUci ? [bestMoveUci] : []).slice(0, 8);
    const bestLineSan = uciPvToSan(beforePosition.fen, bestLineUci);
    const lossCp = estimateMoveLoss(session.lastScoreWhite, scoreWhiteCp, position.mover);
    const moverBeforeCp = session.lastScoreWhite == null ? null : (position.mover === 'w' ? session.lastScoreWhite : -session.lastScoreWhite);
    const moverAfterCp = scoreWhiteCp == null ? null : (position.mover === 'w' ? scoreWhiteCp : -scoreWhiteCp);
    const moveWasBest = Boolean(bestMoveUci && position.uci && bestMoveUci === position.uci);
    const moverSign = position.mover === 'w' ? 1 : -1;
    const secondGapPct = (Number.isFinite(session.lastSecondWhite) && Number.isFinite(session.lastScoreWhite))
      ? Math.max(0, winChance(moverSign * session.lastScoreWhite) - winChance(moverSign * session.lastSecondWhite)) : null;
    const sacrifice = lossCp != null && lossCp <= 80 && detectSacrifice({ fenBefore: beforePosition.fen, playedUci: position.uci, pvAfterUci: currentBestPvUci, mover: position.mover, ChessConstructor: Chess });
    const judgement = lossCp == null ? null : classifyMoveQuality({ moverBeforeCp, moverAfterCp, isBest: moveWasBest, bookMove: position.bookMove, sacrifice, secondGapPct, depth: Math.min(session.currentDepth || 0, session.lastBestDepth || session.currentDepth || 0) || null });
    completedReviewRows.push({
      ply: position.ply, moveNumber: position.moveNumber || Math.ceil(position.ply / 2), san: position.san, mover: position.mover,
      fenBefore: beforePosition.fen, fenAfter: position.fen,
      scoreWhiteCp, scoreBeforeWhiteCp: session.lastScoreWhite,
      scoreType: session.currentScoreType || (position.terminalScoreWhiteCp != null ? 'mate' : 'cp'),
      mateWhite: session.currentMateWhite, lossCp, judgement, bookMove: Boolean(position.bookMove),
      bestMoveUci: bestMoveUci || null, bestMoveSan, bestLineUci, bestLineSan, playedUci: position.uci || null,
      nextBestMoveUci: currentBestUci, nextBestMoveSan: currentBestUci ? (uciPvToSan(position.fen, [currentBestUci])[0] || null) : null,
      nextBestLineUci: currentBestPvUci, nextBestLineSan: uciPvToSan(position.fen, currentBestPvUci),
      moveWasBest: Boolean(bestMoveUci && position.uci && bestMoveUci === position.uci),
      engineDepth: session.currentDepth || 0, bestMoveDepth: session.lastBestDepth || 0
    });
    syncArchivedGameReview();
  }
  if (scoreWhiteCp != null) session.lastScoreWhite = scoreWhiteCp;
  session.lastSecondWhite = Number.isFinite(session.currentSecondWhite) ? session.currentSecondWhite : null;
  if (currentBestUci) session.lastBestUci = currentBestUci;
  session.lastBestPvUci = currentBestPvUci;
  session.lastBestDepth = session.currentDepth || session.lastBestDepth || 0;
  session.lastScoreType = session.currentScoreType || 'cp';
  session.index += 1;
  mainEngineSearchEpoch = -1; mainEngineSearchFen = '';
  engineSearchActive = false;
  try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
  updateReviewPanel();
  setTimeout(beginReviewPosition, 20);
}
function startFullGameReview() {
  if (rankedFairPlayLocked()) { rankedFairPlayNotice(); return; }
  if (!gameStarted || game.history().length < 1) { toast('Chơi ít nhất một nước rồi mới có thể phân tích toàn ván.'); return; }
  if (!game.isGameOver() && !clockFlagged && !manualGameResult) { toast('Phân tích toàn ván khả dụng sau khi trận kết thúc. Bạn vẫn có thể dùng “Phân tích 3 biến” giữa ván.'); return; }
  if (!engineWorker || !engineReady || engineFailed) { toast('Stockfish chưa sẵn sàng; hãy kiểm tra tệp engine và thử lại.'); return; }
  if (arenaRunning || botThinking || engineStopPending || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || engineSearchActive) { toast('Đợi tác vụ Stockfish hiện tại kết thúc rồi mới phân tích ván.'); return; }
  if (reviewAccessPending) return;
  reviewAccessPending = true;
  requestReviewAccess().then(allowed => { if (allowed) runFullGameReview(); }).catch(() => {}).finally(() => { reviewAccessPending = false; });
}
function runFullGameReview() {
  // The access check is asynchronous, so re-verify that the engine is still free before starting.
  if (!gameStarted || !engineWorker || !engineReady || engineFailed || arenaRunning || botThinking || engineStopPending || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || engineSearchActive) { toast('Stockfish đang bận; hãy bấm phân tích lại sau ít giây.'); return; }
  recordDailyEvent('analyze_game');
  stopFullGameReview(false);
  completedReviewRows = [];
  reviewStatus = (settings.reviewQuality === 'standard' || settings.reviewQuality === 'fast') ? 'Đang chuẩn bị phân tích…' : `Đang chuẩn bị phân tích Stockfish 19 · mức ${settings.reviewQuality === 'max' ? 'cao nhất' : 'sâu'}…`;
  const replay = new Chess(gameStartFen);
  const history = game.history({ verbose: true });
  const positions = [{ fen: replay.fen(), ply: 0, san: '', mover: '', bookMove: false, uci: '', terminalScoreWhiteCp: replay.isCheckmate() ? (replay.turn() === 'w' ? -10000 : 10000) : replay.isDraw() ? 0 : null }];
  const openingPrefixes = buildOpeningBookPrefixes(OPENINGS);
  const sanPath = [];
  const maxPlies = Math.min(history.length, 160);
  for (let i = 0; i < maxPlies; i += 1) {
    const move = history[i];
    const moveNumber = Number(replay.fen().split(/\s+/)[5]) || Math.ceil((i + 1) / 2);
    const made = replay.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    if (!made) { toast(`Không thể dựng lại lịch sử ở nửa nước ${i + 1}; phân tích đã hủy.`); return; }
    sanPath.push(made.san);
    const bookMove = openingPrefixes.has(sanPath.join(' '));
    positions.push({ fen: replay.fen(), ply: i + 1, moveNumber, san: made.san, mover: made.color, from: made.from, to: made.to, uci: `${made.from}${made.to}${made.promotion || ''}`, bookMove, terminalScoreWhiteCp: replay.isCheckmate() ? (replay.turn() === 'w' ? -10000 : 10000) : replay.isDraw() ? 0 : null });
  }
  reviewSession = { positions, index: 0, lastScoreWhite: null, lastBestUci: null, lastBestPvUci: [], lastBestDepth: 0, currentScoreWhite: null, currentScoreType: 'cp', currentMateWhite: null, currentBestUci: null, currentPvUci: [], currentDepth: 0, waiting: false, timeout: null };
  if (history.length > maxPlies) reviewStatus = 'Giới hạn phân tích ở 160 nửa nước để giữ ổn định trên điện thoại.';
  updateReviewPanel();
  beginReviewPosition();
}
function persistLocalGameRecovery() {
  try {
    if (!gameStarted || !game || !['local', 'stockfish', 'vila', 'enginehub'].includes(mode)) return false;
    const result = getGameResult();
    // Completed games are archived by the normal history path, not offered as recoverable games.
    if (result.token !== '*') { clearLocalGameRecovery(); return true; }
    const snapshot = {
      savedAt: Date.now(), gameId: currentGameId, mode, fen: game.fen(),
      moves: game.history({ verbose: true }).map(move => ({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) })),
      startFen: gameStartFen, orientation, humanColor, gameStarted,
      clockHistory: moveClockSnapshots.slice(0, 1000).map(item => item ? captureClockSnapshot(item, item.clockFlagged ?? null) : null),
      clockState: clockState ? { enabled: !!clockState.enabled, remaining: { w: Number(clockState.remaining?.w) || 0, b: Number(clockState.remaining?.b) || 0 }, incrementMs: Number(clockState.incrementMs) || 0 } : null,
      result: null
    };
    localStorage.setItem(LOCAL_GAME_RECOVERY_KEY, JSON.stringify(sealLocalGameRecoverySnapshot(snapshot)));
    return true;
  } catch { return false; /* Storage may be unavailable or full; gameplay must continue. */ }
}
function clearLocalGameRecovery() {
  try { localStorage.removeItem(LOCAL_GAME_RECOVERY_KEY); } catch {}
}
function restoreLocalGameRecovery(snapshot) {
  try {
    const validation = validateLocalGameRecoverySnapshot(snapshot);
    if (!validation.ok) return false;
    const startFen = typeof snapshot.startFen === 'string' ? snapshot.startFen : new Chess().fen();
    const restored = new Chess(startFen);
    for (const item of snapshot.moves) {
      if (!item || !/^[a-h][1-8]$/.test(item.from) || !/^[a-h][1-8]$/.test(item.to) || (item.promotion && !/^[qrbn]$/.test(item.promotion))) return false;
      const move = restored.move({ from: item.from, to: item.to, ...(item.promotion ? { promotion: item.promotion } : {}) });
      if (!move) return false;
    }
    if (restored.fen() !== snapshot.fen || restored.isGameOver()) return false;
    premoveQueue = [];
    game = restored;
    moveClockSnapshots = Array.isArray(snapshot.clockHistory) ? snapshot.clockHistory.slice(0, snapshot.moves.length).map(item => item && item.remaining ? captureClockSnapshot(item, item.clockFlagged ?? null) : null) : [];
    redoStack = []; gameStartFen = startFen; mode = snapshot.mode; currentGameId = typeof snapshot.gameId === 'string' && snapshot.gameId ? snapshot.gameId : `recovered-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`; ratedGameSignature = ''; 
    orientation = snapshot.orientation === 'b' ? 'b' : 'w'; humanColor = snapshot.humanColor === 'b' ? 'b' : 'w';
    gameStarted = true; manualGameResult = null; clockFlagged = null;
    lastMove = restored.history({ verbose: true }).slice(-1).map(move => ({ from: move.from, to: move.to }))[0] || null;
    selected = null; selectedTargets = []; boardAnnotations = []; annotationTool = null;
    historyRestoreSignature = ''; completedReviewRows = []; reviewStatus = '';
    resetClock(settings.clockPreset);
    if (snapshot.clockState && clockState.enabled && snapshot.clockState.enabled && snapshot.clockState.remaining) {
      for (const color of ['w', 'b']) clockState.remaining[color] = Math.max(0, Math.min(24 * 60 * 60 * 1000, Number(snapshot.clockState.remaining[color]) || 0));
      clockState.incrementMs = Math.max(0, Math.min(60_000, Number(snapshot.clockState.incrementMs) || 0));
      clockState.running = !restored.isGameOver();
    }
    persistLocalGameRecovery();
    return true;
  } catch { return false; }
}
function offerLocalGameRecovery() {
  let snapshot;
  try { snapshot = JSON.parse(localStorage.getItem(LOCAL_GAME_RECOVERY_KEY) || 'null'); } catch { clearLocalGameRecovery(); return false; }
  if (!snapshot) return false;
  const validation = validateLocalGameRecoverySnapshot(snapshot);
  if (!validation.ok) { clearLocalGameRecovery(); toast('Bản khôi phục đã hỏng hoặc quá hạn; đã bỏ qua để tránh nạp sai ván cờ.'); return false; }
  if (typeof window.confirm !== 'function' || !window.confirm('Phát hiện ván cờ chưa kết thúc đã lưu trên thiết bị. Bạn có muốn khôi phục ván này không?')) { clearLocalGameRecovery(); return false; }
  if (!restoreLocalGameRecovery(snapshot)) { clearLocalGameRecovery(); toast('Không thể khôi phục ván cờ vì dữ liệu lưu không hợp lệ.'); return false; }
  toast('Đã khôi phục ván cờ từ thiết bị.', 'success');
  return true;
}
const CAPTURED_LABELS = Object.freeze({ p: 'Tốt', n: 'Mã', b: 'Tượng', r: 'Xe', q: 'Hậu' });
function renderCapturedMaterial(color) {
  if (!visualSettings.showCapturedMaterial) return '';
  const summary = summarizeCapturedMaterial(game.history({ verbose: true }));
  const victimColor = color === 'w' ? 'b' : 'w';
  const captured = summary.captured[color];
  const pieces = captured.map((type, index) => `<span class="captured-piece-icon captured-${type} ${victimColor === 'w' ? 'captured-white-piece' : 'captured-black-piece'}" title="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" aria-label="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" data-capture-index="${index}">${pieceSvgMarkup({ type, color: victimColor })}</span>`).join('');
  const advantage = summary.advantage[color];
  return `<div id="captured${color === 'w' ? 'White' : 'Black'}" class="captured-material-row" aria-label="Quân bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn"><span class="captured-piece-list">${pieces}</span>${advantage > 0 ? `<span class="captured-material-advantage" aria-label="Lợi thế vật chất ${advantage}">+${advantage}</span>` : ''}</div>`;
}
function updateCapturedMaterialDisplays() {
  const white = $('#capturedWhite');
  const black = $('#capturedBlack');
  if (white) white.outerHTML = renderCapturedMaterial('w');
  if (black) black.outerHTML = renderCapturedMaterial('b');
}

/** Captured-material tray for AI Arena (uses arenaGame history). */
function renderArenaCapturedMaterial(color) {
  if (!visualSettings.showCapturedMaterial) return '';
  const summary = summarizeCapturedMaterial(arenaGame.history({ verbose: true }));
  const victimColor = color === 'w' ? 'b' : 'w';
  const captured = summary.captured[color] || [];
  const pieces = captured.map((type, index) =>
    `<span class="captured-piece-icon captured-${type} ${victimColor === 'w' ? 'captured-white-piece' : 'captured-black-piece'}" title="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" aria-label="${CAPTURED_LABELS[type]} bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn" data-capture-index="${index}">${pieceSvgMarkup({ type, color: victimColor })}</span>`
  ).join('');
  const advantage = summary.advantage[color] || 0;
  return `<div id="arenaCaptured${color === 'w' ? 'White' : 'Black'}" class="captured-material-row arena-captured-row" aria-label="Quân bị ${color === 'w' ? 'Trắng' : 'Đen'} ăn trong đấu trường"><span class="captured-piece-list">${pieces}</span>${advantage > 0 ? `<span class="captured-material-advantage" aria-label="Lợi thế vật chất ${advantage}">+${advantage}</span>` : ''}</div>`;
}
function updateArenaCapturedMaterialDisplays() {
  const white = $('#arenaCapturedWhite');
  const black = $('#arenaCapturedBlack');
  if (white) white.outerHTML = renderArenaCapturedMaterial('w');
  if (black) black.outerHTML = renderArenaCapturedMaterial('b');
}


// ---- Screen-reader announcements, smooth piece slide, premove chip -------------------------
const PIECE_NAMES_VI = Object.freeze({ k: 'Vua', q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã', p: 'Tốt' });
function announceToScreenReader(message) {
  if (!message || visualSettings.announceMoves === false) return;
  let region = document.getElementById('srAnnouncer');
  if (!region) {
    region = document.createElement('div');
    region.id = 'srAnnouncer'; region.className = 'sr-only';
    region.setAttribute('role', 'status'); region.setAttribute('aria-live', 'polite'); region.setAttribute('aria-atomic', 'true');
    document.body.appendChild(region);
  }
  // Clearing first makes screen readers repeat identical consecutive messages.
  region.textContent = '';
  window.setTimeout(() => { region.textContent = message; }, 30);
}
/** Vietnamese description of a move, e.g. "Trắng nhập thành cánh Vua (O-O)". */
function describeMoveVi(move, mover) {
  if (!move) return '';
  const side = (mover || move.color) === 'w' ? 'Trắng' : 'Đen';
  const flags = String(move.flags || '');
  let text;
  if (flags.includes('k')) text = `${side} nhập thành cánh Vua (O-O)`;
  else if (flags.includes('q')) text = `${side} nhập thành cánh Hậu (O-O-O)`;
  else {
    text = `${side} đi ${PIECE_NAMES_VI[move.piece] || 'quân'} từ ${move.from} đến ${move.to}`;
    if (move.captured) text += `, ăn ${PIECE_NAMES_VI[move.captured] || 'quân'}`;
    if (move.promotion) text += `, phong thành ${PIECE_NAMES_VI[move.promotion] || 'quân'}`;
  }
  if (/#/.test(move.san || '')) text += ', chiếu hết';
  else if (/\+/.test(move.san || '')) text += ', chiếu';
  return text;
}
function announceMove(move, mover) { announceToScreenReader(describeMoveVi(move, mover)); }

let moveSlide = null;
// The yellow landing flash belongs to the render right after a move. renderBoard() rebuilds the
// squares for taps, flips and settings too, which would replay the CSS animation every time.
let landingFlash = { fen: '', until: 0 };
function queueMoveSlide(move) {
  if (!move || !visualSettings.smoothAnimations) { moveSlide = null; return; }
  const slide = { from: move.from, to: move.to, fen: game.fen(), extra: null };
  landingFlash = { fen: slide.fen, until: Date.now() + 500 };
  const flags = String(move.flags || '');
  if (/[kq]/.test(flags)) {
    const kingSide = flags.includes('k');
    const rank = move.to[1];
    slide.extra = { from: `${kingSide ? 'h' : 'a'}${rank}`, to: `${kingSide ? 'f' : 'd'}${rank}` };
  }
  moveSlide = slide;
}
/** One-shot FLIP slide of the piece(s) that just moved. Uses the independent `translate` property. */
function runPendingMoveSlide() {
  const slide = moveSlide;
  moveSlide = null;
  if (!slide || slide.fen !== game.fen() || !visualSettings.smoothAnimations) return;
  // If a queued premove lands on the bot's destination (a capture), the cell holds our piece; do not slide it.
  if (premoveQueue.length && premoveFiringUntil > Date.now() && premoveQueue[0]?.to === slide.to) return;
  if (window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) return;
  for (const part of [slide, slide.extra]) {
    if (!part) continue;
    const fromCell = boardSquareMap.get(part.from);
    const toCell = boardSquareMap.get(part.to);
    const piece = toCell?.querySelector('.piece');
    if (!fromCell || !toCell || !piece || typeof piece.animate !== 'function') continue;
    const a = fromCell.getBoundingClientRect();
    const b = toCell.getBoundingClientRect();
    const dx = a.left - b.left, dy = a.top - b.top;
    if (!dx && !dy) continue;
    toCell.classList.add('sliding');
    piece.classList.add('is-sliding');
    const duration = slideDurationMs(dx, dy, {
      min: part === slide ? 160 : 180,
      max: part === slide ? 280 : 300,
      base: part === slide ? 150 : 170
    });
    const animation = piece.animate(
      slideKeyframes(dx, dy),
      { duration, easing: SLIDE_EASING, fill: 'none' }
    );
    const done = () => {
      toCell.classList.remove('sliding');
      piece.classList.remove('is-sliding');
    };
    animation.addEventListener('finish', done);
    animation.addEventListener('cancel', done);
  }
}
function syncPremoveChip() {
  const status = $('#boardStatus');
  const anchor = status?.closest('.board-bottom');
  let chip = $('#premoveChip');
  const show = Boolean(anchor && premoveQueue.length && botThinking && isPremoveWindow());
  if (!show) { chip?.remove(); return; }
  if (!chip) {
    chip = document.createElement('button');
    chip.type = 'button'; chip.id = 'premoveChip'; chip.className = 'premove-chip';
    chip.addEventListener('click', () => clearPendingPremove({ repaint: true, silent: false }));
    anchor.insertAdjacentElement('afterend', chip);
  }
  chip.textContent = `✕ Hủy ${premoveQueue.length} nước đi trước`;
  chip.setAttribute('aria-label', `Hủy ${premoveQueue.length} nước đi trước`);
}

function renderBoard() {
  const board = $('#board');
  if (!board) return;
  const rows = orientation === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orientation === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targetMovesBySquare = new Map();
  for (const move of selectedTargets) {
    if (!targetMovesBySquare.has(move.to)) targetMovesBySquare.set(move.to, []);
    targetMovesBySquare.get(move.to).push(move);
  }
  const legalTargetSet = new Set(targetMovesBySquare.keys());
  const premoveActive = isPremoveShown() && premoveQueue.length > 0;
  const boardGame = (premoveActive && getPremoveView()) || game;
  const premoveMarks = premoveActive ? premoveSquares(premoveQueue) : { from: new Set(), to: new Set() };
  const premoveGhostMap = premoveActive ? premoveGhostPieces(game, humanColor, premoveQueue, Chess) : new Map();
  const inCheck = boardGame === game && game.isCheck();
  const sideToMove = game.turn();
  // Visual effects for the move that was just played: capture ring, castling glow.
  const fxMove = game.history({ verbose: true }).slice(-1)[0] || null;
  const fxCaptureSq = fxMove && fxMove.captured ? fxMove.to : '';
  const fxCastle = new Map();
  if (fxMove && /[kq]/.test(String(fxMove.flags || ''))) {
    const kingSide = String(fxMove.flags).includes('k');
    const rank = fxMove.to[1];
    fxCastle.set(fxMove.to, kingSide ? 'fx-castle fx-castle-king' : 'fx-castle fx-castle-queen');
    fxCastle.set(`${kingSide ? 'f' : 'd'}${rank}`, 'fx-castle');
  }
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = boardGame.get(sq);
    const isLastFrom = visualSettings.highlightLastMove && lastMove && (lastMove.from === sq || lastMove.to === sq);
    // Blue ring for the move you made, red ring for the opponent's move (white = blue in two-player mode).
    const lastOwner = isLastFrom && fxMove ? ((mode === 'local' ? fxMove.color === 'w' : fxMove.color === humanColor) ? 'last-mine' : 'last-opp') : '';
    const lastLanding = isLastFrom && lastMove.to === sq && landingFlash.fen === game.fen() && Date.now() < landingFlash.until ? 'last-landing' : '';
    const checkKing = inCheck && piece?.type === 'k' && piece.color === sideToMove;
    const isSelected = selected === sq;
    const isPremoveFrom = premoveMarks.from.has(sq);
    const isPremoveTo = premoveMarks.to.has(sq);
    const targetMoves = targetMovesBySquare.get(sq) || [];
    const capture = targetMoves.length && piece;
    const showTarget = visualSettings.showLegalMoves && legalTargetSet.has(sq);
    const classes = ['square', squareColor(sq), isSelected ? 'selected' : '', showTarget ? (capture ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-move' : '', lastOwner, lastLanding, checkKing ? 'in-check' : '', visualSettings.smoothAnimations && fxCaptureSq === sq ? 'fx-capture' : '', visualSettings.smoothAnimations ? (fxCastle.get(sq) || '') : '', isPremoveFrom ? 'premove-from' : '', isPremoveTo ? 'premove-to' : ''].filter(Boolean).join(' ');
    const pieceName = piece ? ({ k: 'vua', q: 'hậu', r: 'xe', b: 'tượng', n: 'mã', p: 'tốt' }[piece.type] || 'quân') : '';
    // The premove view already has the queued pieces on their destination squares, so the ghost
    // is that piece drawn faded (an empty-square ghost would duplicate a piece on multi-step queues).
    const ghostInfo = premoveGhostMap.get(sq) || null;
    const ghost = (piece && ghostInfo && isPremoveTo && piece.type === ghostInfo.type && piece.color === ghostInfo.color) ? ghostInfo : null;
    const glyph = piece
      ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}${ghost ? ' premove-ghost' : ''}" aria-hidden="true">${pieceGlyph(piece)}</span>`
      : '';
    const accessibleSquareLabel = `Ô ${sq}${piece ? `, ${piece.color === 'w' ? 'quân Trắng' : 'quân Đen'} ${pieceName}` : ''}${ghost ? ', nước đi trước' : ''}${isSelected ? ', đang chọn' : ''}${legalTargetSet.has(sq) ? ', nước đi hợp lệ' : ''}`;
    // Rank labels stay on the left; every square on the bottom row gets its
    // file label. `files` is already reversed when the board is flipped.
    const coord = visualSettings.showCoordinates ? ((colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : '') + (rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : '')) : '';
    html += `<button type="button" class="${classes}" data-square="${sq}" aria-label="${accessibleSquareLabel}">${glyph}${showTarget && targetMoves.length && !capture ? '<span class="move-dot"></span>' : ''}${coord}</button>`;
  }));
  board.innerHTML = html;
  updateCapturedMaterialDisplays();
  boardSquareMap = new Map($$('.square[data-square]', board).map(square => [square.dataset.square, square]));
  boardHighlightedSquares = new Set([...(selected ? [selected] : []), ...(visualSettings.showLegalMoves ? selectedTargets.map(move => move.to) : [])]);
  syncBoardLayout();
  wireBoardSquareClicks(board);
  wireBoardPointerDrag(board);
  renderHintArrow();
  syncAnnotationWidget();
  $('#boardStatus')?.replaceChildren(document.createTextNode(premoveQueue.length && botThinking ? `${describePremoveQueue(premoveQueue)}. Tự đi lần lượt khi tới lượt bạn; ${window.matchMedia?.('(pointer: coarse)')?.matches ? 'bấm nút Hủy bên dưới để xóa' : 'chuột phải, Esc hoặc nút Hủy để xóa'}.` : gameStarted ? positionStatus() : 'Sẵn sàng — nhấn Bắt đầu ván mới để chơi.'));
  syncPremoveChip();
  runPendingMoveSlide();
  const moveList = $('#moveList');
  if (moveList) renderMoveList(moveList);
  const fenBox = $('#fenText');
  if (fenBox) fenBox.textContent = game.fen();
  const pgnBox = $('#pgnText');
  if (pgnBox) pgnBox.textContent = game.pgn();
  const evalBox = $('#evalNumber');
  if (evalBox && !engineSearchActive) evalBox.textContent = '—';
  $('#turnChip')?.replaceChildren(document.createTextNode(game.turn() === 'w' ? 'Lượt Trắng' : 'Lượt Đen'));
  $('#resignBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  $('#offerDrawBtn')?.toggleAttribute('disabled', !gameStarted || game.isGameOver() || Boolean(clockFlagged) || Boolean(manualGameResult));
  const moveCount = $('#gameMoveCount');
  if (moveCount) moveCount.textContent = String(game.history().length);
  const statusText = $('#gameStatusText');
  if (statusText) statusText.textContent = !gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged || manualGameResult) ? 'Kết thúc' : premoveQueue.length && botThinking ? `Đã xếp ${premoveQueue.length} nước đi trước` : botThinking ? 'Bot đang tính' : 'Đang chơi';
  const openingLabel = $('#openingRecognition');
  if (openingLabel) {
    const recognized = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
    openingLabel.textContent = recognized ? `Khai cuộc nhận diện: ${recognized.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
  }
  renderClockDisplay();
  updateUndoRedoControls();
  renderAnalysisPanel();
  maybeShowPlayResultModal();
}
function updateUndoRedoControls() {
  const undo = $('#undoMove');
  const redo = $('#redoMove');
  if (undo) undo.disabled = !gameStarted || !game.history().length || botThinking || mode === 'lichess' || arenaRunning;
  if (redo) redo.disabled = !redoStack.length || botThinking || mode === 'lichess' || arenaRunning;
}
function positionStatus(chess = game) {
  if (chess === game && clockFlagged) return `Hết giờ — ${clockPlayerName(clockFlagged)} thua`;
  if (chess.isCheckmate()) return `Chiếu hết — ${chess.turn() === 'w' ? 'Đen' : 'Trắng'} thắng`;
  if (chess.isStalemate()) return 'Hòa do hết nước đi';
  if (chess.isThreefoldRepetition()) return 'Hòa do lặp lại thế cờ';
  if (chess.isInsufficientMaterial()) return 'Hòa do không đủ quân chiếu hết';
  if (chess.isDraw()) return 'Ván cờ hòa';
  return `${chess.turn() === 'w' ? 'Trắng' : 'Đen'} đang đi${chess.isCheck() ? ' — đang bị chiếu!' : ''}`;
}
/** One notation cell. Castling (O-O / O-O-O) is monospaced and never wraps; the latest ply is marked. */
function moveSanCell(san, isLast = false) {
  const text = String(san ?? '');
  const classes = ['move-san', /^O-O(-O)?[+#]?$/.test(text) ? 'is-castle' : '', isLast ? 'is-last' : ''].filter(Boolean).join(' ');
  return `<span class="${classes}"${isLast ? ' aria-current="true"' : ''}>${esc(text)}</span>`;
}
function renderMoveList(element) {
  const history = game.history();
  if (!history.length) { element.__moveRows = ''; element.innerHTML = '<div class="empty-state">Nước đi của bạn sẽ xuất hiện ở đây.</div>'; return; }
  let rows = '';
  for (let i = 0; i < history.length; i += 2) {
    rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2) + 1}.</span>${moveSanCell(history[i], i === history.length - 1)}${moveSanCell(history[i + 1] || '…', i + 1 === history.length - 1)}</div>`;
  }
  // Selection and premove repaints do not change the move list; skip the DOM rebuild and forced scroll layout.
  if (element.__moveRows === rows && element.childElementCount) return;
  element.__moveRows = rows;
  element.innerHTML = rows;
  element.scrollTop = element.scrollHeight;
}
function isPremoveWindow() {
  return Boolean(visualSettings.premoveEnabled && gameStarted && botThinking && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) &&
    !manualGameResult && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor);
}
/** Virtual board with every queued premove already played (cached per position + queue). */
function getPremoveView() {
  if (!premoveQueue.length || !isPremoveShown()) return null;
  const key = `${game.fen()}|${premoveQueue.map(item => `${item.from}${item.to}${item.promotion || ''}`).join(',')}`;
  if (premoveViewCache.key !== key) premoveViewCache = { key, chess: buildPremovePosition(game, humanColor, premoveQueue, Chess) };
  return premoveViewCache.chess;
}
/** The position the player is looking at: the virtual premove board while premoving, else the real game. */
function boardPositionForInput() {
  return (isPremoveWindow() && getPremoveView()) || game;
}
function clearPendingPremove({ repaint = false, silent = true } = {}) {
  const count = premoveQueue.length;
  premoveQueue = [];
  premoveViewCache = { key: '', chess: null };
  if (count) {
    if (!silent) toast(count === 1 ? 'Đã hủy nước đi trước.' : `Đã hủy ${count} nước đi trước.`);
    announceToScreenReader(count === 1 ? 'Đã hủy nước đi trước.' : `Đã hủy ${count} nước đi trước.`);
  }
  if (repaint && count && currentView === 'play') renderBoard();
  return count > 0;
}
function queuePremove(from, to, promotion = null) {
  if (!isPremoveWindow()) return false;
  const next = appendPremove(game, humanColor, Chess, premoveQueue, from, to, promotion);
  if (!next) return false;
  premoveQueue = next;
  premoveViewCache = { key: '', chess: null };
  selected = null; selectedTargets = [];
  if (currentView === 'play') renderBoard();
  announceToScreenReader(`Đã xếp nước đi trước ${from} đến ${to}. Tổng ${premoveQueue.length} nước.`);
  return true;
}
/**
 * Play the first queued premove on the real board. A queued move that is no longer legal (the
 * opponent captured or blocked it) cancels the whole queue, like chess.com. Returns true if played.
 */
function executeNextPremove() {
  const queue = premoveQueue;
  premoveQueue = [];
  premoveViewCache = { key: '', chess: null };
  selected = null; selectedTargets = [];
  if (!queue.length || !gameStarted || game.isGameOver() || clockFlagged || manualGameResult || game.turn() !== humanColor) return false;
  const { move, rest, cancelled } = takeNextPremove(game, queue, humanColor);
  if (!move) {
    const first = cancelled[0];
    toast(`Đối thủ đi khác nên nước đi trước ${first.from} → ${first.to}${cancelled.length > 1 ? ` và ${cancelled.length - 1} nước kế tiếp` : ''} đã bị hủy.`);
    announceToScreenReader('Các nước đi trước đã bị hủy vì đối thủ đi khác.');
    return false;
  }
  premoveQueue = rest; // keep the remaining premoves armed for the opponent's next reply
  playMove(move.from, move.to, move.promotion, { slide: false });
  return true;
}
function handlePremoveSquareClick(square) {
  const view = boardPositionForInput();
  if (selected && selectedTargets.some(move => move.to === square)) {
    const choices = selectedTargets.filter(move => move.to === square);
    const needsChoice = choices.some(move => move.promotion);
    const from = selected;
    if (needsChoice && !visualSettings.autoQueen) {
      choosePromotion(humanColor).then(type => { if (type && isPremoveWindow()) queuePremove(from, square, type); });
      return;
    }
    const promotion = needsChoice ? 'q' : null;
    if (queuePremove(from, square, promotion)) return;
  }
  const piece = view.get(square);
  if (piece && piece.color === humanColor) {
    selected = square;
    selectedTargets = getPremoveLegalMoves(game, humanColor, Chess, square, premoveQueue);
  } else if (!selected && isPremoveSquare(premoveQueue, square)) {
    clearPendingPremove({ silent: false }); selected = null; selectedTargets = []; renderBoard(); return;
  } else {
    selected = null; selectedTargets = [];
  }
  renderBoard();
}
function handleSquareClick(square) {
  if (!gameStarted) { toast('Nhấn “Bắt đầu ván mới” để bắt đầu trận.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (arenaRunning) { toast('Đấu trường AI đang dùng Stockfish; hãy dừng trận trước khi chơi bàn chính.'); return; }
  if (game.isGameOver() || clockFlagged) return;
  if (isPremoveWindow()) { handlePremoveSquareClick(square); return; }
  if (botThinking) return;
  if (mode !== 'local' && game.turn() !== humanColor) { toast(mode === 'lichess' ? 'Đang chờ đối thủ đi.' : 'Đang đến lượt bot.'); return; }
  const piece = game.get(square);
  if (selected && selectedTargets.some(m => m.to === square)) {
    const choices = selectedTargets.filter(m => m.to === square);
    const promotion = choices.find(m => m.promotion)?.promotion;
    if (promotion && visualSettings.autoQueen) {
      playMove(selected, square, 'q');
    } else if (promotion) {
      // Capture the origin and position before opening the async chooser. Never read the
      // mutable `selected` variable when the modal resolves.
      const request = { from: selected, to: square, epoch: gameEpoch, fen: game.fen() };
      const mover = game.turn();
      choosePromotion(mover).then(type => {
        if (!type) return;
        if (!isMoveContextCurrent(request, { epoch: gameEpoch, fen: game.fen() })) {
          toast('Thế cờ đã thay đổi; nước phong cấp cũ đã bị hủy.');
          return;
        }
        playMove(request.from, request.to, type);
      });
    } else playMove(selected, square);
    return;
  }
  if (piece && (mode === 'local' || piece.color === game.turn())) {
    selected = square;
    selectedTargets = game.moves({ square, verbose: true });
  } else {
    selected = null;
    selectedTargets = [];
  }
  const board = $('#board');
  if (board && boardSquareMap.size === 64) updateDragSelection(board, selected, selectedTargets);
  else renderBoard();
}
function choosePromotion(color) {
  return new Promise(resolve => {
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-backdrop"><div class="modal-card"><h3>Phong cấp tốt</h3><p>Chọn quân muốn phong cấp.</p><div class="promotion-options">${['q','r','b','n'].map(type => `<button data-promotion="${type}" class="promotion-choice ${color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph({ color, type })}<small>${({ q: 'Hậu', r: 'Xe', b: 'Tượng', n: 'Mã' })[type]}</small></button>`).join('')}</div><button id="cancelPromotion" class="secondary-btn full-width">Hủy</button></div></div>`;
    $$('[data-promotion]', root).forEach(button => button.addEventListener('click', () => { root.innerHTML = ''; resolve(button.dataset.promotion); }));
    $('#cancelPromotion', root).addEventListener('click', () => { root.innerHTML = ''; resolve(null); });
  });
}
function playMove(from, to, promotion, options = {}) {
  if (!gameStarted) { toast('Bắt đầu ván mới trước khi đi quân.'); return; }
  if (manualGameResult) { toast('Ván cờ đã kết thúc. Bấm “Ván mới” để chơi tiếp.'); return; }
  if (clockFlagged) { toast('Ván cờ đã kết thúc do hết giờ.'); return; }
  tickClock();
  if (clockFlagged) return;
  stopAnalysis(true);
  const mover = game.turn();
  const plyBeforeMove = game.history().length;
  const clockBeforeMove = captureMoveClockSnapshot();
  try {
    const move = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!move) return;
    recordClockSnapshot(moveClockSnapshots, plyBeforeMove, clockBeforeMove);
    redoStack = [];
    playBoardSound(move, game, settings.soundEnabled, settings.soundTheme);
    recordDailyEvent('make_move');
    if (move.captured) recordDailyEvent('capture_piece');
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) recordDailyEvent('castle');
    if (move.promotion) recordDailyEvent('promote');
    if (game.isCheck()) recordDailyEvent('check_king');
    lastHintMove = null;
    boardAnnotations = []; annotationTool = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: move.from, to: move.to };
    if (options.slide !== false) queueMoveSlide(move);
    announceMove(move, mover);
    selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null;
    if (mode === 'lichess') submitLichessMove(`${move.from}${move.to}${move.promotion || ''}`);
    persistLocalGameRecovery();
    onMoveComplete();
  } catch (error) { playGameSound('illegal', settings.soundEnabled); toast(`Nước đi không hợp lệ: ${error.message}`); }
}
function onMoveComplete() {
  const isOver = game.isGameOver();
  const needsBot = !isOver && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor;
  // Set this before rendering so a move only rebuilds the view once rather than twice.
  botThinking = needsBot;
  if (isOver || currentView !== 'play') renderView();
  else renderBoard();
  if (isOver) {
    botThinking = false;
    stopClock();
    const outcome = game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.';
    // Checkmate already plays its own board sound; add the win/lose/draw jingle after it.
    const humanWon = game.isCheckmate() && game.turn() !== humanColor;
    const jingle = !game.isCheckmate() ? 'draw' : (mode === 'local' || humanWon) ? 'win' : 'lose';
    setTimeout(() => playGameSound(jingle, settings.soundEnabled), 520);
    toast(outcome, 'success');
    return;
  }
  if (needsBot) {
    scheduleBotMove(220);
  }
  if (currentView === 'play') queryOpeningExplorer(false);
}
function resignCurrentGame(confirmed = false) {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) return;
  if (mode === 'lichess') { toast('Đầu hàng trong ván Lichess phải thực hiện trên dịch vụ Lichess.'); return; }
  const resigning = mode === 'local' ? game.turn() : humanColor;
  const winner = resigning === 'w' ? 'Đen' : 'Trắng';
  if (visualSettings.confirmResign && confirmed !== true) { showBrandedConfirm({ title: 'Xác nhận đầu hàng?', subtitle: `${winner} sẽ thắng ván này. Biên bản nước đi được giữ để xem lại.`, confirmLabel: 'Đầu hàng', tone: 'loss', onConfirm: () => resignCurrentGame(true) }); return; }
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  premoveQueue = []; selected = null; selectedTargets = [];
  gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = {
    token: resigning === 'w' ? '0-1' : '1-0',
    title: `Đầu hàng — ${winner} thắng`,
    detail: `${resigning === 'w' ? 'Trắng' : 'Đen'} đã đầu hàng. Lịch sử nước đi được giữ nguyên để xem lại.`,
    reason: 'resignation'
  };
  stopClock(); persistLocalGameRecovery(); renderView();
}

function offerDrawCurrentGame() {
  if (!gameStarted || game.isGameOver() || clockFlagged || manualGameResult) {
    toast('Ván cờ chưa bắt đầu hoặc đã kết thúc.');
    return;
  }
  if (mode === 'lichess') {
    toast('Xin hòa trong ván Lichess phải thực hiện trên giao diện Lichess.');
    return;
  }
  if (['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode)) {
    if (botThinking) {
      toast('Hãy đợi đối thủ đi nước xong trước khi xin hòa.');
      return;
    }
    const isMaterialDrawn = game.isInsufficientMaterial();
    let botAccepts = false;
    let reasonMsg = '';
    
    if (isMaterialDrawn || game.isThreefoldRepetition() || game.isStalemate()) {
      botAccepts = true;
      reasonMsg = 'Thế cờ hòa theo luật cờ vua.';
    } else if (analysisVariants.length && Number.isFinite(analysisVariants[0]?.scoreWhiteCp)) {
      const cp = analysisVariants[0].scoreWhiteCp;
      const userAdvantage = humanColor === 'w' ? cp : -cp;
      if (userAdvantage >= 180) {
        botAccepts = true;
        reasonMsg = 'Đối thủ nhận thấy bạn đang có ưu thế và đồng ý hòa.';
      } else if (userAdvantage <= -160) {
        botAccepts = false;
        reasonMsg = 'Bot từ chối hòa: Thế cờ đang có ưu thế nghiêng về bot!';
      } else {
        botAccepts = true;
        reasonMsg = 'Thế cờ cân bằng, bot chấp nhận lời đề nghị hòa!';
      }
    } else {
      const mat = summarizeCapturedMaterial(game);
      const diff = Math.abs((mat.whiteCount || 0) - (mat.blackCount || 0));
      if (diff <= 2) {
        botAccepts = true;
        reasonMsg = 'Thế cờ cân bằng, bot đồng ý chia điểm hòa!';
      } else {
        botAccepts = false;
        reasonMsg = 'Đối thủ từ chối: Lực lượng chưa cho phép thỏa thuận hòa.';
      }
    }

    if (botAccepts) {
      cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
      premoveQueue = []; selected = null; selectedTargets = [];
      gameEpoch += 1; botThinking = false; queuedMainEngineMove = false;
      manualGameResult = {
        token: '1/2-1/2',
        title: 'Hòa cờ — Thỏa thuận',
        detail: `Hai bên thỏa thuận hòa ván đấu (${reasonMsg}).`,
        reason: 'draw-agreement'
      };
      stopClock();
      playGameSound('game-end', settings.soundEnabled);
      maybeArchiveCompletedGame();
      toast(`Đối thủ đồng ý: ${reasonMsg}`, 'success');
      persistLocalGameRecovery();
      renderView();
      maybeShowPlayResultModal();
    } else {
      toast(reasonMsg, 'warning');
    }
  } else if (mode === 'local') {
    const agreed = (typeof window.confirm === 'function') ? window.confirm('Bên đối thủ có chấp nhận hòa cờ không?') : true;
    if (agreed) {
      stopClock();
      playGameSound('game-end', settings.soundEnabled);
      manualGameResult = {
        token: '1/2-1/2',
        title: 'Hòa cờ — Thỏa thuận',
        detail: 'Hai người chơi thỏa thuận chia điểm hòa ván đấu.',
        reason: 'draw-agreement'
      };
      maybeArchiveCompletedGame();
      toast('Ván đấu kết thúc hòa do hai bên đồng ý.', 'success');
      persistLocalGameRecovery();
      renderView();
      maybeShowPlayResultModal();
    } else {
      toast('Đối thủ từ chối đề nghị hòa.', '');
    }
  } else {
    toast('Chế độ này không hỗ trợ xin hòa trực tiếp.', '');
  }
}

function freshGame({ startFen = null } = {}) {
  closeResultModal();
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi tạo ván khác.'); return; }
  moveClockSnapshots = []; redoStack = [];
  historyRestoreSignature = ''; reviewReplayState = null;
  if (colorChoice === 'random' && mode !== 'local' && mode !== 'lichess') {
    humanColor = Math.random() < 0.5 ? 'w' : 'b'; orientation = humanColor;
    toast(`🎲 Ngẫu nhiên: bạn cầm quân ${humanColor === 'w' ? 'Trắng — đi trước' : 'Đen — bot đi trước'}.`);
  }
    cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  premoveQueue = [];
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  currentGameId = `g-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  ratedGameSignature = '';
  manualGameResult = null;
  if (mode === 'stockfish' && randomBotEloEnabled) {
    settings.botStrengthMode = 'elo'; settings.botElo = 500 + Math.floor(Math.random() * 28) * 100; settings.botSkill = 20; saveSettings();
  }
  if (mode === 'lichess') mode = 'stockfish';
  stopOnlineStream();
  game = startFen ? new Chess(startFen) : new Chess();
  gameStartFen = game.fen();
  completedReviewRows = []; reviewStatus = '';
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  selected = null; selectedTargets = []; premoveQueue = []; lastMove = null; lastHintMove = null; boardAnnotations = []; annotationTool = null; botThinking = false; currentOpening = null;
  resetClock(settings.clockPreset);
  const returningToPlay = currentView !== 'play';
  currentView = 'play';
  persistLocalGameRecovery();
  renderView();
  if (returningToPlay) window.scrollTo(0, 0);
  if (['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true;
    scheduleBotMove(250);
  }
}
function undoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi hoàn tác.'); return; }
  if (mode === 'lichess') { toast('Không thể tự hoàn tác ván Lichess; hãy dùng chức năng takeback trên Lichess.'); return; }
  if (!game.history().length || botThinking) return;
  // Apply elapsed time before taking a snapshot. Never call resetClock from undo.
  tickClock();
  const priorPlyCount = game.history().length;
  const clockAtUndo = captureMoveClockSnapshot();
  const manualResultAtUndo = manualGameResult ? { ...manualGameResult } : null;
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  const removedMoves = [];
  const first = game.undo();
  if (first) removedMoves.unshift({ from: first.from, to: first.to, promotion: first.promotion || null, san: first.san });
  if (mode !== 'local' && game.history().length && game.turn() !== humanColor) {
    const second = game.undo();
    if (second) removedMoves.unshift({ from: second.from, to: second.to, promotion: second.promotion || null, san: second.san });
  }
  if (!removedMoves.length) return;
  const targetPlyCount = game.history().length;
  const savedClockHistory = cloneClockHistoryRange(moveClockSnapshots, targetPlyCount, priorPlyCount);
  redoStack.push({
    moves: removedMoves,
    clockSnapshot: clockAtUndo,
    clockHistory: savedClockHistory,
    manualGameResult: manualResultAtUndo,
    lastMove: lastMove ? { ...lastMove } : null,
    currentOpening
  });
  moveClockSnapshots.length = targetPlyCount;
  manualGameResult = null;
  premoveQueue = [];
  gameEpoch += 1;
  completedReviewRows = []; reviewStatus = '';
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || null; lastHintMove = null;
  if (!restoreMoveClockSnapshot(moveClockSnapshots[targetPlyCount])) rebaseClockAfterUndoWithoutSnapshot();
  persistLocalGameRecovery();
  renderView();
  toast(`Đã hoàn tác ${removedMoves.length === 1 ? '1 nửa nước đi' : '1 lượt của bạn và bot'}. Đồng hồ đã được khôi phục.`, 'success');
}
function redoMove() {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi làm lại.'); return; }
  if (mode === 'lichess') { toast('Không thể làm lại nước trong ván trực tuyến.'); return; }
  if (botThinking) { toast('Đợi bot hoàn tất nước hiện tại rồi hãy làm lại.'); return; }
  const record = redoStack[redoStack.length - 1];
  if (!record || !record.moves?.length) { toast('Không còn nước đi nào để làm lại.'); return; }
  // Validate the complete redo branch on a clone before changing the active game.
  let candidate;
  try {
    candidate = new Chess(game.fen());
    for (const move of record.moves) { if (!candidate.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) })) throw new Error('Redo move is no longer legal.'); }
  } catch {
    toast('Không thể làm lại nhánh nước đi này trong thế cờ hiện tại.');
    return;
  }
  redoStack.pop();
  cancelScheduledBotMove(); cancelApiMoveRequest(); cancelPendingHint(); stopAnalysis(true); cancelMainEngineSearch();
  const startPly = game.history().length;
  for (let i = 0; i < record.moves.length; i += 1) {
    const move = record.moves[i];
    game.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    const snapshot = record.clockHistory?.[i];
    if (snapshot) recordClockSnapshot(moveClockSnapshots, startPly + i, snapshot);
  }
  moveClockSnapshots.length = startPly + record.moves.length;
  gameEpoch += 1; premoveQueue = []; botThinking = false; queuedMainEngineMove = false;
  manualGameResult = record.manualGameResult ? { ...record.manualGameResult } : null;
  const h = game.history({ verbose: true });
  lastMove = h.length ? { from: h[h.length - 1].from, to: h[h.length - 1].to } : null;
  selected = null; selectedTargets = []; lastHintMove = null; boardAnnotations = []; annotationTool = null;
  currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || record.currentOpening || null;
  if (!restoreMoveClockSnapshot(record.clockSnapshot)) rebaseClockAfterUndoWithoutSnapshot();
  if (game.isGameOver() || clockFlagged || manualGameResult) clockState.running = false;
  persistLocalGameRecovery();
  renderView();
  toast('Đã làm lại nước đi và khôi phục đồng hồ.', 'success');
  if (!game.isGameOver() && !clockFlagged && !manualGameResult && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
    botThinking = true; renderView(); scheduleBotMove(220);
  }
}

function updateEvaluationMeter(scoreType, scoreValue, sideToMove) {
  const fill = $('#evaluationMeterWhite');
  const meter = $('#evaluationMeter');
  if (!fill || !meter) return;
  const whiteCp = scoreSideToWhiteCentipawns(Number(scoreValue), sideToMove, scoreType);
  if (!Number.isFinite(whiteCp)) return;
  // Smoothly map centipawns to a bounded share. This is a visual cue, not win probability.
  const share = Math.max(4, Math.min(96, 50 + 46 * Math.tanh(whiteCp / 500)));
  fill.style.width = `${share.toFixed(1)}%`;
  meter.setAttribute('aria-label', `Thanh đánh giá: ${whiteCp > 0 ? 'Trắng hơn' : whiteCp < 0 ? 'Đen hơn' : 'cân bằng'}`);
}

function setEngineStatusLabel(message, state = 'loading', title = '') {
  const status = $('#engineStatus');
  if (!status) return;
  const safeMessage = String(message || 'Stockfish');
  status.innerHTML = `<span class="engine-status-knight" aria-hidden="true">♞</span><i aria-hidden="true"></i><span class="engine-status-copy">${esc(safeMessage)}</span>`;
  status.classList.toggle('ready', state === 'ready');
  status.classList.toggle('failed', state === 'failed');
  status.classList.toggle('loading', state === 'loading');
  status.dataset.engineState = state;
  status.title = title || `${safeMessage}. Chạm để kiểm tra hoặc tải lại Stockfish.`;
  status.setAttribute('aria-label', `Stockfish: ${safeMessage}. Chạm để kiểm tra hoặc tải lại engine.`);
}

function retireStockfishWorker(message = 'Stockfish không khả dụng.') {
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  if (stockfishWarmupTimer) { clearTimeout(stockfishWarmupTimer); stockfishWarmupTimer = null; }
  waitingForStockfishMove = null;
  // Terminate rather than only sending `stop`: a late bestmove from a timed-out
  // search must never be mistaken for the next request's result.
  const retired = engineWorker;
  engineWorker = null;
  try { retired?.terminate(); } catch {}
  engineReady = false;
  engineFailed = true;
  engineHealthState = failEngineHealth(engineHealthState, message);
  engineUciInitialized = false;
  engineSearchActive = false;
  engineStopPending = false;
  if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
  mainEngineSearchEpoch = -1;
  mainEngineSearchFen = '';
  queuedMainEngineMove = false;
  cancelMainEngineWatchdog();
  if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
  analysisActive = false;
  if (pendingHintRequest) { clearTimeout(pendingHintRequest.timeout); pendingHintRequest = null; }
  if (pendingEngineRequest) {
    const pending = pendingEngineRequest;
    pendingEngineRequest = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (pendingCoachAnalysis) {
    const pending = pendingCoachAnalysis;
    pendingCoachAnalysis = null;
    clearTimeout(pending.timeout);
    try { pending.reject(new Error(message)); } catch {}
  }
  if (reviewSession?.timeout) clearTimeout(reviewSession.timeout);
  if (reviewSession) {
    reviewSession = null;
    reviewStatus = message;
    updateReviewPanel();
  }
  setEngineStatusLabel('Engine lỗi · chạm để tải lại', 'failed', message);
  renderAnalysisPanel();
  console.warn('[Cờ Vua] Stockfish worker retired:', message);
}

function retryStockfishEngine() {
  if (engineStopPending || engineSearchActive || botThinking || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive || reviewSession) {
    toast('Đợi tác vụ cờ hiện tại kết thúc rồi mới tải lại engine.');
    return;
  }
  if (engineWorker && engineReady && !engineFailed) {
    toast(describeEngineHealth(engineHealthState));
    return;
  }
  if (engineWorker && !engineReady && !engineFailed) {
    toast('Stockfish đang khởi tạo; chờ thêm một chút trước khi thử lại.');
    return;
  }
  retireStockfishWorker('Đang tải lại Stockfish…');
  engineFailed = false;
  setEngineStatusLabel('Đang tải Stockfish…', 'loading', 'Đang khởi tạo engine; tài nguyên engine phải có trong bản build.');
  engineInitFallbacksTried = new Set();
  initEngine();
  toast('Đang thử khởi tạo lại Stockfish…');
}

function isAndroidNativeBridgePresent() {
  try {
    const bridge = window.AndroidBridge;
    return Boolean(bridge && typeof bridge.getPlatform === 'function' && bridge.getPlatform() === 'android-native');
  } catch { return false; }
}
function isNativeStockfishAvailable() {
  if (!isAndroidNativeBridgePresent()) return false;
  try { return Boolean(window.AndroidBridge.nativeStockfishAvailable()); } catch { return false; }
}
let nativeEngineActive = false;
function updateNativeEngineUi() {
  const row = document.getElementById('nativeEngineInfoRow');
  if (row) row.hidden = !isNativeStockfishAvailable();
}
function createNativeStockfishWorker() {

  // Android ARM64 runs the packaged Stockfish UCI executable through the native bridge.
  // Browsers and unsupported devices keep using the established JS/WASM Worker path.
  const bridge = window.AndroidBridge;
  if (!bridge || typeof bridge.getPlatform !== 'function' || bridge.getPlatform() !== 'android-native' ||
      typeof bridge.nativeStockfishAvailable !== 'function' ||
      typeof bridge.startNativeStockfish !== 'function' ||
      typeof bridge.sendStockfishCommand !== 'function' ||
      typeof bridge.stopNativeStockfish !== 'function') return null;

  let available = false;
  try { available = Boolean(bridge.nativeStockfishAvailable()); } catch { return null; }
  if (!available) return null;

  let active = true;
  const worker = {
    onmessage: null,
    onerror: null,
    __vilaNativeStockfish: true,
    postMessage(message) {
      if (!active) return;
      let sent = false;
      try { sent = Boolean(bridge.sendStockfishCommand(String(message))); } catch {}
      if (!sent && active && typeof worker.onerror === 'function') {
        worker.onerror({ message: 'Không gửi được lệnh UCI tới Stockfish Android.' });
      }
    },
    terminate() {
      if (!active) return;
      active = false;
      window.removeEventListener('vila-native-stockfish-message', handleNativeLine);
      try { bridge.stopNativeStockfish(); } catch {}
    }
  };
  const handleNativeLine = event => {
    if (!active || typeof worker.onmessage !== 'function') return;
    const line = typeof event?.detail?.line === 'string' ? event.detail.line : '';
    worker.onmessage({ data: line });
  };
  window.addEventListener('vila-native-stockfish-message', handleNativeLine);
  let started = false;
  try { started = Boolean(bridge.startNativeStockfish()); } catch {}
  if (!started) {
    active = false;
    window.removeEventListener('vila-native-stockfish-message', handleNativeLine);
    return null;
  }
  return worker;
}

function fallbackEngineLabel(profile) {
  if (profile === 'full-single') return 'Stockfish Full';
  if (profile === 'lite-single') return 'Stockfish Lite';
  if (profile === 'sf10') return 'Stockfish 10';
  return 'Stockfish ASM-JS';
}
function tryEngineInitFallback(failedProfile) {
  const nextProfile = nextEngineFallback(failedProfile);
  if (!nextProfile || engineInitFallbacksTried.has(nextProfile)) return false;
  engineInitFallbacksTried.add(nextProfile);
  if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
  const previous = engineWorker;
  engineWorker = null;
  try { previous?.terminate(); } catch {}
  engineReady = false;
  engineUciInitialized = false;
  engineFailed = false;
  engineSearchActive = false;
  const label = fallbackEngineLabel(nextProfile);
  setEngineStatusLabel(`Thử ${label} dự phòng…`, 'loading', `Engine trước không khởi tạo được; đang thử ${label}.`);
  console.warn(`[Cờ Vua] Stockfish init fallback: ${failedProfile} -> ${nextProfile}`);
  initEngine({ forceLite: nextProfile === 'lite-single', forceAsm: nextProfile === 'asm', isFallback: true });
  return true;
}
function initEngine({ forceLite = false, forceAsm = false, isFallback = false } = {}) {
  let selectedEngine = 'lite-single';
  try {
    if (!isFallback) engineInitFallbacksTried = new Set();
    selectedEngine = forceAsm ? 'asm' : forceLite ? 'lite-single' : resolveEngineProfile(settings.botEngine, { deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency });
    engineInitFallbacksTried.add(selectedEngine);
    const priorAttempt = engineHealthState?.profile === 'unknown' ? 0 : Math.max(0, Number(engineHealthState?.attempt) || 0);
    engineHealthState = createEngineHealthState(selectedEngine, Date.now(), priorAttempt + 1);
    const engineFile = engineAssetFile(selectedEngine);
    const enginePath = new URL(`${import.meta.env.BASE_URL}engine/${engineFile}`, window.location.href).href;
    // Preserve explicit engine selections: Auto/Full may use native Stockfish on Android;
    // Lite and Stockfish 10 stay on their selected browser workers.
    const nativePreference = ['auto', 'full-single'].includes(settings.botEngine || 'auto');
    const worker = (!isFallback && nativePreference ? createNativeStockfishWorker() : null) || new Worker(enginePath);
    const nativeEngineUsed = worker.__vilaNativeStockfish === true;
    nativeEngineActive = nativeEngineUsed;
    engineWorker = worker;
    worker.onmessage = event => {
      // A retired worker may have a queued message task; never let it mutate the
      // state or feed a result to the newly-created worker session.
      if (engineWorker !== worker) return;
      const output = typeof event.data === 'string' ? event.data : String(event.data?.data || event.data || '');
      // Stockfish 10/older asm.js ports may bundle several UCI lines into one
      // MessageEvent. Process every line separately or uciok/readyok can be missed.
      for (const line of splitUciOutput(output)) {
        engineHealthState = observeEngineLine(engineHealthState, line);
        if (/^uciok\s*$/i.test(line) && !engineUciInitialized) {
          engineUciInitialized = true;
          engineReady = false;
          // Configure memory and threads once. Single-thread engines may ignore Threads.
          engineWorker.postMessage('setoption name Threads value 1');
          // Stockfish 10 is a pure asm.js build with a small heap; keep its hash table modest.
          engineWorker.postMessage(`setoption name Hash value ${selectedEngine === 'sf10' ? Math.min(4, preferredHashMb()) : preferredHashMb()}`);
          engineWorker.postMessage('setoption name MultiPV value 1');
          engineWorker.postMessage('isready');
        }
        if (/^readyok\s*$/i.test(line) && engineHealthState?.status === 'ready' && engineUciInitialized && !engineFailed) {
          if (engineInitTimeout) { clearTimeout(engineInitTimeout); engineInitTimeout = null; }
          engineReady = true;
          const shownName = nativeEngineUsed ? 'Android ARM64 · NNUE' : selectedEngine === 'full-single' ? '19 Full' : selectedEngine === 'asm' ? '19 ASM-JS dự phòng' : selectedEngine === 'sf10' ? '10' : '19 Lite';
          const startupMs = engineStartupDurationMs(engineHealthState);
          const healthDetail = describeEngineHealth(engineHealthState);
          setEngineStatusLabel(`${nativeEngineUsed ? 'Stockfish Android ARM64 · NNUE' : 'Stockfish ' + shownName} · sẵn sàng`, 'ready', `${healthDetail}${startupMs != null ? ` Thời gian khởi động: ${(startupMs / 1000).toFixed(1)} giây.` : ''} ${nativeEngineUsed ? 'Đang chạy engine native ARM64 đã đóng gói cùng APK.' : selectedEngine === 'asm' ? 'ASM-JS tương thích hơn nhưng có thể chậm hơn WASM.' : ''} Chạm để xem trạng thái hoặc tải lại khi gặp lỗi.`);
          runEngineQueue();
          if (waitingForStockfishMove) {
            const waiting = waitingForStockfishMove;
            waitingForStockfishMove = null;
            if (stockfishWarmupTimer) { clearTimeout(stockfishWarmupTimer); stockfishWarmupTimer = null; }
            if (waiting.epoch === gameEpoch && waiting.fen === game.fen() && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) scheduleBotMove(0);
          }
        }
        if (/\binfo\b/.test(line) && analysisActive) receiveAnalysisInfo(line);
        if (/\binfo\b/.test(line) && reviewSession?.waiting) receiveReviewInfo(line);
        if (/\binfo\b/.test(line) && pendingCoachAnalysis) receiveCoachAnalysisInfo(line);
        if (/^info\b.*\bnps\b/.test(line)) recordStockfishSpeed(line);
        // Arena style profiles choose only among legal candidate first moves reported by Stockfish MultiPV.
        // Scores are from the side-to-move perspective; the latest/deepest line replaces older data.
        const arenaPvMatch = line.match(/^info\b.*?\bdepth\s+(\d+)\b.*?\bmultipv\s+(\d+)\b.*?\bscore\s+(cp|mate)\s+(-?\d+).*?\bpv\s+([a-h][1-8][a-h][1-8][qrbn]?)/i);
        if (arenaPvMatch && pendingEngineRequest?.multiPv > 1) {
          const depthValue = Number(arenaPvMatch[1]);
          const pvIndex = Number(arenaPvMatch[2]);
          if (pvIndex >= 1 && pvIndex <= pendingEngineRequest.multiPv) {
            const rawScore = Number(arenaPvMatch[4]);
            const score = arenaPvMatch[3] === 'mate' ? Math.sign(rawScore || 1) * (30000 - Math.min(999, Math.abs(rawScore))) : rawScore;
            const old = pendingEngineRequest.candidates.get(pvIndex);
            if (!old || depthValue >= old.depth) pendingEngineRequest.candidates.set(pvIndex, { multipv: pvIndex, uci: arenaPvMatch[5].toLowerCase(), score, depth: depthValue });
          }
        }
        const scoreMatch = line.match(/\bscore (cp|mate) (-?\d+)/);
        if (scoreMatch && engineSearchActive && !analysisActive && !reviewSession) {
          const rawScore = Number(scoreMatch[2]);
          const whiteScore = rawScore * (game.turn() === 'b' ? -1 : 1);
          const score = scoreMatch[1] === 'mate'
            ? `${whiteScore < 0 ? '-' : ''}M${Math.abs(whiteScore)}`
            : `${whiteScore > 0 ? '+' : ''}${(whiteScore / 100).toFixed(1)}`;
          const label = $('#evalNumber');
          if (label) label.textContent = score;
          updateEvaluationMeter(scoreMatch[1], rawScore, game.turn());
        }
        const bestMatch = line.match(/\bbestmove\s+([a-h][1-8][a-h][1-8][qrbn]?|0000)/i);
        if (bestMatch) {
          cancelMainEngineWatchdog();
          const uci = bestMatch[1].toLowerCase();
          if (engineStopPending) {
            // Consume the terminal line for the cancelled search; never treat it as the next request.
            engineStopPending = false;
            engineSearchActive = false;
            if (engineStopTimeout) { clearTimeout(engineStopTimeout); engineStopTimeout = null; }
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            renderAnalysisPanel();
            if (queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged) {
              queuedMainEngineMove = false;
              scheduleBotMove(0);
            }
            return;
          }
          engineSearchActive = false;
          if (reviewSession?.waiting) { finishReviewPosition(false, uci === '0000' ? null : uci); return; }
          if (pendingEngineRequest) {
            const pending = pendingEngineRequest;
            pendingEngineRequest = null;
            clearTimeout(pending.timeout);
            try { engineWorker?.postMessage('setoption name MultiPV value 1'); } catch {}
            if (uci === '0000') {
              pending.reject(new Error('Stockfish không trả về nước đi trong thế cờ này.'));
            } else if (pending.multiPv > 1) {
              const candidates = [...pending.candidates.values()].sort((a, b) => a.multipv - b.multipv);
              if (!candidates.some(item => item.uci === uci)) candidates.unshift({ multipv: 1, uci, score: candidates[0]?.score ?? 0, depth: 0 });
              pending.resolve(candidates.slice(0, pending.multiPv));
            } else pending.resolve(uci);
            return;
          }
          if (pendingHintRequest) {
            const hint = pendingHintRequest;
            pendingHintRequest = null;
            clearTimeout(hint.timeout);
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            const resumeQueuedMainMove = queuedMainEngineMove;
            queuedMainEngineMove = false;
            if (hint.epoch === gameEpoch && hint.fen === game.fen()) {
              const move = hint.legal.find(candidate => uciForMove(candidate) === uci);
              if (move) setHintSuggestion(move, 'Stockfish');
              toast(move ? `Gợi ý Stockfish: ${move.san} (${uci})` : 'Stockfish chưa trả về được gợi ý hợp lệ.', move ? 'success' : '');
              if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
              if ($('#evalNumber')) $('#evalNumber').textContent = '—';
            }
            if (resumeQueuedMainMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) {
              scheduleBotMove(0);
            }
            return;
          }
          if (pendingCoachAnalysis) {
            const request = pendingCoachAnalysis;
            pendingCoachAnalysis = null;
            clearTimeout(request.timeout);
            engineSearchActive = false;
            mainEngineSearchEpoch = -1;
            mainEngineSearchFen = '';
            try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
            if (request.epoch !== gameEpoch || request.fen !== game.fen()) request.reject(new Error('Thế cờ đã thay đổi trong khi Stockfish phân tích; hãy gửi lại câu hỏi.'));
            else request.resolve([...request.variants.values()].sort((a, b) => a.multipv - b.multipv));
            return;
          }
          if (analysisActive) {
            const currentSession = isCurrentAnalysisSession({ active: analysisActive, sessionFen: analysisFen, currentFen: game.fen(), sessionEpoch: analysisEpoch, currentEpoch: gameEpoch });
            analysisActive = false;
            if (analysisTimeout) { clearTimeout(analysisTimeout); analysisTimeout = null; }
            analysisFen = '';
            analysisEpoch = -1;
            if (!currentSession) { analysisVariants = []; analysisVisible = false; }
            try { engineWorker.postMessage('setoption name MultiPV value 1'); } catch {}
            renderAnalysisPanel();
            return;
          }
          const searchedEpoch = mainEngineSearchEpoch;
          const searchedFen = mainEngineSearchFen;
          mainEngineSearchEpoch = -1;
          mainEngineSearchFen = '';
          if (searchedEpoch !== gameEpoch || !searchedFen || searchedFen !== game.fen()) {
            if (queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && game.turn() !== humanColor) {
              queuedMainEngineMove = false;
              scheduleBotMove(0);
            }
            return;
          }
          if (botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver()) {
            botThinking = false;
            const activeStrength = resolveBotStrength(mode, settings);
            const beginnerBudget = activeStrength?.mode === 'skill-level-floor' ? resolveBeginnerSearchBudget(activeStrength.targetElo, { moveTimeMs: settings.botMoveTimeMs, depth: settings.botDepth }) : null;
            const moveUci = beginnerBudget
              ? chooseBeginnerMove(uci, game.moves({ verbose: true }).map(uciForMove), Math.random, beginnerBudget.deviationChance) || uci
              : uci;
            applyUciMove(moveUci);
          }
        }
      }
    };
    worker.onerror = event => {
      if (engineWorker !== worker) return;
      // Only switch engines during startup. Runtime failures go through the normal
      // cleanup path so pending searches cannot leak into a second worker.
      if (!engineReady && tryEngineInitFallback(selectedEngine)) return;
      failEngine(selectedEngine === 'asm'
        ? `Stockfish ASM-JS cũng không khởi tạo được. Hãy chạy build sạch và kiểm tra tệp engine trong APK. ${String(event?.message || '').slice(0, 120)}`
        : `Không tải được tệp Stockfish ${selectedEngine === 'full-single' ? 'Full' : selectedEngine === 'sf10' ? '10' : 'Lite'}. ${String(event?.message || '').slice(0, 120)} Đang kiểm tra engine và có thể thử lại.`);
    };
    worker.postMessage('uci');
    // Full can take much longer to load; Lite uses a stricter watchdog. ASM has no WASM.
    engineInitTimeout = setTimeout(() => {
      if (engineWorker !== worker || engineReady || engineFailed) return;
      engineHealthState = failEngineHealth(engineHealthState, 'Hết thời gian chờ bắt tay UCI.');
      if (tryEngineInitFallback(selectedEngine)) return;
      failEngine(`Stockfish ${selectedEngine === 'asm' ? 'ASM-JS' : selectedEngine === 'full-single' ? 'Full' : selectedEngine === 'sf10' ? '10' : 'Lite'} khởi tạo quá lâu. Kiểm tra tệp JS/WASM và thử tải lại.`);
    }, nativeEngineUsed || selectedEngine === 'full-single' ? 45000 : selectedEngine === 'sf10' ? 30000 : selectedEngine === 'asm' ? 12000 : 20000);
  } catch (error) {
    if (!isFallback && !engineInitFallbacksTried.has(selectedEngine)) engineInitFallbacksTried.add(selectedEngine);
    if (tryEngineInitFallback(selectedEngine)) return;
    failEngine('Không thể khởi tạo Stockfish. Kiểm tra các tệp engine và thử tải lại.');
  }
}
function failEngine(message) {
  const wasThinking = botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver();
  retireStockfishWorker(message);
  addAppNotification({ title: 'Stockfish chưa sẵn sàng', message, type: 'error' });
  if (!wasThinking) toast(message);
  // Preserve the ticking bot clock and premove window while a stronger VILA offline search runs.
  if (wasThinking) requestOfflineRescueMove('Stockfish bị lỗi');
}

function runEngineQueue() {
  if (!engineWorker || !engineReady || !engineQueue.length) return;
  const next = engineQueue.shift();
  if (next) next();
}
async function chooseStockfishBackedOfflineUci(chess, profile = 'classic', fen = chess.fen()) {
  // Reuse the main UCI worker when idle so the normal offline bots are not weaker than
  // the custom search core solely because they never consult Stockfish. The custom
  // alpha-beta core remains the offline-safe fallback whenever the worker is busy/missing.
  if (!engineWorker || !engineReady || engineFailed || engineStopPending || pendingEngineRequest || pendingHintRequest ||
      pendingCoachAnalysis || analysisActive || reviewSession || engineSearchActive || arenaRunning) return null;
  const isClassic = profile === 'classic';
  const depth = Math.max(16, Math.min(30, Number(settings.botDepth) || 22));
  const moveTimeMs = Math.max(1200, Math.min(3200, Number(settings.botMoveTimeMs) || 2000));
  let result;
  try {
    result = await requestStockfishUci(fen, {
      skill: 20, depth, strengthMode: 'max', moveTimeMs,
      multiPv: isClassic ? 1 : 4,
      timeoutMs: Math.max(12000, moveTimeMs * 5)
    });
  } catch { return null; }
  const candidates = (Array.isArray(result) ? result : [{ uci: result, score: 0, depth }])
    .filter(item => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(item?.uci || '')))
    .filter(item => chess.moves({ verbose: true }).some(move => uciForMove(move) === String(item.uci).toLowerCase()));
  if (!candidates.length) return null;
  if (isClassic) return String(candidates[0].uci).toLowerCase();
  const bestScore = Math.max(...candidates.map(item => Number(item.score) || 0));
  const ranked = candidates.map(item => ({
    ...item,
    personalityScore: personaCandidateScore(chess, item, profile, bestScore)
  })).sort((a, b) => b.personalityScore - a.personalityScore || String(a.uci).localeCompare(String(b.uci)));
  // Keep style differences without letting beginner profiles choose catastrophically bad lines.
  const tolerance = profile === 'rookie' ? 240 : profile === 'mentor' ? 160 :
    ['berserk', 'gambit', 'trickster', 'chaos'].includes(profile) ? 70 : 35;
  const acceptable = ranked.filter(item => bestScore - (Number(item.score) || 0) <= tolerance);
  return String((acceptable[0] || ranked[0]).uci).toLowerCase();
}

async function askVilaMove() {
  if (mode !== 'vila' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const fen = game.fen();
  const epoch = gameEpoch;
  $('#boardStatus') && ($('#boardStatus').textContent = 'ViLa Classic đang tính nước…');
  try {
    const vilaBook = settings.openingBookEnabled ? pickPersonaBookMove(game, 'classic', OPENINGS, { recentChoices: recentOpeningChoices }) : null;
    if (vilaBook) { botThinking = false; applyUciMove(uciForMove(vilaBook)); return; }
    const stockfishUci = await chooseStockfishBackedOfflineUci(game, 'classic', fen);
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'vila' || !botThinking) return;
    const budget = resolveOfflineSearchBudget('classic', settings);
    const uci = stockfishUci || await chooseAlternateMoveAsync(fen, { ...budget, seen: repetitionContext(game) });
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'vila' || !botThinking) return;
    if (!uci) throw new Error('Không tìm thấy nước đi hợp lệ.');
    if (!stockfishUci) recordEngineSpeed('ViLa Classic · alpha-beta ngoại tuyến', getLastOfflineEngineStats());
    applyUciMove(uci);
  } catch (error) {
    if (epoch !== gameEpoch || mode !== 'vila') return;
    botThinking = false;
    toast(`ViLa Classic gặp lỗi: ${error.message}`);
    renderView();
  }
}
function askEngineHubMove() {
  if (mode !== 'enginehub' || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const fen = game.fen();
  const epoch = gameEpoch;
  const profile = OFFLINE_ENGINE_IDS.includes(settings.alternativeEngine) ? settings.alternativeEngine : 'ethereal';
  $('#boardStatus') && ($('#boardStatus').textContent = `${offlineEngineShortName(profile)} · offline đang suy nghĩ…`);
  // Let the status paint, then search in a module worker so the board stays responsive.
  setTimeout(async () => {
    if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
    try {
      const bookMove = settings.openingBookEnabled ? pickPersonaBookMove(game, profile, OPENINGS, { recentChoices: recentOpeningChoices }) : null;
      if (bookMove) { botThinking = false; applyUciMove(uciForMove(bookMove)); return; }
      const stockfishUci = await chooseStockfishBackedOfflineUci(game, profile, fen);
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
      const budget = resolveOfflineSearchBudget(profile, settings);
      const uci = stockfishUci || await chooseAlternateMoveAsync(fen, { ...budget, seen: repetitionContext(game) });
      if (!stockfishUci) recordEngineSpeed(offlineEngineShortName(profile), getLastOfflineEngineStats());
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub' || !botThinking) return;
      if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(uci || ''))) throw new Error('Không tìm thấy nước đi hợp lệ.');
      applyUciMove(uci);
    } catch (error) {
      if (epoch !== gameEpoch || fen !== game.fen() || mode !== 'enginehub') return;
      botThinking = false;
      toast(`AI cục bộ gặp lỗi: ${error.message}`);
      renderView();
    }
  }, 30);
}

function askStockfishMove() {
  if (!['stockfish', 'stockfish-beginner'].includes(mode) || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return;
  const requestedStrength = resolveBotStrength(mode, settings);
  if (settings.openingBookEnabled && game.history().length < 14 && requestedStrength?.mode !== 'skill-level-floor') {
    const bookMove = findOpeningBookMove(game, OPENINGS, { maxPlies: 20, recentChoices: recentOpeningChoices });
    if (bookMove) {
      botThinking = false;
      applyUciMove(uciForMove(bookMove));
      return;
    }
  }
  // Stockfish Skill Level 0 is not a calibrated 500 Elo rating; the 500–600 preset adds a small, legal-only handicap after search. Other Elo presets still use Stockfish's chosen move unchanged.
  if (pendingEngineRequest) { toast('Stockfish đang xử lý một ván khác.'); return; }
  if (engineSearchActive || engineStopPending) { queuedMainEngineMove = true; return; }
  if (!engineWorker || engineFailed) {
    requestOfflineRescueMove('Stockfish không khả dụng');
    return;
  }
  if (!engineReady) {
    const waiting = { epoch: gameEpoch, fen: game.fen() };
    waitingForStockfishMove = waiting;
    $('#boardStatus') && ($('#boardStatus').textContent = `${fallbackEngineLabel(engineHealthState?.profile || (settings.botEngine === 'sf10' ? 'sf10' : 'lite-single'))} đang khởi tạo…`);
    if (stockfishWarmupTimer) clearTimeout(stockfishWarmupTimer);
    stockfishWarmupTimer = setTimeout(() => {
      stockfishWarmupTimer = null;
      if (waitingForStockfishMove !== waiting) return;
      waitingForStockfishMove = null;
      if (waiting.epoch === gameEpoch && waiting.fen === game.fen() && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor) requestOfflineRescueMove('Stockfish khởi tạo chậm');
    }, 8000);
    return;
  }
  engineSearchActive = true;
  mainEngineSearchEpoch = gameEpoch;
  mainEngineSearchFen = game.fen();
  const skill = Math.max(0, Math.min(20, Number(settings.botSkill ?? 20)));
  const depth = Math.max(5, Math.min(30, Number(settings.botDepth || 30)));
  $('#boardStatus') && ($('#boardStatus').textContent = 'Stockfish đang suy nghĩ…');
  $('#evalNumber') && ($('#evalNumber').textContent = '…');
  if (requestedStrength) {
    const strength = requestedStrength;
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength.limitStrength ? 'true' : 'false'}`);
    if (strength.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    engineWorker.postMessage(`setoption name Skill Level value ${strength.skillLevel}`);
  } else {
    engineWorker.postMessage('setoption name UCI_LimitStrength value false');
    engineWorker.postMessage(`setoption name Skill Level value ${skill}`);
  }
  engineWorker.postMessage('setoption name MultiPV value 1');
  engineWorker.postMessage(`position fen ${game.fen()}`);
  let configuredMoveTimeMs = Math.max(500, Math.min(5000, Number(settings.botMoveTimeMs) || 2600));
  // A very low target needs no long search; keep it snappy so the bot never looks frozen.
  if (requestedStrength?.mode === 'skill-level-floor') {
    const weakBudget = resolveBeginnerSearchBudget(requestedStrength.targetElo, { moveTimeMs: configuredMoveTimeMs, depth });
    configuredMoveTimeMs = weakBudget.moveTimeMs;
  }
  // The legacy asm.js build is much slower than the bundled Stockfish 19 WASM build.
  // Cap it separately for human-vs-bot too; a failed legacy engine falls back to a newer profile.
  const isLegacySf10 = engineHealthState?.profile === 'sf10';
  const moveTimeMs = isLegacySf10
    ? Math.max(100, Math.min(220, Math.round(configuredMoveTimeMs * 0.08)))
    : configuredMoveTimeMs;
  const weakSearchBudget = requestedStrength?.mode === 'skill-level-floor' ? resolveBeginnerSearchBudget(requestedStrength.targetElo, { moveTimeMs: configuredMoveTimeMs, depth }) : null;
  const searchDepth = isLegacySf10 ? Math.min(8, Number(depth) || 8) : weakSearchBudget ? weakSearchBudget.depth : depth;
  engineWorker.postMessage(`go movetime ${moveTimeMs} depth ${searchDepth}`);
  if (mainEngineTimer) clearTimeout(mainEngineTimer);
  const watchdogMs = isLegacySf10 ? Math.max(3500, Math.min(7000, moveTimeMs * 6)) : Math.max(12000, Math.min(30000, moveTimeMs * 6));
  mainEngineTimer = setTimeout(() => {
    mainEngineTimer = null;
    if (!botThinking || !isStockfishBotMode(mode) || pendingEngineRequest || !engineSearchActive) return;
    retireStockfishWorker('Stockfish không phản hồi đúng hạn.');
    requestOfflineRescueMove('Stockfish không phản hồi đúng hạn');
  }, watchdogMs);
}
function requestOfflineRescueMove(reason = 'Stockfish chưa sẵn sàng') {
  if (!['stockfish', 'stockfish-beginner'].includes(mode) || !botThinking || game.isGameOver() || clockFlagged || game.turn() === humanColor) return false;
  const fen = game.fen();
  const epoch = gameEpoch;
  const preferredProfile = OFFLINE_ENGINE_IDS.includes(settings.alternativeEngine) ? settings.alternativeEngine : 'ethereal';
  const rescueStrength = resolveBotStrength(mode, settings);
  const profile = rescueProfileForStrength(rescueStrength, preferredProfile);
  $('#boardStatus') && ($('#boardStatus').textContent = `${offlineEngineShortName(profile)} · offline đang suy nghĩ…`);
  const isCurrentSearch = () => epoch === gameEpoch && fen === game.fen() && isStockfishBotMode(mode) && botThinking && !game.isGameOver() && !clockFlagged && game.turn() !== humanColor;
  // A bounded search gives a legal fallback without requiring network access. Keep low-Elo
  // targets from silently turning into a full-strength opponent if Stockfish fails, while
  // preserving the deepest rescue budget for unrestricted / max-strength games.
  const beginnerRescueBudget = rescueStrength?.mode === 'skill-level-floor'
    ? resolveBeginnerSearchBudget(rescueStrength.targetElo, { moveTimeMs: settings.botMoveTimeMs, depth: settings.botDepth }) : null;
  const rescueDepth = beginnerRescueBudget
    ? beginnerRescueBudget.depth
    : rescueStrength ? Math.min(12, Number(settings.botDepth) || 12) : Math.max(30, Number(settings.botDepth) || 30);
  const rescueBudget = resolveOfflineSearchBudget(profile, {
    ...settings,
    ...(beginnerRescueBudget ? { beginnerPractice: true } : {}),
    botMoveTimeMs: beginnerRescueBudget?.moveTimeMs || Math.min(2600, Number(settings.botMoveTimeMs) || 2600),
    botDepth: rescueDepth,
  });
  void chooseAlternateMoveAsync(fen, { ...rescueBudget, seen: repetitionContext(game) }).then(uci => {
    if (!isCurrentSearch()) return;
    // Catch up the active side's clock before accepting a move in case a slow WebView
    // delayed interval callbacks while the offline worker fallback was searching.
    tickClock();
    if (!isCurrentSearch()) return;
    const legalUci = new Set(game.moves({ verbose: true }).map(uciForMove));
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(uci || '')) || !legalUci.has(String(uci).toLowerCase())) {
      throw new Error('Engine ngoại tuyến không trả về nước đi hợp lệ.');
    }
    recordEngineSpeed(offlineEngineShortName(profile), getLastOfflineEngineStats());
    const normalizedUci = String(uci).toLowerCase();
    const chosenUci = beginnerRescueBudget
      ? chooseBeginnerMove(normalizedUci, [...legalUci], Math.random, beginnerRescueBudget.deviationChance) || normalizedUci
      : normalizedUci;
    applyUciMove(chosenUci);
    toast(`${reason}; đã dùng ${offlineEngineShortName(profile)} ngoại tuyến.`, '');
  }).catch(error => {
    if (!isCurrentSearch()) return;
    const fallback = chooseFallbackMove();
    botThinking = false;
    if (fallback) applyUciMove(uciForMove(fallback));
    else renderView();
    toast(`${reason}; engine ngoại tuyến cũng lỗi, đã dùng nước dự phòng cơ bản (${error?.message || 'không rõ lỗi'}).`);
  });
  return true;
}
function chooseFallbackMove() { return chooseFallbackMoveFor(game); }
function chooseFallbackMoveFor(chess) {
  const moves = chess.moves({ verbose: true });
  if (!moves.length) return null;
  // Last-resort only: deterministic ordering and tactical priorities avoid a random blunder
  // when both Stockfish and the alpha-beta worker have failed. This is not advertised as engine strength.
  const values = { p: 1, n: 3.1, b: 3.3, r: 5, q: 9, k: 0 };
  const scored = moves.map(move => {
    let score = 0;
    if (move.captured) score += 2 + values[move.captured] * 0.9 - values[move.piece] * 0.15;
    if (move.san.includes('+')) score += 1.1;
    if (move.san.includes('#')) score += 500;
    if (move.promotion) score += 8 + values[move.promotion] * 0.2;
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) score += 0.15;
    const file = move.to.charCodeAt(0) - 97, rank = Number(move.to[1]) - 1;
    score += ((3.5 - Math.abs(3.5 - file)) + (3.5 - Math.abs(3.5 - rank))) * 0.08;
    // Develop minor pieces toward the center early instead of wasting a move on the rim.
    if (chess.history().length < 20 && ['n', 'b'].includes(move.piece)) {
      if (move.from[1] === (move.color === 'w' ? '1' : '8')) score += 0.35;
      if (['d4', 'e4', 'd5', 'e5'].includes(move.to)) score += 0.18;
    }
    return { move, score, uci: uciForMove(move) };
  }).sort((a, b) => b.score - a.score || a.uci.localeCompare(b.uci));
  return scored[0]?.move || null;
}
function applyUciMove(uci) {
  if (clockFlagged) { premoveQueue = []; botThinking = false; return; }
  tickClock();
  if (clockFlagged) { premoveQueue = []; botThinking = false; return; }
  const mover = game.turn();
  const plyBeforeMove = game.history().length;
  const clockBeforeMove = captureMoveClockSnapshot();
  try {
    const from = uci.slice(0, 2), to = uci.slice(2, 4), promotion = uci[4];
    const made = game.move({ from, to, ...(promotion ? { promotion } : {}) });
    if (!made) throw new Error('Stockfish returned an invalid move.');
    recordClockSnapshot(moveClockSnapshots, plyBeforeMove, clockBeforeMove);
    redoStack = [];
    playBoardSound(made, game, settings.soundEnabled, settings.soundTheme);
    lastHintMove = null;
    creditClockForMove(mover);
    gameEpoch += 1;
    lastMove = { from: made.from, to: made.to };
    queueMoveSlide(made);
    announceMove(made, mover);
    currentOpening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 })?.name || currentOpening;
    botThinking = false;
    if (game.isGameOver()) {
      premoveQueue = [];
      renderView();
      stopClock(); toast(game.isCheckmate() ? 'Chiếu hết!' : 'Ván cờ hòa.', 'success');
    } else if (premoveQueue.length) {
      // The queued intent is resolved against the actual position after the bot move.
      // Calling playMove() here makes the premove instant and restarts the bot's clock next turn.
      // Paint the bot's move first (it slides in), keep the premove ghost visible, then fire the premove
      // once the slide has finished, like chess.com, instead of replacing the slide in the same frame.
      const delay = visualSettings.smoothAnimations ? PREMOVE_FIRE_DELAY_MS : 0;
      const armedEpoch = gameEpoch;
      const firePremove = () => {
        premoveFiringUntil = 0;
        if (gameEpoch !== armedEpoch) { premoveQueue = []; premoveViewCache = { key: '', chess: null }; return; }
        const premovePlayed = executeNextPremove();
        if (!premovePlayed) {
          if (currentView === 'play') renderBoard(); else renderView();
          if (currentView === 'play') queryOpeningExplorer(false);
        }
      };
      if (delay > 0 && currentView === 'play') {
        premoveFiringUntil = Date.now() + delay + 60;
        renderBoard();
        setTimeout(firePremove, delay);
      } else firePremove();
    } else {
      if (currentView !== 'play') renderView(); else renderBoard();
      if (currentView === 'play') queryOpeningExplorer(false);
    }
  } catch (error) { premoveQueue = []; botThinking = false; toast(`Lỗi nước đi engine: ${error.message}`); renderView(); }
}
function chessUciHistory() { return game.history({ verbose: true }).map(m => `${m.from}${m.to}${m.promotion || ''}`).join(','); }

// Arena: each configured model plays by proposing one UCI move from the legal-move list.
// chess.js validates every move, while Stockfish remains the tactical engine.
function arenaCandidates() {
  return [
    { id: 'stockfish', name: 'Stockfish 19 · engine chính', type: 'stockfish', profile: 'stockfish', hint: 'Được cấp chung độ sâu, thời gian và Skill Level với đối thủ khác trong đấu trường' },
    { id: 'stockfish-10', name: 'Stockfish 10 · engine cổ điển', type: 'stockfish-legacy', profile: 'stockfish10', hint: 'Engine thế hệ cũ, vẫn được cấp cùng thời gian suy nghĩ trong đấu trường' },
    ...OFFLINE_ENGINE_CATALOG.map(item => ({
      id: `offline-${item.id}`,
      name: `${item.label} · bot phong cách`,
      type: 'offline',
      profile: item.id,
      hint: item.hint || ''
    }))
  ];
}
function arenaPlayer(id) {
  return arenaCandidates().find(player => player.id === id) || null;
}
function renderArenaOptions(selectedId) {
  return arenaCandidates().map(player => `<option value="${esc(player.id)}" ${player.id === selectedId ? 'selected' : ''}>${esc(player.name)}</option>`).join('');
}
function renderArenaCupPodiumMarkup() {
  if (!arenaCupStandings.length) return '<div class="arena-cup-empty">🥇 Chưa có kết quả giải</div>';
  const medals = ['🥇', '🥈', '🥉'];
  return arenaCupStandings.slice(0, 3).map((entry, index) => `<article class="arena-cup-rank rank-${index + 1}"><span>${medals[index] || `${index + 1}.`}</span><b>${esc(entry.name)}</b><strong>${Number(entry.points || 0).toFixed(1)}</strong><small>${Number(entry.wins || 0)} thắng · ${Number(entry.draws || 0)} hòa · ${Number(entry.losses || 0)} thua</small></article>`).join('');
}
function syncArenaCupPodium() {
  const podium = $('#arenaCupPodium');
  if (podium) podium.innerHTML = renderArenaCupPodiumMarkup();
  const copy = $('.arena-cup-copy p');
  if (copy) copy.textContent = arenaCupStandings.length ? `Nhà vô địch gần nhất: ${arenaCupStandings[0].name} · ${Number(arenaCupStandings[0].points || 0).toFixed(1)} điểm` : 'Chạy giải vòng tròn để xác định nhà vô địch và bảng xếp hạng bot.';
}

function renderArenaView() {
  const players = arenaCandidates();
  const validLeague = new Set(players.map(p => p.id));
  for (const id of [...arenaSelectedLeague]) if (!validLeague.has(id)) arenaSelectedLeague.delete(id);
  if (!arenaSelectedLeague.size) { arenaSelectedLeague.add('stockfish'); arenaSelectedLeague.add('offline-ethereal'); }
  const leagueChecks = players.map(player => {
    const openingNames = getPersonaOpeningNames(player.profile || 'classic');
    const kind = player.type === 'stockfish' ? 'Stockfish 19 · ngân sách chung' : player.type === 'stockfish-legacy' ? 'Stockfish 10 · cùng thời gian nghĩ' : `Phong cách VILA · ${esc(player.hint || player.profile)}`;
    return `<label class="arena-check" title="Kho khai cuộc riêng: ${esc(openingNames.join(' · '))}"><input type="checkbox" class="arena-participant-check" value="${esc(player.id)}" ${arenaSelectedLeague.has(player.id) ? 'checked' : ''}/><span><b>${esc(player.name)}</b><small>${kind}</small><small>4 khai cuộc dự trữ: ${esc(openingNames.join(' · '))}</small></span></label>`;
  }).join('');
  const defaultBlack = players.some(p => p.id === 'offline-ethereal') ? 'offline-ethereal' : players[1]?.id || 'stockfish';
  const whiteName = arenaCurrentPlayers.w?.name || 'Stockfish 19';
  const blackName = arenaCurrentPlayers.b?.name || 'VILA · Bot chiến thuật';
  return `<section class="content-page arena-page arena-redesign">
    <div class="arena-page-heading"><div><span class="eyebrow">CỜ VUA · AI ARENA</span><h1>Đấu trường AI</h1><p>Cho hai bot thi đấu tự động, theo dõi từng nước và lưu biên bản PGN.</p><details class="arena-truth-details"><summary>Cách đấu công bằng &amp; lưu ý</summary><p class="arena-truth-note">Mặc định thi đấu tối đa: mọi bot dùng chung độ sâu, thời gian suy nghĩ và Skill Level; mỗi bot có kho 4 khai cuộc riêng. Bật ‘Khai cuộc ghép cặp’ để benchmark trên cùng khai cuộc đổi màu. Các nhãn phong cách không phải xếp hạng Elo đã benchmark và không phải các engine thương hiệu bên ngoài hay binary neural độc lập; Stockfish được dùng để tìm nước khi sẵn sàng.</p></details></div><span class="arena-header-status ${arenaRunning ? 'is-live' : ''}"><i></i>${arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'}</span></div>
    <section class="panel arena-match-card">
      <div class="arena-player-strip arena-player-top is-black"><div class="arena-profile-avatar avatar-vila">♞</div><div class="arena-player-meta"><b id="arenaBlackName">${esc(blackName)}</b><small><i class="arena-color-dot is-black"></i>QUÂN ĐEN · ${arenaCurrentPlayers.b ? 'AI ĐANG CHƠI' : 'CHỜ GHÉP CẶP'}</small>${renderArenaCapturedMaterial('b')}</div><span class="arena-player-type is-black">ĐEN</span></div>
      <div class="arena-board-frame"><div id="arenaBoard" class="arena-board" role="grid" aria-label="Bàn cờ đấu trường AI"></div></div>
      <div class="arena-board-meta"><span id="arenaStatus">${esc(arenaLastResult || positionStatus(arenaGame))}</span><b id="arenaPlyCount">${arenaGame.history().length} nửa nước</b></div>
      <div class="engine-speed-row">${engineSpeedChipMarkup()}</div><div id="arenaFallbackNote" class="arena-fallback-note">${esc(arenaLastNote || 'Nước đi được kiểm tra bởi chess.js; engine chạy cục bộ khi tài nguyên sẵn sàng.')}</div>
      <div class="arena-player-strip arena-player-bottom is-white"><div class="arena-profile-avatar avatar-stockfish">♘</div><div class="arena-player-meta"><b id="arenaWhiteName">${esc(whiteName)}</b><small><i class="arena-color-dot is-white"></i>QUÂN TRẮNG · ${arenaCurrentPlayers.w ? 'AI ĐANG CHƠI' : 'CHỜ GHÉP CẶP'}</small>${renderArenaCapturedMaterial('w')}</div><span class="arena-player-type is-white">TRẮNG</span></div>
      <div class="arena-primary-controls"><button id="arenaRunMatch" class="primary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>▶ Đấu trận</button><button id="arenaRunLeague" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>♜ Chạy giải đấu</button><button id="arenaPause" class="secondary-btn" type="button" aria-pressed="${arenaPaused}" ${arenaRunning ? '' : 'disabled'}>${arenaPaused ? '▶ Tiếp tục' : '⏸ Tạm dừng'}</button><button id="arenaStop" class="danger-btn" type="button" ${arenaRunning ? '' : 'disabled'}>■ Dừng</button></div>
      <div class="arena-secondary-controls"><button id="arenaSwapRematch" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>⇄ Đổi màu</button><button id="arenaReset" class="secondary-btn" type="button" ${arenaRunning ? 'disabled' : ''}>↺ Ván mới</button><button id="arenaDownloadPGN" class="secondary-btn" type="button" ${(arenaGame.history().length || arenaPgnArchive.length) ? '' : 'disabled'}>↓ Tải PGN</button><button id="arenaOpenSettings" class="secondary-btn" type="button">⚙ Chọn bot &amp; tùy chỉnh</button></div>
      <section class="arena-cup-panel" aria-label="Cúp đấu trường ViLa"><div class="arena-cup-emblem" aria-hidden="true">🏆</div><div class="arena-cup-copy"><small class="eyebrow">VILA AI · CUP</small><h2>Cúp đấu trường</h2><p>${arenaCupStandings.length ? `Nhà vô địch gần nhất: ${esc(arenaCupStandings[0].name)} · ${Number(arenaCupStandings[0].points || 0).toFixed(1)} điểm` : 'Chạy giải vòng tròn để xác định nhà vô địch và bảng xếp hạng bot.'}</p></div><div id="arenaCupPodium" class="arena-cup-podium">${renderArenaCupPodiumMarkup()}</div></section>
      <div id="arenaLeagueSummary" class="arena-league-summary">${esc(arenaTournamentSummary || 'Chọn bot và bấm Đấu trận để bắt đầu.')}</div>
    </section>
    <section class="panel arena-standings-panel" aria-label="Bảng xếp hạng giải đấu"><div class="panel-heading"><div><small class="eyebrow">BẢNG XẾP HẠNG TRỰC TIẾP</small><h2>Kết quả giải</h2></div><span class="context-icon">🏆</span></div><div id="arenaProgress" class="arena-progress" ${arenaProgress ? '' : 'hidden'}></div><div id="arenaStandings" class="arena-standings">${renderArenaStandingsMarkup()}</div></section>
    <section class="panel arena-moves-panel"><div class="panel-heading"><div><small class="eyebrow">BIÊN BẢN VÁN ĐẤU</small><h2>Nước đi</h2></div><span class="small-counter" id="arenaMoveCounter">${arenaGame.history().length}</span></div><div id="arenaMoveList" class="move-list arena-move-list"></div></section>
    <details class="panel arena-advanced-settings"><summary><span><small class="eyebrow">TÙY CHỈNH</small><b>Đối thủ, sức mạnh và giải đấu</b></span><span class="setup-chevron">⌄</span></summary><div class="arena-settings-grid"><section class="arena-setting-section"><div class="panel-heading"><h2>Chọn đối thủ</h2><span class="context-icon">⚔</span></div><label class="field-label" for="arenaWhite">Quân Trắng</label><select id="arenaWhite" class="field">${renderArenaOptions('stockfish')}</select><label class="field-label" for="arenaBlack">Quân Đen</label><select id="arenaBlack" class="field">${renderArenaOptions(defaultBlack)}</select><label class="preference-toggle arena-random-sides"><input id="arenaRandomSides" type="checkbox" ${arenaRandomSides ? 'checked' : ''}/><span><b>🎲 Đảo màu ngẫu nhiên</b><small>Giải vòng tròn tự đổi màu hai lượt mỗi cặp.</small></span></label>
      <div class="two-fields"><div><label class="field-label" for="arenaDepth">Độ sâu tìm kiếm</label><select id="arenaDepth" class="field">${[16,20,24,28,30,32,36,40].map(n=>`<option value="${n}" ${n===32?'selected':''}>${n}${n>=32?' · full power':''}</option>`).join('')}</select></div><div><label class="field-label" for="arenaDelay">Nghỉ mỗi nước</label><select id="arenaDelay" class="field"><option value="0">Nhanh nhất</option><option value="100" selected>0,1 giây</option><option value="400">0,4 giây</option><option value="800">0,8 giây</option></select></div></div>
      <div class="two-fields"><div><label class="field-label" for="arenaPlyLimit">Giới hạn nửa nước</label><select id="arenaPlyLimit" class="field">${[80,120,180,240,300].map(n=>`<option value="${n}" ${n===180?'selected':''}>${n}</option>`).join('')}</select></div><div><label class="field-label" for="arenaSkill">Skill Level chung</label><select id="arenaSkill" class="field">${[14,18,20].map(n=>`<option value="${n}" ${n===20?'selected':''}>${n}/20</option>`).join('')}</select></div></div>
      <div class="two-fields"><div><label class="field-label" for="arenaEngineMode">Sức mạnh</label><select id="arenaEngineMode" class="field"><option value="max" selected>Tối đa · full power</option><option value="elo">Giới hạn mô phỏng Elo</option></select></div><div><label class="field-label" for="arenaEngineElo">Elo mô phỏng</label><select id="arenaEngineElo" class="field">${Array.from({ length: 28 }, (_, i) => 500 + i * 100).map(n=>`<option value="${n}" ${n===2800?'selected':''}>${n}</option>`).join('')}</select></div></div><p class="field-hint">Full power mặc định: độ sâu 32, Skill 20, thời gian suy nghĩ ~2–15 giây/nước (tăng theo độ sâu). Mọi bot dùng chung ngân sách; MultiPV=1 khi full power để giảm overhead. Bật ‘Khai cuộc ghép cặp’ để benchmark cùng khai cuộc. Chế độ Elo chỉ mô phỏng, không phải Elo chuẩn.</p></section>
      <section class="arena-setting-section arena-format-section"><div class="panel-heading"><div><small class="eyebrow">THỂ THỨC</small><h2>Giải đấu</h2></div><span class="context-icon">♜</span></div>
        <div class="two-fields"><div><label class="field-label" for="arenaFormat">Thể thức</label><select id="arenaFormat" class="field">${ARENA_FORMATS.map(item => `<option value="${item.id}" ${item.id === 'roundrobin' ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select></div><div><label class="field-label" for="arenaGamesPerPair">Số ván mỗi cặp</label><select id="arenaGamesPerPair" class="field">${ARENA_GAMES_PER_PAIR_OPTIONS.map(n => `<option value="${n}" ${n === 2 ? 'selected' : ''}>${n}</option>`).join('')}</select></div></div>
        <label class="arena-toggle"><input type="checkbox" id="arenaPairedOpenings"/><span><b>Khai cuộc ghép cặp (tuỳ chọn)</b><small>Mỗi bot có kho 4 khai cuộc riêng; bật tuỳ chọn này để benchmark cùng một khai cuộc và đổi màu.</small></span></label>
        <label class="arena-toggle"><input type="checkbox" id="arenaAdjudicate" checked/><span><b>Xử ván dài theo vật chất</b><small>Chạm giới hạn nửa nước: hơn từ 5 tốt tính thắng, còn lại hòa.</small></span></label>
        <p class="field-hint" id="arenaFormatHint">${esc(ARENA_FORMATS.find(item => item.id === 'roundrobin').hint)}</p></section>
      <section class="arena-setting-section"><div class="panel-heading"><div><small class="eyebrow">GIẢI NỘI BỘ</small><h2>Bot tham gia</h2></div><span class="small-counter">${players.length}</span></div><div class="arena-participant-list">${leagueChecks}</div><p class="field-hint">Chọn 2–8 bot (thứ tự chọn quyết định hạt giống/bot thách đấu). Các phong cách là profile VILA dùng chung engine tìm kiếm cục bộ, không phải engine neural độc lập.</p></section></div></details>
  </section>`;
}
function renderArenaPosition() {
  const board = $('#arenaBoard');
  if (!board) return;
  const rows = [8,7,6,5,4,3,2,1], files = ['a','b','c','d','e','f','g','h'];
  let html = '';
  rows.forEach((rank, rowIndex) => files.forEach((file, colIndex) => {
    const sq = `${file}${rank}`;
    const piece = arenaGame.get(sq);
    const last = arenaLastMove && (arenaLastMove.from === sq || arenaLastMove.to === sq);
    html += `<div class="arena-square ${squareColor(sq)} ${last ? 'arena-last-move' : ''}" aria-label="${sq}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${visualSettings.showCoordinates && colIndex === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${visualSettings.showCoordinates && rowIndex === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</div>`;
  }));
  board.innerHTML = html;
  syncArenaBoardLayout();
  const status = $('#arenaStatus');
  if (status) status.textContent = arenaRunning ? `${arenaCurrentPlayers[arenaGame.turn()]?.name || 'AI'} đang suy nghĩ…` : (arenaLastResult || positionStatus(arenaGame));
  const title = $('#arenaMatchTitle');
  if (title) title.textContent = `${arenaCurrentPlayers.w?.name || 'Stockfish'} vs ${arenaCurrentPlayers.b?.name || 'AI hiện tại'}`;
  const whiteName = $('#arenaWhiteName'); if (whiteName) whiteName.textContent = arenaCurrentPlayers.w?.name || 'Stockfish 19';
  const blackName = $('#arenaBlackName'); if (blackName) blackName.textContent = arenaCurrentPlayers.b?.name || 'VILA · Bot chiến thuật';
  const badge = $('#arenaLiveBadge');
  if (badge) { badge.textContent = arenaRunning ? 'ĐANG ĐẤU' : 'SẴN SÀNG'; badge.classList.toggle('is-live', arenaRunning); }
  const ply = $('#arenaPlyCount'); if (ply) ply.textContent = `${arenaGame.history().length} nửa nước đi`;
  const counter = $('#arenaMoveCounter'); if (counter) counter.textContent = String(arenaGame.history().length);
  const note = $('#arenaFallbackNote'); if (note) note.textContent = arenaEngineWarning || arenaLastNote || 'Các nước của AI sẽ hiện tại đây.';
  const moveList = $('#arenaMoveList');
  if (moveList) {
    const history = arenaGame.history();
    if (!history.length) moveList.innerHTML = '<div class="empty-state">Chưa có nước đi. Bắt đầu một trận để hai AI chơi tự động.</div>';
    else {
      let rows = '';
      for (let i = 0; i < history.length; i += 2) rows += `<div class="move-row"><span class="move-number">${Math.floor(i / 2)+1}.</span>${moveSanCell(history[i])}${moveSanCell(history[i+1] || '…')}</div>`;
      moveList.innerHTML = rows; moveList.scrollTop = moveList.scrollHeight;
    }
  }
  ['arenaRunMatch','arenaRunLeague','arenaSwapRematch','arenaReset','arenaDownloadPGN'].forEach(id => { const button = $(`#${id}`); if (button) button.disabled = arenaRunning || (id === 'arenaDownloadPGN' && !arenaGame.history().length && !arenaPgnArchive.length); });
  const stop = $('#arenaStop'); if (stop) stop.disabled = !arenaRunning;
  updateArenaCapturedMaterialDisplays();
  syncArenaPauseButton();
}
function wireArenaActions() {
  $('#arenaRandomSides')?.addEventListener('change', event => { arenaRandomSides = Boolean(event.target.checked); });
  $('#arenaRunMatch')?.addEventListener('click', () => { drawArenaSides(); unlockBoardSound(); startArenaMatch($('#arenaWhite')?.value || 'stockfish', $('#arenaBlack')?.value || 'offline-ethereal'); });
  $('#arenaRunLeague')?.addEventListener('click', () => { unlockBoardSound(); runArenaLeague(); });
  $('#arenaStop')?.addEventListener('click', stopArenaMatch);
  $('#arenaOpenSettings')?.addEventListener('click', () => { const panel = $('.arena-advanced-settings'); if (!panel) return; panel.open = true; panel.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
  $('#arenaPause')?.addEventListener('click', toggleArenaPause);
  $('#arenaFormat')?.addEventListener('change', event => {
    const hint = ARENA_FORMATS.find(item => item.id === event.target.value)?.hint || '';
    if ($('#arenaFormatHint')) $('#arenaFormatHint').textContent = hint;
    const perPair = $('#arenaGamesPerPair'); if (perPair) perPair.disabled = event.target.value === 'knockout';
  });
  $('#arenaReset')?.addEventListener('click', () => { if (arenaRunning) return; arenaGame = new Chess(); arenaLastMove = null; arenaLastResult = ''; arenaLastNote = ''; arenaEngineWarning = ''; arenaLastPgnResult = '*'; arenaPgnArchive = []; renderArenaPosition(); });
  $('#arenaSwapRematch')?.addEventListener('click', () => { if (arenaRunning) return; unlockBoardSound(); const w = $('#arenaWhite')?.value || 'stockfish'; if ($('#arenaWhite')) $('#arenaWhite').value = $('#arenaBlack')?.value || 'offline-ethereal'; if ($('#arenaBlack')) $('#arenaBlack').value = w; startArenaMatch($('#arenaWhite')?.value || 'stockfish', $('#arenaBlack')?.value || 'offline-ethereal'); });
  $('#arenaDownloadPGN')?.addEventListener('click', downloadArenaPgn);
  $$('.arena-participant-check').forEach(input => input.addEventListener('change', () => { if (input.checked && arenaSelectedLeague.size >= ARENA_MAX_PLAYERS) { input.checked = false; toast(`Tối đa ${ARENA_MAX_PLAYERS} bot mỗi giải.`); return; } if (input.checked) arenaSelectedLeague.add(input.value); else arenaSelectedLeague.delete(input.value); }));
}
/** Single-match colour draw: when "Đảo màu ngẫu nhiên" is on, a coin flip may swap the two selected bots. */
function drawArenaSides() {
  const white = $('#arenaWhite'), black = $('#arenaBlack');
  if (!arenaRandomSides || !white || !black || white.value === black.value) return false;
  if (Math.random() < 0.5) { arenaLastNote = 'Bốc thăm màu: giữ nguyên vị trí đã chọn.'; return false; }
  const whiteValue = white.value;
  white.value = black.value; black.value = whiteValue;
  arenaLastNote = 'Bốc thăm màu: hai bot đã đổi bên.';
  return true;
}
function arenaDelay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
async function arenaWaitIfPaused() {
  while (arenaPaused && arenaRunning && !arenaStopRequested) await arenaDelay(150);
}
function syncArenaPauseButton() {
  const button = $('#arenaPause');
  if (!button) return;
  button.disabled = !arenaRunning;
  button.textContent = arenaPaused ? '▶ Tiếp tục' : '⏸ Tạm dừng';
  button.setAttribute('aria-pressed', String(arenaPaused));
}
function toggleArenaPause() {
  if (!arenaRunning) return;
  arenaPaused = !arenaPaused;
  if ($('#arenaStatus')) $('#arenaStatus').textContent = arenaPaused ? 'Đã tạm dừng — bấm Tiếp tục để chạy tiếp (nước đang tính vẫn hoàn tất).' : 'Đang tiếp tục…';
  syncArenaPauseButton();
}
/** Count how often each position (first 4 FEN fields) has occurred, so offline engines avoid repeating moves. */
function repetitionContext(chess) {
  const key = c => c.fen().split(' ').slice(0, 4).join(' ');
  const counts = {};
  try {
    const replay = new Chess();
    counts[key(replay)] = 1;
    for (const san of chess.history()) { replay.move(san); const k = key(replay); counts[k] = (counts[k] || 0) + 1; }
  } catch {}
  return counts;
}
async function requestStockfishUci(fen, { skill = 20, depth = 18, strengthMode = 'max', elo = 3190, moveTimeMs = null, timeoutMs = null, multiPv = 1 } = {}) {
  // Full-power arena: allow up to 15 s / depth 40 so bots actually run near maximum strength.
  const effectiveMoveTimeMs = Math.max(700, Math.min(15_000, Number(moveTimeMs) || Math.round(Math.max(5, Math.min(40, Number(depth) || 18)) * 200)));
  const safeDepth = Math.max(8, Math.min(40, Math.round(Number(depth) || 18)));
  const effectiveTimeoutMs = Number(timeoutMs) || Math.max(15_000, Math.min(90_000, effectiveMoveTimeMs * 6));
  if (!engineWorker || engineFailed) throw new Error('Stockfish chưa sẵn sàng; kiểm tra gói engine sau npm install.');
  const readyStarted = Date.now();
  while (!engineReady && !engineFailed && Date.now() - readyStarted < 20000) await arenaDelay(100);
  if (!engineReady || engineFailed) throw new Error('Chờ Stockfish quá lâu hoặc engine lỗi.');
  if (engineStopPending || pendingEngineRequest || engineSearchActive) throw new Error('Stockfish đang xử lý hoặc đóng một yêu cầu khác. Hãy thử lại sau.');
  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingEngineRequest?.resolve === resolve) {
        pendingEngineRequest = null;
        engineSearchActive = false;
        retireStockfishWorker('Stockfish quá thời gian suy nghĩ.');
        reject(new Error('Stockfish quá thời gian suy nghĩ; engine đã được dừng để tránh nhầm kết quả cũ.'));
      }
    }, effectiveTimeoutMs);
    const requestedMultiPv = Math.max(1, Math.min(5, Math.round(Number(multiPv) || 1)));
    pendingEngineRequest = { resolve, reject, timeout, multiPv: requestedMultiPv, candidates: new Map() };
    engineSearchActive = true;
    const strength = strengthMode === 'elo' ? resolveStockfishStrength(elo) : null;
    engineWorker.postMessage(`setoption name UCI_LimitStrength value ${strength?.limitStrength ? 'true' : 'false'}`);
    if (strength?.uciElo != null) engineWorker.postMessage(`setoption name UCI_Elo value ${strength.uciElo}`);
    const requestedSkill = Number(skill);
    const effectiveSkill = strengthMode === 'elo' ? strength.skillLevel : Math.max(0, Math.min(20, Number.isFinite(requestedSkill) ? requestedSkill : 20));
    engineWorker.postMessage(`setoption name Skill Level value ${effectiveSkill}`);
    engineWorker.postMessage(`setoption name MultiPV value ${requestedMultiPv}`);
    engineWorker.postMessage(`position fen ${fen}`);
    // Enforce both limits: equal depth ceiling and equal wall-clock budget across arena contestants.
    engineWorker.postMessage(`go movetime ${effectiveMoveTimeMs} depth ${safeDepth}`);
  });
}
function uciForMove(move) { return `${move.from}${move.to}${move.promotion || ''}`; }
function stableMoveNoise(seed, maximum = 12) {
  const text = String(seed || 'vila');
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) { hash ^= text.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return ((hash >>> 0) % 10007) / 10007 * Math.max(0, Number(maximum) || 0);
}
function personaCandidateScore(chess, candidate, profile, bestScore) {
  const loss = Math.max(0, bestScore - Number(candidate.score || 0));
  const uci = String(candidate.uci || '');
  const moveData = { from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) };
  let move = null; let next = null;
  try { next = new Chess(chess.fen()); move = next.move(moveData); } catch {}
  if (!move) return -1e9;

  const mover = chess.turn();
  const aggressive = ['berserk', 'gambit', 'trickster', 'dynamic', 'hunter', 'chaos'].includes(profile);
  const cautious = ['fortress', 'strangler', 'endgame', 'sentinel', 'strategist', 'longgame'].includes(profile);
  const centerSquares = ['d4', 'e4', 'd5', 'e5'];
  const centerControl = centerSquares.reduce((score, square) => {
    const piece = next.get(square);
    return score + (piece?.color === mover ? 1 : piece ? -0.2 : 0);
  }, 0);
  const replies = next.moves({ verbose: true });
  let style = 0;

  // Each persona gets a real move-selection bias on top of legal UCI candidate moves.
  // The profile names are styles, not separate trained networks or measured Elo ratings.
  if (aggressive) {
    if (next.isCheck()) style += profile === 'berserk' ? 42 : 28;
    if (move.captured) style += (profile === 'gambit' || profile === 'berserk') ? 24 : 14;
    if (move.promotion) style += 80;
  }
  if (profile === 'lc0') style += centerControl * 22 + (move.piece === 'n' || move.piece === 'b' ? 4 : 0);
  if (profile === 'ethereal') style -= loss * 0.12; // very low-variance, prioritizes evaluation stability
  if (profile === 'fortress') {
    if (move.captured === 'q' || move.captured === 'r') style += 18;
    if (move.piece === 'p' && Math.abs(Number(move.to[1]) - Number(move.from[1])) === 1) style += 2;
    if (next.isCheck()) style += 4; // only when the defensive move also creates a forcing reply
  }
  if (['endgame', 'longgame'].includes(profile)) {
    const boardPieces = next.board().flat().filter(Boolean);
    const nonPawnMaterial = boardPieces.filter(piece => !['p', 'k'].includes(piece.type)).length;
    if (nonPawnMaterial <= 6) {
      const king = boardPieces.find(piece => piece.type === 'k' && piece.color === mover);
      if (king?.square) {
        const file = king.square.charCodeAt(0) - 97;
        const rank = Number(king.square[1]) - 1;
        const distance = Math.min(...[[3,3],[4,3],[3,4],[4,4]].map(([f,r]) => Math.abs(file-f) + Math.abs(rank-r)));
        style += (7 - distance) * 4;
      }
    }
  }
  if (profile === 'dynamic') style += centerControl * 10;
  if (profile === 'blitz') style += stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|blitz`, 12);
  if (profile === 'gambit' && move.piece === 'p' && chess.history().length < 16) style += 12;
  if (profile === 'hyper' && chess.history().length < 18) {
    if ((move.piece === 'n' || move.piece === 'b') && move.from[1] === (mover === 'w' ? '1' : '8')) style += 22;
    if (String(move.flags || '').includes('k') || String(move.flags || '').includes('q')) style += 20;
    style += centerControl * 8;
  }
  if (profile === 'strangler') style += Math.max(-12, Math.min(18, (30 - replies.length) * 0.8)) + centerControl * 8;
  if (profile === 'trickster' || profile === 'chaos') style += stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|${profile}`, 18) + (move.san.includes('+') ? 9 : 0);
  if (profile === 'hunter') style += (move.captured ? 22 : 0) + (next.isCheck() ? 16 : 0) + (move.promotion ? 90 : 0);
  if (profile === 'sentinel') style -= loss * 0.22;
  if (profile === 'strategist') style += centerControl * 12 + Math.max(-8, Math.min(14, (28 - replies.length) * 0.55));
  if (profile === 'mentor' || profile === 'rookie') style += loss * 0.7 + stableMoveNoise(`${chess.fen()}|${move.from}${move.to}|${profile}`, 18); // controlled sub-best bias, deterministic for repeatable testing

  const lossPenalty = ['rookie', 'mentor'].includes(profile) ? 0.35 : profile === 'ethereal' ? 1.25 : aggressive ? 0.55 : cautious ? 1.2 : 0.8;
  return Number(candidate.score || 0) - loss * lossPenalty + style;
}
function getLegacyArenaEngine() {
  if (legacyArenaEngine) return legacyArenaEngine;
  legacyArenaEngine = new LegacyUciEngine(() => {
    const asset = new URL(`${import.meta.env.BASE_URL}engine/stockfish-10.js`, window.location.href).href;
    return new Worker(asset);
  }, { initTimeoutMs: 8_000, defaultSearchTimeoutMs: 4_500 });
  return legacyArenaEngine;
}
async function requestLegacyArenaUci(chess, depth, skill, options = {}) {
  // Stockfish 10 has no UCI_Elo option in this adapter. Use a clearly approximate
  // Skill Level mapping only in the optional Elo simulation; default/max mode keeps level 20.
  const legacySkill = options.strengthMode === 'elo'
    ? Math.max(0, Math.min(20, Math.round((Math.max(500, Math.min(3200, Number(options.elo) || 2600)) - 500) / (3200 - 500) * 20)))
    : Math.max(0, Math.min(20, Math.round(Number(skill) || 20)));
  const moveTimeMs = Number(options.moveTimeMs) || resolveArenaMoveTimeMs(depth);
  const result = await getLegacyArenaEngine().bestMove(chess.fen(), {
    skill: legacySkill,
    moveTimeMs,
    depth: Math.max(8, Math.min(30, Math.round(Number(depth) || 20))),
    timeoutMs: Math.max(8_000, moveTimeMs * 4)
  });
  if (!result?.uci) throw new Error('Stockfish 10 không trả về nước đi hợp lệ.');
  const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
  if (!legal.has(result.uci)) throw new Error(`Stockfish 10 trả về nước không hợp lệ: ${result.uci}`);
  if (result.depth) engineSpeed = { depth: result.depth, nps: 0, label: 'Stockfish 10 · JavaScript' };
  arenaEngineWarning = '';
  return result.uci;
}

async function chooseArenaUci(player, chess, depth, skill, options = {}) {
  const profile = player.profile || 'classic';
  const requestedStrength = options.strengthMode === 'elo' ? resolveStockfishStrength(options.elo) : null;
  // By default each contestant consults its own four-line repertoire. The optional
  // paired-opening experiment preloads a common line before this function is called;
  // off-book positions always return to the same full-budget engine search.
  if (settings.openingBookEnabled && chess.history().length < 14 && requestedStrength?.mode !== 'skill-level-floor') {
    const bookMove = pickPersonaBookMove(chess, profile, OPENINGS, { recentChoices: arenaOpeningChoices });
    if (bookMove) {
      arenaLastNote = `${player.name} dùng khai cuộc riêng (${getPersonaOpeningNames(profile).length} biến dự trữ).`;
      return uciForMove(bookMove);
    }
  }
  if (player.type === 'stockfish-legacy') {
    try {
      const uci = await requestLegacyArenaUci(chess, depth, skill, options);
      arenaLastNote = 'Stockfish 10 · engine cổ điển riêng biệt, đã kiểm tra nước đi hợp lệ.';
      return uci;
    } catch (legacyError) {
      // Never strand a bot-versus-bot match when a legacy asm.js Worker fails to load.
      // Try the installed Stockfish 19 worker first, then the in-app alpha-beta engine.
      const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
      try {
        const recovered = await requestStockfishUci(chess.fen(), {
          skill: Math.min(20, Math.max(0, skill)), depth: Math.max(8, Number(depth) || 16),
          strengthMode: options.strengthMode || 'max', elo: options.elo || 2600,
          moveTimeMs: Number(options.moveTimeMs) || resolveArenaMoveTimeMs(depth), multiPv: 4
        });
        const uci = Array.isArray(recovered) ? recovered[0]?.uci : recovered;
        if (uci && legal.has(uci)) {
          arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
          arenaLastNote = `Stockfish 10 không khởi chạy; đã chuyển sang Stockfish 19. (${String(legacyError?.message || legacyError).slice(0, 100)})`;
          return uci;
        }
      } catch (recoveryError) { console.warn('[VILA Arena] Stockfish 19 fallback failed:', recoveryError?.message || recoveryError); }
      const recoveryTimeMs = Number(options.moveTimeMs) || resolveArenaMoveTimeMs(depth);
      const offlineUci = await chooseAlternateMoveAsync(chess.fen(), { profile: 'classic', seen: repetitionContext(chess), depth: Math.max(4, Math.min(11, Math.round(Number(depth) / 2.5))), maxNodes: Math.max(80_000, Math.min(600_000, recoveryTimeMs * 180)), maxTimeMs: recoveryTimeMs });
      if (offlineUci && legal.has(offlineUci)) {
        arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
        recordEngineSpeed('VILA offline fallback', getLastOfflineEngineStats());
        arenaLastNote = 'Stockfish 10 không khả dụng; trận vẫn chạy bằng bộ tìm kiếm offline VILA.';
        return offlineUci;
      }
      throw new Error(`Stockfish 10 và các engine dự phòng đều không hoạt động: ${String(legacyError?.message || legacyError)}`);
    }
  }
  try {
    const moveTimeMs = Number(options.moveTimeMs) || resolveArenaMoveTimeMs(depth);
    const result = await requestStockfishUci(chess.fen(), {
      skill,
      depth,
      strengthMode: options.strengthMode || 'max',
      elo: options.elo || 2600,
      moveTimeMs,
      multiPv: 4,
    });
    if (player.type === 'stockfish') return Array.isArray(result) ? result[0]?.uci : result;
    const candidates = Array.isArray(result) ? result : [{ uci: result, score: 0 }];
    const bestScore = Math.max(...candidates.map(item => Number(item.score || 0)));
    const ranked = candidates.map(item => ({ ...item, personalityScore: personaCandidateScore(chess, item, profile, bestScore) })).sort((a, b) => b.personalityScore - a.personalityScore);
    // Preserve tactical quality: personas choose only among searched candidate lines, with a tight score window.
    const tolerance = resolveArenaStyleTolerance(profile);
    const acceptable = ranked.filter(item => bestScore - Number(item.score || 0) <= tolerance);
    const pool = acceptable.length ? acceptable.slice(0, Math.min(3, acceptable.length)) : ranked.slice(0, 1);
    const chosen = [...pool].sort((a, b) => Number(b.personalityScore || 0) - Number(a.personalityScore || 0) || String(a.uci).localeCompare(String(b.uci)))[0] || candidates[0];
    return chosen?.uci || candidates[0]?.uci || '';
  } catch (error) {
    // When the primary worker fails, every contestant gets the same bounded offline rescue
    // search before the arena considers the last-resort legal move. Record the fallback visibly.
    const moveTimeMs = Number(options.moveTimeMs) || resolveArenaMoveTimeMs(depth);
    const fallbackProfile = OFFLINE_ENGINE_IDS.includes(profile) ? profile : 'classic';
    try {
      const fallbackUci = await chooseAlternateMoveAsync(chess.fen(), {
        profile: fallbackProfile,
        seen: repetitionContext(chess),
        depth: Math.max(4, Math.min(11, Math.round(Number(depth) / 2.5))),
        maxNodes: Math.max(80_000, Math.min(600_000, moveTimeMs * 180)),
        maxTimeMs: moveTimeMs,
      });
      const legal = new Set(chess.moves({ verbose: true }).map(uciForMove));
      if (fallbackUci && legal.has(fallbackUci)) {
        arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
        recordEngineSpeed('VILA offline rescue', getLastOfflineEngineStats());
        arenaLastNote = `${player.name}: engine chính lỗi (${String(error?.message || error).slice(0, 90)}); nước này dùng tìm kiếm offline cứu hộ.`;
        return fallbackUci;
      }
    } catch (rescueError) {
      console.warn('[VILA Arena] offline rescue failed:', rescueError?.message || rescueError);
    }
    if (player.type === 'stockfish') throw error;
    throw error;
  }
}
function getArenaOutcome(chess, plyLimit, adjudicate = true) {
  if (chess.isCheckmate()) return { winner: chess.turn() === 'w' ? 'b' : 'w', result: chess.turn() === 'w' ? '0-1' : '1-0', reason: 'Chiếu hết' };
  if (chess.isDraw()) return { winner: null, result: '1/2-1/2', reason: chess.isStalemate() ? 'Hòa pat' : 'Ván hòa theo luật cờ' };
  if (chess.history().length >= plyLimit) {
    const verdict = adjudicateAtPlyLimit(chess.board(), plyLimit, { enabled: adjudicate });
    return { winner: verdict.result === '1-0' ? 'w' : verdict.result === '0-1' ? 'b' : null, result: verdict.result, reason: verdict.reason };
  }
  return null;
}
async function playArenaCore(white, black, options = {}) {
  arenaOpeningChoices = new Map();
  const depth = options.depth || 20, skill = options.skill ?? 20, delayMs = options.delayMs ?? 150, plyLimit = options.plyLimit || 120;
  arenaGame = new Chess(); arenaLastMove = null; arenaLastNote = ''; arenaLastResult = '';
  arenaEngineWarning = '';
  arenaGameMeta = options.meta || null;
  // Paired openings: the same short book line is replayed with colours swapped so luck of the opening cancels out.
  for (const san of Array.isArray(options.openingSan) ? options.openingSan : []) {
    try { const made = arenaGame.move(san); if (made) arenaLastMove = { from: made.from, to: made.to }; } catch { break; }
  }
  if ([white, black].some(player => player?.type === 'stockfish-legacy')) {
    // Reset the legacy engine exactly once per match. Resetting it every ply
    // discards its hash table and slows down the old JavaScript engine.
    getLegacyArenaEngine().newGame();
  }
  if (engineWorker && engineReady && !engineFailed) {
    try { engineWorker.postMessage('stop'); engineWorker.postMessage('ucinewgame'); } catch {}
  }
  arenaCurrentPlayers = { w: white, b: black };
  renderArenaPosition();
  while (arenaRunning && !arenaStopRequested && !arenaGame.isGameOver() && arenaGame.history().length < plyLimit) {
    await arenaWaitIfPaused();
    if (arenaStopRequested || !arenaRunning) break;
    const player = arenaCurrentPlayers[arenaGame.turn()];
    arenaLastNote = `${player.name} đang tính nước đi…`; renderArenaPosition();
    let uci;
    try { uci = await chooseArenaUci(player, arenaGame, depth, skill, options); }
    catch (error) {
      if (arenaStopRequested || error?.name === 'AbortError') break;
      if (['stockfish', 'stockfish-legacy', 'offline'].includes(player.type)) arenaFallbackMoves.set(player.id, (arenaFallbackMoves.get(player.id) || 0) + 1);
      const errorText = String(error?.message || error || 'lỗi không rõ').slice(0, 150);
      if (player.type === 'stockfish-legacy') {
        console.warn('[VILA Arena] Stockfish 10 search failed; using a legal fallback and retrying next turn.', error);
        arenaEngineWarning = `Stockfish 10 gặp lỗi: ${errorText}. Nước này dùng dự phòng; engine sẽ tự thử lại ở lượt sau.`;
        arenaLastNote = arenaEngineWarning;
      } else {
        arenaLastNote = `Lỗi ${player.name}: ${errorText}`;
      }
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      uci = uciForMove(fallback);
    }
    if (arenaStopRequested || !arenaRunning) break;
    const legal = arenaGame.moves({ verbose: true }).map(uciForMove);
    if (!legal.includes(uci)) {
      const fallback = chooseFallbackMoveFor(arenaGame);
      if (!fallback) break;
      arenaLastNote = `${player.name} trả nước không hợp lệ; đã thay bằng một nước hợp lệ.`;
      uci = uciForMove(fallback);
    }
    try {
      const made = arenaGame.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) });
      if (!made) throw new Error('Nước đi bị luật cờ từ chối.');
      arenaLastMove = { from: made.from, to: made.to };
      playBoardSound(made, arenaGame, settings.soundEnabled, settings.soundTheme);
    } catch (error) {
      arenaLastNote = `Bỏ qua nước không hợp lệ: ${error.message}`;
      continue;
    }
    renderArenaPosition();
    await arenaDelay(delayMs);
  }
  if (arenaGame.isGameOver() || arenaGame.history().length >= plyLimit) {
    const outcome = getArenaOutcome(arenaGame, plyLimit, options.adjudicate !== false) || { result: '*', reason: positionStatus(arenaGame) };
    arenaLastPgnResult = outcome.result || '*';
    archiveArenaGame(white, black, arenaLastPgnResult, outcome.reason);
    arenaLastResult = `${outcome.reason} · ${outcome.result} · ${white.name} vs ${black.name}`;
    if (/đang tính nước đi/.test(arenaLastNote)) arenaLastNote = 'Ván đã kết thúc — xem các nước đi bên dưới hoặc tải PGN.';
    return { ...outcome, white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn() };
  }
  arenaLastPgnResult = '*';
  if (arenaGame.history().length) archiveArenaGame(white, black, '*', 'Đã dừng');
  arenaLastResult = `Đã dừng ván tại ${arenaGame.history().length} nửa nước.`;
  if (/đang tính nước đi/.test(arenaLastNote)) arenaLastNote = 'Ván đã dừng — có thể tải PGN hoặc bấm Đấu trận để chơi lại.';
  return { winner: null, result: '*', reason: 'Đã dừng', white: white.name, black: black.name, plies: arenaGame.history().length, pgn: arenaGame.pgn(), stopped: true };
}
async function startArenaMatch(whiteId, blackId) {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish ở bàn Chơi cờ kết thúc rồi mới khởi động đấu trường.'); return; }
  const white = arenaPlayer(whiteId), black = arenaPlayer(blackId);
  if (!white || !black) { toast('Không tìm thấy một trong hai AI.'); return; }
  arenaRunning = true; arenaStopRequested = false; arenaAbortController = new AbortController(); arenaGameCounter++; arenaFallbackMoves = new Map(); arenaPgnArchive = []; arenaLastPgnResult = '*'; arenaEngineWarning = '';
  renderArenaPosition();
  try {
    const result = await playArenaCore(white, black, readArenaOptions());
    if (!result.stopped) {
      const fallbackCount = arenaFallbackMoves.get(white.id) || 0;
      const otherFallback = arenaFallbackMoves.get(black.id) || 0;
      const fallbackTag = fallbackCount + otherFallback ? ` · ${fallbackCount + otherFallback} nước dùng dự phòng khi AI lỗi` : '';
      arenaTournamentSummary = `${result.white} ${result.result} ${result.black} · ${result.reason} · ${result.plies} nửa nước${fallbackTag}`;
    }
    else arenaTournamentSummary = result.reason;
    arenaLastResult = result.reason + (result.result && result.result !== '*' ? ` · ${result.result}` : '');
    renderArenaPosition();
    showArenaResultModal(white, black, result);
  } catch (error) {
    arenaLastResult = `Trận lỗi: ${String(error.message || error).slice(0, 180)}`; arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaAbortController = null;
    if (currentView === 'arena') renderArenaPosition();
  }
}
function readArenaOptions() {
  const search = resolveArenaSearchSettings({
    depth: Number($('#arenaDepth')?.value || 32),
    skill: Number($('#arenaSkill')?.value || 20),
    strengthMode: $('#arenaEngineMode')?.value === 'elo' ? 'elo' : 'max',
    elo: Number($('#arenaEngineElo')?.value || 2800),
  });
  return { ...search, delayMs: Number($('#arenaDelay')?.value ?? 100), plyLimit: Number($('#arenaPlyLimit')?.value || 180),
    format: isValidArenaFormat($('#arenaFormat')?.value) ? $('#arenaFormat').value : 'roundrobin',
    gamesPerPair: Math.max(1, Number($('#arenaGamesPerPair')?.value || 2)),
    pairedOpenings: $('#arenaPairedOpenings') ? $('#arenaPairedOpenings').checked : false,
    adjudicate: $('#arenaAdjudicate') ? $('#arenaAdjudicate').checked : true };
}
function stopArenaMatch() {
  if (!arenaRunning) return;
  arenaStopRequested = true; arenaPaused = false;
  arenaAbortController?.abort();
  if (pendingEngineRequest && engineWorker) { try { engineWorker.postMessage('stop'); } catch {} }
  legacyArenaEngine?.stop();
  if ($('#arenaStatus')) $('#arenaStatus').textContent = 'Đang dừng sau khi yêu cầu hiện tại kết thúc…';
}
function renderArenaStandingsMarkup(ranked = arenaLiveRanked) {
  if (!ranked.length) return '<div class="arena-standings-empty">Bảng xếp hạng sẽ hiện ở đây khi giải bắt đầu.</div>';
  const medals = ['🥇', '🥈', '🥉'];
  const rows = ranked.map((row, index) => `<tr class="${index === 0 && row.games ? 'is-leader' : ''}"><td class="rk">${medals[index] || row.rank}</td><td class="nm">${esc(String(row.name).replace(' · bot phong cách', ''))}</td><td>${row.games}</td><td><b>${formatPoints(row.points)}</b></td><td class="wdl">${row.wins}/${row.draws}/${row.losses}</td><td>${row.games ? row.scorePct.toFixed(0) : '–'}%</td><td class="elo ${row.relElo > 0 ? 'up' : row.relElo < 0 ? 'down' : ''}">${row.games ? (row.relElo > 0 ? '+' : '') + row.relElo : '–'}</td></tr>`).join('');
  const cross = arenaCrosstable(ranked);
  const crossHead = ranked.map((row, index) => `<th title="${esc(row.name)}">${index + 1}</th>`).join('');
  const crossRows = cross.map((row, index) => `<tr><th class="nm">${index + 1}. ${esc(String(row.name).replace(' · bot phong cách', '').slice(0, 14))}</th>${row.cells.map(cell => `<td class="x-${cell.tone}">${esc(cell.text)}</td>`).join('')}</tr>`).join('');
  return `<div class="arena-table-scroll"><table class="arena-standings-table"><thead><tr><th>#</th><th>Bot</th><th>Ván</th><th>Điểm</th><th>T/H/B</th><th>%</th><th title="Elo tương đối trong giải này, không phải Elo benchmark">Elo±</th></tr></thead><tbody>${rows}</tbody></table></div>
  <details class="arena-crosstable-wrap"><summary>Bảng đối đầu</summary><div class="arena-table-scroll"><table class="arena-crosstable"><thead><tr><th></th>${crossHead}</tr></thead><tbody>${crossRows}</tbody></table></div></details>`;
}
function syncArenaStandings() {
  const el = $('#arenaStandings');
  if (el) el.innerHTML = renderArenaStandingsMarkup();
  const bar = $('#arenaProgress');
  if (bar) {
    if (!arenaProgress) { bar.hidden = true; return; }
    const { done, total, startedAt } = arenaProgress;
    const elapsed = Date.now() - startedAt;
    const eta = estimateArenaRemaining(elapsed, done, total);
    bar.hidden = false;
    bar.innerHTML = `<div class="arena-progress-track"><i style="width:${Math.min(100, total ? (done / total) * 100 : 0).toFixed(1)}%"></i></div><small>${done}/${total} ván · ${formatArenaDuration(elapsed)} đã chạy${eta ? ` · còn khoảng ${formatArenaDuration(eta)}` : ''}</small>`;
  }
}
async function runArenaLeague() {
  if (arenaRunning) return;
  if (botThinking || (engineSearchActive && !pendingEngineRequest)) { toast('Hãy đợi lượt Stockfish hiện tại kết thúc.'); return; }
  const options = readArenaOptions();
  const format = options.format;
  const selected = [...arenaSelectedLeague].map(arenaPlayer).filter(Boolean);
  const minPlayers = 2;
  if (selected.length < minPlayers) { toast('Hãy chọn ít nhất hai AI tham gia giải.'); return; }
  if (selected.length > ARENA_MAX_PLAYERS) { toast(`Để giảm tải thiết bị, mỗi giải tối đa ${ARENA_MAX_PLAYERS} bot. Bỏ chọn bớt rồi thử lại.`); return; }
  if (format === 'match' && selected.length > 2) toast('Chế độ 1-1 chỉ dùng hai bot đầu tiên trong danh sách chọn.');
  arenaRunning = true; arenaStopRequested = false; arenaPaused = false; arenaAbortController = new AbortController();
  arenaPgnArchive = []; arenaLastPgnResult = '*'; arenaFallbackMoves = new Map();
  const seed = (Date.now() % 2147483000) + 1;
  const field = format === 'match' ? selected.slice(0, 2) : selected;
  const standings = createArenaStandings(field);
  const byId = new Map(field.map(player => [player.id, player]));
  const totalGames = countArenaGames(format, field.length, options.gamesPerPair);
  arenaProgress = { done: 0, total: totalGames, startedAt: Date.now() };
  arenaLiveRanked = rankArenaStandings(standings);
  const formatLabel = ARENA_FORMATS.find(item => item.id === format)?.label || format;
  arenaTournamentSummary = `${formatLabel}: ${field.length} bot · ${totalGames} ván${options.pairedOpenings ? ' · khai cuộc ghép cặp đổi màu' : ' · dùng kho 4 khai cuộc riêng mỗi bot'}.`;
  renderArenaPosition(); syncArenaStandings(); syncArenaPauseButton();
  let complete = 0;
  let knockoutChampion = null;
  const playOne = async (whiteId, blackId, opening, round) => {
    const white = byId.get(whiteId), black = byId.get(blackId);
    arenaGameCounter += 1;
    const result = await playArenaCore(white, black, { ...options, openingSan: opening?.san || [], meta: { round, opening: opening?.name || '' } });
    if (result.stopped) return null;
    recordArenaResult(standings, whiteId, blackId, result.result);
    complete += 1;
    arenaProgress = { ...arenaProgress, done: complete, total: Math.max(totalGames, complete) };
    arenaLiveRanked = rankArenaStandings(standings);
    for (const [id, count] of arenaFallbackMoves) { const row = standings.get(id); if (row) row.fallbackMoves = count; }
    arenaTournamentSummary = `Ván ${complete}/${arenaProgress.total}: ${result.white} ${result.result} ${result.black} · ${result.reason}`;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    syncArenaStandings();
    renderArenaPosition();
    await arenaDelay(180);
    return result;
  };
  try {
    if (format === 'knockout') {
      let alive = field.map(player => player.id);
      const seedOrder = new Map(alive.map((id, index) => [id, index]));
      let roundNo = 0;
      while (alive.length > 1 && !arenaStopRequested) {
        roundNo += 1;
        const { pairs, bye } = knockoutRound(alive);
        const next = bye ? [bye] : [];
        let pairIndex = 0;
        for (const [a, b] of pairs) {
          if (arenaStopRequested) break;
          pairIndex += 1;
          const [opening] = pickArenaOpenings(options.pairedOpenings ? OPENINGS : [], 1, { seed: seed + roundNo * 101 + pairIndex });
          let scoreA = 0, scoreB = 0;
          for (let k = 0; k < 2 && !arenaStopRequested; k += 1) {
            const whiteId = k === 0 ? a : b, blackId = k === 0 ? b : a;
            const result = await playOne(whiteId, blackId, opening, `${roundNo}.${pairIndex}`);
            if (!result) break;
            const points = result.result === '1-0' ? [1, 0] : result.result === '0-1' ? [0, 1] : [0.5, 0.5];
            if (k === 0) { scoreA += points[0]; scoreB += points[1]; } else { scoreA += points[1]; scoreB += points[0]; }
          }
          let winner = knockoutTieWinner(scoreA, scoreB, a, b);
          let extra = 0;
          while (!winner && !arenaStopRequested && extra < 4) {
            extra += 1;
            const whiteId = extra % 2 ? a : b, blackId = extra % 2 ? b : a;
            const result = await playOne(whiteId, blackId, null, `${roundNo}.${pairIndex}+${extra}`);
            if (!result) break;
            const decisive = result.result === '1-0' ? whiteId : result.result === '0-1' ? blackId : null;
            if (decisive) winner = decisive;
          }
          next.push(winner || (seedOrder.get(a) <= seedOrder.get(b) ? a : b)); // still level: higher seed advances
        }
        alive = next.sort((x, y) => seedOrder.get(x) - seedOrder.get(y));
      }
      if (!arenaStopRequested && alive.length === 1) knockoutChampion = alive[0];
    } else {
      const openings = options.pairedOpenings ? pickArenaOpenings(OPENINGS, Math.max(1, Math.ceil(totalGames / 2)), { seed }) : null;
      const schedule = buildArenaSchedule(format, field.map(player => player.id), { gamesPerPair: options.gamesPerPair, openings, pairedOpenings: options.pairedOpenings });
      for (const game of schedule) {
        if (arenaStopRequested) break;
        const result = await playOne(game.whiteId, game.blackId, game.opening, game.round);
        if (!result) break;
      }
    }
    let finalRanked = rankArenaStandings(standings);
    if (knockoutChampion) finalRanked = [finalRanked.find(row => row.id === knockoutChampion), ...finalRanked.filter(row => row.id !== knockoutChampion)].map((row, index) => ({ ...row, rank: index + 1 }));
    arenaLiveRanked = finalRanked;
    if (complete > 0) {
      arenaCupStandings = finalRanked.slice(0, ARENA_MAX_PLAYERS).map(row => ({ id: row.id, name: row.name, points: row.points, wins: row.wins, draws: row.draws, losses: row.losses, games: row.games, relElo: row.relElo, rank: row.rank, format, playedAt: Date.now() }));
      try { localStorage.setItem('vila.chess.arena-cup-standings.v1', JSON.stringify(arenaCupStandings)); } catch {}
      recordDailyEvent('complete_arena');
      syncArenaCupPodium();
    }
    const champion = finalRanked[0];
    const table = finalRanked.map((x, i) => `${['🥇', '🥈', '🥉'][i] || `${i + 1}.`} ${String(x.name).replace(' · bot phong cách', '')}: ${formatPoints(x.points)} điểm · ${x.wins} thắng / ${x.draws} hòa / ${x.losses} thua · Elo± ${x.relElo > 0 ? '+' : ''}${x.relElo}${x.fallbackMoves ? ` · ${x.fallbackMoves} nước dự phòng` : ''}`).join('\n');
    arenaTournamentSummary = `${arenaStopRequested ? 'GIẢI ĐÃ DỪNG' : '🏆 NHÀ VÔ ĐỊCH CÚP VILA'} (${complete} ván · ${formatArenaDuration(Date.now() - arenaProgress.startedAt)})${complete && champion ? `\n🥇 ${String(champion.name).replace(' · bot phong cách', '')} · ${formatPoints(champion.points)} điểm` : ''}\n${table}\nElo± là Elo tương đối trong giải này, không phải Elo benchmark.`;
    arenaLastResult = arenaStopRequested ? 'Giải đã dừng theo yêu cầu.' : `Giải hoàn tất · ${complete} ván.`;
  } catch (error) {
    arenaLastResult = `Giải gặp lỗi: ${String(error.message || error).slice(0, 180)}`;
    arenaTournamentSummary = arenaLastResult;
  } finally {
    arenaRunning = false; arenaStopRequested = false; arenaPaused = false; arenaAbortController = null; arenaProgress = null;
    if ($('#arenaLeagueSummary')) $('#arenaLeagueSummary').textContent = arenaTournamentSummary;
    if (currentView === 'arena') { renderArenaPosition(); syncArenaStandings(); syncArenaPauseButton(); }
  }
}
function pgnEscape(value) { return String(value || '').replace(/[\\"]+/g, '').slice(0, 120); }
function archiveArenaGame(white, black, result, reason) {
  const outcome = result || '*';
  const moves = (arenaGame.pgn() || '').trim();
  const gamePgn = moves && /(?:1-0|0-1|1\/2-1\/2|\*)$/.test(moves) ? moves : `${moves}${moves ? ' ' : ''}${outcome}`;
  const meta = arenaGameMeta || {};
  const lines = [
    '[Event "Cờ Vua AI Arena"]',
    '[Site "Cờ Vua"]',
    `[Date "${new Date().toISOString().slice(0, 10).replace(/-/g, '.')}"]`,
    `[Round "${pgnEscape(meta.round || arenaGameCounter || '-')}"]`,
    `[White "${pgnEscape(white?.name || 'White')}"]`,
    `[Black "${pgnEscape(black?.name || 'Black')}"]`,
    `[Result "${outcome}"]`,
    ...(meta.opening ? [`[Opening "${pgnEscape(meta.opening)}"]`] : []),
    `[Annotator "${pgnEscape(reason || 'AI Arena')}"]`
  ];
  arenaPgnArchive.push(`${lines.join('\n')}\n\n${gamePgn}`);
}
function downloadArenaPgn() {
  const pgn = arenaPgnArchive.length ? arenaPgnArchive.join('\n\n') : (() => {
    const headers = `[Event "Cờ Vua AI Arena"]\n[Site "Cờ Vua"]\n[White "${pgnEscape(arenaCurrentPlayers.w?.name || 'White')}"]\n[Black "${pgnEscape(arenaCurrentPlayers.b?.name || 'Black')}"]\n[Result "${arenaLastPgnResult}"]\n[Annotator "${pgnEscape(arenaLastResult || 'AI Arena')}"]`;
    return `${headers}\n\n${arenaGame.pgn() || '*'}`;
  })();
  downloadTextFile(pgn, 'covua-vila-ai-arena.pgn', 'application/x-chess-pgn;charset=utf-8');
}



function renderLeaderboardView() {
  const profile = socialState.user ? { elo: Number(socialState.user.elo) || 500, games: Number(socialState.user.games) || 0, wins: Number(socialState.user.wins) || 0, draws: Number(socialState.user.draws) || 0, losses: Number(socialState.user.losses) || 0, lastChange: 0 } : { elo: null, games: 0, wins: 0, draws: 0, losses: 0, lastChange: 0 }; const history = [];
  const rows = history.map((item, index) => `<tr><td>${history.length - index}</td><td>${esc(new Date(item.date).toLocaleDateString())}</td><td>${esc(item.opponent || 'Bot')}</td><td>${esc(item.title || item.result)}</td><td class="rating-change ${item.change > 0 ? 'positive' : item.change < 0 ? 'negative' : ''}">${item.change > 0 ? '+' : ''}${Number(item.change || 0)}</td><td>${Number(item.elo || 1200)}</td></tr>`).join('');
  return `<section class="content-page leaderboard-page"><div class="page-intro"><div class="eyebrow">HỒ SƠ CỜ VUA</div><h1>Bảng xếp hạng</h1><p>Elo xếp hạng chỉ đến từ các ván online đã được máy chủ xác minh. Trận đấu với bot dùng để luyện tập, không cộng hoặc trừ Elo.</p></div><section class="panel server-top100-panel"><div class="panel-heading"><div><small class="eyebrow">CỜ VUA COMMUNITY</small><h2>Top 100 người chơi</h2></div><button class="secondary-btn" id="refreshTop100" type="button">↻ Làm mới</button></div><div id="serverTop100Status" class="field-hint">Đang tải bảng xếp hạng từ máy chủ…</div><div id="serverTop100Rows" class="server-top100-list"><div class="empty-state">Đang tải dữ liệu…</div></div></section><div class="rating-summary-grid"><article class="panel rating-hero"><small>ELO XẾP HẠNG ONLINE</small><strong>${profile.elo ?? '—'}</strong><span>Chỉ đổi sau trận online được máy chủ xác minh</span></article><article class="panel rating-stat"><small>Ván đã tính</small><strong>${profile.games}</strong></article><article class="panel rating-stat"><small>Thắng / Hòa / Thua</small><strong>${profile.wins} / ${profile.draws} / ${profile.losses}</strong></article><article class="panel rating-stat"><small>Tỉ lệ thắng</small><strong>${profile.games ? Math.round(profile.wins / profile.games * 100) : 0}%</strong></article></div><section class="panel leaderboard-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ XẾP HẠNG</small><h2>Kết quả gần đây</h2></div><span class="context-icon">♜</span></div>${rows ? `<div class="leaderboard-table-wrap"><table class="leaderboard-table"><thead><tr><th>#</th><th>Ngày</th><th>Đối thủ</th><th>Kết quả</th><th>Δ Elo</th><th>Elo</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="empty-state">Chưa có lịch sử Elo online. Các ván với bot chỉ dùng để luyện tập và không cộng hoặc trừ điểm.</div>'}<div class="field-hint">Mức Elo khởi đầu là tự đánh giá (200 / 500 / 1000 / 1500). Chỉ trận xếp hạng online do máy chủ xác minh mới thay đổi Elo; đấu với bot không tính Elo.</div></section></section>`;
}

function renderTop100Rows(users = []) {
  if (!users.length) return '<div class="empty-state">Chưa có tài khoản cộng đồng nào. Đăng ký ở mục Bạn bè để xuất hiện trong bảng xếp hạng.</div>';
  return users.map(user => `<article class="top100-row"><span class="top100-rank rank-${Number(user.rank) <= 3 ? Number(user.rank) : 'other'}">${Number(user.rank) <= 3 ? ['🥇','🥈','🥉'][Number(user.rank)-1] : `#${Number(user.rank)}`}</span><button type="button" class="top100-player-open" data-open-profile="${esc(user.username)}"><span class="top100-avatar">${esc((user.displayName || user.username || '?').slice(0,1).toUpperCase())}</span><span class="top100-player"><b>${esc(user.displayName || user.username)}${tierBadge(user)}</b><small>@${esc(user.username)} · ${user.role === 'admin' ? '🛡 Admin' : (user.online ? '🟢 Đang hoạt động' : `${Number(user.games || 0)} ván đã ghi nhận`)}</small></span></button><strong class="top100-elo">${Number(user.elo || 500)} <small>Elo</small></strong></article>`).join('');
}
async function loadTop100() {
  const rows = $('#serverTop100Rows'), status = $('#serverTop100Status');
  if (!rows) return;
  if (status) status.textContent = 'Đang tải dữ liệu từ máy chủ…';
  try {
    const data = await socialApi('/leaderboard?limit=100');
    socialState.leaderboard = Array.isArray(data.users) ? data.users : [];
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = renderTop100Rows(socialState.leaderboard);
    wirePlayerProfileButtons(rows);
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = `${Number(data.totalPlayers || 0)} tài khoản trên máy chủ · Cập nhật ${new Date(data.generatedAt || Date.now()).toLocaleTimeString()}. Chạm tên người chơi để mở hồ sơ. Elo chỉ đổi sau trận xếp hạng online được máy chủ xác minh.`;
  } catch (error) {
    if ($('#serverTop100Rows')) $('#serverTop100Rows').innerHTML = `<div class="empty-state">${esc(error.message || 'Chưa kết nối được máy chủ.')}</div>`;
    if ($('#serverTop100Status')) $('#serverTop100Status').textContent = 'Không thể tải Top 100. Hãy kiểm tra địa chỉ backend trong Cài đặt và bảo đảm server đang chạy.';
  }
}
function wireLeaderboardActions() { $('#refreshTop100')?.addEventListener('click', loadTop100); loadTop100(); wirePlayerProfileButtons(); }

function renderFriendsView() {
  const user = socialState.user;
  const authPanel = !user ? `<div class="social-auth-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN CỘNG ĐỒNG</small><h2>Đăng nhập VILA</h2></div><span class="context-icon">♙</span></div><form id="socialLoginForm"><label class="field-label" for="socialLoginName">Tên tài khoản</label><input class="field" id="socialLoginName" name="username" autocomplete="username" autocapitalize="none" maxlength="254" required placeholder="Tên tài khoản"/><label class="field-label" for="socialLoginPassword">Mật khẩu</label><input class="field" id="socialLoginPassword" name="password" autocomplete="current-password" type="password" maxlength="256" required placeholder="Mật khẩu tài khoản VILA"/><button class="primary-btn full-width social-submit" type="submit">Đăng nhập</button></form><p class="field-hint">Không cần Google, GitHub hoặc Firebase. Một tài khoản VILA dùng cho hồ sơ, bạn bè và ghép trận online.</p></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">BẮT ĐẦU CÙNG CỘNG ĐỒNG</small><h2>Tạo tài khoản</h2></div><span class="context-icon">✦</span></div><form id="socialRegisterForm"><label class="field-label" for="socialRegisterDisplay">Tên tài khoản</label><input class="field" id="socialRegisterDisplay" name="username" autocomplete="username" autocapitalize="none" minlength="3" maxlength="24" pattern="[A-Za-z0-9_.\-]{3,24}" required placeholder="3–24 ký tự: chữ, số, . _ -"/><label class="field-label" for="socialRegisterPassword">Mật khẩu</label><input class="field" id="socialRegisterPassword" name="password" autocomplete="new-password" type="password" minlength="8" maxlength="256" required placeholder="Tối thiểu 8 ký tự"/><label class="field-label" for="socialRegisterElo">Elo khởi đầu · tự đánh giá</label><select class="field" id="socialRegisterElo" name="initialElo"><option value="200">🌱 Mới bắt đầu · 200</option><option value="500" selected>♟ Cơ bản · 500</option><option value="1000">📘 Trung cấp · 1000</option><option value="1500">🔥 Khá · 1500</option></select><button class="primary-btn full-width social-submit" type="submit">Tạo tài khoản</button></form><p class="field-hint">Avatar được chọn ngẫu nhiên. Elo khởi đầu chỉ là mốc ban đầu; Elo xếp hạng thay đổi theo ván online đã được máy chủ xác minh. Ván bot không tính Elo.</p></section></div>` : `<section class="panel social-profile-panel"><div class="social-profile-main"><div class="social-big-avatar" style="${avatarStyle(user)}">${avatarEmoji(user)}</div><div class="social-profile-info"><small class="eyebrow">HỒ SƠ CỜ VUA</small><h2>${esc(user.displayName || user.username)}</h2><p>@${esc(user.username)} · ${user.role === 'admin' ? 'Quản trị viên' : 'Người chơi'} · ${Number(user.elo || 500)} Elo</p></div><button class="secondary-btn" type="button" id="socialLogout">Đăng xuất</button></div><div class="profile-sync-row"><button type="button" class="primary-btn" id="triggerCloudSyncBtn">☁ Đồng bộ lịch sử (${readSavedGames().length} ván)</button></div><form id="socialProfileForm" class="social-profile-edit"><div><label class="field-label" for="socialProfileDisplay">Tên hiển thị</label><input class="field" id="socialProfileDisplay" maxlength="40" minlength="2" required value="${esc(user.displayName || user.username)}"/></div><div><label class="field-label" for="socialProfileBio">Giới thiệu</label><input class="field" id="socialProfileBio" maxlength="180" value="${esc(user.bio || '')}" placeholder="Giới thiệu ngắn về bạn"/></div><button class="secondary-btn" type="submit">Lưu hồ sơ</button></form></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI CỘNG ĐỒNG</small><h2>Tìm bạn bè</h2></div><span class="context-icon">⌕</span></div><form id="socialSearchForm" class="social-search-row"><input class="field" id="socialSearchName" minlength="2" maxlength="30" required placeholder="Tìm theo tên hoặc username"/><button class="primary-btn" type="submit">Tìm</button></form><div id="socialSearchResults" class="social-person-list"><div class="empty-state">Nhập tên người chơi để tìm bạn.</div></div></section><div class="social-friends-grid"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">DANH SÁCH CỦA BẠN</small><h2>Bạn bè <span id="socialFriendCount"></span></h2></div><button class="secondary-btn" id="refreshFriends" type="button">↻</button></div><div id="socialFriendsList" class="social-person-list"><div class="empty-state">Đang tải bạn bè…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỜI MỜI</small><h2>Lời mời kết bạn</h2></div></div><h3>Đang chờ bạn phản hồi</h3><div id="socialIncomingList" class="social-person-list"></div><h3 class="social-subheading">Đã gửi</h3><div id="socialOutgoingList" class="social-person-list"></div></section></div>`;
  return `<section class="content-page social-page"><div class="page-intro"><div class="eyebrow">CỜ VUA COMMUNITY</div><h1>Bạn bè & tài khoản</h1><p>Đăng nhập để tạo hồ sơ cộng đồng, kết nối người chơi và chuẩn bị cho thi đấu xếp hạng trực tuyến. Tài khoản và quan hệ bạn bè được lưu trên máy chủ.</p></div>${authPanel}<p class="field-hint social-status" id="socialPageStatus">${socialState.token ? 'Đã lưu phiên đăng nhập trên thiết bị này.' : 'Tạo tài khoản để thêm bạn bè và xuất hiện trong Top 100.'}</p></section>`;
}
function wireFriendRowActions(root = document) {
  root.querySelectorAll('[data-accept-friend]').forEach(button => {
    if (button.dataset.friendActionBound === '1') return;
    button.dataset.friendActionBound = '1';
    button.addEventListener('click', async () => {
      button.disabled = true;
      try { await socialApi(`/friends/${encodeURIComponent(button.dataset.acceptFriend)}/accept`, { method: 'POST', body: '{}' }); toast('Đã chấp nhận lời mời.', 'success'); await loadFriendsSnapshot(); }
      catch (error) { socialHandleError(error); }
      finally { button.disabled = false; }
    });
  });
  root.querySelectorAll('[data-remove-friend]').forEach(button => {
    if (button.dataset.friendActionBound === '1') return;
    button.dataset.friendActionBound = '1';
    button.addEventListener('click', async () => {
      const friendId = button.dataset.removeFriend;
      if (!confirm('Xóa bạn bè hoặc hủy lời mời này?')) return;
      button.disabled = true;
      try { await socialApi(`/friends/${encodeURIComponent(friendId)}`, { method: 'DELETE' }); await loadFriendsSnapshot(); }
      catch (error) { socialHandleError(error); }
      finally { button.disabled = false; }
    });
  });
  root.querySelectorAll('[data-add-friend]').forEach(button => {
    if (button.dataset.friendActionBound === '1') return;
    button.dataset.friendActionBound = '1';
    button.addEventListener('click', async () => {
      button.disabled = true;
      try { const data = await socialApi('/friends/request', { method: 'POST', body: JSON.stringify({ username: button.dataset.addFriend }) }); toast(data.message || 'Đã gửi lời mời.', 'success'); button.textContent = '✓'; await loadFriendsSnapshot(); }
      catch (error) { socialHandleError(error); button.disabled = false; }
    });
  });
  root.querySelectorAll('[data-message-user]').forEach(button => {
    if (button.dataset.friendActionBound === '1') return;
    button.dataset.friendActionBound = '1';
    button.addEventListener('click', () => {
      activeChatUserId = button.dataset.messageUser;
      const found = socialState.friends.find(user => user.id === activeChatUserId);
      activeChatUser = found || null;
      setView('chat');
    });
  });
}

async function loadFriendsSnapshot() {
  if (!socialState.token || currentView !== 'friends') return;
  try {
    const data = await socialApi('/friends');
    socialState.friends = data.friends || []; socialState.incoming = data.incoming || []; socialState.outgoing = data.outgoing || [];
    captureIncomingFriendNotifications(socialState.incoming);
    const friends = $('#socialFriendsList'), incoming = $('#socialIncomingList'), outgoing = $('#socialOutgoingList');
    if (friends) friends.innerHTML = socialState.friends.length ? socialState.friends.map(u => `<article class="social-person-row"><button type="button" class="social-person-open" data-open-profile="${esc(u.username)}"><span class="social-person-avatar" style="${avatarStyle(u)}">${avatarEmoji(u)}</span><span class="social-person-meta"><b>${esc(u.displayName)}${tierBadge(u)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : 'Ngoại tuyến'} · ${Number(u.elo || 500)} Elo</small></span></button><button type="button" class="tiny-btn" data-message-user="${esc(u.id)}" aria-label="Nhắn tin">✉</button><button class="tiny-btn" data-remove-friend="${esc(u.id)}" aria-label="Xóa bạn">×</button></article>`).join('') : '<div class="empty-state">Chưa có bạn bè. Tìm username phía trên để gửi lời mời.</div>';
    if (incoming) incoming.innerHTML = socialState.incoming.length ? socialState.incoming.map(r => `<article class="social-person-row"><span class="social-person-avatar" style="${avatarStyle(r.user)}">${avatarEmoji(r.user)}</span><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} muốn kết bạn</small></span><button class="tiny-btn social-accept" data-accept-friend="${esc(r.id)}" aria-label="Chấp nhận">✓</button></article>`).join('') : '<div class="small-empty">Không có lời mời mới.</div>';
    if (outgoing) outgoing.innerHTML = socialState.outgoing.length ? socialState.outgoing.map(r => `<article class="social-person-row"><span class="social-person-meta"><b>${esc(r.user.displayName)}</b><small>@${esc(r.user.username)} · Đang chờ</small></span><button class="tiny-btn" data-remove-friend="${esc(r.user.id)}" aria-label="Hủy lời mời">×</button></article>`).join('') : '<div class="small-empty">Chưa gửi lời mời nào.</div>';
    if ($('#socialFriendCount')) $('#socialFriendCount').textContent = `(${socialState.friends.length})`;
    wirePlayerProfileButtons(friends || document);
    wireFriendRowActions(document);
  } catch (error) { socialHandleError(error); }
}
// ---- Chess.com-style player profile (avatar corner → this page) ----
const PROFILE_RATING_CARDS = [
  { key: 'bullet', label: 'Bullet', icon: '⚡' },
  { key: 'blitz', label: 'Blitz', icon: '🔥' },
  { key: 'rapid', label: 'Rapid', icon: '⏱' },
  { key: 'daily', label: 'Cờ ngày', icon: '☀' }
];
function profileJoinedLabel(iso) {
  const time = Date.parse(iso || '');
  return Number.isFinite(time) ? new Date(time).toLocaleDateString('vi-VN', { month: 'long', year: 'numeric' }) : '';
}
function profileResultBar(wins, draws, losses) {
  const total = Math.max(1, wins + draws + losses);
  const pct = value => ((value / total) * 100).toFixed(1);
  return `<div class="profile-wdl" role="img" aria-label="${wins} thắng, ${draws} hòa, ${losses} thua"><span class="is-win" style="width:${pct(wins)}%"></span><span class="is-draw" style="width:${pct(draws)}%"></span><span class="is-loss" style="width:${pct(losses)}%"></span></div><div class="profile-wdl-legend"><span><i class="is-win"></i>Thắng <b>${wins}</b></span><span><i class="is-draw"></i>Hòa <b>${draws}</b></span><span><i class="is-loss"></i>Thua <b>${losses}</b></span></div>`;
}
let profileTargetUser = null;
let activeChatUserId = '';
let activeChatUser = null;
let chatConversations = [];
let chatLoadEpoch = 0;
let chatRefreshTimer = null;
let chatRefreshBusy = false;
let loadedChatRoomUserId = '';

/** Public tier badge: ADMIN / PREMIUM / PRO. Free players get no badge. Safe for innerHTML (fixed strings only). */
function tierOfUser(user) {
  if (!user || typeof user !== 'object') return 'free';
  if (user.role === 'admin') return 'admin';
  const tier = String(user.tier || user.entitlement?.plan || 'free');
  return tier === 'premium' || tier === 'pro' ? tier : 'free';
}
function tierBadge(user) {
  const tier = tierOfUser(user);
  if (tier === 'free') return '';
  const label = tier === 'admin' ? 'ADMIN' : tier === 'premium' ? 'PREMIUM' : 'PRO';
  const icon = tier === 'admin' ? '🛡' : tier === 'premium' ? '✦' : '♛';
  return `<span class="tier-badge tier-${tier}" title="${label}"><i aria-hidden="true">${icon}</i>${label}</span>`;
}
let profileOpenBusy = false;
async function openPlayerProfile(username) {
  const handle = String(username || '').trim();
  if (!handle) return;
  if (!socialState.token) { showAccountGate('login', 'Đăng nhập để xem hồ sơ cộng đồng.'); return; }
  if (profileOpenBusy) return;
  profileOpenBusy = true;
  try {
    const data = await socialApi(`/users/${encodeURIComponent(username)}`);
    const target = data?.user;
    if (!target?.id) throw new Error('Máy chủ không trả hồ sơ người chơi hợp lệ.');
    profileTargetUser = target.id === socialState.user?.id ? null : target;
    setView('profile');
  } catch (error) { socialHandleError(error); }
  finally { profileOpenBusy = false; }
}
// One delegated listener covers every profile link, including rows re-rendered later (friends, search, top 100, chat, admin).
// Per-element listeners were fragile: any innerHTML refresh without a re-wire left the row untappable on mobile.
document.addEventListener('click', event => {
  const target = event.target instanceof Element ? event.target.closest('[data-open-profile]') : null;
  if (!target || target.disabled) return;
  event.preventDefault();
  void openPlayerProfile(target.dataset.openProfile);
});
function wirePlayerProfileButtons(root = document) {
  // Kept for existing callers: marks links as ready/accessible; the delegated listener above does the opening.
  root.querySelectorAll('[data-open-profile]').forEach(button => {
    button.dataset.profileBound = '1';
    if (!button.hasAttribute('type') && button.tagName === 'BUTTON') button.setAttribute('type', 'button');
  });
}
function renderProfileView() {
  const viewed = profileTargetUser && profileTargetUser.id !== socialState.user?.id ? profileTargetUser : socialState.user;
  const user = viewed;
  const own = Boolean(user && socialState.user && user.id === socialState.user.id);
  const other = Boolean(user && !own);
  const guest = !user;
  const local = readRatingProfile();
  const saved = own ? readSavedGames().slice(0, 6) : [];
  const solved = own || guest ? Math.max(0, Number(puzzleState.solvedCount) || 0) : 0;
  const bestStreak = own || guest ? Math.max(0, Number(puzzleState.bestStreak) || 0) : 0;
  const rushBest = own || guest ? Math.max(0, Number(puzzleState.rushBest) || 0) : 0;
  const name = guest ? 'Khách ngoại tuyến' : String(user.displayName || user.username || 'Người chơi');
  const ratings = user?.ratingsByCategory || {};
  const wins = guest ? local.wins : Number(user.wins) || 0;
  const draws = guest ? local.draws : Number(user.draws) || 0;
  const losses = guest ? local.losses : Number(user.losses) || 0;
  const games = guest ? local.games : Number(user.games) || wins + draws + losses;
  const winRate = games ? Math.round((wins / games) * 100) : 0;
  const joined = guest ? '' : profileJoinedLabel(user.createdAt);
  const avatar = guest ? '<span class="profile-avatar" aria-hidden="true">♙</span>' : `<span class="profile-avatar" style="${avatarStyle(user)}" aria-hidden="true">${avatarEmoji(user)}</span>`;
  const ratingCards = PROFILE_RATING_CARDS.map(card => {
    const value = guest ? null : Number(ratings[card.key]) || Number(user.elo) || null;
    return `<article class="profile-rating-card"><span class="profile-rating-icon" aria-hidden="true">${card.icon}</span><div><small>${card.label}</small><b>${value ?? '—'}</b><em>${guest ? 'Đăng nhập để có Elo online' : 'Elo xếp hạng online'}</em></div></article>`;
  }).join('') + (own || guest ? `<article class="profile-rating-card"><span class="profile-rating-icon" aria-hidden="true">🧩</span><div><small>Câu đố</small><b>${solved}</b><em>câu đã giải</em></div></article>` : '');
  const gameRows = own && saved.length ? saved.map(record => {
    const date = Number.isFinite(Date.parse(record.date)) ? new Date(record.date).toLocaleDateString('vi-VN') : '';
    const token = String(record.resultToken || '');
    return `<article class="profile-game-row"><span class="profile-game-result ${token === '1/2-1/2' ? 'draw' : ''}">${esc(token === '1/2-1/2' ? '½' : token)}</span><div><b>${esc(record.title || 'Ván đã lưu')}</b><small>${esc(record.opponent || 'Đối thủ')} · ${Number(record.plies) || 0} nước · ${esc(date)}</small></div><button type="button" class="tiny-btn" data-profile-review="${esc(record.id)}">Xem lại</button></article>`;
  }).join('') : own ? '<div class="empty-state">Chưa có ván nào được lưu trên thiết bị.</div>' : other ? '<div class="empty-state">Hồ sơ công khai hiển thị thành tích tổng hợp; lịch sử ván riêng tư không được công khai.</div>' : '<div class="empty-state">Chơi một ván bot để xem lịch sử huấn luyện. Ván bot không cộng hoặc trừ Elo.</div>';
  const actions = guest
    ? '<button type="button" class="primary-btn" data-profile-go="friends">Đăng nhập / tạo tài khoản</button>'
    : own
      ? '<button type="button" class="primary-btn" data-profile-go="ranked">⚔ Đấu xếp hạng</button><button type="button" class="secondary-btn" data-profile-go="friends">Bạn bè</button><button type="button" class="secondary-btn" data-profile-go="chat">Tin nhắn riêng</button><button type="button" class="secondary-btn" data-profile-go="settings">Cài đặt tài khoản</button>'
      : `<button type="button" class="primary-btn" data-profile-message="${esc(user.id)}">✉ Nhắn tin riêng</button><button type="button" class="secondary-btn" data-profile-add-friend="${esc(user.username)}">＋ Kết bạn</button><button type="button" class="danger-btn" data-profile-report="${esc(user.id)}">⚑ Báo cáo gian lận</button><button type="button" class="secondary-btn" data-profile-go="friends">Quay lại cộng đồng</button>`;
  return `<section class="content-page profile-page ${other ? 'is-public-profile' : ''}">
    <div class="profile-cover"><span class="profile-cover-mark">♞</span><span class="profile-cover-copy">VILA CHESS CLUB <small>${other ? 'HỒ SƠ NGƯỜI CHƠI' : own ? 'PLAYER PROFILE' : 'OFFLINE PROFILE'}</small></span></div>
    <header class="panel profile-hero">
      ${avatar}
      <div class="profile-hero-main">
        <div class="profile-name-row"><h1>${esc(name)}</h1>${!guest ? tierBadge(user) : ''}${!guest ? `<span class="profile-online ${user.online !== false ? 'is-online' : ''}">${user.online !== false ? 'Online' : 'Ngoại tuyến'}</span>` : ''}</div>
        <p class="profile-handle">${guest ? 'Đăng nhập để xem Elo xếp hạng online và lưu hồ sơ trên máy chủ' : `@${esc(user.username)}${joined ? ` · Tham gia ${esc(joined)}` : ''}`}</p>
        ${!guest && user.bio ? `<p class="profile-bio">${esc(user.bio)}</p>` : ''}
        <div class="profile-actions">${actions}</div>
      </div>
    </header>
    <section class="profile-rating-grid" aria-label="Điểm Elo xếp hạng online">${ratingCards}</section>
    <div class="profile-columns">
      <div class="profile-col">
        <section class="panel profile-section-card"><div class="panel-heading"><div><small class="eyebrow">THỐNG KÊ</small><h2>${guest ? 'Thành tích luyện tập' : 'Thành tích xếp hạng'}</h2></div></div>
          <div class="profile-stat-row"><div><small>Tổng ván</small><b>${games}</b></div><div><small>Tỉ lệ thắng</small><b>${winRate}%</b></div><div><small>Elo xếp hạng online</small><b>${guest ? '—' : Number(user.elo) || '—'}</b></div></div>
          ${profileResultBar(wins, draws, losses)}
          <p class="profile-note">${guest ? 'Đây là thống kê luyện tập trên thiết bị, không phải Elo xếp hạng.' : 'Elo chỉ thay đổi sau trận xếp hạng online được máy chủ xác minh. Các ván đấu với bot không tính Elo.'}</p>
        </section>
        ${own || guest ? `<section class="panel profile-section-card"><div class="panel-heading"><div><small class="eyebrow">CÂU ĐỐ</small><h2>Tactical Lab</h2></div><button type="button" class="tiny-btn" data-profile-go="puzzles">Luyện ngay</button></div><div class="profile-stat-row"><div><small>Đã giải</small><b>${solved}</b></div><div><small>Chuỗi tốt nhất</small><b>${bestStreak}</b></div><div><small>Kỷ lục Rush</small><b>${rushBest}</b></div></div></section>` : ''}
      </div>
      <div class="profile-col">
        <section class="panel profile-section-card"><div class="panel-heading"><div><small class="eyebrow">${other ? 'THÔNG TIN CÔNG KHAI' : 'VÁN GẦN ĐÂY'}</small><h2>${other ? 'Giới thiệu người chơi' : 'Lịch sử luyện tập'}</h2></div>${own ? '<button type="button" class="tiny-btn" data-profile-go="history">Tất cả</button>' : ''}</div><div class="profile-games">${other ? `<p class="profile-public-bio">${esc(user.bio || 'Người chơi chưa viết phần giới thiệu.')}</p><p class="profile-note">Đã chơi ${games} ván · ${wins} thắng · ${draws} hòa · ${losses} thua.</p>` : gameRows}</div></section>
        ${own ? `<section class="panel profile-section-card"><div class="panel-heading"><div><small class="eyebrow">BẠN BÈ</small><h2>Bạn bè <span id="profileFriendCount" class="small-counter"></span></h2></div><button type="button" class="tiny-btn" data-profile-go="friends">Quản lý</button></div><div id="profileFriends" class="profile-friends"><div class="small-empty">Đang tải…</div></div></section>` : other ? `<section class="panel profile-contact-panel"><div class="profile-contact-symbol">✉</div><div><h2>Kết nối với ${esc(user.displayName || user.username)}</h2><p>Bạn có thể trò chuyện riêng hoặc gửi lời mời kết bạn từ hồ sơ này.</p></div><button type="button" class="primary-btn" data-profile-message="${esc(user.id)}">Mở chat</button></section>` : ''}
      </div>
    </div>
  </section>`;
}

let profileLoadEpoch = 0;
function wireProfileActions() {
  $$('[data-profile-go]').forEach(button => button.addEventListener('click', () => { if (button.dataset.profileGo !== 'profile') profileTargetUser = null; setView(button.dataset.profileGo); }));
  $$('[data-profile-review]').forEach(button => button.addEventListener('click', () => {
    const record = readSavedGames().find(item => item.id === button.dataset.profileReview);
    if (record) restoreSavedGame(record, false);
  }));
  $$('[data-profile-message]').forEach(button => button.addEventListener('click', () => {
    activeChatUserId = button.dataset.profileMessage;
    activeChatUser = profileTargetUser;
    setView('chat');
  }));
  $$('[data-profile-add-friend]').forEach(button => button.addEventListener('click', async () => {
    button.disabled = true;
    try { const data = await socialApi('/friends/request', { method: 'POST', body: JSON.stringify({ username: button.dataset.profileAddFriend }) }); toast(data.message || 'Đã gửi lời mời kết bạn.', 'success'); button.textContent = '✓ Đã gửi lời mời'; }
    catch (error) { socialHandleError(error); button.disabled = false; }
  }));
  $$('[data-profile-report]').forEach(button => button.addEventListener('click', async () => {
    const choices = { '1': 'cheating', '2': 'abuse', '3': 'spam', '4': 'impersonation', '5': 'other' };
    const choice = prompt('Lý do báo cáo:\n1. Nghi dùng hack / engine\n2. Quấy rối\n3. Spam\n4. Giả mạo\n5. Khác', '1');
    if (choice == null) return;
    const reason = choices[String(choice).trim()];
    if (!reason) { toast('Hãy chọn từ 1 đến 5.'); return; }
    const details = prompt('Mô tả thêm (không bắt buộc):', '') || '';
    button.disabled = true;
    try { const data = await socialApi(`/users/${encodeURIComponent(button.dataset.profileReport)}/report`, { method: 'POST', body: JSON.stringify({ reason, details }) }); toast(data.message || 'Đã gửi báo cáo.', 'success'); button.textContent = '✓ Đã báo cáo'; }
    catch (error) { socialHandleError(error); button.disabled = false; }
  }));
  wirePlayerProfileButtons();
  if (!socialState.token || !socialState.user || (profileTargetUser && profileTargetUser.id !== socialState.user.id)) return;
  const epoch = ++profileLoadEpoch;
  const before = JSON.stringify([socialState.user.games, socialState.user.wins, socialState.user.draws, socialState.user.losses, socialState.user.ratingsByCategory, socialState.user.displayName, socialState.user.bio]);
  socialApi('/auth/me').then(data => {
    if (epoch !== profileLoadEpoch || currentView !== 'profile' || !data?.user || !socialState.token || profileTargetUser) return;
    saveSocialSession(socialState.token, data.user);
    const after = JSON.stringify([data.user.games, data.user.wins, data.user.draws, data.user.losses, data.user.ratingsByCategory, data.user.displayName, data.user.bio]);
    if (after !== before) renderView();
  }).catch(() => {});
  socialApi('/friends').then(data => {
    if (epoch !== profileLoadEpoch || currentView !== 'profile' || profileTargetUser) return;
    const friends = Array.isArray(data?.friends) ? data.friends : [];
    socialState.friends = friends;
    const box = $('#profileFriends'); if (!box) return;
    const count = $('#profileFriendCount'); if (count) count.textContent = `(${friends.length})`;
    box.innerHTML = friends.length ? friends.slice(0, 6).map(friend => `<article class="social-person-row"><button type="button" class="social-person-open" data-open-profile="${esc(friend.username)}"><span class="social-person-avatar" style="${avatarStyle(friend)}">${avatarEmoji(friend)}</span><span class="social-person-meta"><b>${esc(friend.displayName)}${tierBadge(friend)}</b><small>@${esc(friend.username)} · ${friend.online ? '🟢 Online' : 'Ngoại tuyến'} · ${Number(friend.elo || 500)} Elo</small></span></button><button type="button" class="tiny-btn" data-profile-message="${esc(friend.id)}" aria-label="Nhắn tin">✉</button></article>`).join('') : '<div class="small-empty">Chưa có bạn bè. Thêm bạn trong mục Bạn bè.</div>';
    wirePlayerProfileButtons(box);
    box.querySelectorAll('[data-profile-message]').forEach(button => button.addEventListener('click', () => { activeChatUserId = button.dataset.profileMessage; activeChatUser = friends.find(friend => friend.id === activeChatUserId) || null; setView('chat'); }));
  }).catch(() => { const box = $('#profileFriends'); if (box) box.innerHTML = '<div class="small-empty">Không tải được danh sách bạn bè.</div>'; });
}

function renderChatView() {
  if (!socialState.user) return `<section class="content-page chat-page"><div class="page-intro"><div class="eyebrow">VILA DIRECT</div><h1>Tin nhắn riêng</h1><p>Đăng nhập để nhắn tin với bạn bè hoặc người chơi từ trang hồ sơ.</p></div><section class="panel"><button type="button" class="primary-btn" data-home-view="friends">Đăng nhập / tạo tài khoản</button></section></section>`;
  return `<section class="content-page chat-page"><div class="page-intro"><div class="eyebrow">VILA DIRECT</div><h1>Tin nhắn riêng</h1></div><div class="support-bot-slot"></div><div class="chat-layout panel"><aside class="chat-sidebar"><div class="chat-sidebar-head"><div><b>Cuộc trò chuyện</b><small>Tin nhắn riêng tư</small></div><button id="refreshChats" type="button" class="tiny-btn" aria-label="Làm mới chat">↻</button></div><div id="chatConversationList" class="chat-conversation-list"><div class="small-empty">Đang tải hội thoại…</div></div></aside><section class="chat-room"><header id="chatRoomHeader" class="chat-room-head"><span class="chat-room-avatar">✉</span><div><b>Chọn một cuộc trò chuyện</b><small>Tin nhắn riêng</small></div></header><section id="chatAdminPlanPanel" class="chat-admin-plan-panel" hidden aria-label="Trợ lý gói VILA"><div class="chat-admin-plan-copy"><b>Trợ lý gói VILA</b><small>Chọn gói để gửi yêu cầu tới admin. Đây là quy trình tự động có xác nhận máy chủ, không phải bot AI tự quyết định thanh toán.</small></div><div class="chat-admin-plan-actions"><button type="button" class="secondary-btn" data-chat-plan-request="pro">Pro · 1.000đ / 3 giờ</button><button type="button" class="primary-btn" data-chat-plan-open="premium">Đề nghị Premium · 1k–100k</button></div></section><div id="chatMessageList" class="chat-message-list"><div class="chat-empty"><span>✉</span><b>Chưa chọn người trò chuyện</b><small>Mở hồ sơ người chơi để bắt đầu chat.</small></div></div><form id="chatSendForm" class="chat-compose"><textarea id="chatMessageText" class="field" maxlength="1000" rows="2" placeholder="Viết tin nhắn…" required disabled></textarea><button type="submit" class="primary-btn" id="chatSendButton" disabled>Gửi</button></form></section></div></section>`;
}
function renderChatConversations() {
  const list = $('#chatConversationList'); if (!list) return;
  if (!chatConversations.length) { list.innerHTML = '<div class="chat-empty chat-empty-small"><span>♙</span><b>Chưa có tin nhắn</b><small>Vào hồ sơ của người chơi để bắt đầu cuộc trò chuyện.</small></div>'; return; }
  list.innerHTML = chatConversations.map(item => `<button type="button" class="chat-conversation ${item.user.id === activeChatUserId ? 'active' : ''}" data-chat-open="${esc(item.user.id)}"><span class="social-person-avatar" style="${avatarStyle(item.user)}">${avatarEmoji(item.user)}</span><span class="chat-conversation-meta"><b>${esc(item.user.displayName || item.user.username)}</b><small>${esc(item.lastMessage?.text || 'Bắt đầu trò chuyện')}</small></span>${item.unread ? `<span class="chat-unread">${Number(item.unread) > 99 ? '99+' : Number(item.unread)}</span>` : ''}</button>`).join('');
  wireChatConversationButtons();
}
function wireChatConversationButtons() {
  $$('#chatConversationList [data-chat-open]').forEach(button => {
    if (button.dataset.chatBound === '1') return;
    button.dataset.chatBound = '1';
    button.addEventListener('click', () => {
      activeChatUserId = button.dataset.chatOpen;
      const row = chatConversations.find(item => item.user.id === activeChatUserId);
      activeChatUser = row?.user || null;
      renderChatConversations();
      void loadChatRoom(activeChatUserId);
    });
  });
}
async function loadChatConversations() {
  if (!socialState.token || currentView !== 'chat' || chatRefreshBusy) return;
  chatRefreshBusy = true;
  try {
    const data = await socialApi('/messages/conversations');
    chatConversations = Array.isArray(data.conversations) ? data.conversations : [];
    renderChatConversations();
    if (!activeChatUserId && chatConversations.length) {
      activeChatUserId = chatConversations[0].user.id;
      activeChatUser = chatConversations[0].user;
    }
    if (activeChatUserId) await loadChatRoom(activeChatUserId);
  } catch (error) { const list = $('#chatConversationList'); if (list) list.innerHTML = `<div class="small-empty">${esc(error.message || 'Không tải được hội thoại.')}</div>`; }
  finally { chatRefreshBusy = false; }
}
async function loadChatRoom(userId) {
  if (!socialState.token || !userId || currentView !== 'chat') return;
  const epoch = ++chatLoadEpoch;
  const messages = $('#chatMessageList');
  const hasRoomContent = Boolean(messages?.children?.length);
  const shouldStickToBottom = !messages || (messages.scrollHeight - messages.scrollTop - messages.clientHeight < 90);
  if (messages && (!hasRoomContent || loadedChatRoomUserId !== userId)) messages.innerHTML = '<div class="small-empty">Đang tải tin nhắn…</div>';
  try {
    const data = await socialApi(`/messages/${encodeURIComponent(userId)}`);
    if (epoch !== chatLoadEpoch || currentView !== 'chat' || userId !== activeChatUserId) return;
    activeChatUser = data.user;
    const header = $('#chatRoomHeader');
    if (header) header.innerHTML = `<span class="social-person-avatar chat-room-avatar" style="${avatarStyle(data.user)}">${avatarEmoji(data.user)}</span><div><b>${esc(data.user.displayName || data.user.username)}${tierBadge(data.user)}</b><small>@${esc(data.user.username)} · ${data.user.online ? 'Đang hoạt động' : 'Tin nhắn riêng'}</small></div><button type="button" class="tiny-btn" data-chat-profile="${esc(data.user.username)}">Hồ sơ</button>`;
    const adminPlanPanel = $('#chatAdminPlanPanel');
    if (adminPlanPanel) adminPlanPanel.hidden = data.user.role !== 'admin';
    if (messages) {
      messages.innerHTML = (data.messages || []).map(message => `<article class="chat-bubble-row ${message.fromMe ? 'from-me' : 'from-them'}"><div class="chat-bubble">${chatMessageBodyHtml(message.text)}<time>${esc(new Date(message.createdAt).toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' }))}</time></div></article>`).join('') || '<div class="chat-empty"><span>✉</span><b>Bắt đầu cuộc trò chuyện</b><small>Hãy gửi lời chào lịch sự nhé.</small></div>';
      if (shouldStickToBottom || loadedChatRoomUserId !== userId) messages.scrollTop = messages.scrollHeight;
    }
    loadedChatRoomUserId = userId;
    const input = $('#chatMessageText'), send = $('#chatSendButton');
    if (input) input.disabled = false;
    if (send) send.disabled = false;
    wirePlayerProfileButtons(header || document);
    if (header) header.querySelector('[data-chat-profile]')?.addEventListener('click', event => { void openPlayerProfile(event.currentTarget.dataset.chatProfile); });
    const row = chatConversations.find(item => item.user.id === userId);
    if (row) row.unread = 0;
    renderChatConversations();
  } catch (error) { if (messages) messages.innerHTML = `<div class="small-empty">${esc(error.message || 'Không tải được tin nhắn.')}</div>`; }
}
function wireChatActions() {
  void refreshSupportStatus();
  $('#refreshChats')?.addEventListener('click', () => { void loadChatConversations(); });
  $$('[data-chat-plan-request]').forEach(button => { if (button.dataset.planBound === '1') return; button.dataset.planBound = '1'; button.addEventListener('click', () => { void requestPlanWithAdmin('pro'); }); });
  $$('[data-chat-plan-open]').forEach(button => { if (button.dataset.planBound === '1') return; button.dataset.planBound = '1'; button.addEventListener('click', () => { setView('plans'); }); });
  wireChatConversationButtons();
  if (chatRefreshTimer) clearInterval(chatRefreshTimer);
  chatRefreshTimer = setInterval(() => {
    if (currentView !== 'chat') { clearInterval(chatRefreshTimer); chatRefreshTimer = null; return; }
    if (!document.hidden) void loadChatConversations();
  }, 7000);
  const form = $('#chatSendForm');
  form?.addEventListener('submit', async event => {
    event.preventDefault();
    if (!activeChatUserId) { toast('Mở hồ sơ người chơi trước khi gửi tin nhắn.'); return; }
    const input = $('#chatMessageText'), button = $('#chatSendButton');
    const text = String(input?.value || '').trim(); if (!text) return;
    if (button) button.disabled = true;
    const recipientId = activeChatUserId;
    try {
      const result = await socialApi(`/messages/${encodeURIComponent(recipientId)}`, { method: 'POST', body: JSON.stringify({ text }) });
      if (input) input.value = '';
      // Render from the server-confirmed response first. A concurrent seven-second
      // refresh may be busy, so relying on it alone can make a successful send look broken.
      const sent = result?.message;
      const messages = $('#chatMessageList');
      if (sent && messages && currentView === 'chat' && activeChatUserId === recipientId) {
        messages.querySelector('.chat-empty')?.remove();
        messages.querySelector('.small-empty')?.remove();
        const row = document.createElement('article'); row.className = 'chat-bubble-row from-me';
        const bubble = document.createElement('div'); bubble.className = 'chat-bubble'; bubble.append(document.createTextNode(String(sent.text || text)));
        const time = document.createElement('time');
        const date = new Date(sent.createdAt || Date.now());
        time.textContent = date.toLocaleString('vi-VN', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
        bubble.append(time); row.append(bubble); messages.append(row); messages.scrollTop = messages.scrollHeight;
      }
      // Start a refresh, but do not hold up the composer while another poll is finishing.
      void loadChatConversations();
      toast('Đã gửi tin nhắn.', 'success');
    } catch (error) { socialHandleError(error); }
    finally { if (button && activeChatUserId === recipientId) button.disabled = false; }
  });
  if (activeChatUserId && activeChatUser) { void loadChatConversations(); }
  else void loadChatConversations();
}

function renderInboxView() {
  const unread = unreadNotificationCount(appNotifications);
  const rows = [...appNotifications].reverse().map(item => {
    const typeLabel = item.type === 'error' ? 'Lỗi' : item.type === 'warning' ? 'Cảnh báo' : item.type === 'success' ? 'Thành công' : 'Thông tin';
    const date = new Date(item.createdAt);
    const dateLabel = Number.isFinite(date.getTime()) ? date.toLocaleString() : 'Không rõ thời gian';
    return `<article class="inbox-notice ${item.read ? 'is-read' : 'is-unread'} notice-${esc(item.type)}"><span class="inbox-notice-mark" aria-hidden="true">${item.type === 'error' ? '!' : item.type === 'warning' ? '⚠' : item.type === 'success' ? '✓' : '•'}</span><div class="inbox-notice-body"><div class="inbox-notice-head"><b>${esc(item.title)}</b><span>${typeLabel}</span></div><p>${esc(item.message)}</p><time datetime="${esc(item.createdAt)}">${esc(dateLabel)}</time></div>${item.read ? '' : `<button type="button" class="tiny-btn" data-mark-notification="${esc(item.id)}" aria-label="Đánh dấu đã đọc">✓</button>`}</article>`;
  }).join('');
  return `<section class="content-page inbox-page"><div class="page-intro"><div class="eyebrow">THÔNG BÁO TRÊN THIẾT BỊ</div><h1>Hộp thư</h1><p>Hiển thị cảnh báo engine, trạng thái tài khoản và lời mời kết bạn đã được ứng dụng nhận. Đây là hộp thư trong ứng dụng, chưa phải thông báo đẩy Android khi ứng dụng đóng.</p></div><div class="inbox-toolbar panel"><div><b>${unread} chưa đọc</b><small>${appNotifications.length} thông báo được lưu trên thiết bị</small></div><div class="inbox-toolbar-actions"><button type="button" class="secondary-btn" id="markAllNotificationsRead" ${unread ? '' : 'disabled'}>Đánh dấu đã đọc</button><button type="button" class="secondary-btn" id="clearReadNotifications" ${appNotifications.some(item => item.read) ? '' : 'disabled'}>Xóa đã đọc</button></div></div><div class="inbox-list">${rows || '<section class="panel empty-state inbox-empty"><b>Hộp thư đang trống</b><p>Khi engine gặp lỗi, đăng nhập thành công hoặc có lời mời bạn bè mà ứng dụng nhận được, thông báo sẽ xuất hiện ở đây.</p><button type="button" class="secondary-btn" data-home-view="health">Kiểm tra hệ thống</button></section>'}</div></section>`;
}
function wireInboxActions() {
  $$('[data-mark-notification]').forEach(button => button.addEventListener('click', async () => {
    const item = appNotifications.find(entry => entry.id === button.dataset.markNotification);
    const match = String(item?.sourceKey || '').match(/^admin-announcement:(.+)$/);
    if (match && socialState.token) { try { await socialApi(`/inbox/${encodeURIComponent(match[1])}/read`, { method: 'POST', body: '{}' }); } catch {} }
    appNotifications = markNotificationRead(appNotifications, button.dataset.markNotification);
    persistNotifications(); syncInboxBadge(); renderView();
  }));
  $('#markAllNotificationsRead')?.addEventListener('click', async () => {
    if (socialState.token) { try { await socialApi('/inbox/read-all', { method: 'POST', body: '{}' }); } catch {} }
    appNotifications = markAllNotificationsRead(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $('#clearReadNotifications')?.addEventListener('click', () => {
    appNotifications = clearReadNotifications(appNotifications);
    persistNotifications(); syncInboxBadge(); renderView();
  });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
}
function localStorageCheck() {
  const key = `${NOTIFICATIONS_KEY}.health-check`;
  try { localStorage.setItem(key, 'ok'); localStorage.removeItem(key); return true; }
  catch { return false; }
}
function renderSystemHealthView() {
  const protocolHasBackend = location.protocol === 'http:' || location.protocol === 'https:';
  const backendConfigured = Boolean(String(settings.backendUrl || '').trim()) || protocolHasBackend;
  const checks = buildSystemChecks({
    engineReady,
    engineFailed,
    workerSupported: typeof Worker === 'function',
    storageAvailable: localStorageCheck(),
    openingCount: OPENINGS.length,
    backendStatus: healthBackendStatus,
    backendConfigured
  });
  const statusText = { ok: 'Đạt', warning: 'Cần cấu hình', pending: 'Đang chờ', error: 'Cần xử lý' };
  const rows = checks.map(check => `<article class="health-check-row health-${check.status}"><span class="health-check-icon" aria-hidden="true">${check.status === 'ok' ? '✓' : check.status === 'warning' ? '!' : check.status === 'pending' ? '…' : '×'}</span><div><div class="health-check-heading"><b>${esc(check.label)}</b><span>${statusText[check.status] || 'Chưa rõ'}</span></div><p>${esc(check.detail)}</p></div></article>`).join('');
  const errors = checks.filter(check => check.status === 'error').length;
  const warnings = checks.filter(check => check.status === 'warning' || check.status === 'pending').length;
  return `<section class="content-page health-page"><div class="page-intro"><div class="eyebrow">CHẨN ĐOÁN THỰC TẾ</div><h1>Kiểm tra hệ thống</h1><p>Trang này kiểm tra trạng thái hiện tại, không tự đánh dấu đạt nếu engine, backend hoặc dữ liệu khai cuộc chưa thực sự sẵn sàng.</p></div><section class="panel health-summary"><div><span class="eyebrow">KẾT QUẢ LẦN KIỂM TRA</span><h2>${errors ? `${errors} mục cần xử lý` : warnings ? `${warnings} mục chưa xác minh` : 'Các mục đã kiểm tra đều đạt'}</h2><p>Engine: ${engineReady ? 'sẵn sàng' : engineFailed ? 'đang lỗi' : 'đang khởi tạo'} · Kho khai cuộc đang nạp: ${OPENINGS.length.toLocaleString()} dòng</p></div><div class="health-actions"><button type="button" class="primary-btn" id="runHealthChecks">↻ Kiểm tra lại</button><button type="button" class="secondary-btn" id="healthRetryEngine">Tải lại engine</button><button type="button" class="secondary-btn" data-health-settings>Cài đặt ứng dụng</button></div></section><div class="health-check-list" id="healthCheckList">${rows}</div><p class="field-hint health-disclaimer">Lời mời bạn bè, hộp thư cộng đồng và Top 100 cần backend thật. Kho khai cuộc chỉ được báo đủ khi nạp ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()} dòng dữ liệu; tệp fallback rỗng không được xem là kho đầy đủ.</p></section>`;
}
async function runSystemHealthChecks() {
  healthBackendStatus = 'checking';
  const list = $('#healthCheckList');
  if (list) list.innerHTML = '<div class="panel empty-state">Đang kiểm tra phản hồi backend…</div>';
  if (currentView === 'health') {
    const temp = $('#mainView');
    if (temp) temp.innerHTML = renderSystemHealthView();
    wireSystemHealthActions(false);
  }
  const configured = String(settings.backendUrl || DEFAULT_BACKEND_URL).trim().replace(/\/$/, '');
  if (!configured && location.protocol !== 'http:' && location.protocol !== 'https:') {
    healthBackendStatus = 'not-configured';
  } else {
    try {
      const response = await fetch(`${configured}/api/health`, { cache: 'no-store', signal: AbortSignal.timeout(8000) });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (data?.ok !== true) throw new Error('Health endpoint did not report ok=true');
      healthBackendStatus = 'online';
    } catch (error) {
      healthBackendStatus = String(error?.message || error || 'Không kết nối được');
    }
  }
  if (currentView === 'health') renderView();
}
function wireSystemHealthActions(runOnMount = true) {
  $('#runHealthChecks')?.addEventListener('click', () => { void runSystemHealthChecks(); });
  $('#healthRetryEngine')?.addEventListener('click', retryStockfishEngine);
  $('[data-health-settings]')?.addEventListener('click', () => setView('settings'));
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  if (runOnMount && healthBackendStatus === 'unknown') void runSystemHealthChecks();
}
async function pollSocialInbox() {
  if (!socialState.token || document.visibilityState !== 'visible') return;
  try {
    const token = socialState.token;
    const identity = await socialApi('/auth/me');
    if (!socialState.token) return;
    saveSocialSession(socialState.token, identity.user);
    const inbox = await socialApi('/inbox');
    if (socialState.token !== token) return;
    for (const notice of (Array.isArray(inbox.announcements) ? inbox.announcements : [])) {
      addAppNotification({ title: `📣 ${notice.title}`, message: notice.message, type: 'info', sourceKey: `admin-announcement:${notice.id}`, createdAt: notice.createdAt });
      if (notice.read) {
        const stored = appNotifications.find(item => item.sourceKey === `admin-announcement:${notice.id}`);
        if (stored && !stored.read) { stored.read = true; persistNotifications(); }
      }
    }
    const data = await socialApi('/friends');
    if (socialState.token !== token) return;
    captureIncomingFriendNotifications(data.incoming);
    if (currentView === 'friends') await loadFriendsSnapshot();
  } catch (error) {
    const message = String(error?.message || error || '');
    if (isSessionRejected(error) && socialState.token) {
      saveSocialSession('', null);
      addAppNotification({ title: 'Phiên đăng nhập đã hết hạn', message: 'Hãy đăng nhập lại để dùng bạn bè, hộp thư cộng đồng và Top 100.', type: 'warning', sourceKey: `session-expired:${new Date().toISOString().slice(0, 10)}` });
    } else console.info('[Cờ Vua] Background inbox sync skipped:', message);
  }
}

function wireFriendsActions() {
  $('#socialLoginForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/login', { method: 'POST', body: JSON.stringify({ username: $('#socialLoginName').value.trim(), password: $('#socialLoginPassword').value }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng nhập.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Đăng nhập thành công', message: `Xin chào ${data.user?.displayName || data.user?.username || 'bạn'}.`, type: 'success', sourceKey: `login:${data.user?.id || data.user?.username}:${new Date().toISOString().slice(0, 10)}` }); toast('Đăng nhập thành công.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialRegisterForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true; try { const data = await socialApi('/auth/register', { method: 'POST', body: JSON.stringify({ username: $('#socialRegisterDisplay').value.trim(), password: $('#socialRegisterPassword').value, initialElo: Number($('#socialRegisterElo')?.value || 500) }) }); if (!data?.token || !data?.user) throw new Error('Máy chủ không trả token và hồ sơ tài khoản hợp lệ. Chưa thể xác nhận đăng ký.'); saveSocialSession(data.token, data.user); addAppNotification({ title: 'Tài khoản đã tạo', message: 'Hồ sơ Cờ Vua đã được tạo trên máy chủ.', type: 'success' }); toast('Đã tạo tài khoản Cờ Vua.'); renderView(); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } });
  $('#socialLogout')?.addEventListener('click', () => { socialApi('/auth/logout', { method: 'POST', body: '{}' }).catch(() => {}); saveSocialSession('', null); socialState.friends = []; socialState.incoming = []; socialState.outgoing = []; showAccountGate('login', 'Bạn đã đăng xuất khỏi tài khoản VILA.'); });
  $('#socialProfileForm')?.addEventListener('submit', async event => { event.preventDefault(); try { const data = await socialApi('/profile', { method: 'PATCH', body: JSON.stringify({ displayName: $('#socialProfileDisplay').value, bio: $('#socialProfileBio').value }) }); saveSocialSession(socialState.token, data.user); toast('Đã lưu hồ sơ.'); renderView(); } catch (error) { socialHandleError(error); } });
  $('#socialSearchForm')?.addEventListener('submit', async event => { event.preventDefault(); const output = $('#socialSearchResults'); if (!output) return; output.innerHTML = '<div class="small-empty">Đang tìm…</div>'; try { const data = await socialApi(`/users/search?q=${encodeURIComponent($('#socialSearchName').value)}`); socialState.searchResults = data.users || []; output.innerHTML = socialState.searchResults.length ? socialState.searchResults.map(u => `<article class="social-person-row"><button type="button" class="social-person-open" data-open-profile="${esc(u.username)}"><span class="social-person-avatar" style="${avatarStyle(u)}">${avatarEmoji(u)}</span><span class="social-person-meta"><b>${esc(u.displayName)}${tierBadge(u)}</b><small>@${esc(u.username)} · ${u.online ? '🟢 Online' : `${Number(u.elo || 500)} Elo`}</small></span></button><button class="tiny-btn social-add" data-add-friend="${esc(u.username)}" aria-label="Gửi lời mời">＋</button></article>`).join('') : '<div class="empty-state">Không tìm thấy người chơi phù hợp.</div>'; wirePlayerProfileButtons(output); wireFriendRowActions(output); } catch (error) { output.innerHTML = `<div class="small-empty">${esc(error.message)}</div>`; } });
  $('#refreshFriends')?.addEventListener('click', loadFriendsSnapshot);
  wireFriendRowActions();
  $('#openPasswordRecovery')?.addEventListener('click', () => showAccountGate('forgot'));
  $('#triggerCloudSyncBtn')?.addEventListener('click', async () => {
    toast('Đang đồng bộ dữ liệu ván đấu lên đám mây...');
    const result = await syncHistoryToCloud(settings.backendUrl || '', socialState.token || '', readSavedGames());
    toast(result.message, result.ok ? 'success' : 'info');
  });
  wireFriendRowActions();
  loadFriendsSnapshot();
}
/* ---------- Achievements: 10,000 milestones (v3.58) ---------- */
let achievementUi = { category: 'all', status: 'all', limit: 40 };
function renderAchievementsView() {
  const stats = achievementStats();
  const summary = summarizeAchievements(stats);
  const page = listAchievements(stats, { category: achievementUi.category, status: achievementUi.status, offset: 0, limit: achievementUi.limit });
  const chip = (key, label) => `<button type="button" class="ach-chip ${achievementUi.category === key ? 'active' : ''}" data-ach-category="${esc(key)}">${esc(label)}</button>`;
  const statusChip = (key, label) => `<button type="button" class="ach-chip ${achievementUi.status === key ? 'active' : ''}" data-ach-status="${key}">${label}</button>`;
  const row = item => `<li class="ach-item ${item.unlocked ? 'is-unlocked' : ''} tier-${item.tier}"><span class="ach-icon" aria-hidden="true">${uiIcon(item.icon)}</span><div class="ach-body"><b>${esc(item.title)}</b><small>${esc(item.category)} · ${esc(item.tierLabel)} · +${item.points} điểm</small>${item.unlocked ? '' : `<div class="ach-bar" role="progressbar" aria-valuemin="0" aria-valuemax="${item.target}" aria-valuenow="${Math.min(item.value, item.target)}"><i style="width:${Math.round(item.progress * 100)}%"></i></div><small>${formatCount(Math.min(item.value, item.target))} / ${formatCount(item.target)}</small>`}</div><span class="ach-state" aria-label="${item.unlocked ? 'Đã đạt' : 'Chưa đạt'}">${item.unlocked ? '✓' : '🔒'}</span></li>`;
  return `<section class="page achievements-page"><div class="panel-heading"><div><small class="eyebrow">THÀNH TỰU</small><h2>${formatCount(summary.unlocked)} / ${formatCount(ACHIEVEMENT_TOTAL)}</h2></div><span class="context-icon">🏅</span></div>
    <p class="field-hint">${summary.percent}% hoàn thành · <b>${formatCount(summary.points)}</b> điểm thành tựu. Thành tựu tự mở khi bạn chơi cờ, giải câu đố, học bài và điểm danh mỗi ngày.</p>
    <div class="ach-bar ach-total" role="progressbar" aria-valuemin="0" aria-valuemax="${ACHIEVEMENT_TOTAL}" aria-valuenow="${summary.unlocked}"><i style="width:${Math.max(1, Math.round(summary.unlocked / ACHIEVEMENT_TOTAL * 100))}%"></i></div>
    <div class="ach-chips" role="group" aria-label="Lọc theo nhóm">${chip('all', `Tất cả`)}${ACHIEVEMENT_CATEGORIES.map(cat => chip(cat, `${cat} ${formatCount(summary.byCategory[cat].unlocked)}/${formatCount(summary.byCategory[cat].total)}`)).join('')}</div>
    <div class="ach-chips" role="group" aria-label="Lọc theo trạng thái">${statusChip('all', 'Tất cả')}${statusChip('locked', 'Chưa đạt')}${statusChip('unlocked', 'Đã đạt')}</div>
    <ul class="ach-list">${page.items.map(row).join('') || '<li class="empty-state">Chưa có thành tựu nào trong mục này.</li>'}</ul>
    <p class="field-hint">Hiển thị ${formatCount(Math.min(page.total, achievementUi.limit))} / ${formatCount(page.total)}</p>
    ${page.total > achievementUi.limit ? '<p><button type="button" class="secondary-btn full-width" data-ach-more>Xem thêm 40 thành tựu</button></p>' : ''}</section>`;
}
function wireAchievementsActions() {
  $$('[data-ach-category]').forEach(button => button.addEventListener('click', () => { achievementUi = { ...achievementUi, category: button.dataset.achCategory, limit: 40 }; renderView(); }));
  $$('[data-ach-status]').forEach(button => button.addEventListener('click', () => { achievementUi = { ...achievementUi, status: button.dataset.achStatus, limit: 40 }; renderView(); }));
  $('[data-ach-more]')?.addEventListener('click', () => { achievementUi = { ...achievementUi, limit: achievementUi.limit + 40 }; renderView(); });
}

function renderMissionsView() {
  const state = readDailyProgress();
  const summary = getMissionSummary(state);
  const cards = DAILY_MISSIONS.map(mission => {
    const progress = Math.min(mission.goal, Number(state.missionProgress[mission.id] || 0));
    const completed = progress >= mission.goal;
    const claimed = state.claimed.includes(mission.id);
    return `<article class="mission-card panel"><div class="mission-card-top"><span class="mission-card-icon">${uiIcon(mission.icon)}</span><span class="mission-card-category">${esc(mission.category || 'Thử thách')}</span><span class="mission-reward">◈ ${mission.reward} xu</span></div><h2>${esc(mission.title)}</h2><p>${esc(mission.description)}</p><div class="mission-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${mission.goal}" aria-valuenow="${progress}"><span style="width:${Math.round(progress / mission.goal * 100)}%"></span></div><div class="mission-card-bottom"><small>${progress}/${mission.goal} ${completed ? '· Hoàn thành' : '· Chưa hoàn thành'}</small>${claimed ? '<span class="mission-claimed">✓ Đã nhận</span>' : `<button type="button" class="${completed ? 'primary-btn' : 'secondary-btn'}" data-claim-mission="${mission.id}" ${completed ? '' : 'disabled'}>${completed ? 'Nhận thưởng' : 'Chưa xong'}</button>`}</div></article>`;
  }).join('');
  return `<section class="content-page progression-page"><div class="page-intro"><div class="eyebrow">THÓI QUEN NHỎ · TIẾN BỘ MỖI NGÀY</div><h1>Nhiệm vụ hằng ngày</h1><p>Hoàn thành các thử thách để nhận xu trong game, đổi lấy lượt phân tích, Pro dùng thử và giữ chuỗi hoạt động. Tiến độ này được lưu trên thiết bị hiện tại.</p></div><div class="progression-summary-grid"><article class="panel progression-summary-main"><small>VÍ XU TRONG GAME</small><strong>◈ ${summary.coins}</strong><span>Không phải tiền thật và không thể rút ra.</span></article><article class="panel progression-summary-item"><small>CHUỖI NGÀY</small><strong>🔥 ${summary.streak}</strong><span>Ngày hoạt động liên tiếp</span></article><article class="panel progression-summary-item"><small>NHIỆM VỤ XONG</small><strong>${summary.completed}/${summary.total}</strong><span>${summary.claimed} phần thưởng đã nhận</span></article></div><div class="mission-cards-grid">${cards}</div><section class="panel progression-next-step"><div><span class="eyebrow">PHẦN THƯỞNG TRANG TRÍ</span><h2>Đổi xu lấy lượt phân tích</h2><p>Mua lượt phân tích, câu đố và Pro dùng thử 3 giờ. Vật phẩm không tạo lợi thế khi thi đấu.</p></div><button class="primary-btn" type="button" data-open-shop>Mở cửa hàng ↗</button></section></section>`;
}
function formatTrialLeft(ms) {
  const mins = Math.ceil(ms / 60000);
  return mins >= 60 ? `${Math.floor(mins / 60)} giờ ${mins % 60} phút` : `${mins} phút`;
}
function renderShopView() {
  const state = readDailyProgress();
  const inv = state.inventory;
  const trialMs = proTrialLeftMs(state);
  const stock = [
    ['chart', 'Lượt phân tích', inv.reviewCredits],
    ['puzzle', 'Lượt câu đố', inv.puzzleCredits],
    ['shield', 'Bảo vệ chuỗi', inv.streakFreezes],
    ['bolt', 'Nhân đôi xu', inv.coinBoosts]
  ].map(([icon, label, n]) => `<div class="shop-stock-item"><i class="ui-tile tile-sm">${uiIcon(icon)}</i><span><b>${n}</b><small>${label}</small></span></div>`).join('');
  const trialBanner = trialMs > 0 ? `<div class="shop-trial-live" role="status"><i class="ui-tile tile-sm tile-gold">${uiIcon('gem')}</i><span><b>Pro dùng thử đang chạy</b><small>Còn ${esc(formatTrialLeft(trialMs))} · phân tích và câu đố không giới hạn</small></span></div>` : '';
  const groups = SHOP_GROUPS.map(group => {
    const items = SHOP_ITEMS.filter(item => item.group === group.id).map(item => {
      const afford = state.coins >= item.cost;
      return `<article class="shop-item panel"><i class="ui-tile tile-lg tile-${group.id}">${uiIcon(item.icon)}</i><div class="shop-item-copy"><div class="shop-item-title"><h3>${esc(item.name)}</h3>${item.badge ? `<span class="shop-badge">${esc(item.badge)}</span>` : ''}</div><p>${esc(item.description)}</p></div><button type="button" class="${afford ? 'primary-btn' : 'secondary-btn'} shop-buy" data-buy-item="${item.id}" ${afford ? '' : 'disabled'}><i class="shop-coin">${uiIcon('coin')}</i>${item.cost}</button></article>`;
    }).join('');
    return `<section class="shop-group"><header class="shop-group-head"><i class="ui-tile tile-sm tile-${group.id}">${uiIcon(group.icon)}</i><h2>${esc(group.title)}</h2></header><div class="shop-items">${items}</div></section>`;
  }).join('');
  return `<section class="content-page progression-page shop-page"><div class="page-intro"><div class="eyebrow">CỬA HÀNG XU</div><h1>Cửa hàng</h1><p>Dùng xu kiếm từ nhiệm vụ để mua lượt phân tích, dùng thử Pro và các tiện ích luyện tập. Xu chỉ có trong game, không phải tiền thật, và vật phẩm không ảnh hưởng sức mạnh bot, Elo hay kết quả trận.</p></div><div class="shop-wallet panel"><div class="shop-wallet-coins"><i class="ui-tile tile-lg tile-gold">${uiIcon('coin')}</i><div><small>VÍ XU CỦA BẠN</small><strong>${state.coins}</strong></div></div><button type="button" class="secondary-btn" data-open-missions>Kiếm xu từ nhiệm vụ</button></div>${trialBanner}<div class="shop-stock panel" aria-label="Kho vật phẩm">${stock}</div>${groups}<section class="panel shop-future-note"><span class="eyebrow">GÓI THẬT</span><h2>Muốn dùng lâu dài?</h2><p>Pro (1 năm) và Premium (trọn đời) mua bằng Google Play, gắn với tài khoản. Xem chi tiết ở mục Gói Pro &amp; Premium.</p><button type="button" class="secondary-btn" data-home-view="plans">Xem gói Pro &amp; Premium</button></section></section>`;
}
function wireMissionsActions() {
  $$('[data-claim-mission]').forEach(button => button.addEventListener('click', () => {
    const result = claimMissionReward(readDailyProgress(), button.dataset.claimMission, new Date());
    if (!result.ok) { toast(result.reason === 'already_claimed' ? 'Bạn đã nhận phần thưởng này hôm nay.' : 'Hoàn thành nhiệm vụ trước khi nhận thưởng.'); return; }
    persistDailyProgress(result.state);
    toast(`Đã nhận ${result.reward} xu trong game!`);
    renderView();
  }));
  $('[data-open-shop]')?.addEventListener('click', () => setView('shop'));
}
function wireShopActions() {
  $$('[data-buy-item]').forEach(button => button.addEventListener('click', () => {
    const result = purchaseShopItem(readDailyProgress(), button.dataset.buyItem, new Date());
    if (!result.ok) { toast(result.reason === 'not_enough_coins' ? 'Chưa đủ xu. Hoàn thành nhiệm vụ để kiếm thêm.' : result.reason === 'at_limit' ? 'Bạn đã đạt giới hạn tối đa của vật phẩm này.' : 'Không thể mua vật phẩm này.'); return; }
    persistDailyProgress(result.state);
    toast(`Đã mua: ${result.item.name}`, 'success');
    renderView();
  }));
  $('[data-open-missions]')?.addEventListener('click', () => setView('missions'));
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
}

function renderAdminView() {
  if (socialState.user?.role !== 'admin') return `<section class="content-page"><div class="page-intro"><div class="eyebrow">BẢO MẬT NỀN TẢNG</div><h1>Trung tâm quản trị</h1><p>Khu vực này chỉ dành cho tài khoản admin đã được cấp quyền ở phía máy chủ.</p></div><section class="panel"><div class="empty-state">Bạn chưa đăng nhập bằng tài khoản quản trị. Hãy vào mục Bạn bè để đăng nhập. Admin được tạo qua ADMIN_USERNAME và ADMIN_PASSWORD trong cấu hình bí mật của máy chủ — không có mật khẩu mặc định trong APK.</div><button type="button" class="primary-btn" data-home-view="friends">Mở đăng nhập</button></section></section>`;
  return `<section class="content-page admin-page"><div class="page-intro"><div class="eyebrow">ADMIN CONTROL PLANE</div><h1>Quản trị nền tảng</h1><p>Giám sát tiến trình server, tài khoản và sự kiện bảo mật. Các thao tác khóa tài khoản được kiểm tra quyền ở API server.</p><p class="field-hint"><strong>Admin · Elo khởi tạo:</strong> tài khoản quản trị được cấu hình riêng lúc bootstrap server qua <code>ADMIN_INITIAL_ELO</code>; admin bootstrap có mức khởi tạo riêng và không làm thay đổi mức Elo đăng ký của người chơi.</p></div><div class="admin-metrics-grid" id="adminMetrics"><div class="panel"><span class="admin-metric-label">Đang tải</span><strong>—</strong></div></div><section class="panel admin-purchase-panel"><div class="panel-heading"><div><small class="eyebrow">PRO / PREMIUM · REQUEST QUEUE</small><h2>Yêu cầu gói từ Messenger</h2></div><span class="context-icon">✦</span></div><p class="field-hint">Pro: chỉ bấm xác nhận sau khi đã nhận đủ 1.000đ; máy chủ khi đó cấp đúng 3 giờ. Premium: không bán tự động, chỉ đánh dấu đã liên hệ hoặc từ chối. Mọi quyết định được ghi vào audit log.</p><div id="adminPurchaseRequestsList" class="admin-purchase-list"><div class="empty-state">Đang tải yêu cầu từ máy chủ…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Người dùng</h2></div><button class="secondary-btn" id="refreshAdmin" type="button">↻ Làm mới</button></div><form id="adminSearchForm" class="social-search-row"><input class="field" id="adminSearchName" placeholder="Tìm username, tên hiển thị hoặc email" maxlength="80"/><button class="secondary-btn" type="submit">Tìm</button></form><div class="admin-user-list" id="adminUsersList"><div class="empty-state">Đang tải người dùng…</div></div></section><section class="panel admin-reports-panel"><div class="panel-heading"><div><small class="eyebrow">AN TOÀN CỘNG ĐỒNG</small><h2>Báo cáo gian lận & vi phạm</h2></div><span class="context-icon">⚑</span></div><div id="adminReportsList" class="admin-report-list"><div class="empty-state">Đang tải báo cáo…</div></div></section><section class="panel admin-fair-play-panel"><div class="panel-heading"><div><small class="eyebrow">SERVER-SIDE REVIEW</small><h2>Rà soát tín hiệu fair-play</h2></div><span class="context-icon">⌁</span></div><p class="field-hint">Chỉ báo hiệu thống kê để admin xem xét, không phải bằng chứng chắc chắn hoặc kết luận dùng hack. Không tự động khóa tài khoản từ các tín hiệu này.</p><div id="adminFairPlayList" class="admin-report-list"><div class="empty-state">Đang tải tín hiệu…</div></div></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">HỘP THƯ NGƯỜI CHƠI</small><h2>Gửi thông báo cộng đồng</h2></div><span class="context-icon">📣</span></div><form id="adminAnnouncementForm"><label class="field-label" for="adminAnnouncementTitle">Tiêu đề</label><input class="field" id="adminAnnouncementTitle" maxlength="100" minlength="3" required placeholder="Ví dụ: Sự kiện cuối tuần"/><label class="field-label" for="adminAnnouncementMessage">Nội dung</label><textarea class="field" id="adminAnnouncementMessage" maxlength="1200" minlength="5" rows="4" required placeholder="Tin nhắn sẽ xuất hiện trong hộp thư của người chơi"></textarea><button class="primary-btn" type="submit">Gửi thông báo tới mọi tài khoản</button><p id="adminAnnouncementStatus" class="field-hint" aria-live="polite"></p></form></section><section class="panel"><div class="panel-heading"><div><small class="eyebrow">AUDIT LOG</small><h2>Nhật ký bảo mật</h2></div><span class="context-icon">⌁</span></div><div class="admin-audit-list" id="adminAuditList"><div class="empty-state">Đang tải nhật ký…</div></div></section><p class="field-hint">Bảng quản trị không thay thế các lớp phòng thủ của nhà cung cấp hosting. Cần HTTPS, sao lưu, cập nhật hệ điều hành, giám sát và chống DDoS ở tầng hạ tầng khi server được đưa lên Internet.</p></section>`;
}
async function loadAdminDashboard(query = '') {
  if (socialState.user?.role !== 'admin' || currentView !== 'admin') return;
  const metrics = $('#adminMetrics'), usersNode = $('#adminUsersList'), auditNode = $('#adminAuditList'), reportsNode = $('#adminReportsList'), fairPlayNode = $('#adminFairPlayList');
  try {
    const [overview, users, auditData, reportData, fairPlayData, purchaseData] = await Promise.all([socialApi('/admin/overview'), socialApi(`/admin/users?q=${encodeURIComponent(query)}`), socialApi('/admin/audit?limit=40'), socialApi('/admin/reports?status=pending'), socialApi('/admin/fair-play').catch(error => ({ matches: [], loadError: `Chưa tải được tín hiệu fair-play: ${error.message || 'API chưa được cập nhật'}` })), socialApi('/admin/purchase-requests?status=pending').catch(error => ({ requests: [], loadError: `Chưa tải được yêu cầu gói: ${error.message || 'API chưa được cập nhật'}` }))]);
    socialState.adminOverview = overview; socialState.adminUsers = users.users || []; socialState.auditEvents = auditData.events || []; socialState.adminReports = reportData.reports || [];
    const purchaseRequestsNode = $('#adminPurchaseRequestsList');
    const purchaseRows = Array.isArray(purchaseData.requests) ? purchaseData.requests : [];
    if (purchaseRequestsNode) {
      if (purchaseData.loadError) purchaseRequestsNode.innerHTML = `<div class="empty-state">${esc(purchaseData.loadError)}. Cập nhật backend để bật duyệt yêu cầu.</div>`;
      else if (!purchaseRows.length) purchaseRequestsNode.innerHTML = '<div class="empty-state">Không có yêu cầu gói nào đang chờ.</div>';
      else purchaseRequestsNode.innerHTML = purchaseRows.map(request => {
        const isPro = request.plan === 'pro';
        const planLabel = isPro ? 'Pro dùng thử · 3 giờ' : 'Đề nghị Premium · chưa bán';
        const amount = Number(request.amountVnd || 0).toLocaleString('vi-VN');
        const actionButtons = isPro
          ? `<button type="button" class="primary-btn" data-purchase-decision="confirm-pro" data-purchase-request-id="${esc(request.id)}">Xác nhận tiền + cấp 3 giờ</button>`
          : `<button type="button" class="primary-btn" data-purchase-decision="grant-premium" data-purchase-request-id="${esc(request.id)}">Cấp Premium</button><button type="button" class="secondary-btn" data-purchase-decision="contacted" data-purchase-request-id="${esc(request.id)}">Đã liên hệ</button>`;
        return `<article class="admin-purchase-row"><div class="admin-purchase-head"><span class="admin-purchase-icon">${isPro ? '♛' : '✦'}</span><div><b>${esc(planLabel)}</b><small>@${esc(request.user?.username || 'unknown')} · ${esc(request.user?.displayName || '')}</small></div><strong>${amount}đ</strong></div><div class="admin-purchase-meta"><span>Mã: ${esc(request.id.slice(0, 12))}</span><time>${esc(new Date(request.createdAt).toLocaleString('vi-VN'))}</time></div><div class="admin-purchase-actions">${actionButtons}<button type="button" class="danger-btn" data-purchase-decision="reject" data-purchase-request-id="${esc(request.id)}">Từ chối</button><button type="button" class="tiny-btn" data-purchase-message-user="${esc(request.user?.id || '')}">Mở chat</button></div></article>`;
      }).join('');
    }
    if (metrics) metrics.innerHTML = `<article class="panel"><span class="admin-metric-label">Tổng tài khoản</span><strong>${Number(overview.users)}</strong><small>${Number(overview.activeUsers)} hoạt động gần đây</small></article><article class="panel"><span class="admin-metric-label">Tài khoản bị khóa</span><strong>${Number(overview.bannedUsers)}</strong><small>${Number(overview.admins)} admin đang hoạt động</small></article><article class="panel"><span class="admin-metric-label">Server uptime</span><strong>${Math.floor(Number(overview.uptimeSeconds || 0) / 3600)}h ${Math.floor((Number(overview.uptimeSeconds || 0) % 3600) / 60)}m</strong><small>Node ${esc(overview.node)} · ${esc(overview.platform)}/${esc(overview.arch)}</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ tiến trình</span><strong>${Number(overview.memory?.rssMb || 0)} MB</strong><small>Heap ${Number(overview.memory?.heapUsedMb || 0)}/${Number(overview.memory?.heapTotalMb || 0)} MB · ${Number(overview.cpus || 0)} CPU</small></article><article class="panel"><span class="admin-metric-label">Bộ nhớ hệ thống trống</span><strong>${Number(overview.memory?.systemFreeMb || 0)} MB</strong><small>Tổng ${Number(overview.memory?.systemTotalMb || 0)} MB</small></article><article class="panel"><span class="admin-metric-label">Tải CPU (1/5/15 phút)</span><strong>${(overview.loadAverage || [0,0,0]).map(n => Number(n).toFixed(2)).join(' / ')}</strong><small>Chỉ số load average của máy chủ</small></article><article class="panel"><span class="admin-metric-label">Báo cáo chờ xử lý</span><strong>${Number(overview.pendingReports || 0)}</strong><small>${Number(overview.pendingFriendRequests || 0)} lời mời kết bạn · ${Number(overview.db?.auditEvents || 0)} sự kiện nhật ký</small></article>`;
    if (usersNode) usersNode.innerHTML = socialState.adminUsers.length ? socialState.adminUsers.map(u => `<article class="admin-user-row"><span class="social-person-avatar" style="${avatarStyle(u)}">${avatarEmoji(u)}</span><span class="social-person-meta"><b>${esc(u.displayName)}${tierBadge(u)} <small>@${esc(u.username)}</small></b><small>${esc(u.email || 'Chưa thêm email')} · ${u.banned ? '🔒 Đã khóa' : '🟢 Hoạt động'} · ${Number(u.elo || 1200)} Elo · ${esc(new Date(u.createdAt).toLocaleDateString())}</small></span>${u.role === 'admin' ? '<span class="admin-role-tag">ADMIN</span>' : `<button class="${u.banned ? 'secondary-btn' : 'danger-btn'} admin-ban-button" type="button" data-admin-action="${u.banned ? 'unban' : 'ban'}" data-admin-user="${esc(u.id)}">${u.banned ? 'Mở khóa' : 'Khóa'}</button>`}${u.role === 'admin' ? '' : `<span class="admin-plan-actions"><button class="secondary-btn" type="button" data-admin-plan="pro" data-admin-days="30" data-admin-user="${esc(u.id)}">Pro 30 ngày</button><button class="secondary-btn" type="button" data-admin-plan="pro" data-admin-user="${esc(u.id)}">Pro 1 năm</button><button class="secondary-btn" type="button" data-admin-plan="premium" data-admin-user="${esc(u.id)}">Premium</button><button class="danger-btn" type="button" data-admin-revoke="all" data-admin-user="${esc(u.id)}">Thu hồi gói</button></span>`}</article>`).join('') : '<div class="empty-state">Không có người dùng phù hợp.</div>';
    if (reportsNode) reportsNode.innerHTML = socialState.adminReports.length ? socialState.adminReports.map(report => `<article class="admin-report-row"><span class="admin-report-mark">⚑</span><div class="admin-report-body"><b>${esc(report.reason === 'cheating' ? 'Nghi dùng hack / engine' : report.reason === 'abuse' ? 'Quấy rối' : report.reason === 'spam' ? 'Spam' : report.reason === 'impersonation' ? 'Giả mạo' : 'Khác')}</b><small>Người báo cáo: @${esc(report.reporter?.username || 'unknown')} · Bị báo cáo: @${esc(report.target?.username || 'unknown')}</small><p>${esc(report.details || 'Không có mô tả bổ sung.')}</p><time>${esc(new Date(report.createdAt).toLocaleString())}</time></div><div class="admin-report-actions"><button type="button" class="danger-btn" data-report-action="ban" data-report-id="${esc(report.id)}">Xác minh & khóa</button><button type="button" class="secondary-btn" data-report-action="dismiss" data-report-id="${esc(report.id)}">Bỏ qua</button><button type="button" class="tiny-btn" data-open-profile="${esc(report.target?.username || '')}">Hồ sơ</button></div></article>`).join('') : '<div class="empty-state">Không có báo cáo nào đang chờ xử lý.</div>';
    if (fairPlayNode) {
      const fairPlayMatches = Array.isArray(fairPlayData.matches) ? fairPlayData.matches : [];
      fairPlayNode.innerHTML = fairPlayMatches.length ? fairPlayMatches.map(match => {
        const players = Object.values(match.players || {});
        const playerRows = players.map(player => {
          const signal = player.signals || {};
          const metrics = signal.metrics || {};
          const level = String(signal.level || 'review');
          const badge = level === 'priority_review' ? 'ƯU TIÊN RÀ SOÁT' : level === 'review' ? 'CẦN RÀ SOÁT' : 'THEO DÕI';
          return `<div class="fair-play-player"><b>@${esc(player.username || 'unknown')}</b><span class="fair-play-level ${level === 'priority_review' ? 'is-priority' : ''}">${esc(badge)}</span><small>${Number(signal.signals || 0)} tín hiệu · ${Number(metrics.fastComplexMoves || 0)} nước nhanh ở thế nhiều nước đi · trung vị ${metrics.medianTurnMs == null ? '—' : `${Math.max(0, Number(metrics.medianTurnMs) || 0)} ms`}</small></div>`;
        }).join('');
        const events = (Array.isArray(match.events) ? match.events : []).slice(-5).map(event => {
          const player = players.find(item => item.id && item.id === event.userId);
          return `<li><b>${esc(player ? `@${player.username}` : 'Người chơi')}</b> · ${esc(event.type || 'fair_play_signal')} — ${esc(event.detail || '')}<time>${esc(event.at ? new Date(event.at).toLocaleString() : '')}</time></li>`;
        }).join('');
        return `<article class="fair-play-match"><div class="fair-play-match-heading"><b>Trận ${esc(String(match.matchId || '').slice(0, 12) || '—')}</b><span>${esc(match.timeCategory || 'ranked')} · ${esc(match.timeControl || 'không rõ')}</span><small>${esc(match.status || 'unknown')}</small></div><div class="fair-play-player-list">${playerRows || '<small>Không có dữ liệu người chơi.</small>'}</div>${events ? `<details class="fair-play-events"><summary>${(match.events || []).length} sự kiện gần đây</summary><ul>${events}</ul></details>` : ''}</article>`;
      }).join('') : `<div class="empty-state">${esc(fairPlayData.loadError || 'Chưa có tín hiệu fair-play cần rà soát. Tín hiệu chỉ xuất hiện khi trận đấu tạo được sự kiện đủ điều kiện.')}</div>`;
    }
    wirePlayerProfileButtons(reportsNode || document);
    $$('[data-report-action]').forEach(button => { if (button.dataset.reportBound === '1') return; button.dataset.reportBound = '1'; button.addEventListener('click', async () => { const action = button.dataset.reportAction; const reason = action === 'ban' ? (prompt('Lý do khóa tài khoản sau khi xem xét báo cáo:', 'Đã xác minh vi phạm quy định công bằng') || '') : ''; if (action === 'ban' && !reason.trim()) return; button.disabled = true; try { const data = await socialApi(`/admin/reports/${encodeURIComponent(button.dataset.reportId)}`, { method: 'PATCH', body: JSON.stringify({ action, reason }) }); toast(data.message || 'Đã xử lý báo cáo.', 'success'); await loadAdminDashboard($('#adminSearchName')?.value || ''); } catch (error) { socialHandleError(error); button.disabled = false; } }); });
    if (auditNode) auditNode.innerHTML = socialState.auditEvents.length ? socialState.auditEvents.map(item => `<article class="admin-audit-row"><span class="admin-audit-dot"></span><div><b>${esc(item.action)}</b><small>${esc(item.detail || '')}</small><span>${esc(new Date(item.at).toLocaleString())} · actor ${esc(String(item.actor || '').slice(0,12))} · target ${esc(String(item.target || '').slice(0,12))}</span></div></article>`).join('') : '<div class="empty-state">Chưa có sự kiện bảo mật.</div>';
    $$('[data-admin-action]').forEach(button => { if (button.dataset.adminBound === '1') return; button.dataset.adminBound = '1'; button.addEventListener('click', async () => { const action = button.dataset.adminAction; const id = button.dataset.adminUser; const reason = action === 'ban' ? (prompt('Lý do khóa tài khoản (hiển thị cho quản trị viên):', 'Vi phạm quy định cộng đồng') || '') : ''; if (action === 'ban' && !reason.trim()) return; button.disabled = true; try { await socialApi(`/admin/users/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ action, reason }) }); toast(action === 'ban' ? 'Đã khóa tài khoản.' : 'Đã mở khóa tài khoản.'); await loadAdminDashboard($('#adminSearchName')?.value || ''); } catch (error) { socialHandleError(error); } finally { button.disabled = false; } }); });
    $$('[data-admin-plan], [data-admin-revoke]').forEach(button => {
      if (button.dataset.planBound === '1') return; button.dataset.planBound = '1';
      button.addEventListener('click', async () => {
        const revoke = button.dataset.adminRevoke || '';
        const plan = revoke || button.dataset.adminPlan; const id = button.dataset.adminUser; const days = Number(button.dataset.adminDays) || null;
        const label = revoke ? 'Thu hồi toàn bộ gói Pro/Premium của tài khoản này?' : plan === 'pro' ? (days ? `Cấp Pro ${days} ngày cho tài khoản này?` : 'Cấp gói Pro 1 năm cho tài khoản này?') : 'Cấp Premium trọn đời cho tài khoản này?';
        if (!confirm(label)) return;
        button.disabled = true;
        try {
          const body = revoke ? { action: 'revoke', plan: 'all' } : { action: 'grant', plan, ...(days ? { days } : {}) };
          const data = await socialApi(`/admin/users/${encodeURIComponent(id)}/plan`, { method: 'PATCH', body: JSON.stringify(body) });
          toast(data.message || 'Đã cập nhật gói.', 'success');
          await loadAdminDashboard($('#adminSearchName')?.value || '');
        } catch (error) { socialHandleError(error); button.disabled = false; }
      });
    });
    $$('[data-purchase-decision]').forEach(button => { if (button.dataset.purchaseBound === '1') return; button.dataset.purchaseBound = '1'; button.addEventListener('click', async () => { const action = button.dataset.purchaseDecision; const id = button.dataset.purchaseRequestId; const promptText = action === 'confirm-pro' ? 'Chỉ tiếp tục nếu đã xác nhận nhận đủ 1.000đ. Máy chủ sẽ cấp quyền Pro đúng 3 giờ. Tiếp tục?' : action === 'grant-premium' ? 'Chỉ tiếp tục nếu bạn đã thống nhất với người chơi. Máy chủ sẽ cấp Premium trọn đời. Tiếp tục?' : action === 'contacted' ? 'Đánh dấu đã liên hệ Premium? Điều này KHÔNG cấp Premium.' : 'Từ chối yêu cầu gói này?'; if (!confirm(promptText)) return; button.disabled = true; try { const result = await socialApi(`/admin/purchase-requests/${encodeURIComponent(id)}/decision`, { method: 'POST', body: JSON.stringify({ action }) }); toast(result.message || 'Đã xử lý yêu cầu.', 'success'); await loadAdminDashboard($('#adminSearchName')?.value || ''); } catch (error) { socialHandleError(error); button.disabled = false; } }); });
    $$('[data-purchase-message-user]').forEach(button => { if (button.dataset.messageBound === '1') return; button.dataset.messageBound = '1'; button.addEventListener('click', () => { const id = button.dataset.purchaseMessageUser; const row = purchaseRows.find(item => item.user?.id === id); if (!id) return; activeChatUserId = id; activeChatUser = row?.user || null; setView('chat'); }); });
  } catch (error) { if (metrics) metrics.innerHTML = `<div class="empty-state">${esc(error.message)}. Kiểm tra trạng thái server và phiên admin.</div>`; socialHandleError(error); }
}
function wireAdminActions() {
  $('#refreshAdmin')?.addEventListener('click', () => loadAdminDashboard($('#adminSearchName')?.value || ''));
  $('#adminSearchForm')?.addEventListener('submit', event => { event.preventDefault(); loadAdminDashboard($('#adminSearchName')?.value || ''); });
  $('#adminAnnouncementForm')?.addEventListener('submit', async event => { event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type=submit]'); const status = $('#adminAnnouncementStatus'); button.disabled = true; try { const result = await socialApi('/admin/announcements', { method: 'POST', body: JSON.stringify({ title: $('#adminAnnouncementTitle').value, message: $('#adminAnnouncementMessage').value }) }); if (status) status.textContent = result.message || 'Đã gửi thông báo.'; $('#adminAnnouncementMessage').value = ''; toast('Đã gửi thông báo vào hộp thư người chơi.', 'success'); } catch (error) { if (status) status.textContent = error.message || 'Không gửi được thông báo.'; } finally { button.disabled = false; } });
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  loadAdminDashboard();
}

function renderHomeMiniBoard() {
  const rows = [
    ['♜','♞','♝','♛','♚','♝','♞','♜'],
    ['♟','♟','♟','♟','♟','♟','♟','♟'],
    ['','','','','','','',''], ['','','','','','','',''],
    ['','','','','','','',''], ['','','','','','','',''],
    ['♙','♙','♙','♙','♙','♙','♙','♙'],
    ['♖','♘','♗','♕','♔','♗','♘','♖'],
  ];
  return `<div class="home-mini-board" aria-hidden="true">${rows.map((row, r) => row.map((piece, c) => `<span class="home-mini-square ${((r + c) % 2) ? 'is-dark' : 'is-light'} ${r < 2 ? 'is-black' : 'is-white'}">${piece}</span>`).join('')).join('')}</div>`;
}

function renderHomeMall() {
  let coins = 0;
  try { coins = Math.max(0, Number(readDailyProgress()?.coins || 0)); } catch {}
  const departments = [
    { id: 'play', icon: 'sword', title: 'Sảnh thi đấu', note: 'Chơi ngay', items: [['play', 'pawn', 'Chơi với bot'], ['ranked', 'trophy', 'Ghép trận Elo'], ['lichess', 'globe', 'Chơi Lichess'], ['arena', 'robot', 'Đấu trường AI'], ['games', 'gamepad', 'Mini-game']] },
    { id: 'learn', icon: 'book', title: 'Học viện', note: 'Luyện tập', items: [['puzzles', 'puzzle', 'Câu đố'], ['lessons', 'book', 'Bài học'], ['openings', 'crown', 'Khai cuộc'], ['coach', 'chart', 'Phân tích ván'], ['history', 'history', 'Lịch sử ván']] },
    { id: 'community', icon: 'users', title: 'Cộng đồng', note: 'Kết nối', items: [['friends', 'users', 'Bạn bè'], ['leaderboard', 'medal', 'Top người chơi'], ['club', 'rook', 'Câu lạc bộ'], ['chat', 'chat', 'Tin nhắn'], ['inbox', 'bell', 'Hộp thư']] },
    { id: 'rewards', icon: 'gem', title: 'Quầy ưu đãi', note: 'Thưởng & gói', items: [['plans', 'gem', 'Gói Pro / Premium'], ['shop', 'coin', 'Cửa hàng xu'], ['missions', 'star', 'Nhiệm vụ'], ['achievements', 'award', 'Thành tựu']] },
    { id: 'tools', icon: 'gear', title: 'Dịch vụ', note: 'Tiện ích', items: [['settings', 'gear', 'Cài đặt'], ['health', 'check', 'Kiểm tra hệ thống'], ['profile', 'user', 'Hồ sơ']] },
  ];
  const floors = departments.map(dep => `<section class="mall-floor mall-floor-${dep.id}" aria-label="${esc(dep.title)}"><header class="mall-floor-head"><span class="mall-floor-icon">${uiIcon(dep.icon)}</span><span><b>${esc(dep.title)}</b><small>${esc(dep.note)}</small></span></header><div class="mall-floor-items">${dep.items.map(([view, icon, label]) => `<button type="button" class="mall-shop" data-home-view="${view}"><i class="mall-ico">${uiIcon(icon)}</i><span>${esc(label)}</span></button>`).join('')}</div></section>`).join('');
  return `<section class="home-mall" aria-label="Trung tâm VILA">
    <div class="home-section-heading"><div><span class="home-kicker">TRUNG TÂM VILA</span><h2>Mọi thứ về cờ vua, một nơi</h2></div><span class="home-heading-note">${departments.reduce((n, d) => n + d.items.length, 0)} gian hàng</span></div>
    <div class="mall-promo-strip">
      <button type="button" class="mall-promo mall-promo-plan" data-home-view="plans"><span class="mall-promo-tag">GÓI THÀNH VIÊN</span><b>Pro &amp; Premium</b><small>Mở khóa xem lại phân tích đầy đủ</small><strong>Xem gói →</strong></button>
      <button type="button" class="mall-promo mall-promo-shop" data-home-view="shop"><span class="mall-promo-tag">VÍ XU</span><b>${coins} xu</b><small>Đổi lượt phân tích, Pro dùng thử 3 giờ</small><strong>Vào cửa hàng →</strong></button>
      <button type="button" class="mall-promo mall-promo-mission" data-home-view="missions"><span class="mall-promo-tag">HẰNG NGÀY</span><b>Nhiệm vụ &amp; thưởng</b><small>Hoàn thành để nhận thêm xu</small><strong>Làm nhiệm vụ →</strong></button>
    </div>
    <div class="mall-floors">${floors}</div>
  </section>`;
}

function renderHomeView() {
  const profile = readRatingProfile();
  const gamesPlayed = Math.max(0, Number(profile.games || 0));
  const winRate = gamesPlayed ? Math.round(Number(profile.wins || 0) / gamesPlayed * 100) : 0;
  const puzzleSolved = Math.max(0, Number(puzzleState?.solvedCount || 0));
  const puzzleBest = Math.max(0, Number(puzzleState?.bestStreak || 0));
  const isOnline = typeof navigator !== 'undefined' && navigator.onLine;
  return `<section class="home-hub content-page" aria-label="Trang chủ Cờ Vua VILA">
    <header class="home-welcome">
      <div class="home-welcome-copy">
        <span class="home-greeting-eyebrow">CHÀO MỪNG TRỞ LẠI · VILA CHESS CLUB</span>
        <h1>Chơi hay hơn<br><em>mỗi ngày.</em></h1>
        <p>Chơi bot mạnh, luyện puzzle và phân tích ván — mượt trên điện thoại, chạy được cả khi offline.</p>
        <span class="home-connection"><i class="${isOnline ? 'is-online' : ''}"></i>${isOnline ? 'Đã kết nối mạng' : 'Chế độ ngoại tuyến sẵn sàng'} <span>·</span> Stockfish cục bộ</span>
      </div>
      <div class="home-profile-card"><div class="home-avatar-3d home-avatar-image"><img src="./vila-chess-avatar.svg?v=3500" alt="Avatar thương hiệu Cờ Vua" width="76" height="76" loading="eager" decoding="async"></div><small>ELO XẾP HẠNG ONLINE</small><b>${socialState.user ? Number(socialState.user.elo || 500) : '—'}</b><span>Bot không tính Elo</span><button type="button" class="home-profile-link" data-home-view="profile">Xem hồ sơ <span>↗</span></button></div>
    </header>

    <div class="home-one-tap" aria-label="Chơi nhanh theo Elo">
      <button type="button" class="home-one-tap-btn" data-home-elo="800" data-home-clock="3+2">Bot 800 · 3+2</button>
      <button type="button" class="home-one-tap-btn" data-home-elo="1200" data-home-clock="3+2">Bot 1200 · 3+2</button>
      <button type="button" class="home-one-tap-btn primary" data-home-elo="1600" data-home-clock="5+0">Bot 1600 · 5+0</button>
      <button type="button" class="home-one-tap-btn" data-home-elo="2000" data-home-clock="10+0">Bot 2000 · 10+0</button>
      <button type="button" class="home-one-tap-btn" data-home-action="daily-puzzle">Puzzle hôm nay</button>
      <button type="button" class="home-one-tap-btn" data-home-action="last-review">Xem lại ván gần nhất</button>
    </div>
    <nav class="home-quick-modes" aria-label="Lối tắt chế độ chính">
      <button type="button" class="home-quick-mode is-selected" data-home-action="quickplay"><span class="hq-ico">${uiIcon('sword')}</span><b>Chơi cờ</b></button>
      <button type="button" class="home-quick-mode" data-home-view="arena"><span class="hq-ico">${uiIcon('robot')}</span><b>Đấu bot</b></button>
      <button type="button" class="home-quick-mode" data-home-view="coach"><span class="hq-ico">${uiIcon('chart')}</span><b>Phân tích</b></button>
      <button type="button" class="home-quick-mode" data-home-view="history"><span class="hq-ico">${uiIcon('history')}</span><b>Lịch sử</b></button>
      <button type="button" class="home-quick-mode" data-home-view="settings"><span class="hq-ico">${uiIcon('gear')}</span><b>Cài đặt</b></button>
    </nav>

    ${renderHomeMall()}
    <section class="home-feature-grid" aria-label="Bắt đầu chơi">
      <article class="home-play-feature">
        <div class="home-play-copy"><span class="home-kicker"><i></i> GỢI Ý CHO BẠN</span><h2>Sẵn sàng cho<br>một ván mới?</h2><p>Thách đấu Stockfish, chọn thời gian và bước vào bàn cờ khi bạn đã sẵn sàng.</p><button type="button" class="home-cta-primary" data-home-action="quickplay"><span>▶</span> Chơi ngay <b>→</b></button><button type="button" class="home-cta-secondary" data-home-view="play">Tùy chỉnh ván đấu</button></div>
        <div class="home-play-art">${renderHomeMiniBoard()}<span class="home-piece-float home-float-queen">♛</span><span class="home-piece-float home-float-knight">♘</span></div>
      </article>
      <button type="button" class="home-daily-feature" data-home-view="puzzles"><span class="home-daily-icon">✦</span><span class="home-kicker">THỬ THÁCH HÔM NAY</span><b>Giải một thế cờ</b><small>Từ dễ đến khó, liên tục luyện tập</small><span class="home-daily-progress"><span style="width:${Math.min(100, puzzleSolved * 10)}%"></span></span><span class="home-daily-foot"><span>${puzzleSolved} câu đã giải</span><strong>Vào luyện tập ↗</strong></span></button>
    </section>

    <div class="home-section-heading"><div><span class="home-kicker">CHỌN CHẾ ĐỘ</span><h2>Chơi theo cách của bạn</h2></div><span class="home-heading-note">9 chế độ</span></div>
    <section class="home-mode-grid" aria-label="Các chế độ cờ vua">
      <button type="button" class="home-mode-card mode-play" data-home-action="quickplay"><span class="home-mode-icon icon-crossed">${uiIcon('sword')}</span><span class="home-mode-text"><b>Chơi cờ</b><small>Vào ván mới với Stockfish</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-bot" data-home-view="arena"><span class="home-mode-icon icon-bot">${uiIcon('robot')}</span><span class="home-mode-text"><b>Đấu bot</b><small>AI đa phong cách</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-analysis" data-home-view="coach"><span class="home-mode-icon icon-analysis">${uiIcon('chart')}</span><span class="home-mode-text"><b>Phân tích ván</b><small>Xem lại từng nước & thế cờ</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-history" data-home-view="history"><span class="home-mode-icon icon-history">${uiIcon('history')}</span><span class="home-mode-text"><b>Lịch sử ván</b><small>Xem lại từng nước & đồng bộ</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-settings" data-home-view="settings"><span class="home-mode-icon icon-settings">${uiIcon('gear')}</span><span class="home-mode-text"><b>Cài đặt</b><small>Âm thanh, nhạc, độ khó và tuỳ chỉnh</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-puzzle" data-home-view="puzzles"><span class="home-mode-icon icon-puzzle">${uiIcon('puzzle')}</span><span class="home-mode-text"><b>Câu đố</b><small>Rèn chiến thuật cờ vua</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-lessons" data-home-view="openings"><span class="home-mode-icon icon-lessons">${uiIcon('book')}</span><span class="home-mode-text"><b>Bài học & khai cuộc</b><small>${OPENINGS.length.toLocaleString()} biến mẫu ECO</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-ranked" data-home-view="ranked"><span class="home-mode-icon icon-online">${uiIcon('trophy')}</span><span class="home-mode-text"><b>Ghép trận người thật</b><small>Elo Bullet, Blitz, Rapid</small></span><span class="home-mode-arrow">↗</span></button>
      <button type="button" class="home-mode-card mode-online" data-home-view="lichess"><span class="home-mode-icon icon-online">${uiIcon('globe')}</span><span class="home-mode-text"><b>Chơi qua Lichess</b><small>Kết nối tài khoản Lichess</small></span><span class="home-mode-arrow">↗</span></button>
    </section>

    <section class="home-arena-promo">
      <div class="home-arena-copy"><span class="home-kicker">VILA AI ARENA</span><h2>Hai bot. Một bàn cờ.</h2><p>Chọn phong cách và cấp tìm kiếm, xem cả trận đấu và mở phân tích sau khi kết thúc.</p><button type="button" class="home-cta-secondary" data-home-view="arena">Khám phá đấu trường <b>→</b></button></div>
      <div class="home-bot-duel" aria-hidden="true"><span class="home-bot-avatar stockfish-avatar">♜</span><span class="home-versus">VS</span><span class="home-bot-avatar vila-avatar">♞</span><div class="home-bot-labels"><span>STOCKFISH</span><span>VILA BOT</span></div></div>
    </section>

    <div class="home-section-heading"><div><span class="home-kicker">LUYỆN TẬP HẰNG NGÀY</span><h2>Thêm một chút thử thách</h2></div><button type="button" class="home-text-link" data-home-view="openings">Xem tất cả ↗</button></div>
    <section class="home-training-grid">
      <button type="button" class="home-training-card training-openings" data-home-view="openings"><span class="training-art">♕</span><span><b>Khám phá khai cuộc</b><small>Tìm tên, ECO và các nước đi</small></span><strong>→</strong></button>
      <button type="button" class="home-training-card training-analysis" data-home-view="coach"><span class="training-art">⌁</span><span><b>Xem lại ván cờ</b><small>Đánh giá nước hay, sai lầm, bỏ lỡ</small></span><strong>→</strong></button>
      <button type="button" class="home-training-card training-games" data-home-view="games"><span class="training-art">▦</span><span><b>Góc giải trí</b><small>Rubik 3D, 2048, trượt số và lật thẻ</small></span><strong>→</strong></button>
    </section>

    <section class="home-progress-panel"><div class="home-progress-heading"><div><span class="home-kicker">TIẾN BỘ CỦA BẠN</span><h2>Thành tích trên thiết bị</h2></div><span class="home-progress-icon">♛</span></div><div class="home-progress-stats"><div><small>ELO ONLINE</small><b>${socialState.user ? Number(socialState.user.elo || 500) : '—'}</b></div><div><small>VÁN ĐẤU</small><b>${gamesPlayed}</b></div><div><small>TỈ LỆ THẮNG</small><b>${winRate}%</b></div><div><small>CHUỖI CÂU ĐỐ</small><b>${puzzleBest}</b></div></div><p class="home-footnote">Điểm Elo và lịch sử cờ cục bộ được lưu trên máy. Ghép trận xếp hạng trực tuyến cần server cộng đồng được cấu hình; không có máy chủ thì vẫn chơi offline bình thường.</p></section>
    <section class="vila-flower-stage" aria-label="Hoa tỏa sắc màu hoạt họa">
      <div class="vila-flower-visual" aria-hidden="true"><span class="petal p1"></span><span class="petal p2"></span><span class="petal p3"></span><span class="petal p4"></span><span class="petal p5"></span><span class="petal p6"></span><span class="flower-core"></span></div>
      <div class="vila-flower-copy"><span class="home-kicker">VILA COLOR GARDEN</span><h2>Hoa nở — sắc màu chuyển động</h2><p>Hoạt họa nhẹ, không tải video nặng; tối ưu cho WebView và tôn trọng cài đặt giảm chuyển động.</p></div>
    </section>
    ${musicLibraryMarkup({ compact: true })}
  </section>`;
}
const RUBIK_FACES = [
  { id: 'U', label: 'Trên', transform: 'rotateX(90deg) translateZ(var(--cube-half))' },
  { id: 'D', label: 'Dưới', transform: 'rotateX(-90deg) translateZ(var(--cube-half))' },
  { id: 'F', label: 'Trước', transform: 'translateZ(var(--cube-half))' },
  { id: 'B', label: 'Sau', transform: 'rotateY(180deg) translateZ(var(--cube-half))' },
  { id: 'R', label: 'Phải', transform: 'rotateY(90deg) translateZ(var(--cube-half))' },
  { id: 'L', label: 'Trái', transform: 'rotateY(-90deg) translateZ(var(--cube-half))' },
];
function renderRubikFaceMarkup(face) {
  const colors = getRubikFaceStickers(rubikCube, face);
  return `<div class="rubik-face rubik-face-${face}" data-rubik-face="${face}" style="transform:${RUBIK_FACES.find(item => item.id === face)?.transform || ''}" aria-label="Mặt ${RUBIK_FACES.find(item => item.id === face)?.label || face}">${colors.map((color, index) => `<span class="rubik-sticker rubik-color-${color}" data-sticker-index="${index}"></span>`).join('')}</div>`;
}
function renderRubikGame() {
  const solved = isRubikSolved(rubikCube);
  return `<section class="games-layout rubik-game-layout">
    <article class="panel rubik-play-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Rubik 3×3</h2><p>Xoay mặt bằng cách vuốt trên khối, hoặc chọn ký hiệu bên dưới. Chế độ “Xoay góc nhìn” để xoay cả khối.</p></div><span class="game-emblem rubik-emblem">▦</span></div>
      <div class="rubik-stage ${rubikViewMode === 'view' ? 'rubik-view-mode' : 'rubik-turn-mode'}" id="rubikStage" role="application" aria-label="Khối Rubik tương tác" style="--cube-size:min(54vw, 230px);--cube-half:calc(var(--cube-size) / 2)"><div class="rubik-cube" id="rubikCube" style="transform:rotateX(${rubikRotationX}deg) rotateY(${rubikRotationY}deg)">${RUBIK_FACES.map(face => renderRubikFaceMarkup(face.id)).join('')}</div><span class="rubik-stage-hint">${rubikViewMode === 'view' ? 'Vuốt để xoay góc nhìn' : 'Vuốt lên/xuống hoặc trái/phải để xoay mặt'}</span></div>
      <div class="rubik-status-row" id="rubikStatusRow"><span class="rubik-status-dot ${solved ? 'is-solved' : ''}"></span><b>${solved ? 'Đã giải hoàn chỉnh' : 'Đang xáo trộn'}</b><span id="rubikMoveCounter">${rubikMoveCount} lượt xoay</span><span class="rubik-timer" id="rubikTimer" aria-label="Thời gian giải">⏱ ${formatRubikTime(rubikTimerElapsed)}</span><span class="rubik-best" id="rubikBest">${rubikBestMs ? `Kỷ lục ${formatRubikTime(rubikBestMs)}` : 'Chưa có kỷ lục'}</span></div>
      <div class="rubik-main-actions"><button type="button" class="primary-btn" id="rubikScramble">⤨ Xáo trộn tự động</button><button type="button" class="secondary-btn" id="rubikViewToggle">${rubikViewMode === 'view' ? '↻ Đang xoay góc nhìn' : '◉ Xoay góc nhìn'}</button><button type="button" class="secondary-btn" id="rubikUndo" ${rubikMoveHistory.length ? '' : 'disabled'}>↶ Hoàn tác</button><button type="button" class="secondary-btn" id="rubikReset">↺ Làm mới</button></div>
      <div class="rubik-turn-pad"><div class="rubik-turn-heading"><b>Xoay từng mặt</b><small>Ký hiệu quốc tế · chạm hoặc vuốt</small></div><div class="rubik-turn-grid">${['U','U\'','D','D\'','L','L\'','R','R\'','F','F\'','B','B\''].map(move => `<button type="button" class="rubik-turn-btn" data-rubik-move="${move}" aria-label="Xoay mặt ${move}">${move}</button>`).join('')}</div></div>
      <div class="rubik-history"><span>Chuỗi hiện tại</span><code>${rubikMoveHistory.length ? esc(rubikMoveHistory.slice(-16).join(' ')) : 'Chưa có nước xoay'}</code></div>
    </article>
    <aside class="games-side-column"><section class="panel games-help-card"><span class="game-emblem">✦</span><h3>Cách chơi</h3><p>Chạm <b>Xáo trộn tự động</b> để tạo một bài mới. Trong chế độ xoay mặt, vuốt trực tiếp trên một mặt hoặc dùng nút U/D/L/R/F/B. Dấu nháy (') là xoay ngược chiều.</p><p>Khối và quy tắc xoay chạy ngay trên máy, không cần tài khoản hay kết nối mạng.</p></section><section class="panel games-help-card"><span class="game-emblem">🏁</span><h3>Mục tiêu</h3><p>Đưa 9 ô của mỗi mặt về cùng màu. Khi cả 6 mặt đồng màu, VILA xác nhận đã giải xong.</p><button type="button" class="secondary-btn full-width" data-games-mode="2048">Thử 2048 →</button><button type="button" class="secondary-btn full-width" data-games-mode="memory">Thử ghi nhớ →</button></section></aside>
  </section>`;
}

function render2048Game() {
  try { game2048Best = Math.max(game2048Best, Number(localStorage.getItem('vila.mini2048.best') || 0)); } catch {}
  const over = !has2048Moves(game2048Board);
  return `<section class="games-layout simple-game-layout"><article class="panel game2048-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>2048</h2><p>Vuốt hoặc dùng phím mũi tên để gộp các ô số giống nhau.</p></div><span class="game-emblem game2048-emblem">2048</span></div><div class="score-row"><div><small>ĐIỂM</small><b>${game2048Score}</b></div><div><small>KỶ LỤC TRÊN MÁY</small><b>${game2048Best}</b></div><button type="button" id="game2048Restart" class="secondary-btn">Ván mới ↺</button></div><div id="game2048Grid" class="game2048-grid" role="grid" aria-label="Bàn 2048">${game2048Board.map((value, index) => `<div class="game2048-tile tile-${value || 0}" role="gridcell" aria-label="${value || 'trống'}">${value || ''}</div>`).join('')}${over ? '<div class="game2048-overlay"><b>Hết nước đi</b><button type="button" id="game2048RestartOverlay" class="primary-btn">Thử lại</button></div>' : ''}</div><div class="game2048-controls"><button type="button" data-2048-dir="up">↑</button><div><button type="button" data-2048-dir="left">←</button><button type="button" data-2048-dir="down">↓</button><button type="button" data-2048-dir="right">→</button></div></div></article><aside class="panel games-help-card"><span class="game-emblem">✦</span><h3>Luật chơi</h3><p>Gộp hai ô cùng số để tạo ô có giá trị gấp đôi. Mỗi lượt có thay đổi sẽ thêm một ô mới. Đạt 2048 để thắng; có thể tiếp tục chơi sau đó.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">← Quay lại Rubik</button><button class="secondary-btn full-width" type="button" data-games-mode="memory">Lật thẻ ghi nhớ →</button></aside></section>`;
}
function ensureMemoryDeck() {
  if (memoryDeck.length) return;
  const symbols = ['♞','♝','♜','♛','♚','♟','★','◆'];
  memoryDeck = [...symbols, ...symbols].map((symbol, index) => ({ id: `${symbol}-${index}`, symbol, pair: symbol }));
  for (let i = memoryDeck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [memoryDeck[i], memoryDeck[j]] = [memoryDeck[j], memoryDeck[i]];
  }
}
function renderMemoryGame() {
  ensureMemoryDeck();
  const won = memoryMatched.size === memoryDeck.length;
  return `<section class="games-layout simple-game-layout"><article class="panel memory-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Lật thẻ ghi nhớ</h2><p>Tìm các cặp giống nhau với ít lượt lật nhất.</p></div><span class="game-emblem">◆</span></div><div class="score-row"><div><small>LƯỢT LẬT</small><b>${memoryMoves}</b></div><div><small>ĐÃ TÌM</small><b>${memoryMatched.size / 2}/8 cặp</b></div><button type="button" class="secondary-btn" id="memoryRestart">Ván mới ↺</button></div><div class="memory-grid" aria-label="Bộ thẻ ghi nhớ">${memoryDeck.map(card => { const revealed = memorySelected.includes(card.id) || memoryMatched.has(card.id); return `<button type="button" class="memory-card ${revealed ? 'is-revealed' : ''} ${memoryMatched.has(card.id) ? 'is-matched' : ''}" data-memory-card="${card.id}" aria-label="${revealed ? `Thẻ ${card.symbol}` : 'Thẻ úp'}" ${revealed || memoryLock ? 'disabled' : ''}>${revealed ? card.symbol : '✦'}</button>`; }).join('')}</div>${won ? '<div class="game-win-message">Tuyệt vời! Bạn đã tìm đủ 8 cặp.</div>' : ''}</article><aside class="panel games-help-card"><span class="game-emblem">✦</span><h3>Rèn trí nhớ</h3><p>Lật hai thẻ mỗi lượt. Nếu giống nhau, cặp đó sẽ được giữ mở; nếu khác nhau, thẻ sẽ úp lại sau một nhịp ngắn.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">← Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">Chơi 2048 →</button></aside></section>`;
}
function renderSlidingPuzzleGame() {
  const solved = isSlidingPuzzleSolved(slidingPuzzleBoard);
  return `<section class="games-layout simple-game-layout"><article class="panel sliding-puzzle-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Trượt số 15</h2><p>Chạm ô nằm cạnh khoảng trống để di chuyển. Bảng được xáo trộn bằng nước hợp lệ nên luôn giải được.</p></div><span class="game-emblem">▦</span></div><div class="score-row"><div><small>SỐ NƯỚC</small><b>${slidingPuzzleMoves}</b></div><div><small>TRẠNG THÁI</small><b>${solved ? 'Hoàn thành' : 'Đang chơi'}</b></div><button type="button" class="secondary-btn" id="slidingPuzzleRestart">Xáo trộn ↺</button></div><div class="sliding-puzzle-grid" role="grid" aria-label="Trò trượt số 15">${slidingPuzzleBoard.map((value, index) => value ? `<button type="button" role="gridcell" class="sliding-puzzle-tile" data-sliding-tile="${index}" aria-label="Ô số ${value}">${value}</button>` : `<span role="gridcell" class="sliding-puzzle-empty" aria-label="Ô trống"></span>`).join('')}</div>${solved ? '<div class="game-win-message">Xuất sắc! Bạn đã sắp xếp toàn bộ số.</div>' : ''}</article><aside class="panel games-help-card"><span class="game-emblem">15</span><h3>Trò xếp số</h3><p>Đưa các ô 1 đến 15 về đúng thứ tự, ô trống ở góc dưới bên phải. Mỗi lần chạm chỉ di chuyển một ô hợp lệ.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">2048</button></aside></section>`;
}
function renderCoordinateGame() {
  const targetFile = coordinateTargetSquare[0];
  const targetRank = Number(coordinateTargetSquare[1]);
  const squares = [];
  for (let rank = 8; rank >= 1; rank--) {
    for (let fileIndex = 0; fileIndex < 8; fileIndex++) {
      const file = CHESS_FILES[fileIndex];
      const name = `${file}${rank}`;
      const light = ((8 - rank) + fileIndex) % 2 === 0;
      squares.push(`<button type="button" class="coordinate-square ${light ? 'is-light' : 'is-dark'}" data-coordinate-square="${name}" aria-label="Ô ${name}">${fileIndex === 0 ? `<small>${rank}</small>` : ''}${rank === 1 ? `<i>${file}</i>` : ''}</button>`);
    }
  }
  return `<section class="games-layout simple-game-layout"><article class="panel coordinate-game-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · LUYỆN CỜ</span><h2>Phản xạ tọa độ</h2><p>Đọc ô được gọi tên rồi chạm đúng trên bàn cờ để tăng điểm và chuỗi liên tiếp.</p></div><span class="game-emblem">⌖</span></div><div class="coordinate-challenge"><small>HÃY TÌM Ô</small><strong>${targetFile}${targetRank}</strong><span id="coordinateFeedback" aria-live="polite">${esc(coordinateFeedback)}</span></div><div class="coordinate-score-row"><div><small>ĐIỂM</small><b>${coordinateScore}</b></div><div><small>CHUỖI</small><b>${coordinateStreak}</b></div><div><small>KỶ LỤC</small><b>${coordinateBest}</b></div><button type="button" id="coordinateRestart" class="secondary-btn">Làm mới ↺</button></div><div id="coordinateBoard" class="coordinate-board" role="grid" aria-label="Bàn cờ luyện tọa độ">${squares.join('')}</div></article><aside class="panel games-help-card"><span class="game-emblem">♞</span><h3>Nhớ tọa độ nhanh</h3><p>Các chữ a–h là cột, số 1–8 là hàng. Bàn cờ luôn hiển thị từ phía Trắng, giống cách đọc tọa độ tiêu chuẩn.</p><button class="secondary-btn full-width" type="button" data-games-mode="memory">Lật thẻ ghi nhớ →</button><button class="secondary-btn full-width" type="button" data-games-mode="tictactoe">Cờ ca-rô →</button></aside></section>`;
}
function handleCoordinateSquare(square) {
  if (!/^[a-h][1-8]$/.test(String(square || ''))) return;
  if (square === coordinateTargetSquare) {
    coordinateScore += 1;
    coordinateStreak += 1;
    coordinateBest = Math.max(coordinateBest, coordinateStreak);
    coordinateFeedback = `Chính xác! ${square} · +1 điểm.`;
    recordDailyEvent('play_mini_game');
    try { localStorage.setItem('vila.coordinate.best', String(coordinateBest)); } catch {}
  } else {
    coordinateStreak = 0;
    coordinateFeedback = `Chưa đúng — bạn đã chạm ${square}. Hãy tìm ${coordinateTargetSquare}.`;
  }
  coordinateTargetSquare = randomCoordinateSquare(coordinateTargetSquare);
  if (currentView === 'games' && gamesMode === 'coordinates') renderView();
}
function resetCoordinateGame() {
  coordinateTargetSquare = randomCoordinateSquare();
  coordinateScore = 0; coordinateStreak = 0; coordinateFeedback = 'Bắt đầu lại! Tìm ô được gọi tên.';
  if (currentView === 'games') renderView();
}

function renderTicTacToeGame() {
  const outcome = ticTacToeResult || ticTacToeOutcome(ticTacToeBoard);
  const outcomeText = outcome === 'X' ? 'Bạn thắng!' : outcome === 'O' ? 'Bot thắng ván này.' : outcome === 'draw' ? 'Hòa cờ.' : ticTacToeThinking ? 'Bot đang tính nước…' : 'Bạn đi trước bằng dấu X.';
  return `<section class="games-layout simple-game-layout"><article class="panel tictactoe-panel"><div class="game-card-title"><div><span class="eyebrow">VILA MINI-GAMES · OFFLINE</span><h2>Cờ ca-rô 3×3</h2><p>Đấu với bot cục bộ có tìm kiếm minimax; bot không mắc lỗi chiến thuật cơ bản.</p></div><span class="game-emblem">✕○</span></div><div class="tictactoe-score-row"><span class="tictactoe-status" aria-live="polite">${esc(outcomeText)}</span><button type="button" id="ticTacToeRestart" class="secondary-btn">Ván mới ↺</button></div><div class="tictactoe-grid" role="grid" aria-label="Bàn cờ ca-rô 3 nhân 3">${ticTacToeBoard.map((mark, index) => `<button type="button" role="gridcell" class="tictactoe-square ${mark ? `mark-${mark.toLowerCase()}` : ''}" data-ttt-square="${index}" aria-label="Ô ${index + 1}${mark ? `: ${mark}` : ': trống'}" ${mark || outcome || ticTacToeThinking ? 'disabled' : ''}>${mark || ''}</button>`).join('')}</div><p class="tictactoe-note">Lưu ý: bot ca-rô là trò chơi giải trí riêng, không liên quan Elo cờ vua hay Stockfish.</p></article><aside class="panel games-help-card"><span class="game-emblem">♟</span><h3>Đấu trí nhanh</h3><p>Đặt ba dấu liền hàng, cột hoặc chéo để thắng. Bot sử dụng tìm kiếm toàn bộ trạng thái 3×3 nên chơi tối ưu.</p><button class="secondary-btn full-width" type="button" data-games-mode="rubik">Rubik 3×3</button><button class="secondary-btn full-width" type="button" data-games-mode="2048">Chơi 2048</button></aside></section>`;
}
function handleTicTacToeMove(index) {
  if (!Number.isInteger(index) || index < 0 || index > 8 || ticTacToeBoard[index] || ticTacToeResult || ticTacToeThinking) return;
  ticTacToeBoard[index] = 'X';
  recordDailyEvent('play_mini_game');
  ticTacToeResult = ticTacToeOutcome(ticTacToeBoard) || '';
  if (ticTacToeResult) { renderView(); return; }
  ticTacToeThinking = true;
  renderView();
  setTimeout(() => {
    if (currentView !== 'games' || gamesMode !== 'tictactoe') { ticTacToeThinking = false; return; }
    const move = chooseTicTacToeMove(ticTacToeBoard);
    if (move >= 0 && !ticTacToeBoard[move]) ticTacToeBoard[move] = 'O';
    ticTacToeResult = ticTacToeOutcome(ticTacToeBoard) || '';
    ticTacToeThinking = false;
    if (ticTacToeResult) recordDailyEvent('play_mini_game');
    renderView();
  }, 120);
}
function resetTicTacToe() { ticTacToeBoard = Array(9).fill(''); ticTacToeResult = ''; ticTacToeThinking = false; renderView(); }

function renderGamesView() {
  const modes = [{ id: 'rubik', icon: '▦', label: 'Rubik 3×3' }, { id: '2048', icon: '2048', label: '2048' }, { id: 'memory', icon: '◆', label: 'Ghi nhớ' }, { id: 'sliding', icon: '15', label: 'Trượt số' }, { id: 'tictactoe', icon: '✕○', label: 'Cờ ca-rô' }, { id: 'coordinates', icon: '⌖', label: 'Tọa độ' }];
  const body = gamesMode === '2048' ? render2048Game() : gamesMode === 'memory' ? renderMemoryGame() : gamesMode === 'sliding' ? renderSlidingPuzzleGame() : gamesMode === 'tictactoe' ? renderTicTacToeGame() : gamesMode === 'coordinates' ? renderCoordinateGame() : renderRubikGame();
  return `<section class="content-page vila-games-page"><div class="games-page-heading"><div><span class="eyebrow">KHU GIẢI TRÍ · CHƠI NGOẠI TUYẾN</span><h1>Mini-game</h1><p>Trò chơi gọn nhẹ, tối ưu chạm trên Android.</p></div><span class="games-status-pill"><i></i> Chạy cục bộ</span></div><nav class="games-mode-tabs" aria-label="Chọn mini-game">${modes.map(item => `<button type="button" class="games-mode-tab ${gamesMode === item.id ? 'active' : ''}" data-games-mode="${item.id}"><span>${item.icon}</span>${item.label}</button>`).join('')}</nav>${body}</section>`;
}
function applyGamesMove2048(direction) {
  const result = move2048(game2048Board, direction);
  if (!result.changed) return;
  recordDailyEvent('play_mini_game');
  game2048Board = result.board;
  game2048Score += result.score;
  if (result.won) toast('Đạt ô 2048! Bạn có thể tiếp tục chơi.', 'success');
  game2048Best = Math.max(game2048Best, game2048Score);
  try { localStorage.setItem('vila.mini2048.best', String(game2048Best)); } catch {}
  if (currentView === 'games' && gamesMode === '2048') renderView();
}
function reset2048Game() { game2048Board = create2048Board(); game2048Score = 0; if (currentView === 'games') renderView(); }
function formatRubikTime(ms) {
  const total = Math.max(0, Math.floor(Number(ms) / 100) / 10);
  const minutes = Math.floor(total / 60);
  const seconds = (total - minutes * 60).toFixed(1).padStart(4, '0');
  return `${minutes}:${seconds}`;
}
function stopRubikTimer() {
  if (rubikTimerId) { clearInterval(rubikTimerId); rubikTimerId = null; }
  if (rubikTimerStart) rubikTimerElapsed = Date.now() - rubikTimerStart;
  rubikTimerStart = 0;
}
function startRubikTimerIfArmed() {
  if (!rubikTimerArmed || rubikTimerId) return;
  rubikTimerArmed = false; rubikTimerStart = Date.now(); rubikTimerElapsed = 0;
  rubikTimerId = setInterval(() => {
    if (currentView !== 'games' || gamesMode !== 'rubik' || !$('#rubikTimer')) { stopRubikTimer(); return; }
    rubikTimerElapsed = Date.now() - rubikTimerStart;
    const el = $('#rubikTimer'); if (el) el.textContent = `⏱ ${formatRubikTime(rubikTimerElapsed)}`;
  }, 100);
}
/** Patch the existing cube DOM in place so a turn does not rebuild the whole view (no flicker, keeps the view angle). */
function updateRubikDom(animateFace = '') {
  const cube = $('#rubikCube');
  if (!cube) return false;
  for (const face of RUBIK_FACES) {
    const el = cube.querySelector(`[data-rubik-face="${face.id}"]`);
    if (!el) return false;
    const colors = getRubikFaceStickers(rubikCube, face.id);
    el.querySelectorAll('.rubik-sticker').forEach((sticker, index) => { sticker.className = `rubik-sticker rubik-color-${colors[index]}`; });
  }
  if (animateFace) {
    const el = cube.querySelector(`[data-rubik-face="${animateFace}"]`);
    if (el) { el.classList.remove('rubik-pulse'); void el.offsetWidth; el.classList.add('rubik-pulse'); }
  }
  const solved = isRubikSolved(rubikCube);
  const row = $('#rubikStatusRow');
  if (row) {
    row.querySelector('.rubik-status-dot')?.classList.toggle('is-solved', solved);
    const label = row.querySelector('b'); if (label) label.textContent = solved ? 'Đã giải hoàn chỉnh' : 'Đang xáo trộn';
  }
  const counter = $('#rubikMoveCounter'); if (counter) counter.textContent = `${rubikMoveCount} lượt xoay`;
  const history = document.querySelector('.rubik-history code'); if (history) history.textContent = rubikMoveHistory.length ? rubikMoveHistory.slice(-16).join(' ') : 'Chưa có nước xoay';
  const undo = $('#rubikUndo'); if (undo) undo.disabled = !rubikMoveHistory.length;
  const best = $('#rubikBest'); if (best) best.textContent = rubikBestMs ? `Kỷ lục ${formatRubikTime(rubikBestMs)}` : 'Chưa có kỷ lục';
  return true;
}
function makeRubikMove(move) {
  try {
    recordDailyEvent('play_mini_game');
    startRubikTimerIfArmed();
    rubikCube = applyRubikMove(rubikCube, move);
    rubikMoveHistory.push(move); rubikMoveCount++;
    if (isRubikSolved(rubikCube)) {
      const wasTiming = Boolean(rubikTimerId);
      stopRubikTimer();
      if (wasTiming && rubikTimerElapsed > 0) {
        const newBest = !rubikBestMs || rubikTimerElapsed < rubikBestMs;
        if (newBest) { rubikBestMs = rubikTimerElapsed; try { localStorage.setItem('vila.rubik.best', String(rubikBestMs)); } catch {} }
        toast(`Rubik đã giải xong trong ${formatRubikTime(rubikTimerElapsed)}${newBest ? ' · kỷ lục mới!' : ''}`, 'success');
      } else toast('Rubik đã giải hoàn chỉnh!', 'success');
    }
    if (currentView === 'games' && gamesMode === 'rubik' && !updateRubikDom(String(move).replace("'", '')[0])) renderView();
  } catch (error) { console.warn('[VILA] Rubik move rejected:', error); }
}
function wireGamesActions() {
  if (gamesKeyHandler) window.removeEventListener('keydown', gamesKeyHandler);
  $$('[data-games-mode]').forEach(button => button.addEventListener('click', () => { gamesMode = button.dataset.gamesMode; renderView(); }));
  $$('[data-rubik-move]').forEach(button => button.addEventListener('click', () => makeRubikMove(button.dataset.rubikMove)));
  $('#rubikScramble')?.addEventListener('click', () => {
    recordDailyEvent('play_mini_game');
    stopRubikTimer();
    rubikCube = createSolvedRubikCube(); rubikMoveHistory = []; rubikMoveCount = 0; rubikTimerElapsed = 0;
    const moves = scrambleRubikMoves(25);
    for (const move of moves) rubikCube = applyRubikMove(rubikCube, move);
    // The scramble itself is not counted as player moves; the timer starts on the first player turn.
    rubikTimerArmed = true;
    renderView(); toast('Đã xáo trộn Rubik. Đồng hồ chạy khi bạn xoay lượt đầu tiên.', 'success');
  });
  $('#rubikReset')?.addEventListener('click', () => { stopRubikTimer(); rubikTimerArmed = false; rubikTimerElapsed = 0; rubikCube = createSolvedRubikCube(); rubikMoveHistory = []; rubikMoveCount = 0; renderView(); });
  $('#rubikUndo')?.addEventListener('click', () => { const move = rubikMoveHistory.pop(); if (move) { rubikCube = applyRubikMove(rubikCube, invertRubikMove(move)); rubikMoveCount = Math.max(0, rubikMoveCount - 1); if (!updateRubikDom(String(move).replace("'", '')[0])) renderView(); } });
  $('#rubikViewToggle')?.addEventListener('click', () => { rubikViewMode = rubikViewMode === 'view' ? 'turn' : 'view'; renderView(); });
  const stage = $('#rubikStage');
  if (stage) {
    let start = null;
    stage.addEventListener('pointerdown', event => {
      if (event.isPrimary === false) return;
      const face = event.target.closest('[data-rubik-face]')?.dataset.rubikFace || null;
      start = { x: event.clientX, y: event.clientY, lastX: event.clientX, lastY: event.clientY, face, id: event.pointerId, dragged: false };
      try { stage.setPointerCapture(event.pointerId); } catch {}
    });
    // Live view rotation while dragging so the cube follows the finger.
    stage.addEventListener('pointermove', event => {
      if (!start || start.id !== event.pointerId || rubikViewMode !== 'view') return;
      const dx = event.clientX - start.lastX, dy = event.clientY - start.lastY;
      start.lastX = event.clientX; start.lastY = event.clientY;
      if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 4) start.dragged = true;
      rubikRotationY += dx * .8; rubikRotationX = Math.max(-80, Math.min(80, rubikRotationX - dy * .7));
      const cube = $('#rubikCube'); if (cube) cube.style.transform = `rotateX(${rubikRotationX}deg) rotateY(${rubikRotationY}deg)`;
    });
    stage.addEventListener('pointerup', event => {
      if (!start || start.id !== event.pointerId) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      const moved = Math.hypot(dx, dy) > 18;
      if (rubikViewMode === 'turn' && start.face) {
        if (moved) {
          const reverse = Math.abs(dx) >= Math.abs(dy) ? dx < 0 : dy < 0;
          makeRubikMove(`${start.face}${reverse ? "'" : ''}`);
        } else makeRubikMove(start.face); // a tap turns the touched face clockwise
      }
      start = null;
    });
    stage.addEventListener('pointercancel', () => { start = null; });
  }
  $('#game2048Restart')?.addEventListener('click', reset2048Game);
  $('#game2048RestartOverlay')?.addEventListener('click', reset2048Game);
  $('#coordinateRestart')?.addEventListener('click', resetCoordinateGame);
  $$('[data-coordinate-square]').forEach(button => button.addEventListener('click', () => handleCoordinateSquare(button.dataset.coordinateSquare)));
  $$('[data-2048-dir]').forEach(button => button.addEventListener('click', () => applyGamesMove2048(button.dataset['2048Dir'])));
  const grid2048 = $('#game2048Grid');
  if (grid2048) {
    let start = null;
    grid2048.addEventListener('pointerdown', event => { start = { x: event.clientX, y: event.clientY }; });
    grid2048.addEventListener('pointerup', event => {
      if (!start) return;
      const dx = event.clientX - start.x, dy = event.clientY - start.y;
      if (Math.max(Math.abs(dx), Math.abs(dy)) > 28) applyGamesMove2048(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 'left' : 'right') : (dy < 0 ? 'up' : 'down'));
      start = null;
    });
  }
  gamesKeyHandler = event => {
    if (currentView !== 'games' || gamesMode !== '2048' || event.altKey || event.ctrlKey || event.metaKey) return;
    const map = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down' };
    if (map[event.key]) { event.preventDefault(); applyGamesMove2048(map[event.key]); }
  };
  window.addEventListener('keydown', gamesKeyHandler);
  $$('[data-sliding-tile]').forEach(button => button.addEventListener('click', () => {
    const result = moveSlidingPuzzleTile(slidingPuzzleBoard, Number(button.dataset.slidingTile));
    if (!result.changed) return;
    recordDailyEvent('play_mini_game');
    slidingPuzzleBoard = result.board; slidingPuzzleMoves += 1;
    if (result.solved) toast(`Giải xong Trượt số trong ${slidingPuzzleMoves} nước!`, 'success');
    renderView();
  }));
  $('#slidingPuzzleRestart')?.addEventListener('click', () => { slidingPuzzleBoard = createScrambledSlidingPuzzle(100); slidingPuzzleMoves = 0; renderView(); });
  $('#memoryRestart')?.addEventListener('click', () => { memoryDeck = []; memorySelected = []; memoryMatched = new Set(); memoryMoves = 0; memoryLock = false; renderView(); });
  $$('[data-memory-card]').forEach(button => button.addEventListener('click', () => {
    const id = button.dataset.memoryCard;
    if (memoryLock || memoryMatched.has(id) || memorySelected.includes(id) || memorySelected.length >= 2) return;
    recordDailyEvent('play_mini_game');
    memorySelected.push(id); renderView();
    if (memorySelected.length === 2) {
      memoryMoves++;
      const first = memoryDeck.find(card => card.id === memorySelected[0]);
      const second = memoryDeck.find(card => card.id === memorySelected[1]);
      if (first?.pair === second?.pair) {
        memoryMatched.add(first.id); memoryMatched.add(second.id); memorySelected = [];
        setTimeout(() => { if (currentView === 'games' && gamesMode === 'memory') renderView(); }, 80);
      } else {
        memoryLock = true;
        setTimeout(() => { memorySelected = []; memoryLock = false; if (currentView === 'games' && gamesMode === 'memory') renderView(); }, 800);
      }
    }
  }));
  $$('[data-ttt-square]').forEach(button => button.addEventListener('click', () => handleTicTacToeMove(Number(button.dataset.tttSquare))));
  $('#ticTacToeRestart')?.addEventListener('click', resetTicTacToe);
}

function wireHomeActions() {
  wireYoutubeMusicControls();
  $$('[data-home-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.homeView)));
  $$('[data-home-action="quickplay"]').forEach(button => button.addEventListener('click', () => {
    if (gameStarted) { openMatchSetup(); return; }
    mode = 'stockfish';
    colorChoice = 'random';
    humanColor = 'w';
    orientation = 'w';
    setView('play');
  }));
  $$('[data-home-elo]').forEach(button => button.addEventListener('click', () => {
    const elo = Number(button.getAttribute('data-home-elo')) || 1200;
    const clock = button.getAttribute('data-home-clock') || '3+2';
    const preset = resolveBotEloPreset(elo);
    settings.botTargetElo = preset.elo;
    settings.botElo = preset.elo;
    settings.botSkill = preset.skill;
    settings.botStrengthMode = 'elo';
    try { if (typeof saveSettings === 'function') saveSettings(); } catch {}
    mode = 'stockfish';
    colorChoice = 'random';
    humanColor = Math.random() < 0.5 ? 'w' : 'b';
    orientation = humanColor;
    setView('play');
    toast(`Bot ${preset.elo} Elo · ${clock}`, 'success');
  }));
  $$('[data-home-action="daily-puzzle"]').forEach(button => button.addEventListener('click', () => {
    puzzleState.playMode = 'daily';
    setView('puzzles');
  }));
  $$('[data-home-action="last-review"]').forEach(button => button.addEventListener('click', () => {
    setView('coach');
    toast('Mở phân tích — chọn ván trong lịch sử hoặc phân tích ván vừa chơi.', 'success');
  }));
}

let rankedMatchState = { queued: false, match: null, rating: 1200 };
let rankedChess = new Chess();
let rankedSelected = null;
let rankedTargets = [];
let rankedPollTimer = null;
let rankedClockDisplayTimer = null;
let rankedPollBusy = false;
let rankedLastSignature = '';
let rankedMoveBusy = false;
let puzzleGame = new Chess();
let puzzleState = {
  status: 'idle', rootFen: '', solutionUci: '', selected: null,
  targets: [], attempts: 0, lastMessage: 'Tạo một thế cờ ngẫu nhiên để bắt đầu.',
  showHint: false, lastMove: null, solvedCount: 0, rootPly: 0, streak: 0,
  bestStreak: 0, puzzleStartedAt: 0, lastSolveMs: 0, source: 'offline', mateOnly: false, theme: '', level: '', historyCount: 0,
  solutionLine: [], solutionIndex: 0, sourceUrl: '', sourceRating: null, sourceThemes: [],
  playMode: 'classic', busy: false, wrongShown: false, moveVerdict: '', runLives: 3, runSolved: 0, rushRemainingMs: 180000, rushDeadlineAt: 0, rushActive: false, rushBest: 0, dailyDate: '', dailyAlreadySolved: false
};
let puzzleRushTimer = null;
let puzzleGenerationEpoch = 0;
const PUZZLE_DAILY_SOLVED_KEY = 'vila.chess.puzzles.daily-solved-date.v1';
const PUZZLE_RUSH_BEST_KEY = 'vila.chess.puzzles.rush-best.v1';
const PUZZLE_LICHESS_CACHE_KEY = 'vila.chess.puzzles.lichess-daily-cache.v1';
const PUZZLE_LICHESS_TRAINING_CACHE_KEY = 'vila.chess.puzzles.lichess-training-cache.v1';
const PUZZLE_LICHESS_POOL_KEY = 'vila.chess.puzzles.lichess-training-pool.v1';
const PUZZLE_DOWNLOAD_BATCH_SIZE = 50;
try { puzzleState.historyCount = loadPuzzleHistory().length; } catch {}
const puzzleSessionSeen = new Set();
try { for (const fen of loadPuzzleHistory()) puzzleSessionSeen.add(fen); } catch {}
try { puzzleState.solvedCount = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.solved.v1')) || 0); puzzleState.rushBest = Math.max(0, Number(localStorage.getItem(PUZZLE_RUSH_BEST_KEY)) || 0); } catch {}
try {
  puzzleState.streak = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.streak.v1')) || 0);
  puzzleState.bestStreak = Math.max(0, Number(localStorage.getItem('vila.chess.puzzles.bestStreak.v1')) || 0);
} catch {}


function rankedRatingOf(user, category = '') {
  const categoryRating = category && Number(user?.ratingsByCategory?.[category]);
  return Math.max(100, Number(categoryRating) || Number(user?.elo) || 1200);
}
function rankedCategoryLabel(category) {
  return ({ bullet: 'Bullet', blitz: 'Blitz', rapid: 'Rapid', daily: 'Daily', casual: 'Không xếp hạng' })[category] || 'Blitz';
}
function rankedClockText(match, color, now = Date.now()) {
  if (!match?.clockEnabled) return '∞';
  let remaining = Math.max(0, Number(match.clockRemainingMs?.[color]) || 0);
  const activeTurn = String(match.fen || '').split(' ')[1] || 'w';
  if (match.status === 'active' && activeTurn === color) {
    const updatedAt = Number(match.clockUpdatedAt) || now;
    remaining = Math.max(0, remaining - Math.max(0, now - updatedAt));
  }
  return formatClockTime(remaining, true);
}
function updateRankedClockDisplay() {
  if (currentView !== 'ranked') return;
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active') return;
  for (const color of ['w', 'b']) {
    const output = $(`[data-ranked-clock="${color}"]`);
    if (output) output.textContent = rankedClockText(match, color);
  }
}
function rankedClockFaceMarkup(match, color, label) {
  return `<span class="ranked-clock-face" data-clock-color="${color}"><small>${label}</small><strong data-ranked-clock="${color}">${rankedClockText(match, color)}</strong></span>`;
}
function rankedBoardMarkup(match) {
  const whiteBottom = match?.color !== 'b';
  const ranks = whiteBottom ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = whiteBottom ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  // Highlight from the live position (includes our optimistic move), not the last server snapshot.
  const latest = rankedChess.history({ verbose: true }).at(-1) || null;
  const inCheck = rankedChess.isCheck();
  const turn = rankedChess.turn();
  const targets = new Map();
  for (const move of rankedTargets) {
    if (!targets.has(move.to)) targets.set(move.to, []);
    targets.get(move.to).push(move);
  }
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const square = `${file}${rank}`;
    const piece = rankedChess.get(square);
    const selected = rankedSelected === square;
    const choices = targets.get(square) || [];
    const isLastFrom = latest?.from === square;
    const isLastTo = latest?.to === square;
    const classes = ['ranked-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), selected ? 'selected' : '', choices.length ? (piece ? 'capture-target' : 'legal-target') : '', isLastFrom ? 'last-from' : '', isLastTo ? 'last-to' : '', inCheck && piece?.type === 'k' && piece.color === turn ? 'in-check' : ''].filter(Boolean).join(' ');
    const pieceHtml = piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : '';
    html += `<button type="button" class="${classes}" data-ranked-square="${square}" aria-label="${square}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}">${pieceHtml}${visualSettings.showCoordinates && col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${visualSettings.showCoordinates && row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function rankedOpeningInfo(match) {
  const recognized = recognizeOpening((match?.moves || []).map(move => String(move?.san || '')).filter(Boolean), OPENINGS, { minPlies: 5 });
  return {
    name: recognized?.name || ((match?.moves || []).length >= 5 ? 'Chưa nhận diện được khai cuộc' : 'Khai cuộc sẽ được nhận diện sau vài nước'),
    detail: recognized?.eco ? `Mã ECO ${recognized.eco}` : recognized ? 'Nhận diện từ biên bản nước đi đã xác thực' : 'Chỉ nhận diện khai cuộc; không phân tích hoặc gợi ý nước đi'
  };
}
/** Repaint only the board, move list and chips of a running ranked match (no page re-render). */
function refreshRankedLive(match, { slide = null } = {}) {
  const board = $('#rankedBoard');
  if (!board || currentView !== 'ranked' || !match) return false;
  board.innerHTML = rankedBoardMarkup(match);
  if (slide) slideBoardPiece(board, 'data-ranked-square', slide);
  const list = $('#rankedMoveList');
  if (list) { list.innerHTML = rankedMoveListMarkup(match); list.scrollTop = list.scrollHeight; }
  const text = (selector, value) => { const node = $(selector); if (node && node.textContent !== value) node.textContent = value; };
  const yourTurn = match.status === 'active' && rankedChess.turn() === match.color;
  text('#rankedTurnChip', yourTurn ? 'ĐẾN LƯỢT BẠN' : 'ĐANG CHỜ ĐỐI THỦ');
  text('#rankedTurnNote', yourTurn ? 'Kéo thả hoặc chạm quân rồi chạm ô đích để đi.' : 'Đợi đối thủ đi; bàn cờ tự đồng bộ khi có nước mới.');
  text('#rankedHalfMoves', String(Math.max((match.moves || []).length, rankedChess.history().length)));
  const opening = rankedOpeningInfo(match);
  text('#rankedOpeningName', opening.name);
  text('#rankedOpeningDetail', opening.detail);
  updateRankedClockDisplay();
  return true;
}
function rankedCanMoveNow() {
  const match = rankedMatchState?.match;
  return Boolean(match && match.status === 'active' && !rankedMoveBusy && rankedChess.turn() === match.color);
}
function rankedHandleTap(square) {
  const match = rankedMatchState?.match;
  if (!rankedCanMoveNow()) return;
  const piece = rankedChess.get(square);
  if (rankedSelected && rankedTargets.some(move => move.to === square)) {
    const from = rankedSelected;
    const options = rankedTargets.filter(move => move.to === square);
    rankedSelected = null; rankedTargets = [];
    void rankedPlayMove(from, square, options, false);
    return;
  }
  if (piece && piece.color === match.color && rankedSelected !== square) { rankedSelected = square; rankedTargets = rankedChess.moves({ square, verbose: true }); }
  else { rankedSelected = null; rankedTargets = []; }
  const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(match);
}
async function rankedPlayMove(from, to, options, viaDrag) {
  let promotion = '';
  if (options.some(move => move.promotion)) {
    const fen = rankedChess.fen();
    promotion = visualSettings.autoQueen ? 'q' : await choosePromotion(rankedChess.turn());
    if (!promotion || rankedChess.fen() !== fen) { const board = $('#rankedBoard'); if (board && rankedMatchState?.match) board.innerHTML = rankedBoardMarkup(rankedMatchState.match); return; }
  }
  await submitRankedMove(from, to, promotion, { noSlide: viaDrag });
}
function rankedMoveListMarkup(match) {
  const moves = match?.moves || [];
  if (!moves.length) return '<div class="empty-state">Nước đi đã được đồng bộ và xác thực trên máy chủ sẽ xuất hiện ở đây.</div>';
  let html = '';
  for (let i = 0; i < moves.length; i += 2) {
    const first = moves[i]; const second = moves[i + 1];
    html += `<div class="ranked-move-row"><b>${Math.floor(i / 2) + 1}.</b><span>${esc(first?.san || '—')}</span><span>${esc(second?.san || '…')}</span></div>`;
  }
  return html;
}
function rankedClockOptionsMarkup() {
  return RANKED_CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${preset.value === selectedRankedTimeControl ? 'selected' : ''}>${esc(preset.label)}</option>`).join('');
}
function renderRankedView() {
  const user = socialState.user;
  if (!socialState.token || !user) return `<section class="content-page ranked-page"><div class="page-intro"><div class="eyebrow">CỜ VUA · RANKED 1V1</div><h1>Đấu xếp hạng</h1><p>Ghép ngẫu nhiên với người chơi thật theo Elo, máy chủ xác thực luật đi và cập nhật điểm.</p></div><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">${uiTile('users', 'cyan', 'tile-lg')}</div><h2>Đăng nhập để tìm đối thủ</h2><p>Đấu xếp hạng cần tài khoản cộng đồng để lưu Elo trên máy chủ, không dùng điểm giả lập cục bộ.</p><button type="button" class="primary-btn" id="rankedOpenAccount">Đăng nhập / tạo tài khoản</button></section></section>`;
  const data = rankedMatchState || {};
  const match = data.match || null;
  if (!match) {
    const waiting = Boolean(data.queued);
    const selectedPreset = RANKED_CLOCK_PRESETS.find(item => item.value === selectedRankedTimeControl) || RANKED_CLOCK_PRESETS.find(item => item.value === '1d');
    const category = classifyTimeControl(selectedPreset.value);
    const elo = Math.max(100, Number(data.timeCategory === category ? data.rating : 0) || rankedRatingOf(user, category));
    const waitSeconds = Math.floor(Math.max(0, Number(data.waitMs) || 0) / 1000);
    const clockSettings = `<div class="ranked-time-setting ranked-time-panel"><div class="ranked-time-panel-head"><span class="ranked-time-panel-icon">◷</span><span><b>Thời gian mỗi lượt</b><small>Chọn tốc độ ghép trận</small></span></div><label class="field-label" for="rankedTimeControl">Thời gian thi đấu · ${rankedCategoryLabel(category)}</label><select id="rankedTimeControl" class="field">${rankedClockOptionsMarkup()}</select><small class="field-hint">Elo Bullet, Blitz, Rapid và Daily được tính riêng. Ghép đúng mốc thời gian đã chọn. Daily 1d là 24 giờ cho mỗi lượt đi, được làm mới khi bạn đi xong.</small></div>`;
    return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA · XẾP HẠNG TRỰC TUYẾN</div><h1>Ghép trận ngẫu nhiên</h1><p>Ghép người thật theo Elo của đúng thể loại; đồng hồ và kết quả được xác thực bởi máy chủ.</p></div><div class="puzzle-rating-chip">${rankedCategoryLabel(category)} Elo · ${elo}</div></div>${waiting ? `<section class="panel ranked-queue-card"><div class="ranked-queue-orbit">${uiTile('globe', 'cyan', 'tile-lg')}</div><h2>Đang tìm đối thủ…</h2><p>Đang ghép người chơi thật theo ${rankedCategoryLabel(data.timeCategory || category)} · ${esc(data.timeControl || selectedRankedTimeControl)}. Bạn có thể hủy hàng đợi trước khi trận bắt đầu.</p><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Thời gian chờ</small><b id="rankedQueueWait">${waitSeconds}s</b></div><div class="ranked-stat"><small>Đối thủ</small><b>Đang tìm</b></div></div><div style="margin-top:16px"><button type="button" class="secondary-btn" id="rankedQueueCancel">Hủy tìm trận</button></div></section>` : `<div class="ranked-layout"><div class="ranked-left"><section class="panel ranked-queue-card"><div class="ranked-queue-orbit">${uiTile('users', 'cyan', 'tile-lg')}</div><h2>Sẵn sàng đấu với người thật?</h2><p>Mỗi thể loại có Elo riêng. Daily 1d cấp 24 giờ cho từng lượt đi; thời gian, ghép trận và Elo Daily được xác thực bởi máy chủ.</p>${clockSettings}<button type="button" class="primary-btn full-width" id="rankedQueueStart">Tìm đối thủ ngẫu nhiên</button><div class="ranked-stat-grid"><div class="ranked-stat"><small>${rankedCategoryLabel(category)} Elo</small><b>${elo}</b></div><div class="ranked-stat"><small>Đã đấu</small><b>${Number(user.games)||0}</b></div><div class="ranked-stat"><small>Thắng</small><b>${Number(user.wins)||0}</b></div></div></section></div><div class="ranked-right"><section class="panel"><h2>Thể loại và đồng hồ</h2><p class="ranked-note">• UltraBullet 15 giây, HyperBullet 30 giây, Bullet 1–2 phút.
• Blitz thường 3–5 phút; Rapid thường 10–30 phút.
• Các mốc có thêm giây (ví dụ 3+2) được hỗ trợ. Phân loại theo thời gian ước tính cho 40 nước.
• Daily 1d/2d dành riêng cho đấu trực tuyến; mỗi người có 1 hoặc 2 ngày cho mỗi lượt đi, đồng hồ được làm mới sau nước đi.
• Mỗi loại có Elo riêng. Đầu hàng hoặc bỏ trận bị trừ thêm 15 Elo trong loại đang chơi.</p><p class="ranked-note">Ghép đấu online cần server đang chạy và người chơi khác đang chờ đúng mốc thời gian. Fair-play: khi đang ghép trận chỉ có bàn cờ, nước đi hợp lệ, đồng hồ và nhận diện khai cuộc; không có engine gợi ý, phân tích, premove hoặc công cụ hỗ trợ.</p></section></div></div>`}</section>`;
  }
  const color = match.color || 'w';
  const own = color === 'w' ? match.players?.w : match.players?.b;
  const opponent = match.opponent || (color === 'w' ? match.players?.b : match.players?.w);
  const category = ['bullet', 'blitz', 'rapid', 'daily'].includes(match.timeCategory) ? match.timeCategory : classifyTimeControl(match.timeControl || '1d');
  const categoryLabel = rankedCategoryLabel(category);
  const active = match.status === 'active';
  const yourTurn = active && rankedChess.turn() === color;
  const recognizedRankedOpening = recognizeOpening((match.moves || []).map(move => String(move?.san || '')).filter(Boolean), OPENINGS, { minPlies: 5 });
  const rankedOpeningName = recognizedRankedOpening?.name || ((match.moves || []).length >= 5 ? 'Chưa nhận diện được khai cuộc' : 'Khai cuộc sẽ được nhận diện sau vài nước');
  const rankedOpeningDetail = recognizedRankedOpening?.eco ? `Mã ECO ${recognizedRankedOpening.eco}` : recognizedRankedOpening ? 'Nhận diện từ biên bản nước đi đã xác thực' : 'Chỉ nhận diện khai cuộc; không phân tích hoặc gợi ý nước đi';
  let resultTitle = ''; let resultClass = '';
  if (!active) {
    const won = match.result === (color === 'w' ? '1-0' : '0-1');
    const draw = match.result === '1/2-1/2';
    resultTitle = draw ? 'HÒA' : won ? 'CHIẾN THẮNG' : 'THẤT BẠI';
    resultClass = draw ? 'is-draw' : won ? 'is-win' : 'is-loss';
  }
  const change = match.eloChanges;
  const delta = Number(change?.delta) || 0;
  const eloAfter = Number(change?.after) || rankedRatingOf(own, category);
  const resultBlock = !active ? `<section class="ranked-result-hero ${resultClass}"><small class="eyebrow">KẾT QUẢ TRẬN ${categoryLabel.toUpperCase()}</small><h2>${resultTitle}</h2><p>${match.resultReason === 'resignation' || match.resultReason === 'abandoned' ? 'Một người chơi đã rời hoặc đầu hàng.' : match.resultReason === 'disconnect_timeout' ? 'Một người chơi mất kết nối quá 90 giây và bị xử thua.' : match.resultReason === 'time_forfeit' ? 'Một người chơi hết giờ.' : match.resultReason === 'checkmate' ? 'Ván cờ kết thúc bằng chiếu hết.' : 'Ván cờ kết thúc theo luật cờ vua.'} Kết quả do máy chủ lưu lại.</p><div class="ranked-elo-change"><div><small>${categoryLabel} Elo sau trận</small><strong>${eloAfter}</strong></div><div><small>Biến động</small><strong class="${delta > 0 ? 'up' : delta < 0 ? 'down' : ''}">${delta > 0 ? '+' : ''}${delta}</strong></div></div><button type="button" class="primary-btn full-width" id="rankedQueueAgain" style="margin-top:14px">Tìm trận tiếp theo · ${esc(match.timeControl || selectedRankedTimeControl)}</button></section>` : '';
  const opponentName = esc(opponent?.displayName || opponent?.username || 'Đối thủ');
  const ownName = esc(user.displayName || user.username);
  return `<section class="content-page ranked-page"><div class="ranked-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA · ${categoryLabel.toUpperCase()} RANK</div><h1>${active ? 'Đang thi đấu' : 'Trận đã kết thúc'}</h1><p>${esc(match.timeControl || '3+2')} · ${categoryLabel} · ${active ? 'Đồng hồ server và nước đi hợp lệ được xác thực từ xa.' : 'Bàn cờ và lịch sử nước đi được giữ để xem lại.'}</p></div><span class="puzzle-rating-chip" id="rankedTurnChip">${active ? (yourTurn ? 'ĐẾN LƯỢT BẠN' : 'ĐANG CHỜ ĐỐI THỦ') : `Kết quả ${esc(match.result || '—')}`}</span></div>${resultBlock}<div class="ranked-layout"><div class="ranked-left"><div class="ranked-player-bar"><span class="ranked-player-identity"><span class="ranked-player-avatar" style="${avatarStyle(opponent)}">${avatarEmoji(opponent)}</span><span><b>${opponentName}</b><small>Đối thủ · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</small></span></span>${active ? rankedClockFaceMarkup(match, color === 'w' ? 'b' : 'w', 'ĐỒNG HỒ ĐỐI THỦ') : `<span class="turn-chip">${color === 'w' ? 'Cầm Trắng' : 'Cầm Đen'}</span>`}</div><div class="ranked-board-wrap"><div class="ranked-board" id="rankedBoard" role="grid" aria-label="Bàn cờ xếp hạng">${rankedBoardMarkup(match)}</div></div><div class="ranked-player-bar"><span class="ranked-player-identity"><span class="ranked-player-avatar" style="${avatarStyle(own || user)}">${avatarEmoji(own || user)}</span><span><b>${ownName}</b><small>Bạn · ${rankedRatingOf(own, category)} ${categoryLabel} Elo</small></span></span>${active ? rankedClockFaceMarkup(match, color, 'ĐỒNG HỒ CỦA BẠN') : `<span class="turn-chip">Đã xong · Elo ${eloAfter}</span>`}</div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Thể loại</small><b>${categoryLabel}</b></div><div class="ranked-stat"><small>Số nửa nước</small><b id="rankedHalfMoves">${match.moves?.length || 0}</b></div><div class="ranked-stat"><small>${categoryLabel} Elo</small><b>${active ? rankedRatingOf(own, category) : eloAfter}</b></div></div><section class="ranked-opening-recognition" aria-live="polite"><small class="eyebrow">NHẬN DIỆN KHAI CUỘC</small><strong id="rankedOpeningName">${esc(rankedOpeningName)}</strong><small id="rankedOpeningDetail">${esc(rankedOpeningDetail)}</small></section>${active ? '<button type="button" class="danger-btn full-width" id="rankedForfeitBtn">Đầu hàng / thoát trận (mất Elo)</button>' : ''}</div><div class="ranked-right"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ NƯỚC ĐI</small><h2>Biên bản trận</h2></div><span class="context-icon">♞</span></div><div class="ranked-move-list" id="rankedMoveList">${rankedMoveListMarkup(match)}</div><p class="ranked-note">Biên bản được nhận từ máy chủ và phát lại bằng luật cờ vua tiêu chuẩn. Chế độ rank không hỗ trợ hoàn tác, gợi ý hoặc phân tích trong ván.</p></section><section class="panel"><h2>Đối thủ</h2><p>${opponentName} · ${rankedRatingOf(opponent, category)} ${categoryLabel} Elo</p><p class="ranked-note" id="rankedTurnNote">${active ? (yourTurn ? 'Kéo thả hoặc chạm quân rồi chạm ô đích để đi.' : 'Đợi đối thủ đi; bàn cờ tự đồng bộ khi có nước mới.') : `Mọi Elo ${categoryLabel} trong ván đã được cập nhật tại server.`}</p></section></div></div></section>`;
}
function rankedSyncChess(match) {
  if (!match) return;
  let clone;
  try { clone = new Chess(match.startFen || new Chess().fen()); } catch { clone = new Chess(); }
  for (const move of match.moves || []) {
    try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
  }
  rankedChess = clone; rankedSelected = null; rankedTargets = [];
}
function rankedStateSignature(data) {
  const m = data?.match;
  return m ? `${m.id}|${m.status}|${m.fen}|${(m.moves || []).length}|${m.result || ''}|${m.timeControl || ''}|${m.timeCategory || ''}|${m.eloChanges?.delta ?? ''}` : `${Boolean(data?.queued)}|${data?.rating || ''}|${data?.timeControl || ''}|${data?.timeCategory || ''}`;
}
function setSelectedRankedTimeControl(value) {
  if (!RANKED_CLOCK_PRESETS.some(preset => preset.value === value)) return false;
  selectedRankedTimeControl = value;
  try { localStorage.setItem('vila.chess.ranked-time-control.v1', JSON.stringify(value)); } catch {}
  return true;
}
async function refreshRankedStatus(silent = true) {
  // While our own move is in flight the response is authoritative; a poll would reset the optimistic board.
  if (rankedPollBusy || rankedMoveBusy || !socialState.token || currentView !== 'ranked') return;
  rankedPollBusy = true;
  const old = rankedMatchState;
  const oldMatch = old?.match;
  const oldSignature = rankedStateSignature(old);
  try {
    const next = await socialApi('/ranked/status');
    if (rankedMoveBusy) return;
    const nextSignature = rankedStateSignature(next);
    rankedMatchState = next;
    if (next.match?.timeControl) setSelectedRankedTimeControl(next.match.timeControl);
    else if (next.queued && next.timeControl) setSelectedRankedTimeControl(next.timeControl);
    if (nextSignature !== oldSignature) {
      if (next.match) rankedSyncChess(next.match);
      if (!oldMatch && next.match?.status === 'active') toast('Đã ghép trận! Trận đấu xếp hạng đã bắt đầu.', 'success');
      if (oldMatch?.status === 'active' && next.match?.status === 'finished') toast('Trận đã kết thúc. Elo đã được cập nhật bởi máy chủ.', 'success');
      rankedLastSignature = nextSignature;
      const sameLiveMatch = oldMatch && next.match && oldMatch.id === next.match.id && oldMatch.status === 'active' && next.match.status === 'active';
      if (currentView === 'ranked') {
        // Only new moves arrived: patch the board and slide the opponent's piece instead of rebuilding the page.
        if (sameLiveMatch && (next.match.moves || []).length > (oldMatch.moves || []).length && refreshRankedLive(next.match, { slide: slideFromMove(rankedChess.history({ verbose: true }).at(-1)) })) {
          playMoveSoundFor(rankedChess.history({ verbose: true }).at(-1), rankedChess);
        } else renderView();
      }
    } else {
      const wait = $('#rankedQueueWait');
      if (wait) wait.textContent = `${Math.floor(Math.max(0, Number(next.waitMs) || 0) / 1000)}s`;
    }
  } catch (error) {
    if (!silent) toast(`Không thể cập nhật trận: ${error.message || error}`);
  } finally { rankedPollBusy = false; }
}
function syncRankedTimers() {
  const shouldPoll = currentView === 'ranked' && Boolean(rankedMatchState?.queued || rankedMatchState?.match?.status === 'active');
  if (shouldPoll && !rankedPollTimer) rankedPollTimer = setInterval(() => { void refreshRankedStatus(true); }, rankedMatchState?.match?.status === 'active' ? 800 : 1800);
  else if (!shouldPoll && rankedPollTimer) { clearInterval(rankedPollTimer); rankedPollTimer = null; }
  const shouldTickClock = currentView === 'ranked' && rankedMatchState?.match?.status === 'active';
  if (shouldTickClock && !rankedClockDisplayTimer) rankedClockDisplayTimer = setInterval(updateRankedClockDisplay, 200);
  else if (!shouldTickClock && rankedClockDisplayTimer) { clearInterval(rankedClockDisplayTimer); rankedClockDisplayTimer = null; }
  if (shouldTickClock) updateRankedClockDisplay();
}
function startRankedPolling() { syncRankedTimers(); }
async function startRankedQueue() {
  if (!socialState.token || !socialState.user) { setView('friends'); toast('Đăng nhập trước khi bắt đầu đấu xếp hạng.'); return; }
  const button = $('#rankedQueueStart');
  if (button) { button.disabled = true; button.textContent = 'Đang vào hàng đợi…'; }
  try {
    rankedMatchState = await socialApi('/ranked/queue', { method: 'POST', body: JSON.stringify({ timeControl: selectedRankedTimeControl }) });
    if (rankedMatchState.match?.timeControl) setSelectedRankedTimeControl(rankedMatchState.match.timeControl);
    if (rankedMatchState.match) rankedSyncChess(rankedMatchState.match);
    rankedLastSignature = rankedStateSignature(rankedMatchState);
    renderView(); startRankedPolling();
    if (rankedMatchState.queued) toast('Đã vào hàng đợi ghép trận theo Elo.');
  } catch (error) {
    toast(`Không thể tìm trận: ${error.message || error}`);
    if (button) { button.disabled = false; button.textContent = '⚔ Tìm đối thủ ngẫu nhiên'; }
  }
}
async function quitRankedMatch(navigating = false) {
  const match = rankedMatchState?.match;
  try {
    if (match?.status === 'active') {
      const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/resign`, { method: 'POST', body: '{}' });
      rankedMatchState = data; if (data.match) rankedSyncChess(data.match);
      if (!navigating) { toast(`Đã đầu hàng. Elo được cập nhật ở máy chủ (${data.match?.eloChanges?.delta > 0 ? '+' : ''}${data.match?.eloChanges?.delta ?? 0}).`); renderView(); }
    } else if (rankedMatchState?.queued) {
      await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' });
      rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, classifyTimeControl(selectedRankedTimeControl)) };
      if (!navigating) { toast('Đã hủy hàng đợi. Chưa phát sinh thay đổi Elo.'); renderView(); }
    }
  } catch (error) { if (!navigating) toast(`Không thể kết thúc trận: ${error.message || error}`); }
}
async function submitRankedMove(from, to, promotion = '', { noSlide = false } = {}) {
  const match = rankedMatchState?.match;
  if (!match || match.status !== 'active' || rankedMoveBusy) return;
  if (rankedChess.turn() !== match.color) { toast('Chưa đến lượt của bạn.'); return; }
  const expectedPly = (match.moves || []).length;
  rankedMoveBusy = true;
  // Optimistic: show the legal move at once (with the same slide as the practice board) instead of
  // waiting for the network round trip. The server stays authoritative; a rejection resyncs the board.
  let made = null;
  try { made = rankedChess.move({ from, to, ...(promotion ? { promotion } : {}) }); } catch { made = null; }
  if (made) {
    rankedSelected = null; rankedTargets = [];
    playMoveSoundFor(made, rankedChess);
    refreshRankedLive(match, { slide: noSlide ? null : slideFromMove(made) });
  }
  const board = $('#rankedBoard'); if (board) board.setAttribute('aria-busy', 'true');
  try {
    const data = await socialApi(`/ranked/matches/${encodeURIComponent(match.id)}/move`, { method: 'POST', body: JSON.stringify({ from, to, promotion, expectedPly }) });
    const previousMoves = expectedPly + 1;
    rankedMatchState = data;
    rankedLastSignature = rankedStateSignature(data);
    rankedMoveBusy = false;
    const serverMoves = data.match?.moves || [];
    const stillLive = data.match && data.match.id === match.id && data.match.status === 'active';
    // The optimistic position already equals the server's unless the opponent replied in the meantime.
    const opponentReplied = serverMoves.length > previousMoves;
    if (data.match && (opponentReplied || data.match.status !== 'active' || rankedChess.fen() !== data.match.fen)) rankedSyncChess(data.match);
    if (stillLive && board?.isConnected) {
      refreshRankedLive(data.match, { slide: opponentReplied ? slideFromMove(rankedChess.history({ verbose: true }).at(-1)) : null });
      $('#rankedBoard')?.removeAttribute('aria-busy');
    } else {
      renderView();
      if (data.match?.status === 'finished') toast('Đã xác nhận kết quả và Elo trên máy chủ.', 'success');
    }
  } catch (error) {
    rankedMoveBusy = false;
    if (rankedMatchState?.match) rankedSyncChess(rankedMatchState.match);
    await refreshRankedStatus(true);
    if (currentView === 'ranked') renderView();
    toast(`Nước đi chưa được chấp nhận: ${error.message || error}`);
  } finally { rankedMoveBusy = false; }
}
function puzzleBoardIsFree() {
  // After a puzzle is solved / revealed (or before the first one) the board is a free sandbox:
  // any legal move for the side to move, with undo.
  return ['solved', 'revealed', 'idle'].includes(puzzleState.status);
}
function puzzleBoardIsInteractive() {
  return puzzleState.status === 'ready' ? !puzzleState.busy : puzzleBoardIsFree();
}
function renderPuzzleBoardMarkup() {
  const orient = puzzleState.rootColor || 'w';
  const ranks = orient === 'w' ? [8,7,6,5,4,3,2,1] : [1,2,3,4,5,6,7,8];
  const files = orient === 'w' ? ['a','b','c','d','e','f','g','h'] : ['h','g','f','e','d','c','b','a'];
  const targets = new Map();
  for (const move of puzzleState.targets) { if (!targets.has(move.to)) targets.set(move.to, []); targets.get(move.to).push(move); }
  const hintFrom = puzzleState.showHint ? puzzleState.solutionUci.slice(0,2) : '';
  const hintTo = puzzleState.showHint ? puzzleState.solutionUci.slice(2,4) : '';
  const last = puzzleState.lastMove;
  const wrong = Boolean(puzzleState.wrongShown);
  const inCheck = puzzleGame.isCheck();
  const turn = puzzleGame.turn();
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const sq = `${file}${rank}`;
    const piece = puzzleGame.get(sq); const choices = targets.get(sq) || [];
    const movedFrom = last?.from === sq; const movedTo = last?.to === sq;
    const classes = ['puzzle-square', ((file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light'), puzzleState.selected === sq ? 'selected' : '',
      choices.length ? (piece ? 'capture-target' : 'legal-target') : '',
      hintFrom === sq ? 'solution-from' : movedFrom ? (wrong ? 'wrong-from' : 'solution-from') : '',
      hintTo === sq ? 'solution-to' : movedTo ? (wrong ? 'wrong-to' : 'solution-to') : '',
      inCheck && piece?.type === 'k' && piece.color === turn ? 'in-check' : '',
      hintTo === sq ? 'hint-to' : ''].filter(Boolean).join(' ');
    // Chess.com-style round badge on the destination square instead of text tags.
    const badge = movedTo && puzzleState.moveVerdict ? `<span class="puzzle-badge ${puzzleState.moveVerdict === 'good' ? 'is-good' : 'is-bad'}" aria-hidden="true">${puzzleState.moveVerdict === 'good' ? '✓' : '✕'}</span>` : '';
    html += `<button type="button" class="${classes}" data-puzzle-square="${sq}" aria-label="${sq}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceGlyph(piece)}</span>` : ''}${badge}${visualSettings.showCoordinates && col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${visualSettings.showCoordinates && row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}
function localPuzzleDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
function stopPuzzleRushTimer() {
  if (puzzleRushTimer) clearInterval(puzzleRushTimer);
  puzzleRushTimer = null;
}
function puzzleModeStatusText() {
  if (puzzleState.playMode === 'daily') return `Đề ${puzzleState.dailyDate || localPuzzleDateKey()} · ${puzzleState.dailyAlreadySolved ? 'đã hoàn thành' : '1 thử thách/ngày'}`;
  if (puzzleState.playMode === 'rush') {
    const ms = puzzleState.rushActive && puzzleState.rushDeadlineAt ? Math.max(0, puzzleState.rushDeadlineAt - Date.now()) : puzzleState.rushRemainingMs;
    return `⏱ ${formatClockTime(ms)} · ${puzzleState.runSolved} đúng · kỷ lục ${puzzleState.rushBest}`;
  }
  if (puzzleState.playMode === 'survival') return `♥ ${puzzleState.runLives} mạng · ${puzzleState.runSolved} câu đúng`;
  return `Luyện tự do · ${puzzleState.solvedCount} câu đã giải · tránh lặp trong phiên`;
}
function updatePuzzleModeStatus() {
  const node = $('#puzzleModeStatus');
  if (node) node.textContent = puzzleModeStatusText();
}
function pausePuzzleRushTimer() {
  if (puzzleState.playMode !== 'rush' || !puzzleState.rushActive) { stopPuzzleRushTimer(); return; }
  if (puzzleState.rushDeadlineAt) puzzleState.rushRemainingMs = Math.max(0, puzzleState.rushDeadlineAt - Date.now());
  stopPuzzleRushTimer();
  puzzleState.rushDeadlineAt = 0;
}
function resumePuzzleRushTimer() {
  if (puzzleState.playMode !== 'rush' || !puzzleState.rushActive || currentView !== 'puzzles' || puzzleRushTimer) return;
  if (puzzleState.rushRemainingMs <= 0) {
    finishPuzzleRush();
    return;
  }
  puzzleState.rushDeadlineAt = Date.now() + puzzleState.rushRemainingMs;
  puzzleRushTimer = setInterval(() => {
    puzzleState.rushRemainingMs = Math.max(0, puzzleState.rushDeadlineAt - Date.now());
    updatePuzzleModeStatus();
    if (puzzleState.rushRemainingMs <= 0) finishPuzzleRush();
  }, 250);
  updatePuzzleModeStatus();
}
function finishPuzzleRush() {
  stopPuzzleRushTimer();
  puzzleState.rushRemainingMs = 0;
  puzzleState.rushDeadlineAt = 0;
  puzzleState.rushActive = false;
  puzzleGenerationEpoch += 1;
  puzzleState.status = 'finished';
  puzzleState.lastMessage = `Hết giờ! Bạn giải đúng ${puzzleState.runSolved} câu trong Puzzle Rush. Kỷ lục của bạn: ${puzzleState.rushBest}.`;
  if (currentView === 'puzzles') renderView();
}
function readLichessDailyCache(dateKey) {
  try {
    const cached = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_CACHE_KEY) || 'null');
    if (!cached || cached.dateKey !== dateKey || !validateCachedPuzzleLine(cached, Chess)) return null;
    return cached;
  } catch { return null; }
}
function readLichessPuzzlePool() {
  try {
    const saved = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_POOL_KEY) || '[]');
    return normalizePuzzlePool(saved, item => validateCachedPuzzleLine(item, Chess), LICHESS_PUZZLE_POOL_LIMIT);
  } catch { return []; }
}
function saveLichessPuzzleToPool(item) {
  if (!item || !validateCachedPuzzleLine(item, Chess)) return readLichessPuzzlePool();
  const pool = upsertPuzzlePool(readLichessPuzzlePool(), { ...item, cachedAt: Number(item.cachedAt) || Date.now() }, candidate => validateCachedPuzzleLine(candidate, Chess), LICHESS_PUZZLE_POOL_LIMIT);
  try { localStorage.setItem(PUZZLE_LICHESS_POOL_KEY, JSON.stringify(pool)); } catch (error) { console.warn('[VILA] Could not persist the offline puzzle pool:', error?.message || error); }
  return pool;
}
function pickUnusedCachedLichessPuzzle() {
  return chooseUnusedPuzzle(readLichessPuzzlePool(), puzzleSessionSeen, item => validateCachedPuzzleLine(item, Chess));
}
let puzzleBackendCooldownUntil = 0;
async function fetchPuzzlePayload({ kind = 'next', difficulty = 'normal', signal, token = '' } = {}) {
  const endpoint = kind === 'daily' ? 'daily' : `next?difficulty=${encodeURIComponent(['easiest','easier','normal','harder','hardest'].includes(difficulty) ? difficulty : 'normal')}`;
  const backend = String(settings.backendUrl || '').trim().replace(/\/+$/, '');
  const backendBase = backend.replace(/\/+$/, '');
  const backendToken = backendBase === DEFAULT_BACKEND_URL ? '' : String(settings.backendAccessToken || '').trim();
  const headers = { Accept: 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) };
  // Prefer the user's own VILA server, which keeps a bounded recent-ID cache; direct Lichess remains a safe fallback.
  // Máy chủ chậm/treo không được phép giữ câu đố: giới hạn 2,5 giây rồi chuyển sang Lichess; nhớ lỗi 90 giây để các lần sau bỏ qua.
  if (backend && Date.now() > puzzleBackendCooldownUntil) {
    const serverController = typeof AbortController === 'function' ? new AbortController() : null;
    const serverTimer = serverController ? setTimeout(() => serverController.abort(), 2500) : null;
    const relayAbort = () => serverController?.abort();
    signal?.addEventListener?.('abort', relayAbort, { once: true });
    try {
      const response = await fetch(`${backend}/api/puzzles/${endpoint}`, {
        method: 'GET', cache: 'no-store', headers: { ...headers, ...(backendToken ? { 'X-VILA-Access': backendToken } : {}) },
        ...(serverController ? { signal: serverController.signal } : {})
      });
      if (response.ok) { puzzleBackendCooldownUntil = 0; return await response.json(); }
      puzzleBackendCooldownUntil = Date.now() + 90_000;
      console.info('[VILA] Puzzle server not ready; trying Lichess directly:', response.status);
    } catch (error) {
      if (signal?.aborted) throw error;
      puzzleBackendCooldownUntil = Date.now() + 90_000;
      console.info('[VILA] Puzzle server unreachable; trying Lichess directly:', error?.message || error);
    } finally {
      if (serverTimer !== null) clearTimeout(serverTimer);
      signal?.removeEventListener?.('abort', relayAbort);
    }
  }
  const url = kind === 'daily' ? lichessDailyPuzzleUrl() : lichessPuzzleUrlForDifficulty(difficulty);
  const response = await fetch(url, { method: 'GET', cache: 'no-store', headers, ...(signal ? { signal } : {}) });
  if (!response.ok) throw new Error(`Lichess puzzle endpoint returned HTTP ${response.status}`);
  return response.json();
}
let puzzlePackDownloadBusy = false;
let puzzlePackDownloadStatus = '';
async function downloadLichessPuzzlePack() {
  if (puzzlePackDownloadBusy) return;
  if (typeof navigator === 'undefined' || !navigator.onLine || typeof fetch !== 'function') {
    puzzlePackDownloadStatus = 'Ngoại tuyến: dùng kho đã lưu.';
    const status = $('#puzzlePackStatus'); if (status) status.textContent = puzzlePackDownloadStatus;
    toast('Cần có mạng để tải câu đố Lichess. Các câu đã lưu vẫn dùng được ngoại tuyến.');
    return;
  }
  puzzlePackDownloadBusy = true;
  const button = $('#puzzleDownloadPack');
  const status = $('#puzzlePackStatus');
  if (button) { button.disabled = true; button.textContent = 'Đang tải câu đố…'; }
  let added = 0;
  let checked = 0;
  try {
    const difficultyBands = ['easiest', 'easier', 'normal', 'harder', 'hardest'];
    for (let i = 0; i < PUZZLE_DOWNLOAD_BATCH_SIZE; i += 1) {
      if (i > 0) await new Promise(resolve => setTimeout(resolve, 1050));
      const controller = typeof AbortController === 'function' ? new AbortController() : null;
      const timeout = controller ? setTimeout(() => controller.abort(), 7000) : null;
      try {
        const payload = await fetchPuzzlePayload({ kind: 'next', difficulty: difficultyBands[i % difficultyBands.length], ...(controller ? { signal: controller.signal } : {}) });
        const prepared = { ...prepareLichessDailyPuzzle(payload, Chess), cachedAt: Date.now() };
        checked += 1;
        const before = new Set(readLichessPuzzlePool().map(puzzlePoolKey));
        saveLichessPuzzleToPool(prepared);
        if (!before.has(puzzlePoolKey(prepared))) added += 1;
      } catch (error) {
        console.info('[VILA] Puzzle batch item skipped:', error?.message || error);
      } finally { if (timeout !== null) clearTimeout(timeout); }
      if (status) status.textContent = `Đã kiểm tra ${i + 1}/${PUZZLE_DOWNLOAD_BATCH_SIZE} · thêm ${added} câu`;
      if (currentView === 'puzzles') {
        const count = $('#puzzlePoolCount');
        if (count) count.textContent = String(readLichessPuzzlePool().length);
      }
    }
    const count = readLichessPuzzlePool().length;
    puzzlePackDownloadStatus = `Đã lưu ${count} câu hợp lệ (${added} câu mới trong lượt này).`;
    if (status) status.textContent = puzzlePackDownloadStatus;
    if (added > 0) recordDailyEvent('download_puzzle_pack');
    toast(added ? `Đã thêm ${added} câu đố hợp lệ. Tổng kho ngoại tuyến: ${count}.` : `Không có câu mới được thêm. Kho hiện có ${count} câu hợp lệ; đã thử ${checked} phản hồi.`, added ? 'success' : '');
  } finally {
    puzzlePackDownloadBusy = false;
    const currentButton = $('#puzzleDownloadPack');
    if (currentButton) { currentButton.disabled = false; currentButton.textContent = '⇩ Tải thêm 50 câu về máy'; }
  }
}

function readLichessTrainingCache() {
  try {
    const cached = JSON.parse(localStorage.getItem(PUZZLE_LICHESS_TRAINING_CACHE_KEY) || 'null');
    if (!cached || !validateCachedPuzzleLine(cached, Chess)) return null;
    const key = String(cached.fen).trim().split(/\s+/).slice(0, 4).join(' ');
    if (puzzleSessionSeen.has(key)) return null;
    return cached;
  } catch { return null; }
}
async function loadLichessTrainingPuzzle(difficulty, generationToken) {
  const cached = readLichessTrainingCache() || pickUnusedCachedLichessPuzzle();
  if (typeof navigator !== 'undefined' && navigator.onLine && typeof fetch === 'function') {
    try {
      const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
      let prepared = null;
      // Lichess can occasionally hand back a just-seen puzzle. Retry a few bounded times before using the larger local pool.
      // Tổng thời gian chờ tối đa 9 giây: quá hạn thì dùng ngay câu đố đã lưu để không bao giờ treo màn hình.
      const loadDeadline = Date.now() + 9000;
      for (let attempt = 0; attempt < 6 && Date.now() < loadDeadline; attempt += 1) {
        const requestController = typeof AbortController === 'function' ? new AbortController() : null;
        const requestTimeout = requestController ? setTimeout(() => requestController.abort(), 4500) : null;
        try {
          const payload = await fetchPuzzlePayload({ kind: 'next', difficulty, token, ...(requestController ? { signal: requestController.signal } : {}) });
          const candidate = prepareLichessDailyPuzzle(payload, Chess);
          if (generationToken !== puzzleGenerationEpoch) return null;
          const key = candidate.fen.trim().split(/\s+/).slice(0, 4).join(' ');
          if (!puzzleSessionSeen.has(key)) { prepared = candidate; break; }
        } catch (requestError) {
          if (generationToken !== puzzleGenerationEpoch) return null;
          console.info(`[VILA] Puzzle request ${attempt + 1}/6 failed; retrying if possible:`, requestError?.message || requestError);
        } finally { if (requestTimeout !== null) clearTimeout(requestTimeout); }
        if (attempt < 5) await new Promise(resolve => setTimeout(resolve, 200));
      }
      if (!prepared) return pickUnusedCachedLichessPuzzle() || cached;
      const item = { ...prepared, difficulty, cachedAt: Date.now() };
      saveLichessPuzzleToPool(item);
      try { localStorage.setItem(PUZZLE_LICHESS_TRAINING_CACHE_KEY, JSON.stringify(item)); } catch {}
      return item;
    } catch (error) {
      if (generationToken !== puzzleGenerationEpoch) return null;
      if (!cached) console.info('[VILA] Online Lichess training puzzle unavailable; using verified offline fallback.', error?.message || error);
    }
  }
  return pickUnusedCachedLichessPuzzle() || cached;
}
async function loadLichessDailyPuzzle(dateKey, generationToken) {
  const cached = readLichessDailyCache(dateKey);
  if (typeof navigator !== 'undefined' && navigator.onLine && typeof fetch === 'function') {
    const controller = typeof AbortController === 'function' ? new AbortController() : null;
    const timeout = controller ? setTimeout(() => controller.abort(), 7000) : null;
    try {
      const payload = await fetchPuzzlePayload({ kind: 'daily', ...(controller ? { signal: controller.signal } : {}) });
      if (generationToken !== puzzleGenerationEpoch) return null;
      const prepared = prepareLichessDailyPuzzle(payload, Chess);
      const item = { ...prepared, dateKey, cachedAt: Date.now() };
      saveLichessPuzzleToPool(item);
      try { localStorage.setItem(PUZZLE_LICHESS_CACHE_KEY, JSON.stringify(item)); } catch {}
      return item;
    } catch (error) {
      // Offline cache is deliberately preferred over blocking puzzle play when Lichess is unreachable.
      if (generationToken !== puzzleGenerationEpoch) return null;
      if (!cached) console.info('[VILA] Lichess Daily Puzzle unavailable; falling back to offline puzzle.', error?.message || error);
    } finally {
      if (timeout !== null) clearTimeout(timeout);
    }
  }
  return cached;
}
function installLichessPuzzle(puzzle) {
  const fen = String(puzzle?.fen || '');
  const line = Array.isArray(puzzle?.moves) ? puzzle.moves : [];
  if (!fen || !line.length || !validateCachedPuzzleLine(puzzle, Chess)) return false;
  puzzleState.rootFen = fen;
  puzzleState.rootPly = Math.max(0, Number(puzzle.initialPly) || 0);
  puzzleState.historyCount = rememberPuzzle(fen).length;
  puzzleSessionSeen.add(fen.trim().split(/\s+/).slice(0, 4).join(' '));
  puzzleGame = new Chess(fen);
  puzzleState.rootColor = puzzleGame.turn();
  puzzleState.solutionLine = [...line];
  puzzleState.solutionIndex = 0;
  puzzleState.solutionUci = line[0];
  puzzleState.status = 'ready';
  puzzleState.attempts = 0;
  puzzleState.puzzleStartedAt = Date.now();
  puzzleState.lastMove = null;
  puzzleState.showHint = false;
  puzzleState.source = 'lichess';
  puzzleState.sourceUrl = /^https:\/\/lichess\.org\/training\/[a-zA-Z0-9_-]{3,32}$/.test(String(puzzle.gameUrl || '')) ? String(puzzle.gameUrl) : 'https://lichess.org/training';
  puzzleState.sourceRating = Number.isFinite(Number(puzzle.rating)) ? Number(puzzle.rating) : null;
  puzzleState.sourceThemes = Array.isArray(puzzle.themes) ? puzzle.themes.slice(0, 8) : [];
  // Mate-in-one positions can legitimately have multiple mating moves; accept every legal mate.
  puzzleState.mateOnly = isMateInOneTheme(puzzleState.sourceThemes);
  puzzleState.theme = puzzleState.mateOnly ? 'Chiếu hết trong 1' : (localizePuzzleTheme(puzzleState.sourceThemes[0]) || 'Lichess hằng ngày');
  puzzleState.level = puzzleState.sourceRating ? `Elo đề ${puzzleState.sourceRating}` : (puzzle.difficulty ? `Lichess · ${puzzle.difficulty}` : 'Lichess Daily');
  puzzleState.lastMessage = `Đề tuyển chọn từ Lichess${puzzleState.sourceRating ? ` · mức ${puzzleState.sourceRating}` : ''}${puzzle.difficulty ? ` · độ khó ${puzzle.difficulty}` : ''}. Tìm toàn bộ dòng chiến thuật; nước đáp của đối thủ sẽ tự chạy. ${puzzleState.sourceThemes.length ? `Chủ đề: ${localizePuzzleThemes(puzzleState.sourceThemes).join(', ')}.` : ''}`;
  return true;
}

function startPuzzleMode(mode) {
  const allowed = new Set(['classic', 'daily', 'rush', 'survival']);
  if (!allowed.has(mode)) mode = 'classic';
  stopPuzzleRushTimer();
  puzzleGenerationEpoch += 1;
  puzzleState.busy = false; puzzleState.wrongShown = false; puzzleState.moveVerdict = '';
  puzzleState.playMode = mode;
  puzzleState.runSolved = 0;
  puzzleState.runLives = 3;
  puzzleState.rushRemainingMs = 180000;
  puzzleState.rushDeadlineAt = 0;
  puzzleState.rushActive = mode === 'rush';
  puzzleState.dailyDate = localPuzzleDateKey();
  try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch { puzzleState.dailyAlreadySolved = false; }
  puzzleState.status = 'idle';
  puzzleState.lastMessage = mode === 'daily' ? `Đang mở thử thách ngày ${puzzleState.dailyDate}…` : mode === 'rush' ? 'Puzzle Rush bắt đầu: giải càng nhiều càng tốt trước khi hết 3 phút.' : mode === 'survival' ? 'Sinh tồn: bạn có 3 mạng. Mỗi nước giải sai mất một mạng.' : 'Luyện tự do: giải câu đố theo độ khó tăng dần.';
  renderView();
  if (mode === 'rush') resumePuzzleRushTimer();
  void startRandomPuzzle();
}

function puzzleFeedbackClass() {
  return ['solved', 'revealed'].includes(puzzleState.status) ? 'success' : ['error', 'finished'].includes(puzzleState.status) && (puzzleState.playMode === 'survival' || puzzleState.status === 'error') ? 'error' : puzzleState.status === 'finished' ? 'success' : puzzleState.wrongShown ? 'error' : '';
}
function puzzleStatusChipText() {
  const ready = puzzleState.status === 'ready';
  return ready ? (puzzleState.mateOnly ? 'Chiếu hết trong 1' : (puzzleState.level || puzzleState.theme || 'Đang luyện')) : puzzleState.status === 'loading' ? 'Đang chuẩn bị' : puzzleState.status === 'solved' ? 'Đã giải' : puzzleState.status === 'revealed' ? 'Đã xem lời giải' : puzzleState.status === 'locked' ? 'Hết lượt miễn phí' : 'Sẵn sàng';
}
/** Patch the puzzle controls in place (no page re-render) after a move. */
function syncPuzzleControls() {
  if (currentView !== 'puzzles') return;
  const ready = puzzleState.status === 'ready';
  const setDisabled = (selector, value) => { const node = $(selector); if (node) node.disabled = Boolean(value); };
  setDisabled('#puzzleHint', !ready || puzzleState.busy);
  setDisabled('#puzzleShowAnswer', !ready || puzzleState.busy);
  setDisabled('#puzzleUndo', !puzzleBoardIsFree() || !puzzleGame.history().length);
  setDisabled('#puzzleAnalyze', !puzzleState.rootFen);
  const feedback = $('#puzzleFeedback');
  if (feedback) { feedback.textContent = puzzleState.lastMessage; feedback.className = `puzzle-feedback ${puzzleFeedbackClass()}`; }
  const text = (selector, value) => { const node = $(selector); if (node) node.textContent = value; };
  text('#puzzleAttempts', String(puzzleState.attempts));
  text('#puzzleSolvedCount', String(puzzleState.solvedCount));
  text('#puzzleStatusChip', puzzleStatusChipText());
  text('#puzzleStreakBanner', puzzleStreakLabel(puzzleState.streak, puzzleState.bestStreak));
  updatePuzzleModeStatus();
}
/** Repaint only the 64 squares (+ controls) and optionally slide the piece that just moved. */
function refreshPuzzleBoard(slide = null) {
  const board = $('#puzzleBoard');
  if (!board || currentView !== 'puzzles') return;
  board.innerHTML = renderPuzzleBoardMarkup();
  if (slide) slideBoardPiece(board, 'data-puzzle-square', slide);
  syncPuzzleControls();
}
function puzzleQuotaBannerMarkup() {
  const quota = puzzleQuota();
  if (quota.unlimited) return `<p class="puzzle-quota is-pro" role="status">♾ Câu đố không giới hạn · ${quota.plan === 'trial' ? 'Pro dùng thử' : `gói ${esc(PLAN_CATALOG[quota.plan]?.name || '')}`}</p>`;
  if (!quota.allowed) return `<div class="puzzle-quota is-locked" role="status"><b>Đã hết lượt câu đố</b><span>Mua thêm bằng xu ở Cửa hàng, hoặc Pro/Premium để không giới hạn.</span><button type="button" class="primary-btn" data-go-plans>💎 Xem gói Pro & Premium</button></div>`;
  return `<p class="puzzle-quota" role="status">Gói Miễn phí · còn <b>${quota.remaining}</b>/${FREE_PUZZLE_LIMIT} câu đố · <button type="button" class="text-btn" data-go-plans>Nâng cấp</button></p>`;
}
function renderPuzzleView() {
  const saved = puzzleState.solvedCount;
  const puzzleStage = Math.min(4, Math.floor(saved / 5));
  const puzzleStageLabel = ['Mới bắt đầu', 'Dễ', 'Trung bình', 'Khó', 'Chuyên sâu'][puzzleStage];
  const ready = puzzleState.status === 'ready';
  const loading = puzzleState.status === 'loading';
  const feedbackClass = puzzleFeedbackClass();
  return `<section class="content-page puzzle-page"><div class="puzzle-topline"><div class="page-intro"><div class="eyebrow">CỜ VUA · TACTICAL LAB</div><h1>Phòng luyện chiến thuật</h1><p>Luyện tự do, thử thách hằng ngày, Puzzle Rush 3 phút hoặc sinh tồn 3 mạng.</p><details class="puzzle-how-details"><summary>Cách hoạt động</summary><p>Khi có mạng, luyện tập lần lượt lấy câu mới từ Lichess theo 5 mức khó; mỗi dòng lời giải được xác minh bằng luật cờ trước khi dùng. Bạn được đi bất kỳ nước hợp lệ nào, kể cả nước sai: nước sai vẫn hiện trên bàn rồi tự trả về để thử lại. Giải xong, bàn cờ chuyển sang chế độ khám phá tự do (đi thử, hoàn tác). Rush và Sinh tồn tự mở bài kế tiếp; khi API không khả dụng, ứng dụng dùng cache hợp lệ hoặc tự sinh đề ngoại tuyến.</p></details></div><span class="puzzle-rating-chip">♞ ${puzzleStageLabel} · cấp ${puzzleStage + 1}/5</span></div><div class="puzzle-mode-row" role="group" aria-label="Chế độ luyện câu đố"><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'classic' ? 'active' : ''}" data-puzzle-mode="classic">Luyện tự do</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'daily' ? 'active' : ''}" data-puzzle-mode="daily">Đề hôm nay</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'rush' ? 'active' : ''}" data-puzzle-mode="rush">Puzzle Rush · 3 phút</button><button type="button" class="puzzle-mode-btn ${puzzleState.playMode === 'survival' ? 'active' : ''}" data-puzzle-mode="survival">Sinh tồn · 3 mạng</button><span id="puzzleModeStatus" class="puzzle-mode-status">${esc(puzzleModeStatusText())}</span></div>${puzzleQuotaBannerMarkup()}<div class="puzzle-pack-row"><div class="puzzle-pack-copy"><b>Kho câu đố ngoại tuyến</b><small><strong id="puzzlePoolCount">${readLichessPuzzlePool().length}</strong> / ${LICHESS_PUZZLE_POOL_LIMIT} câu đã lưu trên máy</small></div><button type="button" id="puzzleDownloadPack" class="secondary-btn" ${puzzlePackDownloadBusy ? 'disabled' : ''}>${puzzlePackDownloadBusy ? 'Đang tải câu đố…' : '⇩ Tải thêm 50 câu về máy'}</button><span id="puzzlePackStatus" role="status">${esc(puzzlePackDownloadStatus || 'Tải qua API Lichess; câu hợp lệ sẽ được lưu để dùng ngoại tuyến.')}</span></div><div class="puzzle-layout"><div class="puzzle-left"><div class="puzzle-board-wrap"><div id="puzzleBoard" class="puzzle-board" role="grid" aria-label="Bàn cờ câu đố">${renderPuzzleBoardMarkup()}</div></div><div class="puzzle-preset-row"><span id="puzzleStreakBanner" class="puzzle-streak-banner">${puzzleStreakLabel(puzzleState.streak, puzzleState.bestStreak)}</span>
        <button type="button" class="primary-btn puzzle-next-btn" id="puzzleNextQuick" ${loading ? 'disabled aria-busy="true"' : ''}>${loading ? 'Đang chuẩn bị câu đố…' : (puzzleState.status === 'locked' ? 'Xem gói để luyện tiếp' : puzzleNextButtonLabel(puzzleState.playMode))}</button><div class="puzzle-actions-grid">
        <button type="button" class="secondary-btn" id="puzzleNew" ${loading ? 'disabled' : ''}>${loading ? 'Đang tạo thế cờ…' : (puzzleState.status === 'finished' ? 'Chơi lại chế độ' : `${uiIcon('puzzle')}Câu đố mới`)}</button><button type="button" class="secondary-btn" id="puzzleUndo" ${puzzleBoardIsFree() && puzzleGame.history().length ? '' : 'disabled'}>${uiIcon('swap')}Hoàn tác</button><button type="button" class="secondary-btn" id="puzzleHint" ${ready ? '' : 'disabled'}>${uiIcon('sparkle')}Gợi ý</button><button type="button" class="secondary-btn" id="puzzleAnalyze" ${puzzleState.rootFen ? '' : 'disabled'}>${uiIcon('chart')}Phân tích</button><button type="button" class="secondary-btn" id="puzzleShowAnswer" ${ready ? '' : 'disabled'}>${uiIcon('eye')}Xem lời giải</button></div></div><div id="puzzleFeedback" class="puzzle-feedback ${feedbackClass}" aria-live="polite">${esc(puzzleState.lastMessage)}</div></div><div class="puzzle-right"><section class="panel puzzle-status-card"><div class="puzzle-progress-row"><div><small class="eyebrow">TIẾN BỘ CỦA BẠN</small><div><strong id="puzzleSolvedCount">${saved}</strong> câu đã giải</div></div><span class="puzzle-rating-chip" id="puzzleStatusChip">${puzzleStatusChipText()}</span></div><div class="ranked-stat-grid"><div class="ranked-stat"><small>Lượt thử</small><b id="puzzleAttempts">${puzzleState.attempts}</b></div><div class="ranked-stat"><small>Mục tiêu</small><b>${puzzleState.mateOnly ? 'Chiếu hết' : esc(puzzleState.theme || 'Chiến thuật')}</b></div><div class="ranked-stat"><small>Lịch sử đã lưu</small><b>${puzzleState.historyCount}</b></div></div><p class="puzzle-note">Câu đố không làm thay đổi Elo thi đấu. Nguồn hiện tại: ${puzzleState.source === 'lichess' ? `Lichess · mức ${puzzleState.sourceRating ?? '—'}${puzzleState.sourceThemes?.length ? ` · ${esc(localizePuzzleThemes(puzzleState.sourceThemes).join(', '))}` : ''} · <a href="${esc(puzzleState.sourceUrl || 'https://lichess.org/training')}" target="_blank" rel="noopener noreferrer">mở nguồn ↗</a>` : 'VILA ngoại tuyến · đáp án được kiểm tra bằng luật cờ cục bộ'}. Khi giải đúng, tiến độ nhiệm vụ được cập nhật.</p></section><section class="panel"><h2>Phân tích thế cờ</h2><div id="puzzleAnalysisResult" class="puzzle-feedback">${ready ? 'Chọn nước đi trên bàn cờ; gợi ý và lời giải sẽ được đánh dấu trực tiếp trên ô cờ.' : 'Tạo câu đố mới để bắt đầu.'}</div><p class="puzzle-note">Nước đi được kiểm tra bằng thư viện luật cờ vua. Câu đố có thể dùng tìm kiếm VILA hoặc thế chiếu hết trong 1 đã kiểm chứng; Stockfish dùng để phân tích thêm. Nếu engine chưa sẵn sàng, bạn vẫn có thể giải câu đố ngoại tuyến.</p></section><button type="button" class="secondary-btn full-width" id="puzzleBackToPlay">Quay lại bàn chơi ↗</button></div></div></section>`;
}
function generateRandomLegalPuzzlePosition() {
  for (let attempt = 0; attempt < 12; attempt += 1) {
    const clone = new Chess();
    const wantedPlies = 14 + Math.floor(Math.random() * 45);
    for (let ply = 0; ply < wantedPlies; ply += 1) {
      const legal = clone.moves({ verbose: true });
      if (!legal.length) break;
      const move = legal[Math.floor(Math.random() * legal.length)];
      try { clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) }); } catch { break; }
      if (clone.isGameOver()) break;
    }
    if (!clone.isGameOver() && clone.moves().length) return { fen: clone.fen(), plies: clone.history().length };
  }
  return { fen: new Chess().fen(), plies: 0 };
}
async function startRandomPuzzle() {
  const generationToken = ++puzzleGenerationEpoch;
  // A fresh puzzle must never inherit the transient "wrong move shown / opponent replying" lock.
  puzzleState.busy = false; puzzleState.wrongShown = false; puzzleState.moveVerdict = '';
  if (puzzleState.playMode === 'rush' && !puzzleState.rushActive) { puzzleState.lastMessage = 'Thời gian đã hết. Chọn Puzzle Rush để bắt đầu lượt mới.'; renderView(); return; }
  if (puzzleState.playMode === 'survival' && puzzleState.runLives <= 0) { puzzleState.status = 'finished'; renderView(); return; }
  if (!spendPuzzleQuota()) {
    stopPuzzleRushTimer(); puzzleState.rushActive = false; puzzleState.busy = false;
    puzzleState.status = 'locked';
    puzzleState.lastMessage = `Bạn đã dùng hết ${FREE_PUZZLE_LIMIT} câu đố miễn phí. Nâng cấp Pro hoặc Premium để luyện câu đố không giới hạn.`;
    if (currentView === 'puzzles') renderView();
    return;
  }
  puzzleState.status = 'loading'; puzzleState.puzzleStartedAt = Date.now(); puzzleState.lastMessage = puzzleState.playMode === 'daily' ? 'Đang tải thử thách hằng ngày; nếu mất mạng sẽ dùng bộ đề ngoại tuyến…' : 'Đang chuẩn bị câu đố mới (có thể chơi ngoại tuyến)…';
  puzzleState.showHint = false; puzzleState.selected = null; puzzleState.targets = []; puzzleState.solutionUci = '';
  puzzleState.solutionLine = []; puzzleState.solutionIndex = 0; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = []; puzzleState.source = 'offline';
  if (currentView === 'puzzles') renderView();
  try {
    // v3.25: infinite offline puzzles first (no network / Stockfish needed); Stockfish stays as a fallback.
    const history = [...new Set([...loadPuzzleHistory(), ...puzzleSessionSeen])];
    let offline = null;
    if (puzzleState.playMode === 'daily') {
      const dailyPuzzle = await loadLichessDailyPuzzle(puzzleState.dailyDate || localPuzzleDateKey(), generationToken);
      if (generationToken !== puzzleGenerationEpoch) return;
      if (dailyPuzzle && installLichessPuzzle(dailyPuzzle)) {
        try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch { puzzleState.dailyAlreadySolved = false; }
        if (puzzleState.dailyAlreadySolved) puzzleState.lastMessage += ' Bạn đã hoàn thành đề hôm nay; luyện lại không cộng điểm lần nữa.';
        if (currentView === 'puzzles') renderView();
        return;
      }
      offline = await generateDailyPuzzleInWorker(puzzleState.dailyDate || localPuzzleDateKey());
      if (generationToken !== puzzleGenerationEpoch) return;
    } else {
      // Prefer a unique live Lichess puzzle; the bounded validated cache supplies a rotating offline queue.
      const requestedDifficulty = lichessDifficultyForProgress(puzzleState.solvedCount);
      const onlinePuzzle = await loadLichessTrainingPuzzle(requestedDifficulty, generationToken);
      if (generationToken !== puzzleGenerationEpoch) return;
      if (onlinePuzzle && installLichessPuzzle({ ...onlinePuzzle, difficulty: requestedDifficulty })) {
        if (currentView === 'puzzles') renderView();
        return;
      }
      // Fallback still works completely offline and raises the local generator tier as progress grows.
      const localTier = Math.min(3, Math.floor(puzzleState.solvedCount / 3));
      // Verified multi-move mates from the bundled Stockfish-checked bank come before the one-move generator.
      const bankPick = pickBankPuzzle(new Set([...history, ...puzzleSessionSeen]), localTier);
      if (bankPick && installLichessPuzzle({ fen: bankPick.fen, moves: bankPick.moves, themes: [], initialPly: 0 })) {
        puzzleState.source = 'offline'; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.mateOnly = false;
        puzzleState.theme = `Chiếu hết trong ${bankPick.mateIn}`; puzzleState.level = 'Đã xác minh bằng Stockfish 19';
        puzzleState.lastMessage = `Tìm đường chiếu hết trong ${bankPick.mateIn} nước cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'}. Đề đã được Stockfish kiểm tra: nước đầu là duy nhất.`;
        if (currentView === 'puzzles') renderView();
        return;
      }
      let fallbackSameTheme = null;
      for (let attempt = 0; attempt < 8 && !offline; attempt += 1) {
        const candidate = await generateOfflinePuzzle({ budgetMs: 6000, excludeFens: history, difficulty: localTier });
        if (generationToken !== puzzleGenerationEpoch) return;
        if (!candidate || history.includes(candidate.fen.trim().split(/\s+/).slice(0, 4).join(' '))) continue;
        // Prefer a theme that has not appeared in the last two puzzles so practice does not feel repetitive.
        if (puzzleRecentThemes.slice(-2).includes(candidate.theme) && attempt < 6) { fallbackSameTheme = fallbackSameTheme || candidate; continue; }
        offline = candidate;
      }
      offline = offline || fallbackSameTheme;
    }
    if (generationToken !== puzzleGenerationEpoch) return;
    if (puzzleState.playMode === 'daily' && (!offline || !isPuzzleAnswerLegal(offline))) {
      throw new Error('Không tạo được đề hằng ngày đã xác minh; thử lại sau hoặc dùng Luyện tự do.');
    }
    if (offline && isPuzzleAnswerLegal(offline)) {
      puzzleState.rootFen = offline.fen;
      puzzleSessionSeen.add(offline.fen.trim().split(/\s+/).slice(0, 4).join(' '));
      puzzleState.historyCount = rememberPuzzle(offline.fen).length; puzzleState.rootPly = offline.plies;
      if (puzzleState.playMode === 'daily') { puzzleState.dailyDate = offline.dailyDate || puzzleState.dailyDate; try { puzzleState.dailyAlreadySolved = localStorage.getItem(PUZZLE_DAILY_SOLVED_KEY) === puzzleState.dailyDate; } catch {} }
      puzzleState.rootColor = new Chess(offline.fen).turn(); puzzleGame = new Chess(offline.fen);
      puzzleState.solutionUci = offline.best; puzzleState.solutionLine = [offline.best]; puzzleState.solutionIndex = 0; puzzleState.status = 'ready'; puzzleState.attempts = 0; puzzleState.puzzleStartedAt = Date.now();
      puzzleState.lastMove = null; puzzleState.showHint = false; puzzleState.source = 'offline'; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = []; puzzleState.mateOnly = offline.mateOnly;
      puzzleState.theme = offline.theme; puzzleState.level = offline.level; puzzleRecentThemes.push(offline.theme); if (puzzleRecentThemes.length > 6) puzzleRecentThemes.shift();
      puzzleState.lastMessage = puzzleState.playMode === 'daily' ? `[Thử thách ngày ${puzzleState.dailyDate}] Chiếu hết trong 1 — tìm nước duy nhất. ${puzzleState.dailyAlreadySolved ? 'Bạn đã hoàn thành đề hôm nay; lần luyện lại không cộng điểm lần nữa.' : 'Lời giải được kiểm tra có đúng một nước chiếu hết.'}` : `[${offline.theme} · ${offline.level}] ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi — tìm nước tốt nhất. Chọn quân rồi chạm ô đích.`;
      if (currentView === 'puzzles') renderView();
      return;
    }
    puzzleState.source = 'stockfish'; puzzleState.mateOnly = false;
    let chosen = null;
    // Try several legal random positions to prefer a tactical best move (capture,
    // promotion, check, or mate). A fallback keeps the feature usable on a position
    // where the engine's best move is positional instead of forcing.
    for (let attempt = 0; attempt < 7; attempt += 1) {
      const position = generateRandomLegalPuzzlePosition();
      const positionKey = position.fen.trim().split(/\s+/).slice(0, 4).join(' ');
      if (history.includes(positionKey)) continue;
      // MultiPV matters: a legal capture/check alone does not make a fair puzzle.
      // Require a visible tactical move and a meaningful evaluation gap to the runner-up.
      const variations = await requestStockfishUci(position.fen, { skill: 20, depth: 16, moveTimeMs: 1050, timeoutMs: 11000, multiPv: 3 });
      if (generationToken !== puzzleGenerationEpoch) return;
      const quality = selectVerifiedTacticalCandidate(position.fen, variations, Chess, {
        minimumGapCp: 180, minimumScoreCp: 80, minimumDepth: 6, maximumDepthDisparity: 2
      });
      if (!quality) continue;
      chosen = { position, best: quality.uci, tactical: true, quality };
      break;
    }
    if (!chosen) throw new Error('Không tìm được thế cờ để chấm.');
    const stockfishPuzzle = { fen: chosen.position.fen, best: chosen.best };
    if (!isPuzzleAnswerLegal(stockfishPuzzle)) throw new Error('Nước giải không vượt qua bước kiểm tra hợp lệ.');
    puzzleSessionSeen.add(chosen.position.fen.trim().split(/\s+/).slice(0, 4).join(' '));
    puzzleState.rootFen = chosen.position.fen; puzzleState.historyCount = rememberPuzzle(chosen.position.fen).length; puzzleState.rootPly = chosen.position.plies;
    puzzleState.rootColor = new Chess(chosen.position.fen).turn(); puzzleGame = new Chess(chosen.position.fen);
    puzzleState.solutionUci = chosen.best; puzzleState.solutionLine = [chosen.best]; puzzleState.solutionIndex = 0; puzzleState.status = 'ready'; puzzleState.attempts = 0; puzzleState.puzzleStartedAt = Date.now();
    puzzleState.lastMove = null; puzzleState.showHint = false; puzzleState.sourceUrl = ''; puzzleState.sourceRating = null; puzzleState.sourceThemes = [];
    puzzleState.theme = chosen.quality?.mate ? 'Chiếu hết' : 'Chiến thuật';
    puzzleState.level = chosen.quality ? `Stockfish · chênh ${Math.round(chosen.quality.gapCp)} cp` : 'Stockfish';
    puzzleState.lastMessage = `Tìm nước chiến thuật tốt nhất cho ${puzzleGame.turn() === 'w' ? 'Trắng' : 'Đen'} đi. Đề chỉ được nhận khi nước giải hợp lệ, có tính chiến thuật và vượt rõ phương án thứ hai. Chọn quân rồi chạm ô đích.`;
  } catch (error) {
    if (generationToken !== puzzleGenerationEpoch) return;
    puzzleState.status = 'error'; puzzleState.lastMessage = `Không tạo được câu đố: ${String(error.message || error)}. Bấm “Câu đố mới” để thử lại hoặc đổi sang Đề hôm nay.`;
  }
  if (currentView === 'puzzles') renderView();
}
function selectPuzzleSquare(square) {
  if (!puzzleBoardIsInteractive()) return;
  const piece = puzzleGame.get(square);
  if (puzzleState.selected && puzzleState.targets.some(move => move.to === square)) {
    void submitPuzzleMove(puzzleState.targets.filter(move => move.to === square));
    return;
  }
  if (piece && piece.color === puzzleGame.turn() && puzzleState.selected !== square) {
    puzzleState.selected = square; puzzleState.targets = puzzleGame.moves({ square, verbose: true });
  } else { puzzleState.selected = null; puzzleState.targets = []; }
  refreshPuzzleBoard();
}
/** Entry point for taps and drops: resolves promotion, then routes to free play or answer checking. */
async function submitPuzzleMove(options, { noSlide = false } = {}) {
  if (!options?.length || !puzzleBoardIsInteractive()) return;
  const fen = puzzleGame.fen();
  let candidate = options[0];
  if (options.some(move => move.promotion)) {
    const type = visualSettings.autoQueen ? 'q' : await choosePromotion(puzzleGame.turn());
    if (puzzleGame.fen() !== fen) return;
    if (!type) { puzzleState.selected = null; puzzleState.targets = []; refreshPuzzleBoard(); return; }
    candidate = options.find(move => move.promotion === type) || options[0];
  }
  if (puzzleBoardIsFree()) playPuzzleFreeMove(candidate, { noSlide });
  else await submitPuzzleAnswer(candidate, { noSlide });
}
function playPuzzleFreeMove(candidate, { noSlide = false } = {}) {
  let move = null;
  try { move = puzzleGame.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) }); } catch { move = null; }
  puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false;
  if (!move) { refreshPuzzleBoard(); return; }
  puzzleState.lastMove = move; puzzleState.moveVerdict = ''; puzzleState.wrongShown = false;
  const output = $('#puzzleAnalysisResult');
  if (output) {
    const end = puzzleGame.isCheckmate() ? ' · Chiếu hết!' : puzzleGame.isStalemate() ? ' · Hòa (hết nước đi)' : puzzleGame.isDraw() ? ' · Hòa' : puzzleGame.isCheck() ? ' · Chiếu!' : '';
    output.textContent = `Khám phá tự do: ${puzzleGame.history().slice(-6).join(' · ')}${end}`;
  }
  playMoveSoundFor(move, puzzleGame);
  refreshPuzzleBoard(noSlide ? null : slideFromMove(move));
}
function playMoveSoundFor(move, chess) {
  try { if (move && chess) playBoardSound(move, chess, settings.soundEnabled, settings.soundTheme); } catch {}
}
function undoPuzzleFreeMove() {
  if (!puzzleBoardIsFree() || !puzzleGame.history().length) return;
  try { puzzleGame.undo(); } catch { return; }
  puzzleState.lastMove = puzzleGame.history({ verbose: true }).at(-1) || null;
  puzzleState.moveVerdict = ''; puzzleState.wrongShown = false; puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false;
  refreshPuzzleBoard();
}
function showPuzzleHint(reveal = false) {
  const line = Array.isArray(puzzleState.solutionLine) && puzzleState.solutionLine.length ? puzzleState.solutionLine : [puzzleState.solutionUci];
  const remaining = line.slice(Math.max(0, puzzleState.solutionIndex || 0));
  if (!remaining[0]) { toast('Tạo câu đố trước khi xin gợi ý.'); return; }
  puzzleState.showHint = true;
  const answerBoard = new Chess(puzzleGame.fen());
  const sanLine = [];
  try {
    const next = answerBoard.move(uciToMove(remaining[0]));
    if (!next) throw new Error('Nước kế tiếp không hợp lệ.');
    sanLine.push(next.san);
    if (reveal) {
      for (const uci of remaining.slice(1)) {
        const move = answerBoard.move(uciToMove(uci));
        if (!move) throw new Error('Dòng lời giải không hợp lệ.');
        sanLine.push(move.san);
      }
    }
  } catch (error) { toast(`Không thể xác minh lời giải: ${error.message || error}`); return; }
  const currentUci = remaining[0];
  const output = $('#puzzleAnalysisResult');
  if (output) output.textContent = `${reveal ? 'Lời giải còn lại' : 'Gợi ý'}: ${sanLine.join(' · ')}. ${!reveal ? `Nước kế tiếp: ${currentUci}. Ô đi và ô đến đã được đánh dấu.` : ''}`;
  if (reveal && puzzleState.status === 'ready') {
    puzzleState.status = 'revealed';
    puzzleState.lastMessage = `Dòng lời giải: ${sanLine.join(' · ')}. Đây chỉ là xem lời giải, không tính là tự giải đúng.`;
    puzzleState.lastMove = answerBoard.history({ verbose: true }).at(-1) || null;
    puzzleGame = answerBoard; puzzleState.solutionIndex = line.length;
    puzzleState.selected = null; puzzleState.targets = [];
    puzzleState.moveVerdict = ''; puzzleState.wrongShown = false;
  }
  refreshPuzzleBoard();
}
function puzzleLineAndIndex() {
  const line = Array.isArray(puzzleState.solutionLine) && puzzleState.solutionLine.length ? puzzleState.solutionLine : [puzzleState.solutionUci];
  const expectedIndex = Math.max(0, Number(puzzleState.solutionIndex) || 0);
  return { line, expectedIndex, expectedUci: line[expectedIndex] || puzzleState.solutionUci };
}
/** Any legal move is played on the board. A wrong one is shown with a red ✕, then rolled back. */
async function submitPuzzleAnswer(candidate, { noSlide = false } = {}) {
  if (puzzleState.status !== 'ready' || puzzleState.busy) return;
  const token = puzzleGenerationEpoch;
  const input = { from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) };
  const uci = `${candidate.from}${candidate.to}${candidate.promotion || ''}`;
  puzzleState.attempts += 1;
  const { line, expectedIndex, expectedUci } = puzzleLineAndIndex();
  let acceptable = uci === expectedUci;
  if (!acceptable && puzzleState.mateOnly) {
    const probe = new Chess(puzzleGame.fen());
    try { probe.move(input); acceptable = probe.isCheckmate(); } catch {}
  }
  puzzleState.selected = null; puzzleState.targets = []; puzzleState.showHint = false;
  const previousLast = puzzleState.lastMove;
  let move = null;
  try { move = puzzleGame.move(input); } catch { move = null; }
  if (!move) { puzzleState.lastMessage = 'Nước đi không còn hợp lệ ở vị trí hiện tại.'; refreshPuzzleBoard(); return; }
  playMoveSoundFor(move, puzzleGame);
  const slide = noSlide ? null : slideFromMove(move);
  puzzleState.lastMove = move;
  if (!acceptable) { handleWrongPuzzleMove(move, previousLast, slide, token); return; }

  puzzleState.wrongShown = false; puzzleState.moveVerdict = 'good';
  const nextIndex = expectedIndex + 1;
  const hasReply = nextIndex < line.length && !puzzleGame.isGameOver();
  if (!hasReply) {
    puzzleState.solutionIndex = line.length;
    refreshPuzzleBoard(slide);
    completePuzzleSolved([move.san]);
    return;
  }
  // Curated multi-ply puzzle: show the player's move first, then answer with the forced reply.
  puzzleState.busy = true;
  puzzleState.lastMessage = `Đúng: ${move.san}. Đối thủ đang đáp…`;
  refreshPuzzleBoard(slide);
  setTimeout(() => {
    if (token !== puzzleGenerationEpoch || puzzleState.status !== 'ready') { if (token === puzzleGenerationEpoch) puzzleState.busy = false; return; }
    let reply = null;
    try { reply = puzzleGame.move(uciToMove(line[nextIndex])); } catch { reply = null; }
    puzzleState.busy = false;
    if (!reply) { puzzleState.lastMessage = 'Nước đáp của lời giải không hợp lệ.'; refreshPuzzleBoard(); return; }
    playMoveSoundFor(reply, puzzleGame);
    puzzleState.lastMove = reply; puzzleState.moveVerdict = '';
    puzzleState.solutionIndex = nextIndex + 1;
    if (nextIndex + 1 >= line.length || puzzleGame.isGameOver()) {
      refreshPuzzleBoard(slideFromMove(reply));
      completePuzzleSolved([move.san, reply.san]);
      return;
    }
    puzzleState.solutionUci = line[nextIndex + 1];
    puzzleState.lastMessage = `Đúng: ${move.san}. Đối thủ đáp ${reply.san}. Tiếp tục tìm nước tiếp theo trong dòng chiến thuật.`;
    refreshPuzzleBoard(slideFromMove(reply));
  }, 420);
}
function handleWrongPuzzleMove(move, previousLast, slide, token) {
  puzzleState.wrongShown = true; puzzleState.moveVerdict = 'bad';
  puzzleState.streak = 0;
  try { localStorage.setItem('vila.chess.puzzles.streak.v1', '0'); } catch {}
  let lost = false;
  if (puzzleState.playMode === 'survival') {
    puzzleState.runLives = Math.max(0, puzzleState.runLives - 1);
    lost = puzzleState.runLives <= 0;
  }
  if (lost) {
    puzzleState.status = 'finished';
    puzzleState.lastMessage = `Hết mạng! Bạn giải đúng ${puzzleState.runSolved} câu sinh tồn. Chọn Sinh tồn để bắt đầu lượt mới.`;
    renderView();
    return;
  }
  puzzleState.busy = true;
  puzzleState.lastMessage = puzzleState.playMode === 'survival'
    ? `✕ ${move.san} chưa đúng — mất 1 mạng, còn ${puzzleState.runLives}. Thế cờ sẽ được trả lại để bạn thử tiếp.`
    : `✕ ${move.san} chưa phải nước tốt nhất. Thế cờ sẽ được trả lại — thử nước khác hoặc xem gợi ý.`;
  refreshPuzzleBoard(slide);
  setTimeout(() => {
    if (token !== puzzleGenerationEpoch) return;
    puzzleState.busy = false;
    if (!puzzleState.wrongShown || puzzleState.status !== 'ready') return;
    try { puzzleGame.undo(); } catch {}
    puzzleState.wrongShown = false; puzzleState.moveVerdict = '';
    puzzleState.lastMove = previousLast || null;
    puzzleState.lastMessage = puzzleState.playMode === 'survival'
      ? `Còn ${puzzleState.runLives} mạng. Thử nước khác.`
      : 'Thử nước khác, hoặc bấm Gợi ý.';
    refreshPuzzleBoard();
  }, 950);
}
function completePuzzleSolved(playedSan) {
  puzzleState.status = 'solved';
  puzzleState.busy = false;
  const dailyAlreadyCredited = puzzleState.playMode === 'daily' && puzzleState.dailyAlreadySolved;
  const sourceLabel = puzzleState.source === 'lichess' ? 'Câu đố tuyển chọn Lichess đã xác minh luật' : puzzleState.source === 'offline' ? 'Thế cờ được kiểm tra ngoại tuyến' : 'Nước đi được Stockfish đề xuất';
  const auto = ['rush', 'survival'].includes(puzzleState.playMode);
  puzzleState.lastMessage = `Chính xác: ${playedSan.join(' · ')}. ${sourceLabel}. ${dailyAlreadyCredited ? 'Bạn đã nhận thành tích đề hôm nay trước đó; lần luyện lại không cộng thêm. ' : ''}${auto ? '' : 'Bạn có thể đi thử tự do trên bàn cờ hoặc bấm Câu tiếp theo.'}`;
  if (!dailyAlreadyCredited) puzzleState.solvedCount += 1;
  if (['rush', 'survival'].includes(puzzleState.playMode)) { puzzleState.runSolved += 1; if (puzzleState.playMode === 'rush' && puzzleState.runSolved > puzzleState.rushBest) { puzzleState.rushBest = puzzleState.runSolved; try { localStorage.setItem(PUZZLE_RUSH_BEST_KEY, String(puzzleState.rushBest)); } catch {} } }
  if (puzzleState.playMode === 'daily' && !dailyAlreadyCredited) { puzzleState.dailyAlreadySolved = true; try { localStorage.setItem(PUZZLE_DAILY_SOLVED_KEY, puzzleState.dailyDate); } catch {} }
  puzzleState.lastSolveMs = Math.max(0, Date.now() - (puzzleState.puzzleStartedAt || Date.now()));
  if (!dailyAlreadyCredited) { puzzleState.streak += 1; puzzleState.bestStreak = Math.max(puzzleState.bestStreak, puzzleState.streak); }
  try {
    localStorage.setItem('vila.chess.puzzles.streak.v1', String(puzzleState.streak));
    localStorage.setItem('vila.chess.puzzles.bestStreak.v1', String(puzzleState.bestStreak));
    localStorage.setItem('vila.chess.puzzles.solved.v1', String(puzzleState.solvedCount));
  } catch {}
  if (!dailyAlreadyCredited) recordDailyEvent('solve_puzzle');
  syncPuzzleControls();
  if (auto) setTimeout(() => {
    if (currentView !== 'puzzles' || puzzleState.status !== 'solved' || (puzzleState.playMode === 'rush' && !puzzleState.rushActive) || (puzzleState.playMode === 'survival' && puzzleState.runLives <= 0)) return;
    void startRandomPuzzle();
  }, 700);
}
function wireRankedActions() {
  $('#rankedOpenAccount')?.addEventListener('click', () => setView('friends'));
  $('#rankedTimeControl')?.addEventListener('change', event => {
    const value = event.currentTarget.value;
    if (!setSelectedRankedTimeControl(value)) return;
    const category = classifyTimeControl(value);
    rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, category), timeControl: value, timeCategory: category };
    renderView();
  });
  $('#rankedQueueStart')?.addEventListener('click', startRankedQueue);
  $('#rankedQueueCancel')?.addEventListener('click', async () => { try { await socialApi('/ranked/cancel-queue', { method: 'POST', body: '{}' }); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, classifyTimeControl(selectedRankedTimeControl)) }; renderView(); toast('Đã hủy hàng đợi.'); } catch (error) { toast(`Không thể hủy hàng đợi: ${error.message || error}`); } });
  $('#rankedQueueAgain')?.addEventListener('click', async () => { setSelectedRankedTimeControl(rankedMatchState?.match?.timeControl || selectedRankedTimeControl); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, classifyTimeControl(selectedRankedTimeControl)) }; await startRankedQueue(); });
  $('#rankedForfeitBtn')?.addEventListener('click', () => showBrandedConfirm({ title: 'Đầu hàng / thoát trận?', subtitle: 'Trận xếp hạng sẽ được ghi nhận là thua; Elo có thể giảm theo kết quả máy chủ. Bạn có chắc muốn tiếp tục?', confirmLabel: 'Xác nhận đầu hàng', tone: 'loss', onConfirm: () => quitRankedMatch(false) }));
  attachBoardDrag($('#rankedBoard'), {
    attr: 'data-ranked-square',
    orientation: () => (rankedMatchState?.match?.color === 'b' ? 'b' : 'w'),
    getPiece: square => rankedChess.get(square),
    canDrag: piece => rankedCanMoveNow() && piece.color === rankedMatchState.match.color,
    getLegal: square => rankedChess.moves({ square, verbose: true }),
    pieceMarkup: piece => pieceGlyph(piece),
    onTap: square => rankedHandleTap(square),
    onDragStart: (from, moves) => {
      rankedSelected = from; rankedTargets = moves;
      const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(rankedMatchState.match);
    },
    onDrop: (from, to, moves) => { rankedSelected = null; rankedTargets = []; void rankedPlayMove(from, to, moves, true); },
    onDragEnd: () => { rankedSelected = null; rankedTargets = []; const board = $('#rankedBoard'); if (board && rankedMatchState?.match) board.innerHTML = rankedBoardMarkup(rankedMatchState.match); }
  });
  if (rankedMatchState?.queued || rankedMatchState?.match?.status === 'active') startRankedPolling();
  if (rankedMatchState?.match) { const board = $('#rankedBoard'); if (board) board.innerHTML = rankedBoardMarkup(rankedMatchState.match); }
}
function wirePuzzleBoardPointer(board) {
  attachBoardDrag(board, {
    attr: 'data-puzzle-square',
    orientation: () => puzzleState.rootColor || 'w',
    getPiece: square => puzzleGame.get(square),
    canDrag: piece => puzzleBoardIsInteractive() && piece.color === puzzleGame.turn(),
    getLegal: square => puzzleGame.moves({ square, verbose: true }),
    pieceMarkup: piece => pieceGlyph(piece),
    onTap: square => selectPuzzleSquare(square),
    onDragStart: (from, moves) => { puzzleState.selected = from; puzzleState.targets = moves; refreshPuzzleBoard(); },
    onDrop: (_from, _to, moves) => { void submitPuzzleMove(moves, { noSlide: true }); },
    onDragEnd: () => { puzzleState.selected = null; puzzleState.targets = []; refreshPuzzleBoard(); }
  });
}
function wirePuzzleActions() {
  $$('[data-go-plans]').forEach(button => button.addEventListener('click', () => setView('plans')));
  wirePuzzleBoardPointer($('#puzzleBoard'));
  $$('[data-puzzle-mode]').forEach(button => button.addEventListener('click', () => startPuzzleMode(button.dataset.puzzleMode)));
  // Một hàm dùng chung cho cả hai nút "tiếp theo": chặn bấm đúp khi đang tải, và gửi người dùng tới Gói khi hết lượt.
  const requestNextPuzzle = () => {
    if (puzzleState.status === 'loading') return;
    if (puzzleState.status === 'locked') { setView('plans'); return; }
    if (puzzleState.status === 'finished') startPuzzleMode(puzzleState.playMode); else void startRandomPuzzle();
  };
  $('#puzzleNew')?.addEventListener('click', requestNextPuzzle);
  $('#puzzleNextQuick')?.addEventListener('click', requestNextPuzzle);
  $('#puzzleDownloadPack')?.addEventListener('click', () => { void downloadLichessPuzzlePack(); });
  $('#puzzleHint')?.addEventListener('click', () => showPuzzleHint(false));
  $('#puzzleShowAnswer')?.addEventListener('click', () => showPuzzleHint(true));
  $('#puzzleAnalyze')?.addEventListener('click', async () => {
    if (!puzzleState.rootFen) return;
    const output = $('#puzzleAnalysisResult'); if (output) output.textContent = 'Stockfish đang phân tích thế cờ…';
    try {
      const best = await requestStockfishUci(puzzleState.rootFen, { skill: 20, depth: 20, moveTimeMs: 1800, timeoutMs: 18000 });
      const clone = new Chess(puzzleState.rootFen); const move = clone.move({ from: best.slice(0,2), to: best.slice(2,4), ...(best[4] ? { promotion: best[4] } : {}) });
      puzzleState.solutionUci = best; puzzleState.showHint = true;
      if (output) output.textContent = move ? `Nước tốt nhất theo Stockfish: ${move.san} (${best}). Mũi chỉ dẫn đánh dấu trên bàn cờ.` : `Engine trả về ${best}.`;
      refreshPuzzleBoard();
    } catch (error) { if (output) output.textContent = `Không thể phân tích: ${error.message || error}`; }
  });
  $('#puzzleBackToPlay')?.addEventListener('click', () => setView('play'));
  $('#puzzleUndo')?.addEventListener('click', undoPuzzleFreeMove);
}

// ---- Chess.com-style end-of-game dialog: result, Elo, rematch / new match, analysis ----
let resultModalKey = '';
let resultModalPrevFocus = null;
function closeResultModal() {
  const node = document.getElementById('resultModal');
  if (!node) return;
  node.remove();
  document.removeEventListener('keydown', resultModalKeydown, true);
  try { resultModalPrevFocus?.focus?.({ preventScroll: true }); } catch {}
  resultModalPrevFocus = null;
}
function resultModalKeydown(event) {
  if (event.key === 'Escape') { event.stopPropagation(); closeResultModal(); }
}
function showResultModal({ key, tone = 'draw', icon = '½', title, subtitle = '', players = '', stats = [], actions = [] }) {
  if (!key || resultModalKey === key) return;
  resultModalKey = key;
  document.getElementById('resultModal')?.remove();
  const statHtml = stats.filter(Boolean).map(item => `<div><small>${esc(item.label)}</small><b class="${esc(item.tone || '')}">${esc(item.value)}</b></div>`).join('');
  const actionHtml = actions.map((action, index) => `<button type="button" class="${action.primary ? 'primary-btn' : 'secondary-btn'} result-modal-action" data-result-action="${index}">${esc(action.label)}</button>`).join('');
  const wrap = document.createElement('div');
  wrap.id = 'resultModal';
  wrap.className = 'result-modal-backdrop';
  wrap.innerHTML = `<div class="result-modal tone-${esc(tone)}" role="dialog" aria-modal="true" aria-labelledby="resultModalTitle"><button type="button" class="result-modal-close" aria-label="Đóng bảng kết quả">×</button><div class="result-modal-brand"><img src="./covua-vila-logo.webp" alt=""/><span><b>CỜ VUA VILA</b><small>TRẬN ĐẤU · TỔNG KẾT</small></span></div><div class="result-modal-badge" aria-hidden="true">${esc(icon)}</div><h2 id="resultModalTitle">${esc(title)}</h2>${subtitle ? `<p class="result-modal-sub">${esc(subtitle)}</p>` : ''}${players ? `<div class="result-modal-players">${esc(players)}</div>` : ''}${statHtml ? `<div class="result-modal-stats">${statHtml}</div>` : ''}<div class="result-modal-actions">${actionHtml}</div></div>`;
  wrap.addEventListener('click', event => { if (event.target === wrap) closeResultModal(); });
  wrap.querySelector('.result-modal-close')?.addEventListener('click', closeResultModal);
  wrap.querySelectorAll('[data-result-action]').forEach(button => button.addEventListener('click', () => {
    const action = actions[Number(button.dataset.resultAction)];
    closeResultModal();
    try { action?.run?.(); } catch (error) { toast(`Không thực hiện được: ${error.message || error}`); }
  }));
  resultModalPrevFocus = document.activeElement;
  document.body.appendChild(wrap);
  document.addEventListener('keydown', resultModalKeydown, true);
  wrap.querySelector('.result-modal-action')?.focus({ preventScroll: true });
}
function showBrandedConfirm({ title, subtitle = '', confirmLabel = 'Xác nhận', cancelLabel = 'Ở lại', tone = 'draw', onConfirm = () => {} } = {}) {
  document.getElementById('vilaConfirmModal')?.remove();
  const wrap = document.createElement('div');
  wrap.id = 'vilaConfirmModal';
  wrap.className = 'result-modal-backdrop vila-confirm-backdrop';
  wrap.innerHTML = `<div class="result-modal vila-confirm-modal tone-${esc(tone)}" role="dialog" aria-modal="true" aria-labelledby="vilaConfirmTitle" aria-describedby="vilaConfirmDescription"><button type="button" class="result-modal-close" data-confirm-cancel aria-label="Đóng bảng xác nhận">×</button><div class="result-modal-brand"><img src="./covua-vila-logo.webp" alt=""/><span><b>CỜ VUA VILA</b><small>XÁC NHẬN THAO TÁC</small></span></div><div class="result-modal-badge" aria-hidden="true">${tone === 'loss' ? '!' : '♞'}</div><h2 id="vilaConfirmTitle">${esc(title)}</h2><p class="result-modal-sub" id="vilaConfirmDescription">${esc(subtitle)}</p><div class="result-modal-actions"><button type="button" class="primary-btn result-modal-action" data-confirm-yes>${esc(confirmLabel)}</button><button type="button" class="secondary-btn result-modal-action" data-confirm-cancel>${esc(cancelLabel)}</button></div></div>`;
  const clean = () => { wrap.remove(); document.removeEventListener('keydown', onKeydown, true); };
  const cancel = () => { clean(); };
  const confirm = async () => { clean(); try { await onConfirm(); } catch (error) { toast(`Không thực hiện được: ${error?.message || error}`, 'error'); } };
  const onKeydown = event => { if (event.key === 'Escape') { event.stopPropagation(); cancel(); } };
  wrap.addEventListener('click', event => { if (event.target === wrap) cancel(); });
  wrap.querySelectorAll('[data-confirm-cancel]').forEach(button => button.addEventListener('click', cancel));
  wrap.querySelector('[data-confirm-yes]')?.addEventListener('click', confirm);
  document.body.appendChild(wrap);
  document.addEventListener('keydown', onKeydown, true);
  wrap.querySelector('[data-confirm-cancel]')?.focus({ preventScroll: true });
}

function resultToneFor(token, perspective) {
  if (token === '1/2-1/2') return { tone: 'draw', icon: '½', title: 'Hòa cờ' };
  if (!perspective) return { tone: 'win', icon: '♚', title: token === '1-0' ? 'Trắng thắng' : 'Đen thắng' };
  const won = (token === '1-0' && perspective === 'w') || (token === '0-1' && perspective === 'b');
  return won ? { tone: 'win', icon: '♛', title: 'Bạn thắng!' } : { tone: 'loss', icon: '♟', title: 'Bạn thua' };
}
function syntheticRecord(pgn, token, title, detail, signature) {
  return { id: signature, signature, pgn, startFen: new Chess().fen(), resultToken: token, title, detail, reviewRows: [] };
}
function maybeShowPlayResultModal() {
  if (currentView !== 'play' || !gameStarted || mode === 'lichess') return;
  if (!(game.isGameOver() || clockFlagged || manualGameResult)) return;
  if (manualGameResult?.reason === 'saved-replay') return;
  const result = getGameResult();
  if (!['1-0', '0-1', '1/2-1/2'].includes(result.token)) return;
  const solo = mode !== 'local';
  const look = resultToneFor(result.token, solo ? humanColor : null);
  const rated = ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode);
  const profile = rated ? readRatingProfile() : null;
  const opponent = isStockfishBotMode(mode) ? 'Stockfish 19' : mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : ''; 
  showResultModal({
    key: `play:${currentGameId}:${result.token}`,
    ...look,
    subtitle: `${result.title}${result.detail ? ' — ' + result.detail : ''}`,
    players: opponent ? `${humanColor === 'w' ? 'Bạn' : opponent} (Trắng) · ${humanColor === 'b' ? 'Bạn' : opponent} (Đen)` : 'Trắng · Đen',
    stats: [
      { label: 'Số nước', value: String(Math.ceil(game.history().length / 2)) },
      profile ? { label: 'Elo', value: String(profile.elo) } : null,
      profile && profile.lastChange ? { label: 'Biến động', value: `${profile.lastChange > 0 ? '+' : ''}${profile.lastChange}`, tone: profile.lastChange > 0 ? 'up' : 'down' } : null,
      engineSpeed && (isStockfishBotMode(mode) || mode === 'enginehub' || mode === 'vila') ? { label: 'Tốc độ engine', value: engineSpeed.nps ? `${formatNps(engineSpeed.nps)} nút/giây` : `d${engineSpeed.depth}` } : null
    ],
    actions: [
      { label: '↻ Chơi lại', primary: true, run: () => freshGame() },
      { label: '♞ Phân tích ván', run: () => { setView('review'); setTimeout(() => startFullGameReview(), 100); } },
      { label: '⚔ Ghép trận xếp hạng', run: () => setView('ranked') }
    ]
  });
}
function maybeShowRankedResultModal() {
  const match = rankedMatchState?.match;
  if (currentView !== 'ranked' || !match || match.status === 'active') return;
  const color = match.color || 'w';
  const category = ['bullet', 'blitz', 'rapid', 'daily'].includes(match.timeCategory) ? match.timeCategory : classifyTimeControl(match.timeControl || '1d');
  const look = resultToneFor(match.result, color);
  const change = match.eloChanges;
  const delta = Number(change?.delta) || 0;
  const opponent = match.opponent || (color === 'w' ? match.players?.b : match.players?.w);
  showResultModal({
    key: `ranked:${match.id}`,
    ...look,
    subtitle: `${rankedCategoryLabel(category)} · ${match.timeControl || ''}`,
    players: `Đối thủ: ${opponent?.displayName || opponent?.username || 'Người chơi'}`,
    stats: [
      Number.isFinite(Number(change?.after)) ? { label: 'Elo mới', value: String(Number(change.after)) } : null,
      { label: 'Biến động', value: `${delta > 0 ? '+' : ''}${delta}`, tone: delta > 0 ? 'up' : delta < 0 ? 'down' : '' },
      { label: 'Số nước', value: String(Math.ceil(rankedChess.history().length / 2)) }
    ],
    actions: [
      { label: '⚔ Ghép trận mới', primary: true, run: async () => { setSelectedRankedTimeControl(match.timeControl || selectedRankedTimeControl); rankedMatchState = { queued: false, rating: rankedRatingOf(socialState.user, category) }; await startRankedQueue(); } },
      { label: '♞ Phân tích ván', run: () => restoreSavedGame(syntheticRecord(rankedChess.pgn(), match.result, look.title, `Trận xếp hạng ${match.timeControl || ''}`, `ranked-${match.id}`), true) }
    ]
  });
}
function showArenaResultModal(white, black, result) {
  if (!result || result.stopped || !result.pgn) return;
  const winnerName = result.result === '1-0' ? result.white : result.result === '0-1' ? result.black : '';
  showResultModal({
    key: `arena:${arenaGameCounter}:${result.result}`,
    tone: winnerName ? 'win' : 'draw',
    icon: winnerName ? '♚' : '½',
    title: winnerName ? `${winnerName} thắng` : 'Hòa cờ',
    subtitle: /nửa nước/.test(String(result.reason)) ? String(result.reason) : `${result.reason} · ${result.plies} nửa nước`,
    players: `${result.white} (Trắng) vs ${result.black} (Đen)`,
    stats: [engineSpeed ? { label: 'Tốc độ engine', value: engineSpeed.nps ? `${formatNps(engineSpeed.nps)} nút/giây` : `d${engineSpeed.depth}` } : null],
    actions: [
      { label: '↻ Đấu lại', primary: true, run: () => startArenaMatch(white.id, black.id) },
      { label: '♞ Phân tích ván', run: () => restoreSavedGame(syntheticRecord(result.pgn, result.result, `${result.white} vs ${result.black}`, result.reason, `arena-${arenaGameCounter}-${Date.now()}`), true) }
    ]
  });
}

/* ---------- Plans: Free / Pro (1 year) / Premium (lifetime) (v3.56) ---------- */
const ENTITLEMENT_KEY = 'vila.chess.entitlement.v1';
let reviewAccessPending = false;
const PUZZLE_FREE_USED_KEY = 'vila.chess.puzzles.freeUsed.v1';
function readFreePuzzlesUsed() { try { return Math.max(0, Math.floor(Number(localStorage.getItem(PUZZLE_FREE_USED_KEY)) || 0)); } catch { return 0; } }
function puzzleQuota() {
  const base = puzzleAccess(currentEntitlement(), readFreePuzzlesUsed());
  if (base.unlimited) return base;
  const daily = readDailyProgress();
  if (proTrialActive(daily)) return { allowed: true, plan: 'trial', unlimited: true, remaining: null };
  const credits = daily.inventory.puzzleCredits;
  return { ...base, allowed: base.remaining + credits > 0, remaining: base.remaining + credits };
}
/** Spend one free puzzle (no-op for Pro/Premium). Returns false when the free quota is already used up. */
function spendPuzzleQuota() {
  const quota = puzzleQuota();
  if (!quota.allowed) return false;
  if (!quota.unlimited) {
    if (readFreePuzzlesUsed() < FREE_PUZZLE_LIMIT) { try { localStorage.setItem(PUZZLE_FREE_USED_KEY, String(readFreePuzzlesUsed() + 1)); } catch {} }
    else { const spent = spendPuzzleCredit(readDailyProgress(), new Date()); if (!spent.ok) return false; persistDailyProgress(spent.state); }
  }
  return true;
}
function readLocalEntitlement() {
  try { return normalizeEntitlement(JSON.parse(localStorage.getItem(ENTITLEMENT_KEY) || '{}')); } catch { return normalizeEntitlement({}); }
}
function writeLocalEntitlement(entitlement) {
  try { localStorage.setItem(ENTITLEMENT_KEY, JSON.stringify(normalizeEntitlement(entitlement))); return true; } catch { return false; }
}
/** Signed-in accounts on a plan-aware backend use the server's entitlement; everyone else uses the on-device one. */
function accountEntitlement() {
  // Admin luôn có Premium trọn đời, kể cả khi Worker cũ chưa trả về entitlement (máy chủ vẫn tự kiểm tra role khi cần).
  if (socialState.token && socialState.user?.role === 'admin') return normalizeEntitlement({ premium: true });
  return socialState.token && socialState.user?.entitlement ? normalizeEntitlement(socialState.user.entitlement) : null;
}
function currentEntitlement() { return accountEntitlement() || readLocalEntitlement(); }
function applyServerEntitlement(entitlement) {
  if (!entitlement || !socialState.token || !socialState.user) return;
  saveSocialSession(socialState.token, { ...socialState.user, entitlement });
}
function showPlansPrompt() {
  toast('Bạn đã hết lượt phân tích. Mua thêm lượt bằng xu ở Cửa hàng hoặc nâng cấp Pro/Premium.');
  setView('plans');
}
/** Resolves true when this review may run. Consumes the single free review at most once per game. */
function tryShopReviewAccess(gameId) {
  const result = spendReviewCredit(readDailyProgress(), gameId, new Date());
  if (!result.ok) return false;
  persistDailyProgress(result.state);
  if (result.via === 'credit') toast(`Đã dùng 1 lượt phân tích đã mua. Còn ${result.left} lượt.`);
  else if (result.via === 'trial') toast('Đang dùng Pro dùng thử.');
  return true;
}
async function requestReviewAccess() {
  const gameId = String(currentGameId || '');
  if (socialState.token && socialState.user?.role === 'admin') return true;
  if (proTrialActive(readDailyProgress())) return tryShopReviewAccess(gameId);
  if (accountEntitlement()) {
    try {
      const data = await socialApi('/me/review-access', { method: 'POST', body: JSON.stringify({ gameId }) });
      applyServerEntitlement(data.entitlement);
      if (data.reason === 'free-trial') toast('Đang dùng lượt phân tích miễn phí duy nhất của tài khoản.');
      return true;
    } catch (error) {
      if (error?.status === 402) { if (tryShopReviewAccess(gameId)) return true; showPlansPrompt(); return false; }
      // Offline or an older backend without plan routes: fall back to the on-device quota below.
    }
  }
  const local = readLocalEntitlement();
  const access = reviewAccess(local, gameId);
  if (!access.allowed) { if (tryShopReviewAccess(gameId)) return true; showPlansPrompt(); return false; }
  if (access.consumesFree) { writeLocalEntitlement(consumeFreeReview(local, gameId || `game-${Date.now()}`)); toast('Đang dùng lượt phân tích miễn phí duy nhất.'); }
  return true;
}
/* ---------- Plans + server-confirmed admin purchase requests ---------- */
let purchaseRequestState = { busy: false, note: '' };
/* Legacy Google Play restore remains for existing purchases; new plan requests go through the admin panel. */
let billingState = { config: null, prices: {}, busy: false, note: '', selected: '' };
const billingBridge = () => nativeBillingBridge(window);
const billingQueue = createPurchaseQueue({
  api: (path, options) => socialApi(path, options),
  getBridge: billingBridge,
  onResult(result) {
    billingState.busy = false;
    if (result.status === 'pending') { billingState.note = 'Giao dịch đang chờ xử lý. Gói sẽ được kích hoạt khi Google xác nhận thanh toán.'; toast(billingState.note); }
    else {
      applyServerEntitlement(result.entitlement);
      billingState.note = '';
      toast(result.status === 'already' ? 'Gói của bạn đã được kích hoạt.' : `Đã kích hoạt gói ${PLAN_CATALOG[result.plan]?.name || ''}. Cảm ơn bạn đã ủng hộ!`, 'success');
    }
    if (currentView === 'plans') renderView();
  },
  onError(error) {
    billingState.busy = false;
    billingState.note = billingErrorMessage(error);
    toast(billingState.note);
    if (currentView === 'plans') renderView();
  }
});
async function loadBillingConfig(force = false) {
  if (!socialState.token || !billingBridge()) return null;
  if (billingState.config && !force) return billingState.config;
  try {
    billingState.config = await socialApi('/me/billing-config');
    if (billingState.config.enabled) billingBridge()?.init(Object.values(billingState.config.products || {}));
  } catch { billingState.config = null; }
  return billingState.config;
}
/** Re-send purchases Google still lists as owned (paid but never verified, e.g. app closed mid-purchase). */
async function restoreNativePurchases() {
  if (!socialState.token || !billingBridge()) return;
  const config = await loadBillingConfig();
  if (config?.enabled) billingBridge()?.queryOwned();
}
async function startPlanPurchase(planId) {
  const bridge = billingBridge();
  if (!bridge) {
    billingState.selected = planId;
    billingState.note = 'Bạn đã chọn gói ' + (PLAN_CATALOG[planId]?.name || planId) + '. Thanh toán chỉ khả dụng trong ứng dụng Android (Google Play); trên web hãy cài app để mua, hoặc nhờ quản trị viên kích hoạt gói cho tài khoản của bạn.';
    toast(billingState.note);
    if (currentView === 'plans') renderView();
    return;
  }
  if (!socialState.token || !socialState.user) { toast('Hãy đăng nhập tài khoản trước khi mua: gói được gắn với tài khoản để dùng lại khi cài lại app.'); return; }
  if (billingState.busy) return;
  const plan = effectivePlan(currentEntitlement());
  if (plan === 'premium') { toast('Bạn đã có Premium trọn đời.'); return; }
  const config = await loadBillingConfig(true);
  if (!config?.enabled) { toast('Thanh toán chưa sẵn sàng. Hãy thử lại sau.'); return; }
  const productId = config.products?.[planId];
  if (!productId) return;
  billingState.busy = true; billingState.note = '';
  if (!bridge.start(productId, config.accountId)) { billingState.busy = false; toast('Chưa mở được Google Play. Hãy thử lại.'); }
  if (currentView === 'plans') renderView();
}
window.addEventListener(BILLING_EVENT, event => {
  const detail = event?.detail || {};
  if (detail.type === 'purchased') { billingState.busy = true; billingQueue.push(detail); }
  else if (detail.type === 'prices') { billingState.prices = detail.prices || {}; if (currentView === 'plans') renderView(); }
  else if (detail.type === 'pending') { billingState.busy = false; billingState.note = 'Giao dịch đang chờ xử lý. Gói sẽ được kích hoạt khi Google xác nhận thanh toán.'; toast(billingState.note); if (currentView === 'plans') renderView(); }
  else if (detail.type === 'cancelled') { billingState.busy = false; if (currentView === 'plans') renderView(); }
  else if (detail.type === 'error') { billingState.busy = false; toast(String(detail.message || 'Thanh toán không thành công.').slice(0, 200)); if (currentView === 'plans') renderView(); }
});
setTimeout(() => { restoreNativePurchases().catch(() => {}); }, 5000);

const BOT_MESSAGE_PREFIX = 'VILA Trợ lý (bot):';
const botLabel3d = (text = 'BOT') => `<span class="bot-label-3d"><i aria-hidden="true">🤖</i>${esc(text)}</span>`;
/** Chat bubble body: bot auto-replies get the 3D BOT label instead of the raw prefix text. */
function chatMessageBodyHtml(text) {
  const raw = String(text || '');
  return raw.startsWith(BOT_MESSAGE_PREFIX) ? `${botLabel3d()} ${esc(raw.slice(BOT_MESSAGE_PREFIX.length).trim())}` : esc(raw);
}
const supportState = { loaded: false, active: false, admin: null, pending: 0, mine: [], lastSeenAt: null, at: 0, busy: false };
function supportBotPanelHtml() {
  if (!socialState.token || !socialState.user || !supportState.loaded || !supportState.active) return '';
  if (socialState.user.role === 'admin') return '';
  const seen = supportState.lastSeenAt && Number.isFinite(Date.parse(supportState.lastSeenAt)) ? new Date(supportState.lastSeenAt).toLocaleString('vi-VN') : '';
  const mine = supportState.mine.map(item => `<li>Yêu cầu ${item.plan === 'pro' ? 'Pro' : 'Premium'} của bạn đang xếp thứ <b>${Number(item.position) || 1}</b> trong hàng chờ.</li>`).join('');
  return `<section class="panel support-bot-panel" role="status" aria-live="polite"><div class="support-bot-head"><span class="support-bot-icon" aria-hidden="true">🤖</span><div>${botLabel3d('TRỢ LÝ')}<small>Admin ngoại tuyến${seen ? ` · ${esc(seen)}` : ''}</small></div></div><ul class="support-bot-list"><li>${Number(supportState.pending) || 0} yêu cầu đang chờ.</li>${mine}</ul><div class="support-bot-actions"><button type="button" class="primary-btn" data-bot-request="pro">Gửi yêu cầu Pro · 1.000đ</button><button type="button" class="secondary-btn" data-bot-go="plans">Đề nghị Premium</button></div></section>`;
}
function paintSupportPanels() { const html = supportBotPanelHtml(); $$('.support-bot-slot').forEach(slot => { if (slot.dataset.html !== html) { slot.dataset.html = html; slot.innerHTML = html; } }); }
async function refreshSupportStatus(force = false) {
  if (!socialState.token || !socialState.user || supportState.busy) return;
  if (!force && Date.now() - supportState.at < 15_000) { paintSupportPanels(); return; }
  supportState.busy = true;
  try {
    const result = await socialApi('/support/admin');
    const a = result?.assistant || {};
    Object.assign(supportState, { loaded: true, active: Boolean(a.active), admin: result?.admin || null, pending: Number(a.pendingRequests) || 0, mine: Array.isArray(a.yourPending) ? a.yourPending : [], lastSeenAt: a.adminLastSeenAt || null, at: Date.now() });
  } catch { supportState.loaded = false; }
  finally { supportState.busy = false; paintSupportPanels(); }
}
setInterval(() => { if (!document.hidden && (currentView === 'plans' || currentView === 'chat')) void refreshSupportStatus(); }, 30_000);
document.addEventListener('click', event => {
  const request = event.target instanceof Element ? event.target.closest('[data-bot-request]') : null;
  if (request) { void requestPlanWithAdmin(request.dataset.botRequest).then(() => refreshSupportStatus(true)); return; }
  const go = event.target instanceof Element ? event.target.closest('[data-bot-go]') : null;
  if (go) setView(go.dataset.botGo);
});
let findAdminBusy = false;
/** Ask the server which admin is available (online first) and open a chat with them. */
async function findSupportAdminAndChat(note = '') {
  if (!socialState.token || !socialState.user) { toast('Hãy đăng nhập để liên hệ admin.', 'error'); setView('friends'); return null; }
  if (findAdminBusy) return null;
  findAdminBusy = true;
  try {
    const result = await socialApi('/support/admin');
    const admin = result?.admin;
    if (!admin?.id) throw new Error('Máy chủ không trả về admin hợp lệ.');
    if (result.isSelf || admin.id === socialState.user.id) { toast('Bạn chính là admin hỗ trợ.', 'info'); return admin; }
    activeChatUserId = admin.id; activeChatUser = admin; chatConversations = [];
    purchaseRequestState.note = note || (result.adminsOnline > 0 ? `Admin @${admin.username} đang online.` : `Admin @${admin.username} hiện ngoại tuyến; tin nhắn sẽ được lưu lại.`);
    toast(purchaseRequestState.note, 'success');
    setView('chat');
    return admin;
  } catch (error) {
    toast(error?.message || 'Không tìm được admin lúc này.', 'error');
    return null;
  } finally { findAdminBusy = false; }
}

async function requestPlanWithAdmin(planId) {
  if (!['pro', 'premium'].includes(planId)) return;
  if (!socialState.token || !socialState.user) {
    toast('Hãy đăng nhập trước khi gửi yêu cầu gói.', 'error');
    setView('friends');
    return;
  }
  if (purchaseRequestState.busy) return;
  const amountInput = $('#planPremiumAmount');
  const amountVnd = planId === 'pro' ? 1000 : Number(amountInput?.value);
  if (planId === 'premium' && (!Number.isInteger(amountVnd) || amountVnd < 1000 || amountVnd > 100000 || amountVnd % 1000 !== 0)) {
    toast('Mức đề nghị Premium phải từ 1.000đ đến 100.000đ, theo bậc 1.000đ.', 'error');
    amountInput?.focus();
    return;
  }
  purchaseRequestState.busy = true;
  const requestButtons = $$('[data-plan-request], [data-chat-plan-request]');
  requestButtons.forEach(button => { button.disabled = true; });
  try {
    const result = await socialApi('/me/purchase-requests', { method: 'POST', body: JSON.stringify({ plan: planId, amountVnd }) });
    if (!result?.admin?.id || !result?.request?.id) throw new Error('Máy chủ không trả về mã yêu cầu hoặc tài khoản admin; không thể mở cuộc trò chuyện.');
    activeChatUserId = result.admin.id;
    activeChatUser = result.admin;
    chatConversations = [];
    purchaseRequestState.note = result.message || 'Yêu cầu đã được máy chủ ghi nhận.';
    toast(purchaseRequestState.note, 'success');
    setView('chat');
  } catch (error) {
    purchaseRequestState.note = error?.message || 'Không gửi được yêu cầu đến máy chủ.';
    toast(purchaseRequestState.note, 'error');
    if (currentView === 'plans') renderView();
  } finally {
    purchaseRequestState.busy = false;
    requestButtons.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
}

function renderPlansView() {
  const ent = currentEntitlement();
  const plan = effectivePlan(ent);
  const native = Boolean(billingBridge());
  const localTrialRemaining = proTrialLeftMs(readDailyProgress());
  const localTrialMinutes = Math.ceil(localTrialRemaining / 60_000);
  const localTrialLabel = localTrialRemaining > 0 ? `Pro dùng thử bằng xu · còn ${Math.floor(localTrialMinutes / 60) ? `${Math.floor(localTrialMinutes / 60)} giờ ` : ''}${Math.max(1, localTrialMinutes % 60)} phút` : '';
  const statusLabel = plan === 'free' && localTrialLabel ? localTrialLabel : planStatusLabel(ent);
  const card = id => {
    const info = PLAN_CATALOG[id];
    const active = plan === id;
    let cta = active ? '<span class="plan-active-tag">Đang dùng</span>' : '';
    if (id === 'pro' && plan !== 'premium') {
      cta += `<button type="button" class="secondary-btn" data-plan-request="pro"${purchaseRequestState.busy ? ' disabled' : ''}>Yêu cầu Pro · 1.000đ / 3 giờ</button><small class="plan-request-hint">Gửi vào chat admin. Pro chỉ được cấp sau khi admin xác nhận đã nhận tiền.</small>`;
    } else if (id === 'premium' && plan !== 'premium') {
      cta += `<label class="field-label plan-amount-label" for="planPremiumAmount">Mức đề nghị trao đổi (VNĐ)</label><input class="field plan-amount-input" id="planPremiumAmount" type="number" min="1000" max="100000" step="1000" inputmode="numeric" value="1000" aria-describedby="premiumRequestHint"/><button type="button" class="primary-btn" data-plan-request="premium"${purchaseRequestState.busy ? ' disabled' : ''}>Gửi đề nghị tới admin</button><small id="premiumRequestHint" class="plan-request-hint">Premium hiện không bán trực tiếp. Đây chỉ là đề nghị trao đổi, không thanh toán và không tự kích hoạt gói.</small>`;
    }
    const selected = billingState.selected === id;
    return `<article class="plan-card ${active ? 'is-active' : ''} ${selected ? 'is-selected' : ''} plan-${id}" data-plan-card="${id}" tabindex="0"><h3>${esc(info.name)}</h3><p class="plan-tagline">${esc(info.tagline)}</p><ul>${info.perks.map(perk => `<li>${esc(perk)}</li>`).join('')}</ul>${cta}</article>`;
  };
  const status = purchaseRequestState.note || billingState.note;
  return `<section class="page plans-page"><div class="panel-heading"><div><small class="eyebrow">GÓI DỊCH VỤ</small><h2>Gói Pro &amp; Premium</h2></div><span class="context-icon">💎</span></div>
    <p class="field-hint">Trạng thái: <b>${esc(statusLabel)}</b></p>
    <section class="redeem-inline-cta"><span class="redeem-inline-icon">${uiIcon('key-round')}</span><div><b>Bạn có mã kích hoạt?</b><small>Nhập mã dùng thử riêng cho tài khoản của bạn.</small></div><button type="button" class="secondary-btn" data-home-view="redeem">Nhập mã  ↗</button></section>
    <div class="plan-grid">${['free', 'pro', 'premium'].map(card).join('')}</div>
    ${status ? `<p class="field-hint" role="status">${esc(status)}</p>` : ''}
    <div class="support-bot-slot"></div>
    <section class="plan-request-console"><div><span class="eyebrow">KẾT NỐI ADMIN</span><h3>Cần hỗ trợ? Nhắn admin</h3></div><div class="plan-console-actions"><button type="button" class="primary-btn" data-find-admin>Tìm admin &amp; nhắn ngay</button><button type="button" class="secondary-btn" data-home-view="chat">Mở tin nhắn ↗</button></div></section>
    ${native ? '<p class="field-hint">Đã hỗ trợ khôi phục giao dịch Google Play cũ trên thiết bị này.</p><p><button type="button" class="ghost-btn" data-plan-restore>Khôi phục giao dịch cũ</button></p>' : ''}</section>`;
}

let trialCodeUiBusy = false;
let trialCodeUiNote = '';
let trialCodeUiKind = '';
let premiumPreviewExpiryTimer = 0;
function schedulePremiumPreviewExpiry(entitlement = currentEntitlement()) {
  if (premiumPreviewExpiryTimer) window.clearTimeout(premiumPreviewExpiryTimer);
  premiumPreviewExpiryTimer = 0;
  const expiresAt = Number(entitlement?.premiumExpiresAt);
  const accountId = socialState.user?.id;
  if (!socialState.token || !accountId || !Number.isFinite(expiresAt) || expiresAt <= Date.now()) return;
  premiumPreviewExpiryTimer = window.setTimeout(() => {
    premiumPreviewExpiryTimer = 0;
    if (!socialState.token || socialState.user?.id !== accountId) return;
    const current = currentEntitlement();
    if (Number(current?.premiumExpiresAt) !== expiresAt || expiresAt > Date.now()) return;
    const plan = effectivePlan(current);
    addAppNotification({
      title: 'Premium dùng thử đã kết thúc',
      message: plan === 'pro' ? 'Premium Preview đã hết hạn; gói Pro của bạn vẫn còn hiệu lực.' : 'Premium Preview đã hết hạn; tài khoản đã trở về gói Miễn phí.',
      type: 'info', sourceKey: `premium-preview-expired:${accountId}:${expiresAt}`
    });
    if (currentView === 'plans' || currentView === 'redeem') renderView();
  }, Math.min(2_147_000_000, Math.max(0, expiresAt - Date.now() + 50)));
}
function renderRedeemCodeView() {
  const signedIn = Boolean(socialState.token && socialState.user);
  const ent = currentEntitlement();
  const codeStatus = trialCodeUiNote ? `<p class="redeem-status ${trialCodeUiKind}" role="status" aria-live="polite">${esc(trialCodeUiNote)}</p>` : '';
  return `<section class="page redeem-page"><header class="redeem-hero panel"><div class="redeem-key-3d" aria-hidden="true"><svg viewBox="0 0 96 96" focusable="false"><defs><linearGradient id="redeemMetal" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f5ffff"/><stop offset=".35" stop-color="#7de8ed"/><stop offset=".72" stop-color="#238fa9"/><stop offset="1" stop-color="#13516e"/></linearGradient><linearGradient id="redeemGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff0bb"/><stop offset=".5" stop-color="#e6b75a"/><stop offset="1" stop-color="#8d5427"/></linearGradient></defs><ellipse cx="48" cy="82" rx="28" ry="6" fill="#030a16" opacity=".55"/><g transform="rotate(-38 48 48)"><circle cx="34" cy="31" r="15" fill="url(#redeemGold)" stroke="#fff1c9" stroke-width="1.5"/><circle cx="34" cy="31" r="7" fill="#101e36" stroke="#7de8ed" stroke-width="2"/><path d="M44 42 72 70 64 78 58 72 53 77 47 71 52 66 39 53Z" fill="url(#redeemMetal)" stroke="#c9ffff" stroke-width="1.5" stroke-linejoin="round"/><path d="m44 42 28 28" stroke="#f3ffff" stroke-width="2" opacity=".7"/></g></svg></div><div class="redeem-hero-copy"><span class="eyebrow">VILA ACCESS · SECURE REDEMPTION</span><h2>Nhập mã kích hoạt</h2><p>Mã được xác minh ở máy chủ và gắn với tài khoản đang đăng nhập. Mỗi loại mã chỉ sử dụng một lần cho mỗi tài khoản.</p><div class="redeem-current-plan"><span>Gói hiện tại</span><b>${esc(planStatusLabel(ent))}</b></div></div></header>
    <div class="redeem-trial-grid"><article class="redeem-trial-card redeem-pro"><span class="redeem-plan-orb">P</span><div><b>Pro Trial</b><strong>5 ngày</strong><small>Thời hạn tính từ lúc kích hoạt.</small></div></article><article class="redeem-trial-card redeem-premium"><span class="redeem-plan-orb">✦</span><div><b>Premium Preview</b><strong>1 phút</strong><small>Bản xem thử tự hết hạn sau 60 giây.</small></div></article></div>
    <section class="redeem-form-panel panel"><div class="panel-heading"><div><small class="eyebrow">MÃ ĐƯỢC CẤP RIÊNG</small><h3>Kích hoạt quyền dùng thử</h3></div><span class="redeem-lock">${uiIcon('shield-check')}</span></div>
    ${signedIn ? `<form id="redeemCodeForm" class="redeem-form"><label for="redeemCodeInput">Mã kích hoạt</label><div class="redeem-input-wrap"><input id="redeemCodeInput" name="code" type="text" class="field" maxlength="80" minlength="4" autocomplete="off" autocorrect="off" autocapitalize="characters" inputmode="text" enterkeyhint="done" spellcheck="false" placeholder="Nhập mã của bạn" required ${trialCodeUiBusy ? 'disabled' : ''}/><button type="button" class="redeem-reveal" id="redeemRevealCode" aria-label="Ẩn mã" title="Hiện/ẩn mã">${uiIcon('eye')}</button></div><small>Không chia sẻ mã với người khác. Mã được gửi qua HTTPS đến máy chủ để kiểm tra, không lưu nguyên văn ở hồ sơ.</small><button type="submit" class="primary-btn redeem-submit" ${trialCodeUiBusy ? 'disabled' : ''}><span class="redeem-submit-icon">${uiIcon('key-round')}</span>${trialCodeUiBusy ? 'Đang xác minh…' : 'Xác minh & kích hoạt'}</button></form>` : `<div class="redeem-login-required"><span>${uiIcon('user-round')}</span><b>Cần đăng nhập trước</b><p>Gói dùng thử được gắn với tài khoản để hạn chế việc dùng lại mã bằng cách xóa dữ liệu ứng dụng.</p><button type="button" class="primary-btn" data-home-view="friends">Đăng nhập / tạo tài khoản</button></div>`}
    ${codeStatus}<p class="redeem-security-note"><span>${uiIcon('shield-check')}</span><span>Kiểm tra mã và thời hạn ở phía máy chủ. Nếu máy chủ chưa cấu hình kho mã, màn hình sẽ báo rõ thay vì tự cấp quyền trên điện thoại.</span></p></section>
    <button type="button" class="ghost-btn redeem-back" data-home-view="plans">← Quay lại Gói Pro &amp; Premium</button></section>`;
}
function wireRedeemCodeActions() {
  $('#redeemRevealCode')?.addEventListener('click', () => {
    const input = $('#redeemCodeInput'); if (!input) return;
    const show = input.type === 'password'; input.type = show ? 'text' : 'password';
    $('#redeemRevealCode')?.setAttribute('aria-label', show ? 'Ẩn mã' : 'Hiện mã');
  });
  const redeemInput = $('#redeemCodeInput');
  redeemInput?.addEventListener('pointerdown', () => { if (!trialCodeUiBusy) redeemInput.focus({ preventScroll: true }); }, { passive: true });
  $('#redeemCodeForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    if (!socialState.token || !socialState.user) { trialCodeUiNote = 'Hãy đăng nhập trước khi kích hoạt mã.'; trialCodeUiKind = 'error'; renderView(); return; }
    const input = $('#redeemCodeInput');
    const code = String(input?.value || '').trim();
    if (!code) { input?.focus(); trialCodeUiNote = 'Hãy nhập mã kích hoạt trước.'; trialCodeUiKind = 'error'; const status = $('.redeem-status'); if (status) status.textContent = trialCodeUiNote; return; }
    if (trialCodeUiBusy) return;
    trialCodeUiBusy = true; trialCodeUiNote = ''; trialCodeUiKind = '';
    const form = $('#redeemCodeForm');
    const submit = form?.querySelector('[type="submit"]');
    if (input) input.disabled = true;
    if (submit) { submit.disabled = true; submit.textContent = 'Đang xác minh…'; }
    const reveal = $('#redeemRevealCode'); if (reveal) reveal.disabled = true;
    try {
      const result = await socialApi('/me/redeem-code', { method: 'POST', body: JSON.stringify({ code }) });
      if (!result?.ok || !result?.user?.entitlement) throw new Error('Máy chủ chưa xác nhận quyền dùng thử.');
      saveSocialSession(socialState.token, result.user);
      schedulePremiumPreviewExpiry(result.user.entitlement);
      trialCodeUiNote = result.message || 'Mã đã được kích hoạt.'; trialCodeUiKind = 'success';
      addAppNotification({ title: 'Mã VILA đã kích hoạt', message: trialCodeUiNote, type: 'success', sourceKey: `trial-code:${result.plan}:${result.expiresAt}` });
    } catch (error) {
      trialCodeUiNote = error?.message || 'Không xác minh được mã.'; trialCodeUiKind = 'error';
    } finally {
      trialCodeUiBusy = false;
      renderView();
    }
  });
}
function wirePlansActions() {
  $$('[data-plan-card]').forEach(cardEl => {
    const pick = event => {
      if (event.target.closest('button,input,label')) return;
      const id = cardEl.dataset.planCard;
      if (id === 'free' || billingState.selected === id) return;
      billingState.selected = id; renderView();
    };
    cardEl.addEventListener('click', pick);
    cardEl.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { if (event.target.matches('input,button')) return; event.preventDefault(); pick(event); } });
  });
  $$('[data-plan-request]').forEach(button => button.addEventListener('click', () => { void requestPlanWithAdmin(button.dataset.planRequest); }));
  $$('[data-find-admin]').forEach(button => button.addEventListener('click', () => { void findSupportAdminAndChat(); }));
  void refreshSupportStatus();
  $$('[data-plan-restore]').forEach(button => button.addEventListener('click', async () => {
    if (!socialState.token) { toast('Hãy đăng nhập để khôi phục giao dịch.', 'error'); return; }
    toast('Đang kiểm tra giao dịch cũ với Google Play…');
    await restoreNativePurchases();
  }));
  restoreNativePurchases().catch(() => {});
}

/* ---------- Lessons + Club views (v3.56: moved out of adoptSocialCallback, where they never rendered) ---------- */
const LESSON_PROGRESS_KEY = 'vila.chess.lesson-progress.v1';
let lessonOpenKey = '';
function readLessonProgress() {
  try { const value = JSON.parse(localStorage.getItem(LESSON_PROGRESS_KEY) || '{}'); return value && typeof value === 'object' && !Array.isArray(value) ? value : {}; } catch { return {}; }
}
function writeLessonProgress(progress) {
  try { localStorage.setItem(LESSON_PROGRESS_KEY, JSON.stringify(progress)); return true; } catch { return false; }
}
function renderLessonsView() {
  const progress = readLessonProgress();
  if (lessonOpenKey && findLessonChapter(lessonOpenKey)?.content) return lessonReaderMarkup(lessonOpenKey, Boolean(progress[lessonOpenKey]));
  lessonOpenKey = '';
  const summary = lessonProgressSummary(progress);
  return `<section class="page lessons-page"><div class="panel-heading"><div><small class="eyebrow">HỌC CỜ</small><h2>Bài học</h2></div><span class="context-icon">📖</span></div>
    <p class="field-hint">Tiến độ: ${esc(summary.label)}. Nội dung luyện cục bộ — không cần mạng.</p>
    <div class="lesson-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${summary.pct}"><i style="width:${summary.pct}%"></i></div>
    <div class="lesson-grid">${LESSON_CATALOG.map(lesson => `<article class="lesson-card"><h3>${esc(lesson.title)}</h3>${lesson.chapters.map(ch => {
      const key = lesson.id + '/' + ch.id;
      const done = Boolean(progress[key]);
      return `<div class="lesson-chapter ${done ? 'done' : ''}"><span>${esc(ch.title)}</span><button type="button" class="secondary-btn lesson-open-btn" data-lesson-key="${esc(key)}">${done ? '✓ Xem lại' : ch.minutes + ' phút'}</button></div>`;
    }).join('')}</article>`).join('')}</div></section>`;
}
function wireLessonsActions() {
  $$('.lesson-open-btn').forEach(btn => btn.addEventListener('click', () => {
    lessonOpenKey = btn.getAttribute('data-lesson-key') || '';
    renderView();
    $('#mainView')?.scrollTo?.({ top: 0 });
  }));
  $('#lessonBackBtn')?.addEventListener('click', () => { lessonOpenKey = ''; renderView(); });
  $('#lessonDoneBtn')?.addEventListener('click', event => {
    const key = event.currentTarget.getAttribute('data-lesson-key');
    if (!key) return;
    const progress = readLessonProgress();
    progress[key] = true;
    if (!writeLessonProgress(progress)) { toast('Không lưu được tiến độ (bộ nhớ bị chặn).'); return; }
    try { recordDailyEvent('lesson_done'); } catch { /* optional mission hook */ }
    toast('Đã hoàn thành chương học.', 'success');
    lessonOpenKey = '';
    renderView();
  });
}
function renderClubView() {
  return clubHomeMarkup({ name: 'Câu lạc bộ ViLa', members: (socialState?.friends?.length || 0) + 1, activity: 'Thách đấu bạn · phòng xem · BXH' })
    + `<section class="panel" style="margin-top:12px"><div class="panel-heading"><div><small class="eyebrow">SPECTATOR</small><h2>Phòng xem</h2></div></div>
    <p class="field-hint">${esc(spectatorRoomLabel({ white: 'Bạn', black: 'Đối thủ', viewers: 0 }))}</p>
    <p class="field-hint">Ghép với bạn bè qua mục Bạn bè; thách đấu tạo lời mời cục bộ.</p></section>`;
}
function wireClubActions() {
  $('#clubChallengeBtn')?.addEventListener('click', () => {
    const payload = friendChallengePayload({ from: socialState?.user?.username || 'you', to: socialState?.friends?.[0]?.username || 'friend', timeControl: selectedRankedTimeControl || '3+2' });
    if (!payload) { toast('Cần đăng nhập và có bạn bè để thách đấu.'); return; }
    toast(`Đã tạo thách đấu ${payload.timeControl} tới ${payload.to}`, 'success');
  });
  $('#clubSpectateBtn')?.addEventListener('click', () => toast(spectatorRoomLabel({ white: 'Trắng', black: 'Đen', viewers: 1 })));
  $('#clubLeaderboardBtn')?.addEventListener('click', () => { currentView = 'friends'; renderView(); });
}

function renderView() {
  readDailyProgress();
  maybeRecordRatedGame();
  maybeArchiveCompletedGame();
  document.body.classList.toggle('play-screen-active', currentView === 'play' && !gameStarted);
  document.body.classList.toggle('match-setup-active', currentView === 'play' && !gameStarted);
  document.body.classList.toggle('match-live', currentView === 'play' && gameStarted);
  { const titleEl = $('#viewTitle'); if (titleEl) { const label = $(`#mainMenu .tab[data-view="${currentView}"] span`)?.textContent?.trim(); titleEl.textContent = currentView === 'home' ? 'Cờ Vua' : currentView === 'profile' ? 'Hồ sơ' : (label || 'Cờ Vua'); } }
  if (currentView !== 'play' || !gameStarted) document.body.classList.remove('match-sheet-open');
  document.body.classList.toggle('home-screen-active', currentView === 'home');
  document.body.classList.toggle('review-screen-active', currentView === 'review');
  $$('.tab').forEach(tab => tab.classList.toggle('active', tab.dataset.view === currentView));
  const root = $('#mainView');
  if (!root) return;
  if (currentView === 'home') root.innerHTML = renderHomeView();
  else if (currentView === 'play') root.innerHTML = renderPlayView();
  else if (currentView === 'ranked') root.innerHTML = renderRankedView();
  else if (currentView === 'puzzles') root.innerHTML = renderPuzzleView();
  else if (currentView === 'openings') root.innerHTML = renderOpeningsView();
  else if (currentView === 'coach') root.innerHTML = renderCoachView();
  else if (currentView === 'arena') root.innerHTML = renderArenaView();
  else if (currentView === 'games') root.innerHTML = renderGamesView();
  else if (currentView === 'lichess') root.innerHTML = renderLichessView();
  else if (currentView === 'leaderboard') root.innerHTML = renderLeaderboardView();
  else if (currentView === 'friends') root.innerHTML = renderFriendsView();
  else if (currentView === 'profile') root.innerHTML = renderProfileView();
  else if (currentView === 'chat') root.innerHTML = renderChatView();
  else if (currentView === 'inbox') root.innerHTML = renderInboxView();
  else if (currentView === 'health') root.innerHTML = renderSystemHealthView();
  else if (currentView === 'missions') root.innerHTML = renderMissionsView();
  else if (currentView === 'achievements') root.innerHTML = renderAchievementsView();
  else if (currentView === 'shop') root.innerHTML = renderShopView();
  else if (currentView === 'admin') root.innerHTML = renderAdminView();
  else if (currentView === 'history') root.innerHTML = renderHistoryView();
  else if (currentView === 'lessons') root.innerHTML = renderLessonsView();
  else if (currentView === 'club') root.innerHTML = renderClubView();
  else if (currentView === 'plans') root.innerHTML = renderPlansView();
  else if (currentView === 'redeem') root.innerHTML = renderRedeemCodeView();
  else if (currentView === 'review') root.innerHTML = renderReviewView();
  else root.innerHTML = renderSettingsView();
  wireCommonActions();
  if (currentView === 'home') wireHomeActions();
  if (currentView === 'ranked') wireRankedActions();
  if (currentView === 'puzzles') wirePuzzleActions();
  if (currentView === 'friends') wireFriendsActions();
  if (currentView === 'profile') wireProfileActions();
  if (currentView === 'chat') wireChatActions();
  if (currentView === 'inbox') wireInboxActions();
  if (currentView === 'health') wireSystemHealthActions();
  if (currentView === 'missions') wireMissionsActions();
  if (currentView === 'achievements') wireAchievementsActions();
  if (currentView === 'shop') wireShopActions();
  if (currentView === 'leaderboard') wireLeaderboardActions();
  if (currentView === 'admin') wireAdminActions();
  if (currentView === 'lessons') wireLessonsActions();
  if (currentView === 'club') wireClubActions();
  if (currentView === 'plans') wirePlansActions();
  if (currentView === 'redeem') wireRedeemCodeActions();
  if (currentView === 'play') {
    renderBoard();
    watchBoardLayout();
    wirePlayActions();
    renderAnalysisPanel(); // Re-sync hidden/busy state after returning from another view.
  } else {
    boardResizeObserver?.disconnect();
    boardResizeObserver = null;
  }
  if (currentView === 'openings') wireOpeningActions();
  if (currentView === 'review') wireReviewActions();
  if (currentView === 'coach') wireCoachActions();
  if (currentView === 'arena') { renderArenaPosition(); wireArenaActions(); syncArenaCupPodium(); }
  if (currentView === 'games') wireGamesActions();
  if (currentView === 'lichess') wireLichessActions();
  if (currentView === 'settings') wireSettingsActions();
  if (currentView === 'history') wireHistoryActions();
  syncRankedTimers();
  maybeShowPlayResultModal();
  maybeShowRankedResultModal();
}
function renderExperienceChoiceMarkup() {
  if (experienceLevel === 'beginner') return '<small class="experience-selected-label">Đang chọn: người mới chơi</small>';
  if (experienceLevel === 'experienced') return '<small class="experience-selected-label">Đang chọn: đã hiểu luật</small>';
  return '<div class="experience-choice"><button type="button" class="secondary-btn" data-experience-choice="beginner">Mới chơi</button><button type="button" class="secondary-btn" data-experience-choice="experienced">Đã hiểu luật</button></div>';
}
function renderPrestartExperiencePanel() {
  if (gameStarted) return '';
  const title = experienceLevel === 'beginner' ? 'Lộ trình người mới' : experienceLevel === 'experienced' ? 'Đã hiểu luật cờ vua' : 'Bạn mới chơi hay đã biết luật?';
  const description = experienceLevel === 'beginner'
    ? 'Bot khởi đầu nhẹ hơn, thời gian Rapid 10 phút và có gợi ý khi cần.'
    : experienceLevel === 'experienced'
      ? 'Bạn có thể tùy chỉnh thời gian, màu quân, sức mạnh bot và phân tích.'
      : 'Chọn lộ trình phù hợp để ViLa đặt sẵn trải nghiệm ban đầu.';
  return `<section class="prestart-experience-card" aria-label="Chọn kinh nghiệm cờ vua"><div class="prestart-experience-icon" aria-hidden="true">♟</div><div class="prestart-experience-copy"><b>${title}</b><small>${description}</small>${renderExperienceChoiceMarkup()}</div>${experienceLevel ? '<button type="button" id="changeExperience" class="tiny-btn prestart-experience-change">Đổi</button>' : ''}</section>`;
}
function renderMatchSetupView() {
  const selectedProfile = OFFLINE_ENGINE_CATALOG.find(item => item.id === settings.alternativeEngine) || OFFLINE_ENGINE_CATALOG[0];
  const eloOptions = [...new Set([...Array.from({ length: 28 }, (_, i) => 500 + i * 100), 3200, ...(Number(settings.botElo) % 100 === 0 ? [] : [Number(settings.botElo)])])].sort((a, b) => a - b);
  return `<section class="play-setup-screen" aria-labelledby="matchSetupTitle">
    <header class="match-setup-heading"><span class="match-setup-emblem" aria-hidden="true">♟</span><div><small class="eyebrow">VILA CHESS · NEW MATCH</small><h1 id="matchSetupTitle">Thiết lập trận đấu</h1><p>Chọn đối thủ, màu quân và thời gian. Bàn cờ sẽ xuất hiện khi bạn bắt đầu.</p></div></header>
    ${renderPrestartExperiencePanel()}
    <section class="panel match-setup-card">
      <div class="panel-heading"><div><small class="eyebrow">TRẬN ĐẤU MỚI</small><h2>Thiết lập của bạn</h2></div><span class="match-setup-ready"><i></i> Chưa bắt đầu</span></div>
      <div class="match-setup-grid">
        <div class="match-setup-field match-setup-wide"><label class="field-label" for="modeSelect">1 · Chọn chế độ chơi</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish 19 NNUE Lite — đối thủ mạnh</option><option value="stockfish-beginner" ${mode === 'stockfish-beginner' ? 'selected' : ''}>Stockfish — luyện người mới (500 Elo mục tiêu)</option><option value="vila" ${mode === 'vila' ? 'selected' : ''}>ViLa Classic — bot ngoại tuyến</option><option value="enginehub" ${mode === 'enginehub' ? 'selected' : ''}>AI đa phong cách — ngoại tuyến</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess — chơi trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người chơi trên cùng máy</option></select></div>
        <div class="match-setup-field"><label class="field-label" for="gameBotProfile">2 · Phong cách bot</label><select id="gameBotProfile" class="field" ${mode === 'local' || mode === 'lichess' ? 'disabled' : ''}>${OFFLINE_ENGINE_CATALOG.map(item => `<option value="${item.id}" ${settings.alternativeEngine === item.id ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select><small class="field-hint">${esc(selectedProfile.hint)}.</small></div>
        <div class="match-setup-field"><label class="field-label" for="colorSelect">3 · Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="random" ${colorChoice === 'random' ? 'selected' : ''}>🎲 Ngẫu nhiên</option><option value="w" ${colorChoice === 'w' ? 'selected' : ''}>Trắng — đi trước</option><option value="b" ${colorChoice === 'b' ? 'selected' : ''}>Đen — bot đi trước</option></select></div>
        <div class="match-setup-field bot-strength-field"><label class="field-label" for="skillSelect">4 · Sức mạnh bot</label><div class="strength-selector-shell"><span class="strength-selector-emblem">${uiTile('robot','cyan','tile-lg')}</span><div class="strength-selector-copy"><b>${settings.botStrengthMode === 'elo' ? `Elo ${settings.botElo}` : 'Mạnh nhất · không giới hạn'}</b><small>Chọn mức luyện tập hoặc dùng sức mạnh tối đa của engine.</small></div></div><select id="skillSelect" class="field" ${mode === 'local' || mode === 'lichess' ? 'disabled' : ''}><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất — không giới hạn</option>${eloOptions.map(n => `<option value="${n}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === n ? 'selected' : ''}>Elo ${n}${n === 3200 ? ' · mức cao nhất' : ''}</option>`).join('')}</select><div class="strength-quick-picks" aria-label="Mức sức mạnh nhanh">${[{v:'500',t:'500'},{v:'1000',t:'1000'},{v:'1500',t:'1500'},{v:'2000',t:'2000'},{v:'2600',t:'2600'},{v:'3200',t:'3200'},{v:'max',t:'∞'}].map(item => `<button type="button" data-strength-preset="${item.v}" class="strength-chip ${(settings.botStrengthMode === 'max' && item.v === 'max') || (settings.botStrengthMode === 'elo' && item.v === String(settings.botElo)) ? 'is-active' : ''}" ${mode === 'local' || mode === 'lichess' ? 'disabled' : ''}>${item.t}</button>`).join('')}</div><button type="button" id="randomBotElo" class="text-btn random-elo-btn" aria-pressed="${randomBotEloEnabled}">${uiIcon('dice')} Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}</button></div>
        <div class="match-setup-field"><label class="field-label" for="clockPreset">5 · Thời gian mỗi bên</label><select id="clockPreset" class="field">${CLOCK_PRESETS.map(preset => `<option value="${preset.value}" ${settings.clockPreset === preset.value ? 'selected' : ''}>${preset.label}</option>`).join('')}</select></div>
      </div>
      <div class="match-setup-time-shortcuts" role="group" aria-label="Chọn nhanh thời gian"><span>CHỌN NHANH</span>${[['1+0','Bullet'],['3+2','Blitz'],['10+0','Rapid'],['15+10','Classical']].map(([value,label]) => `<button type="button" data-time-preset="${value}" class="time-preset-chip ${settings.clockPreset === value ? 'is-active' : ''}"><b>${value}</b><small>${label}</small></button>`).join('')}</div>
      <div class="match-setup-note"><span aria-hidden="true">ℹ</span><p>Chế độ bot chạy trên thiết bị. Mức Elo là giới hạn luyện tập ước lượng, không phải xếp hạng đã đo.</p></div>
      <button id="startGameOverlay" type="button" class="primary-btn full-width match-start-button"><span aria-hidden="true">♟</span> Bắt đầu trận <span aria-hidden="true">→</span></button>
      <p class="match-setup-footnote">Chỉ sau khi bấm bắt đầu, bàn cờ và các nút trong trận mới hiện ra.</p>
    </section>
  </section>`;
}
function renderPlayView() {
  if (!gameStarted) return renderMatchSetupView();
  const modeLabel = ['stockfish', 'stockfish-beginner'].includes(mode) ? 'Stockfish' : mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? 'AI nhiều phong cách' : mode === 'lichess' ? 'Lichess' : 'Hai người chơi';
  const clockFace = color => `<div class="clock-player-block"><div class="clock-face ${color === humanColor ? 'user-clock' : 'opponent-clock'}"><span id="clock${color === 'w' ? 'White' : 'Black'}Name">${esc(clockPlayerName(color))}</span><strong id="clock${color === 'w' ? 'White' : 'Black'}">${clockState.enabled ? formatClockTime(clockState.remaining[color]) : (mode === 'lichess' ? 'Lichess' : '∞')}</strong></div>${renderCapturedMaterial(color)}</div>`;
  const topClockColor = humanColor === 'w' ? 'b' : 'w';
  const bottomClockColor = humanColor === 'w' ? 'w' : 'b';
  const gameOver = !gameStarted || game.isGameOver() || clockFlagged || manualGameResult;
  const pageShortcuts = [['arena', '🤖', 'Đấu bot'], ['puzzles', '🧩', 'Câu đố'], ['coach', '📊', 'Phân tích ván'], ['history', '↶', 'Lịch sử'], ['openings', '🎓', 'Khai cuộc'], ['games', '🎮', 'Mini-game'], ['ranked', '🏆', 'Xếp hạng'], ['settings', '⚙', 'Cài đặt']];
  return `<section class="play-view-shell match-room">
    <header class="match-topbar"><button type="button" id="matchBack" class="match-icon-btn" aria-label="Thoát trận, về thiết lập trận đấu" title="Về thiết lập trận đấu">←</button><div class="match-topbar-title"><b>${modeLabel}</b><small>${clockState.enabled ? esc(CLOCK_PRESETS.find(item => item.value === settings.clockPreset)?.label || settings.clockPreset) : 'Không giới hạn thời gian'}</small></div><button type="button" id="virtualMouseToggle" class="match-icon-btn virtual-mouse-top-toggle" aria-label="Bật chuột ảo" aria-pressed="false" title="Chuột ảo PC · điều khiển bằng ngón tay">⌖</button><button type="button" id="openMatchMenu" class="match-icon-btn" aria-label="Mở menu trận đấu" aria-expanded="false" aria-controls="matchSheet" title="Menu trận đấu">☰</button></header>
    <section class="play-layout">
    <div class="board-column">
      <section class="player-card player-card-opponent"><div class="opponent-line"><div class="avatar">${mode === 'local' ? '♙' : mode === 'vila' ? '♞' : mode === 'enginehub' ? '⚙' : mode === 'lichess' ? '↗' : '♞'}</div><div class="opponent-meta"><b>${mode === 'local' ? 'Người chơi Đen / Trắng' : mode === 'vila' ? 'ViLa Classic · AI cục bộ' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : mode === 'lichess' ? `Lichess · ${esc(activeOnlineGame?.opponent || 'đối thủ trực tuyến')}` : 'Stockfish'}</b><small>${modeLabel} · ${mode === 'stockfish' ? `Skill ${settings.botSkill}/20` : mode === 'enginehub' ? `AI cục bộ · ${esc(settings.alternativeEngine)} · không cần backend` : mode === 'vila' ? 'Chạy trên điện thoại · không cần backend' : mode === 'lichess' ? `Ván ${esc(activeOnlineGame?.id || '')}` : 'Cùng thiết bị'}</small></div><span id="turnChip" class="turn-chip">Lượt Trắng</span></div>
      
      <div class="clock-face-row">${clockFace(topClockColor)}</div></section>
      <div class="board-frame"><div class="board-surface"><div id="board" class="chessboard" role="grid" aria-label="Bàn cờ vua"></div><svg id="boardArrows" class="board-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" aria-hidden="true"><defs><marker id="hintArrowHead" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadGreen" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadRed" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker><marker id="manualArrowHeadYellow" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 z"/></marker></defs><g id="manualAnnotationLines"></g><g id="hintArrowLine"></g></svg></div></div>
      <section class="player-card player-card-self"><div class="opponent-line self-opponent-line"><div class="avatar">♙</div><div class="opponent-meta"><b>Bạn</b><small>Người chơi · ${Number(readRatingProfile().elo || 1200)} Elo</small></div><span class="player-online-dot" aria-label="Trên thiết bị"></span></div><div class="clock-face-row clock-bottom-row">${clockFace(bottomClockColor)}<small id="clockHint" class="clock-hint">${clockState.enabled ? `+${Math.round(clockState.incrementMs / 1000)} giây/nước` : 'Không giới hạn'}</small></div></section>
      <div class="match-status-row"><span id="boardStatus">Trắng đang đi</span><span id="openingChip" class="opening-chip" hidden></span></div>
      <div id="openingExplorerPanel" class="opening-explorer-host" aria-live="polite"></div>
      <div class="mobile-action-row match-action-bar" aria-label="Thao tác ván cờ">
        <button class="secondary-btn" id="undoMove" aria-label="Hoàn tác nước đi" title="Hoàn tác"><span aria-hidden="true">↶</span><small>Hoàn tác</small></button>
        <button class="secondary-btn" id="redoMove" aria-label="Làm lại nước đi" title="Làm lại" ${redoStack.length ? '' : 'disabled'}><span aria-hidden="true">↷</span><small>Làm lại</small></button>
        <button class="secondary-btn" id="hintMove" aria-label="Gợi ý nước đi"><span aria-hidden="true">✦</span><small>Gợi ý</small></button>
        <button class="secondary-btn analyze-quick-btn" id="analyzeQuickBtn" type="button" aria-label="Phân tích ván cờ" title="Phân tích"><span aria-hidden="true">📊</span><small>Phân tích</small></button>
        <button class="secondary-btn" id="flipBoard" aria-label="Đảo bàn cờ"><span aria-hidden="true">⇅</span><small>Đảo bàn</small></button>
        <button class="secondary-btn draw-btn" id="offerDrawBtn" type="button" title="Xin hòa ván đấu" ${gameOver ? 'disabled' : ''}><span aria-hidden="true">½</span><small>Xin hòa</small></button>
        <button class="secondary-btn resign-btn" id="resignBtn" type="button" title="Đầu hàng" ${gameOver ? 'disabled' : ''}><span aria-hidden="true">⚑</span><small>Đầu hàng</small></button>
      </div>
    </div>
    <div class="match-sheet-backdrop" id="matchSheetBackdrop" hidden></div>
    <aside class="side-column match-sheet" id="matchSheet" aria-label="Menu trận đấu">
      <div class="match-sheet-handle" aria-hidden="true"></div>
      <div class="match-sheet-head"><nav class="match-sheet-tabs" role="tablist" aria-label="Chức năng trận đấu"><button type="button" role="tab" class="is-active" data-sheet-tab="moves">Nước đi</button><button type="button" role="tab" data-sheet-tab="analysis">Phân tích</button><button type="button" role="tab" data-sheet-tab="setup">Thiết lập</button><button type="button" role="tab" data-sheet-tab="pages">Trang khác</button></nav><button type="button" id="closeMatchMenu" class="match-icon-btn match-sheet-close" aria-label="Đóng menu">✕</button></div>
      <div class="match-sheet-pane" data-sheet-pane="moves"><section class="panel moves-panel"><div class="panel-heading"><div><small class="eyebrow">LỊCH SỬ</small><h2>Nước đi</h2></div><div class="panel-icons"><button class="tiny-btn" id="copyPGN" title="Sao chép PGN">⧉</button><button class="tiny-btn" id="downloadPGN" title="Tải PGN">↓</button></div></div><div id="moveList" class="move-list"></div></section>
      </div>
      <div class="match-sheet-pane" data-sheet-pane="analysis" hidden><div class="evaluation-meter-row" aria-label="Thanh đánh giá thế cờ"><span>TRẮNG</span><div id="evaluationMeter" class="evaluation-meter" role="img" aria-label="Lợi thế ước tính của Trắng"><span id="evaluationMeterWhite"></span></div><span>ĐEN</span></div>
      <section class="analysis-tools-entry"><button type="button" id="openDrawingTools" class="secondary-btn full-width" aria-expanded="false">✎ Bút vẽ & đánh dấu bàn cờ</button><div id="annotationToolsDockMenu" class="annotation-tools-dock annotation-tools-dock-menu" hidden></div></section>
      <div class="analysis-action-row"><button id="analyzePosition" class="secondary-btn">♙ Phân tích 3 biến</button><small>Stockfish · PV × 3</small></div>
      <section id="analysisPanel" class="analysis-panel" ${analysisVisible || analysisActive || analysisVariants.length ? '' : 'hidden'} aria-live="polite"><div class="analysis-panel-heading"><b>Phân tích Stockfish</b><span>MultiPV 3 · điểm theo Trắng</span></div><div id="analysisLines" class="analysis-lines"><div class="analysis-empty">Nhấn “Phân tích 3 biến” để xem các phương án tốt nhất.</div></div></section>

      <section class="panel quick-tools"><h3>Phân tích nhanh</h3><div class="tool-grid"><button id="explainPosition" class="tool-btn"><span>✦</span><b>Phân tích thế cờ</b><small>Stockfish · biến thể thật</small></button><button id="queryExplorer" class="tool-btn"><span>⌘</span><b>Khai cuộc</b><small>Dữ liệu Lichess</small></button></div><div id="explorerResult" class="explorer-result"></div></section>
    </div>
      <div class="match-sheet-pane" data-sheet-pane="setup" hidden><details class="panel game-setup" id="gameSetupPanel" open><summary class="game-setup-summary"><span><small class="eyebrow">VÁN CỜ</small><strong>Thiết lập trận</strong><small class="game-setup-subtitle">Chế độ · màu quân · sức mạnh bot</small></span><span class="setup-chevron" aria-hidden="true">⌄</span></summary><div class="game-setup-body">
<label class="field-label" for="modeSelect">Chế độ chơi / đối thủ</label><select id="modeSelect" class="field"><option value="stockfish" ${mode === 'stockfish' ? 'selected' : ''}>Stockfish — chơi với máy</option><option value="vila" ${mode === 'vila' ? 'selected' : ''}>ViLa Classic — AI ngoại tuyến, không phải Stockfish</option><option value="enginehub" ${mode === 'enginehub' ? 'selected' : ''}>AI đa phong cách — offline, không cần backend</option><option value="lichess" ${mode === 'lichess' ? 'selected' : ''}>Lichess trực tuyến</option><option value="local" ${mode === 'local' ? 'selected' : ''}>Hai người trên cùng máy</option></select><p class="field-hint engine-choice-note">Stockfish 19: engine chuyên dụng chạy trong app. Bot phong cách có kho khai cuộc riêng; khi Stockfish sẵn sàng, chúng dùng tìm kiếm Stockfish và chọn biến thể theo cá tính. Đây là profile VILA, không phải binary gốc Lc0/Ethereal/Berserk. Lichess là chế độ online tùy chọn.</p>
        <label class="field-label" for="gameBotProfile">Chọn đối thủ / phong cách bot</label><select id="gameBotProfile" class="field">${OFFLINE_ENGINE_CATALOG.map(item => `<option value="${item.id}" ${settings.alternativeEngine === item.id ? 'selected' : ''}>${esc(item.label)} · ${esc(item.hint)}</option>`).join('')}</select><p class="field-hint">Các phong cách là profile huấn luyện VILA trên engine tìm kiếm cục bộ; không phải 18 mạng neural độc lập hay Elo đã đo.</p>
        <div class="two-fields"><div><label class="field-label" for="colorSelect">Bạn cầm quân</label><select id="colorSelect" class="field" ${mode === 'lichess' ? 'disabled' : ''}><option value="random" ${colorChoice === 'random' ? 'selected' : ''}>🎲 Ngẫu nhiên Trắng / Đen (mặc định)</option><option value="w" ${colorChoice === 'w' ? 'selected' : ''}>Trắng</option><option value="b" ${colorChoice === 'b' ? 'selected' : ''}>Đen</option></select></div><div><label class="field-label" for="skillSelect">Sức mạnh bot (Elo 500–3200)</label><select id="skillSelect" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn Elo</option>${[...new Set([...Array.from({ length: 28 }, (_, i) => 500 + i * 100), 3200, ...(Number(settings.botElo) % 100 === 0 ? [] : [Number(settings.botElo)])])].sort((a,b)=>a-b).map(n => `<option value="${n}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === n ? 'selected' : ''}>Elo ${n}${n === 3200 ? ' · mức cao nhất' : ''}</option>`).join('')}</select><button type="button" id="randomBotElo" class="text-btn random-elo-btn" aria-pressed="${randomBotEloEnabled}">🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}</button></div></div>
        <button id="newGameSetup" class="primary-btn full-width">Bắt đầu ván mới <span>→</span></button>
        <div class="stats-row"><div><small>Đánh giá</small><b id="evalNumber">—</b></div><div><small>Số nước</small><b id="gameMoveCount">${game.history().length}</b></div><div><small>Trạng thái</small><b id="gameStatusText" class="status-text">${!gameStarted ? 'Sẵn sàng' : (game.isGameOver() || clockFlagged) ? 'Kết thúc' : 'Đang chơi'}</b></div></div>
      </div></details>
      
        <div class="match-sheet-extra"><button type="button" class="secondary-btn" id="toggleChessMusic" title="Bật/tắt nhạc nền">🎧 Nhạc</button><button type="button" class="secondary-btn" id="clearBoardSelection" aria-label="Hủy nước đi đang chọn">× Hủy chọn</button><button type="button" class="secondary-btn" id="restartGameBtn" title="Chơi lại ván đấu">↺ Chơi lại</button><button type="button" class="primary-btn" id="newGame" aria-label="Bắt đầu ván mới">▶ Ván mới</button></div></div>
      <div class="match-sheet-pane" data-sheet-pane="pages" hidden><p class="match-sheet-hint">Chuyển sang trang khác — ván đang chơi được giữ lại. Kho khai cuộc: <b id="playOpeningCount">${OPENINGS.length.toLocaleString()}</b> đường.</p><div class="match-page-grid">${pageShortcuts.map(([view, icon, label]) => `<button type="button" class="match-page-link" data-play-rail-view="${view}"><i aria-hidden="true">${icon}</i><span>${label}</span></button>`).join('')}</div><div class="match-sheet-extra"><button type="button" class="secondary-btn" id="gameShowSetup">⚙ Thiết lập trận mới</button></div></div>
    </aside>
    <div id="virtualMousePanel" class="virtual-mouse-panel" hidden aria-label="Chuột ảo điều khiển bằng ngón tay">
      <div class="virtual-mouse-head"><button type="button" id="virtualMouseGrip" class="virtual-mouse-grip" aria-label="Giữ để di chuyển chuột ảo" title="Giữ để di chuyển bảng chuột">⠿ <b>CHUỘT ẢO</b></button><button type="button" id="virtualMouseMinimize" aria-label="Thu nhỏ chuột ảo" title="Thu nhỏ">−</button><button type="button" id="virtualMouseClose" aria-label="Tắt chuột ảo" title="Tắt">×</button></div>
      <div id="virtualMousePad" class="virtual-mouse-pad" role="application" aria-label="Vùng trượt để di chuyển con trỏ"><span>TRƯỢT · CHẠM = NHẤN · CHẠM 2 LẦN + KÉO = GIỮ</span><i aria-hidden="true">⌖</i></div>
      <div class="virtual-mouse-actions"><button type="button" id="virtualMouseClick" title="Nhấn chuột tại vị trí con trỏ">● Nhấn</button><button type="button" id="virtualMouseHold" title="Giữ chuột rồi di chuyển con trỏ để kéo quân" aria-pressed="false">↘ Giữ / kéo</button></div>
      <button type="button" id="virtualMouseCamera" class="virtual-mouse-camera" aria-pressed="false" title="Bật nhận diện bàn tay qua camera">✋ Điều khiển bằng tay</button>
      <button type="button" id="virtualMouseToolsToggle" class="virtual-mouse-tools-toggle" aria-expanded="false" aria-controls="annotationToolsDockMouse">✎ Bút vẽ & đánh dấu</button>
      <div id="annotationToolsDockMouse" class="annotation-tools-dock annotation-tools-dock-mouse" hidden>
        <div class="annotation-dock-caption"><span>✎ BÚT VẼ / PHÂN TÍCH</span><small>Không che bàn cờ</small></div>
                <div id="boardAnnotationWidget" class="board-annotation-widget ${annotationCollapsed ? 'is-collapsed' : ''}" ${!gameStarted || !['stockfish','stockfish-beginner','vila','enginehub'].includes(mode) ? 'hidden' : ''} aria-label="Công cụ vẽ phân tích">
          <button type="button" id="annotationWidgetToggle" class="annotation-widget-toggle" title="Thu gọn / mở công cụ" aria-expanded="${!annotationCollapsed}">✎</button>
          <div id="boardAnnotationTools" class="board-annotation-tools" ${annotationCollapsed ? 'hidden' : ''}>
            <button type="button" data-annotation-tool="move" title="Tắt vẽ để di chuyển quân bình thường" aria-label="Di chuyển quân" aria-pressed="${!annotationTool}">♟</button>
            <button type="button" data-annotation-tool="arrow" title="Kéo để vẽ mũi tên thẳng" aria-label="Vẽ mũi tên" aria-pressed="${annotationTool === 'arrow'}">↗</button>
            <button type="button" data-annotation-tool="pencil" title="Giữ và kéo để vẽ tự do" aria-label="Bút chì vẽ tự do" aria-pressed="${annotationTool === 'pencil'}">✎</button>
            <button type="button" data-annotation-tool="knight" title="Kéo để vẽ đường chữ L kiểu quân Mã" aria-label="Mũi tên chữ L kiểu quân Mã" aria-pressed="${annotationTool === 'knight'}">♘</button>
            <button type="button" data-annotation-tool="circle" title="Khoanh ô" aria-label="Khoanh ô" aria-pressed="${annotationTool === 'circle'}">◯</button>
            <button type="button" data-annotation-color="green" class="annotation-color-dot color-green" aria-label="Màu xanh lá" aria-pressed="${annotationColor === 'green'}">●</button>
            <button type="button" data-annotation-color="red" class="annotation-color-dot color-red" aria-label="Màu đỏ" aria-pressed="${annotationColor === 'red'}">●</button>
            <button type="button" data-annotation-color="yellow" class="annotation-color-dot color-yellow" aria-label="Màu vàng" aria-pressed="${annotationColor === 'yellow'}">●</button>
            <button type="button" data-annotation-color="blue" class="annotation-color-dot color-blue" aria-label="Màu xanh dương" aria-pressed="${annotationColor === 'blue'}">●</button>
            <button type="button" id="annotationColorCycle" class="annotation-color-cycle color-green" title="Đổi màu kế tiếp" aria-label="Đổi màu nét">↻</button>
            <button type="button" id="annotationClear" title="Xóa dấu vẽ" aria-label="Xóa dấu vẽ">⌫</button>
            <button type="button" id="annotationWidgetHide" title="Ẩn menu vẽ" aria-label="Ẩn menu vẽ">×</button>
          </div>
        </div>
      </div>
      <video id="virtualMouseVideo" class="virtual-mouse-video" width="320" height="240" autoplay muted playsinline hidden></video>
      <p id="virtualMouseStatus" class="virtual-mouse-status">Trượt vùng cảm ứng hoặc bật camera để điều khiển bằng ngón trỏ.</p>
    </div>
    <button type="button" id="virtualMouseReopen" class="virtual-mouse-reopen" hidden aria-label="Mở lại chuột ảo" title="Mở chuột ảo">⌖</button>
    <div id="virtualMouseCursor" class="virtual-mouse-cursor" aria-hidden="true" hidden><svg viewBox="0 0 24 28" focusable="false"><path d="M2 1.5 2.4 22 7.8 16.4 12.2 26 16.1 24.2 11.7 14.8 19.8 14.1Z"/></svg></div>
    </section>
  </section>`;
}
function renderOpeningsView() {
  return `<section class="content-page openings-page"><div class="page-intro openings-intro"><div class="eyebrow">CỜ VUA · OPENING EXPLORER</div><h1>Thư viện khai cuộc</h1><p>Tìm theo tên, mã ECO hoặc nước đi; phát lại cả biến khai cuộc trên bàn cờ. Khi build có mạng, VILA đóng gói thêm cơ sở dữ liệu ECO mở rộng, còn kho mẫu vẫn hoạt động khi ngoại tuyến.</p><div class="opening-library-stats"><strong id="openingCount">${OPENINGS.length} đường khai cuộc</strong><span>Đã lọc theo biến hợp lệ</span><span class="opening-source-chip">ECO · Lichess CC0</span></div></div>
    <div class="opening-toolbar"><label class="opening-search-wrap"><span aria-hidden="true">⌕</span><input id="openingSearch" class="field search-field" placeholder="Tìm tên khai cuộc, mã ECO…" aria-label="Tìm khai cuộc"/></label><select id="openingFilter" class="field" aria-label="Lọc hệ thống"><option value="all">Tất cả hệ thống</option><option value="Mở e4">Khai cuộc 1.e4</option><option value="Mở d4">Khai cuộc 1.d4</option><option value="Phòng thủ">Phòng thủ</option><option value="Tấn công">Tấn công</option><option value="Mở c4">Khai cuộc 1.c4 / linh hoạt</option></select></div>
    <div id="openingGrid" class="opening-grid">${renderOpeningCards()}</div>
    <div class="note-banner opening-note"><span>✦</span><div><b>Kho mẫu + ECO mở rộng</b><p>Chọn “Xem biến” để kiểm tra toàn bộ nước trên bàn tạm trước khi thay ván hiện tại. AI chọn nước trong các nhánh có tiền tố khớp lịch sử ván; hết kho hoặc rời biến thì Stockfish tiếp quản. Dữ liệu khai cuộc là tài liệu tham khảo, không cam kết mọi biến đều là lựa chọn chiến thuật tốt nhất.</p></div></div>
  </section>`;
}
function renderOpeningCards(filter = '', family = 'all', limit = openingPageLimit) {
  const query = String(filter || '').trim().toLocaleLowerCase();
  const filtered = OPENINGS.filter(o => (family === 'all' || o.family === family) && `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(query));
  const visible = filtered.slice(0, Math.max(1, Number(limit) || 48));
  const cards = visible.map(o => `<article class="opening-card"><div class="opening-card-top"><span class="eco-tag">${esc(o.eco)}</span><span class="family-tag">${esc(o.family)}</span></div><h3>${esc(o.name)}</h3><p>${esc(o.note)}</p><div class="opening-line">${esc(o.line)}</div><div class="opening-card-bottom"><span>${o.san.length} nửa nước đi</span><button class="mini-primary" data-load-opening="${OPENINGS.indexOf(o)}">Xem biến ↗</button></div></article>`).join('');
  const more = filtered.length > visible.length ? `<div class="opening-load-more-wrap"><span>Đang hiện ${visible.length} / ${filtered.length} khai cuộc</span><button id="loadMoreOpenings" type="button" class="secondary-btn">Tải thêm 48 biến ↓</button></div>` : `<div class="opening-load-more-wrap"><span>Hiển thị ${visible.length} / ${filtered.length} khai cuộc</span></div>`;
  return `${cards || '<div class="empty-state">Không tìm thấy khai cuộc phù hợp.</div>'}${more}`;
}
function renderCoachView() {
  const moveCount = game.history().length;
  const opening = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
  return `<section class="content-page coach-page offline-coach-page">
    <div class="page-intro"><div class="eyebrow">OFFLINE ANALYSIS LAB</div><h1>Phân tích & huấn luyện</h1><p>Công cụ cờ vua chạy cục bộ: Stockfish tính biến thể, bộ xem lại chấm từng nước, kho khai cuộc và câu đố theo tiến trình. Không cần API key hoặc chatbot ngoài.</p></div>
    <div class="coach-layout offline-tools-grid">
      <section class="panel coach-context"><div class="panel-heading"><div><small class="eyebrow">THẾ CỜ HIỆN TẠI</small><h2>Vị trí đang chơi</h2></div><span class="context-icon">♞</span></div>
        <div class="context-stat"><span>FEN</span><code>${esc(game.fen())}</code><button id="copyFen" class="tiny-btn" type="button" aria-label="Sao chép FEN">⧉</button></div>
        <div class="context-stat"><span>PGN</span><code class="truncate-code">${esc(game.pgn() || 'Chưa có nước đi')}</code><button id="copyPgnCoach" class="tiny-btn" type="button" aria-label="Sao chép PGN">⧉</button></div>
        <div class="ranked-stat-grid"><div class="ranked-stat"><small>Số nửa nước</small><b>${moveCount}</b></div><div class="ranked-stat"><small>Khai cuộc</small><b>${esc(opening?.eco || '—')}</b></div><div class="ranked-stat"><small>Engine</small><b>${engineReady && !engineFailed ? 'Sẵn sàng' : 'Đang tải'}</b></div></div>
        <p class="field-hint">${esc(opening?.name || (moveCount < 5 ? 'Khai cuộc sẽ được nhận diện sau vài nước.' : 'Chưa nhận diện được biến khai cuộc trong kho hiện có.'))}</p>
      </section>
      <section class="panel offline-analysis-actions"><div class="panel-heading"><div><small class="eyebrow">CÔNG CỤ THỰC CHIẾN</small><h2>Phân tích nước đi</h2></div><span class="context-icon">⌘</span></div>
        <button id="coachAnalyzePosition" class="primary-btn full-width" type="button">♙ Phân tích 3 biến bằng Stockfish</button>
        <button id="coachReviewGame" class="secondary-btn full-width" type="button">↶ Xem lại & đánh giá toàn ván</button>
        <button id="coachOpenPuzzles" class="secondary-btn full-width" type="button">🧩 Luyện câu đố từ dễ đến khó</button>
        <button id="coachOpenOpenings" class="secondary-btn full-width" type="button">⌘ Học kho khai cuộc</button>
        <p class="field-hint">Phân tích dùng engine cờ; phần nhận xét dựa trên đánh giá nước đi và biến UCI, không giả vờ là lời giải của chatbot.</p>
      </section>
      <section class="panel coach-online-explorer"><div class="panel-heading"><div><small class="eyebrow">LICHESS OPEN DATABASE</small><h2>Bàn học trực tuyến</h2></div><span class="context-icon">↗</span></div><p class="field-hint">Tra cứu thống kê các nước phổ biến từ cơ sở dữ liệu ván cờ công khai Lichess theo thế cờ hiện tại. Cần kết nối mạng và backend API đang hoạt động.</p><button id="coachOnlineExplorer" class="secondary-btn full-width" type="button">Tra nước phổ biến trong thế này</button><div id="coachOnlineExplorerResults" class="coach-online-explorer-results" aria-live="polite">Chưa tải dữ liệu trực tuyến.</div><a class="external-link" href="https://lichess.org/analysis" target="_blank" rel="noopener noreferrer">Mở bàn phân tích Lichess ↗</a></section>
    </div>
  </section>`;
}
function renderLichessView() {
  const token = activeLichessToken || safeSessionGet(lichessTokenKey) || '';
  const activeLichessUrl = activeOnlineGame ? safeLichessUrl(activeOnlineGame.url, activeOnlineGame.id) : 'https://lichess.org/';
  return `<section class="content-page"><div class="page-intro"><div class="eyebrow">CHƠI TRỰC TUYẾN</div><h1>Kết nối Lichess</h1><p>Kết nối tài khoản bằng Personal Access Token. Token chỉ giữ trong phiên trình duyệt và được gửi tới backend đã cấu hình; không đưa token lên GitHub. Bot API cần tài khoản đã được nâng cấp thành Bot và đúng scope.</p></div>
    <div class="lichess-layout"><section class="panel"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Kết nối Lichess.org</h2></div><div class="lichess-logo">♞</div></div><label class="field-label" for="lichessToken">Personal Access Token</label><input id="lichessToken" type="password" autocomplete="off" class="field" placeholder="Dán token có quyền phù hợp" value="${esc(token)}"/><div class="field-hint">Dùng quyền cần thiết cho cách chơi bạn muốn: đọc tài khoản và chơi ván cờ. Không dán token vào nơi công khai.</div><label class="field-label" for="lichessApiMode">Kiểu API chơi ván</label><select id="lichessApiMode" class="field"><option value="board">Tài khoản thông thường (Board API)</option><option value="bot">Tài khoản Lichess Bot (Bot API)</option></select><div class="field-hint">Chọn Bot API chỉ khi tài khoản đã được nâng cấp thành bot; tài khoản thường dùng Board API.</div><div class="button-row"><button id="connectLichess" class="primary-btn">Kiểm tra kết nối</button><button id="forgetLichess" class="secondary-btn">Xóa token</button></div><div id="lichessAccountResult" class="connection-result">${token ? 'Token đang lưu tạm trong phiên này; hãy kiểm tra kết nối.' : 'Chưa kết nối tài khoản.'}</div><div class="form-divider"></div><h3>Thử đấu AI của Lichess</h3><div class="two-fields"><div><label class="field-label" for="lichessLevel">Độ khó AI (1–8)</label><select id="lichessLevel" class="field">${[1,2,3,4,5,6,7,8].map(n=>`<option value="${n}" ${n===3?'selected':''}>Cấp ${n}</option>`).join('')}</select></div><div><label class="field-label" for="lichessClock">Thời gian (giây)</label><select id="lichessClock" class="field"><option value="60">1 phút</option><option value="180">3 phút</option><option value="300" selected>5 phút</option><option value="600">10 phút</option><option value="0">Không giới hạn</option></select></div></div><button id="challengeLichessAI" class="primary-btn full-width">Tạo ván với AI Lichess ↗</button><div class="form-divider"></div><h3>Thách đấu người chơi</h3><label class="field-label" for="lichessUsername">Tên người chơi Lichess</label><input id="lichessUsername" class="field" placeholder="Ví dụ: username"/><button id="challengeLichessUser" class="secondary-btn full-width">Gửi lời mời đấu ↗</button><div id="lichessChallengeResult" class="connection-result"></div></section>
    <section class="panel lichess-info"><div class="panel-heading"><div><small class="eyebrow">KẾT NỐI THỰC TẾ</small><h2>Trạng thái & hướng dẫn</h2></div><span class="online-indicator"></span></div><div class="info-row"><span class="info-icon">✓</span><div><b>Dữ liệu khai cuộc</b><p>Tra thống kê nước đi trong tab Khai cuộc qua Lichess Opening Explorer; không cần token cho truy vấn công khai.</p></div></div><div class="info-row"><span class="info-icon">↗</span><div><b>Ván trực tuyến</b><p>Sau khi gửi thử thách, mở trang ván trên Lichess để chấp nhận/chơi. Đồng bộ nước đi trong ứng dụng cần token, đúng API scope và backend có thể truy cập Lichess.</p></div></div><div class="info-row"><span class="info-icon">!</span><div><b>Bot Lichess không giống AI Stockfish nội bộ</b><p>API Bot chỉ hoạt động với tài khoản bot đủ điều kiện. Không dùng tài khoản thường để tự động hóa qua Bot API.</p></div></div><a class="external-link" href="https://lichess.org/account/oauth/token" target="_blank" rel="noopener noreferrer">Mở trang quản lý token ↗</a><a class="external-link" href="https://lichess-org.github.io/api/" target="_blank" rel="noopener noreferrer">Tài liệu API chính thức ↗</a><div id="lichessActiveGame" class="active-game-card">${activeOnlineGame ? `Ván vừa tạo: <b>${esc(activeOnlineGame.id || '')}</b><br><a href="${esc(activeLichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a><br><button id="playLichessHere" class="mini-primary">Kết nối ván trong Cờ Vua</button>` : 'Chưa tạo ván nào trong phiên này.'}</div></section></div>
    </section>
  </section>`;
}
function accountSettingsMarkup() {
  const user = socialState.user;
  if (!socialState.token || !user) {
    return `<section class="panel settings-panel account-settings"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Tài khoản Cờ Vua</h2></div><span class="context-icon">♙</span></div>
        <p class="field-hint">Bạn đang chơi không đăng nhập. Đăng nhập để đổi tên, liên kết email, đổi mật khẩu và đồng bộ ván cờ giữa các thiết bị.</p>
        <div class="button-row"><button id="accountLogin" class="primary-btn" type="button">Đăng nhập / Tạo tài khoản</button></div></section>`;
  }
  const email = String(user.email || '');
  return `<section class="panel settings-panel account-settings" id="accountSettings"><div class="panel-heading"><div><small class="eyebrow">TÀI KHOẢN</small><h2>Tài khoản của bạn</h2></div><span class="context-icon">♙</span></div>
        <div class="account-summary"><div class="social-big-avatar" style="${avatarStyle(user)}">${avatarEmoji(user)}</div><div class="account-summary-info"><b id="accountSummaryName">${esc(user.displayName || user.username)}</b><small>@${esc(user.username)} · ${email ? esc(email) : 'Chưa liên kết email'}</small></div></div>
        <form id="accountNameForm" class="account-form" autocomplete="off"><label class="field-label" for="accountDisplayName">Tên hiển thị</label><input id="accountDisplayName" class="field" maxlength="40" minlength="2" required value="${esc(user.displayName || user.username)}"/><small class="field-hint">Tên bạn bè và bảng xếp hạng nhìn thấy. Tên đăng nhập @${esc(user.username)} không đổi.</small><button class="secondary-btn" type="submit">Lưu tên</button></form>
        <form id="accountEmailForm" class="account-form" autocomplete="off"><label class="field-label" for="accountEmail">Email liên kết</label><input id="accountEmail" class="field" type="email" inputmode="email" autocapitalize="none" maxlength="254" value="${esc(email)}" placeholder="ban@example.com"/><label class="field-label" for="accountEmailPassword">Mật khẩu để xác nhận</label><input id="accountEmailPassword" class="field" type="password" autocomplete="current-password" maxlength="256" required placeholder="Mật khẩu hiện tại"/><div class="button-row"><button class="secondary-btn" type="submit">${email ? 'Đổi email' : 'Liên kết email'}</button>${email ? '<button id="accountEmailRemove" class="secondary-btn" type="button">Gỡ email</button>' : ''}</div></form>
        <form id="accountPasswordForm" class="account-form" autocomplete="off"><label class="field-label" for="accountCurrentPassword">Đổi mật khẩu</label><input id="accountCurrentPassword" class="field" type="password" autocomplete="current-password" maxlength="256" required placeholder="Mật khẩu hiện tại"/><input id="accountNewPassword" class="field" type="password" autocomplete="new-password" minlength="8" maxlength="256" required placeholder="Mật khẩu mới (tối thiểu 8 ký tự)"/><input id="accountConfirmPassword" class="field" type="password" autocomplete="new-password" minlength="8" maxlength="256" required placeholder="Nhập lại mật khẩu mới"/><small class="field-hint">Sau khi đổi, các thiết bị khác sẽ bị đăng xuất.</small><button class="secondary-btn" type="submit">Đổi mật khẩu</button></form>
        <div class="button-row"><button id="accountLogout" class="secondary-btn" type="button">Đăng xuất</button></div>
        <div id="accountResult" class="connection-result" aria-live="polite"></div></section>`;
}
function renderSettingsView() {
  const strengthOptions = [...new Set([...Array.from({ length: 28 }, (_, index) => 500 + index * 100), 3200, Number(settings.botElo)])].filter(value => Number.isFinite(value) && value >= 500 && value <= 3200).sort((a, b) => a - b);
  return `<section class="content-page settings-page offline-settings-page">
    <div class="page-intro settings-page-intro"><div class="eyebrow">CỜ VUA · TÙY CHỈNH TRẢI NGHIỆM</div><h1>Cài đặt</h1><p>Tùy chỉnh bàn cờ, cách di chuyển, âm thanh, sức mạnh bot và chất lượng phân tích. Thay đổi được lưu trên thiết bị và không sửa luật cờ.</p></div>
    <div class="settings-layout settings-layout-pro">
      <div class="settings-main">
        ${accountSettingsMarkup()}
        <section class="panel settings-panel settings-section-card"><div class="settings-section-heading"><span class="settings-section-icon">${uiTile('cube','cyan','tile-lg')}</span><div><small class="eyebrow">01 · GIAO DIỆN</small><h2>Bàn cờ & quân cờ</h2><p>Thiết kế không gian chơi theo mắt nhìn của bạn.</p></div></div>
          <label class="field-label">Bảng màu bàn cờ</label>
          <div class="theme-swatch-row" id="boardThemeSwatches">${BOARD_THEME_CATALOG.map(theme => `<button type="button" class="theme-swatch ${document.documentElement.dataset.boardTheme === theme.id ? 'active' : ''}" data-board-theme="${theme.id}" title="${esc(theme.label)}" style="--sw-light:${theme.light};--sw-dark:${theme.dark}" aria-label="${esc(theme.label)}"><i><b></b><b></b><b></b><b></b></i></button>`).join('')}</div>
          <div class="settings-fields-grid"><div><label class="field-label" for="pieceStyleSetting">Bộ quân cờ</label><select id="pieceStyleSetting" class="field">${PIECE_STYLES.map(item => `<option value="${item.id}" ${getPieceStyle() === item.id ? 'selected' : ''}>${esc(item.label)}</option>`).join('')}</select></div><div><label class="field-label" for="boardThemeSetting">Hiệu ứng / chủ đề</label><select id="boardThemeSetting" class="field">${COSMETICS.map(item => `<option value="${item.id}" ${getSelectedBoardTheme(document.documentElement.dataset.boardTheme || 'classic') === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></div></div>
          <small class="field-hint">Chủ đề được áp dụng cho bàn chơi và các chế độ có hỗ trợ. Hình xem trước giúp kiểm tra độ tương phản trước khi vào trận.</small>
          <div class="appearance-preview" aria-label="Xem trước bàn cờ và bộ quân"><div class="appearance-preview-board" aria-hidden="true">${Array.from({length:16}, (_, index) => `<span class="${((Math.floor(index / 4) + index % 4) % 2) ? 'dark' : 'light'}">${index === 5 ? pieceSvgMarkup({type:'k',color:'w'}, getPieceStyle()) : index === 10 ? pieceSvgMarkup({type:'q',color:'b'}, getPieceStyle()) : ''}</span>`).join('')}</div><div class="appearance-preview-pieces">${['k','q','r','b','n','p'].map(type => `<span title="${({k:'Vua',q:'Hậu',r:'Xe',b:'Tượng',n:'Mã',p:'Tốt'})[type]}">${pieceSvgMarkup({type,color:'w'}, getPieceStyle())}</span>`).join('')}</div><small>Xem trước bàn cờ và quân cờ</small></div>
        </section>
        <section class="panel settings-panel settings-section-card"><div class="settings-section-heading"><span class="settings-section-icon">${uiTile('hand','purple','tile-lg')}</span><div><small class="eyebrow">02 · CÁCH CHƠI</small><h2>Di chuyển & tiện ích</h2><p>Các tùy chọn quen thuộc trong cài đặt chơi cờ trực tuyến.</p></div></div>
          <div class="preference-grid visual-preference-grid">
            <label class="preference-toggle"><input id="showLegalMovesSetting" type="checkbox" ${visualSettings.showLegalMoves ? 'checked' : ''}/><span><b>Hiện nước đi hợp lệ</b><small>Hiện các ô có thể đi khi chọn quân.</small></span></label>
            <label class="preference-toggle"><input id="highlightLastMoveSetting" type="checkbox" ${visualSettings.highlightLastMove ? 'checked' : ''}/><span><b>Tô nước đi gần nhất</b><small>Giúp theo dõi nước vừa được thực hiện.</small></span></label>
            <label class="preference-toggle"><input id="showCoordinatesSetting" type="checkbox" ${visualSettings.showCoordinates ? 'checked' : ''}/><span><b>Tọa độ bàn cờ</b><small>Hiện ký hiệu a–h và 1–8 quanh bàn.</small></span></label>
            <label class="preference-toggle"><input id="premoveEnabledSetting" type="checkbox" ${visualSettings.premoveEnabled ? 'checked' : ''}/><span><b>Nước đi trước (premove)</b><small>Đặt nước dự kiến khi bot đang suy nghĩ; nước chỉ đi nếu hợp lệ đến lượt bạn.</small></span></label>
            <label class="preference-toggle"><input id="showCapturedMaterialSetting" type="checkbox" ${visualSettings.showCapturedMaterial ? 'checked' : ''}/><span><b>Quân đã ăn & lợi thế vật chất</b><small>Hiện quân bị bắt và chênh lệch vật chất.</small></span></label>
            <label class="preference-toggle"><input id="smoothAnimationsSetting" type="checkbox" ${visualSettings.smoothAnimations ? 'checked' : ''}/><span><b>Hiệu ứng chuyển động</b><small>Tắt để giảm hiệu ứng trên điện thoại cấu hình thấp.</small></span></label>
            <label class="preference-toggle"><input id="autoQueenSetting" type="checkbox" ${visualSettings.autoQueen ? 'checked' : ''}/><span><b>Tự động phong Hậu</b><small>Phong Hậu ngay khi tốt đến hàng cuối mà không hỏi lại.</small></span></label>
            <label class="preference-toggle"><input id="confirmResignSetting" type="checkbox" ${visualSettings.confirmResign ? 'checked' : ''}/><span><b>Xác nhận trước khi đầu hàng</b><small>Dùng bảng xác nhận mang thương hiệu VILA, không dùng hộp thoại thô của trình duyệt.</small></span></label>
            <label class="preference-toggle"><input id="announceMovesSetting" type="checkbox" ${visualSettings.announceMoves ? 'checked' : ''}/><span><b>Hỗ trợ trình đọc màn hình</b><small>Thông báo nước đi, chiếu và trạng thái bàn cờ.</small></span></label>
          </div>
        </section>
        <section class="panel settings-panel settings-section-card"><div class="settings-section-heading"><span class="settings-section-icon">${uiTile('robot','gold','tile-lg')}</span><div><small class="eyebrow">03 · BOT & PHÂN TÍCH</small><h2>Sức mạnh đối thủ</h2><p>Đặt sức mạnh mặc định cho các ván mới. Thay đổi không làm đổi bot giữa chừng trong ván đang chạy.</p></div></div>
          <div class="settings-fields-grid"><div><label class="field-label" for="settingsBotStrength">Mức sức mạnh</label><select id="settingsBotStrength" class="field"><option value="max" ${settings.botStrengthMode !== 'elo' ? 'selected' : ''}>Mạnh nhất · không giới hạn</option>${strengthOptions.map(elo => `<option value="${elo}" ${settings.botStrengthMode === 'elo' && Number(settings.botElo) === elo ? 'selected' : ''}>Elo ${elo}${elo === 3200 ? ' · cao nhất' : ''}</option>`).join('')}</select></div><div><label class="field-label" for="settingsBotEngine">Engine ưu tiên</label><select id="settingsBotEngine" class="field">${[{id:'auto',label:'Tự động · khuyến nghị'},{id:'lite-single',label:'Chế độ nhẹ'},{id:'full-single',label:'Chế độ đầy đủ'},{id:'sf10',label:'Stockfish 10 · tương thích'}].map(option => `<option value="${option.id}" ${settings.botEngine === option.id ? 'selected' : ''}>${option.label}</option>`).join('')}</select></div><div><label class="field-label" for="settingsBotDepth">Độ sâu tìm kiếm</label><select id="settingsBotDepth" class="field">${[12,16,20,24,28,30].map(depth => `<option value="${depth}" ${Number(settings.botDepth) === depth ? 'selected' : ''}>${depth} ply</option>`).join('')}</select></div><div><label class="field-label" for="settingsBotMoveTime">Thời gian nghĩ mỗi nước</label><select id="settingsBotMoveTime" class="field">${[{v:800,l:'Nhanh · 0,8 giây'},{v:1200,l:'1,2 giây'},{v:1600,l:'1,6 giây'},{v:2200,l:'2,2 giây'},{v:2600,l:'Tiêu chuẩn · 2,6 giây'},{v:3200,l:'3,2 giây'},{v:4000,l:'4 giây'},{v:5000,l:'5 giây'}].map(option => `<option value="${option.v}" ${Number(settings.botMoveTimeMs) === option.v ? 'selected' : ''}>${option.l}</option>`).join('')}</select></div><div><label class="field-label" for="settingsReviewQuality">Chất lượng phân tích sau ván</label><select id="settingsReviewQuality" class="field">${[{id:'fast',label:'Nhanh'},{id:'standard',label:'Tiêu chuẩn'},{id:'deep',label:'Sâu'},{id:'max',label:'Tối đa · tốn thời gian hơn'}].map(option => `<option value="${option.id}" ${settings.reviewQuality === option.id ? 'selected' : ''}>${option.label}</option>`).join('')}</select></div><div><label class="field-label" for="settingsClockPreset">Đồng hồ mặc định cho ván mới</label><select id="settingsClockPreset" class="field">${CLOCK_PRESETS.map(option => `<option value="${option.value}" ${settings.clockPreset === option.value ? 'selected' : ''}>${esc(option.label)}</option>`).join('')}</select></div></div>
          <div class="preference-grid"><label class="preference-toggle"><input id="settingsOpeningBook" type="checkbox" ${settings.openingBookEnabled ? 'checked' : ''}/><span><b>Nạp kho khai cuộc</b><small>Dùng dữ liệu khai cuộc đã nạp để bot ưu tiên nước đi mở đầu và nhận diện các dòng khai cuộc.</small></span></label></div>
          <p class="field-hint settings-note">Elo ở đây là mức luyện tập ước lượng, không phải kết quả benchmark Elo chính thức. Engine thực tế còn phụ thuộc thiết bị, tệp engine đã tải và giới hạn thời gian.</p>
        </section>
        <section class="panel settings-panel settings-section-card"><div class="settings-section-heading"><span class="settings-section-icon">${uiTile('headphones','pink','tile-lg')}</span><div><small class="eyebrow">04 · ÂM THANH</small><h2>Âm thanh & nhạc nền</h2><p>Chọn âm báo nước đi và cách phát nhạc nền.</p></div></div>
          <div class="settings-fields-grid"><div><label class="field-label" for="settingsSoundTheme">Kiểu âm nước đi</label><select id="settingsSoundTheme" class="field">${SOUND_THEME_CATALOG.map(option => `<option value="${option.id}" ${settings.soundTheme === option.id ? 'selected' : ''}>${esc(option.label)}</option>`).join('')}</select></div><div class="preference-grid settings-sound-toggles"><label class="preference-toggle"><input id="soundEnabledSetting" type="checkbox" ${settings.soundEnabled ? 'checked' : ''}/><span><b>Âm thanh trong trận</b><small>Tắt toàn bộ âm báo của nước đi.</small></span></label><label class="preference-toggle"><input id="musicAutostartSetting" type="checkbox" ${musicAutostart ? 'checked' : ''}/><span><b>Tự bật nhạc nền</b><small>Trình duyệt có thể cần chạm một lần để cho phép phát.</small></span></label></div></div>
          ${musicLibraryMarkup()}
        </section>
      </div>
      <aside class="panel settings-about settings-about-pro"><div class="panel-heading"><div><small class="eyebrow">THƯƠNG HIỆU</small><h2>Cờ Vua ViLa</h2></div>${uiTile('crown','gold','tile-lg')}</div><div class="brand-showcase"><img src="./covua-vila-logo.webp" alt="Logo thương hiệu Cờ Vua" loading="lazy" decoding="async" /></div>
        <div class="settings-status-card"><span>${uiTile('shield','cyan','tile-sm')}</span><div><b>Ưu tiên an toàn cài đặt</b><small>Các giá trị được kiểm tra trước khi lưu. Thay đổi engine áp dụng ở phiên tiếp theo nếu ván đang chạy.</small></div></div>
        <section class="memory-keepsake" aria-labelledby="memoryKeepsakeTitle"><div class="memory-keepsake-heading"><span class="memory-keepsake-icon" aria-hidden="true">♜</span><div><small class="eyebrow">KỶ VẬT HÀNH TRÌNH</small><h3 id="memoryKeepsakeTitle">Dấu mốc Cờ Vua</h3></div></div><img class="memory-keepsake-image" src="./vila-memory-monument.webp" alt="Tượng đài kỷ niệm hành trình xây dựng Cờ Vua" width="1254" height="1254" loading="lazy" decoding="async" /><p>Một kỷ vật lưu lại những ý tưởng, sự kiên trì và niềm vui khi cùng xây dựng dự án.</p></section>
        <div class="license-note"><b>Giấy phép</b><p>chess.js theo BSD-2-Clause. Stockfish theo GPL-3.0; giữ thông báo bản quyền và giấy phép engine khi phân phối.</p></div>
      </aside>
    </div>
  </section>`;
}
function wireCommonActions() {
  // Global navigation listeners are attached once during boot; the views below are re-rendered.
}
function openMatchSetup(confirmed = false) {
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi thiết lập trận mới.'); return; }
  const liveGame = gameStarted && !game.isGameOver() && !clockFlagged && !manualGameResult;
  if (liveGame && game.history().length && confirmed !== true) { showBrandedConfirm({ title: 'Kết thúc ván hiện tại?', subtitle: 'Thiết lập trận mới sẽ dừng ván đang chơi. Lịch sử ván được giữ để xem lại nếu đã lưu.', confirmLabel: 'Thiết lập ván mới', onConfirm: () => openMatchSetup(true) }); return; }
  closeResultModal();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  queuedMainEngineMove = false;
  botThinking = false;
  premoveQueue = [];
  selected = null;
  selectedTargets = [];
  if (mode === 'lichess') stopOnlineStream();
  stopClock();
  gameStarted = false;
  setView('play');
  window.scrollTo(0, 0);
}

function startGameFromSetup() {
  unlockBoardSound();
  const selectedMode = $('#modeSelect')?.value || mode;
    if (selectedMode === 'lichess') {
    if (!activeOnlineGame?.id) {
      toast('Hãy kết nối Lichess và tạo ván trực tuyến trước.');
      setView('lichess');
      return;
    }
    mode = 'lichess';
    startOnlinePlay();
    return;
  }
  playGameSound('start', settings.soundEnabled);
  mode = selectedMode;
  colorChoice = $('#colorSelect')?.value || 'w';
  humanColor = colorChoice === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : colorChoice === 'b' ? 'b' : 'w';
  orientation = humanColor;
  freshGame();
}

function wirePlayActions() {
  wireAnnotationWidget();
  wireVirtualMouse();
  // Match room: back to setup, slide-up menu with tabs (moves / analysis / setup / other pages).
  const setMatchSheet = open => {
    document.body.classList.toggle('match-sheet-open', open);
    $('#openMatchMenu')?.setAttribute('aria-expanded', String(open));
    const backdrop = $('#matchSheetBackdrop'); if (backdrop) backdrop.hidden = !open;
    // Avoid stacking the mouse panel on top of the hamburger sheet. Keep the cursor available;
    // the small reopen handle returns after the sheet closes.
    if (open && virtualMouseEnabled && !virtualMouseCollapsed) {
      virtualMouseCollapsed = true;
      syncVirtualMouse();
    } else if (!open && virtualMouseEnabled) {
      syncVirtualMouse();
    }
  };
  const showSheetTab = name => {
    $$('[data-sheet-tab]').forEach(tab => { const on = tab.dataset.sheetTab === name; tab.classList.toggle('is-active', on); tab.setAttribute('aria-selected', String(on)); });
    $$('[data-sheet-pane]').forEach(pane => { pane.hidden = pane.dataset.sheetPane !== name; });
    try { sessionStorage.setItem('vila.sheet-tab', name); } catch {}
    if (name === 'moves') { const ml = $("#moveList"); if (ml) renderMoveList(ml); }
  };
  $('#matchBack')?.addEventListener('click', openMatchSetup);
  $('#openMatchMenu')?.addEventListener('click', () => setMatchSheet(!document.body.classList.contains('match-sheet-open')));
  $('#closeMatchMenu')?.addEventListener('click', () => setMatchSheet(false));
  $('#matchSheetBackdrop')?.addEventListener('click', () => setMatchSheet(false));
  $$('[data-sheet-tab]').forEach(tab => tab.addEventListener('click', () => showSheetTab(tab.dataset.sheetTab)));
  $('#openDrawingTools')?.addEventListener('click', () => {
    showSheetTab('analysis');
    setMatchSheet(true);
    toggleAnnotationToolsDock('menu');
  });
  $('#virtualMouseToolsToggle')?.addEventListener('click', () => toggleAnnotationToolsDock('mouse'));
  $$('.match-page-link').forEach(button => button.addEventListener('click', () => setMatchSheet(false)));
  if ($('[data-sheet-pane]')) showSheetTab((() => { try { return sessionStorage.getItem('vila.sheet-tab') || 'moves'; } catch { return 'moves'; } })());
  $$('[data-experience-choice]').forEach(button => button.addEventListener('click', () => {
    const next = button.dataset.experienceChoice;
    if (!['beginner', 'experienced'].includes(next)) return;
    experienceLevel = next;
    try { localStorage.setItem('vila.chess.experience.v1', JSON.stringify(next)); } catch {}
    if (next === 'beginner') {
      settings.botStrengthMode = 'elo'; settings.botElo = 800; settings.clockPreset = '10+0';
      saveSettings();
    }
    renderView();
    toast(next === 'beginner' ? 'Đã bật lộ trình người mới: bot khoảng Elo 800, Rapid 10+0. Gợi ý chỉ dùng ở chế độ solo.' : 'Đã chọn chế độ người chơi đã biết luật. Bạn có thể tự đổi thời gian và sức mạnh bot.');
  }));
  $('#changeExperience')?.addEventListener('click', () => {
    experienceLevel = '';
    try { localStorage.removeItem('vila.chess.experience.v1'); } catch {}
    renderView();
  });
  $('#randomBotElo')?.addEventListener('click', () => {
    randomBotEloEnabled = !randomBotEloEnabled;
    const button = $('#randomBotElo');
    if (button) { button.setAttribute('aria-pressed', String(randomBotEloEnabled)); button.textContent = `🎲 Elo ngẫu nhiên mỗi ván ${randomBotEloEnabled ? '· Bật' : ''}`; }
    toast(randomBotEloEnabled ? 'Mỗi ván solo Stockfish sẽ chọn Elo ngẫu nhiên từ 500–3200. Đây không phải Elo rank.' : 'Đã tắt Elo ngẫu nhiên; dùng mức bot đã chọn.');
  });
  $$('[data-play-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.playView)));
  $$('[data-play-rail-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.playRailView)));
  $('#clearBoardSelection')?.addEventListener('click', () => {
    const hadSelection = Boolean(selected || premoveQueue.length);
    selected = null; selectedTargets = [];
    if (premoveQueue.length) clearPendingPremove();
    if (currentView === 'play') renderBoard();
    if (hadSelection) toast('Đã hủy lựa chọn nước đi.');
  });
  $('#gameBotProfile')?.addEventListener('change', event => {
    if (botThinking) { event.target.value = settings.alternativeEngine; toast('Đợi bot hoàn tất nước đi trước khi đổi phong cách.'); return; }
    const selectedProfile = OFFLINE_ENGINE_IDS.includes(event.target.value) ? event.target.value : 'ethereal';
    settings.alternativeEngine = selectedProfile;
    saveSettings();
    const turn = game.turn();
    renderView();
    toast(`Đã chọn ${offlineEngineShortName(selectedProfile)} cho các lượt bot tiếp theo.`, 'success');
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && turn !== humanColor && !game.isGameOver()) { botThinking = true; renderView(); scheduleBotMove(220); }
  });
  const modeSelect = $('#modeSelect');
  modeSelect?.addEventListener('change', () => {
    const chosen = modeSelect.value;
    if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi đổi chế độ bàn cờ.'); modeSelect.value = mode; return; }
    if ((mode === 'lichess' && chosen !== 'lichess') || (chosen === 'lichess' && !activeOnlineGame?.id)) stopOnlineStream();
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    if (chosen === 'lichess' && !activeOnlineGame?.id) {
      toast('Kết nối Lichess và tạo ván trước.'); mode = 'stockfish'; modeSelect.value = mode;
    } else {
      const previousMode = mode;
      mode = chosen;
      if (mode === 'stockfish-beginner') {
        if (previousMode !== 'stockfish-beginner') beginnerSettingsBackup = { botStrengthMode: settings.botStrengthMode, botElo: settings.botElo, botSkill: settings.botSkill };
        settings.botStrengthMode = 'elo'; settings.botElo = 500; settings.botSkill = 0; saveSettings();
      } else if (previousMode === 'stockfish-beginner' && beginnerSettingsBackup) {
        // Leaving the 500-Elo trainer must not leave the normal Stockfish stuck at beginner strength.
        Object.assign(settings, beginnerSettingsBackup); beginnerSettingsBackup = null; saveSettings();
      }
      if (mode === 'lichess') {
        gameEpoch += 1; queuedMainEngineMove = false; botThinking = false;
        resetClock('untimed');
        startOnlinePlay(); return;
      }
      if (previousMode === 'lichess') resetClock(settings.clockPreset);
    }
    gameEpoch += 1; queuedMainEngineMove = false; botThinking = false; premoveQueue = []; selected = null; selectedTargets = [];
    renderView();
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      botThinking = true; renderView();
      scheduleBotMove(220);
    }
  });
  $('#colorSelect')?.addEventListener('change', event => {
    if (mode === 'lichess') { toast('Màu quân trong ván Lichess do Lichess quyết định.'); renderView(); return; }
    cancelScheduledBotMove();
    cancelApiMoveRequest();
    cancelPendingHint();
    cancelMainEngineSearch();
    colorChoice = event.target.value;
    humanColor = colorChoice === 'random' ? (Math.random() < 0.5 ? 'w' : 'b') : colorChoice === 'b' ? 'b' : 'w';
    orientation = humanColor;
    gameEpoch += 1; // Invalidate any engine result calculated for the old player-to-move setup.
    queuedMainEngineMove = false;
    botThinking = false; premoveQueue = []; selected = null; selectedTargets = [];
    renderView();
    if (gameStarted && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor && !game.isGameOver()) {
      botThinking = true;
      renderView();
      scheduleBotMove(220);
    }
  });
  $('#skillSelect')?.addEventListener('change', event => {
    randomBotEloEnabled = false;
    const value = event.target.value;
    if (value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(500, Math.min(3200, Number(value) || 2600)); settings.botSkill = 20; }
    $$('[data-strength-preset]').forEach(button => button.classList.toggle('is-active', (value === 'max' && button.dataset.strengthPreset === 'max') || button.dataset.strengthPreset === value));
    const strengthTitle = $('.strength-selector-copy b');
    if (strengthTitle) strengthTitle.textContent = value === 'max' ? 'Mạnh nhất · không giới hạn' : `Elo ${settings.botElo}`;
    const saved = saveSettings(); toast(saved ? (settings.botStrengthMode === 'max' ? 'Stockfish đang ở sức mạnh tối đa.' : `Đã giới hạn Stockfish ở khoảng Elo luyện tập ${settings.botElo} (mức dưới 1320 dùng Skill Level 0–7 của Stockfish, không phải Elo benchmark).`) : 'Cấu hình có hiệu lực trong phiên này nhưng chưa lưu được.');
  });
  $$('[data-strength-preset]').forEach(button => button.addEventListener('click', () => { const select = $('#skillSelect'); if (!select || button.disabled) return; select.value = button.dataset.strengthPreset; select.dispatchEvent(new Event('change', { bubbles: true })); $$('[data-strength-preset]').forEach(item => item.classList.toggle('is-active', item === button)); const title = $('.strength-selector-copy b'); if (title) title.textContent = select.value === 'max' ? 'Mạnh nhất · không giới hạn' : `Elo ${select.value}`; }));
  $('#newGame')?.addEventListener('click', openMatchSetup);
  $('#redoMove')?.addEventListener('click', redoMove);
  $('#gameShowAnalysis')?.addEventListener('click', () => { toggleAnalysis(); $('#analysisPanel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#gameShowMoves')?.addEventListener('click', () => { $('#moveList')?.closest('.moves-panel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#gameShowSetup')?.addEventListener('click', openMatchSetup);
  $('#gameShowOpening')?.addEventListener('click', () => { $('#queryExplorer')?.click(); $('#explorerResult')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
  $('#resultPlayAgain')?.addEventListener('click', openMatchSetup);
  $('#resignBtn')?.addEventListener('click', resignCurrentGame);
  try { renderOpeningExplorerPanel(); } catch {}

  $('#offerDrawBtn')?.addEventListener('click', offerDrawCurrentGame);
  $('#restartGameBtn')?.addEventListener('click', openMatchSetup);
  $('#startGameOverlay')?.addEventListener('click', startGameFromSetup);
  $('#reviewGameBtn')?.addEventListener('click', startFullGameReview);
  $('#stopReviewBtn')?.addEventListener('click', () => stopFullGameReview(true));
  $('#clockPreset')?.addEventListener('change', event => {
    const nextPreset = parseClockPreset(event.target.value).preset;
    settings.clockPreset = nextPreset;
    saveSettings();
    $$('[data-time-preset]').forEach(button => button.classList.toggle('is-active', button.dataset.timePreset === nextPreset));
    toast(`Đã chọn ${CLOCK_PRESETS.find(item => item.value === nextPreset)?.label || nextPreset}. Đồng hồ áp dụng từ ván mới.`);
  });
  $$('[data-time-preset]').forEach(button => button.addEventListener('click', () => {
    const select = $('#clockPreset');
    if (!select) return;
    const next = parseClockPreset(button.dataset.timePreset).preset;
    select.value = next;
    select.dispatchEvent(new Event('change', { bubbles: true }));
  }));
  $('#newGameSetup')?.addEventListener('click', openMatchSetup);
  $('#undoMove')?.addEventListener('click', undoMove);
  $('#analyzePosition')?.addEventListener('click', toggleAnalysis);
  $('#flipBoard')?.addEventListener('click', () => { orientation = orientation === 'w' ? 'b' : 'w'; renderBoard(); });
  const musicButton = $('#toggleChessMusic');
  if (musicButton) { syncMusicControls(); musicButton.addEventListener('click', toggleChessMusicFromUi); }
  $$('[data-review-step]').forEach(button => button.addEventListener('click', () => {
    const action = button.dataset.reviewStep;
    setReviewReplayPly((ply, last) => action === 'first' ? 0 : action === 'prev' ? ply - 1 : action === 'next' ? ply + 1 : action === 'last' ? last : ply);
  }));
  $('#reviewMoveAnalysis')?.addEventListener('click', event => {
    const row = event.target.closest('[data-review-ply]');
    if (row) setReviewReplayPly(Number(row.dataset.reviewPly));
  });
  updateReviewReplay();
  $('#hintMove')?.addEventListener('click', requestHint);
  $('#analyzeQuickBtn')?.addEventListener('click', () => {
    if (rankedFairPlayLocked()) { rankedFairPlayNotice(); return; }
    const finished = gameStarted && game.history().length > 0 && (game.isGameOver() || clockFlagged || manualGameResult);
    if (finished) { setView('review'); setTimeout(() => startFullGameReview(), 100); return; }
    // Mid-game: open the analysis tab of the match sheet and start the 3-line analysis.
    setMatchSheet(true); showSheetTab('analysis');
    if (!analysisActive) setTimeout(() => $('#analyzePosition')?.click(), 60);
  });
  $('#speakHint')?.addEventListener('click', speakCurrentHint);
  $('#useHint')?.addEventListener('click', applyCurrentHint);
  $('#copyPGN')?.addEventListener('click', () => copyText(game.pgn() || 'Chưa có PGN.'));
  $('#downloadPGN')?.addEventListener('click', downloadPgn);
  $('#reviewDownloadPGN')?.addEventListener('click', downloadPgn);
  $('#explainPosition')?.addEventListener('click', () => { setView('coach'); });
  $('#queryExplorer')?.addEventListener('click', () => queryOpeningExplorer(true));
}
function wireOpeningActions() {
  const update = () => {
    openingPageLimit = 48;
    const filtered = OPENINGS.filter(o => ($('#openingFilter')?.value || 'all') === 'all' || o.family === $('#openingFilter')?.value)
      .filter(o => `${o.name} ${o.eco} ${o.note} ${o.line}`.toLocaleLowerCase().includes(String($('#openingSearch')?.value || '').trim().toLocaleLowerCase()));
    if ($('#openingCount')) $('#openingCount').textContent = `${filtered.length.toLocaleString()} đường khai cuộc`;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  };
  $('#openingSearch')?.addEventListener('input', update);
  $('#openingFilter')?.addEventListener('change', update);
  wireOpeningButtons();
}
function wireOpeningButtons() {
  $$('[data-load-opening]').forEach(button => button.addEventListener('click', () => loadOpening(Number(button.dataset.loadOpening))));
  $('#loadMoreOpenings')?.addEventListener('click', () => {
    openingPageLimit += 48;
    if ($('#openingGrid')) $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', $('#openingFilter')?.value || 'all');
    wireOpeningButtons();
  });
}
function loadOpening(index) {
  const opening = OPENINGS[index];
  if (!opening) return;
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi nạp khai cuộc.'); return; }
  if (!Array.isArray(opening.san) || opening.san.length === 0) {
    toast(`Biến ${opening.name || 'khai cuộc'} chưa có danh sách nước đi hợp lệ. Ván hiện tại vẫn được giữ nguyên.`);
    return;
  }

  // Validate the whole line on a temporary board before touching the active game.
  // A malformed catalogue item must never leave the player with a partial opening.
  const candidateGame = new Chess();
  for (let ply = 0; ply < opening.san.length; ply += 1) {
    const san = opening.san[ply];
    try {
      candidateGame.move(san);
    } catch (error) {
      console.error('Rejected invalid opening line:', opening.name, `ply ${ply + 1}`, san, error);
      toast(`Biến ${opening.name} có nước không hợp lệ (${san}). Ván hiện tại vẫn được giữ nguyên.`);
      return;
    }
  }

  historyRestoreSignature = ''; reviewReplayState = null;
  if (mode === 'lichess') stopOnlineStream();
  cancelScheduledBotMove();
  cancelApiMoveRequest();
  cancelPendingHint();
  stopFullGameReview(false);
  stopAnalysis(true);
  cancelMainEngineSearch();
  gameEpoch += 1;
  gameStarted = true;
  game = candidateGame;
  moveClockSnapshots = []; redoStack = [];
  gameStartFen = new Chess().fen();
  manualGameResult = null;
  completedReviewRows = []; reviewStatus = '';
  currentOpening = opening.name;
  lastHintMove = null;
  mode = 'local';
  selected = null; selectedTargets = []; lastMove = null; humanColor = 'w'; orientation = 'w'; botThinking = false;
  resetClock(settings.clockPreset);
  setView('play');
  toast(`Đã nạp biến mẫu: ${opening.name}. Bạn có thể tiếp tục nước đi từ thế cờ này.`, 'success');
}
function wireCoachActions() {
  $('#copyFen')?.addEventListener('click', () => copyText(game.fen()));
  $('#copyPgnCoach')?.addEventListener('click', () => copyText(game.pgn() || ''));
  $('#coachOnlineExplorer')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    const box = $('#coachOnlineExplorerResults');
    if (!button || !box) return;
    const expectedFen = game.fen();
    const moves = game.history({ verbose: true }).map(uciForMove).slice(-80).join(',');
    button.disabled = true; button.textContent = 'Đang tra Lichess…';
    box.innerHTML = '<div class="explorer-loading">Đang tải thống kê theo thế cờ…</div>';
    try {
      const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`, { timeoutMs: 18000 });
      if (expectedFen !== game.fen() || currentView !== 'coach') return;
      const rows = (Array.isArray(data?.moves) ? data.moves : []).slice(0, 8).filter(item => item && /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(String(item.uci || '')));
      box.innerHTML = rows.length ? `<div class="coach-online-move-list">${rows.map(item => { const white = Math.max(0, Number(item.white) || 0); const draws = Math.max(0, Number(item.draws) || 0); const black = Math.max(0, Number(item.black) || 0); const total = white + draws + black; const label = typeof item.san === 'string' ? item.san : item.uci; return `<div class="coach-online-move"><b>${esc(label)}</b><span>${total.toLocaleString('vi-VN')} ván mẫu</span><small>Trắng ${white.toLocaleString('vi-VN')} · Hòa ${draws.toLocaleString('vi-VN')} · Đen ${black.toLocaleString('vi-VN')}</small></div>`; }).join('')}</div><small class="field-hint">Thống kê từ cơ sở dữ liệu mở; số lượng mẫu không chứng minh nước đi là tốt nhất.</small>` : '<div class="empty-state small-empty">Không có thống kê cho thế cờ này hoặc backend chưa cung cấp dữ liệu.</div>';
    } catch (error) {
      if (expectedFen === game.fen() && currentView === 'coach') box.innerHTML = `<div class="empty-state small-empty">Không tải được dữ liệu online: ${esc(error?.message || 'lỗi mạng')}.</div>`;
    } finally {
      if (currentView === 'coach') { button.disabled = false; button.textContent = 'Tra nước phổ biến trong thế này'; }
    }
  });
  $('#coachAnalyzePosition')?.addEventListener('click', () => { setView('play'); toggleAnalysis(); });
  $('#coachReviewGame')?.addEventListener('click', () => {
    if (gameStarted && (game.isGameOver() || clockFlagged || manualGameResult)) { setView('review'); setTimeout(() => startFullGameReview(), 100); }
    else { setView('play'); startFullGameReview(); }
  });
  $('#coachOpenPuzzles')?.addEventListener('click', () => setView('puzzles'));
  $('#coachOpenOpenings')?.addEventListener('click', () => setView('openings'));
}
function wireSettingsActions() {
  $('#pieceStyleSetting')?.addEventListener('change', event => { setPieceStyle(event.target.value); renderView(); });
  $('#boardThemeSetting')?.addEventListener('change', event => { if (selectBoardTheme(event.target.value)) toast('Đã áp dụng bàn cờ mới cho mọi chế độ.', 'success'); });
  for (const [id, key] of [
    ['showLegalMovesSetting','showLegalMoves'], ['highlightLastMoveSetting','highlightLastMove'],
    ['smoothAnimationsSetting','smoothAnimations'], ['autoQueenSetting','autoQueen'],
    ['announceMovesSetting','announceMoves'], ['showCoordinatesSetting','showCoordinates'],
    ['premoveEnabledSetting','premoveEnabled'], ['showCapturedMaterialSetting','showCapturedMaterial'],
    ['confirmResignSetting','confirmResign']
  ]) {
    $(`#${id}`)?.addEventListener('change', event => {
      visualSettings = saveVisualSettings({ ...visualSettings, [key]: Boolean(event.target.checked) });
      if (key === 'premoveEnabled' && !visualSettings.premoveEnabled) { premoveQueue = []; premoveViewCache = { key: '', chess: null }; if (currentView === 'play') renderBoard(); }
      if (key === 'showCoordinates' || key === 'showCapturedMaterial') {
        if (currentView === 'arena' || currentView === 'ranked' || currentView === 'puzzles') rerenderKeepingScroll();
      }
    });
  }
  wireYoutubeMusicControls();
  $('#musicAutostartSetting')?.addEventListener('change', event => {
    musicAutostart = Boolean(event.target.checked);
    try { localStorage.setItem(MUSIC_AUTOSTART_KEY, String(musicAutostart)); } catch {}
    musicAutostartHandled = false;
    toast(musicAutostart ? 'Lần mở app sau nhạc sẽ tự phát.' : 'Đã tắt tự phát nhạc nền.');
  });
  
  $('#boardThemeSwatches')?.addEventListener('click', event => {
    const btn = event.target.closest('[data-board-theme]');
    if (!btn) return;
    const id = btn.getAttribute('data-board-theme');
    document.documentElement.dataset.boardTheme = id;
    try { localStorage.setItem('vila.chess.board-theme.v1', id); } catch {}
    renderView();
  });
  $('#soundEnabledSetting')?.addEventListener('change', event => {
    settings.soundEnabled = Boolean(event.target.checked);
    saveSettings();
  });
  $('#settingsSoundTheme')?.addEventListener('change', event => {
    settings.soundTheme = ['soft', 'wood', 'neon', 'mute'].includes(event.target.value) ? event.target.value : 'soft';
    saveSettings();
    toast(`Đã chọn âm thanh: ${SOUND_THEME_CATALOG.find(item => item.id === settings.soundTheme)?.label || 'Êm'}.`, 'success');
  });
  $('#settingsBotStrength')?.addEventListener('change', event => {
    if (event.target.value === 'max') { settings.botStrengthMode = 'max'; settings.botSkill = 20; }
    else { settings.botStrengthMode = 'elo'; settings.botElo = Math.max(500, Math.min(3200, Number(event.target.value) || 2600)); settings.botSkill = 20; }
    saveSettings();
    toast(settings.botStrengthMode === 'max' ? 'Mặc định bot đã đặt ở sức mạnh tối đa.' : `Mặc định bot: Elo luyện tập ${settings.botElo}.`, 'success');
  });
  $('#settingsBotEngine')?.addEventListener('change', event => {
    settings.botEngine = event.target.value;
    settings.botEnginePreferenceSet = true;
    saveSettings();
    toast('Đã lưu engine ưu tiên cho các ván mới.', 'success');
  });
  $('#settingsBotDepth')?.addEventListener('change', event => {
    settings.botDepth = Math.max(5, Math.min(30, Number(event.target.value) || DEFAULTS.botDepth));
    settings.botSearchSettingsPreferenceSet = true;
    saveSettings();
    toast(`Độ sâu tìm kiếm mặc định: ${settings.botDepth} ply.`, 'success');
  });
  $('#settingsBotMoveTime')?.addEventListener('change', event => {
    settings.botMoveTimeMs = Math.max(500, Math.min(5000, Number(event.target.value) || DEFAULTS.botMoveTimeMs));
    settings.botSearchSettingsPreferenceSet = true;
    saveSettings();
    toast(`Thời gian nghĩ mặc định: ${(settings.botMoveTimeMs / 1000).toFixed(1)} giây/nước.`, 'success');
  });
  $('#settingsReviewQuality')?.addEventListener('change', event => {
    settings.reviewQuality = ['fast', 'standard', 'deep', 'max'].includes(event.target.value) ? event.target.value : 'fast';
    settings.reviewQualityPreferenceSet = true;
    saveSettings();
    toast('Đã lưu chất lượng phân tích sau ván.', 'success');
  });
  $('#settingsClockPreset')?.addEventListener('change', event => {
    const parsed = parseClockPreset(event.target.value);
    settings.clockPreset = parsed.preset;
    saveSettings();
    toast(`Đồng hồ mặc định cho ván mới: ${CLOCK_PRESETS.find(item => item.value === parsed.preset)?.label || parsed.preset}.`, 'success');
  });
  $('#settingsOpeningBook')?.addEventListener('change', event => {
    settings.openingBookEnabled = Boolean(event.target.checked);
    saveSettings();
    toast(settings.openingBookEnabled ? 'Đã bật kho khai cuộc.' : 'Đã tắt nước khai cuộc từ sách; nhận diện vẫn dùng danh mục đã nạp.', 'success');
  });
  wireAccountSettings();
}
function rerenderKeepingScroll() { const y = window.scrollY; renderView(); window.scrollTo(0, y); }
function wireAccountSettings() {
  const say = (message, ok = true) => {
    const result = $('#accountResult'); // re-query: the view may have been re-rendered since
    if (result) { result.textContent = message; result.className = `connection-result ${ok ? 'success-result' : 'error-result'}`; }
    else toast(message, ok ? 'success' : undefined);
  };
  const failWith = error => {
    // Only a rejected session (401 / locked account) signs the player out; wrong-password errors stay inline.
    if (isSessionRejected(error) && socialState.token) { socialHandleError(error); return; }
    say(String(error?.message || 'Không thể kết nối máy chủ. Hãy thử lại.'), false);
  };
  const busy = (form, on) => form?.querySelectorAll('button').forEach(button => { button.disabled = on; });
  $('#accountLogin')?.addEventListener('click', () => showAccountGate('login'));
  $('#accountLogout')?.addEventListener('click', () => {
    socialApi('/auth/logout', { method: 'POST', body: '{}' }).catch(() => {});
    saveSocialSession('', null);
    socialState.friends = []; socialState.incoming = []; socialState.outgoing = [];
    showAccountGate('login', 'Bạn đã đăng xuất khỏi tài khoản VILA.');
  });
  $('#accountNameForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const displayName = String($('#accountDisplayName')?.value || '').trim();
    if (displayName.length < 2) { say('Tên hiển thị cần ít nhất 2 ký tự.', false); return; }
    if (displayName === (socialState.user?.displayName || '')) { say('Tên hiển thị không thay đổi.'); return; }
    busy(form, true);
    try {
      // /profile also stores the bio, so send the current one back instead of clearing it.
      const data = await socialApi('/profile', { method: 'PATCH', body: JSON.stringify({ displayName, bio: socialState.user?.bio || '' }) });
      saveSocialSession(socialState.token, data.user);
      rerenderKeepingScroll();
      say('Đã đổi tên hiển thị.');
    } catch (error) { failWith(error); } finally { busy(form, false); }
  });
  const submitEmail = async (event, remove = false) => {
    event?.preventDefault?.();
    const form = $('#accountEmailForm');
    const email = remove ? '' : String($('#accountEmail')?.value || '').trim().toLowerCase();
    const password = String($('#accountEmailPassword')?.value || '');
    if (!password) { say('Hãy nhập mật khẩu hiện tại để xác nhận.', false); return; }
    if (!remove && !email) { say('Hãy nhập địa chỉ email.', false); return; }
    if (!remove && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { say('Email không hợp lệ.', false); return; }
    busy(form, true);
    try {
      const data = await socialApi('/account/email', { method: 'PATCH', body: JSON.stringify({ email, password }) });
      saveSocialSession(socialState.token, data.user);
      rerenderKeepingScroll();
      say(remove ? 'Đã gỡ email khỏi tài khoản.' : 'Đã liên kết email. Bạn có thể dùng email này để đăng nhập.');
    } catch (error) { failWith(error); } finally { busy(form, false); }
  };
  $('#accountEmailForm')?.addEventListener('submit', event => submitEmail(event, false));
  $('#accountEmailRemove')?.addEventListener('click', () => submitEmail(null, true));
  $('#accountPasswordForm')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const currentPassword = String($('#accountCurrentPassword')?.value || '');
    const newPassword = String($('#accountNewPassword')?.value || '');
    const confirmPassword = String($('#accountConfirmPassword')?.value || '');
    if (newPassword.length < 8) { say('Mật khẩu mới cần ít nhất 8 ký tự.', false); return; }
    if (newPassword !== confirmPassword) { say('Mật khẩu nhập lại không khớp.', false); return; }
    if (newPassword === currentPassword) { say('Mật khẩu mới phải khác mật khẩu hiện tại.', false); return; }
    busy(form, true);
    try {
      const data = await socialApi('/account/password', { method: 'PATCH', body: JSON.stringify({ currentPassword, newPassword }) });
      // The server revokes older tokens; keep this device signed in with the fresh one.
      saveSocialSession(data.token || socialState.token, data.user || socialState.user);
      form.reset();
      say('Đã đổi mật khẩu. Các thiết bị khác đã được đăng xuất.');
    } catch (error) { failWith(error); } finally { busy(form, false); }
  });
}
function wireLichessActions() {
  $('#connectLichess')?.addEventListener('click', connectLichess);
  $('#playLichessHere')?.addEventListener('click', startOnlinePlay);
  $('#forgetLichess')?.addEventListener('click', () => {
    // Revoke the app's local session immediately: abort any stream using the
    // token and invalidate the active game before clearing the stored values.
    stopOnlineStream();
    activeLichessToken = '';
    activeLichessUsername = '';
    activeOnlineGame = null;
    safeSessionRemove(lichessTokenKey);
    safeSessionRemove('tubor.chess.lichessUsername');
    if (mode === 'lichess') {
      mode = 'stockfish';
      gameEpoch += 1;
      botThinking = false;
      cancelScheduledBotMove();
      cancelPendingHint();
      cancelMainEngineSearch();
    }
    if ($('#lichessToken')) $('#lichessToken').value = '';
    const result = $('#lichessAccountResult');
    if (result) result.textContent = 'Đã xóa token và ngắt kết nối Lichess khỏi phiên hiện tại.';
    if (currentView === 'play') renderView();
  });
  $('#challengeLichessAI')?.addEventListener('click', challengeLichessAI);
  $('#challengeLichessUser')?.addEventListener('click', challengeLichessUser);
}
async function connectLichess() {
  const token = getLichessToken();
  if (!token) { toast('Hãy nhập Lichess personal access token.'); return; }
  activeLichessToken = token;
  const persisted = safeSessionSet(lichessTokenKey, token);
  const result = $('#lichessAccountResult'); result.textContent = 'Đang xác thực token…';
  try {
    const account = await apiFetch('/api/lichess/account', { method: 'POST', body: JSON.stringify({ token }) });
    activeLichessUsername = account.username || '';
    safeSessionSet('tubor.chess.lichessUsername', activeLichessUsername);
    result.textContent = `Đã kết nối: ${account.username}${account.title ? ` (${account.title})` : ''}${persisted ? '' : ' · token chỉ được giữ trong phiên hiện tại'}`;
    result.className = 'connection-result success-result';
  } catch (error) { result.textContent = `Kết nối thất bại: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessAI() {
  const token = getLichessToken();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang tạo thử thách AI…';
  try {
    const data = await apiFetch('/api/lichess/challenge-ai', { method: 'POST', body: JSON.stringify({ token, level: Number($('#lichessLevel').value), clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã tạo thử thách. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a> <button id="playLichessChallenge" class="mini-primary">Chơi trong Cờ Vua</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Ván vừa tạo: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở ván trên Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không tạo được thử thách: ${error.message}`; result.className = 'connection-result error-result'; }
}
async function challengeLichessUser() {
  const token = getLichessToken();
  const username = $('#lichessUsername').value.trim();
  const result = $('#lichessChallengeResult');
  if (!token) { result.textContent = 'Hãy nhập token Lichess trước.'; result.className = 'connection-result error-result'; return; }
  if (!username) { result.textContent = 'Hãy nhập tên người chơi muốn thách đấu.'; result.className = 'connection-result error-result'; return; }
  activeLichessToken = token;
  safeSessionSet(lichessTokenKey, token);
  result.textContent = 'Đang gửi lời mời…';
  try {
    const data = await apiFetch('/api/lichess/challenge-user', { method: 'POST', body: JSON.stringify({ token, username, clockLimit: Number($('#lichessClock').value), clockIncrement: 0, color: 'random' }) });
    activeOnlineGame = { ...data, apiMode: 'board', opponent: username, username: activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '' };
    const lichessUrl = safeLichessUrl(data.url, data.id);
    result.innerHTML = `Đã gửi lời mời. <a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở lời mời ↗</a> <button id="playLichessChallenge" class="mini-primary">Kết nối ván trong Cờ Vua</button>`;
    $('#playLichessChallenge')?.addEventListener('click', startOnlinePlay);
    result.className = 'connection-result success-result';
    $('#lichessActiveGame').innerHTML = `Lời mời: <b>${esc(data.id || '')}</b><br><a href="${esc(lichessUrl)}" target="_blank" rel="noopener noreferrer">Mở Lichess ↗</a>`;
  } catch (error) { result.textContent = `Không gửi được lời mời: ${error.message}`; result.className = 'connection-result error-result'; }
}

async function requestHint() {
  if (rankedFairPlayLocked()) { rankedFairPlayNotice(); return; }
  if (!gameStarted) { toast('Bắt đầu ván trước khi yêu cầu gợi ý.'); return; }
  if (arenaRunning) { toast('Hãy dừng Đấu trường AI trước khi dùng gợi ý.'); return; }
  if (botThinking) { toast('Đợi bot đi xong rồi hãy xin gợi ý.'); return; }
  if (game.isGameOver()) { toast('Ván cờ đã kết thúc.'); return; }
  if (engineWorker && engineReady && !engineFailed) {
    if (engineStopPending || engineSearchActive || pendingEngineRequest || pendingHintRequest || pendingCoachAnalysis || analysisActive) {
      toast('Stockfish đang xử lý yêu cầu khác; chờ xong rồi thử lại.');
      return;
    }
    const legal = game.moves({ verbose: true });
    if (!legal.length) return;
    cancelMainEngineWatchdog();
    const request = { fen: game.fen(), epoch: gameEpoch, legal, timeout: null };
    request.timeout = setTimeout(() => {
      if (pendingHintRequest !== request) return;
      pendingHintRequest = null;
      engineSearchActive = false;
      const shouldResumeBot = queuedMainEngineMove && botThinking && ['stockfish', 'stockfish-beginner'].includes(mode) && !game.isGameOver() && game.turn() !== humanColor;
      retireStockfishWorker('Stockfish không phản hồi gợi ý kịp thời.');
      if ($('#boardStatus')) $('#boardStatus').textContent = positionStatus();
      toast('Stockfish chưa phản hồi gợi ý kịp thời; đã dừng engine để tránh kết quả cũ. Chạm trạng thái engine để thử lại.');
      if (shouldResumeBot) { queuedMainEngineMove = false; scheduleBotMove(0); }
    }, 30000);
    pendingHintRequest = request;
    engineSearchActive = true;
    configureStockfishForAnalysis(1);
    engineWorker.postMessage(`position fen ${request.fen}`);
    engineWorker.postMessage(`go movetime ${Math.max(700, Math.min(5000, Number(settings.analysisMoveTimeMs) || 2600))}`);
    return;
  }
  const move = chooseFallbackMove();
  if (move) setHintSuggestion(move, 'Dự phòng nhanh');
  toast(move ? `Gợi ý nhanh: ${move.san}. Đây là gợi ý dự phòng, không phải phân tích Stockfish.` : 'Không có nước đi hợp lệ.');
}

async function queryOpeningExplorer(showToast = true) {
  const requestId = ++explorerRequestId;
  const expectedFen = game.fen();
  const box = $('#explorerResult');
  if (box) box.innerHTML = '<div class="explorer-loading">Đang tra Opening Explorer…</div>';
  try {
    const moves = chessUciHistory();
    const data = await apiFetch(`/api/openings/explorer?moves=${encodeURIComponent(moves)}`);
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    lastExplorerData = data;
    const topMoves = Array.isArray(data?.moves) ? data.moves.slice(0, 4) : [];
    if (box) {
      const rows = topMoves.filter(m => m && typeof m === 'object').map(m => {
        const white = Math.max(0, Number(m.white) || 0);
        const draws = Math.max(0, Number(m.draws) || 0);
        const black = Math.max(0, Number(m.black) || 0);
        const total = white + draws + black;
        const pct = total ? Math.round(100 * white / total) : 0;
        const label = typeof m.san === 'string' ? m.san : typeof m.uci === 'string' ? m.uci : '';
        if (!label) return '';
        return `<div class="explorer-move"><b>${esc(label)}</b><span>${total.toLocaleString('vi-VN')} ván</span><small>Trắng thắng ${pct}%</small></div>`;
      }).filter(Boolean);
      box.innerHTML = rows.length ? `<div class="explorer-title">Nước phổ biến ở thế này</div>${rows.join('')}` : '<div class="empty-state small-empty">Chưa có thống kê cho thế cờ này.</div>';
    }
    if (showToast) toast(topMoves.length ? 'Đã tải dữ liệu khai cuộc từ Lichess.' : 'Không có dữ liệu khai cuộc ở thế này.');
  } catch (error) {
    if (requestId !== explorerRequestId || expectedFen !== game.fen()) return;
    if (box) box.innerHTML = `<div class="empty-state small-empty">Chưa tra được: ${esc(error.message)}. Kiểm tra backend hoặc internet.</div>`;
    if (showToast) toast(`Không tra được khai cuộc: ${error.message}`);
  }
}
async function startOnlinePlay() {
  const token = getLichessToken();
  if (!activeOnlineGame?.id || !token) { toast('Cần có ván Lichess và token đã kết nối.'); setView('lichess'); return; }
  historyRestoreSignature = ''; reviewReplayState = null;
  activeLichessToken = token;
  activeOnlineGame.apiMode = $('#lichessApiMode')?.value || activeOnlineGame.apiMode || 'board';
  activeOnlineGame.username = activeLichessUsername || safeSessionGet('tubor.chess.lichessUsername') || '';
  mode = 'lichess';
  humanColor = activeOnlineGame.color === 'black' ? 'b' : activeOnlineGame.color === 'white' ? 'w' : 'w';
  orientation = humanColor;
  game = new Chess(); moveClockSnapshots = []; redoStack = []; gameStartFen = game.fen(); gameStarted = true; selected = null; selectedTargets = []; lastMove = null; botThinking = false;
  setView('play');
  toast('Đang kết nối luồng ván Lichess…');
  listenOnlineGame();
}
async function submitLichessMove(uci) {
  if (!activeOnlineGame?.id) { toast('Chưa có mã ván Lichess.'); return; }
  const token = getLichessToken();
  try {
    await apiFetch('/api/lichess/move', { method: 'POST', body: JSON.stringify({ token, gameId: activeOnlineGame.id, move: uci, apiMode: activeOnlineGame.apiMode || 'board' }) });
  } catch (error) {
    toast(`Lichess từ chối nước ${uci}: ${error.message}`);
    listenOnlineGame();
  }
}
async function listenOnlineGame() {
  stopOnlineStream();
  const token = getLichessToken();
  const streamGameId = String(activeOnlineGame?.id || '');
  if (!streamGameId || !token) return;
  const controller = new AbortController();
  onlineStreamController = controller;
  const isCurrentStream = () => !controller.signal.aborted && activeOnlineGame?.id === streamGameId && onlineStreamController === controller;
  try {
    const response = await fetch(apiUrl('/api/lichess/stream'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...backendAuthorizationHeaders() },
      body: JSON.stringify({ token, gameId: streamGameId, apiMode: activeOnlineGame.apiMode || 'board' }),
      signal: controller.signal
    });
    if (!isCurrentStream()) return;
    if (!response.ok || !response.body) {
      const message = await response.text().catch(() => 'Không mở được luồng ván.');
      throw new Error(message.slice(0, 300));
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    const handleStreamLine = line => {
      const trimmed = line.trim();
      if (!trimmed || !isCurrentStream()) return;
      try { processLichessEvent(JSON.parse(trimmed)); }
      catch (error) { console.warn('Lichess event parse:', error); }
    };
    while (isCurrentStream()) {
      const { value, done } = await reader.read();
      if (!isCurrentStream()) break;
      if (done) {
        pending += decoder.decode();
        if (pending.trim()) handleStreamLine(pending);
        pending = '';
        break;
      }
      pending += decoder.decode(value, { stream: true });
      const lines = pending.split('\n');
      pending = lines.pop() || '';
      for (const line of lines) {
        if (!isCurrentStream()) break;
        handleStreamLine(line);
      }
    }
  } catch (error) {
    if (isCurrentStream() && error?.name !== 'AbortError') toast(`Luồng Lichess bị ngắt: ${error.message}`);
  } finally {
    if (onlineStreamController === controller) onlineStreamController = null;
  }
}
function processLichessEvent(event) {
  if (!event || typeof event !== 'object') return;
  if (event.type === 'gameFull') {
    activeOnlineGame.initialFen = event.initialFen && event.initialFen !== 'startpos' ? event.initialFen : null;
    const whiteName = event.white?.name || event.white?.id || '';
    const blackName = event.black?.name || event.black?.id || '';
    if (activeOnlineGame.username && whiteName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'w';
    else if (activeOnlineGame.username && blackName.toLowerCase() === activeOnlineGame.username.toLowerCase()) humanColor = 'b';
    else if (event.color === 'black' || event.color === 'white') humanColor = event.color === 'black' ? 'b' : 'w';
    orientation = humanColor;
    syncLichessMoveList(event.state?.moves || '');
    if (currentView === 'play') renderView();
  } else if (event.type === 'gameState') {
    syncLichessMoveList(event.moves || '');
    if (event.status && event.status !== 'started') toast(`Ván Lichess kết thúc: ${event.status}.`, 'success');
    if (currentView === 'play') renderView();
  } else if (event.type === 'chatLine') {
    console.info('[Lichess chat]', event.username, event.text);
  }
}
function syncLichessMoveList(movesText) {
  const replay = activeOnlineGame?.initialFen ? new Chess(activeOnlineGame.initialFen) : new Chess();
  for (const uci of String(movesText || '').split(/\s+/).filter(Boolean)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(uci)) continue;
    try { replay.move({ from: uci.slice(0,2), to: uci.slice(2,4), ...(uci[4] ? { promotion: uci[4] } : {}) }); }
    catch { break; }
  }
  game = replay;
  gameEpoch += 1;
  const history = game.history({ verbose: true });
  const last = history[history.length - 1];
  lastMove = last ? { from: last.from, to: last.to } : null;
  selected = null; selectedTargets = [];
}

async function copyText(value) {
  const text = String(value ?? '');
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      toast('Đã sao chép.', 'success');
      return true;
    }
  } catch { /* Try the legacy selection API below for older WebViews. */ }
  let textarea;
  try {
    textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    const ok = Boolean(document.execCommand?.('copy'));
    toast(ok ? 'Đã sao chép.' : 'Không sao chép được trên trình duyệt này.');
    return ok;
  } catch {
    toast('Không sao chép được trên trình duyệt này.');
    return false;
  } finally {
    textarea?.remove();
  }
}
function downloadTextFile(contents, filename, mimeType) {
  let url;
  let link;
  try {
    url = URL.createObjectURL(new Blob([contents], { type: mimeType }));
    link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    return true;
  } catch (error) {
    toast(`Không tạo được tệp tải xuống: ${error.message || error}`);
    return false;
  } finally {
    link?.remove();
    if (url) setTimeout(() => URL.revokeObjectURL(url), 1500);
  }
}
function gamePgnWithResult() {
  const result = getGameResult().token;
  const raw = (game.pgn() || '').trim();
  // chess.js may return a complete PGN after a saved game has been loaded.
  // Strip its prior header block, then write one canonical, current header set.
  let moveText = raw;
  const hasPgnHeaders = /^\[[A-Za-z0-9_]+\s+\"/.test(raw);
  const blankLine = hasPgnHeaders ? raw.indexOf('\n\n') : -1;
  if (blankLine >= 0) moveText = raw.slice(blankLine + 2).trim();
  else moveText = raw.replace(/^(?:\s*\[[^\]\r\n]*\]\s*)+/, '').trim();
  moveText = moveText.replace(/(?:1-0|0-1|1\/2-1\/2|\*)\s*$/, '').trim();

  const whiteName = mode === 'local' ? 'White' : (humanColor === 'w' ? 'Player' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish'));
  const blackName = mode === 'local' ? 'Black' : (humanColor === 'b' ? 'Player' : (mode === 'vila' ? 'ViLa Classic' : mode === 'enginehub' ? offlineEngineShortName(settings.alternativeEngine) : 'Stockfish'));
  const defaultFen = new Chess().fen();
  const setupHeaders = gameStartFen && gameStartFen !== defaultFen
    ? `\n[SetUp "1"]\n[FEN "${pgnEscape(gameStartFen)}"]`
    : '';
  const terminationHeader = manualGameResult?.reason
    ? `\n[Termination "${pgnEscape(manualGameResult.reason)}"]`
    : '';
  const headers = `[Event "Cờ Vua"]\n[Site "Cờ Vua"]\n[White "${pgnEscape(whiteName)}"]\n[Black "${pgnEscape(blackName)}"]\n[Result "${result}"]${setupHeaders}${terminationHeader}`;
  return `${headers}\n\n${moveText || result}${moveText ? ` ${result}` : ''}`;
}
function downloadPgn() {
  downloadTextFile(gamePgnWithResult(), 'covua-vila-game.pgn', 'application/x-chess-pgn;charset=utf-8');
}

function stopOnlineStream() {
  if (onlineStreamController) { onlineStreamController.abort(); onlineStreamController = null; }
}

// Re-measure against the actual WebView viewport on rotation, split-screen, or inset changes.
window.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });
window.addEventListener('orientationchange', scheduleBoardLayoutSync, { passive: true });
window.visualViewport?.addEventListener('resize', scheduleBoardLayoutSync, { passive: true });

async function loadExternalOpeningCatalog() {
  if (openingCatalogLoadPromise) return openingCatalogLoadPromise;
  openingCatalogLoadPromise = (async () => {
    try {
      const response = await fetch('./openings-eco.json', { cache: 'force-cache' });
      if (!response.ok) throw new Error(`HTTP ${response.status} loading openings-eco.json`);
      const payload = await response.json();
      const entries = Array.isArray(payload) ? payload : payload?.openings;
      if (!Array.isArray(entries) || !entries.length) {
        if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Kho khai cuộc chưa đầy đủ', message: `Ứng dụng đang có ${OPENINGS.length.toLocaleString()} biến mẫu, chưa đạt yêu cầu ${REQUIRED_OPENING_COUNT.toLocaleString()}. Cần build lại với dữ liệu ECO hợp lệ; không xóa kho đang có.`, type: 'error', sourceKey: 'opening-catalog:missing-full-data' });
        if (currentView === 'health') renderView();
        return 0;
      }
      const additions = mergeOpeningEntries(OPENINGS, entries, 5000);
      if (additions.length) {
        OPENINGS.push(...additions);
        console.info(`[Cờ Vua] Loaded ${additions.length} additional ECO openings; total ${OPENINGS.length}.`);
      } else {
        console.info('[Cờ Vua] The bundled ECO file contains no new move lines; keeping the curated book already loaded in the app.');
      }
      // A non-empty JSON file can still be only the curated fallback or contain duplicates.
      // Always report the actual live count instead of silently returning before the readiness check.
      if (OPENINGS.length >= REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Thư viện khai cuộc đã nạp', message: `Đã nạp ${OPENINGS.length.toLocaleString()} biến khai cuộc hợp lệ.`, type: 'success', sourceKey: `opening-catalog:loaded:${OPENINGS.length}` });
      else addAppNotification({ title: 'Kho khai cuộc chưa đủ dữ liệu', message: `Hiện có ${OPENINGS.length.toLocaleString()} biến khai cuộc (kể cả bộ dự phòng); bản phát hành yêu cầu ít nhất ${REQUIRED_OPENING_COUNT.toLocaleString()}. Cần build lại với kho ECO đầy đủ.`, type: 'warning', sourceKey: `opening-catalog:below-threshold:${OPENINGS.length}` });
      const playCount = $('#playOpeningCount');
      if (playCount) playCount.textContent = OPENINGS.length.toLocaleString();
      if (currentView === 'openings' && $('#openingGrid')) {
        openingPageLimit = 48;
        const query = String($('#openingSearch')?.value || '').trim().toLocaleLowerCase();
        const family = $('#openingFilter')?.value || 'all';
        const filteredCount = OPENINGS.filter(item => (family === 'all' || item.family === family) && `${item.name} ${item.eco} ${item.note} ${item.line}`.toLocaleLowerCase().includes(query)).length;
        if ($('#openingCount')) $('#openingCount').textContent = `${filteredCount.toLocaleString()} đường khai cuộc`;
        $('#openingGrid').innerHTML = renderOpeningCards($('#openingSearch')?.value || '', family);
        wireOpeningButtons();
      }
      const label = $('#openingRecognition');
      if (label && currentView === 'play') {
        const found = recognizeOpening(game.history(), OPENINGS, { minPlies: 5 });
        label.textContent = found ? `Khai cuộc nhận diện: ${found.name}` : (game.history().length >= 5 ? 'Chưa khớp biến khai cuộc đã biết' : 'Khai cuộc sẽ được nhận diện sau vài nước');
      }
      if (currentView === 'health') renderView();
      return additions.length;
    } catch (error) {
      console.info('[Cờ Vua] Expanded opening catalog unavailable; curated offline book remains active.', error?.message || error);
      if (OPENINGS.length < REQUIRED_OPENING_COUNT) addAppNotification({ title: 'Không tải được kho khai cuộc mở rộng', message: `Chỉ còn ${OPENINGS.length.toLocaleString()} biến mẫu trên thiết bị. Lỗi nạp dữ liệu: ${String(error?.message || error).slice(0, 220)}`, type: 'error', sourceKey: 'opening-catalog:load-failed' });
      if (currentView === 'health') renderView();
      return 0;
    }
  })();
  return openingCatalogLoadPromise;
}

// Boot
syncSocialNav();
syncInboxBadge();
ensurePieceSprite();
{ const savedYt = parseYoutubeUrl(savedYoutubeMusicUrl()); if (savedYt) setChessMusicYoutube(savedYt, { onFailure: error => toast(`${error?.message || 'YouTube không phát được.'} Đã chuyển về danh sách nhạc của app.`) }); }
window.addEventListener('vila:music-changed', () => refreshMusicLibraryUi());
window.addEventListener('vila:music-error', event => toast(`${event.detail?.message || 'Không tải được nhạc.'} Chạm 🎧 để thử lại khi có mạng.`));
window.addEventListener('vila:youtube-closed', () => { musicAutostartHandled = true; setChessMusicPlaying(false); refreshMusicLibraryUi(); });
// Vào app là có nhạc: Android WebView cho phép tự phát; trình duyệt thì phát ngay ở lần chạm đầu tiên.
if (musicAutostart && (window.AndroidBridge || navigator.userActivation?.hasBeenActive)) { musicAutostartHandled = true; setChessMusicPlaying(true); }
syncMusicControls();
$('#appMusicToggle')?.addEventListener('click', toggleChessMusicFromUi);
document.addEventListener('click', handleMusicAutostartGesture, { capture: true, passive: true }); // click (not pointerdown): the mini player appears after the tap, never under the finger
document.addEventListener('keydown', handleMusicAutostartGesture, { capture: true });
installRankedFairPlayGuards();
setInterval(() => { void pollSocialInbox(); }, 60_000);
if (socialState.token) setTimeout(() => { void pollSocialInbox(); }, 1500);
$$('.tab').forEach(tab => tab.addEventListener('click', () => { if (tab.hidden) return; setView(tab.dataset.view); }));
$('.brand')?.addEventListener('click', event => { event.preventDefault(); setView('home'); });
$('#accountShortcut')?.addEventListener('click', () => { profileTargetUser = null; setView(socialState.user ? 'profile' : 'friends'); });
$('#openInbox')?.addEventListener('click', () => setView('inbox'));
const brandLogo = $('.brand-logo');
brandLogo?.addEventListener('error', () => { brandLogo.hidden = true; const fallback = $('#brandLogoFallback'); if (fallback) fallback.hidden = false; }, { once: true });
if (brandLogo?.complete && brandLogo.naturalWidth === 0) brandLogo.dispatchEvent(new Event('error'));
$('#bottomMore')?.addEventListener('click', () => { $('#openMenu')?.click(); const open = $('#mainMenu')?.classList.contains('menu-open'); $('#bottomMore')?.setAttribute('aria-expanded', String(Boolean(open))); });
$('#openMenu')?.addEventListener('click', () => { const menu = $('#mainMenu'); const open = menu?.classList.toggle('menu-open') ?? false; $('#openMenu')?.setAttribute('aria-expanded', String(open)); $('#bottomMore')?.setAttribute('aria-expanded', String(open)); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && currentView === 'play' && (premoveQueue.length || selected) && !$('#modalRoot')?.children.length) {
    const hadPremoves = clearPendingPremove({ silent: false });
    selected = null; selectedTargets = [];
    if (hadPremoves || currentView === 'play') renderBoard();
    return;
  }
  if (event.key !== 'Escape' || !$('#mainMenu')?.classList.contains('menu-open')) return;
  $('#mainMenu')?.classList.remove('menu-open');
  $('#openMenu')?.setAttribute('aria-expanded', 'false');
  $('#bottomMore')?.setAttribute('aria-expanded', 'false');
  $('#openMenu')?.focus();
});
$('#openSettings')?.addEventListener('click', () => setView('settings'));
$('#engineStatus')?.addEventListener('click', retryStockfishEngine);
window.addEventListener('pagehide', () => {
  if (handMouseStream) stopHandMouse();
  if (virtualMouseHeld) virtualMouseSetHeld(false);
  persistLocalGameRecovery();
  const match = rankedMatchState?.match;
  if (currentView !== 'ranked' || !socialState.token || match?.status !== 'active' || match?.timeCategory === 'daily') return;
  try {
    const base = socialBackendBase();
    void fetch(`${base}/api/social/ranked/matches/${encodeURIComponent(match.id)}/abandon`, {
      method: 'POST', keepalive: true,
      headers: { Authorization: `Bearer ${socialState.token}`, 'Content-Type': 'application/json' },
      body: '{}'
    }).catch(() => {});
  } catch { /* Server-side presence timeout remains the fallback when pagehide cannot reach the backend. */ }
});
resetClock(settings.clockPreset);
ensureClockTicker();
const restoredLocalGame = offerLocalGameRecovery();
showVilaIntro();
renderView();
startIconObserver(document.body);
initializeRequiredAccountGate();
if (restoredLocalGame && ['stockfish', 'stockfish-beginner', 'vila', 'enginehub'].includes(mode) && game.turn() !== humanColor) {
  botThinking = true;
  scheduleBotMove(300);
}
initEngine();
void loadExternalOpeningCatalog();

// Offline support (v3.46.4): cache the app shell and engines so VILA works without a network.
if ('serviceWorker' in navigator && import.meta.env.PROD && /^https?:$/.test(window.location.protocol) && !window.Capacitor?.isNativePlatform?.()) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(new URL(`${import.meta.env.BASE_URL}sw.js`, window.location.href).href).catch(error => console.warn('[VILA] Service worker not registered:', error));
  });
}
window.addEventListener('offline', () => toast('Đang offline: Stockfish, bot cục bộ, khai cuộc, câu đố và xem lại vẫn chạy; chỉ tính năng Lichess/cộng đồng trực tuyến cần mạng.'));
window.addEventListener('online', () => toast('Đã có mạng trở lại.', 'success'));


document.addEventListener('pointerdown', event => {
  const menu = $('#mainMenu');
  if (!menu?.classList.contains('menu-open')) return;
  if (event.target.closest('#mainMenu, #openMenu, #bottomMore')) return;
  menu.classList.remove('menu-open'); $('#openMenu')?.setAttribute('aria-expanded', 'false'); $('#bottomMore')?.setAttribute('aria-expanded', 'false');
}, true);
