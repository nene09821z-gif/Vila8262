/** Persistent in-app notifications. This is an inbox for app events, not Android push messaging. */
export const NOTIFICATION_LIMIT = 100;
const ALLOWED_TYPES = new Set(['info', 'success', 'warning', 'error']);
const text = (value, max) => String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

export function normalizeNotifications(input, limit = NOTIFICATION_LIMIT) {
  if (!Array.isArray(input)) return [];
  const seen = new Set();
  const rows = [];
  for (const item of input) {
    if (!item || typeof item !== 'object') continue;
    const id = text(item.id, 100);
    const title = text(item.title, 100);
    const message = text(item.message, 500);
    if (!id || !title || !message || seen.has(id)) continue;
    seen.add(id);
    const date = new Date(item.createdAt || 0);
    rows.push({
      id,
      title,
      message,
      type: ALLOWED_TYPES.has(item.type) ? item.type : 'info',
      read: Boolean(item.read),
      createdAt: Number.isFinite(date.getTime()) ? date.toISOString() : new Date(0).toISOString(),
      sourceKey: text(item.sourceKey, 160)
    });
  }
  const cap = Math.max(1, Math.min(NOTIFICATION_LIMIT, Number(limit) || NOTIFICATION_LIMIT));
  return rows.slice(-cap);
}

export function addNotification(input, payload, now = new Date()) {
  const items = normalizeNotifications(input);
  const sourceKey = text(payload?.sourceKey, 160);
  if (sourceKey) {
    const existing = items.find(item => item.sourceKey === sourceKey);
    if (existing) return { items, notification: existing, added: false };
  }
  const title = text(payload?.title, 100);
  const message = text(payload?.message, 500);
  if (!title || !message) return { items, notification: null, added: false };
  const timestamp = new Date(now);
  const safeTimestamp = Number.isFinite(timestamp.getTime()) ? timestamp : new Date();
  const id = text(payload?.id, 100) || `notice-${safeTimestamp.getTime().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  const notification = {
    id, title, message,
    type: ALLOWED_TYPES.has(payload?.type) ? payload.type : 'info',
    read: false,
    createdAt: safeTimestamp.toISOString(),
    sourceKey
  };
  const next = normalizeNotifications([...items, notification]);
  return { items: next, notification, added: true };
}

export function markNotificationRead(input, id) {
  const target = text(id, 100);
  return normalizeNotifications(input).map(item => item.id === target ? { ...item, read: true } : item);
}

export function markAllNotificationsRead(input) {
  return normalizeNotifications(input).map(item => ({ ...item, read: true }));
}

export function unreadNotificationCount(input) {
  return normalizeNotifications(input).reduce((count, item) => count + (item.read ? 0 : 1), 0);
}

export function clearReadNotifications(input) {
  return normalizeNotifications(input).filter(item => !item.read);
}
