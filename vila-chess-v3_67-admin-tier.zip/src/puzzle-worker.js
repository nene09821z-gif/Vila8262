import { generateOfflinePuzzle } from './puzzle-generator.js';

// Puzzle scoring is CPU-heavy by design; keep it off the UI thread on Android WebView.
self.addEventListener('message', async event => {
  const { id, options } = event.data || {};
  if (!Number.isInteger(id)) return;
  try {
    const puzzle = await generateOfflinePuzzle(options || {});
    self.postMessage({ id, puzzle: puzzle || null });
  } catch (error) {
    self.postMessage({ id, error: String(error?.message || 'Không thể tạo câu đố ngoại tuyến.') });
  }
});
