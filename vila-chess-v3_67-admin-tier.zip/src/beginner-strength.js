/** Skill-0 is not a calibrated 500 Elo rating; low presets use a bounded teaching handicap. */
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

/**
 * Conservative search budgets for low-rated practice. These are difficulty heuristics, not
 * a claim that Stockfish has been empirically calibrated to a FIDE/online Elo rating.
 */
export function resolveBeginnerSearchBudget(targetElo, { moveTimeMs = 2600, depth = 20 } = {}) {
  const elo = clamp(Math.round(Number(targetElo) || 500), 500, 1319);
  const sourceTime = clamp(Math.round(Number(moveTimeMs) || 2600), 100, 5000);
  const sourceDepth = clamp(Math.round(Number(depth) || 20), 1, 30);
  if (elo <= 600) return { targetElo: elo, moveTimeMs: Math.min(sourceTime, 260), depth: Math.min(sourceDepth, 5), deviationChance: 0.34 };
  if (elo <= 800) return { targetElo: elo, moveTimeMs: Math.min(sourceTime, 360), depth: Math.min(sourceDepth, 6), deviationChance: 0.27 };
  if (elo <= 1000) return { targetElo: elo, moveTimeMs: Math.min(sourceTime, 550), depth: Math.min(sourceDepth, 7), deviationChance: 0.19 };
  return { targetElo: elo, moveTimeMs: Math.min(sourceTime, 900), depth: Math.min(sourceDepth, 10), deviationChance: 0.1 };
}

export function chooseBeginnerMove(bestMove, legalMoves, random = Math.random, deviationChance = 0.34) {
  const legal = [...new Set((Array.isArray(legalMoves) ? legalMoves : [])
    .map(move => String(typeof move === 'string' ? move : move?.uci || '').toLowerCase())
    .filter(move => UCI_RE.test(move)))];
  if (!legal.length) return null;
  const best = String(bestMove || '').toLowerCase();
  if (!legal.includes(best)) return legal[0];
  let draw = 1;
  try { draw = Number(random()); } catch {}
  draw = Number.isFinite(draw) ? clamp(draw, 0, 0.999999) : 1;
  if (legal.length < 2 || draw >= clamp(Number(deviationChance) || 0, 0, 0.5)) return best;
  const alternatives = legal.filter(move => move !== best);
  if (!alternatives.length) return best;
  let choice = 0.5;
  try { choice = Number(random()); } catch {}
  choice = Number.isFinite(choice) ? clamp(choice, 0, 0.999999) : 0.5;
  return alternatives[Math.floor(choice * alternatives.length)] || best;
}
