/** Split multiline output used by some legacy browser-worker builds. */
export function splitUciOutput(rawOutput) {
  return String(rawOutput ?? '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
}

/**
 * Observable Stockfish startup state. A worker is only marked ready after the
 * complete UCI handshake (uciok, then readyok); arbitrary output never implies success.
 */
export function createEngineHealthState(profile = 'unknown', now = Date.now(), attempt = 1) {
  return {
    profile: String(profile || 'unknown'),
    status: 'loading',
    phase: 'waiting-uci',
    uciOk: false,
    readyOk: false,
    startedAt: Number.isFinite(Number(now)) ? Number(now) : Date.now(),
    readyAt: null,
    lastMessageAt: null,
    failure: '',
    attempt: Math.max(1, Math.floor(Number(attempt) || 1))
  };
}

export function observeEngineLine(state, rawLine, now = Date.now()) {
  if (!state || typeof state !== 'object' || state.status !== 'loading') return state;
  const line = String(rawLine ?? '').trim();
  if (!line) return state;
  const at = Number.isFinite(Number(now)) ? Number(now) : Date.now();
  const next = { ...state, lastMessageAt: at };
  if (/^uciok\s*$/.test(line)) {
    next.uciOk = true;
    next.phase = 'waiting-ready';
  } else if (/^readyok\s*$/.test(line)) {
    // Ignore a stray readyok until UCI negotiation has actually completed.
    if (!next.uciOk) return next;
    next.readyOk = true;
    next.status = 'ready';
    next.phase = 'ready';
    next.readyAt = at;
    next.failure = '';
  }
  return next;
}

export function failEngineHealth(state, reason, now = Date.now()) {
  const base = state && typeof state === 'object' ? state : createEngineHealthState();
  return {
    ...base,
    status: 'failed',
    phase: 'failed',
    readyOk: false,
    failure: String(reason || 'Không xác định được lỗi khởi tạo engine.').slice(0, 240),
    lastMessageAt: Number.isFinite(Number(now)) ? Number(now) : Date.now()
  };
}

export function engineStartupDurationMs(state, now = Date.now()) {
  if (!state || !Number.isFinite(Number(state.startedAt))) return null;
  const end = Number.isFinite(Number(state.readyAt)) ? Number(state.readyAt) : Number(now);
  return Math.max(0, Math.round(end - Number(state.startedAt)));
}

export function describeEngineHealth(state) {
  if (!state) return 'Chưa có dữ liệu trạng thái engine.';
  const elapsed = engineStartupDurationMs(state);
  if (state.status === 'ready') return `Engine ${state.profile} đã bắt tay UCI hoàn chỉnh trong ${elapsed ?? '—'} ms (uciok + readyok).`;
  if (state.status === 'failed') return `Engine ${state.profile} lỗi ở bước ${state.phase}: ${state.failure || 'không rõ nguyên nhân'}`;
  return `Engine ${state.profile} đang chờ ${state.uciOk ? 'readyok' : 'uciok'}${elapsed == null ? '' : ` · ${elapsed} ms`}.`;
}
