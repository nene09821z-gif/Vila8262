// Bộ icon SVG nội bộ: nét trắng vẽ tay trên viên gạch 3D (gradient + viền sáng + bóng) do CSS tạo.
// Không dùng emoji hệ thống nên hiển thị giống nhau trên mọi máy Android.
const G = {
  sword: '<path d="M4.5 4.5l15 15M19.5 4.5l-15 15M15 21l6-6M3 15l6 6"/>',
  pawn: '<circle cx="12" cy="7" r="3.6" fill="#fff"/><path d="M7 20.5h10M8.5 20.5c.2-3 1-5 3.5-7 2.5 2 3.3 4 3.5 7M9.3 12.8h5.4"/>',
  trophy: '<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H5a3 3 0 0 0 3 4M16 6h3a3 3 0 0 1-3 4M12 13v4M8 20h8M10 17h4"/>',
  globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
  robot: '<rect x="5" y="8" width="14" height="11" rx="3"/><path d="M12 4v4M9 17h6"/><circle cx="9" cy="13" r="1.2" fill="#fff"/><circle cx="15" cy="13" r="1.2" fill="#fff"/>',
  gamepad: '<rect x="3" y="8" width="18" height="9" rx="4"/><path d="M8 10.5v4M6 12.5h4"/><circle cx="15" cy="12" r="1" fill="#fff"/><circle cx="17.5" cy="14" r="1" fill="#fff"/>',
  puzzle: '<path d="M3.5 8.5H8a2.2 2.2 0 1 1 4.4 0h4.1v4.1a2.2 2.2 0 1 1 0 4.4v3.5H3.5z"/>',
  book: '<path d="M4 5a2 2 0 0 1 2-1h6v16H6a2 2 0 0 0-2 1zM20 5a2 2 0 0 0-2-1h-6v16h6a2 2 0 0 1 2 1z"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5zM6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5M22 9v6"/>',
  crown: '<path d="M5 18h14M5 18L4 8l5 4 3-6 3 6 5-4-1 10z"/>',
  chart: '<path d="M5 20V10M12 20V4M19 20v-8"/>',
  history: '<path d="M4 12a8 8 0 1 0 3-6.2M4 4v5h5M12 8v4l3 2"/>',
  users: '<circle cx="9" cy="8" r="3"/><path d="M3 19a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14a5 5 0 0 1 6 5"/>',
  medal: '<path d="M8 3l2.8 6.5M16 3l-2.8 6.5"/><circle cx="12" cy="15" r="5.5"/><circle cx="12" cy="15" r="1.6" fill="#fff"/>',
  award: '<circle cx="12" cy="9.5" r="5.5"/><path d="M8.5 14.5L7 21l5-3 5 3-1.5-6.5"/>',
  rook: '<path d="M6 21h12M8 21l.8-8.5M16 21l-.8-8.5M7 12.5h10M7 8.5V4h2.6v2.2h4.8V4H17v4.5zM7 8.5h10"/>',
  chat: '<path d="M4 5h16v11H9l-5 4z"/>',
  mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
  bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4zM10 21h4"/>',
  megaphone: '<path d="M3 10h3.5L15 5v14l-8.5-5H3zM18.5 8.5a5 5 0 0 1 0 7"/>',
  gem: '<path d="M6 4h12l4 6-10 11L2 10zM2 10h20M9 4l-2 6 5 11 5-11-2-6"/>',
  coin: '<circle cx="12" cy="12" r="9"/><path d="M14.6 9.3c-.6-.8-1.5-1.2-2.6-1.2-1.5 0-2.5.8-2.5 2s1 1.6 2.5 1.9 2.5.8 2.5 2-1 2-2.5 2c-1.1 0-2-.4-2.6-1.2M12 6.4v1.7M12 15.9v1.7"/>',
  star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  sparkle: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',
  gear: '<path d="M19.1 10.6L21.4 10.8L21.4 13.2L19.1 13.4L18.0 16.0L19.5 17.8L17.8 19.5L16.0 18.0L13.4 19.1L13.2 21.4L10.8 21.4L10.6 19.1L8.0 18.0L6.2 19.5L4.5 17.8L6.0 16.0L4.9 13.4L2.6 13.2L2.6 10.8L4.9 10.6L6.0 8.0L4.5 6.2L6.2 4.5L8.0 6.0L10.6 4.9L10.8 2.6L13.2 2.6L13.4 4.9L16.0 6.0L17.8 4.5L19.5 6.2L18.0 8.0z"/><circle cx="12" cy="12" r="2.8"/>',
  check: '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  home: '<path d="M4 11l8-7 8 7M6 10v10h12V10"/>',
  shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  bolt: '<path d="M13 2L5 14h6l-1 8 8-12h-6z"/>',
  flame: '<path d="M12 22c-4 0-7-3-7-7 0-3 2-5 3-7 1 2 2 2.5 3 2.5C11 7 12 4 14 2c0 4 5 6 5 12 0 4-3 8-7 8z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  hourglass: '<path d="M6 3h12M6 21h12M7 3c0 5 5 6 5 9s-5 4-5 9M17 3c0 5-5 6-5 9s5 4 5 9"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
  dice: '<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1.2" fill="#fff"/><circle cx="15" cy="15" r="1.2" fill="#fff"/><circle cx="15" cy="9" r="1.2" fill="#fff"/><circle cx="9" cy="15" r="1.2" fill="#fff"/>',
  headphones: '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>',
  music: '<path d="M9 18V5l10-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
  flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
  finish: '<path d="M5 21V4M5 4h14v9H5M10 4v9M15 4v9M5 8.5h14"/>',
  warn: '<path d="M12 3l10 18H2zM12 10v5M12 18v.5"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.5-8A6 6 0 0 1 18 11a3.5 3.5 0 0 1-.5 7z"/>',
  hand: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5M11 11V4.5a1.5 1.5 0 0 1 3 0V11M14 11V6a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-1a6 6 0 0 1-5-3l-2-4a1.5 1.5 0 0 1 2.5-1.5L8 14"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4.5"/><circle cx="12" cy="12" r="1" fill="#fff"/>',
  crosshair: '<circle cx="12" cy="12" r="7"/><path d="M12 2v6M12 16v6M2 12h6M16 12h6"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
  pencil: '<path d="M4 20l1-5L16 4l4 4L9 19zM14 6l4 4"/>',
  eraser: '<path d="M4 16l9-10 7 6-6 8H8zM9 20h11"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  castle: '<path d="M4 21V7h4v3h2.5V7h3v3H16V7h4v14zM10 21v-4a2 2 0 0 1 4 0v4"/>',
  handshake: '<path d="M2.5 11.5L6 8l4 2 3-2 5 3.5M2.5 11.5l8 8M6 8L2.5 11.5M21.5 11.5l-8 8M18 8l3.5 3.5M10 16.5l1.8 1.8M12.5 14l1.8 1.8M8 14.5l1.8 1.8"/>',
  brain: '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V4a3 3 0 0 0-3 0zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>',
  sprout: '<path d="M12 21v-9M12 12c0-4-3-6-7-6 0 4 3 6 7 6zM12 14c0-3 2-5 6-5 0 3-2 5-6 5z"/>',
  pulse: '<path d="M2 12h5l2-6 4 12 2-6h7"/>',
  cube: '<path d="M12 3l8 4v10l-8 4-8-4V7zM4 7l8 4 8-4M12 11v10"/>',
  diamond: '<path d="M12 3l8 9-8 9-8-9z"/>',
  infinity: '<path d="M7 8c-3 0-5 2-5 4s2 4 5 4c4 0 6-8 10-8 3 0 5 2 5 4s-2 4-5 4c-4 0-6-8-10-8z"/>',
  heart: '<path d="M12 20S3 14.5 3 8.5A4.5 4.5 0 0 1 12 6a4.5 4.5 0 0 1 9 2.5C21 14.5 12 20 12 20z"/>',
  download: '<path d="M12 3v12M7 11l5 5 5-5M4 21h16"/>',
  swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
  play: '<path d="M7 4l13 8-13 8z" fill="#fff"/>',
  pause: '<rect x="6" y="4" width="4" height="16" rx="1" fill="#fff"/><rect x="14" y="4" width="4" height="16" rx="1" fill="#fff"/>',
  stop: '<rect x="5" y="5" width="14" height="14" rx="2" fill="#fff"/>',
  prev: '<path d="M18 5v14L8 12zM5 5v14"/>',
  next: '<path d="M6 5v14l10-7zM19 5v14"/>',
  dot: '<circle cx="12" cy="12" r="5" fill="#fff"/>',
  face: '<circle cx="12" cy="12" r="9"/><path d="M8.5 14.5a4 4 0 0 0 7 0"/><circle cx="9" cy="10" r="1" fill="#fff"/><circle cx="15" cy="10" r="1" fill="#fff"/>',
  'key-round': '<circle cx="8" cy="8" r="4.5"/><path d="m11.5 11.5 8 8M16 16l2.5-2.5M18.5 18.5l2.5-2.5"/>',
  'shield-check': '<path d="M12 3 20 6v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="m8.5 12 2.3 2.3 4.8-5"/>',
  'user-round': '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
};
/** Màu viên gạch mặc định theo icon (CSS: .tone-*). */
const TONE = { sword: 'red', pawn: 'blue', trophy: 'gold', globe: 'blue', robot: 'cyan', gamepad: 'purple', puzzle: 'orange', book: 'green', cap: 'green', crown: 'gold', chart: 'green', history: 'slate', users: 'purple', medal: 'gold', award: 'gold', rook: 'purple', chat: 'purple', mail: 'purple', bell: 'gold', megaphone: 'orange', gem: 'gold', coin: 'gold', star: 'gold', sparkle: 'gold', gear: 'slate', check: 'green', user: 'blue', home: 'blue', shield: 'cyan', bolt: 'orange', flame: 'red', clock: 'cyan', hourglass: 'cyan', sun: 'gold', dice: 'purple', headphones: 'pink', music: 'pink', flag: 'red', finish: 'slate', warn: 'orange', cloud: 'cyan', hand: 'orange', target: 'red', crosshair: 'cyan', search: 'blue', pencil: 'blue', eraser: 'slate', menu: 'slate', lock: 'slate', castle: 'purple', handshake: 'green', brain: 'pink', sprout: 'green', pulse: 'cyan', cube: 'purple', diamond: 'cyan', infinity: 'cyan', heart: 'red', download: 'blue', swap: 'blue', play: 'green', pause: 'orange', stop: 'red', prev: 'slate', next: 'slate', dot: 'green', face: 'orange' };
export function uiIcon(name) {
  const g = G[name] || G.star;
  return `<svg class="ui-ico" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${g}</svg>`;
}
export function uiTile(name, tone = '', size = '') {
  return `<i class="ui-tile tone-${tone || TONE[name] || 'blue'} ${size}" aria-hidden="true">${uiIcon(name)}</i>`;
}
export const UI_ICON_NAMES = Object.keys(G);

/** Ký tự emoji/ký hiệu thô còn nằm trong chữ → icon 3D. Quân cờ, mũi tên và ✓ ✕ ★ được giữ nguyên. */
const GLYPH = {
  '🏆': ['trophy'], '🥇': ['medal', 'gold'], '🥈': ['medal', 'silver'], '🥉': ['medal', 'bronze'], '🏅': ['award'],
  '🎧': ['headphones'], '♫': ['music'], '🔥': ['flame'], '⚡': ['bolt'], '⏱': ['clock'], '◷': ['clock'], '⏳': ['hourglass'], '⌛': ['hourglass'],
  '☀': ['sun'], '🧩': ['puzzle'], '🎲': ['dice'], '🎮': ['gamepad'], '🤖': ['robot'], '📊': ['chart'], '📖': ['book'], '📘': ['book'],
  '🎓': ['cap'], '💎': ['gem'], '🌐': ['globe'], '🛡': ['shield'], '🔒': ['lock'], '🟢': ['dot'], '📣': ['megaphone'], '✉': ['mail'],
  '⚑': ['flag'], '⚠': ['warn'], '☁': ['cloud'], '✋': ['hand'], '⌖': ['crosshair'], '⌕': ['search'], '✎': ['pencil'], '⌫': ['eraser'],
  '⚙': ['gear'], '☰': ['menu'], '◈': ['coin'], '✦': ['sparkle'], '⚔': ['sword'], '🏰': ['castle'], '🤝': ['handshake'], '🧠': ['brain'],
  '🎯': ['target'], '🌱': ['sprout'], '⌘': ['crown'], '⌁': ['pulse'], '▦': ['cube'], '◆': ['diamond'], '♾': ['infinity'], '♥': ['heart'],
  '🏁': ['finish'], '▶': ['play'], '⏸': ['pause'], '⏮': ['prev'], '⏭': ['next'], '■': ['stop'], '⇄': ['swap'], '🛍': ['gem']
};
const GLYPH_RE = new RegExp(`(${Object.keys(GLYPH).map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\ufe0f?`, 'gu');
const NO_ICO = '[data-no-ico], .chat-bubble';
const SKIP = /^(SCRIPT|STYLE|OPTION|SELECT|TEXTAREA|INPUT|TITLE|CODE|PRE|SVG)$/;

/** Trả về các ký hiệu trong chuỗi sẽ được đổi thành icon 3D (dùng cho kiểm thử). */
export function findGlyphs(text) { return [...String(text).matchAll(GLYPH_RE)].map(m => m[1]); }
export const GLYPH_ICON_NAMES = Object.values(GLYPH).map(v => v[0]);
function glyphNode(char) {
  const [name, tone] = GLYPH[char];
  const el = document.createElement('i');
  el.className = `ui-tile ui-glyph tone-${tone || TONE[name] || 'blue'}`;
  el.setAttribute('aria-hidden', 'true');
  el.innerHTML = uiIcon(name);
  return el;
}
function iconizeText(node) {
  const text = node.nodeValue;
  GLYPH_RE.lastIndex = 0;
  if (!GLYPH_RE.test(text)) return;
  GLYPH_RE.lastIndex = 0;
  const frag = document.createDocumentFragment();
  let last = 0, match;
  while ((match = GLYPH_RE.exec(text))) {
    if (match.index > last) frag.appendChild(document.createTextNode(text.slice(last, match.index)));
    frag.appendChild(glyphNode(match[1]));
    last = match.index + match[0].length;
  }
  if (last < text.length) frag.appendChild(document.createTextNode(text.slice(last)));
  node.parentNode.replaceChild(frag, node);
}
/** Thay ký hiệu thô bằng icon 3D trong một nhánh DOM và điền các phần tử [data-ico]. */
export function hydrateIcons(root) {
  if (!root || typeof document === 'undefined') return;
  if (root.nodeType === 3) { if (root.parentNode && !SKIP.test(root.parentNode.nodeName) && !root.parentNode.closest?.(NO_ICO)) iconizeText(root); return; }
  if (root.nodeType !== 1 && root.nodeType !== 11) return;
  root.querySelectorAll?.('[data-ico]:empty').forEach(el => { el.innerHTML = uiIcon(el.dataset.ico); el.classList.add('ui-tile', `tone-${TONE[el.dataset.ico] || 'blue'}`); });
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(n) {
      const p = n.parentNode;
      if (!p || SKIP.test(p.nodeName) || p.closest?.(NO_ICO)) return NodeFilter.FILTER_REJECT;
      GLYPH_RE.lastIndex = 0;
      return GLYPH_RE.test(n.nodeValue) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(iconizeText);
}
let iconObserver = null;
export function startIconObserver(root = document.body) {
  if (iconObserver || typeof MutationObserver === 'undefined') return;
  const pending = new Set();
  let scheduled = false;
  const flush = () => {
    scheduled = false;
    const items = [...pending]; pending.clear();
    for (const item of items) if (item.isConnected) hydrateIcons(item);
  };
  iconObserver = new MutationObserver(records => {
    for (const record of records) {
      if (record.type === 'characterData') pending.add(record.target);
      else record.addedNodes.forEach(n => { if (n.nodeType === 1 || n.nodeType === 3) pending.add(n); });
    }
    if (pending.size && !scheduled) { scheduled = true; (window.requestAnimationFrame || setTimeout)(flush); }
  });
  hydrateIcons(root);
  iconObserver.observe(root, { childList: true, subtree: true, characterData: true });
}
