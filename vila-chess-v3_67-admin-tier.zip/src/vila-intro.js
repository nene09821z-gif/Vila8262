const INTRO_KEY = 'vila.chess.brand-intro.v1';
const INTRO_DURATION_MS = 5000;

/** First-launch-only brand intro; the logo is inline SVG so it never depends on remote image loading. */
export function showVilaIntro() {
  if (typeof document === 'undefined') return false;
  try {
    if (localStorage.getItem(INTRO_KEY) === '1') return false;
    localStorage.setItem(INTRO_KEY, '1');
  } catch { /* Storage may be disabled; this launch still gets the branded intro. */ }
  if (document.getElementById('vilaBrandIntro')) return false;

  const layer = document.createElement('div');
  layer.id = 'vilaBrandIntro';
  layer.className = 'vila-brand-intro';
  layer.setAttribute('role', 'status');
  layer.setAttribute('aria-label', 'Đang mở Cờ Vua ViLa');
  layer.innerHTML = `
    <div class="vila-intro-stars" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
    <div class="vila-intro-stage" aria-hidden="true">
      <span class="vila-intro-orbit vila-intro-orbit-a"></span><span class="vila-intro-orbit vila-intro-orbit-b"></span>
      <span class="vila-intro-ground"></span>
      <svg class="vila-intro-knight" viewBox="0 0 240 260" xmlns="http://www.w3.org/2000/svg" focusable="false">
        <defs>
          <linearGradient id="vilaKnightMetal" x1=".08" y1=".06" x2=".9" y2=".94"><stop offset="0" stop-color="#f8ffff"/><stop offset=".18" stop-color="#9cf8f4"/><stop offset=".42" stop-color="#43cbd7"/><stop offset=".68" stop-color="#1b789e"/><stop offset=".88" stop-color="#16456c"/><stop offset="1" stop-color="#0b2546"/></linearGradient>
          <linearGradient id="vilaKnightGold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff4c8"/><stop offset=".38" stop-color="#ecc36b"/><stop offset=".7" stop-color="#b77b31"/><stop offset="1" stop-color="#67401e"/></linearGradient>
          <linearGradient id="vilaKnightEdge" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff" stop-opacity=".92"/><stop offset="1" stop-color="#3af5f1" stop-opacity=".1"/></linearGradient>
          <radialGradient id="vilaKnightGlow"><stop offset="0" stop-color="#7fffee" stop-opacity=".44"/><stop offset="1" stop-color="#36bfff" stop-opacity="0"/></radialGradient>
          <filter id="vilaKnightBlur" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="7"/></filter>
          <filter id="vilaKnightShadow" x="-50%" y="-50%" width="200%" height="220%"><feDropShadow dx="0" dy="11" stdDeviation="7" flood-color="#020817" flood-opacity=".72"/></filter>
        </defs>
        <ellipse cx="120" cy="225" rx="88" ry="28" fill="url(#vilaKnightGlow)" filter="url(#vilaKnightBlur)"/>
        <g class="vila-knight-body" filter="url(#vilaKnightShadow)">
          <!-- Original chess-knight silhouette: sculpted facets and metallic rim, no external image. -->
          <path d="M49 208 53 188 67 174 73 151 65 132 52 119 45 93 56 66 76 42 97 52 110 71 132 80 145 65 169 57 190 67 184 88 171 106 173 125 190 146 194 171 206 188 209 208Z" fill="url(#vilaKnightMetal)" stroke="#b7fffb" stroke-width="3" stroke-linejoin="round"/>
          <path d="m56 66 20-24 21 10 13 19 22 9-10 21-28-8-13-19-17-3Z" fill="url(#vilaKnightGold)" stroke="#fff2c5" stroke-width="2" stroke-linejoin="round"/>
          <path d="m76 42 21 10 13 19-9 4-13-15-17-3Z" fill="#fff8dc" opacity=".65"/>
          <path d="m110 71 22 9 13-15 24-8 21 10-6 20-22 13-7 25-20 8-11-20-21-9-17-19Z" fill="url(#vilaKnightMetal)" stroke="#d0fffb" stroke-width="2" stroke-linejoin="round"/>
          <path d="m144 85 24-13 10 5-13 13-8 20-10 11-7-16Z" fill="#0c355c" opacity=".85"/>
          <path d="m171 106 20 40 3 25 12 17-3 20h-44l-2-20-14-24 1-31 9-18Z" fill="url(#vilaKnightMetal)" stroke="#8af2f0" stroke-width="2.5" stroke-linejoin="round"/>
          <path d="m83 129 27 7 12 24-5 24 22 24H49l4-20 14-14 6-23Z" fill="url(#vilaKnightMetal)" stroke="#b7fffb" stroke-width="3" stroke-linejoin="round"/>
          <path d="m85 151 23-1 6 13-5 19 14 17H62l4-13 14-10Z" fill="#17658b" opacity=".85"/>
          <path d="m49 208 4-20 14-14 6-23 11 2-1 20-13 15-1 20ZM143 208l-1-16-13-15 2-29 13-2 4 25 14 18 1 19Z" fill="url(#vilaKnightGold)" stroke="#f8e5a7" stroke-width="2" stroke-linejoin="round"/>
          <path d="m68 208 1 10h-25l5-10ZM164 208h36l7 10h-43Z" fill="url(#vilaKnightGold)" stroke="#ffedb6" stroke-width="2" stroke-linejoin="round"/>
          <path d="m57 70 18-20 14 7M115 75l19 9 13-13M85 134l24 5M78 177l-9 12M154 131l13-22" fill="none" stroke="url(#vilaKnightEdge)" stroke-width="3" stroke-linecap="round" opacity=".8"/>
          <path d="m96 108 24 12-11 10-16-10Z" fill="#103656" stroke="#70f5ed" stroke-width="1.5"/>
          <path d="m99 109 9 4-4 5-9-4Z" fill="#f5ffff"/>
        </g>
        <path class="vila-knight-sheen" d="M54 56 77 42 102 52 135 81 185 69 165 115 143 135 120 205 78 206 89 157 65 122Z" fill="url(#vilaKnightEdge)" opacity=".23"/>
      </svg>
      <span class="vila-intro-ring"></span>
    </div>
    <div class="vila-intro-brand"><span class="vila-intro-wordmark"><b>ViLa</b><span>CHESS</span></span><span class="vila-intro-tagline">THINK · PLAY · MASTER</span><span class="vila-intro-progress"><i></i></span></div>`;
  document.body.appendChild(layer);
  window.setTimeout(() => {
    layer.classList.add('vila-intro-leaving');
    window.setTimeout(() => layer.remove(), 420);
  }, INTRO_DURATION_MS - 420);
  return true;
}
