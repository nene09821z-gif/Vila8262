/**
 * Performance wrapper around chess.js.
 *
 * chess.js v1 recomputes `history()`, `pgn()` and the game-over predicates from scratch on every
 * call: `history()` undoes and replays the whole game and generates every legal move on each ply.
 * The UI calls them many times per board render and `isGameOver()` on every 100 ms clock tick, so
 * the cost grew with game length and caused visible lag (worst while premoving).
 *
 * The cache is dropped on every method that can change the position, history, headers or
 * comments, so results are always identical to the uncached library.
 */
const MUTATORS = ['move', 'undo', 'load', 'reset', 'clear', 'put', 'remove', 'loadPgn',
  'setHeader', 'removeHeader', 'setComment', 'deleteComment', 'deleteComments', 'setCastlingRights'];
const PREDICATES = ['isGameOver', 'isCheckmate', 'isCheck', 'isStalemate', 'isDraw', 'isInsufficientMaterial', 'isThreefoldRepetition'];

export function createCachedChess(Base) {
  class CachedChess extends Base {
    __vcDrop() { this.__vc = null; }
    __vcStore() { return this.__vc || (this.__vc = Object.create(null)); }
    history(options) {
      const verbose = Boolean(options && options.verbose);
      const key = verbose ? 'history:v' : 'history:s';
      const store = this.__vcStore();
      if (!store[key]) store[key] = super.history(options);
      return store[key].slice();
    }
    pgn(options) {
      if (options !== undefined) return super.pgn(options);
      const store = this.__vcStore();
      if (store.pgn === undefined) store.pgn = super.pgn();
      return store.pgn;
    }
  }
  for (const name of MUTATORS) {
    if (typeof Base.prototype[name] !== 'function') continue;
    CachedChess.prototype[name] = function mutator(...args) {
      this.__vc = null;
      try { return Base.prototype[name].apply(this, args); }
      finally { this.__vc = null; }
    };
  }
  for (const name of PREDICATES) {
    if (typeof Base.prototype[name] !== 'function') continue;
    CachedChess.prototype[name] = function predicate(...args) {
      if (args.length) return Base.prototype[name].apply(this, args);
      const store = this.__vcStore();
      const key = `p:${name}`;
      if (store[key] === undefined) store[key] = Base.prototype[name].call(this);
      return store[key];
    };
  }
  return CachedChess;
}
