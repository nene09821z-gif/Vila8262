/**
 * Chess.com-style premoves.
 *
 * A premove queue is an ordered list of intents `{ from, to, promotion }` that the player
 * entered while the opponent was still thinking. Each intent is planned on a *virtual* board in
 * which the earlier queued moves were already played and the opponent did nothing. Nothing is
 * ever trusted at play time: every intent is revalidated against the real position, and the
 * whole queue is cancelled as soon as one intent is no longer legal (for example because the
 * opponent captured or moved the piece involved).
 */
const SQUARE = /^[a-h][1-8]$/;
const PROMOTIONS = ['q', 'r', 'b', 'n'];

/** FEN with `color` to move and no en-passant right (those expire after the opponent's reply). */
function plannedFen(fen, color) {
  const fields = String(fen).split(' ');
  if (fields.length < 6) return null;
  fields[1] = color;
  fields[3] = '-';
  return fields.join(' ');
}

function normalizePromotion(candidates, requested) {
  if (!candidates.some(move => move.promotion)) return { ok: true, promotion: null };
  const promotion = PROMOTIONS.includes(requested) ? requested : 'q';
  return { ok: candidates.some(move => move.promotion === promotion), promotion };
}

/**
 * Virtual position after playing every queued intent for `color` while the opponent passes.
 * Returns a chess instance (with `color` to move) or null when an intent cannot be replayed.
 */
export function buildPremovePosition(chess, color, queue, ChessConstructor) {
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return null;
  try {
    let fen = plannedFen(chess.fen(), color);
    if (!fen) return null;
    let preview = new ChessConstructor(fen);
    for (const intent of Array.isArray(queue) ? queue : []) {
      const candidates = preview.moves({ verbose: true }).filter(move => move.from === intent?.from && move.to === intent?.to);
      if (!candidates.length) return null;
      const { ok, promotion } = normalizePromotion(candidates, intent.promotion);
      if (!ok) return null;
      const made = preview.move({ from: intent.from, to: intent.to, ...(promotion ? { promotion } : {}) });
      if (!made) return null;
      fen = plannedFen(preview.fen(), color);
      if (!fen) return null;
      preview = new ChessConstructor(fen);
    }
    return preview;
  } catch {
    return null;
  }
}

/**
 * Legal premove destinations for the next queued move. With an empty queue this is the player's
 * move list as if it were already their turn; with a queue it is evaluated on the virtual board.
 */
export function getPremoveLegalMoves(chess, color, ChessConstructor, square = null, queue = []) {
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return [];
  try {
    const preview = queue && queue.length
      ? buildPremovePosition(chess, color, queue, ChessConstructor)
      : new ChessConstructor(plannedFen(chess.fen(), color) || '');
    if (!preview) return [];
    if (square) return preview.moves({ square, verbose: true });
    return preview.moves({ verbose: true });
  } catch {
    return [];
  }
}

/** Validates and appends one intent. Returns the new queue, or null when the intent is illegal. */
export function appendPremove(chess, color, ChessConstructor, queue, from, to, promotion = null) {
  if (!SQUARE.test(String(from || '')) || !SQUARE.test(String(to || ''))) return null;
  const current = Array.isArray(queue) ? queue : [];
  const preview = buildPremovePosition(chess, color, current, ChessConstructor);
  if (!preview) return null;
  try {
    const piece = preview.get(from);
    if (!piece || piece.color !== color) return null;
    const candidates = preview.moves({ square: from, verbose: true }).filter(move => move.to === to);
    if (!candidates.length) return null;
    const { ok, promotion: chosen } = normalizePromotion(candidates, promotion);
    if (!ok) return null;
    return [...current, { from, to, promotion: chosen }];
  } catch {
    return null;
  }
}

/** Resolve a stored premove against the actual post-opponent position. */
export function resolveQueuedPremove(chess, intent, color) {
  if (!chess || !intent || chess.turn?.() !== color || !SQUARE.test(String(intent.from || '')) || !SQUARE.test(String(intent.to || ''))) return null;
  try {
    const candidates = chess.moves({ verbose: true }).filter(move => move.from === intent.from && move.to === intent.to);
    if (!candidates.length) return null;
    const isPromotion = candidates.some(move => Boolean(move.promotion));
    const promotion = isPromotion ? (PROMOTIONS.includes(intent.promotion) ? intent.promotion : 'q') : null;
    const move = candidates.find(candidate => (candidate.promotion || null) === promotion);
    return move ? { from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) } : null;
  } catch {
    return null;
  }
}

/**
 * Take the first intent of the queue and resolve it on the real board.
 * `{ move, rest }` — when the first intent is no longer legal the whole queue is dropped
 * (`move: null, rest: []`), exactly like chess.com cancels premoves after a different reply.
 */
export function takeNextPremove(chess, queue, color) {
  const list = Array.isArray(queue) ? queue : [];
  if (!list.length) return { move: null, rest: [], cancelled: [] };
  const move = resolveQueuedPremove(chess, list[0], color);
  if (!move) return { move: null, rest: [], cancelled: list };
  return { move, rest: list.slice(1), cancelled: [] };
}

/** Square sets used to paint the queue (origin and destination of every queued move). */
export function premoveSquares(queue) {
  const from = new Set();
  const to = new Set();
  const list = Array.isArray(queue) ? queue : [];
  for (const intent of list) { from.add(intent.from); to.add(intent.to); }
  return { from, to };
}

/** True when `square` is the origin or destination of any queued move. */
export function isPremoveSquare(queue, square) {
  return (Array.isArray(queue) ? queue : []).some(intent => intent.from === square || intent.to === square);
}

/** Short Vietnamese summary for the status line / screen readers. */
export function describePremoveQueue(queue) {
  const list = Array.isArray(queue) ? queue : [];
  if (!list.length) return '';
  const text = list.map(intent => `${intent.from}→${intent.to}${intent.promotion ? `=${intent.promotion.toUpperCase()}` : ''}`).join(', ');
  return `${list.length} nước đi trước: ${text}`;
}
