/** Pure 3x3 tic-tac-toe rules and optimal O-player move selection. */
export const TIC_TAC_TOE_LINES = Object.freeze([
  Object.freeze([0, 1, 2]), Object.freeze([3, 4, 5]), Object.freeze([6, 7, 8]),
  Object.freeze([0, 3, 6]), Object.freeze([1, 4, 7]), Object.freeze([2, 5, 8]),
  Object.freeze([0, 4, 8]), Object.freeze([2, 4, 6]),
]);

export function ticTacToeOutcome(board) {
  if (!Array.isArray(board) || board.length !== 9) return null;
  for (const [a, b, c] of TIC_TAC_TOE_LINES) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(cell => cell === 'X' || cell === 'O') ? 'draw' : null;
}

function minimax(board, isMaximizing, depth) {
  const outcome = ticTacToeOutcome(board);
  if (outcome === 'O') return 10 - depth;
  if (outcome === 'X') return depth - 10;
  if (outcome === 'draw') return 0;
  let best = isMaximizing ? -Infinity : Infinity;
  for (let index = 0; index < 9; index += 1) {
    if (board[index]) continue;
    board[index] = isMaximizing ? 'O' : 'X';
    const score = minimax(board, !isMaximizing, depth + 1);
    board[index] = '';
    best = isMaximizing ? Math.max(best, score) : Math.min(best, score);
  }
  return best;
}

/** Returns an optimal empty square for O, or -1 when no move is legal. */
export function chooseTicTacToeMove(input) {
  if (!Array.isArray(input) || input.length !== 9 || ticTacToeOutcome(input)) return -1;
  const board = input.map(cell => cell === 'X' || cell === 'O' ? cell : '');
  let bestScore = -Infinity;
  let bestIndex = -1;
  for (let index = 0; index < 9; index += 1) {
    if (board[index]) continue;
    board[index] = 'O';
    const score = minimax(board, false, 1);
    board[index] = '';
    if (score > bestScore) { bestScore = score; bestIndex = index; }
  }
  return bestIndex;
}
