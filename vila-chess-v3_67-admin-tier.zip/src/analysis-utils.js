/** Parse one UCI `info` line into a bounded, display-ready variation record. */
export function parseUciInfoLine(line) {
  const text = String(line || '');
  if (!/\binfo\b/.test(text) || !/\bpv\s+/.test(text)) return null;
  const depth = Number(text.match(/\bdepth\s+(\d+)/)?.[1] || 0);
  const multipv = Number(text.match(/\bmultipv\s+(\d+)/)?.[1] || 1);
  const scoreMatch = text.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
  const pvMatch = text.match(/\bpv\s+((?:[a-h][1-8][a-h][1-8][qrbn]?\s*)+)/i);
  if (!depth || !scoreMatch || !pvMatch || !Number.isInteger(multipv) || multipv < 1 || multipv > 5) return null;
  const pv = pvMatch[1].trim().toLowerCase().split(/\s+/).filter(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move));
  if (!pv.length) return null;
  return { depth, multipv, scoreType: scoreMatch[1], score: Number(scoreMatch[2]), pv: pv.slice(0, 12) };
}

export function formatUciScore(variation) {
  if (!variation) return '—';
  // UCI scores are from the side-to-move perspective; show the familiar
  // White-positive convention used by chess analysis boards.
  const turn = String(variation.fen || '').split(/\s+/)[1] || 'w';
  const raw = Number(variation.score) || 0;
  const score = raw * (turn === 'b' ? -1 : 1);
  if (variation.scoreType === 'mate') {
    // UCI mate 0 means the side to move is already mated, so the sign is negative
    // from that side's perspective; after converting to White's POV invert for Black.
    const whiteSign = raw === 0 ? (turn === 'w' ? -1 : 1) : Math.sign(score);
    return `${whiteSign < 0 ? '-' : '+'}M${Math.abs(raw)}`;
  }
  const pawns = score / 100;
  return `${pawns > 0 ? '+' : ''}${pawns.toFixed(2)}`;
}
