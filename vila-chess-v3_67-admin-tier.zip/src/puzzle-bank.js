/**
 * Bundled forced-mate puzzles (mate in 2-4). Each entry was mined from Stockfish 19 self-play and
 * verified at depth 14: the first move is the only mating try within one move of the best line, and
 * `moves` is the full principal line [player, reply, player, ...] ending in checkmate.
 */
export const PUZZLE_BANK = [
  {"fen": "1r1Q4/6pp/p1N1Pk2/P7/4bp2/2P5/1p1q2P1/5K2 b - - 0 41", "moves": ["b8d8", "c6d8", "b2b1q"], "mateIn": 2},
  {"fen": "2r5/5k2/1p5p/5p2/Q1pr4/3n2qP/1P6/5R1K b - - 10 40", "moves": ["g3h3", "h1g1", "c8g8"], "mateIn": 2},
  {"fen": "3b2k1/2p2pp1/8/4P1q1/1P6/8/r3R3/7K b - - 1 41", "moves": ["a2e2", "e5e6", "g5g2"], "mateIn": 2},
  {"fen": "3rr1k1/1p4p1/5QR1/p1B4p/1P2pP2/P3p2P/5q2/2K5 b - - 1 41", "moves": ["d8d1", "c1d1", "f2d2"], "mateIn": 2},
  {"fen": "6kR/5pp1/1N2n3/r1b5/4bP2/P6P/4K3/r1q5 b - - 1 35", "moves": ["g8h8", "b6d5", "c1d1"], "mateIn": 2},
  {"fen": "7Q/8/6p1/5pk1/p6p/1pPRR2P/1qBKN1P1/8 w - - 2 46", "moves": ["e3g3", "h4g3", "d3g3"], "mateIn": 2},
  {"fen": "k7/2r5/pR5r/P1Pp4/4q3/4P3/4K3/8 b - - 1 56", "moves": ["h6h2", "e2e1", "e4h1"], "mateIn": 2},
  {"fen": "r1b3kr/pppp3p/2n2Qp1/5p2/3P4/2P2N2/P1PB1PPP/R3K2R w KQ - 0 17", "moves": ["d2h6", "c6d4", "f6g7"], "mateIn": 2},
  {"fen": "r4Q2/1p1k4/p2p4/2pBp3/2P4P/1P4p1/P2R4/4K3 w - - 2 37", "moves": ["d5e6", "d7e6", "d2d6"], "mateIn": 2},
  {"fen": "r5k1/3n2bp/1p2p1p1/pPP5/P1N1n2q/N1P2KP1/1B2Q3/R4R2 b - - 0 27", "moves": ["h4g3", "f3e4", "d7c5"], "mateIn": 2},
  {"fen": "rnb1Qbk1/2qpp2N/p1p5/1p4P1/3P2P1/2P5/PP1NBP2/2R1K3 w - - 3 23", "moves": ["e8f8", "g8h7", "e2d3"], "mateIn": 2},
  {"fen": "2bknr2/4Rp2/r4B2/1p1N2Pp/8/1P4P1/P7/1K1R4 w - - 3 34", "moves": ["d5b6", "e8d6", "d1d6", "c8d7", "d6d7"], "mateIn": 3},
  {"fen": "2k2B2/p1p5/1P1r1pr1/4p2p/6q1/1RNPQ3/P1P2PbK/2R5 b - - 0 30", "moves": ["g4h4", "e3h3", "h4h3", "h2g1", "h3h1"], "mateIn": 3},
  {"fen": "2r2k1r/R7/4p3/1pp1PpB1/3b3P/P2P2Q1/1P3P2/6K1 w - - 0 35", "moves": ["g5h6", "f8e8", "g3g6", "e8d8", "h6g5"], "mateIn": 3},
  {"fen": "3k4/4b3/p3Q3/1p6/4Np2/P7/2KB4/5RN1 w - - 1 47", "moves": ["d2a5", "d8e8", "e4d6", "e8f8", "e6f7"], "mateIn": 3},
  {"fen": "4k3/7Q/3p4/8/P7/1P1BP2p/1q5N/4R2K w - - 2 53", "moves": ["d3b5", "e8f8", "e1f1", "b2f2", "f1f2"], "mateIn": 3},
  {"fen": "5R2/7k/4r3/6p1/1p1B4/1P4K1/3p4/3B4 w - - 0 49", "moves": ["d1c2", "e6e4", "c2e4", "h7h6", "f8h8"], "mateIn": 3},
  {"fen": "5k2/p1pn4/3pb2p/4q1P1/7P/Pr3B2/6K1/8 b - - 0 59", "moves": ["b3b2", "g2f1", "e5g3", "g5h6", "g3f2"], "mateIn": 3},
  {"fen": "6k1/2R5/4p1p1/p2bP1Q1/p6p/7P/1P1Nq1P1/4K3 w - - 9 43", "moves": ["e1e2", "d5c4", "d2c4", "g8f8", "g5d8"], "mateIn": 3},
  {"fen": "6r1/2k3q1/8/pQ1p4/5KP1/1P2P3/P2N1P2/8 b - - 0 43", "moves": ["g7g5", "f4g3", "g5g4", "g3h2", "g4g2"], "mateIn": 3},
  {"fen": "7k/pb4p1/1p2r2p/1P4qP/5pPR/P1r1nP2/2P5/2R3K1 b - g3 0 38", "moves": ["g5h4", "c1f1", "h4g3", "g1h1", "g3g2"], "mateIn": 3},
  {"fen": "8/1p6/4Pk1p/8/p3r2P/P7/1P1K1Pq1/8 b - - 5 41", "moves": ["g2f2", "d2c3", "e4d4", "b2b3", "f2d2"], "mateIn": 3},
  {"fen": "8/5k1p/3bp2P/6p1/3Q2B1/4P1P1/1P3PK1/2B5 w - - 1 36", "moves": ["d4d6", "e6e5", "g4h5", "f7g8", "d6d8"], "mateIn": 3},
  {"fen": "8/8/2BK2k1/7p/5Q2/3N4/7r/8 w - - 5 57", "moves": ["d3e5", "g6g7", "f4f7", "g7h6", "f7g6"], "mateIn": 3},
  {"fen": "8/P4k2/1n1Q3p/4P2P/3K4/2P5/8/8 w - - 5 54", "moves": ["d6b6", "f7f8", "b6c7", "f8e8", "a7a8q"], "mateIn": 3},
  {"fen": "B4k2/7p/8/p6K/b5P1/8/3q4/8 b - - 3 53", "moves": ["h7h6", "h5g6", "d2g5", "g6h7", "g5g7"], "mateIn": 3},
  {"fen": "r1b2k2/1p4p1/p1q4r/P4pBn/1PQP3p/2PP3P/6P1/4R1K1 w - - 0 29", "moves": ["g5e7", "f8e8", "c4g8", "e8d7", "g8d8"], "mateIn": 3},
  {"fen": "1r6/5kp1/5p1p/p3p2P/b3P1P1/q4P2/7K/7R b - - 9 47", "moves": ["a3f3", "h1f1", "b8b2", "f1f2", "b2f2", "h2g1", "f3g2"], "mateIn": 4},
  {"fen": "2RB4/8/3R1pk1/p5Pp/P5r1/5BP1/P5P1/6K1 w - - 0 39", "moves": ["d6f6", "g6g7", "c8c7", "g7g8", "f3d5", "g8h8", "f6f8"], "mateIn": 4},
  {"fen": "2rr2k1/pp3ppn/4b3/6QP/4P3/R2p1P1P/1P1Bq3/6KR b - - 7 27", "moves": ["h7g5", "d2g5", "c8c2", "g5d2", "c2d2", "a3a7", "e2f2"], "mateIn": 4},
  {"fen": "3R4/3P2k1/2p5/1p5p/1P1P3p/pB3P2/P4P2/6K1 w - - 0 45", "moves": ["d8g8", "g7h6", "d7d8q", "c6c5", "d8g5", "h6h7", "g5h5"], "mateIn": 4},
  {"fen": "3r1bk1/1p5p/1P6/p4pp1/P3p3/4PnPP/1R3PK1/B7 b - - 0 34", "moves": ["d8d1", "b2b1", "d1b1", "h3h4", "b1g1", "g2h3", "g5g4"], "mateIn": 4},
  {"fen": "3rkb2/4np2/2p4p/p4b2/4r3/PP3P2/7R/1K6 b - - 0 33", "moves": ["e4e2", "b1c1", "e2h2", "b3b4", "h2c2", "c1b1", "d8d1"], "mateIn": 4},
  {"fen": "5b2/1b3k1p/N6p/6PP/8/4Q1PK/4Br2/8 w - - 5 58", "moves": ["e2c4", "b7d5", "c4d5", "f7g7", "e3c3", "f2f6", "c3f6"], "mateIn": 4},
  {"fen": "7k/5pq1/4p2p/p1p4Q/P1P2P1P/1P1r2p1/6K1/8 b - - 0 47", "moves": ["d3d2", "h5e2", "d2e2", "g2f3", "e2f2", "f3e3", "g7d4"], "mateIn": 4},
  {"fen": "7k/5rp1/3P1p2/3Q1P2/8/6Pp/5P1P/5K2 w - - 2 44", "moves": ["d5f7", "h8h7", "d6d7", "h7h8", "f7h5", "h8g8", "d7d8q"], "mateIn": 4},
  {"fen": "8/ppkr4/8/6RP/3p4/4PPK1/8/1qq5 b - - 1 43", "moves": ["c1g1", "g3h4", "b1e1", "h4h3", "g1g5", "h3h2", "e1h4"], "mateIn": 4},
  {"fen": "q1k1r3/1R3p1r/2pb1Pp1/P3Np1p/2pP1P2/8/1Q3PK1/1R6 w - - 1 40", "moves": ["b2b6", "e8e7", "b6c6", "c8d8", "f6e7", "d6e7", "c6d7"], "mateIn": 4}
];

const keyOf = fen => String(fen || '').trim().split(/\s+/).slice(0, 4).join(' ');
export function puzzleBankKey(puzzle) { return keyOf(puzzle?.fen); }

/** Pick an unseen bank puzzle whose mate length suits the tier (0-1: mate in 2, 2: up to 3, 3: up to 4). */
export function pickBankPuzzle(seenKeys = new Set(), tier = 0, rng = Math.random) {
  const maxMate = Math.max(2, Math.min(4, 2 + Math.floor(Number(tier) / 1.5)));
  const unseen = PUZZLE_BANK.filter(item => !seenKeys.has(keyOf(item.fen)));
  if (!unseen.length) return null;
  const suited = unseen.filter(item => item.mateIn <= maxMate);
  const pool = suited.length ? suited : unseen;
  // Prefer the hardest suited length so progress is felt, but keep some variety.
  const hardest = Math.max(...pool.map(item => item.mateIn));
  const top = pool.filter(item => item.mateIn === hardest);
  const chosen = rng() < 0.65 && top.length ? top : pool;
  return chosen[Math.floor(rng() * chosen.length)];
}
