/**
 * Local-first spaced practice from a player's own analyzed mistakes.
 * The module deliberately stores no account secrets and is resilient to disabled storage.
 */
export const MISTAKE_TRAINING_STORAGE_KEY = 'vila.chess.mistake-training.v1';
export const MISTAKE_TRAINING_LIMIT = 500;
export const TRAINABLE_MISTAKE_KEYS = Object.freeze(['blunder', 'missed-win', 'mistake', 'inaccuracy']);
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;
const FEN_RE = /^(?:[rnbqkpRNBQKP1-8]+\/){7}[rnbqkpRNBQKP1-8]+\s+[wb]\s+(?:K?Q?k?q?|-)\s+(?:[a-h][36]|-)\s+\d+\s+\d+$/;

function finite(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function hashText(value) {
  // FNV-1a: stable non-cryptographic identifier only; never used for authentication.
  let hash = 0x811c9dc5;
  for (const character of String(value)) {
    hash ^= character.codePointAt(0);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(36);
}

export function isUsableTrainingFen(fen) {
  const value = String(fen || '').trim();
  return value.length <= 160 && FEN_RE.test(value);
}

export function isUciMove(value) { return UCI_RE.test(String(value || '').trim()); }

function severityFor(key) {
  return ({ blunder: 4, 'missed-win': 4, mistake: 3, inaccuracy: 2 })[key] || 1;
}

/**
 * Convert reviewed move rows into safe-to-practice records. `fenBefore` must describe the
 * position before the player's mistake; `bestMoveUci` must be a legal move verified by caller.
 */
export function buildMistakeTrainingItems(rows = [], {
  gameId = 'game', playerColor = 'both', now = Date.now(), isLegalSolution = () => true
} = {}) {
  if (!Array.isArray(rows)) return [];
  const result = [];
  for (const row of rows) {
    const judgement = String(row?.judgement?.key || row?.judgement || '');
    const mover = row?.mover === 'b' ? 'b' : row?.mover === 'w' ? 'w' : '';
    const ply = Math.floor(finite(row?.ply, -1));
    const fenBefore = String(row?.fenBefore || '').trim();
    const solutionUci = String(row?.bestMoveUci || '').trim().toLowerCase();
    const playedUci = String(row?.playedUci || '').trim().toLowerCase();
    if (!TRAINABLE_MISTAKE_KEYS.includes(judgement) || ply < 1 || !mover ||
        (playerColor !== 'both' && playerColor !== mover) || !isUsableTrainingFen(fenBefore) ||
        !isUciMove(solutionUci) || !isUciMove(playedUci) || solutionUci === playedUci) continue;
    let legal = false;
    try { legal = Boolean(isLegalSolution({ fen: fenBefore, uci: solutionUci, row })); } catch { legal = false; }
    if (!legal) continue;
    const signature = `${hashText(gameId)}:${ply}:${mover}:${hashText(fenBefore.split(/\s+/).slice(0, 4).join(' '))}`;
    const bestLineUci = Array.isArray(row.bestLineUci)
      ? row.bestLineUci.map(value => String(value || '').toLowerCase()).filter(isUciMove).slice(0, 8)
      : [solutionUci];
    const createdAt = Math.max(0, finite(now, Date.now()));
    result.push({
      id: signature,
      gameId: String(gameId).slice(0, 120),
      ply,
      moveNumber: Math.max(1, Math.floor(finite(row.moveNumber, Math.ceil(ply / 2)))),
      mover,
      fenBefore,
      solutionUci,
      solutionSan: String(row.bestMoveSan || '').slice(0, 24),
      playedUci,
      playedSan: String(row.san || '').slice(0, 24),
      judgement: TRAINABLE_MISTAKE_KEYS.includes(judgement) ? judgement : 'mistake',
      lossCp: Math.max(0, Math.floor(finite(row.lossCp, 0))),
      bestLineUci,
      createdAt,
      attempts: 0,
      correctAttempts: 0,
      wrongAttempts: 0,
      streak: 0,
      solved: false,
      dueAt: createdAt,
      lastAttemptAt: 0,
      lastResult: ''
    });
  }
  return result;
}

function normalizeStoredItem(item) {
  if (!item || typeof item !== 'object' || typeof item.id !== 'string' || !item.id ||
      !isUsableTrainingFen(item.fenBefore) || !isUciMove(item.solutionUci) || !isUciMove(item.playedUci) ||
      !TRAINABLE_MISTAKE_KEYS.includes(String(item.judgement)) || !['w', 'b'].includes(item.mover)) return null;
  return {
    id: item.id.slice(0, 180), gameId: String(item.gameId || 'game').slice(0, 120),
    ply: Math.max(1, Math.floor(finite(item.ply, 1))),
    moveNumber: Math.max(1, Math.floor(finite(item.moveNumber, 1))), mover: item.mover,
    fenBefore: String(item.fenBefore), solutionUci: String(item.solutionUci).toLowerCase(),
    solutionSan: String(item.solutionSan || '').slice(0, 24),
    playedUci: String(item.playedUci).toLowerCase(), playedSan: String(item.playedSan || '').slice(0, 24),
    judgement: String(item.judgement), lossCp: Math.max(0, Math.floor(finite(item.lossCp, 0))),
    bestLineUci: Array.isArray(item.bestLineUci) ? item.bestLineUci.map(m => String(m || '').toLowerCase()).filter(isUciMove).slice(0, 8) : [],
    createdAt: Math.max(0, finite(item.createdAt, 0)), attempts: Math.max(0, Math.floor(finite(item.attempts, 0))),
    correctAttempts: Math.max(0, Math.floor(finite(item.correctAttempts, 0))),
    wrongAttempts: Math.max(0, Math.floor(finite(item.wrongAttempts, 0))),
    streak: Math.max(0, Math.floor(finite(item.streak, 0))), solved: item.solved === true,
    dueAt: Math.max(0, finite(item.dueAt, 0)), lastAttemptAt: Math.max(0, finite(item.lastAttemptAt, 0)),
    lastResult: item.lastResult === 'correct' || item.lastResult === 'wrong' ? item.lastResult : ''
  };
}

export function normalizeMistakeTrainingItems(items, limit = MISTAKE_TRAINING_LIMIT) {
  if (!Array.isArray(items)) return [];
  const seen = new Set();
  const clean = [];
  for (const raw of items) {
    const item = normalizeStoredItem(raw);
    if (!item || seen.has(item.id)) continue;
    seen.add(item.id);
    clean.push(item);
  }
  return clean.slice(-Math.max(1, Math.min(MISTAKE_TRAINING_LIMIT, Math.floor(finite(limit, MISTAKE_TRAINING_LIMIT)))));
}

export function loadMistakeTrainingItems(storage = globalThis.localStorage) {
  try {
    const raw = storage?.getItem(MISTAKE_TRAINING_STORAGE_KEY);
    return normalizeMistakeTrainingItems(raw ? JSON.parse(raw) : []);
  } catch { return []; }
}

export function saveMistakeTrainingItems(items, storage = globalThis.localStorage) {
  const clean = normalizeMistakeTrainingItems(items);
  try { storage?.setItem(MISTAKE_TRAINING_STORAGE_KEY, JSON.stringify(clean)); return { ok: true, items: clean }; }
  catch { return { ok: false, items: clean }; }
}

/** Preserve spaced-repetition progress while merging newly analyzed games. */
export function upsertMistakeTrainingItems(existing, incoming, limit = MISTAKE_TRAINING_LIMIT) {
  const map = new Map(normalizeMistakeTrainingItems(existing, limit).map(item => [item.id, item]));
  for (const freshRaw of normalizeMistakeTrainingItems(incoming, limit)) {
    const fresh = normalizeStoredItem(freshRaw);
    if (!fresh) continue;
    const previous = map.get(fresh.id);
    map.set(fresh.id, previous ? { ...fresh,
      attempts: previous.attempts, correctAttempts: previous.correctAttempts, wrongAttempts: previous.wrongAttempts,
      streak: previous.streak, solved: previous.solved, dueAt: previous.dueAt,
      lastAttemptAt: previous.lastAttemptAt, lastResult: previous.lastResult
    } : fresh);
  }
  return normalizeMistakeTrainingItems([...map.values()].sort((a, b) => a.createdAt - b.createdAt), limit);
}

const REVIEW_INTERVALS = Object.freeze([24 * 60 * 60_000, 3 * 24 * 60 * 60_000, 7 * 24 * 60 * 60_000, 14 * 24 * 60 * 60_000, 30 * 24 * 60 * 60_000]);

/** Record a validated answer and schedule the next repetition. Wrong answers remain retryable soon. */
export function recordMistakeAttempt(items, itemId, correct, now = Date.now()) {
  const timestamp = Math.max(0, finite(now, Date.now()));
  let updated = false;
  const next = normalizeMistakeTrainingItems(items).map(item => {
    if (item.id !== itemId) return item;
    updated = true;
    const spacedAnswer = item.attempts === 0 || timestamp >= item.dueAt;
    const streak = correct ? (spacedAnswer ? item.streak + 1 : item.streak) : 0;
    const interval = REVIEW_INTERVALS[Math.min(Math.max(0, streak - 1), REVIEW_INTERVALS.length - 1)];
    return { ...item,
      attempts: item.attempts + 1,
      correctAttempts: item.correctAttempts + (correct ? 1 : 0),
      wrongAttempts: item.wrongAttempts + (correct ? 0 : 1),
      streak,
      solved: correct && streak >= 3,
      dueAt: correct ? timestamp + interval : timestamp + 5 * 60_000,
      lastAttemptAt: timestamp,
      lastResult: correct ? 'correct' : 'wrong'
    };
  });
  return { items: next, updated, item: next.find(item => item.id === itemId) || null };
}

/** Highest-severity unsolved mistake first; spaced repetition takes precedence when due. */
export function selectNextMistake(items, now = Date.now(), excludeIds = []) {
  const timestamp = Math.max(0, finite(now, Date.now()));
  const excluded = new Set(Array.isArray(excludeIds) ? excludeIds : []);
  const pending = normalizeMistakeTrainingItems(items).filter(item => !item.solved && !excluded.has(item.id));
  if (!pending.length) return null;
  const due = pending.filter(item => item.dueAt <= timestamp);
  if (!due.length) return null;
  due.sort((a, b) => severityFor(b.judgement) - severityFor(a.judgement) || b.lossCp - a.lossCp || a.dueAt - b.dueAt || a.createdAt - b.createdAt);
  return due[0] || null;
}

export function summarizeMistakeTraining(items) {
  const normalized = normalizeMistakeTrainingItems(items);
  return {
    total: normalized.length,
    pending: normalized.filter(item => !item.solved).length,
    mastered: normalized.filter(item => item.solved).length,
    attempts: normalized.reduce((sum, item) => sum + item.attempts, 0),
    wrongAttempts: normalized.reduce((sum, item) => sum + item.wrongAttempts, 0),
    correctAttempts: normalized.reduce((sum, item) => sum + item.correctAttempts, 0)
  };
}
