/** Pure helpers for the post-game review panel; move legality is checked by chess.js in the caller. */
export function classifyCentipawnLoss(lossCp) {
  const loss = Math.max(0, Number(lossCp) || 0);
  if (loss <= 5) return { label: 'Tốt nhất', key: 'best' };
  if (loss <= 15) return { label: 'Xuất sắc', key: 'excellent' };
  if (loss < 25) return { label: 'Tốt', key: 'good' };
  if (loss < 70) return { label: 'Chưa chính xác', key: 'inaccuracy' };
  if (loss < 150) return { label: 'Sai lầm', key: 'mistake' };
  return { label: 'Blunder', key: 'blunder' };
}

export function scoreSideToWhiteCentipawns(score, sideToMove, scoreType = 'cp') {
  const value = Number(score) || 0;
  if (scoreType === 'mate') {
    // UCI mate 0 means the root side to move is already checkmated (therefore losing).
    const signed = value === 0
      ? (sideToMove === 'w' ? -1 : 1)
      : value * (sideToMove === 'b' ? -1 : 1);
    return Math.sign(signed) * (10000 - Math.min(999, Math.abs(value)) * 10);
  }
  return sideToMove === 'b' ? -value : value;
}

export function estimateMoveLoss(previousWhiteCp, currentWhiteCp, mover) {
  if (previousWhiteCp == null || currentWhiteCp == null || previousWhiteCp === '' || currentWhiteCp === '' ||
      !Number.isFinite(Number(previousWhiteCp)) || !Number.isFinite(Number(currentWhiteCp))) return null;
  const delta = mover === 'w' ? Number(previousWhiteCp) - Number(currentWhiteCp) : Number(currentWhiteCp) - Number(previousWhiteCp);
  return Math.max(0, Math.round(delta));
}

/** A conservative review label. Do not call a move brilliant merely because a piece can be captured.
 * An opening tag is shown only when the move also retained a strong evaluation. */
export function classifyReviewedMove(lossCp, _sacrificeCandidate = false, bookMove = false, context = {}) {
  if (lossCp == null || !Number.isFinite(Number(lossCp))) return { label: 'Chưa đánh giá', key: 'unrated' };
  const loss = Math.max(0, Number(lossCp));
  const before = Number(context.moverBeforeCp);
  const after = Number(context.moverAfterCp);
  // A big swing from a clearly winning position to an equal/losing one is more useful
  // to describe as a missed win than a generic blunder. Thresholds are transparent heuristics.
  if (Number.isFinite(before) && Number.isFinite(after) && before >= 350 && after <= 100 && loss >= 100) {
    return { label: 'Bỏ lỡ cơ hội thắng', key: 'missed-win' };
  }
  if (bookMove && loss <= 15) return { label: 'Khai cuộc', key: 'book' };
  return classifyCentipawnLoss(loss);
}

/** Chess-annotation style symbols for the review list. These are local heuristic labels, not official Chess.com marks. */
export function reviewSymbolForJudgement(judgement) {
  const key = typeof judgement === 'string' ? judgement : judgement?.key;
  return ({
    book: 'BK',
    'missed-win': '⊘',
    brilliant: '!!',
    great: '!',
    best: '★',
    excellent: '✓',
    good: '·',
    inaccuracy: '?!',
    mistake: '?',
    blunder: '??'
  })[key] || '';
}

export function reviewSymbolDescription(judgement) {
  const key = typeof judgement === 'string' ? judgement : judgement?.key;
  return ({
    book: 'Nước trong sách khai cuộc',
    'missed-win': 'Bỏ lỡ cơ hội thắng từ một thế đang thắng rõ',
    brilliant: 'Nước thiên tài — hy sinh quân đúng lúc mà vẫn giữ thế tốt',
    great: 'Nước tuyệt vời — nước duy nhất hoặc lật ngược thế cờ',
    best: 'Nước tốt nhất — dấu sao giao diện',
    excellent: 'Nước xuất sắc — dấu kiểm giao diện',
    good: 'Nước tốt — chấp nhận được',
    inaccuracy: 'Nước chưa chính xác',
    mistake: 'Sai lầm',
    blunder: 'Blunder — sai lầm nghiêm trọng'
  })[key] || 'Chưa có đánh giá';
}


/** Build SAN-prefix keys from the current opening catalogue for quick book tagging. */
export function buildOpeningBookPrefixes(openings = []) {
  const prefixes = new Set();
  for (const opening of openings) {
    if (!Array.isArray(opening?.san)) continue;
    const path = [];
    for (const san of opening.san) {
      if (typeof san !== 'string' || !san.trim()) break;
      path.push(san.trim());
      prefixes.add(path.join(' '));
    }
  }
  return prefixes;
}

/* ---------- Chess.com-style move quality (v3.48) ----------
 * Moves are judged by the drop in the mover's winning chance (expected points), not by raw
 * centipawns, so the same 80cp mistake matters less in a won position than in an equal one. */

/** Winning chance of the side with `cp` centipawns, 0–100 (logistic model used by Lichess). */
export function winChance(cp) {
  const clamped = Math.max(-1500, Math.min(1500, Number(cp) || 0));
  return 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * clamped)) - 1);
}

export const MOVE_QUALITY_LABELS = Object.freeze({
  brilliant: 'Thiên tài',
  great: 'Tuyệt vời',
  best: 'Tốt nhất',
  excellent: 'Xuất sắc',
  good: 'Tốt',
  book: 'Khai cuộc',
  inaccuracy: 'Thiếu chính xác',
  mistake: 'Sai lầm',
  'missed-win': 'Bỏ lỡ',
  blunder: 'Sai lầm nghiêm trọng',
  unrated: 'Chưa đánh giá'
});

function verdict(key) { return { key, label: MOVE_QUALITY_LABELS[key] }; }

/**
 * @param {object} input
 * @param {number|null} input.moverBeforeCp  engine score for the mover before the move (best play)
 * @param {number|null} input.moverAfterCp   engine score for the mover after the move
 * @param {boolean} input.isBest             the move equals the engine's first choice
 * @param {boolean} input.bookMove           the move is part of a known opening line
 * @param {boolean} input.sacrifice          the move gives up material that the engine line does not win back
 * @param {number|null} input.secondGapPct   winning-chance gap between the best and second-best move (only-move test)
 */
export function classifyMoveQuality(input = {}) {
  const { moverBeforeCp, moverAfterCp, isBest = false, bookMove = false, sacrifice = false, secondGapPct = null, depth = null } = input;
  const before = Number(moverBeforeCp);
  const after = Number(moverAfterCp);
  if (!Number.isFinite(before) || !Number.isFinite(after) || moverBeforeCp == null || moverAfterCp == null) return verdict('unrated');
  const wb = winChance(before);
  const wa = winChance(after);
  const rawDrop = Math.max(0, wb - wa);
  // The engine's own first choice can never be a mistake. The "before" and "after" scores come from
  // two separate time-limited searches, so a depth mismatch alone can fake a drop; cap it.
  // Two shallow searches (< 12 plies) are noisy: shrink the measured drop so a depth artefact is not reported as a
  // blunder. Deep searches are taken at face value.
  const depthNum = Number(depth);
  const noiseFactor = depth != null && Number.isFinite(depthNum) && depthNum > 0 && depthNum < 12 ? 0.6 + 0.4 * (depthNum / 12) : 1;
  const drop = isBest ? Math.min(rawDrop, 2) : rawDrop * noiseFactor;
  if (!isBest && before >= 350 && after <= 100 && drop >= 15) return verdict('missed-win');
  if (drop > 20) return verdict('blunder');
  if (drop > 10) return verdict('mistake');
  if (drop > 5) return verdict('inaccuracy');
  if (bookMove && drop <= 5) return verdict('book');
  const nearBest = isBest || drop <= 2;
  // Brilliant: a real sacrifice that is (nearly) the best move, in a position that was not already
  // decided, and that leaves the mover at least equal-ish.
  if (nearBest && sacrifice && wb < 88 && wa >= 40) return verdict('brilliant');
  // Great: the only good move, or the move that turns a bad position around.
  const onlyMove = Number.isFinite(Number(secondGapPct)) && secondGapPct != null && Number(secondGapPct) >= 12;
  const turnaround = wb <= 35 && wa >= 45;
  if ((isBest || drop <= 1) && wb < 90 && (onlyMove || turnaround)) return verdict('great');
  if (isBest || drop <= 0.5) return verdict('best');
  if (drop <= 2) return verdict('excellent');
  return verdict('good');
}


/* ---------- Win-percent accuracy (Lichess-style, v3.56) ----------
 * Per move: 103.1668 * exp(-0.04354 * winDrop) - 3.1669 (+1 uncertainty bonus), clamped 0..100.
 * Per game: mean of the volatility-weighted mean and the harmonic mean, so one blunder is not hidden
 * by many easy moves. Inputs are the review rows produced by the full-game review. */

/** Accuracy (0–100) of one move from the mover's win chance before/after (both 0–100). */
export function moveAccuracyFromWinPercents(beforePct, afterPct) {
  const before = Number(beforePct);
  const after = Number(afterPct);
  if (!Number.isFinite(before) || !Number.isFinite(after)) return null;
  if (after >= before) return 100;
  const raw = 103.1668100711649 * Math.exp(-0.04354415386753951 * (before - after)) - 3.166924740191411 + 1;
  return Math.max(0, Math.min(100, raw));
}

function stdDev(values) {
  if (!values.length) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.sqrt(values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length);
}

/**
 * @param {Array<{ply:number, mover?:string, color?:string, scoreBeforeWhiteCp?:number|null, scoreWhiteCp?:number|null}>} rows
 * @returns {{white:number|null, black:number|null, combined:number|null, moves:{w:number,b:number}}}
 */
export function computeWinPercentAccuracy(rows = []) {
  const moves = (Array.isArray(rows) ? rows : []).filter(row => row && row.ply > 0 && (row.mover || row.color)
    && Number.isFinite(Number(row.scoreBeforeWhiteCp)) && row.scoreBeforeWhiteCp != null
    && Number.isFinite(Number(row.scoreWhiteCp)) && row.scoreWhiteCp != null);
  const empty = { white: null, black: null, combined: null, moves: { w: 0, b: 0 } };
  if (!moves.length) return empty;
  // White-perspective win-percent series including the start position, used for the volatility weights.
  const series = [winChance(moves[0].scoreBeforeWhiteCp), ...moves.map(row => winChance(row.scoreWhiteCp))];
  const windowSize = Math.max(2, Math.min(8, Math.floor(series.length / 10)));
  const windows = [];
  for (let i = 0; i < windowSize - 2; i += 1) windows.push(series.slice(0, windowSize));
  for (let i = 0; i + windowSize <= series.length; i += 1) windows.push(series.slice(i, i + windowSize));
  const perColor = { w: [], b: [] };
  moves.forEach((row, index) => {
    const color = (row.mover || row.color) === 'b' ? 'b' : 'w';
    const sign = color === 'w' ? 1 : -1;
    const accuracy = moveAccuracyFromWinPercents(winChance(sign * row.scoreBeforeWhiteCp), winChance(sign * row.scoreWhiteCp));
    if (accuracy == null) return;
    const window = windows[Math.min(index, windows.length - 1)] || series;
    const weight = Math.max(0.5, Math.min(12, stdDev(window)));
    perColor[color].push({ accuracy, weight });
  });
  const summarize = list => {
    if (!list.length) return null;
    const weighted = list.reduce((a, item) => a + item.accuracy * item.weight, 0) / list.reduce((a, item) => a + item.weight, 0);
    const harmonic = list.length / list.reduce((a, item) => a + 1 / Math.max(item.accuracy, 1), 0);
    return Math.round(((weighted + harmonic) / 2) * 10) / 10;
  };
  const white = summarize(perColor.w);
  const black = summarize(perColor.b);
  const both = [...perColor.w, ...perColor.b];
  return { white, black, combined: summarize(both), moves: { w: perColor.w.length, b: perColor.b.length } };
}
