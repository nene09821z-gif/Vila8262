# v3.53 (from 3.52.1)
- Game review: new default tier "fast" (~1 s/position, 1 lane, 0.45 s for book moves). Old implicit "max" (8 s/position) migrates to fast unless the player chose it.
- New quick "Phân tích" button in the match action bar (full review after the game, 3-line analysis mid-game; locked in ranked games).
- Rubik: in-place cube updates (no re-render), live drag rotation, tap-to-turn, timer + best time, better contrast.
- Online matchmaking: queue/result/player-bar CSS polish, mobile column layout, reduced-motion support.
- Tests: tests/v3-53-upgrade.test.js. 9 suites still need chess.js/express (not installable offline here).
- Ranked online: optimistic own move, 0.8 s status poll while a match is live, copy/paste/context-menu/drag blocked during live matches, warning when the player leaves the app.
- Premove: the bot's move now slides in first, the queued premove stays painted and fires 170 ms later (cancelled if the player moves manually).
- Puzzles: 6 online retries, pool 200, random rotation of unused cached puzzles, offline tier rises every 3 solved and avoids repeating a theme within the last two puzzles.
- Puzzles: bundled bank of 38 forced-mate puzzles (mate in 2-4) mined with Stockfish 19 self-play, verified at depth 14 (unique first move) and re-verified legal and ending in checkmate; used before the one-move offline generator, filtered by history and by tier (src/puzzle-bank.js).
