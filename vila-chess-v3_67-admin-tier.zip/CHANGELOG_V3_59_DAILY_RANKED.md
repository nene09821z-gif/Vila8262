# ViLa Chess v3.59 — Daily Ranked 1d

- Online ranked matchmaking now defaults to Daily 1d (24 hours per move).
- Daily has its own rating category; Bullet, Blitz, Rapid and Daily ratings remain separate.
- Matchmaking requires the same exact time-control preset and uses the rating for that category.
- Server-authoritative clock resets the moving player's allowance to the full per-move amount after a valid move.
- Daily matches are not forfeited solely because a player closes the app or remains offline; the active per-move deadline remains authoritative.
- Daily matches are not abandoned by the foreground pagehide handler.
- Redesigned the online time-control panel for mobile with clearer typography, active focus, and higher-contrast surfaces.

Validation: JavaScript syntax checks passed for `src/main.js`, `server/social.js`, and `cloudflare/src/index.js`. Targeted clock/ranked UI/backend static tests: 21 passed. Full Cloudflare runtime integration was not run because the local `chess.js` dependency is incomplete in this offline environment.
