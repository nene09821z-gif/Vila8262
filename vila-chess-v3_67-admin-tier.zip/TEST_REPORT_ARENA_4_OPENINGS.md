# Test report — VILA Chess Arena: 4 khai cuộc riêng mỗi bot

## Thay đổi
- `src/bot-personas.js` định nghĩa 21 kho khai cuộc riêng; mỗi kho có đúng 4 tên biến lấy từ catalogue cờ vua đã đóng gói.
- `repertoireLines()` chỉ trả các biến đã lưu của bot đó, không mở rộng ngầm ra toàn bộ sách chung.
- Đấu trường gọi `pickPersonaBookMove()` với hồ sơ của bot hiện tại; lịch sử lựa chọn khai cuộc ở đấu trường được tách khỏi các ván thường và reset mỗi trận.
- Stockfish 19 và Stockfish 10 cũng có kho riêng, không dùng chung hồ sơ `classic`.
- Mặc định tắt `Khai cuộc ghép cặp` để mỗi bot tự chọn từ repertoire của nó. Tuỳ chọn vẫn còn để người dùng benchmark trên cùng khai cuộc đổi màu.
- Danh sách 4 khai cuộc hiển thị trong phần chọn bot; UI giải thích rõ chế độ cá nhân và chế độ ghép cặp.

## Kết quả
- Test mục tiêu: **34/34 đạt** (`v3-23`, `v3-24`, project smoke, static engine profiles và arena tournament).
- Kiểm tra cú pháp `node --check`: đạt cho các file nguồn và test đã sửa.
- `npm run test:static`: **291/292 đạt**. Bài `tests/premove.test.js` không khởi chạy vì môi trường làm việc thiếu package `chess.js` (`ERR_MODULE_NOT_FOUND`); không phải lỗi assertion của thay đổi khai cuộc.
- Build APK/Vite: chưa xác minh vì dependency/binary build không có trong `node_modules` ở môi trường hiện tại. Không tuyên bố APK đã build hay đã test trên OPPO A17k.

## Ghi chú về công bằng
Cả hai bot vẫn nhận cùng thiết lập độ sâu, Skill Level và ngân sách thời gian theo nước đi. Mỗi bot có thể có phong cách khai cuộc khác nhau theo đúng yêu cầu; khi cần so sánh engine dưới cùng một vị trí, bật `Khai cuộc ghép cặp` để dùng cùng một khai cuộc rồi đổi màu.
