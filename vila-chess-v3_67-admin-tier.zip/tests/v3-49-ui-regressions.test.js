import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const v4css = fs.readFileSync(new URL('../src/vila-v4.css', import.meta.url), 'utf8');

test('every identifier the Arena match button and game recovery rely on is actually defined', () => {
  // Found by running the real UI: drawArenaSides() and LOCAL_GAME_RECOVERY_KEY were referenced but never declared,
  // which made "Đấu trận" throw a ReferenceError and silently disabled unfinished-game recovery.
  assert.match(main, /function drawArenaSides\(\)/);
  assert.match(main, /const LOCAL_GAME_RECOVERY_KEY = 'vila\.chess\.local-game-recovery\.v1'/);
  assert.match(main, /\$\('#arenaRunMatch'\)\?\.addEventListener\('click', \(\) => \{ drawArenaSides\(\);/);
});

test('arena colour draw only swaps when the option is on and both bots differ', () => {
  const start = main.indexOf('function drawArenaSides()');
  const body = main.slice(start, main.indexOf('\n}\n', start));
  assert.match(body, /!arenaRandomSides/);
  assert.match(body, /white\.value === black\.value/);
  assert.match(body, /Math\.random\(\) < 0\.5/);
});

test('match top bar grid has one column for each of its four controls', () => {
  const header = main.match(/<header class="match-topbar">([\s\S]*?)<\/header>/)[1];
  const controls = (header.match(/<button\b/g) || []).length + (header.match(/class="match-topbar-title"/g) || []).length;
  assert.equal(controls, 4);
  assert.match(v4css, /\.match-topbar \{ display: grid; grid-template-columns: auto minmax\(0, 1fr\) auto auto;/);
});

test('arena keeps the board high on phones and offers a settings shortcut', () => {
  assert.match(main, /<details class="arena-truth-details"><summary>Cách đấu công bằng/);
  assert.match(main, /id="arenaOpenSettings"/);
  assert.match(main, /\$\('#arenaOpenSettings'\)\?\.addEventListener\('click'/);
  assert.match(v4css, /\.arena-primary-controls #arenaStop\{grid-column:auto\}/);
});

test('arena clears the stale "đang tính nước đi" note when a game ends or is stopped', () => {
  assert.match(main, /if \(\/đang tính nước đi\/\.test\(arenaLastNote\)\) arenaLastNote = 'Ván đã kết thúc/);
  assert.match(main, /if \(\/đang tính nước đi\/\.test\(arenaLastNote\)\) arenaLastNote = 'Ván đã dừng/);
});

test('puzzle page keeps a one-line intro with the long explanation in a collapsible', () => {
  assert.match(main, /<details class="puzzle-how-details"><summary>Cách hoạt động<\/summary>/);
  assert.match(v4css, /\.puzzle-how-details>summary/);
});
