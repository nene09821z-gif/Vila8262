import test from 'node:test';
import assert from 'node:assert/strict';
import { createPuzzleService } from '../server/puzzle-service.js';

function payload(id) {
  return { game: { pgn: '1. e4 e5 2. Nf3 Nc6' }, puzzle: { id, initialPly: 0, solution: ['e2e4'] } };
}
function mockResponse(body, ok = true, status = 200) {
  return { ok, status, async json() { return structuredClone(body); } };
}

test('puzzle proxy validates allowed difficulty and skips recently served puzzle IDs', async () => {
  let calls = 0;
  const service = createPuzzleService({ recentLimit: 2, fetchImpl: async url => {
    calls += 1;
    if (calls === 1) return mockResponse(payload('p1'));
    if (calls === 2) return mockResponse(payload('p1'));
    return mockResponse(payload('p2'));
  } });
  assert.equal((await service.next('hardest')).puzzle.id, 'p1');
  assert.equal((await service.next('unknown')).puzzle.id, 'p2');
  assert.equal(calls, 3);
  assert.deepEqual(service.getRecentIds(), ['p1', 'p2']);
});

test('puzzle proxy caches daily puzzle for the same date and validates payload shape', async () => {
  let calls = 0;
  const service = createPuzzleService({ now: () => Date.parse('2026-10-20T12:00:00Z'), fetchImpl: async () => { calls += 1; return mockResponse(payload('daily1')); } });
  const first = await service.daily();
  const second = await service.daily();
  assert.equal(first.puzzle.id, 'daily1');
  assert.equal(second.puzzle.id, 'daily1');
  assert.equal(calls, 1);
});

test('puzzle proxy rejects malformed upstream payloads and HTTP errors', async () => {
  const malformed = createPuzzleService({ fetchImpl: async () => mockResponse({ game: {}, puzzle: {} }) });
  await assert.rejects(() => malformed.next(), /incomplete puzzle payload/i);
  const failed = createPuzzleService({ fetchImpl: async () => mockResponse({}, false, 429) });
  await assert.rejects(() => failed.daily(), /HTTP 429/);
});
