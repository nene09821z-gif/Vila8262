import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const social = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');
const env = fs.readFileSync(new URL('../.env.example', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('Admin Elo seed is server-configured, bounded, explicit and applied only once before ranked games', () => {
  assert.match(social, /process\.env\.ADMIN_INITIAL_ELO \?\? 3200/);
  assert.match(social, /Math\.max\(100, Math\.min\(4000, Math\.round\(requestedAdminElo\)\)\)/);
  assert.match(social, /adminEloSeedApplied/);
  assert.match(social, /const noRatedGames = \(Number\(admin\.games\) \|\| 0\) === 0/);
  assert.match(social, /ratingsByCategory: \{ bullet: adminInitialElo, blitz: adminInitialElo, rapid: adminInitialElo \}/);
  assert.match(env, /ADMIN_INITIAL_ELO=3200/);
  assert.match(main, /Admin · Elo khởi tạo/);
  assert.match(main, /admin bootstrap có mức khởi tạo riêng/);
});
