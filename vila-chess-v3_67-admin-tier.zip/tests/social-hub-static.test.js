import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/social-hub.css', import.meta.url), 'utf8');
const nodeBackend = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');
const worker = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');

const signupEloChoices = ['200', '500', '1000', '1500'];

test('registration uses only the four requested initial Elo choices on UI and both backends', () => {
  for (const value of signupEloChoices) {
    assert.match(main, new RegExp(`<option value="${value}"`));
    assert.match(nodeBackend, new RegExp(`${value}`));
    assert.match(worker, new RegExp(`${value}`));
  }
  assert.match(nodeBackend, /const eloChoices = \[200, 500, 1000, 1500\]/);
  assert.match(worker, /const choices = \[200, 500, 1000, 1500\]/);
  assert.match(main, /Bot không tính Elo/);
});

test('public player profile, search-to-profile, chat navigation and message API are connected', () => {
  assert.match(nodeBackend, /router\.get\('\/users\/\:username', requireAuth/);
  assert.match(worker, /method === 'GET' && params\[0\] === 'users' && params\.length === 2/);
  assert.match(main, /async function openPlayerProfile\(username\)/);
  assert.match(main, /data-open-profile="\$\{esc\(u\.username\)\}"/);
  assert.match(main, /function renderChatView\(\)/);
  assert.match(main, /function loadChatRoom\(userId\)/);
  assert.match(main, /socialApi\(`\/messages\/\$\{encodeURIComponent\((?:activeChatUserId|recipientId)\)\}`/);
  assert.match(html, /data-view="chat"/);
  assert.match(css, /\.profile-cover/);
  assert.match(css, /\.chat-layout/);
  assert.match(css, /select:not\(\[multiple\]\)/);
  assert.match(main, /chatRefreshTimer = setInterval/);
});

test('reports are rate-limited and admin-only moderation can ban only after review', () => {
  assert.match(nodeBackend, /router\.post\('\/users\/\:userId\/report'/);
  assert.match(worker, /method === 'POST' && params\[0\] === 'users' && params\[2\] === 'report'/);
  assert.match(worker, /\['user-report', 8, 900_000\]/);
  assert.match(worker, /\['direct-message', 40, 60_000\]/);
  assert.match(nodeBackend, /router\.patch\('\/admin\/reports\/\:reportId'/);
  assert.match(worker, /method === 'PATCH' && params\[0\] === 'admin' && params\[1\] === 'reports'/);
  assert.match(main, /Xác minh & khóa/);
  assert.match(nodeBackend, /target\.role === 'admin'/);
  assert.match(worker, /target\.role === 'admin'/);
});

test('server-controlled admin premium entitlement and admin review-access bypass are present', () => {
  assert.match(nodeBackend, /user\.role === 'admin' \? entitlementForClient\(\{ premium: true \}\)/);
  assert.match(worker, /user\.role === 'admin' \? entitlementForClient\(\{ premium: true \}\)/);
  assert.match(nodeBackend, /if \(user\.role === 'admin'\) \{[\s\S]{0,120}allowed: true/);
  assert.match(worker, /if \(user\.role === 'admin'\) return json\(\{ allowed: true/);
});


test('local development uses the paired API and leaderboard surfaces keep readable contrast', () => {
  assert.match(main, /const isLocalDev = import\.meta\.env\?\.DEV === true/);
  assert.match(main, /isLocalDev && \(!configured \|\| configured === DEFAULT_BACKEND_URL\)\) return ''/);
  assert.match(main, /class="content-page leaderboard-page"/);
  assert.match(css, /\.leaderboard-page \.top100-player b \{ color: #f2f7ff !important/);
  assert.match(css, /\.chat-page \.chat-compose \.primary-btn/);
  const v4 = fs.readFileSync(new URL('../src/vila-v4.css', import.meta.url), 'utf8');
  assert.match(v4, /html body #app \{ width: 100% !important; max-width: min\(100%, 1280px\) !important/);
  assert.doesNotMatch(v4, /html body #app \{ max-width: 560px !important/);
});
