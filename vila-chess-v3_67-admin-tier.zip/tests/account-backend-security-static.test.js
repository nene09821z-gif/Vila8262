import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const social = read('server/social.js');
const server = read('server/index.js');
const app = read('src/main.js');

test('account tokens reject placeholders and public server binding needs a real access secret', () => {
  assert.match(social, /externalTokenSecret\.startsWith\('REPLACE_'\)/);
  assert.match(social, /Buffer\.byteLength\(externalTokenSecret, 'utf8'\) < 32/);
  assert.match(server, /Buffer\.byteLength\(ACCESS_SECRET, 'utf8'\) < 32 \|\| ACCESS_SECRET\.startsWith\('REPLACE_'\)/);
});

test('recovery code is cryptographically random, hashed, short-lived and attempt-limited', () => {
  assert.match(social, /randomInt\(100000, 1000000\)/);
  assert.match(social, /emailCodeHash\(user\.id, code\)/);
  assert.match(social, /10 \* 60_000/);
  assert.match(social, /passwordReset\.attempts > 5/);
  assert.match(social, /RESEND_API_KEY/);
});

test('ranked online screen excludes hint, undo and engine/analysis controls', () => {
  const start = app.indexOf('function renderRankedView()');
  const end = app.indexOf('function rankedSyncChess(', start);
  const ranked = app.slice(start, end);
  assert.ok(start >= 0 && end > start);
  assert.doesNotMatch(ranked, /id="(?:hintMove|newGame|undoMove|analyzePosition|engineStatus|puzzleAnalyze)"/);
  assert.match(ranked, /không có engine gợi ý, phân tích, premove hoặc công cụ hỗ trợ/i);
  assert.match(ranked, /recognizeOpening\(\(match\.moves \|\| \[\]\)\.map/);
  assert.match(ranked, /ranked-player-avatar/);
  assert.match(ranked, /ranked-opening-recognition/);
  assert.match(social, /chess\.move\(\{ from, to/);
  assert.match(social, /finishRankedMatch\(match, result/);
});

test('self-hosted social endpoints are VILA account endpoints, not OAuth provider callbacks', () => {
  assert.match(social, /router\.post\('\/auth\/register'/);
  assert.match(social, /router\.post\('\/auth\/login'/);
  assert.match(social, /router\.post\('\/auth\/forgot-password'/);
  assert.match(social, /router\.post\('\/auth\/reset-password'/);
  assert.doesNotMatch(social, /\/auth\/oauth|signInWithIdp|google\.com|github\.com/i);
});
