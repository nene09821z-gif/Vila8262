import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { resolveBeginnerSearchBudget } from '../src/beginner-strength.js';
import { resolveOfflineSearchBudget } from '../src/engine-budgets.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('v3.67 beginner bot uses explicitly bounded engine and rescue budgets', () => {
  const budget = resolveBeginnerSearchBudget(500, { moveTimeMs: 4000, depth: 30 });
  assert.equal(budget.moveTimeMs, 260);
  assert.equal(budget.depth, 5);
  assert.equal(budget.deviationChance, 0.34);
  assert.ok(resolveBeginnerSearchBudget(500, { moveTimeMs: 4000, depth: 30 }).depth < resolveBeginnerSearchBudget(1000, { moveTimeMs: 4000, depth: 30 }).depth);
  assert.match(main, /resolveBeginnerSearchBudget\(requestedStrength\.targetElo/);
  const rescue = resolveOfflineSearchBudget('rookie', { beginnerPractice: true, botMoveTimeMs: 260, botDepth: 5 });
  assert.equal(rescue.maxTimeMs, 260);
  assert.equal(rescue.depth, 5);
  assert.ok(rescue.maxNodes <= 45000);
  assert.match(main, /beginnerRescueBudget/);
});

test('v3.67 review rows preserve the pre-mistake position needed for training', () => {
  assert.match(main, /fenBefore:\s*beforePosition\.fen,\s*fenAfter:\s*position\.fen/);
  assert.match(main, /buildMistakeTrainingItems/);
  assert.match(main, /isLegalSolution:\s*\(\{ fen, uci \}\)/);
});

test('personal mistake training is available from game review and has touch-sized responsive board controls', () => {
  assert.match(main, /id="reviewMistakeTrainingBtn"/);
  assert.match(main, /data-training-square/);
  assert.match(main, /data-training-next/);
  assert.match(css, /\.mistake-training-board/);
  assert.match(css, /@media\(max-width:680px\)\{\.mistake-training-layout/);
});

test('release scripts include personal-training regression tests', () => {
  assert.equal(packageJson.version, '3.67.0');
  assert.ok(packageJson.scripts['test:static'].includes('tests/mistake-training.test.js'));
  assert.ok(packageJson.scripts['test:static'].includes('tests/v3-67-training-and-stability.test.js'));
});
