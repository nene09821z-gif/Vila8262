import test from 'node:test';
import assert from 'node:assert/strict';
import { puzzleAccess, FREE_PUZZLE_LIMIT, grantPlan, PLAN_CATALOG } from '../src/plans.js';
import { classifyMoveQuality } from '../src/game-review.js';

test('free accounts get exactly 3 puzzles; Pro and Premium are unlimited', () => {
  assert.equal(FREE_PUZZLE_LIMIT, 3);
  const free = {};
  assert.deepEqual([0, 1, 2].map(n => puzzleAccess(free, n).allowed), [true, true, true]);
  assert.equal(puzzleAccess(free, 3).allowed, false);
  assert.equal(puzzleAccess(free, 99).remaining, 0);
  assert.equal(puzzleAccess(free, 1).remaining, 2);
  const pro = grantPlan({}, 'pro');
  assert.equal(puzzleAccess(pro, 500).allowed, true);
  assert.equal(puzzleAccess(pro, 500).unlimited, true);
  assert.equal(puzzleAccess(grantPlan({}, 'premium'), 500).unlimited, true);
});

test('plan perks mention the puzzle limits', () => {
  assert.ok(PLAN_CATALOG.free.perks.some(p => /3 câu/.test(p)));
  assert.ok(PLAN_CATALOG.pro.perks.some(p => /Câu đố không giới hạn/.test(p)));
  assert.ok(PLAN_CATALOG.premium.perks.some(p => /Câu đố không giới hạn/.test(p)));
});

test('shallow searches cannot fake a blunder, deep searches still report it', () => {
  const base = { moverBeforeCp: 0, moverAfterCp: -300, isBest: false };
  assert.equal(classifyMoveQuality({ ...base, depth: 30 }).key, 'blunder');
  assert.notEqual(classifyMoveQuality({ moverBeforeCp: 0, moverAfterCp: -120, depth: 6 }).key, 'blunder');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 0, moverAfterCp: -120 }).key, classifyMoveQuality({ moverBeforeCp: 0, moverAfterCp: -120, depth: 20 }).key);
});
