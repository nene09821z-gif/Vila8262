import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');
const main = read('../src/main.js');
const css = read('../src/style.css');
const core = read('../src/alternate-engine-core.js');
const schema = read('../src/settings-schema.js');
const worker = read('../src/alternate-engine-worker.js');

test('eighteen offline engine profiles are catalogued and selectable in settings, bot play and the arena', () => {
  for (const id of ['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz', 'gambit', 'hyper', 'strangler', 'trickster', 'rookie']) {
    assert.ok(core.includes(`id: '${id}'`), `catalogue missing ${id}`);
    assert.ok(schema.includes(`'${id}'`), `settings schema must accept ${id}`);
  }
  for (const file of ['fortress', 'endgame', 'dynamic', 'blitz']) assert.ok(fs.existsSync(new URL(`../src/engines/${file}.js`, import.meta.url)));
  assert.match(main, /OFFLINE_ENGINE_CATALOG\.map\(item => `<option value="\$\{item\.id\}"/);
  assert.match(main, /type: 'offline',\s*profile: item\.id/);
  assert.match(main, /async function chooseArenaUci/);
  assert.match(main, /pickPersonaBookMove\(chess, profile, OPENINGS, \{ recentChoices: arenaOpeningChoices \}\)/);
  const arena = main.slice(main.indexOf('async function chooseArenaUci'), main.indexOf('function getArenaOutcome'));
  assert.match(arena, /getPersonaOpeningNames\(profile\)/);
  assert.doesNotMatch(arena, /findOpeningBookMove\(chess, OPENINGS/);
});

test('engine speed (depth, nodes/second) is recorded for Stockfish and offline engines', () => {
  assert.match(main, /function recordStockfishSpeed\(line\)/);
  assert.match(main, /function recordEngineSpeed\(name, stats\)/);
  assert.match(main, /data-engine-speed/);
  assert.match(worker, /nps: result\.nps/);
  assert.match(css, /\.engine-speed-chip/);
});

test('end-of-game dialog offers rematch / new match and analysis in play, ranked and arena', () => {
  assert.match(main, /function showResultModal\(/);
  assert.match(main, /maybeShowPlayResultModal\(\);\s*maybeShowRankedResultModal\(\);/);
  assert.match(main, /showArenaResultModal\(white, black, result\)/);
  assert.match(main, /Ghép trận mới/);
  assert.match(main, /Phân tích ván/);
  assert.match(main, /role="dialog" aria-modal="true"/);
  assert.match(css, /\.result-modal-backdrop/);
  assert.match(css, /prefers-reduced-motion:reduce\)\{\.result-modal-backdrop/);
});

test('arrows follow Chess.com conventions: polygon heads, knight L-shapes, toggle, right-drag, four colours', () => {
  assert.match(main, /function arrowMarkup\(fromSquare, toSquare, cls, forceKnightL = false\)/);
  assert.match(main, /const knight = /);
  assert.match(main, /function toggleBoardAnnotation\(mark\)/);
  assert.match(main, /event\.pointerType === 'mouse' && event\.button === 2/);
  assert.match(main, /ANNOTATION_COLORS = \['green', 'red', 'yellow', 'blue'\]/);
  assert.match(main, /slice\(0, 3\)\.map\(\(variant, index\)/);
  assert.match(css, /\.manual-arrow-blue/);
  assert.match(css, /\.analysis-arrow-1/);
});

test('piece dragging is sized once, placed before first paint and highlights the hovered target', () => {
  assert.match(main, /--drag-size/);
  assert.match(main, /boardRect: board\.getBoundingClientRect\(\)/);
  assert.match(main, /classList\.add\('drag-over'\)/);
  assert.match(css, /\.square\.drag-over/);
});
