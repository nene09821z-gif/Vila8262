import test from 'node:test';
import assert from 'node:assert/strict';
import { groupReviewedMoves, summarizeReviewSide } from '../src/review-list.js';

test('review move list pairs White and Black moves and sorts by move number', () => {
  const rows = [
    { ply: 4, moveNumber: 2, mover: 'b', san: 'Nc6' },
    { ply: 1, moveNumber: 1, mover: 'w', san: 'e4' },
    { ply: 3, moveNumber: 2, mover: 'w', san: 'Nf3' },
    { ply: 2, moveNumber: 1, mover: 'b', san: 'e5' },
  ];
  const groups = groupReviewedMoves(rows);
  assert.deepEqual(groups.map(group => [group.moveNumber, group.white?.san, group.black?.san]), [
    [1, 'e4', 'e5'], [2, 'Nf3', 'Nc6']
  ]);
});

test('review move list keeps a black-to-move custom FEN number and never mutates input', () => {
  const rows = [{ ply: 1, moveNumber: 17, mover: 'b', san: 'Kf7' }, { ply: 2, moveNumber: 18, mover: 'w', san: 'Kf2' }];
  const copy = structuredClone(rows);
  const groups = groupReviewedMoves(rows);
  assert.deepEqual(groups.map(group => group.moveNumber), [17, 18]);
  assert.deepEqual(rows, copy);
});

test('side stats count only the requested color and known verdict categories', () => {
  const rows = [
    { ply: 1, mover: 'w', judgement: { key: 'best' } },
    { ply: 2, mover: 'b', judgement: { key: 'blunder' } },
    { ply: 3, mover: 'w', judgement: { key: 'mistake' } },
    { ply: 4, mover: 'w', judgement: null },
  ];
  const white = summarizeReviewSide(rows, 'w');
  assert.equal(white.total, 3);
  assert.equal(white.rated, 2);
  assert.equal(white.counts.best, 1);
  assert.equal(white.counts.mistake, 1);
  assert.equal(summarizeReviewSide(rows, 'b').counts.blunder, 1);
});
