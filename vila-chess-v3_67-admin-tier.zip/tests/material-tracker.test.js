import test from 'node:test';
import assert from 'node:assert/strict';
import { summarizeCapturedMaterial } from '../src/material-tracker.js';

test('summarizes captures by capturing side and computes Chess.com-style material advantage', () => {
  const summary = summarizeCapturedMaterial([
    { color: 'w', captured: 'p' },
    { color: 'b', captured: 'r' },
    { color: 'w', captured: 'q' },
    { color: 'w', captured: 'n' },
    { color: 'b', captured: 'p' }
  ]);
  assert.deepEqual(summary.captured.w, ['q', 'n', 'p']);
  assert.deepEqual(summary.captured.b, ['r', 'p']);
  assert.deepEqual(summary.points, { w: 13, b: 6 });
  assert.equal(summary.difference, 7);
  assert.deepEqual(summary.advantage, { w: 7, b: 0 });
});

test('handles en-passant capture records, empty history, and invalid pieces safely', () => {
  const empty = summarizeCapturedMaterial([]);
  assert.deepEqual(empty.captured, { w: [], b: [] });
  assert.deepEqual(empty.advantage, { w: 0, b: 0 });
  const ep = summarizeCapturedMaterial([{ color: 'w', captured: 'p', flags: 'e' }, { color: 'b', captured: 'k' }, null]);
  assert.deepEqual(ep.captured, { w: ['p'], b: [] });
  assert.deepEqual(ep.points, { w: 1, b: 0 });
});
