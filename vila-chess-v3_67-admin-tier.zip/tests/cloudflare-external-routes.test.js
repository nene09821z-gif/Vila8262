import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../cloudflare/src/index.js';

function request(path, { method = 'GET', body } = {}) {
  return new Request(`https://vila-test.workers.dev${path}`, {
    method,
    headers: { Origin: 'https://game.example', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

test('Cloudflare external proxy keeps existing Lichess account integration working without shared backend key', async () => {
  const originalFetch = globalThis.fetch;
  let upstreamUrl = '';
  let upstreamHeaders = {};
  globalThis.fetch = async (url, options = {}) => {
    upstreamUrl = String(url);
    upstreamHeaders = options.headers || {};
    return new Response(JSON.stringify({ id: 'lichess-id', username: 'Player', title: 'FM', perfs: { blitz: { rating: 1800 } } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  try {
    const response = await worker.fetch(request('/api/lichess/account', { method: 'POST', body: { token: 'user-token' } }), {});
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('Access-Control-Allow-Origin'), 'https://game.example');
    assert.deepEqual(await response.json(), { id: 'lichess-id', username: 'Player', title: 'FM', perfs: { blitz: { rating: 1800 } } });
    assert.equal(upstreamUrl, 'https://lichess.org/api/account');
    assert.equal(upstreamHeaders.Authorization, 'Bearer user-token');
  } finally { globalThis.fetch = originalFetch; }
});

test('Cloudflare Lichess proxy rejects malformed moves before contacting upstream', async () => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async () => { throw new Error('should not call upstream'); };
  try {
    const response = await worker.fetch(request('/api/lichess/move', { method: 'POST', body: { token: 'x', gameId: 'bad', move: 'e2e5' } }), {});
    assert.equal(response.status, 400);
    assert.match((await response.json()).error, /Mã ván Lichess không hợp lệ/);
  } finally { globalThis.fetch = originalFetch; }
});

test('Cloudflare Opening Explorer validates UCI and proxies a valid query', async () => {
  const originalFetch = globalThis.fetch;
  let upstreamUrl = '';
  globalThis.fetch = async url => {
    upstreamUrl = String(url);
    return new Response(JSON.stringify({ moves: [{ san: 'e4', uci: 'e2e4', white: 100, draws: 20, black: 80 }] }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  try {
    const invalid = await worker.fetch(request('/api/openings/explorer?moves=e2e9'), {});
    assert.equal(invalid.status, 400);
    const valid = await worker.fetch(request('/api/openings/explorer?moves=e2e4'), {});
    assert.equal(valid.status, 200);
    assert.equal((await valid.json()).moves[0].san, 'e4');
    const parsed = new URL(upstreamUrl);
    assert.equal(parsed.hostname, 'explorer.lichess.ovh');
    assert.equal(parsed.searchParams.get('moves'), 'e2e4');
  } finally { globalThis.fetch = originalFetch; }
});

test('Cloudflare puzzle routes validate upstream payload and return daily cache policy', async () => {
  const originalFetch = globalThis.fetch;
  let upstreamUrl = '';
  globalThis.fetch = async url => {
    upstreamUrl = String(url);
    return new Response(JSON.stringify({ puzzle: { id: 'puzzle1', solution: ['e2e4'] }, game: { pgn: '[Event "Puzzle"]' } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  try {
    const daily = await worker.fetch(request('/api/puzzles/daily'), {});
    assert.equal(daily.status, 200);
    assert.match(daily.headers.get('Cache-Control'), /max-age=300/);
    assert.equal(new URL(upstreamUrl).pathname, '/api/puzzle/daily');
    const next = await worker.fetch(request('/api/puzzles/next?difficulty=harder'), {});
    assert.equal(next.status, 200);
    assert.equal(new URL(upstreamUrl).searchParams.get('difficulty'), 'harder');
  } finally { globalThis.fetch = originalFetch; }
});
