import test from 'node:test';
import assert from 'node:assert/strict';
import { LICHESS_PUZZLE_POOL_LIMIT, puzzlePoolKey, normalizePuzzlePool, upsertPuzzlePool, chooseUnusedPuzzle } from '../src/puzzle-pool.js';

const fenRow = file => file === 0 ? 'K7' : file === 7 ? '7K' : `${file}K${7 - file}`;
const blackRow = file => file === 0 ? 'k7' : file === 7 ? '7k' : `${file}k${7 - file}`;
const puzzle = (n, extra = {}) => ({ fen: `8/8/8/8/8/8/${fenRow(n % 8)}/${blackRow((Math.floor(n / 8) + 5) % 8)} ${n % 2 ? 'b' : 'w'} ${['-', 'K', 'Q', 'KQ', 'k', 'kq', 'KQkq'][Math.floor(n / 2) % 7]} ${n % 8 === 0 ? '-' : `${'abcdefgh'[n % 8]}${(n % 6) + 2}`} ${n} 1`, moves: ['e2e3'], cachedAt: n, ...extra });
const valid = item => Boolean(item && Array.isArray(item.moves) && item.moves.length && String(item.fen).includes('/'));

test('pool deduplicates positions by normalized position key and validates lines', () => {
  const a = puzzle(0), duplicate = { ...puzzle(55), fen: a.fen.replace(/ \d+ 1$/, ' 55 1') };
  const pool = normalizePuzzlePool([a, duplicate, puzzle(2, { moves: [] }), null], valid);
  assert.equal(pool.length, 1);
  assert.equal(puzzlePoolKey(pool[0]), puzzlePoolKey(a));
});

test('upsert keeps the cache bounded and replaces duplicates', () => {
  let pool = [];
  for (let i = 0; i < LICHESS_PUZZLE_POOL_LIMIT + 10; i += 1) pool = upsertPuzzlePool(pool, puzzle(i), valid);
  assert.equal(pool.length, LICHESS_PUZZLE_POOL_LIMIT);
  assert.equal(pool.at(-1).cachedAt, LICHESS_PUZZLE_POOL_LIMIT + 9);
});

test('offline picker returns an unused valid puzzle (random order) and never mutates the pool', () => {
  const items = [puzzle(0), puzzle(1), puzzle(2)];
  const seen = new Set([puzzlePoolKey(items[0])]);
  const choice = chooseUnusedPuzzle(items, seen, valid);
  assert.ok([puzzlePoolKey(items[1]), puzzlePoolKey(items[2])].includes(puzzlePoolKey(choice)));
  assert.notEqual(puzzlePoolKey(choice), puzzlePoolKey(items[0]));
  const picks = new Set(Array.from({ length: 60 }, () => puzzlePoolKey(chooseUnusedPuzzle(items, seen, valid))));
  assert.equal(picks.size, 2, 'both unused puzzles get rotated in over time');
  assert.equal(items.length, 3);
  assert.equal(chooseUnusedPuzzle(items, new Set(items.map(puzzlePoolKey)), valid), null);
});
