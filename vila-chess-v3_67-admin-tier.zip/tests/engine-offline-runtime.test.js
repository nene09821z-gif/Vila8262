import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawnSync } from 'node:child_process';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('offline Stockfish 19 Lite starts, completes the UCI handshake and emits a legal start-position move', () => {
  const result = spawnSync(process.execPath, ['scripts/verify-engine-assets.mjs'], {
    cwd: new URL('..', import.meta.url), encoding: 'utf8', timeout: 30000,
  });
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  assert.match(result.stdout, /Stockfish 19 Lite runtime OK/);
  assert.match(result.stdout, /depth-4 bestmove (?:[a-h][1-8]){2}/);
});

test('offline engine fallback resources and explicit Full NNUE metadata are not silently fabricated', () => {
  const manifest = JSON.parse(read('public/engine/engine-manifest.json'));
  assert.equal(manifest.lite, true);
  assert.equal(manifest.asmFallback, true);
  assert.ok(fs.statSync(new URL('../public/engine/stockfish-19-lite-single.wasm', import.meta.url)).size > 100000);
  assert.ok(fs.statSync(new URL('../public/engine/stockfish-19-asm.js', import.meta.url)).size > 100000);
  if (manifest.full) {
    assert.ok(manifest.assets.fullJs && manifest.assets.fullWasm, 'Full NNUE must name both assets');
    assert.ok(fs.existsSync(new URL(`../public/engine/${manifest.assets.fullJs}`, import.meta.url)));
    assert.ok(fs.existsSync(new URL(`../public/engine/${manifest.assets.fullWasm}`, import.meta.url)));
  } else {
    assert.equal(manifest.assets.fullJs, null);
    assert.equal(manifest.assets.fullWasm, null);
  }
});
