import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { uiIcon, uiTile, findGlyphs, UI_ICON_NAMES, GLYPH_ICON_NAMES } from '../src/ui-icons.js';
import { DAILY_MISSIONS, SHOP_ITEMS, SHOP_GROUPS } from '../src/daily-progress.js';
import { ACHIEVEMENT_METRICS } from '../src/achievements.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const names = new Set(UI_ICON_NAMES);

test('every icon referenced by data, glyph table and index.html exists in the 3D icon set', () => {
  for (const mission of DAILY_MISSIONS) assert.ok(names.has(mission.icon), `mission ${mission.id}: ${mission.icon}`);
  for (const item of SHOP_ITEMS) assert.ok(names.has(item.icon), `shop ${item.id}`);
  for (const group of SHOP_GROUPS) assert.ok(names.has(group.icon), `group ${group.id}`);
  for (const name of GLYPH_ICON_NAMES) assert.ok(names.has(name), `glyph ${name}`);
  for (const [, name] of read('index.html').matchAll(/data-ico="([a-z]+)"/g)) assert.ok(names.has(name), `index ${name}`);
  assert.ok(uiIcon('sword').startsWith('<svg'));
  assert.match(uiTile('trophy'), /tone-gold/);
});

test('rough emoji and symbols are converted but chess pieces, arrows and avatars are left alone', () => {
  assert.deepEqual(findGlyphs('🏆 Thắng ⚡ nhanh 🔥'), ['🏆', '⚡', '🔥']);
  assert.deepEqual(findGlyphs('♞ ♟ ↗ → ✓ ★ 🐼'), []);
  assert.deepEqual(findGlyphs('🥇 🥈 🥉'), ['🥇', '🥈', '🥉']);
});

test('index.html navigation no longer uses plain text glyphs as icons', () => {
  const nav = read('index.html').match(/<nav class="tabs"[\s\S]*?<\/nav>/)[0];
  assert.equal(findGlyphs(nav).length, 0);
  assert.ok((nav.match(/data-ico=/g) || []).length >= 20);
});

test('shop sells review credits, a 50,000-coin Pro 3h trial and extras, and no longer sells board colours', () => {
  const main = read('src/main.js');
  assert.match(main, /data-buy-item/);
  assert.doesNotMatch(main, /data-buy-cosmetic|data-equip-cosmetic|purchaseCosmetic/);
  assert.ok(SHOP_ITEMS.length >= 8);
  const trial = SHOP_ITEMS.find(item => item.id === 'pro_trial_3h');
  assert.equal(trial.cost, 50000);
  assert.equal(trial.grant.proTrialMs, 10800000);
  assert.match(main, /tryShopReviewAccess/);
  assert.match(main, /spendPuzzleCredit/);
  assert.ok(ACHIEVEMENT_METRICS ? ACHIEVEMENT_METRICS.every(m => names.has(m.icon)) : true);
});
