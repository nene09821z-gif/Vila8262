import test from 'node:test';
import assert from 'node:assert/strict';
import { ACHIEVEMENT_TOTAL, ACHIEVEMENT_METRICS, achievementCatalogue, milestoneLadder, reachedMilestones, summarizeAchievements, listAchievements, newlyUnlocked } from '../src/achievements.js';

test('catalogue holds exactly 10,000 unique achievements', () => {
  assert.equal(ACHIEVEMENT_TOTAL, 10000);
  assert.equal(ACHIEVEMENT_METRICS.reduce((sum, metric) => sum + metric.count, 0), 10000);
  const all = achievementCatalogue();
  assert.equal(all.length, 10000);
  assert.equal(new Set(all.map(item => item.id)).size, 10000);
});

test('ladders are strictly increasing and start at 1', () => {
  for (const metric of ACHIEVEMENT_METRICS) {
    const ladder = milestoneLadder(metric.count, metric.spread);
    assert.equal(ladder.length, metric.count);
    assert.equal(ladder[0], 1);
    for (let i = 1; i < ladder.length; i += 1) assert.ok(ladder[i] > ladder[i - 1], `${metric.id} @${i}`);
  }
});

test('milestones unlock exactly at their threshold', () => {
  assert.equal(reachedMilestones('solve_puzzle', 0), 0);
  assert.equal(reachedMilestones('solve_puzzle', 1), 1);
  assert.equal(reachedMilestones('solve_puzzle', 3), 3);
  assert.equal(reachedMilestones('nonexistent', 99), 0);
  assert.equal(reachedMilestones('checkin', 365 * 1000), 365);
  assert.equal(reachedMilestones('solve_puzzle', -5), 0);
});

test('summary and paging behave', () => {
  const empty = summarizeAchievements({});
  assert.equal(empty.unlocked, 0);
  assert.equal(empty.total, 10000);
  const stats = { solve_puzzle: 10, win_game: 2 };
  const s = summarizeAchievements(stats);
  assert.equal(s.unlocked, reachedMilestones('solve_puzzle', 10) + reachedMilestones('win_game', 2));
  assert.ok(s.points > 0);
  const locked = listAchievements(stats, { status: 'locked', limit: 5 });
  assert.equal(locked.items.length, 5);
  assert.ok(locked.items.every(item => !item.unlocked));
  assert.equal(listAchievements(stats, { status: 'unlocked', limit: 1000 }).total, s.unlocked);
  assert.equal(listAchievements(stats, { category: 'Câu đố', status: 'all', limit: 1000 }).total, 1800 + 300 + 300);
});

test('newlyUnlocked reports only what changed', () => {
  assert.equal(newlyUnlocked({ win_game: 1 }, { win_game: 1 }).length, 0);
  const fresh = newlyUnlocked({ win_game: 0 }, { win_game: 1 });
  assert.equal(fresh.length, 1);
  assert.equal(fresh[0].metric, 'win_game');
});
