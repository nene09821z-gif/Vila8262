import test from 'node:test';
import assert from 'node:assert/strict';
import { PUZZLE_HISTORY_KEY, loadPuzzleHistory, puzzleHistoryKey, rememberPuzzle } from '../src/puzzle-history.js';

function memoryStorage(initial = {}) {
  const values = new Map(Object.entries(initial));
  return { getItem: key => values.has(key) ? values.get(key) : null, setItem: (key, value) => values.set(key, String(value)) };
}

test('puzzle history normalizes FEN by board, turn, castling and en-passant fields', () => {
  assert.equal(puzzleHistoryKey('8/8/8/8/8/8/4K3/7k w - - 0 1'), '8/8/8/8/8/8/4K3/7k w - -');
});

test('puzzle history persists, deduplicates and remains bounded', () => {
  const storage = memoryStorage();
  const a = '8/8/8/8/8/8/4K3/7k w - - 0 1';
  const b = '8/8/8/8/8/8/4K3/7k b - - 0 1';
  rememberPuzzle(a, storage, 2);
  rememberPuzzle(a.replace('0 1', '7 9'), storage, 2);
  assert.equal(loadPuzzleHistory(storage, 2).length, 1, 'same position should not duplicate');
  rememberPuzzle(b, storage, 2);
  rememberPuzzle('7k/8/8/8/8/8/4K3/8 w - - 0 1', storage, 2);
  assert.equal(loadPuzzleHistory(storage, 2).length, 2);
  assert.ok(storage.getItem(PUZZLE_HISTORY_KEY));
});
