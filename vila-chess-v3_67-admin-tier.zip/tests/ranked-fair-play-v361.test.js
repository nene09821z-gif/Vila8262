import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = path => fs.readFileSync(new URL(path, import.meta.url), 'utf8');
import { assessRankedFairPlayMove, createRankedFairPlayState } from '../src/ranked-fair-play.js';

const sample = (state, duration, legal = 10, ply = 0) => assessRankedFairPlayMove(state, {
  userId: 'p1', turnDurationMs: duration, legalMoveCount: legal, ply, now: 1_800_000_000_000 + ply * 1000
});

test('one fast move is not treated as cheating', () => {
  const state = createRankedFairPlayState();
  const out = sample(state, 55, 32, 0);
  assert.equal(out.events.length, 0);
  assert.equal(out.state.signals, 0);
  assert.equal(out.state.level, 'clear');
});

test('four consecutive ultra-fast own turns emit one review signal without an automatic sanction', () => {
  let state = createRankedFairPlayState();
  let events = [];
  for (let i = 0; i < 4; i++) {
    const out = sample(state, 65 + i, 12, i * 2);
    state = out.state;
    events.push(...out.events);
  }
  assert.equal(events.length, 1);
  assert.equal(events[0].type, 'repeated_ultra_fast_moves');
  assert.equal(state.signals, 1);
  assert.equal(state.level, 'review');
  assert.equal('banned' in state, false);
});

test('repeated fast moves in high-branching positions generate a distinct signal', () => {
  let state = createRankedFairPlayState();
  const events = [];
  for (let i = 0; i < 3; i++) {
    const out = sample(state, 200 + i * 5, 30, i * 2);
    state = out.state;
    events.push(...out.events);
  }
  assert.ok(events.some(event => event.type === 'fast_moves_in_complex_positions'));
  assert.equal(state.metrics.fastComplexMoves, 3);
});

test('normal timing resets ultra-fast streak and telemetry storage stays bounded', () => {
  let state = createRankedFairPlayState();
  for (let i = 0; i < 4; i++) state = sample(state, 80, 10, i * 2).state;
  assert.equal(state.ultraFastStreak, 4);
  state = sample(state, 1800, 18, 8).state;
  assert.equal(state.ultraFastStreak, 0);
  for (let i = 0; i < 20; i++) state = sample(state, 900 + i, 15, 10 + i * 2).state;
  assert.equal(state.recentTurns.length, 12);
  assert.ok(state.metrics.movesObserved >= 25);
});


test('admin dashboard consumes and safely renders server fair-play review signals', () => {
  const main = read('../src/main.js');
  assert.match(main, /id=\"adminFairPlayList\"/);
  assert.match(main, /socialApi\('\/admin\/fair-play'\)/);
  assert.match(main, /fairPlayMatches\.map\(match =>/);
  assert.match(main, /fair-play-events/);
  assert.match(main, /Chưa có tín hiệu fair-play cần rà soát/);
  assert.match(main, /Không tự động khóa tài khoản từ các tín hiệu này/);
});
