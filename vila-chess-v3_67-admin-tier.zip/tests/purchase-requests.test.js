import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import worker, { ChessState } from '../cloudflare/src/index.js';
import { PRO_TRIAL_DURATION_MS, effectivePlan } from '../src/plans.js';

const ADMIN_USERNAME = 'vila_admin';
const ADMIN_PASSWORD = 'AdminPassword!12345';
const registerBody = username => ({ username, displayName: username, password: 'Password!1' });

async function startNodeBackend(dataDir) {
  const [{ default: express }, { createSocialRouter }] = await Promise.all([import('express'), import('../server/social.js')]);
  const envBackup = { ADMIN_USERNAME: process.env.ADMIN_USERNAME, ADMIN_PASSWORD: process.env.ADMIN_PASSWORD, ADMIN_EMAIL: process.env.ADMIN_EMAIL };
  process.env.ADMIN_USERNAME = ADMIN_USERNAME;
  process.env.ADMIN_PASSWORD = ADMIN_PASSWORD;
  process.env.ADMIN_EMAIL = 'admin@example.test';
  const app = express();
  app.use(express.json({ limit: '1mb' }));
  app.use('/api/social', await createSocialRouter({ dataDir }));
  const server = await new Promise(resolve => { const instance = app.listen(0, '127.0.0.1', () => resolve(instance)); });
  const base = `http://127.0.0.1:${server.address().port}/api/social`;
  const call = async (route, { method = 'GET', body, token } = {}) => {
    const response = await fetch(base + route, {
      method,
      headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    return { status: response.status, data: await response.json() };
  };
  return { server, call, envBackup };
}

function createWorkerHarness(env = {}) {
  const records = new Map();
  const sql = {
    exec(statement, ...args) {
      if (/^CREATE TABLE/i.test(statement)) return [];
      if (/^SELECT key, value FROM vila_records/i.test(statement)) return [...records.entries()].map(([key, value]) => ({ key, value }));
      if (/^INSERT INTO vila_records/i.test(statement)) { records.set(String(args[0]), String(args[1])); return []; }
      if (/^DELETE FROM vila_records/i.test(statement)) { records.delete(String(args[0])); return []; }
      throw new Error(`SQL statement not covered by test harness: ${statement}`);
    }
  };
  const makeState = () => ({ storage: { sql, transactionSync: callback => callback() }, blockConcurrencyWhile: callback => callback() });
  let object = new ChessState(makeState(), env);
  const binding = { idFromName: () => 'vila-purchase-tests', get: () => ({ fetch: request => object.fetch(request) }) };
  return { binding, restart() { object = new ChessState(makeState(), env); } };
}
function workerCall(harness, route, { method = 'GET', body, token } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const request = new Request(`https://vila-test.workers.dev${route}`, { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  return worker.fetch(request, { CHESS_STATE: harness.binding }).then(async response => ({ status: response.status, data: await response.json() }));
}

async function exerciseRequestFlow(call, prefix) {
  assert.equal((await call(`${prefix}/me/purchase-requests`, { method: 'POST', body: { plan: 'pro', amountVnd: 1000 } })).status, 401, 'requests require login');
  const registered = await call(`${prefix}/auth/register`, { method: 'POST', body: registerBody('buyerone') });
  assert.equal(registered.status, 201, JSON.stringify(registered.data));
  const token = registered.data.token;
  const adminLogin = await call(`${prefix}/auth/login`, { method: 'POST', body: { username: ADMIN_USERNAME, password: ADMIN_PASSWORD } });
  assert.equal(adminLogin.status, 200, JSON.stringify(adminLogin.data));
  const adminToken = adminLogin.data.token;

  assert.equal((await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'pro', amountVnd: 500 } })).status, 400, 'server fixes Pro price at 1,000 VND');
  const created = await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'pro', amountVnd: 1000 } });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  assert.equal(created.data.request.plan, 'pro');
  assert.equal(created.data.request.amountVnd, 1000);
  assert.equal(created.data.request.status, 'pending');
  assert.ok(created.data.admin.id);
  assert.equal((await call(`${prefix}/auth/me`, { token })).data.user.entitlement.plan, 'free', 'submitting a request never activates Pro');
  assert.equal((await call(`${prefix}/admin/purchase-requests`, { token })).status, 403, 'players cannot inspect the admin queue');
  const queue = await call(`${prefix}/admin/purchase-requests?status=pending`, { token: adminToken });
  assert.equal(queue.status, 200);
  assert.equal(queue.data.requests.length, 1);
  assert.equal(queue.data.requests[0].user.id, registered.data.user.id);
  const conversations = await call(`${prefix}/messages/conversations`, { token: adminToken });
  assert.ok(conversations.data.conversations.some(item => item.user.id === registered.data.user.id), 'purchase request appears in admin Messenger');
  const userRoom = await call(`${prefix}/messages/${created.data.admin.id}`, { token });
  assert.ok(userRoom.data.messages.some(message => /trợ lý: Đã nhận yêu cầu Pro 3 giờ/.test(message.text)), 'auto-reply is a real persisted message');

  const duplicate = await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'pro', amountVnd: 1000 } });
  assert.equal(duplicate.status, 200);
  assert.equal(duplicate.data.duplicate, true);
  assert.equal(duplicate.data.request.id, created.data.request.id, 'one pending request per user/plan');

  const confirm = await call(`${prefix}/admin/purchase-requests/${created.data.request.id}/decision`, { method: 'POST', token: adminToken, body: { action: 'confirm-pro' } });
  assert.equal(confirm.status, 200, JSON.stringify(confirm.data));
  assert.equal(confirm.data.request.status, 'approved');
  assert.equal(confirm.data.user.entitlement.plan, 'pro');
  const remaining = confirm.data.user.entitlement.proExpiresAt - Date.now();
  assert.ok(remaining > PRO_TRIAL_DURATION_MS - 10_000 && remaining <= PRO_TRIAL_DURATION_MS, `expected a server-timed 3h grant, got ${remaining}`);
  assert.equal(effectivePlan(confirm.data.user.entitlement), 'pro');
  assert.equal((await call(`${prefix}/admin/purchase-requests/${created.data.request.id}/decision`, { method: 'POST', token: adminToken, body: { action: 'confirm-pro' } })).status, 409, 'approval cannot be replayed');

  const invalidPremiumLow = await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'premium', amountVnd: 999 } });
  const invalidPremiumHigh = await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'premium', amountVnd: 101000 } });
  assert.equal(invalidPremiumLow.status, 400);
  assert.equal(invalidPremiumHigh.status, 400);
  const premium = await call(`${prefix}/me/purchase-requests`, { method: 'POST', token, body: { plan: 'premium', amountVnd: 100000 } });
  assert.equal(premium.status, 201, JSON.stringify(premium.data));
  const premiumRoom = await call(`${prefix}/messages/${premium.data.admin.id}`, { token });
  assert.ok(premiumRoom.data.messages.some(message => /Premium hiện không bán tự động/.test(message.text)));
  assert.equal((await call(`${prefix}/admin/purchase-requests/${premium.data.request.id}/decision`, { method: 'POST', token: adminToken, body: { action: 'confirm-pro' } })).status, 400, 'a Premium request cannot be converted into a Pro grant');
  const contacted = await call(`${prefix}/admin/purchase-requests/${premium.data.request.id}/decision`, { method: 'POST', token: adminToken, body: { action: 'contacted' } });
  assert.equal(contacted.status, 200);
  assert.equal(contacted.data.request.status, 'contacted');
  assert.equal(contacted.data.user.entitlement.premium, false, 'contacting the user never grants Premium');
  assert.equal((await call(`${prefix}/admin/purchase-requests?status=pending`, { token: adminToken })).data.requests.length, 0);
  const adminReply = await call(`${prefix}/messages/${registered.data.user.id}`, { method: 'POST', token: adminToken, body: { text: 'Tin nhắn admin kiểm tra Messenger thật.' } });
  assert.equal(adminReply.status, 201, 'admin can send a real direct message');
  const userRoomAfterReply = await call(`${prefix}/messages/${created.data.admin.id}`, { token });
  assert.ok(userRoomAfterReply.data.messages.some(message => /Tin nhắn admin kiểm tra Messenger thật/.test(message.text)), 'the admin reply is visible in the chat room');
}

test('Node backend: purchase requests are persisted, rate-limited, admin-only to approve, and open Messenger', async t => {
  const dataDir = await fs.mkdtemp(path.join(os.tmpdir(), 'vila-purchase-'));
  let srv;
  try {
    try { srv = await startNodeBackend(dataDir); } catch (error) {
      if (error?.code === 'ERR_MODULE_NOT_FOUND' && /express|chess\.js|Cannot find package/.test(String(error.message))) { t.skip(`Node backend integration unavailable in this incomplete node_modules: ${error.message}`); return; }
      throw error;
    }
    await exerciseRequestFlow(srv.call, '');
    const raw = JSON.parse(await fs.readFile(path.join(dataDir, 'social-store.json'), 'utf8'));
    assert.equal(raw.purchaseRequests.length, 2, 'requests persist on the server');
    assert.ok(raw.audit.some(item => item.action === 'purchase_request_pro_approved'));
  } finally {
    if (srv?.server) await new Promise(resolve => srv.server.close(resolve));
    if (srv?.envBackup) {
      for (const [key, value] of Object.entries(srv.envBackup)) { if (value === undefined) delete process.env[key]; else process.env[key] = value; }
    }
    await fs.rm(dataDir, { recursive: true, force: true });
  }
});

test('Cloudflare Worker: purchase requests survive the backend flow and never sell Premium automatically', async () => {
  const harness = createWorkerHarness({ ADMIN_USERNAME, ADMIN_PASSWORD });
  await exerciseRequestFlow((route, options = {}) => workerCall(harness, `/api/social${route}`, options), '');
  harness.restart();
  const login = await workerCall(harness, '/api/social/auth/login', { method: 'POST', body: { username: ADMIN_USERNAME, password: ADMIN_PASSWORD } });
  assert.equal(login.status, 200);
  const all = await workerCall(harness, '/api/social/admin/purchase-requests?status=all', { token: login.data.token });
  assert.equal(all.status, 200);
  assert.equal(all.data.requests.length, 2, 'Cloudflare durable state retains processed requests after restart');
  assert.ok(all.data.requests.some(item => item.status === 'approved'));
  assert.ok(all.data.requests.some(item => item.status === 'contacted'));
  const conversations = await workerCall(harness, '/api/social/messages/conversations', { token: login.data.token });
  assert.ok(conversations.data.conversations.length >= 1, 'Messenger conversations survive a Worker restart');
  const buyer = conversations.data.conversations.find(item => item.user.username === 'buyerone');
  assert.ok(buyer, 'purchase requester remains in the admin inbox after restart');
  const room = await workerCall(harness, `/api/social/messages/${encodeURIComponent(buyer.user.id)}`, { token: login.data.token });
  assert.ok(room.data.messages.some(item => /ĐỀ NGHỊ PREMIUM/.test(item.text)), 'the Premium proposal persists as a Messenger message');
  assert.ok(room.data.messages.some(item => /VILA Admin · trợ lý/.test(item.text)), 'the bot reply persists as a Messenger message');
  assert.ok(room.data.messages.some(item => /Tin nhắn admin kiểm tra Messenger thật/.test(item.text)), 'the admin’s manual direct reply persists after restart');

  const rateHarness = createWorkerHarness({ ADMIN_USERNAME, ADMIN_PASSWORD });
  const rateBuyer = await workerCall(rateHarness, '/api/social/auth/register', { method: 'POST', body: registerBody('limitbuyer') });
  assert.equal(rateBuyer.status, 201);
  for (let i = 0; i < 8; i++) {
    const response = await workerCall(rateHarness, '/api/social/me/purchase-requests', { method: 'POST', token: rateBuyer.data.token, body: { plan: 'pro', amountVnd: 1000 } });
    assert.ok([200, 201].includes(response.status), `request ${i + 1} should be allowed, got ${response.status}`);
  }
  assert.equal((await workerCall(rateHarness, '/api/social/me/purchase-requests', { method: 'POST', token: rateBuyer.data.token, body: { plan: 'pro', amountVnd: 1000 } })).status, 429, 'ninth purchase request in an hour is rejected by the server rate limit');
});
