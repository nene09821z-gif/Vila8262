import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DEFAULT_BACKEND_URL } from '../src/settings-schema.js';

const worker = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
const wrangler = fs.readFileSync(new URL('../cloudflare/wrangler.toml', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../cloudflare/package.json', import.meta.url), 'utf8'));

test('app URL and Cloudflare Worker name point to the same fixed endpoint', () => {
  assert.equal(DEFAULT_BACKEND_URL, 'https://bitter-sun-751a.nene09821z.workers.dev');
  assert.match(wrangler, /^name = "bitter-sun-751a"/m);
  assert.match(wrangler, /name = "CHESS_STATE"\s+class_name = "ChessState"/);
  assert.match(wrangler, /\[exports\.ChessState\]/);
  assert.match(wrangler, /storage = "sqlite"/);
});

test('cloud backend has durable serialized requests, password hashing, signed sessions and legal server-side moves', () => {
  assert.match(worker, /class ChessState/);
  assert.match(worker, /this\.serial = task\.then/);
  assert.match(worker, /CREATE TABLE IF NOT EXISTS vila_records/);
  assert.match(worker, /transactionSync\(\(\) =>/);
  assert.match(worker, /PBKDF2/);
  assert.match(worker, /subtle\.sign\('HMAC'/);
  assert.match(worker, /chess\.move\(/);
  assert.match(worker, /finishMatch\(this\.db, match/);
  assert.match(worker, /ranked\/queue/);
  assert.match(worker, /ranked\/status/);
  assert.match(worker, /ranked\/cancel-queue/);
  assert.match(worker, /api\/lichess\/account/, 'legacy Lichess account proxy remains available');
  assert.match(worker, /api\/openings\/explorer/, 'Opening Explorer remains available through the default backend');
  assert.match(worker, /puzzle-proxy/, 'health advertises online puzzle proxy support');
  assert.match(worker, /api\/puzzle\/daily/, 'online puzzle daily route proxies Lichess');
  assert.match(worker, /\['all', 300, 60_000\]/, 'community requests have a global abuse limit');
  assert.match(worker, /API chưa được hỗ trợ trong backend Cloudflare này/);
  assert.match(worker, /PBKDF2/);
});

test('Cloudflare deploy package resolves chess legality library and offers a deployment command', () => {
  assert.equal(pkg.dependencies['chess.js'], '1.4.0');
  assert.equal(pkg.scripts.deploy, 'wrangler deploy');
  assert.equal(pkg.scripts.check, 'node --check src/index.js');
});
