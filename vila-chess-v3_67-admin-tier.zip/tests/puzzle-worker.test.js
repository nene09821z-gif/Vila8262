import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const client = fs.readFileSync(new URL('../src/puzzle-worker-client.js', import.meta.url), 'utf8');
const worker = fs.readFileSync(new URL('../src/puzzle-worker.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');

test('Puzzle tactical search is routed through a module worker, not called from the UI directly', () => {
  assert.match(main, /generateOfflinePuzzleInWorker as generateOfflinePuzzle/);
  assert.match(client, /new Worker\(new URL\('\.\/puzzle-worker\.js', import\.meta\.url\), \{ type: 'module' \}\)/);
  assert.match(worker, /await generateOfflinePuzzle\(options \|\| \{\}\)/);
  assert.doesNotMatch(main, /from '\.\/puzzle-generator\.js'/);
});

test('Slow or unsupported WebViews get a fast verified puzzle fallback instead of a long UI freeze', () => {
  assert.match(client, /createFallbackMatePuzzle/);
  assert.match(client, /Math\.max\(3500, Math\.min\(8500/);
  assert.match(client, /timedOutWorker\?\.terminate\(\)/);
});

test('Every board palette from the cosmetic catalogue has explicit theme variables', () => {
  for (const theme of ['classic', 'ocean', 'walnut', 'midnight', 'violet', 'rose', 'ice', 'forest']) {
    assert.match(css, new RegExp(`html\\[data-board-theme="${theme}"\\]\\{--board-light:`));
  }
});
