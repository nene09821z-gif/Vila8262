import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolveEngineProfile, nextEngineFallback, engineAssetFile, describeEngineProfile } from '../src/engine-profile.js';
import { normalizeSettings } from '../src/settings-schema.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('Stockfish 10 profile resolves, loads stockfish-10.js and falls back to Lite then ASM-JS', () => {
  assert.equal(resolveEngineProfile('sf10'), 'sf10');
  assert.equal(engineAssetFile('sf10'), 'stockfish-10.js');
  assert.equal(nextEngineFallback('sf10'), 'lite-single');
  assert.equal(nextEngineFallback('lite-single'), 'asm');
  assert.equal(resolveEngineProfile('auto'), 'lite-single');
  assert.match(describeEngineProfile('sf10'), /Stockfish 10/);
});

test('settings accept the sf10 engine and still reject unknown values', () => {
  assert.equal(normalizeSettings({ botEngine: 'sf10', botEnginePreferenceSet: true }).botEngine, 'sf10');
  assert.equal(normalizeSettings({ botEngine: 'sf11' }).botEngine, 'auto');
});

test('Stockfish 10 stays available to the engine loader (no engine picker in Settings any more)', () => {
  const main = read('src/main.js');
  assert.doesNotMatch(main, /id="botEngineSetting"/, 'Settings must not expose a Stockfish download/engine picker');
  assert.match(main, /selectedEngine === 'sf10'/);
  assert.match(main, /splitUciOutput\(output\)/, 'main engine worker must split multiline Stockfish 10 UCI events');
});

test('package.json requires Stockfish 10 from the stockfish.js@10.0.2 npm package alias', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.dependencies['stockfish-10'], 'npm:stockfish.js@10.0.2');
  assert.equal(pkg.optionalDependencies?.['stockfish-10'], undefined);
});

function makeFixture({ withSf10 }) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-sf10-'));
  fs.mkdirSync(path.join(dir, 'scripts'), { recursive: true });
  fs.copyFileSync(path.join(root, 'scripts', 'copy-engine.mjs'), path.join(dir, 'scripts', 'copy-engine.mjs'));
  const sf19 = path.join(dir, 'node_modules', 'stockfish');
  fs.mkdirSync(sf19, { recursive: true });
  for (const name of ['stockfish-19-lite-single.js', 'stockfish-19-lite-single.wasm', 'stockfish-19-asm.js', 'Copying.txt']) fs.writeFileSync(path.join(sf19, name), `fixture:${name}`);
  if (withSf10) {
    const sf10 = path.join(dir, 'node_modules', 'stockfish-10', 'src');
    fs.mkdirSync(sf10, { recursive: true });
    fs.writeFileSync(path.join(sf10, 'stockfish.js'), `// fixture\n${'x'.repeat(5000)}`);
    fs.writeFileSync(path.join(dir, 'node_modules', 'stockfish-10', 'COPYING'), `GNU GENERAL PUBLIC LICENSE\n${'license text '.repeat(50)}`);
  }
  return dir;
}
function run(dir, env = {}) {
  return spawnSync(process.execPath, [path.join(dir, 'scripts', 'copy-engine.mjs'), '--required'], {
    cwd: dir, encoding: 'utf8', timeout: 5000, env: { ...process.env, REQUIRE_STOCKFISH: '1', INCLUDE_STOCKFISH_FULL: '0', ...env }
  });
}

test('engine packager bundles Stockfish 10 when the Stockfish 10 package exists', t => {
  const dir = makeFixture({ withSf10: true });
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const result = run(dir);
  assert.equal(result.status, 0, `${result.stdout}\n${result.stderr}`);
  assert.ok(fs.existsSync(path.join(dir, 'public', 'engine', 'stockfish-10.js')));
  assert.ok(fs.existsSync(path.join(dir, 'public', 'engine', 'STOCKFISH-10-LICENSE.txt')));
  const manifest = JSON.parse(fs.readFileSync(path.join(dir, 'public', 'engine', 'engine-manifest.json'), 'utf8'));
  assert.equal(manifest.sf10, true);
  assert.equal(manifest.sf10Version, '10.0.2');
});

test('engine packager still succeeds without Stockfish 10, but REQUIRE_STOCKFISH_10=1 makes it fail', t => {
  const dir = makeFixture({ withSf10: false });
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const ok = run(dir);
  assert.equal(ok.status, 0, `${ok.stdout}\n${ok.stderr}`);
  assert.equal(fs.existsSync(path.join(dir, 'public', 'engine', 'stockfish-10.js')), false);
  assert.equal(JSON.parse(fs.readFileSync(path.join(dir, 'public', 'engine', 'engine-manifest.json'), 'utf8')).sf10, false);
  assert.equal(run(dir, { REQUIRE_STOCKFISH_10: '1' }).status, 1);
});

test('service worker caches shell + engines tolerantly and never intercepts API or cross-origin calls', () => {
  const sw = read('public/sw.js');
  assert.match(sw, /Promise\.allSettled/);
  assert.match(sw, /stockfish-10\.js/);
  assert.match(sw, /stockfish-19-lite-single\.wasm/);
  assert.match(sw, /url\.origin !== self\.location\.origin/);
  assert.match(sw, /\/api\//);
  assert.match(sw, /request\.method !== 'GET'/);
  const main = read('src/main.js');
  assert.match(main, /serviceWorker\.register/);
  assert.match(main, /import\.meta\.env\.PROD/);
});

test('required Stockfish 10 build with missing GPL license fails closed without deleting already bundled engines', t => {
  const dir = makeFixture({ withSf10: true });
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const license = path.join(dir, 'node_modules', 'stockfish-10', 'COPYING');
  fs.unlinkSync(license);
  const engineDir = path.join(dir, 'public', 'engine');
  fs.mkdirSync(engineDir, { recursive: true });
  const marker = path.join(engineDir, 'stockfish-19-lite-single.js');
  fs.writeFileSync(marker, 'previous-good-engine');

  const result = run(dir, { REQUIRE_STOCKFISH_10: '1' });
  assert.equal(result.status, 1, `${result.stdout}\n${result.stderr}`);
  assert.match(`${result.stdout}\n${result.stderr}`, /license file was not/i);
  assert.equal(fs.readFileSync(marker, 'utf8'), 'previous-good-engine', 'a failed build must preserve prior engine assets');
});
