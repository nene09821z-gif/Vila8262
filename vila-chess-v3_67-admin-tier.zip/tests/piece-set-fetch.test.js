import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = name => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');

test('open artwork sets are license-scoped, locally bundled during build, and safely cached offline', () => {
  const fetcher = read('scripts/fetch-piece-sets.mjs');
  const pieces = read('src/pieces.js');
  const sw = read('public/sw.js');
  const credits = read('public/piece-sets/CREDITS.md');
  for (const id of ['fantasy', 'spatial', 'celtic', 'chessnut', 'rhosgfx', 'kiwen-suwi', 'firi', 'totoy', 'shapes']) {
    assert.match(fetcher, new RegExp(`id: '${id}'`));
    assert.match(pieces, new RegExp(`id: '${id}'`));
    assert.match(sw, new RegExp(`'${id}'`));
    assert.ok(credits.toLowerCase().includes(id));
  }
  assert.match(fetcher, /<script\\b|<foreignObject\\b|javascript:/);
  assert.match(fetcher, /REQUIRE_PIECE_SETS/);
  assert.match(fetcher, /downloaded\.size !== total/);
  assert.match(sw, /\.svg/);
  assert.match(sw, /LICENSED_PIECE_FILES/);
  assert.match(read('package.json'), /fetch-piece-sets\.mjs/);
  for (const workflow of ['.github/workflows/build-android.yml', '.github/workflows/build-from-zip.yml']) {
    assert.match(read(workflow), /REQUIRE_PIECE_SETS: '1'/);
  }
});
