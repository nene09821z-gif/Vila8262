import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { slideDurationMs, slideKeyframes, premoveGhostPieces, SLIDE_EASING } from '../src/board-motion.js';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const read = (rel) => readFileSync(join(root, rel), 'utf8');

test('slideDurationMs clamps and grows with distance', () => {
  const short = slideDurationMs(20, 0);
  const long = slideDurationMs(400, 0);
  assert.ok(short >= 160 && short <= 280);
  assert.ok(long >= short);
  assert.ok(long <= 280);
});

test('slideKeyframes start offset and end at rest', () => {
  const frames = slideKeyframes(40, -20);
  assert.equal(frames[0].translate, '40px -20px');
  assert.equal(frames[1].translate, '0px 0px');
  assert.ok(SLIDE_EASING.includes('cubic-bezier'));
});

// chess.js is a normal dependency (npm install). When it is missing the logic tests are reported
// as skipped instead of silently passing.
let ChessCtor = null;
try { ({ Chess: ChessCtor } = await import('chess.js')); } catch { /* optional in minimal sandboxes */ }
const withChess = ChessCtor ? test : test.skip;

test('premoveGhostPieces ignores missing board, bad colour and empty queues', () => {
  assert.equal(premoveGhostPieces(null, 'w', [], null).size, 0);
  assert.equal(premoveGhostPieces({ fen: () => '' }, 'x', [{ from: 'd2', to: 'd4' }], function Fake() {}).size, 0);
});

withChess('premoveGhostPieces maps the destination of a simple pawn premove', () => {
  const game = new ChessCtor();
  game.move('e2e4'); // White moved; Black is "thinking" and White (the human) queues d2-d4.
  const before = game.fen();
  const ghosts = premoveGhostPieces(game, 'w', [{ from: 'd2', to: 'd4' }], ChessCtor);
  assert.equal(ghosts.size, 1);
  assert.deepEqual(ghosts.get('d4'), { type: 'p', color: 'w' });
  assert.equal(game.fen(), before, 'the real game must not be modified');
});

withChess('premoveGhostPieces follows a chain of premoves and stops at the first illegal one', () => {
  const game = new ChessCtor();
  game.move('e2e4');
  const chain = premoveGhostPieces(game, 'w', [{ from: 'd2', to: 'd4' }, { from: 'd4', to: 'd5' }], ChessCtor);
  assert.deepEqual([...chain.keys()].sort(), ['d4', 'd5']);
  const stopped = premoveGhostPieces(game, 'w', [{ from: 'g1', to: 'f3' }, { from: 'a1', to: 'a5' }], ChessCtor);
  assert.deepEqual([...stopped.keys()], ['f3']);
  assert.equal(stopped.get('f3').type, 'n');
});

withChess('premoveGhostPieces promotes to a queen by default and honours an explicit piece', () => {
  const game = new ChessCtor('8/P6k/8/8/8/8/8/K7 b - - 0 1');
  assert.equal(premoveGhostPieces(game, 'w', [{ from: 'a7', to: 'a8' }], ChessCtor).get('a8').type, 'q');
  assert.equal(premoveGhostPieces(game, 'w', [{ from: 'a7', to: 'a8', promotion: 'n' }], ChessCtor).get('a8').type, 'n');
});

test('main.js wires board-motion slide and premove ghosts', () => {
  const main = read('src/main.js');
  assert.match(main, /board-motion\.js/);
  assert.match(main, /slideDurationMs/);
  assert.match(main, /premoveGhostPieces/);
  assert.match(main, /premove-ghost/);
  // Motion styles are consolidated into the canonical stylesheet imported by main.js.
  assert.match(main, /vila-professional\.css/);
  const css = read('src/board-motion.css');
  assert.match(css, /\.drag-ghost/);
  assert.match(css, /\.premove-ghost/);
});

test('premove ghost fades the queued piece instead of drawing a duplicate on an empty square', () => {
  const main = read('src/main.js');
  // The premove view already holds the piece on its destination square, so the ghost must decorate
  // that piece; the old `!piece && premoveGhostMap.has(sq)` branch never fired (or duplicated pieces).
  assert.doesNotMatch(main, /!piece && premoveGhostMap\.has\(sq\)/);
  assert.match(main, /piece\.type === ghostInfo\.type && piece\.color === ghostInfo\.color/);
  assert.match(main, /\$\{ghost \? ' premove-ghost' : ''\}/);
});

test('landing flash only plays on the render right after a move, not on every re-render', () => {
  const main = read('src/main.js');
  assert.match(main, /landingFlash = \{ fen: slide\.fen, until: Date\.now\(\) \+ 500 \}/);
  assert.match(main, /landingFlash\.fen === game\.fen\(\) && Date\.now\(\) < landingFlash\.until/);
});

test('sliding squares keep a z-index above neighbours and skip heavy shadows on small screens', () => {
  const css = read('src/board-motion.css');
  assert.match(css, /\.square\.sliding \{\s*z-index: 9;/);
  assert.match(css, /@media \(max-width: 680px\)[\s\S]*?\.piece\.is-sliding \{\s*filter: none;/);
});
