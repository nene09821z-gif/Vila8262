import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { ALTERNATE_ENGINE_PROFILES, analyzeAlternateMove, chooseAlternateMove } from '../src/alternate-engine.js';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

test('each independent offline engine returns a legal move from the start position', () => {
  for (const profile of ['lc0', 'ethereal', 'berserk', 'fortress', 'endgame', 'dynamic', 'blitz']) {
    const uci = chooseAlternateMove(START, { profile, maxNodes: 1800, maxTimeMs: 150, depth: 2 });
    assert.match(uci || '', /^[a-h][1-8][a-h][1-8][qrbn]?$/i, `${profile} should return a UCI move`);
    const chess = new Chess(START);
    const applied = chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) });
    assert.ok(applied, `${profile} move should be legal`);
  }
});

test('invalid FEN and game-over positions safely return null', () => {
  assert.equal(chooseAlternateMove('not a fen', { profile: 'lc0' }), null);
  const mate = new Chess();
  for (const san of ['f3', 'e5', 'g4', 'Qh4#']) mate.move(san);
  assert.equal(chooseAlternateMove(mate.fen(), { profile: 'berserk' }), null);
});

test('each profile owns distinct evaluation code and sensible mobile budgets', () => {
  assert.equal(ALTERNATE_ENGINE_PROFILES.lc0.style, 'positional');
  assert.equal(ALTERNATE_ENGINE_PROFILES.ethereal.style, 'tactical');
  assert.equal(ALTERNATE_ENGINE_PROFILES.berserk.style, 'aggressive');
  assert.ok(ALTERNATE_ENGINE_PROFILES.lc0.defaultDepth >= 6);
  assert.ok(ALTERNATE_ENGINE_PROFILES.ethereal.maxNodes >= 30000);
  assert.match(ALTERNATE_ENGINE_PROFILES.lc0.name, /Leela-style/);
});

test('search exposes its completed depth and does not return an illegal best move', () => {
  const result = analyzeAlternateMove(START, { profile: 'ethereal', depth: 3, maxNodes: 4000, maxTimeMs: 250 });
  assert.ok(result && result.uci);
  assert.ok(result.depth >= 1 && result.depth <= 3);
  const chess = new Chess(START);
  const move = result.uci;
  assert.ok(chess.move({ from: move.slice(0, 2), to: move.slice(2, 4), ...(move[4] ? { promotion: move[4] } : {}) }));
});

test('search reports nodes-per-second so the UI can show engine speed', () => {
  const result = analyzeAlternateMove(START, { profile: 'blitz', depth: 3, maxNodes: 3000, maxTimeMs: 200 });
  assert.ok(result.nodes > 0);
  assert.ok(Number.isFinite(result.nps) && result.nps > 0);
  assert.ok(result.elapsedMs >= 1);
});
