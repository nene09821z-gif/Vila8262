import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = name => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');

test('v3.67.0 settings controls are present and wired to validated persistence', () => {
  const pkg = JSON.parse(read('package.json'));
  const schema = read('src/settings-schema.js');
  const visual = read('src/visual-settings.js');
  const main = read('src/main.js');
  assert.equal(pkg.version, '3.67.0');
  for (const id of ['settingsBotStrength', 'settingsBotEngine', 'settingsBotDepth', 'settingsBotMoveTime', 'settingsReviewQuality', 'settingsClockPreset', 'settingsOpeningBook', 'settingsSoundTheme', 'showCoordinatesSetting', 'premoveEnabledSetting', 'showCapturedMaterialSetting', 'confirmResignSetting']) {
    assert.ok(main.includes(`id="${id}"`), `missing setting control ${id}`);
  }
  assert.match(schema, /soundTheme:\s*'soft'/);
  assert.match(schema, /\['soft', 'wood', 'neon', 'mute'\]/);
  for (const key of ['showCoordinates', 'premoveEnabled', 'showCapturedMaterial', 'confirmResign']) assert.match(visual, new RegExp(`${key}:`));
  assert.match(main, /settingsOpeningBook/);
  assert.match(main, /settings\.openingBookEnabled\s*=\s*Boolean\(event\.target\.checked\)/);
});

test('match exits and results use the branded confirmation/result modal', () => {
  const main = read('src/main.js');
  const css = read('src/vila-professional.css');
  assert.match(main, /function showBrandedConfirm\(/);
  assert.match(main, /result-modal-brand/);
  assert.match(main, /onConfirm:\s*\(\)\s*=>\s*openMatchSetup\(true\)/);
  assert.match(main, /onConfirm:\s*\(\)\s*=>\s*resignCurrentGame\(true\)/);
  assert.match(main, /confirmLabel:\s*'Xác nhận đầu hàng'/);
  assert.match(css, /\.result-modal-brand/);
  assert.match(css, /\.vila-confirm-modal/);
});

test('online matchmaking uses clean SVG 3D tiles instead of the old sword glyph', () => {
  const main = read('src/main.js');
  const onlineView = main.slice(main.indexOf('function renderRankedView()'), main.indexOf('function renderRankedBoard'));
  assert.match(onlineView, /uiTile\('users', 'cyan', 'tile-lg'\)/);
  assert.match(onlineView, /uiTile\('globe', 'cyan', 'tile-lg'\)/);
  assert.doesNotMatch(onlineView, /rankedQueueStart">⚔/);
  assert.match(read('src/vila-professional-theme.css'), /ranked-queue-orbit \.ui-tile/);
});

test('Pro/Premium request still posts to server and switches to the admin chat', () => {
  const main = read('src/main.js');
  const start = main.indexOf('async function requestPlanWithAdmin');
  const block = main.slice(start, main.indexOf('\nfunction ', start + 10));
  assert.match(block, /socialApi\('\/me\/purchase-requests'/);
  assert.match(block, /result\.admin\.id/);
  assert.match(block, /activeChatUserId\s*=\s*result\.admin\.id/);
  assert.match(block, /setView\('chat'\)/);
});
