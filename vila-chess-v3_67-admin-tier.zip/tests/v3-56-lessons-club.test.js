import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  LESSON_CATALOG, LESSON_CONTENT, parseFenBoard, fenToDiagramMarkup, findLessonChapter, lessonReaderMarkup
} from '../src/chesscom-ux.js';
import { DAILY_MISSIONS } from '../src/daily-progress.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('every lesson chapter has real content with a valid diagram position', () => {
  for (const lesson of LESSON_CATALOG) {
    for (const chapter of lesson.chapters) {
      const key = `${lesson.id}/${chapter.id}`;
      const content = LESSON_CONTENT[key];
      assert.ok(content, `${key} has content`);
      assert.ok(content.intro.length > 30 && content.points.length >= 3 && content.caption.length > 10, `${key} text is substantive`);
      const board = parseFenBoard(content.fen);
      assert.ok(board, `${key} FEN parses`);
      const pieces = board.flat().filter(Boolean);
      assert.equal(pieces.filter(p => p === 'K').length, 1, `${key} has one white king`);
      assert.equal(pieces.filter(p => p === 'k').length, 1, `${key} has one black king`);
      assert.match(content.fen, / [wb] /, `${key} has a side to move`);
      assert.equal((fenToDiagramMarkup(content.fen).match(/lesson-sq/g) || []).length, 64);
    }
  }
  assert.deepEqual(Object.keys(LESSON_CONTENT).sort(), LESSON_CATALOG.flatMap(l => l.chapters.map(c => `${l.id}/${c.id}`)).sort());
});

test('FEN parser rejects malformed boards and the reader escapes text', () => {
  assert.equal(parseFenBoard('8/8/8/8/8/8/8 w'), null);
  assert.equal(parseFenBoard('9/8/8/8/8/8/8/8 w'), null);
  assert.equal(parseFenBoard('xx6/8/8/8/8/8/8/8 w'), null);
  assert.equal(fenToDiagramMarkup('nonsense'), '');
  assert.equal(lessonReaderMarkup('nope/none'), '');
  assert.equal(findLessonChapter('rules-basics/king').chapter.id, 'king');
  const html = lessonReaderMarkup('tactics-1/fork', true);
  assert.match(html, /Đã hoàn thành/);
  assert.match(html, /id="lessonBackBtn"/);
});

test('club and lessons are real routed views (not code stranded inside the social login callback)', () => {
  const main = read('src/main.js');
  const callback = main.split('\n').find(line => line.startsWith('function adoptSocialCallback()')) || '';
  assert.ok(!/lessons|club/.test(main.slice(main.indexOf('function adoptSocialCallback()'), main.indexOf('let ratedGameSignature'))), 'login callback no longer contains view markup');
  assert.ok(callback.length > 0);
  assert.match(main, /else if \(currentView === 'lessons'\) root\.innerHTML = renderLessonsView\(\)/);
  assert.match(main, /else if \(currentView === 'club'\) root\.innerHTML = renderClubView\(\)/);
  assert.match(main, /if \(currentView === 'lessons'\) wireLessonsActions\(\)/);
  assert.match(main, /if \(currentView === 'club'\) wireClubActions\(\)/);
  const html = read('index.html');
  assert.match(html, /data-view="club"/);
  assert.match(html, /data-view="lessons"/);
  assert.match(main, /import '\.\/vila-professional\.css'/);
  assert.match(read('src/vila-professional.css'), /Professional stylesheet layer: lessons\.css/);
});

test('finishing a lesson counts for a daily mission and no dead guarded globals remain', () => {
  assert.ok(DAILY_MISSIONS.some(m => m.event === 'lesson_done'));
  const main = read('src/main.js');
  assert.ok(!/typeof selectedClockPreset/.test(main));
  assert.ok(!/typeof applyBoardTheme/.test(main));
});
