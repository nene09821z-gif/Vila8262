import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const main = read('src/main.js');
const settingsView = main.slice(main.indexOf('function accountSettingsMarkup()'), main.indexOf('function wireCommonActions()'));

test('Settings has an account section: display name, email link, password change, logout', () => {
  for (const id of ['accountNameForm', 'accountEmailForm', 'accountPasswordForm', 'accountLogout', 'accountLogin']) {
    assert.match(settingsView, new RegExp(`id="${id}"`), id);
  }
  assert.match(main, /socialApi\('\/account\/password', \{ method: 'PATCH'/);
  assert.match(main, /socialApi\('\/account\/email', \{ method: 'PATCH'/);
  assert.match(main, /saveSocialSession\(data\.token \|\| socialState\.token/);
});

test('Settings no longer exposes Stockfish download or engine tuning controls', () => {
  assert.doesNotMatch(settingsView, /botEngineSetting|botSkillSetting|botDepthSetting|botMoveTimeSetting|analysisMoveTimeSetting|reviewQualitySetting|botEloPresets|saveSettings|resetSettings/);
  assert.doesNotMatch(main, /function saveSettingsForm/);
  // The engine still starts silently at boot, and its status chip only shows when a manual retry is needed.
  assert.match(main, /\ninitEngine\(\);/);
  assert.match(read('src/chesscom-polish.css'), /#engineStatus:not\(\.failed\) \{ display: none !important; \}/);
});

test('Both backends expose password and email endpoints that need the current password', () => {
  for (const file of ['cloudflare/src/index.js', 'server/social.js']) {
    const text = read(file);
    assert.match(text, /\/account\/password/, file);
    assert.match(text, /\/account\/email/, file);
    assert.match(text, /password_changed/, file);
    assert.match(text, /selfUser\(/, file);
  }
  // Other players must never receive the email address.
  assert.doesNotMatch(read('cloudflare/src/index.js').slice(read('cloudflare/src/index.js').indexOf('function publicUser'), read('cloudflare/src/index.js').indexOf('/** The signed-in player')), /email/);
});

test('chess.js is wrapped with a per-position cache to avoid O(n) history/pgn/isGameOver work', async () => {
  assert.match(main, /createCachedChess\(BaseChess\)/);
  const { createCachedChess } = await import('../src/cached-chess.js');
  let calls = { history: 0, pgn: 0, isGameOver: 0 };
  class Fake {
    constructor() { this.moves = []; }
    move(m) { this.moves.push(m); return m; }
    undo() { return this.moves.pop(); }
    history() { calls.history += 1; return [...this.moves]; }
    pgn() { calls.pgn += 1; return this.moves.join(' '); }
    isGameOver() { calls.isGameOver += 1; return this.moves.length > 2; }
  }
  const Cached = createCachedChess(Fake);
  const game = new Cached();
  game.move('e4');
  assert.deepEqual(game.history(), ['e4']);
  game.history(); game.history(); game.pgn(); game.pgn(); game.isGameOver(); game.isGameOver();
  assert.deepEqual(calls, { history: 1, pgn: 1, isGameOver: 1 });
  game.history().push('mutation');
  assert.deepEqual(game.history(), ['e4'], 'callers must not be able to corrupt the cache');
  game.move('e5'); game.move('Nf3');
  assert.deepEqual(game.history(), ['e4', 'e5', 'Nf3']);
  assert.equal(game.isGameOver(), true);
  game.undo();
  assert.equal(game.isGameOver(), false, 'undo must invalidate the cache');
  assert.equal(game.pgn(), 'e4 e5');
});
