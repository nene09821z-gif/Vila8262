import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeGameAccuracy,
  buildReviewDashboard,
  BOT_ELO_PRESETS,
  resolveBotEloPreset,
  botThinkDelayMs,
  matchActionBarEnabled,
  matchActionBarMarkup,
  puzzleStreakLabel,
  puzzleNextButtonLabel,
  BOARD_THEME_CATALOG,
  SOUND_THEME_CATALOG,
  resolveBoardTheme,
  resolveSoundTheme,
  matchmakingStatusText,
  openingExplorerContinuations,
  openingExplorerMarkup,
  LESSON_CATALOG,
  lessonProgressSummary,
  clubHomeMarkup,
  friendChallengePayload,
  spectatorRoomLabel,
  boardSquareClasses
} from '../src/chesscom-ux.js';

test('computeGameAccuracy weights judgements into side percentages', () => {
  const rows = [
    { color: 'w', judgement: { key: 'best' } },
    { color: 'w', judgement: { key: 'blunder' } },
    { color: 'b', judgement: { key: 'excellent' } },
    { color: 'b', judgement: { key: 'good' } },
    { color: 'w', judgement: { key: 'unrated' } }
  ];
  const acc = computeGameAccuracy(rows);
  assert.equal(acc.white, 50); // (1 + 0) / 2
  assert.equal(acc.black, 90); // (0.95 + 0.85) / 2 ≈ 0.9 → 90
  assert.ok(acc.combined >= 50 && acc.combined <= 90);
  assert.equal(acc.counts.blunder, 1);
});

test('buildReviewDashboard aggregates brilliancies and blunders', () => {
  const dash = buildReviewDashboard([
    { color: 'w', judgement: { key: 'brilliant' } },
    { color: 'b', judgement: { key: 'blunder' } },
    { color: 'w', judgement: { key: 'mistake' } }
  ], { title: 'Test', result: '1-0' });
  assert.equal(dash.brilliant, 1);
  assert.equal(dash.blunders, 1);
  assert.equal(dash.mistakes, 1);
  assert.equal(dash.result, '1-0');
});

test('bot elo presets resolve by id and nearest elo', () => {
  assert.equal(resolveBotEloPreset('expert').elo, 2000);
  assert.equal(resolveBotEloPreset(1180).id, 'club');
  assert.equal(BOT_ELO_PRESETS.length >= 6, true);
  const delay = botThinkDelayMs('beginner', () => 0);
  assert.ok(delay >= 400 && delay <= 900);
  const mid = botThinkDelayMs({ thinkMs: [100, 300] }, () => 0.5);
  assert.equal(mid, 200);
});

test('match action bar gates and markup', () => {
  assert.equal(matchActionBarEnabled({ gameStarted: true, gameOver: false }), true);
  assert.equal(matchActionBarEnabled({ gameStarted: false }), false);
  assert.equal(matchActionBarEnabled({ gameStarted: true, gameOver: true }), false);
  const html = matchActionBarMarkup({ gameStarted: true, gameOver: false });
  assert.match(html, /offerDrawBtn/);
  assert.match(html, /resignBtn/);
  assert.match(html, /cancelPremoveBtn/);
  assert.doesNotMatch(html, /disabled/);
  const off = matchActionBarMarkup({ gameStarted: false });
  assert.match(off, /disabled/);
});

test('puzzle streak and next labels', () => {
  assert.match(puzzleStreakLabel(5, 5), /kỷ lục mới/);
  assert.match(puzzleStreakLabel(0, 3), /kỷ lục 3/);
  assert.equal(puzzleNextButtonLabel('daily'), 'Luyện lại đề hôm nay');
  assert.equal(puzzleNextButtonLabel('rush'), 'Puzzle tiếp · Rush');
});

test('board and sound theme catalogs', () => {
  assert.ok(BOARD_THEME_CATALOG.length >= 6);
  assert.equal(resolveBoardTheme('forest').id, 'forest');
  assert.equal(resolveBoardTheme('nope').id, 'classic-green');
  assert.equal(resolveSoundTheme('mute').id, 'mute');
  assert.ok(SOUND_THEME_CATALOG.some(t => t.id === 'wood'));
});

test('matchmaking status text', () => {
  assert.match(matchmakingStatusText({ searching: false, elo: 1500 }), /Elo 1500/);
  assert.match(matchmakingStatusText({ searching: true, elo: 1200, queueSeconds: 12 }), /Đang tìm/);
  assert.match(matchmakingStatusText({ searching: true, mode: 'friendly', queueSeconds: 3 }), /bạn bè/);
});

test('opening explorer ranks continuations from catalog lines', () => {
  const openings = [
    { name: 'Italian', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] },
    { name: 'Spanish', eco: 'C60', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5'] },
    { name: 'Italian quiet', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'] }
  ];
  const root = openingExplorerContinuations([], openings, 5);
  assert.equal(root.continuations[0].san, 'e4');
  assert.equal(root.continuations[0].pct, 100);
  const after = openingExplorerContinuations(['e4', 'e5', 'Nf3', 'Nc6'], openings, 5);
  assert.ok(after.continuations.some(c => c.san === 'Bc4'));
  assert.ok(after.continuations.some(c => c.san === 'Bb5'));
  const html = openingExplorerMarkup(after);
  assert.match(html, /opening-explorer/);
  assert.match(html, /Bc4|Bb5/);
});

test('lessons progress and club/friend/spectator helpers', () => {
  assert.ok(LESSON_CATALOG.length >= 3);
  const summary = lessonProgressSummary({ 'rules-basics/king': true });
  assert.equal(summary.done, 1);
  assert.ok(summary.total > 1);
  assert.match(summary.label, /\//);
  const club = clubHomeMarkup({ name: 'ViLa Club', members: 12 });
  assert.match(club, /ViLa Club/);
  assert.match(club, /clubChallengeBtn/);
  assert.equal(friendChallengePayload({ from: 'a', to: 'a' }), null);
  const challenge = friendChallengePayload({ from: 'alice', to: 'bob', timeControl: '5+0', rated: true });
  assert.equal(challenge.type, 'friend-challenge');
  assert.equal(challenge.rated, true);
  assert.match(spectatorRoomLabel({ white: 'A', black: 'B', viewers: 3 }), /3 người xem/);
});

test('boardSquareClasses composes chess.com-like square states', () => {
  const cls = boardSquareClasses({
    isLastTo: true,
    isCheck: true,
    isPremoveFrom: true,
    smooth: true
  });
  assert.match(cls, /last-to/);
  assert.match(cls, /in-check/);
  assert.match(cls, /premove-from/);
  assert.match(cls, /anim-ready/);
});
