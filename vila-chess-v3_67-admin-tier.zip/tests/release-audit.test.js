import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const pkg = JSON.parse(read('package.json'));
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');

test('release metadata and browser cache keys consistently identify v3.67.0', () => {
  const html = read('index.html');
  const sw = read('public/sw.js');
  assert.equal(pkg.version, '3.67.0');
  assert.match(html, /ViLa Chess .*v3\.67\.0/);
  assert.match(sw, /const VERSION = 'covua-vila-v3\.67\.0'/);
  for (const href of ['./favicon.ico?v=353', './favicon-48.png?v=353', './favicon.png?v=353']) {
    assert.ok(html.includes(href), `index.html is missing ${href}`);
    assert.ok(sw.includes(href), `service-worker cache is missing ${href}`);
  }
  assert.doesNotMatch(html, /v=346(?:\D|$)/);
  assert.doesNotMatch(sw, /v=346(?:\D|$)/);
  assert.match(read('server/index.js'), /version: '3\.67\.0'/);
  assert.match(read('server/puzzle-service.js'), /VILA-Chess\/3\.67\.0 puzzle-proxy/);
});

test('the bundled offline opening fallback is non-empty, deduplicated, and honestly labelled', () => {
  const payload = JSON.parse(read('public/openings-eco.json'));
  assert.equal(payload.completeness, 'fallback-seed');
  assert.equal(payload.releaseReady, false);
  assert.equal(payload.minimumRequiredForRelease, 3000);
  assert.equal(payload.count, payload.openings.length);
  assert.ok(payload.openings.length >= 300, `expected a useful curated seed, received ${payload.openings.length}`);
  assert.ok(payload.openings.every(item => /^[A-E]\d{2}$/.test(item.eco)));
  assert.ok(payload.openings.every(item => typeof item.name === 'string' && item.name.trim()));
  assert.ok(payload.openings.every(item => Array.isArray(item.san) && item.san.length > 0 && item.san.length <= 60));
  const lines = payload.openings.map(item => item.san.join(' '));
  assert.equal(new Set(lines).size, lines.length, 'fallback should not include duplicate SAN lines');
  assert.doesNotMatch(payload.license, /CC0-1\.0/); // Do not mislabel project-curated data as Lichess data.
});

test('release scripts still require a complete 3,000-line validated Lichess catalog', () => {
  const prepare = read('scripts/prepare-openings.mjs');
  const verify = read('scripts/verify-opening-catalog.mjs');
  const workflow = read('.github/workflows/build-android.yml');
  const zipWorkflow = read('.github/workflows/build-from-zip.yml');
  assert.match(prepare, /const requiredCount = 3000/);
  assert.match(prepare, /REQUIRE_OPENING_CATALOG/);
  assert.match(verify, /const requiredCount = 3000/);
  assert.match(workflow, /REQUIRE_OPENING_CATALOG: '1'/);
  assert.match(workflow, /node scripts\/verify-opening-catalog\.mjs/);
  assert.match(zipWorkflow, /REQUIRE_OPENING_CATALOG: '1'/);
  assert.match(zipWorkflow, /node scripts\/verify-opening-catalog\.mjs/);
});

test('opening loader does not silently skip readiness checks when all JSON entries are duplicates', () => {
  const source = read('src/main.js');
  assert.match(source, /if \(additions\.length\) \{/);
  assert.match(source, /A non-empty JSON file can still be only the curated fallback or contain duplicates/);
  assert.match(source, /opening-catalog:below-threshold:/);
  assert.doesNotMatch(source, /if \(!additions\.length\) return 0;/);
});

test('changelog release headings are unique and ordered newest-first', () => {
  const changelog = read('CHANGELOG.md');
  const versions = [...changelog.matchAll(/^## v(\d+\.\d+\.\d+)\b/gm)].map(match => match[1]);
  assert.ok(versions.length >= 10);
  assert.equal(new Set(versions).size, versions.length, `duplicate changelog headings: ${versions.join(', ')}`);
  const numeric = versions.map(version => version.split('.').map(Number));
  for (let i = 1; i < numeric.length; i += 1) {
    const newer = numeric[i - 1];
    const older = numeric[i];
    assert.ok(newer[0] > older[0] || (newer[0] === older[0] && (newer[1] > older[1] || (newer[1] === older[1] && newer[2] > older[2]))), `${versions[i - 1]} should appear before ${versions[i]}`);
  }
});

test('README and puzzle-source documentation link to current QA and no longer claim v3.38 as current', () => {
  const readme = read('README.md');
  const puzzleSource = read('PUZZLES_SOURCE.md');
  assert.ok(fs.existsSync(path.join(root, 'TEST_REPORT_V3_46_1.md')));
  assert.ok(fs.existsSync(path.join(root, 'TEST_REPORT_V3_46_3.md')));
  assert.ok(fs.existsSync(path.join(root, 'TEST_REPORT_V3_46_4.md')));
  assert.ok(fs.existsSync(path.join(root, 'TEST_REPORT_V3_47_2.md')));
  assert.match(readme, /TEST_REPORT_V3_47_2\.md/);
  assert.match(readme, /TEST_REPORT_V3_46_4\.md/);
  assert.match(readme, /TEST_REPORT_V3_46_1\.md/);
  assert.ok(readme.indexOf('Bản vá v3.37.2') < readme.indexOf('Bản vá v3.37.1'));
  assert.match(puzzleSource, /VILA Chess v3\.67\.0/);
  assert.doesNotMatch(puzzleSource, /v3\.38\.0|6,157,341/);
});

test('GitHub source packer consolidates copied Android assets but preserves the canonical web and engine files', () => {
  const packer = read('scripts/package-github-source.py');
  const gradle = read('app/build.gradle.kts');
  assert.match(packer, /app\/src\/main\/assets/);
  assert.match(packer, /public_copy/);
  assert.match(packer, /ZIP_DEFLATED, compresslevel=9/);
  assert.match(packer, /public\/engine\/stockfish-10\.js/);
  assert.match(gradle, /stagePublicAssetsForAndroid/);
  assert.match(gradle, /from\(publicDir\)/);
  assert.match(gradle, /dependsOn\(stagePublicAssetsForAndroid\)/);
});

test('all twelve bundled chess-piece PNGs have valid headers/dimensions and current icon targets exist', () => {
  // PNG headers and dimensions are checked with a small stdlib parser; no image package is required.
  const pngSize = file => {
    const bytes = fs.readFileSync(file);
    assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${file} is not a PNG`);
    assert.ok(bytes.length > 1000, `${file} looks unexpectedly small`);
    return { width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) };
  };
  for (const color of ['w', 'b']) {
    for (const piece of ['p', 'n', 'b', 'r', 'q', 'k']) {
      const file = path.join(root, 'public', 'pieces', `${color}_${piece}.png`);
      assert.ok(fs.existsSync(file), `missing ${file}`);
      const { width, height } = pngSize(file);
      assert.ok(width > 0 && height > 0, `invalid dimensions for ${file}`);
    }
  }
  for (const asset of ['favicon.ico', 'favicon-48.png', 'favicon.png', 'covua-vila-icon.png', 'covua-vila-logo.webp', 'covua-vila-brand-icon.png', 'vila-memory-monument.webp', 'manifest.webmanifest']) {
    assert.ok(fs.existsSync(path.join(root, 'public', asset)), `missing icon target ${asset}`);
  }
  const html = read('index.html');
  assert.match(html, /class="wordmark3d"/);
  assert.match(html, /href="\.\/covua-vila-icon\.png\?v=353"/);
});
