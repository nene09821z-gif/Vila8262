import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { nativeBillingBridge, planPurchaseUi, verifyPurchase, createPurchaseQueue, billingErrorMessage, BILLING_EVENT } from '../src/billing-client.js';
import { refundPurchase, grantPlan, effectivePlan, daysLeft, DAY_MS } from '../src/plans.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const NOW = Date.UTC(2026, 9, 24);

test('bridge is null in a browser / old APK and wraps the native calls otherwise', () => {
  assert.equal(nativeBillingBridge({}), null);
  assert.equal(nativeBillingBridge({ AndroidBridge: { getPlatform() {} } }), null);
  const calls = [];
  const bridge = nativeBillingBridge({ AndroidBridge: { billingStart: (...a) => { calls.push(['start', ...a]); return true; }, billingInit: (...a) => calls.push(['init', ...a]), billingQueryOwned: () => calls.push(['owned']), billingFinish: (...a) => calls.push(['finish', ...a]), billingAvailable: () => true } });
  assert.equal(bridge.start('p', 'acc'), true);
  bridge.init(['a', 'b']); bridge.queryOwned(); bridge.finish('tok', 1);
  assert.deepEqual(calls, [['start', 'p', 'acc'], ['init', '["a","b"]'], ['owned'], ['finish', 'tok', true]]);
  const broken = nativeBillingBridge({ AndroidBridge: { billingStart() { throw new Error('boom'); } } });
  assert.equal(broken.start('p', 'a'), false, 'a throwing native call never crashes the web app');
});

test('purchase buttons: free can buy both, Pro can renew (and is nudged near expiry), Premium has nothing to buy', () => {
  assert.deepEqual(Object.values(planPurchaseUi('free')).map(x => x.show), [true, true]);
  assert.equal(planPurchaseUi('pro', 200).pro.expiringSoon, false);
  assert.equal(planPurchaseUi('pro', 14).pro.expiringSoon, true);
  assert.equal(planPurchaseUi('pro', 15).pro.expiringSoon, false);
  assert.match(planPurchaseUi('pro', 3).pro.label, /Gia hạn/);
  assert.deepEqual(Object.values(planPurchaseUi('premium')).map(x => x.show), [false, false]);
});

test('verifyPurchase: consumes Pro, acknowledges Premium, and only after the server accepted', async () => {
  const finished = [];
  const bridge = { finish: (...a) => finished.push(a) };
  const api = async (path, opts) => { assert.equal(path, '/me/purchase/verify'); const b = JSON.parse(opts.body); return { granted: true, plan: b.productId === 'pro' ? 'pro' : 'premium', consume: b.productId === 'pro', entitlement: { plan: 'x' } }; };
  assert.equal((await verifyPurchase({ api, bridge, purchase: { productId: 'pro', purchaseToken: 't1' } })).status, 'granted');
  await verifyPurchase({ api, bridge, purchase: { productId: 'premium', purchaseToken: 't2' } });
  assert.deepEqual(finished, [['t1', true], ['t2', false]]);
  const refused = async () => { throw Object.assign(new Error('no'), { status: 404 }); };
  finished.length = 0;
  await assert.rejects(verifyPurchase({ api: refused, bridge, purchase: { productId: 'pro', purchaseToken: 't3' } }));
  assert.deepEqual(finished, [], 'a purchase the server rejected is never consumed');
  const pending = await verifyPurchase({ api: async () => ({ pending: true, message: 'wait' }), bridge, purchase: { productId: 'pro', purchaseToken: 't4' } });
  assert.equal(pending.status, 'pending'); assert.deepEqual(finished, []);
  await assert.rejects(verifyPurchase({ api, bridge, purchase: { productId: '', purchaseToken: '' } }));
});

test('purchase queue: sequential, de-duplicates the same token, and allows a retry after a failure', async () => {
  const order = []; let fail = true;
  const api = async (_p, opts) => { const t = JSON.parse(opts.body).purchaseToken; order.push(`start:${t}`); await new Promise(r => setTimeout(r, t === 'a' ? 20 : 1)); order.push(`end:${t}`); if (t === 'flaky' && fail) { fail = false; throw Object.assign(new Error('x'), { status: 502 }); } return { granted: true, plan: 'pro', consume: true }; };
  const results = [], errors = [];
  const queue = createPurchaseQueue({ api, getBridge: () => ({ finish() {} }), onResult: (r, p) => results.push(p.purchaseToken), onError: (e, p) => errors.push(p.purchaseToken) });
  queue.push({ productId: 'p', purchaseToken: 'a' }); queue.push({ productId: 'p', purchaseToken: 'a' }); queue.push({ productId: 'p', purchaseToken: 'b' });
  await queue.push({ productId: 'p', purchaseToken: 'flaky' });
  assert.deepEqual(order.slice(0, 4), ['start:a', 'end:a', 'start:b', 'end:b'], 'no interleaving; duplicate dropped');
  assert.deepEqual(results, ['a', 'b']); assert.deepEqual(errors, ['flaky']);
  await queue.push({ productId: 'p', purchaseToken: 'flaky' });
  assert.deepEqual(results, ['a', 'b', 'flaky'], 'a failed verification can be retried (restore)');
});

test('error messages are specific and in Vietnamese', () => {
  for (const status of [503, 404, 403, 409, 401, 502]) assert.match(billingErrorMessage({ status }), /[a-zà-ỹ]/i);
  assert.notEqual(billingErrorMessage({ status: 404 }), billingErrorMessage({ status: 403 }));
});

test('refundPurchase removes exactly one Pro year, switches Premium off, keeps free-review usage', () => {
  let ent = grantPlan(grantPlan({ freeReviewsUsed: 1, freeReviewGameId: 'g' }, 'pro', NOW), 'pro', NOW);
  assert.equal(daysLeft(ent, NOW), 730);
  ent = refundPurchase(ent, 'pro', NOW);
  assert.equal(daysLeft(ent, NOW), 365);
  ent = refundPurchase(ent, 'pro', NOW);
  assert.equal(effectivePlan(ent, NOW), 'free'); assert.equal(ent.proExpiresAt, null); assert.equal(ent.freeReviewsUsed, 1);
  assert.equal(refundPurchase({ proExpiresAt: null }, 'pro', NOW).proExpiresAt, null);
  const mid = refundPurchase({ proExpiresAt: NOW + 100 * DAY_MS }, 'pro', NOW);
  assert.equal(mid.proExpiresAt, null, 'refunding a year that was mostly used cannot leave negative/odd time');
  assert.equal(effectivePlan(refundPurchase(grantPlan({}, 'premium'), 'premium'), NOW), 'free');
  assert.throws(() => refundPurchase({}, 'gold'));
});

test('static wiring: web app, Android bridge, Gradle dependency, Play Billing rules', () => {
  const main = read('src/main.js'), kt = read('app/src/main/java/com/example/PlayBilling.kt'), activity = read('app/src/main/java/com/example/MainActivity.kt'), gradle = read('app/build.gradle.kts');
  assert.match(main, /from '\.\/billing-client\.js'/);
  assert.match(main, /\/me\/billing-config/);
  assert.match(main, /data-plan-restore/);
  assert.doesNotMatch(main, /Thanh toán chưa được bật trong bản này/, 'the placeholder toast is gone');
  assert.match(gradle, /com\.android\.billingclient:billing:7\./);
  for (const name of ['billingAvailable', 'billingInit', 'billingStart', 'billingQueryOwned', 'billingFinish']) assert.match(activity, new RegExp(`fun ${name}\\(`));
  assert.match(kt, /setObfuscatedAccountId\(accountId\)/, 'purchase is bound to the account');
  assert.match(kt, /consumeAsync/); assert.match(kt, /acknowledgePurchase/);
  assert.match(kt, /ProductType\.INAPP/);
  assert.match(kt, new RegExp(BILLING_EVENT));
  assert.doesNotMatch(kt, /purchaseState == Purchase\.PurchaseState\.PURCHASED[\s\S]{0,80}grant/i, 'the app never grants a plan itself');
});
