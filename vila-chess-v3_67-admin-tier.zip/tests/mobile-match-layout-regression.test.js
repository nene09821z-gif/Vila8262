import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/style.css'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

test('new-player chooser is visible before the board on narrow screens', () => {
  assert.match(main, /function renderPrestartExperiencePanel\(\)/);
  assert.match(main, /<section class="prestart-experience-card"/);
  assert.match(main, /data-experience-choice="beginner">Mới chơi/);
  assert.match(main, /data-experience-choice="experienced">Đã hiểu luật/);
  assert.match(main, /\$\{renderPrestartExperiencePanel\(\)\}/);
  assert.match(css, /\.prestart-experience-card/);
  assert.match(main, /id="startGameOverlay"/);
});

test('changing views resets scroll and keeps the opponent card from hiding under the header', () => {
  assert.match(main, /const previousView = currentView/);
  assert.match(main, /if \(view !== previousView\) window\.scrollTo\(0, 0\)/);
  assert.match(main, /if \(returningToPlay\) window\.scrollTo\(0, 0\)/);
});

test('layout is versioned; bottom actions stay compact while the analysis palette floats independently', () => {
  assert.equal(pkg.version, '3.67.0');
  const v4 = fs.readFileSync(new URL('../src/vila-v4.css', import.meta.url), 'utf8');
  assert.match(v4, /body\.match-live \.match-action-bar button small/);
  assert.match(v4, /\.match-sheet \{ position: fixed/);
  assert.match(v4, /\.board-annotation-widget\{position:fixed!important/);
  assert.match(v4, /\.virtual-mouse-panel\{position:fixed/);
  assert.match(v4, /\.virtual-mouse-cursor/);
});
