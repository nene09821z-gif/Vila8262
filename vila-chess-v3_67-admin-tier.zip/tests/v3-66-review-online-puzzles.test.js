import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { LICHESS_PUZZLE_POOL_LIMIT, upsertPuzzlePool } from '../src/puzzle-pool.js';
const read = name => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');

test('review board has a separate SVG overlay for played and best-move arrows', () => {
  const main = read('src/main.js');
  const css = read('src/vila-professional.css');
  assert.match(main, /function reviewArrowLine\(/);
  assert.match(main, /review-arrow-\$\{kind\}/);
  assert.match(main, /reviewArrowHead-best/);
  assert.match(main, /nextBestMoveUci: currentBestUci/);
  assert.match(main, /ArrowLeft.*ArrowRight.*Home.*End/s);
  assert.match(css, /\.review-replay-arrows\{position:absolute/);
});

test('redeem-code input uses a mobile text keyboard and preserves input while request is pending', () => {
  const main = read('src/main.js');
  const form = main.slice(main.indexOf('function renderRedeemCodeView'), main.indexOf('function wirePlansActions'));
  assert.match(form, /id="redeemCodeInput" name="code" type="text"/);
  assert.match(form, /inputmode="text"/);
  assert.match(form, /input\.disabled = true/);
  assert.doesNotMatch(form, /trialCodeUiBusy = true; trialCodeUiNote = ''; trialCodeUiKind = ''; renderView\(\);/);
});

test('coach learning page queries the Lichess opening explorer through the existing API proxy', () => {
  const main = read('src/main.js');
  assert.match(main, /id="coachOnlineExplorer"/);
  assert.match(main, /apiFetch\(`\/api\/openings\/explorer\?moves=/);
  assert.match(main, /https:\/\/lichess\.org\/analysis/);
});

test('offline puzzle cache capacity is 500 and still deduplicates positions', () => {
  assert.equal(LICHESS_PUZZLE_POOL_LIMIT, 500);
  let pool = [];
  for (let n = 0; n < 520; n += 1) {
    const fen = `synthetic-position-${n} w - - 0 1`;
    pool = upsertPuzzlePool(pool, { fen, moves: ['a1a2'], cachedAt: n }, item => item.moves.length > 0);
  }
  assert.equal(pool.length, 500);
});
