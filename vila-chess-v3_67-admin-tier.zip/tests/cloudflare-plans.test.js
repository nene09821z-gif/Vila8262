import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

function createHarness(env = {}) {
  const records = new Map();
  const sql = {
    exec(statement, ...args) {
      if (/^CREATE TABLE/i.test(statement)) return [];
      if (/^SELECT key, value FROM vila_records/i.test(statement)) {
        return [...records.entries()].map(([key, value]) => ({ key, value }));
      }
      if (/^INSERT INTO vila_records/i.test(statement)) {
        records.set(String(args[0]), String(args[1]));
        return [];
      }
      if (/^DELETE FROM vila_records/i.test(statement)) {
        records.delete(String(args[0]));
        return [];
      }
      throw new Error(`SQL statement not covered by test harness: ${statement}`);
    }
  };
  const makeState = () => ({
    storage: { sql, transactionSync: callback => callback() },
    blockConcurrencyWhile: callback => callback()
  });
  let object = new ChessState(makeState(), env);
  const binding = {
    idFromName: () => 'vila-global-test',
    get: () => ({ fetch: request => object.fetch(request) })
  };
  return {
    binding,
    records,
    restart() { object = new ChessState(makeState(), env); }
  };
}

function makeRequest(path, { method = 'GET', token = '', body } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return new Request(`https://vila-test.workers.dev${path}`, {
    method,
    headers,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

async function call(harness, path, options = {}) {
  const response = await worker.fetch(makeRequest(path, options), { CHESS_STATE: harness.binding });
  const data = await response.json();
  return { status: response.status, data };
}


const ENV = { ADMIN_USERNAME: 'boss', ADMIN_PASSWORD: 'AdminPassword!12345' };
const relogin = async (h, name) => (await call(h, '/api/social/auth/login', { method: 'POST', body: { username: name, password: 'Password!1' } })).data.token;
const register = (h, name) => call(h, '/api/social/auth/register', { method: 'POST', body: { username: name, displayName: name, password: 'Password!1' } });
const review = (h, token, gameId) => call(h, '/api/social/me/review-access', { method: 'POST', token, body: { gameId } });
const grant = (h, adminToken, id, plan, action = 'grant') => call(h, `/api/social/admin/users/${id}/plan`, { method: 'PATCH', token: adminToken, body: { action, plan } });
async function adminLogin(h) {
  const r = await call(h, '/api/social/auth/login', { method: 'POST', body: { username: 'boss', password: ENV.ADMIN_PASSWORD } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r.data.token;
}

test('Worker: new account is free with an entitlement on /auth/me and register', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice');
  assert.equal(a.data.user.entitlement.plan, 'free');
  const me = await call(h, '/api/social/auth/me', { token: a.data.token });
  assert.equal(me.data.user.entitlement.plan, 'free');
  assert.equal(me.data.user.entitlement.freeReviewsUsed, 0);
});

test('Worker: free = exactly one review, same game reopens, other game gets 402, survives restart', async () => {
  const h = createHarness(ENV);
  const { data: { token } } = await register(h, 'alice');
  assert.equal((await review(h, '', 'g1')).status, 401, 'needs auth');
  const first = await review(h, token, 'g1');
  assert.equal(first.status, 200);
  assert.equal(first.data.reason, 'free-trial');
  assert.equal(first.data.entitlement.freeReviewsUsed, 1);
  assert.equal((await review(h, token, 'g1')).data.reason, 'free-same-game', 'free game stays viewable');
  const second = await review(h, token, 'g2');
  assert.equal(second.status, 402);
  assert.equal(second.data.allowed, false);
  assert.equal((await review(h, token, '')).status, 402, 'empty game id cannot reuse the slot');
  h.restart();
  assert.equal((await review(h, token, 'g2')).status, 402, 'quota persists after cold start');
  assert.equal((await review(h, token, 'g1')).status, 200);
});

test('Worker: free quota is per account, not shared', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice'); const b = await register(h, 'bobby');
  await review(h, a.data.token, 'g1');
  assert.equal((await review(h, a.data.token, 'g2')).status, 402);
  assert.equal((await review(h, b.data.token, 'g2')).status, 200);
});

test('Worker: only admins can grant/revoke; players cannot self-upgrade', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice');
  const id = a.data.user.id;
  assert.equal((await grant(h, '', id, 'pro')).status, 401);
  assert.equal((await grant(h, a.data.token, id, 'premium')).status, 403, 'player cannot grant themselves');
  const me = await call(h, '/api/social/auth/me', { token: a.data.token });
  assert.equal(me.data.user.entitlement.plan, 'free');
  const adminToken = await adminLogin(h);
  assert.equal((await grant(h, adminToken, 'nope', 'pro')).status, 404);
  assert.equal((await grant(h, adminToken, id, 'gold')).status, 400);
  assert.equal((await grant(h, adminToken, id, 'pro', 'steal')).status, 400);
});

test('Worker: Pro unlocks unlimited reviews, stacks 365 days, persists, and revoke returns to free', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice'); const id = a.data.user.id;
  await review(h, a.data.token, 'g1');
  assert.equal((await review(h, a.data.token, 'g2')).status, 402);
  const adminToken = await adminLogin(h);
  const g = await grant(h, adminToken, id, 'pro');
  assert.equal(g.status, 200, JSON.stringify(g.data));
  assert.equal(g.data.user.entitlement.plan, 'pro');
  assert.equal(g.data.user.entitlement.daysLeft, 365);
  for (const game of ['g2', 'g3', 'g4']) {
    const r = await review(h, a.data.token, game);
    assert.equal(r.status, 200); assert.equal(r.data.reason, 'pro'); assert.equal(r.data.entitlement.freeReviewsUsed, 1);
  }
  const again = await grant(h, adminToken, id, 'pro');
  assert.equal(again.data.user.entitlement.daysLeft, 730, 'renewal while active stacks');
  h.restart();
  const me = await call(h, '/api/social/auth/me', { token: a.data.token });
  assert.equal(me.data.user.entitlement.plan, 'pro');
  const rev = await grant(h, adminToken, id, 'pro', 'revoke');
  assert.equal(rev.data.user.entitlement.plan, 'free');
  assert.equal((await review(h, a.data.token, 'g9')).status, 402, 'free quota was kept, cannot be replayed');
});

test('Worker: Pro expiry falls back to free at the exact instant', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice'); const id = a.data.user.id;
  const adminToken = await adminLogin(h);
  await review(h, a.data.token, 'g1');
  await grant(h, adminToken, id, 'pro');
  const realNow = Date.now;
  try {
    Date.now = () => realNow() + 364 * 86400000;
    assert.equal((await review(h, await relogin(h, 'alice'), 'g2')).status, 200);
    Date.now = () => realNow() + 366 * 86400000;
    const r = await review(h, await relogin(h, 'alice'), 'g2');
    assert.equal(r.status, 402, 'expired Pro is free again; free review already used');
    assert.equal(r.data.entitlement.plan, 'free');
  } finally { Date.now = realNow; }
});

test('Worker: Premium is lifetime, survives expiry/pro grants, and revoke all returns to free', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice'); const id = a.data.user.id;
  const adminToken = await adminLogin(h);
  assert.equal((await grant(h, adminToken, id, 'premium')).data.user.entitlement.plan, 'premium');
  await grant(h, adminToken, id, 'pro');
  const realNow = Date.now;
  try {
    Date.now = () => realNow() + 30 * 365 * 86400000;
    const r = await review(h, await relogin(h, 'alice'), 'gx');
    assert.equal(r.status, 200); assert.equal(r.data.reason, 'premium');
  } finally { Date.now = realNow; }
  await grant(h, adminToken, id, 'all', 'revoke');
  assert.equal((await review(h, a.data.token, 'g1')).data.reason, 'free-trial');
});

test('Worker: plan changes are audited and entitlements are not leaked to other players', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice'); const b = await register(h, 'bobby');
  const adminToken = await adminLogin(h);
  await grant(h, adminToken, a.data.user.id, 'pro');
  await review(h, b.data.token, 'g1');
  const log = await call(h, '/api/social/admin/audit?limit=50', { token: adminToken });
  const actions = log.data.events.map(e => e.action);
  assert.ok(actions.includes('plan_grant')); assert.ok(actions.includes('free_review_used'));
  const search = await call(h, '/api/social/users/search?q=alice', { token: b.data.token });
  assert.doesNotMatch(JSON.stringify(search.data), /entitlement|proExpiresAt/);
});

test('Worker: malformed/abusive review-access bodies are safe', async () => {
  const h = createHarness(ENV);
  const a = await register(h, 'alice');
  const huge = await review(h, a.data.token, 'x'.repeat(5000));
  assert.equal(huge.status, 200);
  assert.ok(huge.data.entitlement.freeReviewGameId.length <= 120);
  const r = await call(h, '/api/social/me/review-access', { method: 'POST', token: a.data.token, body: {} });
  assert.equal(r.status, 402, 'free slot already used by the long id; an empty id cannot reuse it');
});

test('Worker password hashing stays at Cloudflare\'s 100,000 PBKDF2 limit (higher throws and breaks every login)', async () => {
  const { readFileSync } = await import('node:fs');
  const source = readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
  assert.match(source, /const PBKDF2_ITERATIONS = 100_000;/);
  assert.match(source, /iterations: PBKDF2_ITERATIONS/);
  assert.doesNotMatch(source, /iterations: 1[2-9]\d_000/);
});
