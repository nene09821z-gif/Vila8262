import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  buildArenaSchedule, countArenaGames, knockoutRound, knockoutTieWinner, pickArenaOpenings, seededRandom,
  createArenaStandings, recordArenaResult, rankArenaStandings, arenaCrosstable, eloFromScore,
  materialBalance, adjudicateAtPlyLimit, estimateArenaRemaining, formatArenaDuration, ARENA_FORMATS
} from '../src/arena-tournament.js';

const ids = ['a', 'b', 'c', 'd'];

test('schedules have the right size and alternate colours with paired openings', () => {
  const openings = pickArenaOpenings([{ name: 'X', san: ['e4', 'e5', 'Nf3', 'Nc6'] }, { name: 'Y', san: ['d4', 'd5', 'c4', 'e6'] }], 6, { seed: 3 });
  for (const [format, n, per] of [['roundrobin', 4, 2], ['roundrobin', 4, 4], ['gauntlet', 4, 2], ['match', 4, 6]]) {
    const schedule = buildArenaSchedule(format, ids.slice(0, n), { gamesPerPair: per, openings });
    assert.equal(schedule.length, countArenaGames(format, n, per), `${format}/${per}`);
  }
  const g = buildArenaSchedule('match', ['a', 'b'], { gamesPerPair: 4, openings });
  assert.deepEqual(g.map(x => x.whiteId), ['a', 'b', 'a', 'b']);
  assert.equal(g[0].opening, g[1].opening, 'colour-swapped pair shares one opening');
  assert.notEqual(g[0].opening, null);
});

test('every pairing plays each colour equally and gauntlet is champion vs rest', () => {
  const rr = buildArenaSchedule('roundrobin', ids, { gamesPerPair: 4 });
  for (const id of ids) {
    const white = rr.filter(x => x.whiteId === id).length, black = rr.filter(x => x.blackId === id).length;
    assert.equal(white, black);
  }
  const gt = buildArenaSchedule('gauntlet', ids, { gamesPerPair: 2 });
  assert.ok(gt.every(x => x.whiteId === 'a' || x.blackId === 'a'));
  assert.equal(new Set(gt.flatMap(x => [x.whiteId, x.blackId])).size, 4);
});

test('opening picker is deterministic, even-length and falls back to the start position', () => {
  const book = [{ name: 'A', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5'] }, { name: 'B', san: ['d4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6'] }];
  const one = pickArenaOpenings(book, 3, { seed: 9, plies: 6 }), two = pickArenaOpenings(book, 3, { seed: 9, plies: 6 });
  assert.deepEqual(one, two);
  assert.ok(one.every(o => o.san.length % 2 === 0 && o.san.length >= 2));
  assert.deepEqual(pickArenaOpenings([], 2).map(o => o.san), [[], []]);
  assert.equal(seededRandom(5)(), seededRandom(5)());
});

test('knockout pairs by seed with a bye for the top seed and breaks ties', () => {
  assert.deepEqual(knockoutRound(['a', 'b', 'c', 'd']), { pairs: [['a', 'd'], ['b', 'c']], bye: null });
  assert.deepEqual(knockoutRound(['a', 'b', 'c']), { pairs: [['b', 'c']], bye: 'a' });
  assert.equal(knockoutTieWinner(1.5, 0.5, 'x', 'y'), 'x');
  assert.equal(knockoutTieWinner(1, 1, 'x', 'y'), null);
});

test('standings, ranking and cross-table are consistent', () => {
  const st = createArenaStandings([{ id: 'a', name: 'A' }, { id: 'b', name: 'B' }, { id: 'c', name: 'C' }]);
  assert.equal(recordArenaResult(st, 'a', 'b', '1-0'), true);
  assert.equal(recordArenaResult(st, 'b', 'a', '1/2-1/2'), true);
  assert.equal(recordArenaResult(st, 'a', 'c', '0-1'), true);
  assert.equal(recordArenaResult(st, 'a', 'c', '*'), false);
  const ranked = rankArenaStandings(st);
  assert.equal(ranked.reduce((n, r) => n + r.points, 0), 3); // 1 point per decisive/drawn game
  assert.equal(ranked.reduce((n, r) => n + r.games, 0), 6);
  assert.ok(Math.abs(ranked.reduce((n, r) => n + r.relElo, 0)) <= 3, 'relative Elo is centred on the field');
  assert.equal(ranked[0].rank, 1);
  const cross = arenaCrosstable(ranked);
  assert.equal(cross.length, 3);
  assert.ok(cross.every((row, i) => row.cells[i].tone === 'self'));
});

test('relative Elo is monotonic, finite at 0 % and 100 %', () => {
  assert.equal(eloFromScore(0, 0), 0);
  assert.ok(eloFromScore(10, 10) > eloFromScore(7, 10));
  assert.ok(eloFromScore(7, 10) > eloFromScore(5, 10));
  assert.ok(Number.isFinite(eloFromScore(0, 10)) && Number.isFinite(eloFromScore(10, 10)));
  assert.ok(Math.abs(eloFromScore(5, 10)) < 1e-9);
});

test('ply-limit adjudication uses material only when enabled and clearly decisive', () => {
  const row = (type, color) => ({ type, color });
  const up = [[row('q', 'w'), row('p', 'b')]];
  assert.equal(materialBalance(up), 800);
  assert.equal(adjudicateAtPlyLimit(up, 120).result, '1-0');
  assert.equal(adjudicateAtPlyLimit([[row('q', 'b')]], 120).result, '0-1');
  assert.equal(adjudicateAtPlyLimit([[row('n', 'w')]], 120).result, '1/2-1/2');
  assert.equal(adjudicateAtPlyLimit(up, 120, { enabled: false }).result, '1/2-1/2');
});

test('time helpers', () => {
  assert.equal(formatArenaDuration(125000), '2:05');
  assert.equal(estimateArenaRemaining(60000, 2, 6), 120000);
  assert.equal(estimateArenaRemaining(1000, 0, 6), 0);
});

test('arena UI is wired: formats, pause, live standings, paired openings and the runner uses the module', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  for (const token of ['id="arenaFormat"', 'id="arenaGamesPerPair"', 'id="arenaPairedOpenings"', 'id="arenaAdjudicate"', 'id="arenaPause"', 'id="arenaStandings"', 'id="arenaProgress"', 'id="arenaRunLeague"', 'id="arenaStop"']) assert.ok(main.includes(token), token);
  const run = main.slice(main.indexOf('async function runArenaLeague'), main.indexOf('function pgnEscape'));
  for (const token of ['buildArenaSchedule', 'knockoutRound', 'recordArenaResult', 'rankArenaStandings', 'pickArenaOpenings', 'openingSan']) assert.ok(run.includes(token), token);
  assert.match(main, /async function arenaWaitIfPaused/);
  assert.match(main, /\[Opening "\$\{pgnEscape\(meta\.opening\)\}"\]/);
  assert.equal(ARENA_FORMATS.length, 4);
});
