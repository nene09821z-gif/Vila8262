import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const social = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');

test('VILA account session is persisted and the profile UI uses a stable generated avatar', () => {
  assert.match(main, /function saveSocialSession\(token, user\)/);
  assert.match(main, /localStorage\.setItem\(SOCIAL_SESSION_KEY, nextToken\)/);
  assert.match(main, /localStorage\.setItem\(SOCIAL_USER_KEY, JSON\.stringify\(socialState\.user\)\)/);
  assert.match(main, /function initializeRequiredAccountGate\(\)/);
  assert.match(main, /function avatarParts\(user\)/);
  assert.match(html, /id="accountAvatar"/);
});

test('startup requires the dedicated VILA nickname/email/password gate and supports recovery', () => {
  assert.match(main, /showAccountGate\('login'\)/);
  assert.match(main, /data-auth-submit="register"/);
  assert.match(main, /initialElo/);
  assert.match(main, /\/auth\/forgot-password/);
  assert.match(main, /\/auth\/reset-password/);
  assert.match(social, /randomInt\(100000, 1000000\)/);
  assert.match(social, /expiresAt: Date\.now\(\) \+ 10 \* 60_000/);
});

test('third-party account providers and Firebase config screens are removed', () => {
  assert.doesNotMatch(main, /authenticateWithFirebase|oauth\/google|oauth\/github|firebaseConfigForm|Cấu hình Firebase/);
  assert.doesNotMatch(social, /router\.(get|post)\(['"]\/auth\/oauth|router\.(get|post)\(['"]\/oauth/);
  assert.doesNotMatch(fs.readFileSync(new URL('../app/build.gradle.kts', import.meta.url), 'utf8'), /firebase\.|googleServices/);
});
