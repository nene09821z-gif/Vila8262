import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const baseCss = fs.readFileSync(new URL('../src/style.css', import.meta.url), 'utf8');
const v4Css = fs.readFileSync(new URL('../src/vila-v4.css', import.meta.url), 'utf8');

test('Analysis tools are docked in the mouse menu or match hamburger analysis pane, never floating over the board', () => {
  const mousePanel = main.indexOf('<div id="virtualMousePanel"');
  const widget = main.indexOf('id="boardAnnotationWidget"', mousePanel);
  const mouseDock = main.indexOf('id="annotationToolsDockMouse"', mousePanel);
  const menuDock = main.indexOf('id="annotationToolsDockMenu"');
  assert.ok(mousePanel >= 0 && mouseDock > mousePanel && widget > mouseDock);
  assert.ok(menuDock >= 0 && main.indexOf('id="openDrawingTools"') >= 0);
  assert.doesNotMatch(main, /board-annotation-toolbar-row/);
  assert.doesNotMatch(main, /id="annotationWidgetReopen"/);
  for (const token of ['annotationWidgetToggle', 'annotationWidgetHide', 'virtualMouseToolsToggle', 'openDrawingTools', 'data-annotation-tool="move"', 'data-annotation-tool="arrow"', 'data-annotation-tool="pencil"', 'data-annotation-tool="knight"', 'data-annotation-tool="circle"', 'data-annotation-color="green"', 'data-annotation-color="red"', 'data-annotation-color="yellow"', 'data-annotation-color="blue"', 'annotationColorCycle', 'annotationClear']) {
    assert.ok(main.includes(token), `missing annotation control: ${token}`);
  }
  assert.match(main, /function syncAnnotationWidget\(\)[\s\S]*annotation-tool-docked/);
  assert.match(main, /function toggleAnnotationToolsDock\(location = 'mouse'\)[\s\S]*target\.append\(widget\)/);
  assert.match(main, /#openDrawingTools[\s\S]*toggleAnnotationToolsDock\('menu'\)/);
  assert.match(main, /#virtualMouseToolsToggle[\s\S]*toggleAnnotationToolsDock\('mouse'\)/);
  assert.match(v4Css, /html body \.board-annotation-widget\.annotation-tool-docked\s*\{[^}]*position: relative !important/s);
  assert.match(v4Css, /\.annotation-tools-dock\[hidden\]/);
  assert.match(v4Css, /\.virtual-mouse-panel\.has-annotation-tools/);
  assert.match(baseCss, /\.manual-arrow-blue/);
});

test('Virtual PC mouse supports compact touchpad movement and hold-drag-release using the existing board pointer path', () => {
  for (const token of ['virtualMouseToggle', 'virtualMousePanel', 'virtualMousePad', 'virtualMouseCursor', 'virtualMouseClick', 'virtualMouseHold', 'virtualMouseReopen']) assert.ok(main.includes(token), `missing virtual mouse control: ${token}`);
  assert.match(main, /const VIRTUAL_MOUSE_SENSITIVITY = 2\.35/);
  assert.match(main, /function virtualMouseSetPosition\([\s\S]*requestAnimationFrame/);
  assert.match(main, /function virtualMouseSetHeld\([\s\S]*pointerdown/);
  assert.match(main, /function virtualMouseDispatchPointer\([\s\S]*VIRTUAL_MOUSE_POINTER_ID/);
  assert.match(main, /function wireVirtualMouse\([\s\S]*pointermove/);
  assert.match(v4Css, /\.virtual-mouse-cursor/);
  assert.match(v4Css, /\.virtual-mouse-pad\{position:relative/);
});

test('Optional hand-tracking cursor uses a worker, pinch-to-drag, and a touchpad fallback', () => {
  const worker = fs.readFileSync(new URL('../src/hand-mouse-worker.js', import.meta.url), 'utf8');
  assert.ok(main.includes('id="virtualMouseCamera"'));
  assert.match(main, /async function startHandMouse\(\)[\s\S]*getUserMedia/);
  assert.match(main, /new Worker\(new URL\('\.\/hand-mouse-worker\.js', import\.meta\.url\)/);
  assert.match(main, /HAND_MOUSE_PINCH_DOWN = 0\.047/);
  assert.match(main, /HAND_MOUSE_PINCH_UP = 0\.075/);
  assert.match(main, /chụm cái \+ trỏ để nhấn\/giữ/);
  assert.match(main, /function stopHandMouse\([\s\S]*button\.disabled = false/);
  assert.match(main, /function setView\(view\)[\s\S]*previousView === 'play' && view !== 'play'[\s\S]*stopHandMouse/);
  assert.match(main, /addEventListener\('visibilitychange',[\s\S]*if \(handMouseStream\) stopHandMouse\(\)/);
  assert.match(worker, /HandLandmarker\.createFromOptions/);
  assert.match(worker, /detectForVideo/);
  assert.match(worker, /postMessage\(\{\s*type: 'landmarks'/);
  assert.doesNotMatch(worker, /fetch\([^)]*landmarks|sendBeacon|WebSocket/);
  assert.match(v4Css, /\.virtual-mouse-camera\{/);
  assert.match(v4Css, /\.virtual-mouse-video\{/);
});
