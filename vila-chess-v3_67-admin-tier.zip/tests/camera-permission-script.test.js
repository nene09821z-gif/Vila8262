import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const script = new URL('../scripts/ensure-camera-permission.mjs', import.meta.url);
const verifier = new URL('../scripts/verify-android-project.mjs', import.meta.url);
const branding = new URL('../scripts/apply-android-branding.mjs', import.meta.url);
const workflows = [
  new URL('../.github/workflows/build-android.yml', import.meta.url),
  new URL('../.github/workflows/build-from-zip.yml', import.meta.url)
];

test('camera permission patch is idempotent and is wired into both GitHub Android builds', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vila-camera-permission-'));
  try {
    const manifest = path.join(tmp, 'app', 'src', 'main', 'AndroidManifest.xml');
    fs.mkdirSync(path.dirname(manifest), { recursive: true });
    fs.writeFileSync(manifest, '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application /></manifest>\n');
    const first = spawnSync(process.execPath, [script.pathname, tmp], { encoding: 'utf8' });
    assert.equal(first.status, 0, first.stderr);
    let xml = fs.readFileSync(manifest, 'utf8');
    assert.equal((xml.match(/android\.permission\.CAMERA/g) || []).length, 1);
    const second = spawnSync(process.execPath, [script.pathname, tmp], { encoding: 'utf8' });
    assert.equal(second.status, 0, second.stderr);
    xml = fs.readFileSync(manifest, 'utf8');
    assert.equal((xml.match(/android\.permission\.CAMERA/g) || []).length, 1);
    assert.match(fs.readFileSync(verifier, 'utf8'), /missing CAMERA permission/);
    const brandingSource = fs.readFileSync(branding, 'utf8');
    assert.match(brandingSource, /import \{ ensureCameraPermission \} from '\.\/ensure-camera-permission\.mjs'/);
    assert.ok(brandingSource.indexOf('fs.writeFileSync(manifestPath, manifest)') < brandingSource.indexOf('ensureCameraPermission(path.join(root, '));
    for (const url of workflows) {
      const source = fs.readFileSync(url, 'utf8');
      const brandingIndex = source.indexOf('node scripts/apply-android-branding.mjs');
      const permissionIndex = source.indexOf('node scripts/ensure-camera-permission.mjs android');
      const verifyIndex = source.indexOf('node scripts/verify-android-project.mjs');
      assert.ok(brandingIndex >= 0, `${url.pathname} must apply Android branding`);
      assert.ok(permissionIndex >= 0, `${url.pathname} must ensure CAMERA permission`);
      assert.ok(verifyIndex >= 0, `${url.pathname} must verify the Android project`);
      assert.ok(brandingIndex < permissionIndex && permissionIndex < verifyIndex,
        `${url.pathname} must patch CAMERA permission after branding and before verification`);
    }
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});
