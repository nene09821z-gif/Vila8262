import test from 'node:test';
import assert from 'node:assert/strict';
import {
  MISTAKE_TRAINING_STORAGE_KEY, buildMistakeTrainingItems, normalizeMistakeTrainingItems,
  upsertMistakeTrainingItems, recordMistakeAttempt, selectNextMistake, summarizeMistakeTraining,
  loadMistakeTrainingItems, saveMistakeTrainingItems, isUsableTrainingFen
} from '../src/mistake-training.js';

const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
function candidate(overrides = {}) {
  return {
    ply: 4, moveNumber: 2, mover: 'w', fenBefore: START_FEN,
    bestMoveUci: 'd2d4', bestMoveSan: 'd4', bestLineUci: ['d2d4', 'd7d5'],
    playedUci: 'e2e4', san: 'e4', judgement: { key: 'mistake' }, lossCp: 90,
    ...overrides
  };
}
function memoryStorage() {
  const data = new Map();
  return { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, String(value)), removeItem: key => data.delete(key), data };
}

test('only analyzed mistakes with a valid position and distinct legal engine move enter personal training', () => {
  assert.equal(isUsableTrainingFen(START_FEN), true);
  const items = buildMistakeTrainingItems([
    candidate(), candidate({ ply: 5, judgement: { key: 'good' } }),
    candidate({ ply: 6, bestMoveUci: 'z9z1' }), candidate({ ply: 7, fenBefore: '' }),
    candidate({ ply: 8, mover: 'b' })
  ], { gameId: 'game-1', playerColor: 'w', now: 100, isLegalSolution: ({ uci }) => ['d2d4'].includes(uci) });
  assert.equal(items.length, 1);
  assert.equal(items[0].solutionUci, 'd2d4');
  assert.equal(items[0].fenBefore, START_FEN);
  assert.equal(buildMistakeTrainingItems([candidate()], { playerColor: 'b', isLegalSolution: () => true }).length, 0);
});

test('upserting a reanalyzed game preserves the learner progress and avoids duplicates', () => {
  const [fresh] = buildMistakeTrainingItems([candidate()], { gameId: 'game-2', now: 100, isLegalSolution: () => true });
  const first = upsertMistakeTrainingItems([], [fresh]);
  const recorded = recordMistakeAttempt(first, fresh.id, false, 200);
  const merged = upsertMistakeTrainingItems(recorded.items, [fresh, fresh]);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].attempts, 1);
  assert.equal(merged[0].wrongAttempts, 1);
  assert.equal(merged[0].lastResult, 'wrong');
});

test('three spaced correct responses master a mistake; wrong response resets consecutive streak', () => {
  const [fresh] = buildMistakeTrainingItems([candidate()], { gameId: 'game-3', now: 100, isLegalSolution: () => true });
  let items = [fresh];
  items = recordMistakeAttempt(items, fresh.id, true, 1_000).items;
  assert.equal(items[0].streak, 1);
  items = recordMistakeAttempt(items, fresh.id, false, 2_000).items;
  assert.equal(items[0].streak, 0);
  const firstDue = items[0].dueAt;
  items = recordMistakeAttempt(items, fresh.id, true, firstDue).items;
  const secondDue = items[0].dueAt;
  items = recordMistakeAttempt(items, fresh.id, true, secondDue).items;
  const thirdDue = items[0].dueAt;
  items = recordMistakeAttempt(items, fresh.id, true, thirdDue).items;
  assert.equal(items[0].solved, true);
  assert.equal(items[0].correctAttempts, 4);
  assert.equal(summarizeMistakeTraining(items).mastered, 1);
  assert.equal(selectNextMistake(items, 9_000), null);
});

test('selection prioritizes due high-severity mistakes and storage is defensive', () => {
  const [low] = buildMistakeTrainingItems([candidate({ ply: 2, judgement: { key: 'inaccuracy' }, lossCp: 30 })], { gameId: 'same', now: 1, isLegalSolution: () => true });
  const [high] = buildMistakeTrainingItems([candidate({ ply: 4, judgement: { key: 'blunder' }, lossCp: 450 })], { gameId: 'same', now: 1, isLegalSolution: () => true });
  const chosen = selectNextMistake([low, high], 2);
  assert.equal(chosen.id, high.id);
  const storage = memoryStorage();
  assert.equal(saveMistakeTrainingItems([high, low], storage).ok, true);
  assert.equal(storage.data.has(MISTAKE_TRAINING_STORAGE_KEY), true);
  assert.equal(loadMistakeTrainingItems(storage).length, 2);
  assert.equal(normalizeMistakeTrainingItems([{ id: 'bad', fenBefore: 'not a fen', solutionUci: 'a1a2', playedUci: 'a1a2', judgement: 'mistake', mover: 'w' }]).length, 0);
  const brokenStorage = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('quota'); } };
  assert.deepEqual(loadMistakeTrainingItems(brokenStorage), []);
  assert.equal(saveMistakeTrainingItems([high], brokenStorage).ok, false);
});
