import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { RANKED_CLOCK_PRESETS } from '../src/clock.js';
const read = path => fs.readFileSync(new URL(path, import.meta.url), 'utf8');

test('online ranked clock presets have one canonical catalogue shared with Cloudflare and Node', () => {
  const worker = read('../cloudflare/src/index.js');
  const social = read('../server/social.js');
  assert.match(worker, /import \{ RANKED_CLOCK_PRESETS \} from '\.\.\/\.\.\/src\/clock\.js'/);
  assert.match(worker, /Object\.fromEntries\(RANKED_CLOCK_PRESETS\.map/);
  assert.match(social, /RANKED_CLOCK_PRESETS\.some/);
  for (const preset of RANKED_CLOCK_PRESETS) {
    assert.ok(preset.value && preset.category && preset.baseSeconds > 0, `invalid preset ${preset.value}`);
  }
  assert.ok(RANKED_CLOCK_PRESETS.some(preset => preset.value === '1d' && preset.category === 'daily'));
  assert.ok(RANKED_CLOCK_PRESETS.some(preset => preset.value === '2d' && preset.category === 'daily'));
});

test('queued match status restores the actual selected time control and category after refresh', () => {
  const node = read('../server/social.js');
  const worker = read('../cloudflare/src/index.js');
  assert.match(node, /timeControl: queueItem\?\.timeControl \|\| null/);
  assert.match(node, /timeCategory: queueItem\?\.timeCategory \|\| null/);
  assert.match(worker, /timeControl: entry\?\.timeControl \|\| null/);
  assert.match(worker, /timeCategory: entry\?\.timeCategory \|\| null/);
  assert.match(node, /req\.body\?\.timeControl, 16\) \|\| '1d'/);
  assert.match(worker, /asText\(body\.timeControl, 16\) \|\| '1d'/);
  assert.match(read('../src/main.js'), /else if \(next\.queued && next\.timeControl\) setSelectedRankedTimeControl\(next\.timeControl\)/);
});

test('fair-play signals use server-side duration and pre-move branching factor, are review-only, and never auto-ban', () => {
  const node = read('../server/social.js');
  const worker = read('../cloudflare/src/index.js');
  const shared = read('../src/ranked-fair-play.js');
  for (const source of [node, worker]) {
    assert.match(source, /turnDurationMs/);
    assert.match(source, /legalMoveCount = chess\.moves\(\)\.length/);
    assert.match(source, /assessRankedFairPlayMove/);
    assert.match(source, /ranked_fair_play_signal/);
    assert.match(source, /admin\/fair-play/);
  }
  assert.match(shared, /repeated_ultra_fast_moves/);
  assert.match(shared, /fast_moves_in_complex_positions/);
  assert.match(shared, /manual review/i);
  assert.doesNotMatch(node, /if \(signal\.signals >= 3\)[\s\S]{0,100}banned = true/);
  assert.doesNotMatch(worker, /if \(signal\.signals >= 3\)[\s\S]{0,100}banned = true/);
});

test('Cloudflare avatar IDs are deterministic rather than randomly changing on each profile request', () => {
  const worker = read('../cloudflare/src/index.js');
  assert.match(worker, /function stableAvatarId\(user\)/);
  assert.match(worker, /: stableAvatarId\(user\)/);
  assert.doesNotMatch(worker, /const avatarId =[^\n]*Math\.random\(\)/);
});
