import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
// The slim GitHub ZIP omits duplicate static copies under app/src/main/assets; Gradle restores them
// from public/ before building. Fall back to the canonical public/ file so the check still runs.
const readAndroid = file => {
  const androidPath = path.join(root, file);
  if (fs.existsSync(androidPath)) return fs.readFileSync(androidPath, 'utf8');
  return read(file.replace('app/src/main/assets/', 'public/'));
};

test('Professional UI uses one canonical stylesheet without replacing interaction modules', () => {
  const main = read('src/main.js');
  const css = read('src/vila-professional.css');
  assert.match(main, /import '\.\/vila-professional\.css';/);
  assert.doesNotMatch(main, /import '\.\/(?:style|vila-atelier|mobile-upgrade|vila-polish|chesscom-polish|vila-commercial|board-motion|board-live|profile|lessons|vila-v4|account-gate|header-chesscom|achievements|social-hub)\.css';/);
  assert.match(css, /Final authoritative ViLa Professional theme/);
  assert.match(main, /function renderBoard\(\)/);
  assert.match(main, /function renderPlayView\(\)/);
  assert.match(main, /function renderReviewView\(\)/);
  assert.match(main, /function renderPuzzleView\(\)/);
});

test('Professional theme defines dark surfaces, high-contrast text, 3D badges and reduced-motion support', () => {
  const css = read('src/vila-professional.css');
  assert.match(css, /--bg:\s*#08111f/);
  assert.match(css, /--vila-accent:\s*#3c8cff/);
  assert.match(css, /:focus-visible/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
  assert.match(css, /color-scheme:\s*dark/);
  assert.match(css, /\.top100-rank\.rank-1/);
  assert.match(css, /box-shadow:\s*inset 0 1px rgba\(255,255,255,\.25\),0 3px 0 #081321/);
  assert.doesNotMatch(css, /@import\s+url\(/);
});

test('mobile layout keeps full-width content, touch navigation and safe-area spacing', () => {
  const css = read('src/vila-professional.css');
  assert.match(css, /#app\s*\{[^}]*width:\s*100% !important/s);
  assert.match(css, /\.content-page\s*\{[^}]*max-width:\s*1180px !important/s);
  assert.match(css, /\.bottom-nav\s*\{[^}]*position:\s*fixed/s);
  assert.match(css, /env\(safe-area-inset-bottom\)/);
  assert.match(css, /body\.play-screen-active #app \{ padding-bottom:/);
  assert.match(css, /\.chat-layout \{ grid-template-columns: minmax\(0,1fr\) !important/);
});

test('the full set of app navigation views remains reachable through More and quick navigation', () => {
  const html = read('index.html');
  const main = read('src/main.js');
  for (const view of ['home','play','ranked','lichess','arena','puzzles','openings','coach','games','missions','shop','leaderboard','friends','inbox','history','health','settings']) {
    assert.ok(html.includes(`data-view="${view}"`), `Missing navigation target ${view}`);
  }
  assert.match(main, /\$\$\('\.tab'\)/);
  assert.match(main, /setAttribute\('aria-current', 'page'\)/);
  assert.match(main, /event\.key !== 'Escape'/);
  assert.match(main, /function setView\(view\)/);
});

test('specialist screens use the unified Professional dark system for analysis, puzzles, history, social and results', () => {
  const css = read('src/vila-professional.css');
  for (const selector of [
    '.game-review-page .game-review-header',
    '.history-view .page-heading h1',
    '.puzzle-mode-row',
    '.ranked-stat-grid',
    '.progression-summary-main',
    '.social-person-row',
    '.top100-row',
    '.result-modal',
  ]) assert.ok(css.includes(selector), `Missing specialist theme selector ${selector}`);
  assert.match(css, /\.game-review-page \.review-actions/);
  assert.match(css, /@media\s*\(max-width:\s*680px\)/);
});

test('release metadata and offline cache keys use v3.67.0', () => {
  assert.equal(JSON.parse(read('package.json')).version, '3.67.0');
  assert.match(read('index.html'), /ViLa Chess .*v3\.67\.0/);
  assert.match(read('server/index.js'), /version: '3\.67\.0'/);
  assert.match(read('public/sw.js'), /covua-vila-v3\.67\.0/);
  assert.match(read('public/sw.js'), /favicon\.ico\?v=353/);
  assert.match(read('public/sw.js'), /covua-vila-brand-icon\.png\?v=353/, 'the current brand icon is precached for offline startup');
});

test('Android Gradle staging uses the fresh responsive stylesheet from the canonical web build', () => {
  const gradle = read('app/build.gradle.kts');
  const androidHtml = read('app/src/main/assets/index.html');
  const sourceCss = read('src/vila-professional.css');
  const worker = readAndroid('app/src/main/assets/sw.js');
  assert.match(androidHtml, /giao diện web chưa được build/i);
  assert.doesNotMatch(androidHtml, /index-nreOU-41\.css|index-CYdsNhSO\.js/i);
  assert.match(gradle, /stageBuiltWebAssetsForAndroid/);
  assert.match(gradle, /from\(webDist\)/);
  assert.match(sourceCss, /--bg:\s*#08111f/);
  assert.match(sourceCss, /--vila-accent:\s*#3c8cff/);
  assert.match(sourceCss, /Final authoritative ViLa Professional theme/);
  assert.match(worker, /covua-vila-v3\.67\.0/);
});
