import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DEFAULTS, DEFAULT_BACKEND_URL, normalizeSettings } from '../src/settings-schema.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server/index.js', import.meta.url), 'utf8');
const social = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');

test('cloud backend is preconfigured; players do not need to enter a Worker URL', () => {
  assert.equal(DEFAULT_BACKEND_URL, 'https://bitter-sun-751a.nene09821z.workers.dev');
  assert.equal(DEFAULTS.backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({}).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'https://cosmetics-paris-believe-harvey.trycloudflare.com' }).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'https://my.example.com/' }).backendUrl, 'https://my.example.com');
  assert.doesNotMatch(main, /vilaAuthBackendUrl|data-save-auth-server|id="communityBackendUrl"|id="communityBackendToken"/);
  assert.doesNotMatch(main, /nhập URL vào Cài đặt/);
});

test('account gate offers a real offline guest path when no cloud backend is configured', () => {
  assert.match(main, /data-offline-guest/);
  assert.match(main, /localStorage\.setItem\(OFFLINE_GUEST_MODE_KEY, '1'\)/);
  assert.match(main, /if \(!socialState\.token \|\| !socialState\.user\) \{ if \(!offlineGuestMode\) showAccountGate/);
  assert.match(main, /Ghép trận xếp hạng và quản trị cần tài khoản cùng backend online đã triển khai/);
});

test('sign-up and sign-in forms use only a username and password', () => {
  const gateRegister = main.match(/<form data-auth-submit="register">[\s\S]*?<\/form>/)[0];
  assert.match(gateRegister, /name="username"/);
  assert.match(gateRegister, /name="password"[^>]*minlength="8"/);
  assert.doesNotMatch(gateRegister, /type="email"|name="email"/);
  const gateLogin = main.match(/<form data-auth-submit="login">[\s\S]*?<\/form>/)[0];
  assert.match(gateLogin, /name="identity"/);
  assert.doesNotMatch(gateLogin, /minlength=/, 'legacy accounts with longer passwords and any length must still sign in');
  assert.match(main, /socialApi\('\/auth\/register', \{ method: 'POST', body: JSON\.stringify\(\{ username: String\(values\.get\('username'\)/);
  assert.match(social, /MIN_PASSWORD_LENGTH = 8/);
});

test('only a definite 401 (or banned/missing account) ends the stored session; offline or validation errors do not', () => {
  assert.match(main, /failure\.status = response\.status/);
  assert.match(main, /function isSessionRejected\(error\)/);
  assert.doesNotMatch(main, /không hợp lệ\|HTTP 401\|HTTP 403/, 'message-text matching used to sign users out on unrelated validation errors');
  assert.match(main, /Only a definite rejection from the server ends the session/);
});

test('server keeps sessions long-lived, refreshes them, and has a safe reverse-proxy trust default', () => {
  assert.match(social, /TOKEN_TTL_SECONDS = 30 \* 24 \* 60 \* 60/);
  assert.match(social, /router\.post\('\/auth\/logout'/);
  assert.match(server, /app\.set\('trust proxy', 'loopback'\)/);
  assert.match(server, /https:\/\/localhost/, 'Capacitor Android WebView origin stays in the CORS allow-list');
});
