import test from 'node:test';
import assert from 'node:assert/strict';
import { captureClockSnapshot, recordClockSnapshot, restoreClockSnapshot, cloneClockHistoryRange } from '../src/move-clock-history.js';

test('clock snapshots are deep copies and restore exact time/increment without an old tick timestamp', () => {
  const current = { enabled: true, running: true, remaining: { w: 123456, b: 76543 }, incrementMs: 2000, lastTickAt: 12 };
  const snapshot = captureClockSnapshot(current, null);
  current.remaining.w = 1;
  assert.equal(snapshot.remaining.w, 123456);
  const restored = restoreClockSnapshot(snapshot, 8000);
  assert.deepEqual(restored, { enabled: true, running: true, remaining: { w: 123456, b: 76543 }, incrementMs: 2000, lastTickAt: 8000, clockFlagged: null });
});

test('per-ply history preserves sparse/restorable records and bounded values', () => {
  const history = [];
  recordClockSnapshot(history, 4, { enabled: true, running: true, remaining: { w: 9e9, b: -3 }, incrementMs: 7e9, clockFlagged: 'b' });
  assert.equal(history.length, 5);
  assert.equal(history[4].remaining.w, 86400000);
  assert.equal(history[4].remaining.b, 0);
  assert.equal(history[4].incrementMs, 60000);
  assert.equal(history[4].clockFlagged, 'b');
  assert.equal(cloneClockHistoryRange(history, 3, 5).length, 2);
  assert.equal(restoreClockSnapshot(null), null);
});
