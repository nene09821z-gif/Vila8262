# Test report — v3.49.1: đồng bộ test Đấu trường với kho 4 khai cuộc riêng

## Nguyên nhân 2 lỗi
- `arena-strength.test.js` còn kiểm tra thiết kế cũ (sách khai cuộc chung `findOpeningBookMove`), trong khi v3.49 đã chuyển sang `pickPersonaBookMove` (kho 4 khai cuộc riêng mỗi bot).
- Câu mô tả đầu trang Đấu trường đổi chữ ("đấu toàn lực") nên lệch với test.

## Đã sửa
- Test cập nhật theo thiết kế mới, vẫn giữ các kiểm tra "không handicap" (cùng thời gian, Skill Level, multiPv 4, dung sai 18 cp).
- Giao diện: gợi ý ở mục Sức mạnh không còn nói sai "mọi bot dùng chung sách khai cuộc"; thống nhất câu "Mặc định thi đấu tối đa…".
- Thêm test: mọi 21 bot đều phân giải đúng 4 khai cuộc từ catalogue (đã kiểm tra thực tế: 21/21 đạt).

## Kết quả
- 301/307 đạt. 6 file còn lại chỉ lỗi `ERR_MODULE_NOT_FOUND` (thiếu `chess.js`/`express` do môi trường không có mạng để `npm install`), không phải lỗi assertion.
- Chưa chạy được: build Vite/APK và kiểm tra giao diện thực trên thiết bị.
