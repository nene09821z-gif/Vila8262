# Third-party license notices

- chess.js 1.4.0: BSD-2-Clause — https://github.com/jhlywa/chess.js
- Stockfish / Stockfish.js 19.0.1: GPL-3.0 — https://github.com/official-stockfish/Stockfish and https://www.npmjs.com/package/stockfish
- Vite, Express, Capacitor and other dependencies retain their own licenses in the installed packages.

The build script copies the Stockfish browser JS and WASM assets from the npm package into `public/engine`. Check the package's included notice/source materials when distributing a built APK; the Stockfish project source and GPL text are available from the official project repository. Do not remove upstream copyright and license notices.
