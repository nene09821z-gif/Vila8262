# Báo cáo kiểm thử — ViLa Chess v3.63.0

Ngày: 2026-10-24

## Phạm vi thay đổi

- Dùng thử Pro bằng 50.000 xu trong 3 giờ.
- API yêu cầu Pro/Premium ở Node backend và Cloudflare Worker; xác thực người dùng, quyền admin, xác thực mệnh giá, giới hạn 8 yêu cầu/giờ, chống yêu cầu trùng đang chờ và audit.
- Quyết định admin: Pro chỉ cấp đúng 3 giờ sau quyết định xác nhận; Premium không tự cấp; quyết định không thể phát lại.
- Nhắn tin tự động vào hộp thư admin, phản hồi tự động theo quy tắc, thông báo lại người dùng và panel trong chat admin.
- Lưu bền vững `purchaseRequests` và `directMessages` trong Cloudflare Durable Object records.

## Kết quả đã quan sát

- **36/36 test mục tiêu** đạt khi chạy nhóm `tests/purchase-request-ui.test.js`, `tests/daily-progress.test.js`, `tests/ui-icons-shop.test.js`, `tests/v3-56-plans-review.test.js`, `tests/billing-client.test.js`, `tests/social-hub-static.test.js`.
- Bộ rộng `npm run test:static`: **338/343 đạt; 5 bài không chạy được vì thiếu dependencies**, nên lệnh trả mã lỗi. `tests/account-auth-e2e.test.js` không nạp được `express`; `tests/cloudflare-billing.test.js`, `tests/cloudflare-external-routes.test.js`, `tests/cloudflare-plans.test.js` và `tests/premove.test.js` không nạp được `chess.js`. Không tính 5 bài này là đạt.
- Cả tám lệnh `node --check` cho `src/main.js`, `src/daily-progress.js`, `src/plans.js`, `server/social.js`, `cloudflare/src/index.js`, `scripts/build-professional-css.mjs`, `tests/purchase-requests.test.js` và `tests/purchase-request-ui.test.js` đều hoàn thành thành công. `package.json` và `package-lock.json` đều parse JSON hợp lệ.
- Một nhóm hồi quy chọn lọc gồm **92/92 bài** đạt sau khi cập nhật các test metadata release lên v3.63.0; bao gồm test Pro 50.000 xu/3 giờ, API yêu cầu gói, release metadata, chat/UI và các hồi quy trước đây.
- **Cloudflare Worker integration test đạt** với harness Durable Object: gửi yêu cầu, chặn mệnh giá sai, giới hạn yêu cầu, kiểm tra quyền admin, xác nhận Pro 3 giờ, từ chối phát lại quyết định, không tự cấp Premium, gửi tin nhắn admin, và xác nhận yêu cầu/tin nhắn còn tồn tại sau khi dựng lại Worker.
- Test integration Node đã được khai báo nhưng **bị skip** trong môi trường này vì gói `express` không được cài đầy đủ (`node_modules/express/index.js` không tồn tại). `chess.js` cũng thiếu; một shim tạm thời chỉ dùng để nạp Worker trong bài test purchase/message, không kiểm tra luật cờ, và đã bị xóa sau test.
- `npm ci` không hoàn tất do timeout/không truy cập được npm registry (`EAI_AGAIN`). Do vậy **chưa xác minh `npm run build`, toàn bộ `npm test`, Vite dist, Gradle/APK hoặc kiểm thử máy Android thật**. Đây không được tính là pass.

## Lệnh được thêm

- `npm run test:purchase-requests` — kiểm tra yêu cầu gói, UI tĩnh và integration backend. Trong môi trường có dependencies đầy đủ, bài Node sẽ chạy thay vì skip.
- `npm run test:static` có thêm `tests/purchase-request-ui.test.js`.

## Cần làm trước khi phát hành

1. Cài dependencies sạch bằng `npm ci` trong GitHub Actions/máy có npm registry truy cập được.
2. Chạy `npm run test:purchase-requests`, `npm run test:static`, `npm test`, sau đó `npm run build`.
3. Deploy Worker mới rồi test bằng hai tài khoản thật (user/admin), xác nhận binding Durable Object và cấu hình admin role; không dùng dữ liệu thử làm giao dịch tiền thật.
4. Xác minh thủ công giao dịch trước khi admin bấm xác nhận Pro. Hệ thống không tự đối chiếu ngân hàng và không bán/kích hoạt Premium tự động.

## Giới hạn và an toàn

“Anti-ban” không thể bảo đảm tránh việc nền tảng bên ngoài khóa tài khoản; phiên bản này chỉ thêm biện pháp chống lạm dụng API, kiểm tra quyền, giới hạn tần suất và audit. Trợ lý chat là trả lời theo quy tắc, không phải mô hình AI. Yêu cầu mua hiện là luồng liên hệ/duyệt nội bộ, không phải cổng thanh toán trực tuyến.
