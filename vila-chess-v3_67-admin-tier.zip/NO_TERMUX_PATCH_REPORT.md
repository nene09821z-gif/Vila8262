# Báo cáo bản vá — ViLa Chess Internet matchmaking

## Hành vi phía người chơi
- Ứng dụng dùng sẵn `https://bitter-sun-751a.nene09821z.workers.dev`; không hiển thị trường nhập Worker URL/API key cho ghép trận.
- Cài đặt cũ trỏ tới localhost/loopback hoặc tunnel tạm được tự chuyển sang backend mặc định khi đọc cài đặt, để không còn phụ thuộc máy chủ Termux cũ.
- Nút kiểm tra kết nối xác minh phản hồi dịch vụ cộng đồng; lỗi mạng/backend chưa sẵn sàng được báo rõ.
- Không xóa cơ chế migration localhost: đây là xử lý tương thích cho người đang nâng cấp, không phải chức năng chạy local.

## Backend đi kèm
- `cloudflare/` chứa Worker ghép trận dùng Durable Object SQLite.
- Các route online và proxy liên quan được giữ trong source.
- Không cần chạy điện thoại hoặc máy cá nhân liên tục sau khi backend được deploy lên Cloudflare.

## Kiểm thử và giới hạn
- Source đã được kiểm tra tĩnh trong lượt đóng gói trước: cú pháp JavaScript, cấu hình Wrangler và các test tập trung đã chạy được.
- Đây chưa phải xác nhận production: Worker chưa được triển khai vào tài khoản Cloudflare từ môi trường đóng gói; chưa kiểm thử hai thiết bị qua Internet thật; chưa tạo APK ở lượt này.
- Để ghép trận Internet hoạt động, cần triển khai thư mục `cloudflare/` một lần lên Cloudflare và kiểm tra `/api/health`, `/api/social/health`, sau đó thử hai tài khoản trên hai thiết bị/mạng riêng.
- Không chia sẻ Cloudflare API token hoặc thông tin đăng nhập. Không nhập API key vào ứng dụng người chơi.
