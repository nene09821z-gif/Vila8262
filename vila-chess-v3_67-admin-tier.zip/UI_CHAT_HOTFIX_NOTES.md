# ViLa Chess UI and chat development hotfix (based on v3.61.0)

- Removed the unconditional 560px app-shell cap. The shell now fills the available viewport and remains capped at 1280px on wide screens.
- Restyled the leaderboard and direct-message area into a consistent navy/blue/cyan palette with stronger text contrast and larger touch targets.
- When run with Vite on localhost, social/account/chat API calls now use the same-origin `/api` proxy to the Express API started by `npm run dev`; a production build continues to use the configured community Worker.
- A successful direct-message POST is now shown immediately from the server response even if a periodic conversation refresh is already running.
- Added regression assertions for the responsive shell, localhost API routing, and social page contrast.

## Verification limits

The source/static tests can validate routing choices and UI markup, but they cannot prove that a public Cloudflare Worker is deployed with the same routes or test chat between two remote devices. For local testing, run both services with `npm run dev`, create/use accounts in the local API database, and test two accounts. Production chat still depends on the deployed Worker backend being updated and reachable.
