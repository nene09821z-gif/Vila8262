/** Optional on-screen performance meter for tuning on a real phone: open the app with ?fps=1 (or set localStorage vila.fps = 1). */
export function perfMeterRequested(win = typeof window === 'undefined' ? null : window) {
  try { return Boolean(win) && (/[?&]fps=1(?:&|$)/.test(win.location?.search || '') || win.localStorage?.getItem('vila.fps') === '1'); } catch { return false; }
}

export function startPerfMeter(win = window) {
  const doc = win?.document;
  if (!doc?.body || doc.getElementById('vilaPerfMeter')) return null;
  const el = doc.createElement('div');
  el.id = 'vilaPerfMeter';
  Object.assign(el.style, { position: 'fixed', left: '6px', top: 'calc(env(safe-area-inset-top, 0px) + 4px)', zIndex: '2147483647', padding: '4px 7px', borderRadius: '8px', background: 'rgba(0,0,0,.72)', color: '#9fffa8', font: '600 11px/1.35 ui-monospace, monospace', pointerEvents: 'none', whiteSpace: 'pre' });
  doc.body.appendChild(el);
  const now = () => win.performance?.now?.() ?? Date.now();
  let frames = 0; let worst = 0; let last = now(); let windowStart = last;
  const longTasks = [];
  try {
    new win.PerformanceObserver(list => { for (const entry of list.getEntries()) longTasks.push({ at: now(), ms: entry.duration }); }).observe({ type: 'longtask', buffered: true });
  } catch { /* long-task timing is optional */ }
  const nav = win.navigator || {};
  const loop = t => {
    const time = typeof t === 'number' ? t : now();
    frames += 1; worst = Math.max(worst, time - last); last = time;
    if (time - windowStart >= 1000) {
      const fps = Math.round((frames * 1000) / (time - windowStart));
      while (longTasks.length && now() - longTasks[0].at > 10000) longTasks.shift();
      const longMs = Math.round(longTasks.reduce((sum, item) => sum + item.ms, 0));
      el.textContent = `${fps} fps · khung chậm nhất ${Math.round(worst)} ms\nTác vụ dài 10s: ${longTasks.length} (${longMs} ms)\nChế độ ${doc.documentElement?.dataset?.perf || 'full'} · ${doc.getElementsByTagName('*').length} nút DOM\nRAM ${nav.deviceMemory ?? '?'} GB · ${nav.hardwareConcurrency ?? '?'} nhân`;
      frames = 0; worst = 0; windowStart = time;
    }
    win.requestAnimationFrame(loop);
  };
  win.requestAnimationFrame(loop);
  return el;
}
