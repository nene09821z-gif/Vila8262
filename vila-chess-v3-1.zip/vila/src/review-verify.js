/**
 * Adaptive verification pass for the full-game review (v3.69.5).
 *
 * Pass 1 searches every position quickly. Most moves are obviously fine, so spending the same time on
 * all of them wastes the budget. Pass 2 re-searches ONLY the positions around moves that might be
 * mislabelled (a drop that is small but not zero, a rare "Thiên tài"/"Tuyệt vời", a missed win) and
 * replaces the shallow score with the deeper one, so the "before" and "after" scores of a flagged move
 * come from comparable, deeper searches. Everything here is pure so the app and the benchmark script
 * (scripts/bench-review-accuracy.mjs) share one implementation.
 */
import { classifyMoveQuality, estimateMoveLoss, winChance } from './game-review.js';

/** @typedef {{scoreWhiteCp:number|null, secondWhiteCp?:number|null, depth?:number, bestUci?:string|null}} PositionEval */

export const VERIFY_DEFAULTS = Object.freeze({
  /** Re-check any non-best move that loses at least this many win-percent points (labels start at 2). */
  minDropPct: 2.5,
  /** Never verify more than this share of the positions (keeps the extra time bounded on a phone). */
  maxFraction: 0.4,
  /** Hard cap on extra searches. */
  maxPositions: 48
});

/** Mover-perspective win-percent drop of one reviewed row, or null when it cannot be judged. */
export function rowWinDropPct(row) {
  if (!row || !(row.ply > 0)) return null;
  const before = Number(row.scoreBeforeWhiteCp);
  const after = Number(row.scoreWhiteCp);
  if (row.scoreBeforeWhiteCp == null || row.scoreWhiteCp == null || !Number.isFinite(before) || !Number.isFinite(after)) return null;
  const sign = (row.mover || row.color) === 'b' ? -1 : 1;
  return Math.max(0, winChance(sign * before) - winChance(sign * after));
}

/**
 * Choose which positions (by ply index; position k = board after ply k, 0 = start) deserve a deeper search.
 * @param {Array<object>} rows first-pass review rows (ply 0 row may be present and is ignored)
 * @returns {number[]} ascending, de-duplicated ply indexes
 */
export function selectPositionsToVerify(rows = [], options = {}) {
  const opts = { ...VERIFY_DEFAULTS, ...options };
  const moves = (Array.isArray(rows) ? rows : []).filter(row => row && row.ply > 0);
  if (!moves.length) return [];
  const cap = Math.max(0, Math.min(opts.maxPositions, Math.ceil((moves.length + 1) * opts.maxFraction)));
  const scored = [];
  for (const row of moves) {
    const drop = rowWinDropPct(row);
    if (drop == null) continue;
    const key = row.judgement?.key || '';
    const rare = key === 'brilliant' || key === 'great' || key === 'missed-win';
    const suspicious = !row.moveWasBest && !row.bookMove && drop >= opts.minDropPct;
    if (!suspicious && !rare) continue;
    // Bigger drops first; rare labels are always interesting because a wrong "!!" is very visible.
    scored.push({ ply: row.ply, priority: rare ? 100 + drop : drop });
  }
  scored.sort((a, b) => b.priority - a.priority);
  const picked = new Set();
  for (const item of scored) {
    const need = [item.ply - 1, item.ply].filter(index => !picked.has(index));
    if (picked.size + need.length > cap) continue;
    need.forEach(index => picked.add(index));
  }
  return [...picked].sort((a, b) => a - b);
}

/**
 * Judge one move from the engine evaluations of the position before it and after it.
 * Mirrors the first-pass logic in main.js so pass 1 and pass 2 always label the same way.
 * @param {PositionEval} before position before the move (side to move = mover)
 * @param {PositionEval} after position after the move
 */
export function judgeMoveFromEvals(before, after, move = {}) {
  const mover = move.mover === 'b' ? 'b' : 'w';
  const sign = mover === 'w' ? 1 : -1;
  const lossCp = estimateMoveLoss(before?.scoreWhiteCp, after?.scoreWhiteCp, mover);
  const moverBeforeCp = Number.isFinite(Number(before?.scoreWhiteCp)) && before?.scoreWhiteCp != null ? sign * Number(before.scoreWhiteCp) : null;
  const moverAfterCp = Number.isFinite(Number(after?.scoreWhiteCp)) && after?.scoreWhiteCp != null ? sign * Number(after.scoreWhiteCp) : null;
  const moveWasBest = Boolean(before?.bestUci && move.uci && before.bestUci === move.uci);
  const secondGapPct = Number.isFinite(Number(before?.secondWhiteCp)) && before?.secondWhiteCp != null && moverBeforeCp != null
    ? Math.max(0, winChance(moverBeforeCp) - winChance(sign * Number(before.secondWhiteCp))) : null;
  const depths = [before?.depth, after?.depth].map(Number).filter(value => Number.isFinite(value) && value > 0);
  const judgement = lossCp == null ? null : classifyMoveQuality({
    moverBeforeCp, moverAfterCp, isBest: moveWasBest, bookMove: Boolean(move.bookMove),
    sacrifice: Boolean(move.sacrifice), secondGapPct, depth: depths.length ? Math.min(...depths) : null
  });
  return { lossCp, judgement, moveWasBest, moverBeforeCp, moverAfterCp };
}

const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;

/** Write best move / best line of a verified position into `row` (prefix 'best' or 'nextBest'). */
function syncBestFields(row, prefix, evaluation, fen, helpers) {
  const best = String(evaluation.bestUci || '').toLowerCase();
  if (!UCI_RE.test(best)) return;
  const pv = Array.isArray(evaluation.pv) && evaluation.pv[0] === best ? evaluation.pv.slice(0, 8) : [best];
  const lineKey = prefix === 'best' ? 'bestLine' : 'nextBestLine';
  row[`${prefix}MoveUci`] = best;
  row[`${lineKey}Uci`] = pv;
  if (fen && typeof helpers.uciPvToSan === 'function') {
    try {
      const san = helpers.uciPvToSan(fen, pv);
      row[`${prefix}MoveSan`] = san?.[0] || null;
      row[`${lineKey}San`] = san || [];
    } catch { /* keep the previous SAN text if the conversion fails */ }
  }
}

/**
 * Overwrite first-pass rows with deeper evaluations. `verified` maps ply index → PositionEval.
 * Rows whose "before" or "after" position was re-searched are re-judged; neighbours share the same
 * score so the series stays consistent. Returns the number of rows whose label changed.
 * `helpers.fenAt(ply)` and `helpers.uciPvToSan(fen, ucis)` (optional) keep the SAN text of the best
 * move/line in step with the arrow when the deeper search prefers a different move.
 */
export function applyVerifiedEvaluations(rows, verified, helpers = {}) {
  if (!Array.isArray(rows) || !verified) return 0;
  const get = ply => (verified instanceof Map ? verified.get(ply) : verified[ply]);
  let changed = 0;
  // Pass 1: scores of the positions themselves (also for the ply-0 row used by the eval graph).
  for (const row of rows) {
    if (!row) continue;
    const here = get(row.ply);
    if (here && Number.isFinite(Number(here.scoreWhiteCp))) {
      row.scoreWhiteCp = here.scoreWhiteCp;
      row.engineDepth = Math.max(Number(row.engineDepth) || 0, Number(here.depth) || 0);
      if (here.bestUci) syncBestFields(row, 'nextBest', here, helpers.fenAt?.(row.ply), helpers);
    }
    const prev = get(row.ply - 1);
    if (row.ply > 0 && prev && Number.isFinite(Number(prev.scoreWhiteCp))) {
      row.scoreBeforeWhiteCp = prev.scoreWhiteCp;
      if (prev.bestUci) { syncBestFields(row, 'best', prev, helpers.fenAt?.(row.ply - 1), helpers); row.bestMoveUci = prev.bestUci; }
      row.bestMoveDepth = Math.max(Number(row.bestMoveDepth) || 0, Number(prev.depth) || 0);
      if (Number.isFinite(Number(prev.secondWhiteCp))) row.secondBeforeWhiteCp = prev.secondWhiteCp;
    }
  }
  // Pass 2: re-judge every row that touched a verified position.
  for (const row of rows) {
    if (!row || !(row.ply > 0)) continue;
    if (!get(row.ply) && !get(row.ply - 1)) continue;
    const result = judgeMoveFromEvals(
      { scoreWhiteCp: row.scoreBeforeWhiteCp, secondWhiteCp: row.secondBeforeWhiteCp, depth: row.bestMoveDepth, bestUci: row.bestMoveUci },
      { scoreWhiteCp: row.scoreWhiteCp, depth: row.engineDepth },
      { mover: row.mover, uci: row.playedUci, bookMove: row.bookMove, sacrifice: row.sacrifice }
    );
    if (!result.judgement) continue;
    if (row.judgement?.key !== result.judgement.key) changed += 1;
    row.lossCp = result.lossCp;
    row.judgement = result.judgement;
    row.moveWasBest = result.moveWasBest;
  }
  return changed;
}
