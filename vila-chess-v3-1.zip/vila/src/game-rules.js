/**
 * Shared, dependency-free chess *result* rules.
 *
 * One implementation is imported by the browser app, the Node backend (server/social.js) and the
 * Cloudflare Worker, so a game can never end differently depending on where it was played.
 * Everything here works on plain FEN text; it does not need chess.js and is unit-tested in Node.
 *
 * Rules implemented
 *  - FIDE Laws 6.9: a player whose flag falls loses ONLY if the opponent could still checkmate by
 *    some series of legal moves. Otherwise the game is drawn.
 *  - Ranked abort rule: a game in which either side has not yet moved (fewer than 2 plies) ends with
 *    no result and no rating change when someone resigns, leaves, disconnects or runs out of time.
 *    Without it two accounts can trade rating by queueing together and abandoning on move 0.
 */

export const RANKED_MIN_PLIES = 2;
/** Reasons that end a game because a player stopped playing (as opposed to a result on the board). */
export const FORFEIT_REASONS = Object.freeze(['resignation', 'abandoned', 'disconnect_timeout', 'time_forfeit']);

function emptySide() {
  return { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0, bishopsLight: 0, bishopsDark: 0 };
}

/**
 * Count pieces per side from a FEN. Returns null for anything that is not a well-formed 8x8 board so
 * callers can fall back to the conservative answer ("the flagged player loses").
 */
export function parseFenMaterial(fen) {
  const board = String(fen || '').trim().split(/\s+/)[0] || '';
  const rows = board.split('/');
  if (rows.length !== 8) return null;
  const sides = { w: emptySide(), b: emptySide() };
  for (let row = 0; row < 8; row += 1) {
    let file = 0;
    for (const ch of rows[row]) {
      if (ch >= '1' && ch <= '8') { file += Number(ch); continue; }
      const kind = ch.toLowerCase();
      if (!'pnbrqk'.includes(kind) || kind.length !== 1 || file > 7) return null;
      const side = sides[ch === kind ? 'b' : 'w'];
      side[kind] += 1;
      if (kind === 'b') {
        const rank = 7 - row; // 0 = rank 1
        side[(file + rank) % 2 === 0 ? 'bishopsDark' : 'bishopsLight'] += 1; // a1 is a dark square
      }
      file += 1;
    }
    if (file !== 8) return null;
  }
  if (sides.w.k !== 1 || sides.b.k !== 1) return null;
  return sides;
}

/**
 * True when `color` can NOT deliver checkmate in any sequence of legal moves, even if the opponent
 * cooperates. Deliberately conservative: when in doubt the answer is false, so a player who flags is
 * only spared when a draw is certain.
 *  - lone king                                   -> cannot mate
 *  - king + one minor piece, opponent bare king  -> cannot mate
 *  - king + bishops all on one colour, opponent bare king -> cannot mate
 *  - king + two knights vs bare king             -> mate is possible (cooperation), so NOT insufficient
 *  - any pawn / rook / queen, or an opponent with any other piece (a blocker makes helpmates possible) -> sufficient
 */
export function hasInsufficientMatingMaterial(fen, color) {
  if (color !== 'w' && color !== 'b') return false;
  const material = parseFenMaterial(fen);
  if (!material) return false;
  const me = material[color];
  const opponent = material[color === 'w' ? 'b' : 'w'];
  if (me.p || me.r || me.q) return false;
  const minors = me.n + me.b;
  if (minors === 0) return true;
  const opponentIsBareKing = opponent.p + opponent.n + opponent.b + opponent.r + opponent.q === 0;
  if (!opponentIsBareKing) return false;
  if (minors === 1) return true;
  return me.n === 0 && (me.bishopsLight === 0 || me.bishopsDark === 0);
}

/** Result when `flaggedColor` runs out of time in position `fen` (FIDE 6.9). */
export function resolveFlagResult(fen, flaggedColor) {
  if (flaggedColor !== 'w' && flaggedColor !== 'b') return { result: '*', reason: 'invalid_color', drawn: false };
  const winner = flaggedColor === 'w' ? 'b' : 'w';
  if (hasInsufficientMatingMaterial(fen, winner)) {
    return { result: '1/2-1/2', reason: 'timeout_vs_insufficient', drawn: true, winner: null };
  }
  return { result: winner === 'w' ? '1-0' : '0-1', reason: 'time_forfeit', drawn: false, winner };
}

/**
 * Decide how a ranked game really ends. Backends call this once, right before applying ratings.
 * @param {object} input
 * @param {string} input.result   '1-0' | '0-1' | '1/2-1/2' proposed by the caller
 * @param {string} input.reason   'checkmate' | 'draw' | 'resignation' | 'abandoned' | 'disconnect_timeout' | 'time_forfeit' | ...
 * @param {number} input.plyCount half-moves played so far
 * @param {string} input.fen      current position (used for the flag rule)
 * @returns {{status:'finished'|'aborted', result:string|null, reason:string, rated:boolean, originalReason?:string}}
 */
export function planRankedFinish({ result, reason = 'game_over', plyCount = 0, fen = '' } = {}) {
  if (FORFEIT_REASONS.includes(reason) && !(Number(plyCount) >= RANKED_MIN_PLIES)) {
    return { status: 'aborted', result: null, reason: 'aborted', originalReason: reason, rated: false };
  }
  if (reason === 'time_forfeit' && (result === '1-0' || result === '0-1')) {
    const flagged = result === '1-0' ? 'b' : 'w';
    const outcome = resolveFlagResult(fen, flagged);
    return { status: 'finished', result: outcome.result, reason: outcome.reason, rated: true };
  }
  return { status: 'finished', result, reason, rated: true };
}
