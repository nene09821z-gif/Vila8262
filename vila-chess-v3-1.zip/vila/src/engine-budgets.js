const clamp = (value, min, max) => Math.max(min, Math.min(max, Math.round(Number(value) || 0)));

/** Resolve a bounded, phone-friendly budget for VILA's in-app alpha-beta engine.
 * Stockfish is still the primary engine; this profile is used for VILA mode and rescue.
 */
export function resolveOfflineSearchBudget(profile = 'ethereal', settings = {}) {
  const lightweight = profile === 'blitz' || profile === 'rookie';
  if (settings.beginnerPractice === true) {
    // The fallback engine is still much stronger than a beginner at deep settings. For Elo 500,
    // use a truly short phone-safe budget and let the caller apply the legal-only handicap too.
    const beginnerMs = clamp(settings.botMoveTimeMs ?? 260, 120, 500);
    const beginnerDepth = clamp(settings.botDepth ?? 5, 3, 5);
    return {
      profile: lightweight ? profile : 'rookie',
      depth: beginnerDepth,
      maxTimeMs: clamp(beginnerMs, 180, 350),
      maxNodes: clamp(beginnerMs * 100, 20000, 45000),
    };
  }
  const rawMs = clamp(settings.botMoveTimeMs ?? 2600, 500, 5000) || 2600;
  const rawDepth = clamp(settings.botDepth ?? 30, 5, 30) || 30;
  // v3.49: stronger offline bots — deeper search and larger node/time budgets, still hard-capped for phones.
  const maxTimeMs = lightweight
    ? clamp(rawMs * 0.7, 600, 1800)
    : clamp(rawMs * 1.15, 1200, 4200);
  const depth = lightweight
    ? clamp(Math.floor(rawDepth / 3.5), 3, 7)
    : clamp(Math.floor(rawDepth / 2.5), 5, 11);
  const maxNodes = lightweight
    ? clamp(maxTimeMs * 100, 60000, 180000)
    : clamp(maxTimeMs * 190, 160000, 600000);
  return { profile, depth, maxTimeMs, maxNodes };
}

/** Full-game review must spend enough time per position for a useful stable score.
 * The value is still bounded for mobile devices; callers show progress and can stop a review. */
export function resolveReviewMoveTimeMs(settings = {}) {
  const configured = clamp(settings.analysisMoveTimeMs ?? 2600, 1000, 8000) || 2600;
  // "max" is the strongest Stockfish 19 review this app can run: longest search, MultiPV 2 for only-move detection.
  if (settings.reviewQuality === 'max') return 8000;
  // "fast" is the default: about one second per position so a 60-move game reviews in roughly two minutes.
  if (settings.reviewQuality === 'fast') return clamp(configured * 0.4, 600, 1200);
  if (settings.reviewQuality === 'deep') return clamp(configured * 1.5, 3000, 6000);
  return clamp(configured * 0.85, 1200, 4200);
}

/** Two-pass review plan (v3.69.5): a quick first search of every position, then a deeper search of the few
 * positions around doubtful moves (src/review-verify.js). Same total time as the old single pass, spent where it matters. */
export function resolveReviewPlan(settings = {}) {
  const base = resolveReviewMoveTimeMs(settings);
  return { firstMs: clamp(Math.round(base * 0.45), 400, 3600), verifyMs: clamp(Math.round(base * 1.9), 1600, 12000) };
}
