/**
 * Review board motion (FLIP).
 *
 * The review board is re-rendered with innerHTML on every ply, so pieces used to teleport. These helpers
 * snapshot the board before the repaint and slide the pieces that moved from their old square afterwards,
 * so stepping with the arrows / swipe / move list feels like a real move. Pure planning code is exported
 * for Node tests; `captureReviewBoard` / `animateReviewBoard` touch the DOM.
 */

export const REVIEW_SLIDE_EASING = 'cubic-bezier(0.22, 0.82, 0.18, 1)';

/** Slide time (ms) by distance measured in squares: 1 square ≈ 150 ms, long slides cap at 260 ms. */
export function reviewSlideMs(squares = 1) {
  const d = Math.max(0, Number(squares) || 0);
  return Math.round(Math.min(260, Math.max(130, 120 + d * 30)));
}

/**
 * Plan which pieces moved between two snapshots.
 * A snapshot is a Map square -> { key, x, y } where `key` identifies colour+type (e.g. "wN") and (x, y) is the
 * centre of the square in px. Returns { moves: [{ to, from, dx, dy, squares }], captured: [square] }.
 * Pieces that did not change are ignored; a piece that appeared on a square that held something else is
 * matched with the nearest square that lost a piece of the same kind (handles castling and promotion-free moves).
 */
export function planReviewMoves(before, after) {
  const lost = [];
  const gained = [];
  const captured = [];
  for (const [sq, old] of before) {
    const now = after.get(sq);
    if (!now || now.key !== old.key) lost.push([sq, old]);
  }
  for (const [sq, now] of after) {
    const old = before.get(sq);
    if (!old || old.key !== now.key) gained.push([sq, now]);
  }
  const moves = [];
  const used = new Set();
  // Closest pairs first so castling pairs the king with the king and the rook with the rook.
  const pairs = [];
  for (const [to, now] of gained) {
    for (const [from, old] of lost) {
      if (old.key !== now.key) continue;
      pairs.push({ to, from, now, old, dist: Math.hypot(now.x - old.x, now.y - old.y) });
    }
  }
  pairs.sort((a, b) => a.dist - b.dist);
  const takenTo = new Set();
  for (const pair of pairs) {
    if (used.has(pair.from) || takenTo.has(pair.to)) continue;
    used.add(pair.from);
    takenTo.add(pair.to);
    moves.push({
      to: pair.to,
      from: pair.from,
      dx: pair.old.x - pair.now.x,
      dy: pair.old.y - pair.now.y,
      dist: pair.dist
    });
  }
  // A square that held one piece and now holds a different one was a capture (or a promotion).
  for (const [sq, old] of before) {
    const now = after.get(sq);
    if (now && now.key !== old.key) captured.push(sq);
  }
  return { moves, captured };
}

function reducedMotion() {
  return typeof window !== 'undefined' && Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches);
}

/** Snapshot the pieces of a review board: Map square -> { key, x, y }. */
export function captureReviewBoard(boardEl) {
  const snap = new Map();
  if (!boardEl?.querySelectorAll) return snap;
  for (const cell of boardEl.querySelectorAll('.review-replay-square[data-square]')) {
    const piece = cell.querySelector('.review-replay-piece');
    if (!piece) continue;
    const rect = cell.getBoundingClientRect();
    snap.set(cell.dataset.square, {
      key: piece.dataset.piece || '',
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    });
  }
  return snap;
}

/**
 * Slide pieces on the freshly rendered `boardEl` from where `before` (captureReviewBoard) had them.
 * Skipped for reduced motion, for big jumps (> `maxJump` plies handled by the caller) and when the board flipped.
 * Returns the number of animated pieces.
 */
export function animateReviewBoard(boardEl, before, { skip = false } = {}) {
  if (skip || !before?.size || !boardEl?.querySelectorAll || reducedMotion()) return 0;
  const after = captureReviewBoard(boardEl);
  const { moves } = planReviewMoves(before, after);
  if (!moves.length || moves.length > 4) return 0; // a long jump or a new position: do not animate every piece
  let count = 0;
  for (const move of moves) {
    const cell = boardEl.querySelector(`.review-replay-square[data-square="${move.to}"]`);
    const piece = cell?.querySelector('.review-replay-piece');
    if (!piece || typeof piece.animate !== 'function') continue;
    const size = cell.getBoundingClientRect().width || 1;
    cell.classList.add('rv-sliding');
    const animation = piece.animate(
      [{ translate: `${move.dx.toFixed(1)}px ${move.dy.toFixed(1)}px` }, { translate: '0px 0px' }],
      { duration: reviewSlideMs(move.dist / size), easing: REVIEW_SLIDE_EASING, fill: 'none' }
    );
    const done = () => cell.classList.remove('rv-sliding');
    animation.addEventListener('finish', done);
    animation.addEventListener('cancel', done);
    count += 1;
  }
  return count;
}
