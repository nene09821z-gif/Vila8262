/**
 * Adaptive performance governor.
 *
 * Measures real frame times while a piece is dragged or slides. If the device repeatedly drops frames,
 * it switches the whole app to a "lite" look (data-perf="lite" on <html>): no backdrop blur, no filters
 * outside the board, no decorative infinite animations. Piece motion itself (transform only) is never reduced.
 * The decision is remembered on the device. `?perf=lite|full` forces a tier, `?perf=1` shows a small probe.
 *
 * Pure functions (summarizeFrames, decideTier) are exported for Node tests; the rest touches the DOM.
 */
export const PERF_KEY = 'vila.perfTier';
export const MIN_FRAMES = 14;
export const JANK_RATIO = 0.2;

const median = list => { const s = [...list].sort((a, b) => a - b); return s.length ? s[Math.floor(s.length / 2)] : 0; };

/** Frame deltas (ms) -> { count, medianMs, p95Ms, jankRatio, fps }. A frame is janky when it is far above the device's own rhythm. */
export function summarizeFrames(deltas) {
  const list = (deltas || []).filter(d => Number.isFinite(d) && d > 0 && d < 1000);
  if (!list.length) return { count: 0, medianMs: 0, p95Ms: 0, jankRatio: 0, fps: 0 };
  const med = median(list);
  const limit = Math.max(24, med * 1.8);
  const sorted = [...list].sort((a, b) => a - b);
  const p95 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))];
  const janky = list.filter(d => d > limit).length;
  return { count: list.length, medianMs: med, p95Ms: p95, jankRatio: janky / list.length, fps: 1000 / (list.reduce((a, b) => a + b, 0) / list.length) };
}

/** Two janky sessions among the last four switch to lite. Too little data never changes anything. */
export function decideTier(history, current = 'full') {
  if (current === 'lite') return 'lite';
  const recent = (history || []).slice(-4);
  const janky = recent.filter(s => s.count >= MIN_FRAMES && s.jankRatio >= JANK_RATIO).length;
  return janky >= 2 ? 'lite' : 'full';
}

function readUrlOverride(search) {
  try {
    const value = new URLSearchParams(search || '').get('perf');
    return value === 'lite' || value === 'full' ? value : value === '1' ? 'probe' : '';
  } catch { return ''; }
}


/** Phones and weak devices start in the lite look so the first screens are already smooth (never persisted: a real measurement can still switch to full). */
export function looksLowEnd(win) {
  try {
    const nav = win?.navigator;
    if (!nav) return false;
    const coarse = Boolean(win.matchMedia?.('(pointer: coarse)')?.matches);
    const memory = Number(nav.deviceMemory);
    const cores = Number(nav.hardwareConcurrency);
    const saveData = Boolean(nav.connection?.saveData);
    const reduced = Boolean(win.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches);
    return saveData || reduced || (coarse && ((Number.isFinite(memory) && memory <= 4) || (Number.isFinite(cores) && cores <= 8)));
  } catch { return false; }
}

export function createPerfGovernor({
  win = typeof window !== 'undefined' ? window : null,
  doc = typeof document !== 'undefined' ? document : null,
  storage = (() => { try { return win?.localStorage || null; } catch { return null; } })(),
  raf = win?.requestAnimationFrame?.bind(win),
  caf = win?.cancelAnimationFrame?.bind(win),
  now = () => (win?.performance?.now ? win.performance.now() : Date.now())
} = {}) {
  let tier = 'full';
  let history = [];
  let session = null;
  let probe = null;
  const override = readUrlOverride(win?.location?.search);

  const apply = next => {
    tier = next;
    if (doc?.documentElement) doc.documentElement.dataset.perf = next;
    if (storage && !override) { try { storage.setItem(PERF_KEY, next); } catch { /* private mode */ } }
  };
  const showProbe = summary => {
    if (override !== 'probe' || !doc?.body) return;
    if (!probe) {
      probe = doc.createElement('div');
      probe.setAttribute('aria-hidden', 'true');
      probe.style.cssText = 'position:fixed;left:6px;top:calc(env(safe-area-inset-top,0px) + 4px);z-index:2147483000;padding:4px 7px;border-radius:8px;background:rgba(0,0,0,.78);color:#9f9;font:11px/1.3 monospace;pointer-events:none;white-space:pre';
      doc.body.appendChild(probe);
    }
    probe.textContent = `perf ${tier} · ${summary.label}\nfps ${summary.fps.toFixed(0)} · p95 ${summary.p95Ms.toFixed(0)}ms · jank ${(summary.jankRatio * 100).toFixed(0)}% · n=${summary.count}`;
  };

  // Startup: URL override wins, then the remembered tier, then a quick hardware guess (phone / few cores / little RAM).
  let saved = '';
  try { saved = storage?.getItem(PERF_KEY) || ''; } catch { saved = ''; }
  tier = override === 'lite' || override === 'full' ? override : (saved === 'lite' ? 'lite' : (saved === 'full' ? 'full' : (looksLowEnd(win) ? 'lite' : 'full')));
  if (doc?.documentElement) doc.documentElement.dataset.perf = tier;

  function begin(label = 'drag') {
    if (session || !raf) return false;
    session = { label, deltas: [], last: 0, id: 0 };
    const tick = stamp => {
      if (!session) return;
      if (session.last) session.deltas.push(stamp - session.last);
      session.last = stamp;
      session.id = raf(tick);
    };
    session.id = raf(tick);
    return true;
  }

  /** `onlyLabel` lets a timed session (a slide) end without cutting a drag that started meanwhile. */
  function end(onlyLabel) {
    if (!session || (onlyLabel && session.label !== onlyLabel)) return null;
    const done = session; session = null;
    try { caf?.(done.id); } catch { /* ignore */ }
    const summary = { ...summarizeFrames(done.deltas), label: done.label };
    if (summary.count >= MIN_FRAMES) {
      history = [...history, summary].slice(-6);
      if (!override) {
        const next = decideTier(history, tier);
        if (next !== tier) apply(next);
      }
    }
    showProbe(summary);
    return summary;
  }

  return { begin, end, get tier() { return tier; }, get history() { return history.slice(); }, force: apply, _now: now };
}
