/**
 * Xuất PGN kèm đánh giá của Stockfish (NAG, [%eval] và nhận xét) để chia sẻ hoặc mở bằng công cụ khác.
 * Hàng dữ liệu là các đối tượng do bước phân tích toàn ván tạo ra (ply, mover, san, judgement, scoreWhiteCp, ...).
 */
const NEGATIVE = new Set(['inaccuracy', 'mistake', 'missed-win', 'blunder']);
const finite = value => Number.isFinite(Number(value)) && value !== null && value !== '';
const usable = rows => (Array.isArray(rows) ? rows : []).filter(row => row && row.ply > 0 && row.san && (row.mover === 'w' || row.mover === 'b')).sort((a, b) => a.ply - b.ply);

const NAG = { brilliant: 3, great: 1, inaccuracy: 6, mistake: 2, 'missed-win': 2, blunder: 4 };
const cleanComment = text => String(text || '').replace(/[{}\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
const headerValue = text => String(text ?? '?').replace(/[\\"\r\n]/g, ch => (ch === '"' || ch === '\\' ? `\\${ch}` : ' '));
function evalTag(row) {
  if (!finite(row.scoreWhiteCp)) return '';
  if (row.scoreType === 'mate' || Math.abs(Number(row.scoreWhiteCp)) >= 9900) {
    const n = finite(row.mateWhite) ? Math.abs(Number(row.mateWhite)) : 0;
    return `[%eval #${Number(row.scoreWhiteCp) < 0 ? '-' : ''}${n}]`;
  }
  return `[%eval ${(Number(row.scoreWhiteCp) / 100).toFixed(2)}]`;
}

/**
 * PGN with Stockfish annotations. Moves come from the reviewed rows (must start at ply 1 and be contiguous).
 * @param {{headers?:Record<string,string>, startFen?:string, result?:string}} options
 */
export function buildAnnotatedPgn(rows, { headers = {}, startFen = '', result = '*' } = {}) {
  const list = usable(rows);
  const moves = [];
  for (const row of list) { if (row.ply !== moves.length + 1) break; moves.push(row); }
  const token = ['1-0', '0-1', '1/2-1/2', '*'].includes(result) ? result : '*';
  const base = { Event: 'ChessPlus', Site: 'ChessPlus', Date: new Date().toISOString().slice(0, 10).replace(/-/g, '.'), Round: '-', White: 'Trắng', Black: 'Đen', ...headers, Result: token };
  const standard = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const head = Object.entries(base).map(([k, v]) => `[${k.replace(/[^A-Za-z0-9_]/g, '')} "${headerValue(v)}"]`);
  if (startFen && startFen !== standard) head.push('[SetUp "1"]', `[FEN "${headerValue(startFen)}"]`);
  head.push('[Annotator "ChessPlus · Stockfish"]');
  const parts = moves.map(row => {
    const number = row.mover === 'b' ? `${Math.ceil(row.ply / 2)}...` : `${Math.ceil(row.ply / 2)}.`;
    const nag = NAG[row.judgement?.key] ? ` $${NAG[row.judgement.key]}` : '';
    const notes = [];
    const tag = evalTag(row); if (tag) notes.push(tag);
    if (row.judgement?.label && NEGATIVE.has(row.judgement.key)) notes.push(cleanComment(row.judgement.label));
    if (!row.moveWasBest && row.bestMoveSan && NEGATIVE.has(row.judgement?.key)) notes.push(`Nên đi: ${cleanComment(row.bestMoveSan)}`);
    if (row.judgement?.key === 'brilliant') notes.push('Nước thiên tài');
    return `${number} ${row.san}${nag}${notes.length ? ` { ${notes.join(' · ')} }` : ''}`;
  });
  const body = parts.join(' ');
  // wrap at ~80 columns without splitting a comment's braces across lines unpredictably
  const wrapped = body.replace(/(.{1,78})(\s+|$)/g, '$1\n').trim();
  return `${head.join('\n')}\n\n${wrapped}${wrapped ? ' ' : ''}${token}\n`;
}
