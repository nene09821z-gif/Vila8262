/**
 * Play Billing — web side (v3.57). The Android shell (`PlayBilling.kt`) owns the Google dialog; the Worker owns the
 * decision of who is paid. This module is the glue and is dependency-injected so it can be tested without a phone.
 *
 * Flow:  buy -> native sheet -> native event "purchased"(token) -> POST /me/purchase/verify -> server grants
 *        -> only then tell native to consume (Pro and Diamond, so they can be bought again) or acknowledge (Premium).
 * A purchase that was paid but never verified stays owned on Google's side, so `restore` re-sends it later.
 */
export const BILLING_EVENT = 'vila-native-billing';

/** Wraps window.AndroidBridge; returns null in a browser / older APK that has no billing. */
export function nativeBillingBridge(win = globalThis) {
  const bridge = win?.AndroidBridge;
  if (!bridge || typeof bridge.billingStart !== 'function') return null;
  const call = (name, ...args) => { try { return bridge[name]?.(...args); } catch { return undefined; } };
  return {
    available: () => call('billingAvailable') !== false,
    init: (productIds) => call('billingInit', JSON.stringify(productIds)),
    start: (productId, accountId) => call('billingStart', String(productId), String(accountId)) === true,
    queryOwned: () => call('billingQueryOwned'),
    finish: (purchaseToken, consume) => call('billingFinish', String(purchaseToken), Boolean(consume))
  };
}

/** Which purchase button to show for each plan, given what the account already has. */
export function planPurchaseUi(plan, daysLeft = 0, diamondLeft = 0) {
  const diamond = { show: true, label: plan === 'diamond' ? 'Gia hạn Kim Cương thêm 1 năm (cộng dồn)' : 'Mua Kim Cương 1 năm', expiringSoon: plan === 'diamond' && diamondLeft > 0 && diamondLeft <= 14 };
  if (plan === 'free') return { pro: { show: true, label: 'Mua Pro 1 năm' }, premium: { show: true, label: 'Mua Premium trọn đời' }, diamond };
  if (plan === 'pro') {
    return {
      pro: { show: true, label: 'Gia hạn thêm 1 năm (cộng dồn)', expiringSoon: daysLeft > 0 && daysLeft <= 14 },
      premium: { show: true, label: 'Nâng lên Premium trọn đời' },
      diamond
    };
  }
  // premium/diamond: Pro and Premium have nothing left to buy; Diamond can always be bought or renewed (it stacks).
  return { pro: { show: false, label: '' }, premium: { show: false, label: '' }, diamond };
}

/**
 * Send one native purchase to the server, then close it out on Google's side.
 * Resolves { status: 'granted'|'already'|'pending', entitlement, plan }; throws on a server refusal so nothing is
 * consumed or acknowledged for a purchase the server did not accept.
 */
export async function verifyPurchase({ api, bridge, purchase }) {
  const productId = String(purchase?.productId || ''), purchaseToken = String(purchase?.purchaseToken || '');
  if (!productId || !purchaseToken) throw Object.assign(new Error('Giao dịch không hợp lệ.'), { status: 400 });
  const data = await api('/me/purchase/verify', { method: 'POST', body: JSON.stringify({ productId, purchaseToken }) });
  if (data?.pending) return { status: 'pending', message: data.message };
  bridge?.finish(purchaseToken, Boolean(data?.consume));
  return { status: data?.alreadyGranted ? 'already' : 'granted', entitlement: data?.entitlement, plan: data?.plan };
}

/** Sequential on purpose: two verifications for one account must not interleave. */
export function createPurchaseQueue({ api, bridge, getBridge, onResult, onError }) {
  const currentBridge = () => (typeof getBridge === 'function' ? getBridge() : bridge);
  let chain = Promise.resolve();
  const seen = new Set();
  return {
    push(purchase) {
      const token = String(purchase?.purchaseToken || '');
      if (token && seen.has(token)) return chain; // the same token can arrive from both the buy flow and restore
      if (token) seen.add(token);
      chain = chain.then(async () => {
        try { onResult?.(await verifyPurchase({ api, bridge: currentBridge(), purchase }), purchase); }
        catch (error) { seen.delete(token); onError?.(error, purchase); } // allow a retry (offline, Google hiccup)
      });
      return chain;
    }
  };
}

export function billingErrorMessage(error) {
  const status = error?.status;
  if (status === 503) return 'Thanh toán chưa được bật trên máy chủ. Hãy thử lại sau.';
  if (status === 404) return 'Google Play không xác nhận giao dịch này. Nếu bạn đã bị trừ tiền, hãy mở lại mục Gói để khôi phục.';
  if (status === 403) return 'Giao dịch này thuộc tài khoản khác.';
  if (status === 409) return 'Giao dịch này đã được dùng hoặc đã hoàn tiền.';
  if (status === 401) return 'Hãy đăng nhập lại để hoàn tất giao dịch.';
  return 'Chưa xác nhận được giao dịch. Gói sẽ được kích hoạt khi mở lại mục Gói có mạng.';
}
