/** Recognize the longest named opening prefix without rescanning every ECO line. */
const trieCache = new WeakMap();

/** SAN may carry check/mate/annotation suffixes that vary across PGN sources. */
export function normalizeOpeningSan(value) {
  return String(value ?? '').trim().replace(/0-0-0/g, 'O-O-O').replace(/0-0/g, 'O-O').replace(/[+#?!]+$/g, '');
}

function buildTrie(openings) {
  const root = { children: new Map(), endings: [], firstDescendant: null };
  for (const opening of openings) {
    if (opening?.catalogOnly === true) continue;
    const line = opening?.san;
    if (!Array.isArray(line) || line.length < 2) continue;
    let node = root;
    for (const san of line) {
      const key = normalizeOpeningSan(san);
      if (!node.children.has(key)) node.children.set(key, { children: new Map(), endings: [], firstDescendant: opening });
      node = node.children.get(key);
    }
    node.endings.push(opening);
  }
  return root;
}

function getTrie(openings) {
  const cached = trieCache.get(openings);
  if (cached?.length === openings.length) return cached.root;
  const root = buildTrie(openings);
  trieCache.set(openings, { length: openings.length, root });
  return root;
}

/** Build the trie ahead of time (idle callback) so the first recognised move of a game does not pay for it. */
export function prewarmOpeningTrie(openings) {
  if (Array.isArray(openings)) getTrie(openings);
}

export function recognizeOpening(history = [], openings = [], options = {}) {
  const minPlies = Math.max(1, Math.min(12, Number(options.minPlies ?? 2) || 2));
  if (!Array.isArray(history) || history.length < minPlies || !Array.isArray(openings)) return null;
  let node = getTrie(openings);
  let bestEnding = null;
  for (let index = 0; index < history.length; index += 1) {
    node = node.children.get(normalizeOpeningSan(history[index]));
    if (!node) return bestEnding;
    if (node.endings.length) bestEnding = node.endings[0];
  }
  // If the played history exactly names an entry, prefer that over a longer branch.
  if (node.endings.length) return node.endings[0];
  return node.firstDescendant || bestEnding;
}
