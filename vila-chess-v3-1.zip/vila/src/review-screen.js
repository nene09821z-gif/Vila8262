/**
 * ChessPlus — màn «Tổng kết ván đấu» và «Xem lại ván đấu» (thay hoàn toàn trang phân tích cũ).
 * Module này chỉ sinh markup từ dữ liệu thuần, không đụng DOM hay engine, nên test được bằng Node.
 * main.js giữ trạng thái (ván cờ, Stockfish, hàng phân tích) và gắn sự kiện.
 */
const escDefault = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export const BRAND_MARK_SRC = './chessplus-mark.svg?v=2';

/** Huy hiệu chất lượng nước đi: khóa phân loại → ký hiệu + màu (class b-*). */
export function badgeFor(key) {
  return ({
    brilliant: { glyph: '!!', cls: 'b-brilliant', label: 'Nước đi xuất sắc' },
    great: { glyph: '!', cls: 'b-great', label: 'Nước đi hay' },
    best: { glyph: '★', cls: 'b-best', label: 'Nước đi tốt nhất' },
    excellent: { glyph: '✓', cls: 'b-good', label: 'Nước đi tốt' },
    good: { glyph: '✓', cls: 'b-good', label: 'Nước đi tốt' },
    book: { glyph: '♙', cls: 'b-book', label: 'Nước trong sách khai cuộc' },
    inaccuracy: { glyph: '?', cls: 'b-unclear', label: 'Nước đi không rõ' },
    mistake: { glyph: '?', cls: 'b-mistake', label: 'Nước đi sai' },
    blunder: { glyph: '✕', cls: 'b-blunder', label: 'Nước đi mắc lỗi' },
    'missed-win': { glyph: '??', cls: 'b-miss', label: 'Nước đi bỏ lỡ' }
  })[key] || null;
}

/** Tám dòng thống kê của trang tổng kết, đúng thứ tự trong thiết kế. */
export const REVIEW_TALLY = Object.freeze([
  { id: 'brilliant', label: 'Nước đi xuất sắc', keys: ['brilliant'], badge: 'brilliant' },
  { id: 'great', label: 'Nước đi hay', keys: ['great'], badge: 'great' },
  { id: 'best', label: 'Nước đi tốt nhất', keys: ['best', 'book'], badge: 'best' },
  { id: 'good', label: 'Nước đi tốt', keys: ['excellent', 'good'], badge: 'good' },
  { id: 'unclear', label: 'Nước đi không rõ', keys: ['inaccuracy'], badge: 'inaccuracy' },
  { id: 'mistake', label: 'Nước đi sai', keys: ['mistake'], badge: 'mistake' },
  { id: 'blunder', label: 'Nước đi mắc lỗi', keys: ['blunder'], badge: 'blunder' },
  { id: 'miss', label: 'Nước đi bỏ lỡ', keys: ['missed-win'], badge: 'missed-win' }
]);

/** Đếm số nước theo từng nhóm cho một bên ('w' | 'b'). */
export function tallyMoves(rows = [], side = 'w') {
  const out = Object.fromEntries(REVIEW_TALLY.map(item => [item.id, 0]));
  for (const row of Array.isArray(rows) ? rows : []) {
    if (!row || !(row.ply > 0) || !row.judgement?.key) continue;
    if ((row.mover || row.color) !== side) continue;
    const bucket = REVIEW_TALLY.find(item => item.keys.includes(row.judgement.key));
    if (bucket) out[bucket.id] += 1;
  }
  return out;
}


/** Biểu tượng giai đoạn vẽ bằng SVG (không dùng ký tự ♞ ♜ ♚ vì mỗi máy hiển thị một kiểu, có máy thành emoji lệch màu). */
const phaseSvg = d => `<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" focusable="false"><path fill="currentColor" d="${d}"/></svg>`;
export const PHASE_ICONS = Object.freeze({
  opening: phaseSvg('M6 21h12v-2.2H6zM8.2 17.4h9.6c.4-4.6-.9-8.4-4.4-10l.9-2.5-2.2.9C9.1 4.5 6.5 6.9 5.9 11l2.7 1.6 1.2-2 1.1.8c-2.2 1.6-2.7 3.8-2.7 6z'),
  middlegame: phaseSvg('M6 21h12v-2.2H6zM7.6 17.4h8.8l-.7-7H8.3zM6.5 9.2h11V4.6h-2.1v1.7h-1.8V4.6h-3.2v1.7H8.6V4.6H6.5z'),
  endgame: phaseSvg('M11 2h2v2h2v2h-2v2.3c3.1.6 5.3 2.7 5.3 5.4 0 1.7-.8 2.9-1.8 3.7v1.6H7.5v-1.6c-1-.8-1.8-2-1.8-3.7 0-2.7 2.2-4.8 5.3-5.4V6H9V4h2zM6 21h12v-2H6z')
});

/** Điểm xếp loại cho từng giai đoạn (độ chính xác %). */
export function phaseGrade(accuracy) {
  const value = Number(accuracy);
  if (accuracy == null || !Number.isFinite(value)) return { key: 'none', label: '—', glyph: '' };
  if (value >= 94) return { key: 'great', label: 'Tuyệt vời', glyph: '★' };
  if (value >= 90) return { key: 'best', label: 'Xuất sắc', glyph: '★' };
  if (value >= 78) return { key: 'good', label: 'Tốt', glyph: '★' };
  if (value >= 62) return { key: 'unclear', label: 'Thiếu chính xác', glyph: '?' };
  if (value >= 45) return { key: 'mistake', label: 'Sai lầm', glyph: '?' };
  return { key: 'blunder', label: 'Sai lầm nghiêm trọng', glyph: '✕' };
}

/** Kết quả nhìn từ phía người chơi: tỉ số, nhãn, tông màu, câu chúc. */
export function resultView({ token = '*', side = 'w', human = true } = {}) {
  const draw = token === '1/2-1/2';
  const whiteWon = token === '1-0';
  const blackWon = token === '0-1';
  if (!draw && !whiteWon && !blackWon) {
    return { score: '– : –', pill: 'Chưa kết thúc', tone: 'pending', subtitle: 'Ván cờ đang xem lại.' };
  }
  if (draw) return { score: '½ - ½', pill: 'Hòa', tone: 'draw', subtitle: 'Một ván cờ cân bằng và đầy thử thách!' };
  const youWon = (side === 'w' && whiteWon) || (side === 'b' && blackWon);
  if (!human) {
    return { score: whiteWon ? '1 - 0' : '0 - 1', pill: whiteWon ? 'Trắng thắng!' : 'Đen thắng!', tone: 'win', subtitle: 'Trận đấu đã khép lại.' };
  }
  return youWon
    ? { score: '1 - 0', pill: 'Bạn thắng!', tone: 'win', subtitle: 'Trận đấu diễn ra thật tuyệt vời!' }
    : { score: '0 - 1', pill: 'Bạn thua', tone: 'loss', subtitle: 'Cố lên! Xem lại các nước đi để tiến bộ hơn.' };
}

const squashCp = cp => Math.tanh((Number(cp) || 0) / 300);

/** Biểu đồ lợi thế (vùng xanh = bạn đang hơn). rows có scoreWhiteCp; side là phía người xem. */
export function evalChartMarkup(rows = [], side = 'w') {
  const sign = side === 'b' ? -1 : 1;
  const points = (Array.isArray(rows) ? rows : [])
    .filter(row => row && row.ply > 0 && Number.isFinite(row.scoreWhiteCp))
    .sort((a, b) => a.ply - b.ply);
  const axis = '<div class="rv2-chart-axis" aria-hidden="true"><span>+1.0</span><span>0.0</span><span>-1.0</span></div>';
  if (points.length < 2) {
    return `<div class="rv2-chart is-empty">${axis}<div class="rv2-chart-body"><p>Chưa có biểu đồ — hãy phân tích ván đấu.</p></div></div>`;
  }
  const W = 600, H = 150, pad = 8, mid = H / 2;
  const xy = points.map((row, index) => {
    const x = (W * index) / (points.length - 1);
    const y = mid - squashCp(sign * row.scoreWhiteCp) * (mid - pad);
    return [x, y];
  });
  const line = xy.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(' ');
  const area = `M0,${mid} ${xy.map(([x, y]) => `L${x.toFixed(1)},${y.toFixed(1)}`).join(' ')} L${W},${mid} Z`;
  const [lx, ly] = xy[xy.length - 1];
  return `<div class="rv2-chart">${axis}<div class="rv2-chart-body"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Biểu đồ lợi thế của bạn theo từng nước đi" data-graph-plies="${points.map(row => row.ply).join(',')}">
    <defs>
      <linearGradient id="rv2gUp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2fe36a" stop-opacity=".95"/><stop offset="1" stop-color="#2fe36a" stop-opacity=".12"/></linearGradient>
      <linearGradient id="rv2gDown" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8da2d6" stop-opacity=".12"/><stop offset="1" stop-color="#8da2d6" stop-opacity=".6"/></linearGradient>
      <clipPath id="rv2cUp"><rect x="0" y="0" width="${W}" height="${mid}"/></clipPath>
      <clipPath id="rv2cDown"><rect x="0" y="${mid}" width="${W}" height="${mid}"/></clipPath>
    </defs>
    <line class="rv2-chart-zero" x1="0" y1="${mid}" x2="${W}" y2="${mid}"/>
    <path d="${area}" fill="url(#rv2gUp)" clip-path="url(#rv2cUp)"/>
    <path d="${area}" fill="url(#rv2gDown)" clip-path="url(#rv2cDown)"/>
    <polyline class="rv2-chart-line is-up" points="${line}" clip-path="url(#rv2cUp)"/>
    <polyline class="rv2-chart-line is-down" points="${line}" clip-path="url(#rv2cDown)"/>
    <circle class="rv2-chart-dot" cx="${lx.toFixed(1)}" cy="${ly.toFixed(1)}" r="5"/>
  </svg></div></div>`;
}

const PAWN_SILHOUETTE = '<svg viewBox="0 0 64 64" aria-hidden="true" focusable="false"><circle cx="32" cy="19" r="9"/><path d="M24 54c0-9 3-13 6-17-5-1-8-4-8-6h20c0 2-3 5-8 6 3 4 6 8 6 17z"/><rect x="18" y="52" width="28" height="6" rx="3"/></svg>';

function brandHeader(esc, { left, right }) {
  return `<header class="rv2-header">${left}<span class="rv2-brand"><img class="rv2-brand-mark" src="${BRAND_MARK_SRC}" alt="" width="34" height="34" decoding="async"/><b class="rv2-brand-word">Chess<span>Plus</span></b></span>${right}</header>`;
}

const ICON_BACK = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ICON_HOME = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M3.5 11.2 12 4l8.5 7.2V20a1 1 0 0 1-1 1H15v-6H9v6H4.5a1 1 0 0 1-1-1z" fill="currentColor"/></svg>';
const ICON_SHARE = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="18" cy="5" r="2.6" fill="currentColor"/><circle cx="6" cy="12" r="2.6" fill="currentColor"/><circle cx="18" cy="19" r="2.6" fill="currentColor"/><path d="M8.3 10.8 15.7 6.2M8.3 13.2l7.4 4.6" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/></svg>';
const ICON_GEAR = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.5-2.3.9a7.5 7.5 0 0 0-1.7-1L15 3.5h-4l-.4 2.4a7.5 7.5 0 0 0-1.7 1l-2.3-.9-2 3.5 2 1.5a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.5 2.3-.9a7.5 7.5 0 0 0 1.7 1l.4 2.4h4l.4-2.4a7.5 7.5 0 0 0 1.7-1l2.3.9 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg>';
const ICON_BARS = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="3" y="12" width="4" height="9" rx="1" fill="currentColor"/><rect x="10" y="6" width="4" height="15" rx="1" fill="currentColor"/><rect x="17" y="9" width="4" height="12" rx="1" fill="currentColor"/></svg>';
export const ICON_PLAY_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg>';
export const ICON_PAUSE_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="currentColor"/></svg>';
const ICON_TROPHY = '<svg class="rv2-trophy" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><use href="#cp-trophy"/></svg>';

/* ───────────────────────── Màn 1: Tổng kết ván đấu ───────────────────────── */

/**
 * @param {object} vm
 *  result {token, side, human}, names {you, opp}, youAvatarHtml, accuracy {you, opp},
 *  tally (kết quả tallyMoves), phases {opening|middlegame|endgame: {grade,...}|null} (đã chọn phía người xem),
 *  chartRows, side, analyzed, reviewing, progress {done,total}, status, esc
 */
export function summaryMarkup(vm, esc = escDefault) {
  const result = resultView(vm.result);
  const acc = value => (value == null || !Number.isFinite(Number(value)) ? '—' : `${Number(value).toFixed(1)}%`);
  const tallyRows = REVIEW_TALLY.map(item => {
    const count = Number(vm.tally?.[item.id]) || 0;
    const badge = badgeFor(item.badge);
    return `<li class="rv2-tally-row t-${item.id}${count === 0 ? ' is-zero' : ''}"><i class="rv2-badge ${badge.cls}" aria-hidden="true">${esc(badge.glyph)}</i><span>${esc(item.label)}</span><b>${count}</b></li>`;
  }).join('');
  const phaseDefs = [['opening', 'Khai cuộc', PHASE_ICONS.opening], ['middlegame', 'Trung cuộc', PHASE_ICONS.middlegame], ['endgame', 'Tàn cuộc', PHASE_ICONS.endgame]];
  const phaseRows = phaseDefs.map(([key, label, glyph]) => {
    const info = vm.phases?.[key];
    const grade = phaseGrade(info?.accuracy);
    return `<div class="rv2-phase-row"><span class="rv2-phase-name"><i class="rv2-phase-ico" aria-hidden="true">${glyph}</i>${label}</span>${info ? `<span class="rv2-phase-grade g-${grade.key}"><i aria-hidden="true">${esc(grade.glyph)}</i>${esc(grade.label)}</span><em>(${Math.round(info.accuracy)}%)</em>` : '<span class="rv2-phase-grade g-none">—</span><em></em>'}</div>`;
  }).join('');
  const done = Number(vm.progress?.done) || 0;
  const total = Number(vm.progress?.total) || 0;
  const pct = total ? Math.max(4, Math.min(100, Math.round((done / total) * 100))) : 0;
  const statusLine = vm.reviewing
    ? `<div class="rv2-progress" id="reviewProgress" role="status"><div class="rv2-progress-bar"><span style="width:${pct}%"></span></div><small>Đang phân tích ${Math.min(done + 1, total)}/${total} thế cờ…</small></div>`
    : (!vm.analyzed ? `<div class="rv2-progress" id="reviewProgress" role="status"><small>${esc(vm.status || 'Chưa phân tích ván này. Nhấn nút bên dưới để Stockfish chấm từng nước.')}</small></div>` : '<div class="rv2-progress" id="reviewProgress" hidden></div>');
  const cta = vm.reviewing
    ? '<button type="button" class="rv2-cta is-stop" id="stopReviewBtn"><span aria-hidden="true">■</span>Dừng phân tích</button>'
    : vm.analyzed
      ? '<button type="button" class="rv2-cta" id="reviewOpenReplay"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg>Xem lại ván đấu</button>'
      : '<button type="button" class="rv2-cta" id="reviewGameBtn"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg>Phân tích ván đấu</button>';
  return `<section class="rv2 rv2-summary" id="reviewScreen" data-screen="summary">
    ${brandHeader(esc, {
      left: `<button type="button" class="rv2-icon-btn" id="reviewBack" aria-label="Quay lại">${ICON_BACK}</button>`,
      right: `<button type="button" class="rv2-icon-btn" id="reviewBackHome" aria-label="Trang chủ">${ICON_HOME}</button>`
    })}
    <div class="rv2-title">${ICON_TROPHY}<div><h1>Tổng kết ván đấu</h1><p>${esc(result.subtitle)}</p></div></div>
    <div id="evaluationGraph">${evalChartMarkup(vm.chartRows, vm.side)}</div>
    <div class="rv2-players">
      <div class="rv2-player is-you"><span class="rv2-avatar is-you">${vm.youAvatarHtml || `<img src="${BRAND_MARK_SRC}" alt="" width="52" height="52"/>`}</span><b>${esc(vm.names?.you || 'Bạn')}</b></div>
      <div class="rv2-score"><svg class="rv2-crown" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><use href="#cp-crown"/></svg><strong>${esc(result.score)}</strong><span class="rv2-pill is-${result.tone}">${esc(result.pill)}</span></div>
      <div class="rv2-player is-opp"><span class="rv2-avatar is-opp">${PAWN_SILHOUETTE}</span><b>${esc(vm.names?.opp || 'Đối thủ')}</b></div>
    </div>
    <div class="rv2-accuracy">
      <div class="rv2-acc-card is-you"><small>Độ chính xác</small><b>${acc(vm.accuracy?.you)}</b></div>
      <div class="rv2-acc-card is-opp"><small>Độ chính xác</small><b>${acc(vm.accuracy?.opp)}</b></div>
    </div>
    <ul class="rv2-tally" id="reviewTally" aria-label="Thống kê chất lượng nước đi của bạn">${tallyRows}</ul>
    <section class="rv2-phases" aria-label="Đánh giá từng giai đoạn">
      <h3><span class="rv2-phases-ico">${ICON_BARS}</span>Đánh giá từng giai đoạn <button type="button" class="rv2-info" id="reviewPhaseInfo" aria-expanded="false" aria-controls="reviewPhaseNote" aria-label="Cách chấm điểm">i</button></h3>
      <p class="rv2-note" id="reviewPhaseNote" hidden>Phân loại do ChessPlus ước lượng từ mức giảm xác suất thắng giữa hai lần Stockfish tìm kiếm, nên phụ thuộc phiên bản engine, độ sâu và thời gian. Đây không phải điểm của Chess.com.</p>
      ${phaseRows}
    </section>
    ${statusLine}
    ${cta}
    ${vm.analyzed && !vm.reviewing && Number(vm.mistakeCount) > 0 ? '<button type="button" class="rv2-link" id="reviewMistakeTrainingBtn">Luyện lại các nước đi sai</button><section class="mistake-training-panel" id="mistakeTrainingPanel" hidden></section>' : ''}
  </section>`;
}

/* ───────────────────────── Màn 2: Xem lại ván đấu ───────────────────────── */

/** Gom các nửa nước thành từng dòng "12. Nf3 … Bc5". */
export function buildMovePairs(positions = [], rowByPly = () => null) {
  const pairs = [];
  for (let ply = 1; ply < positions.length; ply += 1) {
    const position = positions[ply];
    if (!position?.san) continue;
    const fullmove = Number(String(positions[ply - 1]?.fen || '').split(/\s+/)[5]) || Math.ceil(ply / 2);
    const cell = { ply, san: position.san, key: rowByPly(ply)?.judgement?.key || '' };
    const last = pairs[pairs.length - 1];
    if (position.mover === 'b' && last && last.no === fullmove && !last.b) last.b = cell;
    else pairs.push({ no: fullmove, w: position.mover === 'w' ? cell : null, b: position.mover === 'b' ? cell : null });
  }
  return pairs;
}

export function moveListMarkup(pairs = [], activePly = 0, esc = escDefault) {
  const cell = (c, side) => {
    if (!c) return `<span class="rv2-mv is-empty">${side === 'b' ? '…' : ''}</span>`;
    const badge = badgeFor(c.key);
    return `<button type="button" class="rv2-mv${c.ply === activePly ? ' is-active' : ''}" data-review-ply="${c.ply}"${c.ply === activePly ? ' aria-current="step"' : ''}><span class="rv2-mv-san">${esc(c.san)}</span>${badge ? `<i class="rv2-badge ${badge.cls}" title="${esc(badge.label)}" aria-label="${esc(badge.label)}">${esc(badge.glyph)}</i>` : ''}</button>`;
  };
  return pairs.map(pair => {
    const active = pair.w?.ply === activePly || pair.b?.ply === activePly;
    return `<div class="rv2-row${active ? ' is-active' : ''}" role="row"><span class="rv2-no">${pair.no}.</span>${cell(pair.w, 'w')}${cell(pair.b, 'b')}</div>`;
  }).join('');
}

/** Dải thông báo màu phía trên bàn cờ. */
export function bannerFor(row, position) {
  const ply = Number(position?.ply) || 0;
  if (ply === 0) return { tone: 'start', glyph: '♙', label: 'THẾ CỜ BẮT ĐẦU', chip: '' };
  const num = Number(String(position?.prevFen || '').split(/\s+/)[5]) || Math.ceil(ply / 2);
  const chip = `${num}${position.mover === 'b' ? '...' : '.'} ${position.san}`;
  const key = row?.judgement?.key || '';
  const labels = {
    brilliant: ['brilliant', 'NƯỚC ĐI XUẤT SẮC'], great: ['great', 'NƯỚC ĐI HAY'], best: ['best', 'NƯỚC ĐI TỐT NHẤT'],
    excellent: ['good', 'NƯỚC ĐI TỐT'], good: ['good', 'NƯỚC ĐI TỐT'], book: ['book', 'NƯỚC TRONG SÁCH'],
    inaccuracy: ['unclear', 'NƯỚC ĐI KHÔNG RÕ'], mistake: ['mistake', 'NƯỚC ĐI SAI'], blunder: ['blunder', 'NƯỚC ĐI MẮC LỖI'],
    'missed-win': ['miss', 'NƯỚC ĐI BỎ LỠ']
  };
  const [tone, label] = labels[key] || ['none', 'CHƯA PHÂN TÍCH'];
  const badge = badgeFor(key);
  return { tone, glyph: badge ? badge.glyph : '•', label, chip };
}

/** Câu giải thích ngắn dưới bàn cờ (suy ra từ nước đi thật, không bịa lý do). */
export function hintFor(row, position, positionBefore) {
  const ply = Number(position?.ply) || 0;
  if (ply === 0) return 'Thế cờ bắt đầu. Dùng các nút bên dưới hoặc kéo thanh trượt để xem lại từng nước.';
  const san = position?.san || '';
  if (!row?.judgement) return `${san} — nước này chưa được phân tích. Quay lại trang Tổng kết và chọn «Phân tích ván đấu».`;
  const key = row.judgement.key;
  const better = row.bestMoveSan && row.bestMoveSan !== san ? row.bestMoveSan : '';
  const reason = moveReason(position, positionBefore);
  const good = `${san} ${({ brilliant: 'là nước đi xuất sắc', great: 'là nước đi hay', best: 'là nước đi tốt nhất', excellent: 'là nước đi tốt', good: 'là nước đi tốt', book: 'là nước trong sách khai cuộc' })[key] || ''}`.trim();
  if (['brilliant', 'great', 'best', 'excellent', 'good', 'book'].includes(key)) return `${good}${reason ? `, ${reason}` : ''}.`;
  const bad = ({ inaccuracy: 'là nước đi không rõ ràng', mistake: 'là một sai lầm', blunder: 'là sai lầm nghiêm trọng', 'missed-win': 'đã bỏ lỡ cơ hội thắng' })[key] || 'cần xem lại';
  return `${san} ${bad}.${better ? ` Nước tốt hơn là ${better}.` : ''}`;
}

function moveReason(position, before) {
  const san = String(position?.san || '');
  if (!san) return '';
  if (/#$/.test(san)) return 'chiếu hết đối phương';
  if (/^O-O/.test(san)) return 'đưa Vua vào nơi an toàn và kết nối các Xe';
  if (san.includes('=')) return 'phong cấp biến Tốt thành quân mạnh';
  if (san.includes('x')) return 'thu được quân của đối phương';
  if (/\+$/.test(san)) return 'chiếu Vua đối phương';
  const from = String(position?.from || '');
  const to = String(position?.to || '');
  const ply = Number(position?.ply) || 0;
  const piece = san[0];
  const homeRank = position?.mover === 'w' ? '1' : '8';
  if ((piece === 'N' || piece === 'B') && from[1] === homeRank && ply <= 24) {
    return /^[c-f]/.test(to) ? 'giúp phát triển quân và kiểm soát trung tâm' : 'giúp phát triển quân';
  }
  if (!/[A-Z]/.test(piece) && ['d4', 'e4', 'd5', 'e5', 'c4', 'c5', 'f4', 'f5'].includes(to) && ply <= 24) return 'chiếm giữ trung tâm';
  void before;
  return '';
}

/**
 * @param {object} vm
 *  ply, total, positions, rowByPly, boardHtml (đã gồm mũi tên), playing, esc
 */
export function replayMarkup(vm, esc = escDefault) {
  const ply = Math.max(0, Math.min(Number(vm.total) || 0, Number(vm.ply) || 0));
  const total = Number(vm.total) || 0;
  const position = vm.positions?.[ply] || { ply: 0 };
  const row = vm.rowByPly ? vm.rowByPly(ply) : null;
  const banner = bannerFor(row, { ...position, prevFen: vm.positions?.[ply - 1]?.fen });
  const hint = hintFor(row, position, vm.positions?.[ply - 1]);
  const pairs = buildMovePairs(vm.positions, vm.rowByPly || (() => null));
  const pct = total ? Math.round((ply / total) * 1000) / 10 : 0;
  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'].map(f => `<span>${f}</span>`).join('');
  const ranks = [8, 7, 6, 5, 4, 3, 2, 1].map(r => `<span>${r}</span>`).join('');
  const step = (action, label, glyph, disabled) => `<button type="button" class="rv2-ctl" data-review-step="${action}" aria-label="${label}"${disabled ? ' disabled' : ''}>${glyph}</button>`;
  const GL_FIRST = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 5v14M18 5.5v13L8.5 12z" stroke="currentColor" stroke-width="2.2" fill="currentColor" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const GL_PREV = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M17 5.5v13L7 12z" fill="currentColor"/></svg>';
  const GL_NEXT = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 5.5v13L17 12z" fill="currentColor"/></svg>';
  const GL_LAST = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M18 5v14M5.5 5.5v13L15 12z" stroke="currentColor" stroke-width="2.2" fill="currentColor" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const GL_PLAY = ICON_PLAY_SVG;
  const GL_PAUSE = ICON_PAUSE_SVG;
  return `<section class="rv2 rv2-replay" id="reviewScreen" data-screen="replay">
    ${brandHeader(esc, {
      left: `<button type="button" class="rv2-icon-btn" id="reviewBack" aria-label="Quay lại tổng kết">${ICON_BACK}</button>`,
      right: `<span class="rv2-header-actions"><button type="button" class="rv2-icon-btn" id="reviewShare" aria-label="Chia sẻ PGN">${ICON_SHARE}</button><button type="button" class="rv2-icon-btn" id="reviewSettings" aria-label="Cài đặt">${ICON_GEAR}</button></span>`
    })}
    <div class="rv2-banner t-${banner.tone}" id="reviewBanner" role="status"><span class="rv2-banner-ico" aria-hidden="true">${esc(banner.glyph)}</span><b>${esc(banner.label)}</b>${banner.chip ? `<span class="rv2-banner-chip">${esc(banner.chip)}</span>` : ''}</div>
    <div class="rv2-board-wrap">
      <div class="rv2-ranks" aria-hidden="true">${ranks}</div>
      <div id="reviewReplayBoard" class="review-replay-board rv2-board" role="grid" aria-label="Bàn cờ xem lại" data-review-ply="${ply}">${vm.boardHtml || ''}</div>
      <div class="rv2-files" aria-hidden="true">${files}</div>
    </div>
    <div class="rv2-hint" id="reviewHint"><span class="rv2-hint-ico" aria-hidden="true">💡</span><p>${esc(hint)}</p></div>
    <div class="rv2-moves" id="reviewMoveAnalysis" role="table" aria-label="Danh sách nước đi">${moveListMarkup(pairs, ply, esc)}</div>
    <div class="rv2-controls" role="group" aria-label="Điều khiển xem lại">
      ${step('first', 'Về đầu ván', GL_FIRST, ply === 0)}
      ${step('prev', 'Nước trước', GL_PREV, ply === 0)}
      <button type="button" class="rv2-ctl is-play" id="reviewPlayBtn" aria-label="${vm.playing ? 'Tạm dừng' : 'Tự động phát'}" aria-pressed="${vm.playing ? 'true' : 'false'}">${vm.playing ? GL_PAUSE : GL_PLAY}</button>
      ${step('next', 'Nước sau', GL_NEXT, ply >= total)}
      ${step('last', 'Đến cuối ván', GL_LAST, ply >= total)}
    </div>
    <div class="rv2-scrub"><input type="range" id="reviewSlider" min="0" max="${total}" value="${ply}" step="1" aria-label="Vị trí nước đi" style="--rv2-pct:${pct}%"/><span id="reviewSliderLabel">${ply} / ${total}</span></div>
  </section>`;
}

/** Màn chờ khi chưa có ván nào được mở (dán PGN / chọn ván gần đây). */
export function landingMarkup({ cardsHtml = '' } = {}, esc = escDefault) {
  return `<section class="rv2 rv2-landing" id="reviewScreen" data-screen="landing">
    ${brandHeader(esc, {
      left: `<button type="button" class="rv2-icon-btn" id="reviewBackHome" aria-label="Trang chủ">${ICON_BACK}</button>`,
      right: '<span class="rv2-icon-spacer" aria-hidden="true"></span>'
    })}
    <div class="rv2-title">${ICON_TROPHY}<div><h1>Phân tích ván đấu</h1><p>Chọn ván đã chơi hoặc dán PGN để xem tổng kết và xem lại từng nước.</p></div></div>
    <section class="rv2-card"><h3>Dán PGN</h3><textarea id="reviewPgnInput" class="rv2-textarea" rows="5" spellcheck="false" placeholder="1. e4 e5 2. Nf3 Nc6 …"></textarea><div class="rv2-card-actions"><button id="reviewPgnLoad" type="button" class="rv2-btn">Xem lại</button><button id="reviewPgnAnalyze" type="button" class="rv2-btn is-primary">Phân tích ngay</button></div></section>
    <section class="rv2-card"><h3>Ván gần đây</h3>${cardsHtml || '<p class="rv2-empty">Chưa có ván nào được lưu. Chơi một ván hoặc dán PGN ở trên.</p>'}<div class="rv2-card-actions"><button id="reviewLandingHistory" type="button" class="rv2-btn">Xem toàn bộ lịch sử</button></div></section>
  </section>`;
}
