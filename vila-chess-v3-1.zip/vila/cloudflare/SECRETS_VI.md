# Hướng dẫn thêm biến và bí mật trên Cloudflare (Worker `bitter-sun-751a`)

Các biến dưới đây là toàn bộ những gì `cloudflare/src` đọc từ `env`. **Bí mật** (Secret) được mã hoá, không xem lại được. **Biến** (Text) hiện công khai trong dashboard. Sau khi thêm hoặc sửa, Worker tự dùng giá trị mới ở lần chạy kế tiếp (nếu dùng dashboard, bấm **Deploy**).

## 1. Bảng tổng hợp

| Tên | Loại | Bắt buộc? | Dùng để làm gì |
|---|---|---|---|
| `ADMIN_USERNAME` | Secret | **Có** | Tên đăng nhập admin (3–24 ký tự: chữ, số, `.` `_` `-`). |
| `ADMIN_PASSWORD` | Secret | **Có** | Mật khẩu admin, **tối thiểu 14 ký tự**. Nếu thiếu/yếu, admin không được tạo và trang Quản trị báo lỗi. |
| `ADMIN_INITIAL_ELO` | Text | Không | Elo khởi tạo của admin (mặc định 3200, từ 100 đến 4000). |
| `CORS_ORIGINS` | Text | Khi chạy web/Vite | Danh sách origin được gọi API, ngăn cách bằng dấu phẩy. Ví dụ khi test: `http://localhost:5173`. Mặc định chỉ cho app native. |
| `PLAY_PRICE_VND_PRO` | Text | Không | Giá gói Pro (VND) để bảng **Doanh thu** của admin tính tiền Google Play. |
| `PLAY_PRICE_VND_PREMIUM` | Text | Không | Giá gói Premium (VND), dùng cho mục đích như trên. |
| `RESEND_API_KEY` | Secret | Nếu muốn gửi email | Khoá API của Resend (resend.com) để gửi email thông báo: liên kết email, đăng nhập từ thiết bị mới, đổi mật khẩu, đổi email. Thiếu thì app vẫn chạy bình thường, chỉ không gửi email. |
| `MAIL_FROM` | Text | Nếu muốn gửi email | Địa chỉ gửi, ví dụ `Cờ Vua ViLa <no-reply@ten-mien-cua-ban.com>`. Tên miền phải được xác minh trong Resend. Nếu đã đặt `RESET_EMAIL_FROM` thì Worker dùng giá trị đó khi không có `MAIL_FROM`. |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | Secret | Nếu bán qua Google Play | Nội dung file JSON của service account để xác minh giao dịch và thu hồi khi hoàn tiền. |
| `PLAY_PACKAGE_NAME` | Text | Nếu khác mặc định | Mặc định `com.aistudio.covuavila.vzrk`. |
| `PRO_PRODUCT_ID` | Text | Nếu khác mặc định | Mặc định `vila_pro_1y`. |
| `PREMIUM_PRODUCT_ID` | Text | Nếu khác mặc định | Mặc định `vila_premium_lifetime`. |
| `DIAMOND_PRODUCT_ID` | Text | Nếu khác mặc định | Mặc định `vila_diamond_1y` (gói Kim Cương 1 năm, cộng dồn). |
| `PLAY_PRICE_VND_DIAMOND` | Text | Tuỳ chọn | Giá ghi nhận doanh thu cho gói Kim Cương (mặc định 99000). |
| `TOKEN_SECRET` | Secret | Khuyến nghị | Khoá ký phiên đăng nhập (base64url, ≥ 32 byte; script `generate-secrets.mjs` tự sinh). Có biến này thì khoá **không còn nằm trong cơ sở dữ liệu**, lộ bản sao DB cũng không giả mạo được phiên. Đổi/xoá biến sẽ đăng xuất mọi người. |
| `VILA_TRIAL_CODE_SECRET` | Secret | Nếu dùng mã dùng thử | Khoá HMAC, **tối thiểu 32 ký tự**. |
| `VILA_PRO_TRIAL_CODE_HMAC` | Secret | Nếu dùng mã dùng thử | Mã băm 64 ký tự hex của mã Pro 5 ngày. |
| `VILA_PREMIUM_TRIAL_CODE_HMAC` | Secret | Nếu dùng mã dùng thử | Mã băm 64 ký tự hex của mã Premium 1 tháng. |

> Chỉ **3 mục in đậm** (`ADMIN_USERNAME`, `ADMIN_PASSWORD`, và `CORS_ORIGINS` khi bạn test trên web) là cần để chạy được. Còn lại thêm khi bạn dùng tính năng tương ứng.

## 2. Cách 1: dùng giao diện Cloudflare (không cần máy tính)

1. Vào **dash.cloudflare.com → Workers & Pages**, chọn Worker `bitter-sun-751a`.
2. Chọn **Settings → Variables and Secrets → Add**.
3. Chọn **Type**: `Secret` (cho bí mật) hoặc `Text` (cho biến thường), nhập **Variable name** và **Value**.
4. Lặp lại cho từng biến, rồi bấm **Deploy**.
5. Kiểm tra: mở trang Quản trị trong app. Nếu còn thiếu, dòng trạng thái sẽ ghi `missing-secrets`, `bad-username` hoặc `weak-password`.

## 3. Cách 2: dùng dòng lệnh `wrangler`

Chạy trong thư mục `cloudflare/`:

```bash
npx wrangler login

# Bí mật (sẽ hỏi giá trị, không lưu vào lịch sử lệnh)
npx wrangler secret put ADMIN_USERNAME
npx wrangler secret put ADMIN_PASSWORD
npx wrangler secret put GOOGLE_SERVICE_ACCOUNT_JSON < service-account.json
npx wrangler secret put VILA_TRIAL_CODE_SECRET
npx wrangler secret put VILA_PRO_TRIAL_CODE_HMAC
npx wrangler secret put VILA_PREMIUM_TRIAL_CODE_HMAC

# Biến thường: thêm vào wrangler.toml rồi deploy
```

Thêm vào `cloudflare/wrangler.toml` (biến thường):

```toml
[vars]
CORS_ORIGINS = "http://localhost:5173"
PLAY_PRICE_VND_PRO = "99000"
PLAY_PRICE_VND_PREMIUM = "299000"
```

Rồi chạy `npx wrangler deploy`. **Đổi giá trị trên cho đúng giá thật của bạn.**

> Lưu ý: nếu bạn deploy bằng Git kết nối Cloudflare mà `wrangler.toml` có `[vars]`, các biến đặt tay trên dashboard có thể bị ghi đè ở lần deploy sau. Hãy chọn một cách và dùng nhất quán.

## 4. Tạo mã dùng thử (3 biến `VILA_*`)

1. Tạo khoá HMAC (≥ 32 ký tự), ví dụ:
   ```bash
   openssl rand -hex 32
   ```
   Giá trị này là `VILA_TRIAL_CODE_SECRET`.
2. Chọn mã bạn sẽ phát cho người dùng (chữ thường, số, dấu `-`, 4–80 ký tự), ví dụ `pro-demo-2026` và `premium-demo-2026`.
3. Tính mã băm của từng mã bằng chính khoá ở bước 1:
   ```bash
   printf '%s' 'pro-demo-2026' | openssl dgst -sha256 -hmac 'KHOÁ_Ở_BƯỚC_1'
   ```
   Kết quả 64 ký tự hex là `VILA_PRO_TRIAL_CODE_HMAC`. Làm tương tự với mã Premium để có `VILA_PREMIUM_TRIAL_CODE_HMAC`.
4. Mỗi tài khoản chỉ dùng được mỗi loại mã một lần. Muốn thu hồi mã, đổi lại mã băm tương ứng.

## 5. Tạo service account cho Google Play

1. Google Cloud Console: tạo **Service Account** và tải file **JSON** khoá.
2. Play Console → **Setup → API access**: liên kết dự án, cấp cho service account quyền xem giao dịch và quản lý đơn hàng.
3. Dán **nguyên nội dung file JSON** vào secret `GOOGLE_SERVICE_ACCOUNT_JSON` (cách 2 ở trên dùng `< service-account.json`).
4. Worker có cron mỗi 6 giờ (`17 */6 * * *`) để thu hồi gói đã hoàn tiền; cron cần secret này.

## 6. Kiểm tra sau khi cấu hình

- **Admin**: đăng nhập bằng `ADMIN_USERNAME`/`ADMIN_PASSWORD` trong mục Bạn bè, rồi mở Quản trị; không còn dòng `missing-secrets`.
- **Doanh thu**: mục **Doanh thu ứng dụng** hiện số liệu. Giao dịch Google Play mới sẽ có giá nếu đã đặt `PLAY_PRICE_VND_*`.
- **CORS**: mở app bằng Vite (`npm run dev`) mà vẫn gọi được API thì `CORS_ORIGINS` đã đúng; nếu lỗi CORS trong console, thêm đúng origin (đúng cả cổng).
- **Không** commit bí mật vào Git, không đặt mật khẩu admin trong mã nguồn hay trong APK.

## 7. Kết nối GitHub: có cần nhập biến không?

- **Worker vẫn chạy** khi chưa nhập biến, nhưng thiếu: không có tài khoản admin, mã dùng thử trả lỗi 503, không xác minh được Google Play, và web localhost bị chặn CORS.
- `cloudflare/wrangler.toml` hiện **không có** phần `[vars]`, nên các biến và bí mật bạn nhập trên dashboard sẽ **được giữ nguyên** qua mỗi lần Cloudflare build từ GitHub.
- Nhập một lần trên dashboard là đủ. **Đừng** đưa bí mật vào repository.
- Sinh sẵn giá trị: chạy `node cloudflare/scripts/generate-secrets.mjs ten_admin 99000 299000` trên máy bạn (không cần mạng), rồi dán từng dòng vào Cloudflare theo mục 2.

## 8. Email thông báo tài khoản

- Cần hai biến: `RESEND_API_KEY` (Secret) và `MAIL_FROM` (Text), thêm giống các biến khác rồi bấm **Deploy**. Kiểm tra: `GET /api/social/health` trả `"mail": "configured"`.
- Admin vào trang **Quản trị → Người dùng → Gửi email thử** để gửi thử một thư và biết cấu hình đã đúng chưa (tối đa 5 lần mỗi giờ).
- Các thư được gửi: chào mừng khi đăng ký có email; email vừa được liên kết; email đổi sang địa chỉ khác (thư bảo mật tới địa chỉ cũ, chỉ hiện địa chỉ mới dưới dạng che bớt); đăng nhập từ thiết bị mới (kèm loại thiết bị, quốc gia, IP che bớt, không lộ IP đầy đủ); mật khẩu vừa đổi.
- Chống lạm dụng: mỗi địa chỉ nhận tối đa 4 thư mỗi giờ. Lỗi gửi thư chỉ ghi log, không làm hỏng thao tác của người chơi.
- Email chưa được xác minh, nên thư "liên kết" nhắc người nhận bỏ qua nếu không phải họ. Muốn xác minh quyền sở hữu email thì cần thêm bước xác nhận bằng liên kết (chưa có).
