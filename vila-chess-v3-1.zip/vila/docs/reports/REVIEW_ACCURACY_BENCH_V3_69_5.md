# Review accuracy benchmark (v3.69.5)

Offline test: 5 self-play games (Stockfish 19 lite, low Skill Levels so errors appear), 205 positions, 200 judged moves.
Reference = same engine searched 3 s/position, MultiPV 2. This is NOT a comparison with chess.com's website
(no network in the test environment); it measures agreement with a deeper Stockfish 19 analysis.

| Setting | s/position | Same quality tier | Mistakes found (recall / precision) | Accuracy score error |
|---|---|---|---|---|
| Old "fast" (1.04 s, 1 lane) | 1.04 | 94.5% | 81.8% / 75.0% | 0.90 |
| Old "standard" (2.2 s, 2 lanes) | 2.21 | 95.5% | 100% / 100% | 1.03 |
| New two-pass, 2-lane first pass | 1.19 | 96.0% | 90.9% / 83.3% | 1.41 |
| New two-pass, 1-lane first pass (what "fast" runs) | 1.14 | 95.0% | 90.9% / 76.9% | 0.81 |

Limits: only 11 reference mistakes (one mistake = 9 points of recall), one CPU thread, self-play games from
low-Skill engines. Differences between rows 1, 3 and 4 are within noise; row 2 (twice the time) is the clear leader.
Exact-label agreement is 67-71% for every setting, so borderline labels (e.g. Excellent vs Good) stay unstable.
Reproduce: `node scripts/bench-review-accuracy.mjs --games 5 --plies 40 --ref-ms 3000`.
