# Thanh toán Google Play (cách A: mua một lần)

| Gói | Sản phẩm Play Console | Loại | Hiệu lực |
|---|---|---|---|
| Pro | `vila_pro_1y` | Sản phẩm trong ứng dụng, **tiêu hao (consumable)** | +365 ngày mỗi lần mua, mua lại để gia hạn, **cộng dồn** |
| Premium | `vila_premium_lifetime` | Sản phẩm trong ứng dụng, **không tiêu hao** | Trọn đời, chỉ mua một lần |

Đổi mã sản phẩm: đặt biến Worker `PRO_PRODUCT_ID` / `PREMIUM_PRODUCT_ID` / `DIAMOND_PRODUCT_ID` (gói Kim Cương, mặc định `vila_diamond_1y`). Đổi package: `PLAY_PACKAGE_NAME` (mặc định `com.aistudio.covuavila.vzrk`).

## Luồng
1. Người dùng đăng nhập, mở tab **Gói**, bấm mua. App lấy `accountId` (mã gắn tài khoản) từ Worker rồi mở Google Play.
2. Google trả `purchaseToken`. App gửi `POST /api/social/me/purchase/verify`.
3. Worker xác thực token trực tiếp với Google Play Developer API (đăng nhập bằng service account), kiểm tra: đã thanh toán, đúng sản phẩm, đúng tài khoản, chưa dùng, rồi cấp gói **một lần**, acknowledge phía server.
4. Chỉ khi Worker chấp nhận, app mới gọi consume (Pro) hoặc acknowledge (Premium).
5. Mất mạng giữa chừng: giao dịch vẫn nằm ở Google, app tự gửi lại khi mở tab Gói hoặc bấm **Khôi phục giao dịch**.
6. Hoàn tiền: Worker chạy cron mỗi 6 giờ, đọc danh sách voided purchases của Google và trừ đúng phần đã hoàn (Pro trừ 365 ngày của lần mua đó, Premium tắt).

## Cấu hình một lần
**Play Console**
1. Tạo ứng dụng với đúng package `com.aistudio.covuavila.vzrk`, tải bản AAB lên ít nhất kênh Internal testing (sản phẩm chỉ hiện khi có bản đã tải lên).
2. Monetize → Products → In-app products: tạo `vila_pro_1y` và `vila_premium_lifetime`, đặt giá, kích hoạt. Pro phải là loại có thể mua lại (consumable do app consume).
3. Setup → License testing: thêm email Gmail của bạn để thử mua mà không bị trừ tiền.

**Google Cloud / API**
1. Google Cloud → bật *Google Play Android Developer API* → tạo service account → tạo khóa JSON.
2. Play Console → Users and permissions → mời email service account, cấp quyền **View financial data** và **Manage orders and subscriptions** cho app.
3. Quyền có thể mất vài giờ mới có hiệu lực.

**Cloudflare Worker**
```sh
cd cloudflare
npx wrangler secret put GOOGLE_SERVICE_ACCOUNT_JSON   # dán toàn bộ nội dung file JSON
npm run deploy
```
Cron đã khai báo trong `wrangler.toml`. Không đưa file JSON vào Git.

## Kiểm thử thật (trước khi phát hành)
Cài bản Internal testing bằng tài khoản license tester, đăng nhập app, rồi:
1. Mua Pro: gói Pro hiện "còn 365 ngày"; phân tích ván không giới hạn.
2. Mua Pro lần nữa: "còn 730 ngày" (cộng dồn). Tab Gói hiện nút gia hạn khi còn ≤ 14 ngày.
3. Mua Premium: "Premium · trọn đời", nút mua biến mất.
4. Tắt mạng ngay sau khi thanh toán, mở lại có mạng: gói tự kích hoạt (hoặc bấm Khôi phục).
5. Gỡ app, cài lại, đăng nhập: gói vẫn còn.
6. Đăng nhập tài khoản thứ hai rồi bấm Khôi phục: tài khoản đó vẫn là Free.
7. Hủy/hoàn tiền một giao dịch thử trong Play Console, chờ cron (hoặc admin gọi `POST /api/social/admin/billing/sync-voided`): gói bị thu hồi đúng phần.

## Giới hạn cần biết
- Phân tích ván chạy trên máy người dùng nên đây là cổng mềm theo tài khoản, không phải DRM. Quyền lợi nằm ở tài khoản trên Worker, nên cài lại hoặc đổi máy vẫn giữ gói.
- Mua trong app chỉ hoạt động trong bản Android cài từ Google Play. Bản web/APK ngoài chỉ có admin cấp gói.
- Chưa có Express server tương đương cho mua hàng (server Express chỉ để phát triển); thanh toán thật chạy trên Worker.
- Mã Kotlin (`PlayBilling.kt`) chưa được biên dịch trong sandbox tạo ZIP: hãy chạy GitHub Actions build và thử trên máy thật.
