# Công thức Game Review của Chess.com (nguồn công khai) và cách ChessPlus áp dụng

Nguồn: support.chess.com — "How are moves classified?" và "How is accuracy in Analysis determined?".

## 1. Phân loại nước đi — Expected Points (công khai)
Điểm kỳ vọng (expected points) của người đi: 1.00 = thắng chắc, 0.50 = cân bằng, 0.00 = thua chắc.
Nước đi bị trừ bao nhiêu điểm kỳ vọng thì xếp loại như sau:

| Loại | Điểm kỳ vọng mất |
|---|---|
| Best | 0.00 |
| Excellent | 0.00 – 0.02 |
| Good | 0.02 – 0.05 |
| Inaccuracy | 0.05 – 0.10 |
| Mistake | 0.10 – 0.20 |
| Blunder | 0.20 – 1.00 |

Trong `src/game-review.js` → `classifyMoveQuality()` dùng đúng các mốc này (tính theo thang 0–100: 2 / 5 / 10 / 20).
Brilliant = hy sinh quân hợp lý, không bị thế xấu sau nước đó, và trước đó chưa thắng hẳn. Great = nước then chốt (nước duy nhất, hoặc thua→hòa / hòa→thắng). Miss = bỏ lỡ cơ hội thắng sau sai lầm của đối thủ.

## 2. Phần KHÔNG công khai
* Hàm chuyển điểm engine (centipawn) → expected points của Chess.com **phụ thuộc rating và không được công bố**.
* Công thức Accuracy "CAPS2" cũng **không được công bố** (chỉ biết điểm thường rơi vào 50–95).

ChessPlus dùng thay thế công khai gần nhất:
* `winChance(cp) = 50 + 50 * (2 / (1 + e^(-0.00368208 * cp)) - 1)` (mô hình thắng/thua của Lichess).
* Accuracy mỗi nước = `103.1668 * e^(-0.04354 * winDrop) - 3.1669 (+1)`, kẹp 0–100.
* Accuracy cả ván = trung bình của (trung bình có trọng số độ biến động) và (trung bình điều hòa).

→ Số liệu sẽ **gần** chứ không trùng 100% với Chess.com. Muốn so sánh: phân tích cùng một ván trên cả hai nơi rồi chỉnh các hằng số trong `winChance` / `moveAccuracyFromWinPercents`.

## 3. Đánh giá từng giai đoạn
Khai cuộc: 10 nước đầu mỗi bên (ply ≤ 20). Tàn cuộc: tổng quân nặng/nhẹ còn ≤ 24 điểm (N,B=3, R=5, Q=9, cả hai bên). Còn lại là trung cuộc. Điểm giai đoạn = trung bình accuracy các nước trong giai đoạn đó.
