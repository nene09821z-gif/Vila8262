#!/usr/bin/env bash
# Builds ClaudeFish for the browser/Android WebView: public/claudefish/claudefish.{js,wasm}
# Needs the Emscripten SDK (emcc). Usage: bash scripts/build-claudefish-wasm.sh
# NOTE: the app's worker (public/claudefish/claudefish-worker.js) now runs the prebuilt WASI module
# public/claudefish/cf-engine.wasm (cf_init/cf_best API), NOT this emscripten build. This script only
# rebuilds the older single-file C++ UCI source for experiments; it does not touch cf-engine.wasm.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v emcc >/dev/null || { echo "emcc not found. Install emsdk: https://emscripten.org/docs/getting_started/downloads.html" >&2; exit 1; }
emcc engines/claudefish/claudefish.cpp -O3 -std=c++17 -DNDEBUG --no-entry \
  -sENVIRONMENT=worker -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=67108864 -sNO_EXIT_RUNTIME=1 \
  -sEXPORTED_FUNCTIONS=_claudefish_command,_claudefish_init -sEXPORTED_RUNTIME_METHODS=cwrap \
  -o public/claudefish/claudefish.js
ls -l public/claudefish/claudefish.js public/claudefish/claudefish.wasm
