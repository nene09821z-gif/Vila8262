## Patch — 3 nền tảng vững: luật kết quả, toàn vẹn ván xếp hạng, phân tích được kiểm chứng

- **1. Luật kết quả chuẩn FIDE dùng chung** (`src/game-rules.js`, không phụ thuộc chess.js): hết giờ mà đối thủ không còn đủ quân để chiếu hết (vua trần, vua + một mã/tượng, vua + tượng cùng màu ô) nay xử **hòa** thay vì thua (FIDE 6.9). Cùng một hàm được trình duyệt (ván local/bot có đồng hồ), máy chủ Node và Cloudflare Worker gọi, nên một ván không còn kết thúc khác nhau tuỳ nơi chơi. Vua + 2 mã vs vua vẫn tính là đủ quân (có thể chiếu hết nếu đối thủ hợp tác), nên bên hết giờ vẫn thua.
- **2. Ván xếp hạng toàn vẹn**: (a) **luật huỷ ván** — nếu đầu hàng / rời trận / mất kết nối / hết giờ khi chưa đủ 2 nửa nước thì ván bị huỷ, **không ai đổi Elo, không bị phạt 15 điểm** (trước đây hai tài khoản có thể bỏ ván ở nước 0 để bơm Elo cho nhau); (b) **khoá theo từng ván** ở máy chủ Node (`createKeyedMutex`) cho nước đi, đầu hàng, rời trận và lượt thăm dò trạng thái, chặn lỗi gửi trùng một nước đi làm hỏng biên bản; (c) giao diện hiện «VÁN BỊ HUỶ · KHÔNG ĐỔI ELO», nút «Huỷ ván (chưa mất Elo)» khi chưa đủ 2 nước, và lý do «hết giờ nhưng đối thủ không đủ quân» khi xử hòa.
- **3. Phân tích được kiểm chứng bằng Stockfish thật** (`tests/review-engine-truth.test.js`): mỗi tình huống (ăn hậu miễn phí, bỏ hậu, nước khai cuộc thường, chiếu hết, hoà cờ bí thay vì chiếu hết) được chạy cho cả Trắng lẫn Đen qua đúng chuỗi điểm engine → điểm theo Trắng → điểm theo người đi → nhãn, và phải ra cùng một nhãn; thêm kiểm tra đối xứng «lật màu thì điểm đổi dấu» để bắt lỗi nhầm phía.
- Test mới: `game-rules` (7), `ranked-integrity` (8), `review-engine-truth` (12). Cache service worker `fix11`.
- Chưa chạy được trong môi trường soạn: build Vite/APK và test cần `chess.js`/`express` (registry npm bị chặn). Hãy chạy `npm ci && npm test` trước khi deploy; các thay đổi ở `server/social.js` và `cloudflare/src/index.js` mới qua kiểm tra cú pháp + test logic thuần + test tĩnh, chưa qua test end-to-end.

## Patch — Tổng kết ván đấu + Xem lại ván mới (thay hoàn toàn trang Phân tích cũ)

- **Hai màn mới theo thiết kế ChessPlus** (`src/review-screen.js`, `src/review-screen.css`): «Tổng kết ván đấu» (biểu đồ lợi thế, tỉ số + «Bạn thắng!», độ chính xác hai bên, 8 dòng thống kê nước đi, đánh giá khai cuộc / trung cuộc / tàn cuộc, nút «Xem lại ván đấu») và «Xem lại ván đấu» (dải «NƯỚC ĐI TỐT NHẤT 12. Nf3», bàn cờ có tọa độ ngoài bàn và mũi tên, câu giải thích, danh sách nước đi có huy hiệu, nút đầu/trước/phát/sau/cuối, thanh trượt 12 / 34). Chữ lớn «VILA Chess» ở header được thay bằng logo + chữ **ChessPlus**.
- **Xoá hẳn trang Phân tích cũ**: bỏ view `coach` (`src/pages/analysis-page.js`, ~240 dòng trong `main.js`, tab «Phân tích (Analysis)», luật `.ap-*`), bố cục xem lại cũ (`review-layers.css`, `review-polish.css`, `review-chess.css`, `review-insights-view.js`, `review-list.js`) và các hàm/test đi kèm. Mọi lối vào cũ («Phân tích» ở trang chủ, thanh chế độ, «Phân tích thế cờ») nay mở màn mới; `setView('coach')` tự chuyển sang `review`.
- Dữ liệu phân tích (Stockfish, độ chính xác, giai đoạn) giữ nguyên; nút Back Android đi từ Xem lại → Tổng kết → màn trước. PGN xuất ra ghi `ChessPlus`.
- Cache service worker `fix9`. Test mới `tests/review-screen.test.js`; các test cũ gắn với giao diện đã xoá được cập nhật.

## Patch — đồng bộ giao diện ChessPlus cho mọi trang trên mobile

- **Header chung giống trang chủ**: mọi trang (≤ 820 px) dùng header logo **ChessPlus** + dòng phụ là tên trang đang mở + chip hồ sơ (tên, Elo) + nút ba gạch. Nhạc, hộp thư, trạng thái engine và cài đặt nằm trong menu (như trang chủ); thư chưa đọc hiện chấm đỏ trên nút ba gạch. Thu gọn riêng cho màn 360 / 320 px.
- **Menu ba gạch / «Thêm» mới trên mọi trang**: tờ menu xanh bo góc nổi phía trên thanh điều hướng, có tiêu đề «Tất cả chức năng», lưới 2 cột, mục đang mở sáng lên. Trước đó chỉ trang chủ dùng; các trang khác vẫn hiện danh sách cũ màu xanh lá/xám.
- **Đồng bộ toàn bộ trang**: nền trời xanh navy, thẻ `panel`/thẻ bài học/khai cuộc/nhiệm vụ/cửa hàng… viền phát sáng xanh, ô nhập, nút chính (pill xanh) và nút phụ cùng ngôn ngữ với trang chủ; trang Câu đố và Phân tích đổi bảng màu xám-xanh lá sang navy; phòng thi đấu (`match-live`) dùng chung bảng màu; màn Đăng nhập/Đăng ký đổi từ thẻ sáng sang thẻ navy kèm logo ChessPlus.
- **Sửa lỗi trùng tên class**: `.cp-hero` của trang chủ đè lên `.cp-hero` (ba ô thống kê) của trang Câu đố làm chúng xếp dọc; nay bộ luật trang chủ gắn vào `.cp-home .cp-hero`.
- CSS mới: `src/mobile-chessplus.css` (lớp cuối của bundle `vila-professional.css`, chỉ áp dụng ≤ 820 px — giao diện máy tính không đổi). `main.js` thêm `syncTopbarProfile()`. Cache service worker nâng lên `fix8`. Test mới `tests/mobile-chessplus-shell.test.js`.

## Trang chủ ChessPlus mới

- **Thay hoàn toàn trang chủ cũ** (trung tâm 23 gian hàng, các khối thu gọn, vườn hoa, nhạc, thống kê) bằng giao diện mới: header logo ChessPlus + chip hồ sơ/Elo + nút menu, banner trượt 4 slide có chấm tròn, lưới 6 ô bo góc đều nhau (Chơi cờ, Đấu bot, Câu đố, Phân tích, Khai cuộc, Cài đặt), thanh Nhiệm vụ hằng ngày và khu **banner sự kiện** phía dưới (rương chuỗi ngày, giải đấu CLB, gói thành viên).
- Thanh điều hướng dưới đổi thành Trang chủ · Thành tích · Ghép trận · Thư viện (lịch sử ván) · Thêm; biểu tượng là SVG nội bộ trong `#cpSprite` (index.html).
- CSS mới nằm ở lớp `src/home-chessplus.css` (đã thêm vào `scripts/build-professional-css.mjs` và build lại `vila-professional.css`). Cache service worker nâng lên `fix7`.
- Nhạc nền và thư viện nhạc chuyển hẳn về Cài đặt; lối tắt "Nhắn Admin" dùng ở mục Gói Pro & Premium.

## Patch tiếp theo — ClaudeFish chạy thật, độc lập, không dùng Stockfish

- **Nguyên nhân ClaudeFish "có tên mà không chạy"**: đấu trường đã đăng ký ClaudeFish nhưng `public/claudefish/` chỉ có worker, thiếu `claudefish.js/.wasm` đã build, nên mọi nước đều rơi về Stockfish 19. Nay có `public/claudefish/cf-engine.wasm` (engine WASI, NNUE tuỳ chọn) và `claudefish-worker.js` mới: nói UCI, tải wasm bằng `fetch`, không cần emscripten, xử lý lệnh tuần tự.
- **Dự phòng không còn là Stockfish**: nếu wasm thiếu/hỏng, nước đó do engine JS nội bộ của VILA (ViLa Classic) đi thay, ghi rõ trong ghi chú trận, đếm vào "nước dự phòng"; lỗi nạp wasm báo ngay (không chờ hết giờ khởi tạo).
- **Chơi ván thường với ClaudeFish**: Thiết lập trận → «AI đa phong cách» → «ClaudeFish (WASM · không dùng Stockfish)». Profile này bỏ qua đường nhờ Stockfish của các bot ngoại tuyến khác, dùng thời gian/độ sâu của cài đặt bot; beginner dùng 200 ms / độ sâu 3.
- Đấu trường: ClaudeFish chỉ xuất hiện một lần trong danh sách (không nhân đôi từ catalog). Thanh tốc độ hiện đúng tên «ClaudeFish · WebAssembly» (trước đó thiếu `name`).
- Service worker precache `claudefish-worker.js` + `cf-engine.wasm`.
- Test: `tests/claudefish-integration.test.js` chạy worker thật trong sandbox (mở đầu, chiếu hết 1 nước, ăn Hậu treo, phong Hậu, hết nước đi, thiếu wasm) và kiểm tra ClaudeFish không gọi Stockfish.
- Giới hạn đã biết: `cf-engine.wasm` là bản không SIMD; mã nguồn C++ của bản này chưa có trong repo (`engines/claudefish/claudefish.cpp` là bản cũ, build bằng emscripten như trước). Engine chỉ nhận FEN nên không tự tránh lặp nước ba lần.

## Patch tiếp theo — nhãn 3D, premove ghép trận, chat riêng mới, gói Kim Cương

- **Nhãn 3D thống nhất** (`src/label-3d.css`, lớp mới trong bundle): huy hiệu chất lượng nước đi ở trang Xem lại (!!, !, ★, ✓, BK, ?!, ?, ×, ??), tọa độ a–h / 1–8 trên bàn cờ, nhãn BOT và huy hiệu gói (Pro, Premium, Admin, **Kim Cương**) dùng chung một hệ nổi khối: gradient, viền sáng, bóng đổ và khắc nổi chữ; tôn trọng chế độ giảm chuyển động.
- **Kéo quân đi trước (premove) kiểu chess.com cho ghép trận online**: khi chưa đến lượt có thể kéo-thả hoặc chạm để xếp hàng nhiều nước; ô đi/đến tô đỏ như chess.com, quân hiện mờ ở ô đích; chuột phải, phím Esc hoặc nút «Hủy premove» huỷ hàng đợi; ngay khi đối thủ đi, nước đầu tiên tự bắn nếu còn hợp lệ (máy chủ vẫn kiểm tra `expectedPly`), nước sai bị huỷ kèm thông báo. Tốc độ hỏi trạng thái tăng lên 250 ms khi có premove. Dùng chung `premove.js` với chế độ chơi bot (nước giả-hợp-lệ, nhập thành, phong cấp, đi xuyên quân địch).
- **Chat riêng đẹp hơn** (`src/chat-direct.css`): bố cục kiểu messenger — danh sách hội thoại có tìm kiếm, tiêu đề phòng, nhóm tin theo ngày, bong bóng gom nhóm kèm giờ, bộ đếm ký tự; trên điện thoại hiển thị từng ngăn (danh sách ↔ phòng). Giữ nguyên toàn bộ id cũ.
- **Gói thành viên Kim Cương** (cao hơn Pro/Premium): 1 năm, cộng dồn khi gia hạn, giá cố định `DIAMOND_PRICE_VND` (99.000đ — số tạm, đổi trong `src/plans.js` và backend), huy hiệu 3D «KIM CƯƠNG» và khung tin nhắn ánh kim cương. Quy trình: gửi yêu cầu cho admin → admin xác nhận (`confirm-diamond`) trong cả Worker và Express; Google Play dùng sản phẩm `vila_diamond_1y` (biến `DIAMOND_PRODUCT_ID`, `PLAY_PRICE_VND_DIAMOND`).
- Test mới `tests/v3-70-diamond-premove-labels.test.js`; cập nhật các test cũ liên quan (premove nay được phép trong ghép trận). Cache service worker `chessplus-v3.69.1-fix5`.

## Patch tiếp theo — bộ điều tốc hiệu năng thích ứng (perf-governor)

- `src/perf-governor.js`: đo thời gian từng khung hình thật khi kéo quân hoặc quân trượt. Nếu máy rớt khung ở ít nhất 2 trong 4 lần gần nhất (≥ 14 khung, ≥ 20% khung bị khựng so với nhịp của chính máy đó), app tự chuyển sang chế độ **lite** (`<html data-perf="lite">`) và nhớ lựa chọn trên thiết bị. Máy 120 Hz hoặc máy bị giới hạn 30 fps không bị đánh giá nhầm.
- `src/perf-lite.css` (lớp cuối của bundle): chế độ lite tắt `backdrop-filter` toàn app, bỏ đổ bóng chữ ngoài bàn cờ và dừng vài hiệu ứng trang trí chạy vô hạn (equalizer nhạc, cánh hoa, quỹ đạo tìm trận, chấm tìm trận). Chuyển động của quân (transform) giữ nguyên.
- `?perf=lite` / `?perf=full` ép chế độ (không lưu); `?perf=1` hiện bảng đo fps / p95 / tỷ lệ khựng nhỏ ở góc trái.
- Kiểm tra trong Chromium thật: phiên mượt 60 fps giữ nguyên chế độ đầy đủ; hai phiên bị cố tình chặn luồng chính chuyển sang lite, `backdrop-filter` về `none`, animation về `none`, giá trị được lưu. Test mới `tests/perf-governor.test.js`.

## Patch tiếp theo — nhẹ hơn sau mỗi nước đi (kéo/thả quân)

- Sau khi thả quân, việc ghi nhiệm vụ ngày (`recordDailyEvent`, nhiều lần đọc/ghi localStorage đồng bộ) và lưu bản khôi phục ván (`persistLocalGameRecovery`) được dời sang **sau khung hình đầu tiên** (`runAfterPaint`), nên quân hiện và trượt ngay thay vì chờ các thao tác lưu. Lưu khôi phục được gộp (mỗi khung hình tối đa một lần).
- Quy tắc `body.board-dragging *{cursor:grabbing}` làm trình duyệt tính lại style cho **toàn bộ DOM** khi bắt đầu kéo; nay chỉ áp dụng cho chuột (`hover:hover` + `pointer:fine`), điện thoại không còn bị khựng lúc nhấc quân.
- Trang Phân tích: chừa đủ khoảng trống dưới cùng để thanh điều khiển cố định không che dòng cuối; số trên thanh đánh giá nhỏ lại cho vừa.

## Patch trên v3.69.1 — Xem lại ván: quân trượt mượt, hết chữ đè, gọn hơn (review-polish)

- **Quân trượt mượt khi xem lại** (`src/review-board-motion.js`): bàn cờ xem lại vẽ lại toàn bộ mỗi nước nên quân "nhảy". Nay chụp vị trí quân trước khi vẽ, rồi trượt (FLIP) quân đã đi từ ô cũ sang ô mới; bắt quân, nhập thành (vua + xe) đều đúng; tiến/lùi từng nước và chạy biến engine đều mượt. Nhảy xa nhiều nước thì bỏ qua animation; tôn trọng chế độ giảm chuyển động. Ô bàn cờ xem lại có thêm `data-square`, quân có `data-piece`.
- **Hết chữ đè / bị cắt** (`src/review-polish.css`, lớp cuối của bundle): tọa độ a–h/1–8 nhỏ lại, không che quân; số trên thanh lợi thế không còn bị cắt; nút «Ẩn mũi tên» không rớt xuống dòng; nhãn «Sai lầm nghiêm trọng» không còn bị cắt; bỏ biểu tượng 📖 trùng với huy hiệu BK; «Điểm đã mất» hiển thị đủ.
- **Gọn hơn trên điện thoại**: danh sách nước cao đến ~44% màn hình (trước đó chỉ ~4 dòng), hàng nước thấp hơn, ẩn chú giải ký hiệu trùng với bảng chất lượng, ẩn dòng chú thích dưới bàn cờ, rút gọn khoảng cách trang «Tổng quan» (~12% ngắn hơn). Đã kiểm tra bằng Chromium ở 360/390/430 px: không tràn ngang, không phần tử chữ nào chồng lên nhau.
- Quân đang kéo: bóng đổ nhỏ hơn trên điện thoại để đỡ nặng GPU.
- Cache service worker đổi thành `chessplus-v3.69.1-fix4`. Test mới `tests/review-board-motion.test.js`.

## Patch trên v3.69.1 — Viết lại trang Phân tích và Câu đố theo chess.com (mobile)

- **Câu đố** (`src/pages/puzzle-page.js`): bố cục dọc cho điện thoại — thanh Rating/Streak, bàn cờ full-width, nhắc lượt, 5 chế độ (Xếp hạng, Hằng ngày, Rush, Sinh tồn, Tuỳ chỉnh), tuỳ chỉnh theo chủ đề/độ khó/"chỉ câu từng sai". Giữ nguyên logic giải, gợi ý, xem đáp án, bàn cờ tự do sau khi giải.
- **Phân tích** (`src/pages/analysis-page.js`): trang mới thay trang cũ — bàn cờ + thanh đánh giá, mũi tên nước tốt nhất, 1–3 biến Stockfish, danh sách nước đi có thể đi tiếp biến, tab Engine / Khai cuộc / Ván cờ, nạp FEN/PGN, ván đã lưu, thanh điều khiển cố định trên thanh điều hướng.
- **Kho câu đố**: workflow CI dựng tới 1.000.000 câu đố Lichess (CC0) chia shard 1500 dòng (`puzzle_pack_max` / `vars.PUZZLE_PACK_MAX`).
- CSS: thêm lớp `chesscom-pages.css` (cuối cùng trong bundle), dọn selector của hai trang cũ; bundle `vila-professional.css` đã dựng lại.
- Workflow Android: bỏ gói SDK `tools` đã lỗi thời. Test cũ cập nhật theo markup mới, thêm `tests/chesscom-pages.test.js`.

## 3.69.1 patch — Android review, small mouse, chess.com premoves, sharded puzzle packs

- Game review (Android): sticky board on page 2, 52 px thumb controls, compact coach card, two-row move list, horizontally scrolling tools, safe-area padding.
- Virtual mouse: panel 188 -> 132 px wide, pad 76 -> 54 px, pointer 18x22 -> 11x14 px.
- Premoves are now pseudo-legal like chess.com/Lichess: capture onto squares the opponent may reach, slide through enemy pieces, diagonal pawn steps onto empty squares, castling. The real position still validates every premove when it fires (illegal -> queue cancelled).
- Puzzle pack: bands can be split into shards (`--shard-size`, default 1500 rows) so packs of 300000+ puzzles load one small file at a time; index.json lists `files` per band. Both Android workflows now build the full pack from the Lichess CC0 dump on the CI runner (falls back to the bundled 1,684-puzzle pack if the download fails).
- Text: replaced glyphs missing from many Android fonts (⊘ -> ×, ⧉ -> "Chép").

## Patch trên v3.69.1 — Đủ 4000 khai cuộc, kho câu đố thật, mũi tên xem lại ván mới

- **Khai cuộc**: `public/openings-eco.json` trước đây chỉ là bản dự phòng 338 dòng (nên app chỉ thấy ~341 khai cuộc khi bước `predev` không tải được GitHub). Nay gói đã kèm sẵn **4000 dòng** (3865 khai cuộc có tên từ Lichess chess-openings, CC0, + 135 đường dẫn trung gian đánh dấu `catalogOnly`); mọi dòng đã được phát lại từng nước để chắc chắn hợp lệ. `scripts/prepare-openings.mjs` hỗ trợ thêm `OPENINGS_SOURCE_DIR=<thư mục chứa a.tsv…e.tsv>` để dựng offline. App nạp file với khóa `?v=4000-complete` và `no-cache`, cache service worker đổi thành `chessplus-v3.69.1-fix3` nên máy cũ không còn giữ bản 338 dòng.
- **Kho câu đố**: bộ 110 câu giả (thế cờ xe+vua, cùng một đáp án) được thay bằng kho câu đố do ViLa tự sinh từ các ván tự chơi xuất phát từ khai cuộc thật. Mỗi câu chiếu hết (trong 1/2/3) đều được **chứng minh bằng tìm kiếm vét cạn**: nước đáp là duy nhất ở mọi bước và không có chiếu hết ngắn hơn; câu chiến thuật «đòn chĩa đôi» được kiểm bằng alpha-beta độ sâu 3–4. Elo của từng câu chỉ là **ước lượng** theo độ sâu lời giải. Câu của ViLa có id bắt đầu bằng `vg`, hiển thị nguồn «ViLa» và không còn gắn liên kết Lichess. Vẫn có thể thay bằng kho Lichess đầy đủ: `node scripts/build-puzzle-pack.mjs lichess_db_puzzle.csv.zst --max 40000`.
- **Mũi tên khi xem lại ván**: viết lại hoàn toàn (`src/review-arrows.js`): khối mũi tên có viền tối mờ để rõ trên mọi ô, chấm gốc ở ô xuất phát, nước mã vẽ hình chữ L; khi nước đã đi là sai lầm, hiện thêm mũi tên mảnh màu theo mức độ (vàng/cam/đỏ) dưới mũi tên xanh «nước tốt hơn». Có hiệu ứng hiện nhẹ (tôn trọng chế độ giảm chuyển động).
- **Xem lại ván — bản nâng cấp mạnh** (`src/review-insights.js`, `src/review-insights-view.js`): trang «Tổng quan» có thêm khối **Điểm nhấn của ván** gồm tóm tắt thông minh bằng tiếng Việt (ai nắm lợi thế, bước ngoặt, sai lầm lớn nhất mỗi bên, nước thiên tài), **Elo ước tính** từng bên quy từ độ chính xác (chỉ để tham khảo) và thẻ **khoảnh khắc then chốt** (bấm để nhảy tới nước đó). Trang «Từng nước» có thêm: nút **Sai lầm trước/sau** (phím `[` và `]`), **Chạy biến engine** ngay trên bàn cờ (tự chạy/tạm dừng/lùi/tiến, `Esc` để thoát) và **Sao chép/Tải PGN kèm đánh giá** (NAG `$1…$6`, `[%eval]`, ghi chú «Nên đi: …»).
- Test mới `tests/review-insights.test.js`, `tests/review-arrows.test.js`; cập nhật `release-audit` (chấp nhận catalog đủ 4000) và `chessplus-visual-fix`.

## Patch trên v3.69.1 — Xem lại ván kiểu Chess.com (2 trang) và kiểm tra đồng bộ

- **Trang 1 «Tổng quan»**: thẻ độ chính xác hai bên kèm tên người chơi, biểu đồ lợi thế dạng vùng sáng/tối (chấm màu ở các nước sai lầm, thiên tài…; chạm vào biểu đồ để nhảy sang nước đó), bảng **chất lượng theo giai đoạn** (Khai cuộc / Trung cuộc / Tàn cuộc), bảng số nước theo chất lượng có biểu tượng tròn, các nút hành động.
- **Trang 2 «Từng nước»**: thanh lợi thế dọc cạnh bàn cờ, tên hai bên, tọa độ a–h/1–8, **huy hiệu tròn ở góc ô đến** (!!, !, ★, ✓, ?!, ?, ??, ⊘…) và ô đi/đến được tô màu theo chất lượng, mũi tên xanh chỉ nước tốt hơn (chỉ hiện khi nước đã đi không phải nước tốt nhất; có nút Ẩn/Hiện), thẻ huấn luyện viên («Nf3 là nước tốt nhất», mất bao nhiêu quân tốt, biến chính), danh sách nước có biểu tượng từng nước và tự cuộn tới nước đang xem.
- Ổn định: mỗi khối giao diện xem lại dựng trong `safeReviewMarkup` nên một dòng dữ liệu hỏng không còn làm trắng cả trang; danh sách nước giữ nguyên vị trí cuộn khi Stockfish đang phân tích; giữ mọi id điều khiển cũ.
- Đồng bộ/GitHub: `index.js` rời (bản Worker v3.68.1) không dùng được vì import `./plans.js`, `./clock.js`… không tồn tại cạnh nó; Worker đúng là `cloudflare/src/index.js` (import `../../src/…`). Thêm `scripts/check-sync.mjs` (`npm run check:sync`, chạy cả trong CI) kiểm tra phiên bản, import của Worker, dòng CRLF/LF lẫn lộn, bộ CSS gộp và giới hạn 25 MB; thêm `.gitattributes` ép LF. Cache service worker đổi thành `chessplus-v3.69.1-fix2`.
- Test mới `tests/review-chesscom.test.js`.

## v3.69.1 — Rà soát và sửa lỗi sau kiểm tra v3.69.0

- Đồng bộ phiên bản 3.69.1 ở `package.json`, `index.html`, `sw.js`, server, Worker, Gradle (versionCode 17) và các test. Tên cache service worker đổi thành `chessplus-v3.69.1-fix1` nên máy đã cài sẽ tải lại engine, quân cờ và lc0 thay vì giữ bản cũ.
- Worker Cloudflare: hỗ trợ secret `TOKEN_SECRET` để khoá ký phiên đăng nhập nằm ngoài cơ sở dữ liệu (không còn lưu vào DB khi có secret; khi chưa đặt thì giữ cách cũ nên không phá bản đang chạy). `generate-secrets.mjs` và `SECRETS_VI.md` cập nhật theo.
- Lưu ý triển khai: dùng `cloudflare/src/index.js` trong gói này, không dùng `index.js` rời bản v3.67 (thiếu email, giấy phép, giải đấu).
- Xem lại ván chia **2 lớp** giống Chess.com: lớp 1 «Tổng quan» (độ chính xác hai bên, biểu đồ lợi thế, bảng chất lượng nước đi Trắng/Đen, nút hành động) và lớp 2 «Từng nước» (bàn cờ xem lại, tua nước, phân tích từng nước, danh sách nước). Nút Back của Android từ lớp 2 quay về lớp 1 trước khi rời trang. Giữ nguyên mọi id điều khiển cũ; thanh nút không còn dính đáy màn hình che nội dung. Kiểm tra bằng Chromium ở khổ 390px, không tràn ngang.
- Thống nhất chữ: «Thiếu chính xác», «Sai lầm», «Sai lầm nghiêm trọng» dùng một cách duy nhất (trước đó lẫn «Chưa chính xác», «Chưa chuẩn», «Blunder»); đơn vị mất điểm ghi rõ «quân tốt» thay cho «tốt» (dễ nhầm với tính từ). README cập nhật theo. Test mới `tests/review-layers.test.js`.
- Kiểm tra dữ liệu theo tài khoản (v3.69): mô phỏng hai tài khoản trên một máy cho thấy dữ liệu cũ được chuyển đúng một lần cho chủ máy, tài khoản khác không thấy ván, Elo hay tiến trình của nhau, và ID đăng nhập bất thường bị làm sạch. Còn hai mục vẫn dùng chung theo thiết bị: mức kinh nghiệm (`experience`) và bảng xếp hạng cúp đấu trường (`arena-cup-standings`).

## Patch trên v3.69.0 — Kéo quân mượt, nước đi trước, bút vẽ ngoài bàn, sửa nút bị bẻ chữ

- Sửa lỗi giao diện hồ sơ (Tactical Lab → "Luyện ngay", Lịch sử luyện tập → "Tất cả", "Xem lại"): nút chữ dùng chung lớp `.tiny-btn` bị ép vào ô icon 31×31px nên chữ rơi từng ký tự xuống dòng. Thêm biến thể `.tiny-btn-text` (rộng theo chữ, không xuống dòng) cho cả 4 nút chữ.
- Kéo quân mượt hơn cho cả bàn chính, bàn xếp hạng và bàn câu đố (module dùng chung `src/board-drag-fx.js`): quân bám ngón tay ngay trong sự kiện `pointermove` (không còn trễ một khung hình), chuột giữ quân ngay dưới con trỏ còn cảm ứng nhấc lên trên ngón tay, quân "hạ cánh" từ điểm thả vào tâm ô thay vì nhảy tức thì, thả sai ô thì quân lướt về chỗ cũ thay vì biến mất.
- Hiệu ứng trượt quân từng bị ô cờ cắt (`overflow:hidden`) nên trông giật/lẹm; ô đang trượt giờ cho phép tràn ra ngoài.
- Bàn chính cập nhật theo từng ô (`patchBoardCells`): mỗi nước chỉ thay 2–4 ô thay vì dựng lại 64 ô, hết nháy ảnh quân và nhẹ hơn trên máy yếu. Áp dụng cho mọi bộ quân cờ.
- Nước đi trước (premove): quân đi trước cũng hạ cánh mượt, thời gian chờ sau nước bot giảm từ 170ms xuống 110ms.
- Bút vẽ: thêm nút "✎ Bút vẽ" ngay dưới bàn cờ (mở thanh công cụ ngay tại chỗ), vẫn giữ lối vào cũ trong menu và chuột ảo.
- Test mới `tests/board-drag-fx.test.js`.

## Patch trên v3.69.0 — Máy chủ Stockfish riêng và kho câu đố nâng cấp

- Máy chủ phân tích riêng `analysis-server/` (Node thuần, không thư viện ngoài): Stockfish bản gốc, nhiều engine song song, giới hạn theo số node (kết quả ổn định), cache LRU lưu đĩa, hợp nhất yêu cầu trùng, hàng đợi ưu tiên, tự thay engine sập, luồng NDJSON cho phân tích cả ván, kiểm tra FEN nghiêm ngặt, khóa Bearer so sánh thời gian cố định, giới hạn tốc độ và chặn dò khóa, CORS (kể cả Private Network Access). Có Dockerfile, docker-compose (kèm Cloudflare Tunnel), hướng dẫn `analysis-server/README_VI.md`.
- App: mục Cài đặt "Máy chủ Stockfish riêng" (địa chỉ, khóa, kiểm tra kết nối). Phân tích sau ván gửi lên máy chủ; kết quả đi qua đúng đường chấm của app (`receiveReviewInfo` → `classifyMoveQuality`) nên nhãn không đổi; lỗi mạng/máy chủ tự chuyển sang Stockfish trên máy. `src/remote-analysis.js` là client.
- Kho câu đố tích hợp `src/puzzle-pack.js` + `scripts/build-puzzle-pack.mjs`: chọn câu theo Elo câu đố của người chơi, lọc chủ đề, nhớ câu đã làm theo tài khoản, đề hằng ngày xác định theo ngày (dùng khi mất mạng). Là nguồn đầu tiên trong luồng chọn câu.
- Script build: thêm `--out`, và kiểm chứng bằng máy chủ Stockfish (`--verify-url/--verify-key`): chỉ giữ câu mà engine xác nhận nước giải hợp lệ, tốt nhất và duy nhất (`POST /v1/puzzle/verify`).
- Test: `tests/analysis-server.test.js` (gồm chạy Stockfish 19 thật), `tests/analysis-server-wiring.test.js`, `tests/puzzle-pack.test.js`, `tests/puzzle-pack-verify.test.js`.
- Lưu ý: `public/puzzles/` chưa kèm dữ liệu; chạy `npm run build:puzzle-pack -- <tệp csv.zst>` để tạo (xem `docs/guides/PUZZLE_PACK_VI.md`).

## Patch trên v3.69.0 — Email thông báo tài khoản, quyền admin, chống lạm dụng

- Email thông báo (Resend, Worker Cloudflare): chào mừng khi đăng ký có email, email vừa liên kết, đổi/gỡ email (báo cả địa chỉ cũ, chỉ hiện địa chỉ mới đã che bớt), đăng nhập từ thiết bị mới (thiết bị, quốc gia, IP che bớt), đổi mật khẩu. Mỗi địa chỉ nhận tối đa 4 thư mỗi giờ; lỗi gửi thư không ảnh hưởng thao tác. Cần secret `RESEND_API_KEY` và biến `MAIL_FROM` (xem `cloudflare/SECRETS_VI.md` mục 8); `/health` báo `mail`.
- Admin: khóa tài khoản có thời hạn (tự mở khi hết hạn), cấm nhắn tin/kết bạn (người bị cấm vẫn nhắn được admin để khiếu nại), đăng xuất mọi thiết bị, đặt lại Elo, xem chi tiết tài khoản (thiết bị, báo cáo, cảnh cáo, nhật ký hoạt động), gửi email thử. Giao diện Admin có nút tương ứng.
- Chống lạm dụng: giới hạn theo tài khoản (không chỉ theo IP) cho tin nhắn, lời mời kết bạn, báo cáo, tìm kiếm; gửi tin nhắn/lời mời quá nhanh 3 lần trong 1 giờ thì tự cấm chat 30 phút; chặn tên đăng nhập/biệt danh giả danh admin, hỗ trợ, staff.
- Chưa áp dụng cho `server/` (Node tự chạy): các tính năng trên chỉ có ở Worker Cloudflare.
- Test: `tests/account-mail-sanctions.test.js`.

## Patch trên v3.69.0 — Nút Back không thoát nhầm, camera cho chuột tay

- Chuột nhận diện tay: WebView Android chưa bao giờ được cấp quyền camera (thiếu `onPermissionRequest` và xin quyền CAMERA lúc chạy), nên `getUserMedia` luôn bị từ chối. Nay ứng dụng xin quyền CAMERA khi bật camera tay và chỉ cấp quyền camera cho origin của ứng dụng; thông báo lỗi nói rõ cách bật quyền trong Cài đặt. Manifest khai báo camera là không bắt buộc.
- Nút Back/thoát: trước đây Back đi lùi theo lịch sử WebView nên có thể thoát hẳn ứng dụng. Nay trang xử lý Back trước (`window.handleAppBack`): đóng hộp thoại/menu, thoát trận qua màn hình xác nhận, rồi về trang chủ; chỉ từ trang chủ mới cần bấm Back lần hai trong 2 giây để thoát.
- Test: `tests/android-back-camera.test.js`.

## Patch trên v3.68.1 — Sửa chuột nhận diện tay không tải được mô hình

## v3.69.0 — Tách dữ liệu theo tài khoản, sửa admin, Lc0 mạng nơ-ron thật

- **Sửa giao diện admin**: hàng người dùng không còn bị ép thành một cột chữ dọc trên điện thoại (hàng tự xuống dòng, nút gói xếp lưới).
- **Mỗi tài khoản một kho dữ liệu riêng**: ván đã lưu, Elo, gói Pro/Premium cục bộ, nhiệm vụ, hộp thư, puzzle, bài học… được lưu theo `u-<id>`/`guest`; đổi tài khoản tự nạp lại dữ liệu đúng người. Dữ liệu cũ dùng chung được chuyển một lần cho chủ máy rồi xóa khỏi khóa chung.
- **Không còn lưu ván của người khác**: xem lại ván xếp hạng/arena/bản ghi tài khoản khác chỉ là xem, không tạo mục mới trong lịch sử. Đồng bộ đám mây chỉ gửi ván của đúng tài khoản; máy chủ (Node + Cloudflare) từ chối ván gắn `ownerId` khác.
- **Lc0 thật**: mục “Lc0 · Maia 1100/1500/1900” là mạng nơ-ron Lc0 chạy bằng bộ chạy tự viết (`src/lc0/`): đọc trọng số .pb/.pb.gz, MCTS PUCT, nhân tích chập WASM-SIMD tự lắp (~4 ms/lượt đánh giá, ~10× bản JS), mỗi mạng một Web Worker riêng, tối đa 2 mạng trong bộ nhớ. Có thể nạp mạng .pb/.pb.gz riêng (T60, T70…). Lỗi → tự rơi về engine Leela-style cũ nên ván không bao giờ kẹt. “Leela-style” cũ được ghi rõ là mô phỏng.


- Gốc lỗi: Worker nhận diện tay chạy kiểu `module` và nạp MediaPipe bằng `import()`; MediaPipe nạp WASM bằng `importScripts()` mà module worker cấm, nên mô hình không bao giờ khởi tạo được, kể cả khi có mạng.
- Worker nay là Worker kiểu thường; thư viện MediaPipe, WASM và mô hình `hand_landmarker.task` được đóng gói sẵn vào `public/mediapipe/` khi build (`scripts/fetch-hand-model.mjs`, chạy trong `prebuild`), nên chạy được offline và trong WebView Android. CDN chỉ còn là phương án dự phòng.
- Thông báo lỗi hiển thị nguyên nhân thật (HTTP, tệp thiếu, GPU/CPU) thay vì câu chung chung; service worker lưu cache thư mục `/mediapipe/`.
- Test: `tests/hand-mouse-worker.test.js`.

## Patch trên v3.67.0 — Admin cấp gói, tìm admin, huy hiệu Pro/Premium, chạm hồ sơ ổn định

- Hồ sơ: mọi liên kết `data-open-profile` mở qua MỘT trình nghe ủy quyền ở cấp document (không còn phụ thuộc gắn lại sau mỗi lần render), có chống bấm đúp và `touch-action: manipulation`/vùng chạm ≥ 44px.
- Huy hiệu: máy chủ trả `tier` (`free`/`pro`/`premium`; admin hiển thị ADMIN) tính theo hạn gói thật; hiển thị ở hồ sơ, bảng xếp hạng, bạn bè, tìm kiếm, chat, bảng admin. Gói hết hạn tự về `free`.
- Tìm admin: `GET /support/admin` chọn admin đang online trước, rồi admin hoạt động gần nhất; yêu cầu mua gói luôn gửi tới admin này. Nút “Tìm admin & nhắn ngay” trong trang Gói.
- Admin cấp/thu hồi: Pro 30 ngày / 1 năm, Premium trọn đời, “Thu hồi gói”; kiểm tra phía máy chủ (số ngày 1–366, không đổi gói tài khoản bị khóa), tự nhắn thông báo cho người chơi và ghi audit. Đề nghị Premium có thêm nút “Cấp Premium”.
- Sửa: bảng admin gắn trùng sự kiện mỗi lần tải lại (hộp xác nhận hiện nhiều lần); danh sách không tự làm mới sau khi cấp gói.
- Bot khi admin offline: panel “VILA Trợ lý” hiện ở trang Gói và Tin nhắn khi không admin nào online (hàng chờ, vị trí yêu cầu của bạn, FAQ, nút gửi yêu cầu Pro); tin nhắn tới admin offline nhận 1 phản hồi tự động/giờ. Bot không bao giờ tự cấp gói.
- Giao diện: nhãn 3D “BOT” (cùng kiểu bevel với icon hiện tại) cho panel trợ lý và tin nhắn tự động; trình phát nhạc chỉ còn một viên thuốc nhỏ (tên ngắn, ⏸, ✕); bỏ các dòng chữ mô tả thừa ở trang Gói, Tin nhắn và thư viện nhạc.
- Test: `tests/v3-68-admin-tier.test.js` (7 bài, gồm kiểm tra chạy thật Worker + Durable Object).

## Post-v3.67.0 test correction — offline Stockfish rescue contract

- Fixed test 292's stale source-pattern assertion. The implementation now resolves a dedicated beginner search budget before choosing the bounded rescue depth; the old assertion only accepted the previous ternary and incorrectly reported a failure.
- Tightened the regression checks to verify the beginner budget, bounded depth, strength-aware time/node budget, beginner-practice flag, legal UCI move validation, clock/current-position guard, and fallback ordering.
- Runtime code behavior was not changed because inspection confirmed the strength-aware rescue path was already implemented. This patch aligns the test with that behavior instead of weakening the test.
- Targeted runtime tests: 13/13 passed (Elo-500 strength, search budgets and engine profiles). Eight direct rescue-contract assertions passed. The full `tests/premove.test.js` file could not be executed in this work environment because the npm install timed out and the `chess.js` dependency directory is incomplete; rerun after a successful `npm install`.

## v3.68.1 (hotfix)
- Fix: test `v3.67.1 account settings use collapsible sections…` thất bại vì bundle `vila-professional.css` thiếu CSS cho `.account-section > summary`, `.review-ply-san` và `select.field`. Đã thêm vào layer `vila-professional-theme.css` và dựng lại bundle.
- UI: mục tài khoản (Tên hiển thị / Email / Mật khẩu) là thẻ gập có mũi tên, vùng bấm ≥56px, ô nhập 16px (không bị zoom trên Android); chữ nước đi trong Review 15px; ô chọn (select) đồng bộ giao diện, có mũi tên riêng.
- Fix: nút "Kiểm tra kết nối online" ở cổng đăng nhập giờ kiểm tra đúng máy chủ đang dùng (proxy /api khi chạy dev/Termux) thay vì luôn gọi Cloudflare Worker.
- Tooling: `npm run build` (prebuild) tự dựng lại bundle CSS; thêm `tests/css-bundle-sync.test.js` để bundle không còn lệch khỏi các layer nguồn.
- Version: đồng bộ 3.68.1 ở package.json, service worker (cache key mới), Gradle (versionCode 16), server, Cloudflare Worker, index.html và các test liên quan.
- Docs: gom 55 file báo cáo/hướng dẫn vào `docs/` (guides, changelogs, reports) kèm mục lục `docs/README.md`; cập nhật liên kết và test.
- UI polish: vùng bấm ≥44px trên màn cảm ứng, ô nhập 16px chống zoom, chặn tràn ngang, modal cuộn theo dvh, toast tránh thanh điều hướng, focus ring rõ, hỗ trợ prefers-contrast và forced-colors.

## v3.67.0 — Stability, Chess Intelligence & Personal Mistake Training

- Preserve FEN before/after each analyzed move so review lines can be replayed and converted into legal training positions.
- Add a local-first spaced-repetition module for the player's own inaccuracies, mistakes, blunders and missed wins; filters engine-suggested moves through legal-move validation.
- Add a touch-first training board in the review page with move selection, legal validation, hints, reset, next-item flow, persistent attempts and mastery after three correct spaced responses.
- Bound the Elo 500 search to 5 plies / 260 ms and add a larger but still legal-only move-deviation handicap in both primary and offline-rescue engine paths. Elo remains a training target, not a match-calibrated rating.
- Add unit and static regression tests, mobile styling, and release-script registration.
- Full engine/browser integration is still subject to a complete npm dependency install and device testing.

## v3.66.0 — Xem lại có mũi tên, bàn học trực tuyến và bot dễ hơn

- Thêm lớp phủ SVG trên bàn xem lại: mũi tên vàng cho nước đã đi, cyan cho nước tốt nhất Stockfish đề xuất tại vị trí hiện tại; hỗ trợ tua bằng phím mũi tên và Home/End.
- Sửa luồng nhập mã trên di động để không render lại toàn trang trước khi gửi khiến ô nhập mất focus; nút hiện/ẩn mã đồng bộ với trạng thái ban đầu.
- Thêm bàn học trực tuyến tra thống kê khai cuộc qua backend `/api/openings/explorer`, kèm thông báo khi mạng/backend không sẵn sàng.
- Tăng giới hạn kho câu đố ngoại tuyến lên 500 và nút tải theo lô tối đa 50 câu từ API Lichess; từng câu vẫn được kiểm tra luật và loại trùng trước khi lưu. Không nhúng toàn bộ cơ sở dữ liệu câu đố vào gói phát hành.
- Làm mức bot Elo 500–600 yếu hơn có chủ đích bằng ngân sách tìm kiếm thấp hơn và xác suất chọn nước hợp lệ khác; đây là handicap huấn luyện, không phải Elo được hiệu chuẩn.
- Nâng `versionName` Android lên 3.66.0; cập nhật báo cáo QA và regression tests.
- Kiểm thử `test:static`: 351/356 đạt; 5 bài không khởi chạy do môi trường thiếu `express`/`chess.js`. Chưa xác nhận build web/APK và thử nghiệm E2E trên điện thoại trong môi trường này.

## v3.65.0 — Mã dùng thử bảo mật và intro quân mã VILA

- Thêm trang nhập mã riêng, dùng thử Pro 5 ngày và Premium 1 phút theo thời hạn máy chủ.
- Mã được xác minh bằng HMAC-SHA-256 ở máy chủ; không nhúng mã thô trong giao diện. Cần cấu hình secret trước khi bật sử dụng trên production.
- Giới hạn mỗi tài khoản chỉ đổi một lần cho từng loại thử nghiệm; giới hạn tốc độ endpoint và ghi nhật ký kiểm toán.
- Thêm intro quân mã VILA bằng SVG nội tuyến và CSS 3D, chạy một lần trong 5 giây; không tải ảnh ngoài.
- Tăng Android versionCode lên 13, versionName lên 3.65.0.
- Lưu ý: thời gian Premium 1 phút là thời gian hết hạn entitlement, UI vẫn cần tải lại trạng thái nếu ứng dụng đang mở sau khi hết hạn.

# ViLa Chess v3.63.0 — Admin Messenger & Plans — 2026-10-24

- Added server-backed Pro/Premium purchase requests, admin-only decision queue, rate limits and audit entries in both Node and Cloudflare backends.
- Pro requests are fixed at VND 1,000 for three hours and require explicit admin confirmation; Premium proposal range is VND 1,000–100,000 and is not automatically sold or granted.
- Local Pro trial costs 50,000 coins for three hours. Cloudflare Durable Object record serialization now persists direct messages and purchase requests across restart.
- Added plan-assistant panel in the admin chat and real admin dashboard actions; no ban-evasion mechanism was added.
- Targeted UI/plan tests (36/36) and Worker route/persistence integration passed. The broader static set reports 338/343; five tests cannot load because `express`/`chess.js` are absent. Node integration and clean Vite/APK builds remain unverified because dependencies could not be installed in this environment; see `docs/reports/TEST_REPORT_V3_63_0.md`.



- Fixed a global 560px app-width cap that squeezed the full application on larger layout viewports.
- Improved leaderboard and direct-message contrast, card hierarchy, and touch targets.
- Local Vite development now routes default community API calls through the local `/api` proxy to the paired Express server.
- Direct-message send now renders the server-confirmed message immediately instead of depending on a potentially busy poll.

# Changelog Cờ Vua ViLa

## v3.64.0 — Cài đặt nâng cao, kết quả mang thương hiệu và ghép trận 3D

- Thiết kế lại Cài đặt thành các nhóm giao diện, di chuyển, bot/phân tích và âm thanh; bổ sung tùy chọn tọa độ, premove, quân đã ăn, xác nhận đầu hàng, depth/time, engine, chất lượng phân tích, đồng hồ và kho khai cuộc.
- Bảng chọn sức mạnh bot có các nút mức nhanh Elo 500–3200 và lựa chọn tối đa; giá trị áp dụng cho ván mới, không âm thầm thay engine giữa ván.
- Thêm các kiểu âm thanh Êm/Gỗ/Neon/Tắt, lưu lựa chọn hợp lệ.
- Chuyển xác nhận thoát/đầu hàng sang modal VILA có logo, hỗ trợ phím Escape và nút ở lại; bổ sung thương hiệu vào bảng kết quả.
- Thay icon ghép trận bằng SVG 3D màu cyan, không dùng biểu tượng kiếm đỏ.
- Chuẩn hóa SAN khi nhận diện khai cuộc, bỏ dấu chiếu/chiếu hết/ký hiệu chú thích và chuẩn hóa nhập thành kiểu 0-0.
- Yêu cầu Pro/Premium tiếp tục gửi về API máy chủ và mở cuộc trò chuyện với admin; yêu cầu không tự kích hoạt gói khi chưa được admin xác nhận.

## v3.62.0 — Professional Edition, thống nhất hệ thống giao diện

- Gom các stylesheet đang dùng thành một entrypoint duy nhất `src/vila-professional.css`; giữ nguyên quy tắc component theo thứ tự cũ và áp dụng design system cuối cùng thống nhất.
- Dùng bảng màu navy/xanh dương/cyan/vàng thống nhất, tăng tương phản chữ và chuẩn hóa thẻ, biểu mẫu, hồ sơ, xếp hạng, chat và màn đấu.
- Chuẩn hóa nhãn/huy hiệu kiểu 3D với gradient vật liệu, cạnh sáng và bóng đổ; huy chương Top 3 dùng hiệu ứng kim loại vàng/bạc/đồng.
- Cải thiện bố cục responsive, vùng an toàn Android, chat trên màn nhỏ, toast và trình phát nhạc nổi để giảm che nội dung.
- Không thay đổi logic luật cờ, engine, tài khoản, backend, ghép trận hoặc schema dữ liệu.
- Đã kiểm tra cú pháp và các test tĩnh mục tiêu; chưa xác minh Vite/APK build sạch vì `npm ci` timeout khi lấy dependency. Chi tiết: `docs/reports/TEST_REPORT_V3_62_PRO_UI.md`.

## v3.61.0 — ổn định thiết lập xếp hạng và rà soát fair-play

- Dùng chung danh mục time control cho giao diện, Node và Cloudflare Worker; khi tải lại trang trong lúc chờ, khôi phục đúng loại Elo và mốc thời gian đang ghép.
- Nếu client cũ không gửi time control, backend mặc định Daily 1d nhất quán.
- Anti-cheat ghi nhận tín hiệu từ thời gian mỗi lượt do server đo và số nước hợp lệ ở vị trí trước khi đi; giới hạn dữ liệu lưu, cho admin rà soát thủ công, không tự động khóa tài khoản.
- Sửa avatar hồ sơ Cloudflare dùng ID ổn định thay vì đổi ngẫu nhiên mỗi lần API trả về.
- Đồng bộ phiên bản web, Service Worker, backend và Android lên 3.61.0; tăng Android versionCode lên 10.
- Thêm bảng admin rà soát tín hiệu fair-play: từng trận, loại thời gian, số tín hiệu, số lượt nhanh ở thế phức tạp và sự kiện gần nhất; API mới không làm hỏng dashboard khi backend đang dùng chưa có endpoint này.
- Cải thiện giao diện mobile cho thẻ review, badge mức độ và danh sách sự kiện, đồng thời giữ nguyên nguyên tắc không tự động kết tội/khóa từ tín hiệu thời gian.
- Kiểm thử mục tiêu 56/56 đạt và cú pháp JS bốn module hợp lệ. Giới hạn: chưa coi đây là build APK hoặc kiểm thử ghép trận Internet thật khi chưa có cài đặt npm hoàn chỉnh và triển khai Worker; xem `docs/reports/TEST_REPORT_V3_61_0.md`.


### Ghi chú triển khai backend Cloudflare (bản gốc v3.52.0, 2026-10-22)

- Đặt backend cộng đồng mặc định thành `https://bitter-sun-751a.nene09821z.workers.dev`; URL trống, localhost/loopback và tunnel tạm thời cũ tự chuyển về địa chỉ này.
- Giao diện không còn yêu cầu người chơi nhập Worker URL hay mã truy cập.
- Thêm mã Cloudflare Worker + Durable Object SQLite cho tài khoản, bạn bè, bảng xếp hạng, lịch sử và ghép trận ngẫu nhiên; máy chủ xác thực nước đi và cập nhật Elo.
- Lưu các mục thành bản ghi riêng trong SQLite và ghi thay đổi bằng transaction đồng bộ; không ghi toàn bộ dữ liệu cộng đồng vào một giá trị dễ vượt giới hạn.
- Lưu ý phát hành: mã nguồn đã được chuẩn bị, nhưng Worker phải được triển khai vào tài khoản Cloudflare trước khi tính năng online hoạt động thực tế. Kiểm tra hai thiết bị sau triển khai. Khôi phục tài khoản qua email cần cấu hình nhà cung cấp gửi thư.

## v3.52.0 — tài khoản VILA riêng, hồ sơ và hộp thư

- Thêm màn hình đăng nhập/tạo tài khoản xuất hiện trước khi vào app; đăng nhập bằng email hoặc biệt danh cùng mật khẩu VILA.
- Loại bỏ hoàn toàn luồng đăng nhập và cấu hình Firebase/Google/GitHub khỏi mã chạy và Gradle.
- Thêm lựa chọn Elo xuất phát theo trình độ, 1.000 tổ hợp avatar cute, tìm bạn bè, hộp thư admin và thông báo chuỗi hoạt động.
- Thêm mã khôi phục 6 chữ số dùng một lần, hết hạn sau 10 phút; cần cấu hình Resend bằng biến môi trường bí mật của backend đã triển khai để email thật được gửi.
- Ghi chú công bằng: không cung cấp engine/hint trong trận xếp hạng online; không thể bảo đảm tuyệt đối rằng nền tảng bên ngoài sẽ không khóa tài khoản.
- Tài khoản, ghép trận, tìm kiếm và hộp thư online yêu cầu máy chủ VILA chạy và có thể truy cập từ Internet.
- Sửa fixture của test tích hợp ghép trận: Alice và Bob dùng cùng Elo khởi điểm để đáp ứng quy tắc matchmaking hiện hành, thay vì kỳ vọng ghép ngay khi lệch 300 Elo.
- Bổ sung kiểm tra hồi quy: chênh lệch 300 Elo bị từ chối lúc đầu và chỉ được ghép sau khi cửa sổ Elo mở rộng đủ theo thời gian chờ.

## v3.51.1 — bàn cờ mượt hơn, đồng bộ phiên bản

- Quân cờ trượt theo khoảng cách (160–280 ms), có bóng khi kéo và tô sáng ô thả; thêm module `board-motion` kèm test.
- Sửa quân đi trước (premove): quân xếp hàng giờ hiện mờ ở ô đích; trước đó nhánh vẽ bóng không bao giờ chạy đúng và có thể vẽ thừa một quân khi xếp nhiều nước.
- Hiệu ứng nháy vàng khi quân hạ cánh chỉ chạy ngay sau nước đi, không lặp lại mỗi lần bàn cờ được vẽ lại (lật bàn, đổi cài đặt, xếp nước đi trước); ô đang trượt giữ z-index 9; bỏ bóng đổ nặng của quân đang trượt trên màn hình nhỏ.
- Sửa test premove của patch: test cũ gọi `e7e5` ở lượt Trắng nên lỗi ngay khi có `chess.js`; thay bằng test logic thật (một nước, chuỗi nước, nước sai dừng chuỗi, phong cấp) và báo *skipped* thay vì pass giả khi thiếu `chess.js`.
- Đồng bộ phiên bản `3.51.1` ở `package.json`, `package-lock.json`, tiêu đề web và Android, `public/sw.js` (khóa cache), `/api/health`, user-agent proxy câu đố; `versionCode` Android 8. Các test ghim phiên bản được cập nhật theo.
- Chưa xác minh trên điện thoại hoặc build APK thật.

## v3.50.0 — ổn định kéo quân, engine offline và quy trình phát hành

- Đồng bộ phiên bản web, Android, API, avatar và service-worker cache lên `3.50.0`; tăng `versionCode` lên 6.
- Bỏ qua thao tác nhấc tay/nhả chuột cũ nếu ván đấu hoặc FEN đã đổi trong lúc pointer còn được giữ, tránh chọn nhầm quân ở ván mới.
- Thêm kiểm tra tài nguyên engine có đối chiếu manifest, chữ ký WASM, giấy phép Stockfish 10 và chế độ Full NNUE trong build release.
- Thêm smoke test chạy Stockfish 19 Lite thật bằng UCI trên Node: xác nhận `uciok`, `readyok` và `bestmove` hợp lệ từ vị trí đầu.
- Giữ công cụ phân tích nằm trong menu chuột/menu trận; kiểm tra hồi quy công cụ vẽ, xem lại, mini-game và avatar offline.
- Chưa xác minh build APK hoặc thao tác trên điện thoại: npm registry không phân giải được DNS ở môi trường làm việc này. Cần kiểm tra artifact GitHub Actions trước khi cài.

## v3.49.5 — công cụ bút vẽ được ghim vào menu, không nổi đè bàn cờ

- Bỏ bảng công cụ phân tích dạng `position: fixed` nổi trên bàn cờ.
- Đưa một bộ điều khiển bút vẽ dùng chung vào menu Chuột ảo và tab Phân tích của menu trận đấu ☰; hai lối mở dùng chung cùng một widget, không tạo bản sao ID hay listener.
- Menu bút vẽ xuống dòng theo chiều rộng, bảng chuột giới hạn chiều cao và cuộn nội bộ khi mở nhiều công cụ.
- Chế độ Di chuyển quân vẫn là lựa chọn riêng; đóng bảng công cụ hoặc chọn lại ♟ sẽ không để chế độ vẽ chặn đường kéo quân.
- Tăng Android versionCode lên 5, versionName lên 3.49.5.

# Changelog


## v3.49.4 — thao tác bàn cờ mượt hơn, bảng phân tích và mini-game gọn hơn

- Tinh chỉnh ngưỡng kéo chuột/ngón tay và tiếp tục gom cập nhật vị trí quân theo khung hình để hạn chế giật khi kéo.
- Tách công cụ bàn cờ thành Di chuyển quân, Mũi tên, Bút chì tự do, Đường chữ L quân Mã và Khoanh ô; thêm màu nét, preview nét tự do và cuộn ngang thanh công cụ trên màn nhỏ.
- Chuyển về Di chuyển quân ngay khi chọn công cụ tương ứng; khi đang dùng chuột ảo, đổi công cụ sẽ thả trạng thái giữ chuột để không mắc kẹt trong chế độ kéo/vẽ.
- Bổ sung mini-game ngoại tuyến Phản xạ tọa độ với điểm, chuỗi liên tiếp và kỷ lục lưu trên thiết bị.
- Thêm avatar SVG thương hiệu VILA tối giản; được cache cho khởi động offline.
- Giảm khoảng cách/padding ở trang xem lại, làm gọn các khối biểu đồ, phát lại và nút hành động.
- Giữ Stockfish 19 NNUE Full/Lite và nhánh ASM-JS dự phòng trong GitHub Actions; không thay bằng một bản Leela WebAssembly thử nghiệm chưa tích hợp và kiểm chứng.
- Kiểm thử tĩnh liên quan đến kéo quân/chuột ảo, bảng vẽ, xem lại, engine profile và mini-game đã chạy. Build Android/đo độ trễ trên OPPO A17k chưa xác minh được trong môi trường này.

## Chưa phát hành — Đấu trường AI toàn lực, 4 khai cuộc riêng cho mỗi bot

- **Sửa lỗi nghiêm trọng (phát hiện khi chạy giao diện thật):** nút **Đấu trận** trong Đấu trường AI báo `drawArenaSides is not defined` nên không chạy được; đã thêm hàm bốc thăm màu theo tùy chọn “Đảo màu ngẫu nhiên”.
- **Sửa lỗi:** `LOCAL_GAME_RECOVERY_KEY` chưa được khai báo nên tính năng khôi phục ván đang chơi không bao giờ hoạt động (lỗi bị `try/catch` nuốt im lặng); đã khai báo khóa lưu `vila.chess.local-game-recovery.v1`.
- **Giao diện:** thanh đầu ván có 4 nút nhưng lưới chỉ 3 cột nên nút Menu rơi xuống và đè lên avatar đối thủ; đã sửa lưới.
- **Đấu trường:** thu gọn đoạn giải thích dài thành mục mở rộng để bàn cờ lên cao hơn trên điện thoại; thêm nút “Chọn bot & tùy chỉnh”; Tạm dừng/Dừng nằm cùng hàng; cỡ chữ nút 12,5px; xóa ghi chú “đang tính nước đi…” cũ khi ván kết thúc; hộp kết quả không lặp “80 nửa nước”.
- **Câu đố:** đoạn giới thiệu 7 dòng thu gọn còn 1 dòng, phần giải thích chuyển vào mục “Cách hoạt động”.
- Đồng bộ test Đấu trường với kho 4 khai cuộc riêng và thêm test hồi quy `tests/v3-49-ui-regressions.test.js`.
- Mỗi hồ sơ trong Đấu trường AI có đúng 4 biến khai cuộc đã lưu riêng (21 bộ hồ sơ gồm các bot VILA, Stockfish 19 và Stockfish 10); tên các biến được hiển thị ngay trong danh sách bot để người dùng kiểm tra.
- Mặc định, giải bắt đầu từ vị trí ban đầu để từng bot tự sử dụng kho 4 khai cuộc riêng; tuỳ chọn “Khai cuộc ghép cặp” vẫn có thể bật để benchmark cùng một khai cuộc rồi đổi màu.
- Giữ điều kiện engine công bằng: chung độ sâu, Skill Level và ngân sách thời gian mỗi nước. Kho khai cuộc đổi phong cách/độ đa dạng, không tăng ngân sách suy nghĩ của bot.
- Stockfish 19, Stockfish 10 và các profile VILA nhận giới hạn độ sâu/thời gian chung; profile VILA là phong cách chọn nước từ các biến thể Stockfish gần ngang điểm, không phải engine neural độc lập hay Elo đã benchmark. Nhánh cứu hộ offline vẫn giới hạn thời gian và ghi nhận khi được dùng.
- Kiểm thử mục tiêu: 34/34 bài về repertoire riêng, chọn bot, arena và lịch giải đạt. Bộ test tĩnh lớn: 291/292 đạt; test premove không khởi chạy do môi trường thiếu package `chess.js`. Build chưa xác minh vì môi trường hiện cũng thiếu binary/dependency Vite; chưa khẳng định APK hoặc thiết bị thật đã chạy. Chi tiết ở `docs/reports/TEST_REPORT_ARENA_4_OPENINGS.md`.

## Chưa phát hành — sửa hồi quy test dự phòng Stockfish
- Đồng bộ kiểm thử hồi quy với nhánh độ sâu tìm kiếm theo sức mạnh: cấu hình Elo/skill thấp giữ giới hạn cứu hộ, còn chế độ sức mạnh tối đa dùng ngân sách sâu hơn trong giới hạn engine.
- Tách tính toán độ sâu cứu hộ khỏi cấu hình ngân sách để dễ đọc và giảm nguy cơ kiểm thử phụ thuộc vào một dòng mã dài.
- Xác minh nước đi fallback là hợp lệ, cập nhật đồng hồ và chỉ dùng nước khẩn cấp khi tìm kiếm offline thất bại.

## Chưa phát hành — Chuột ảo PC và bảng vẽ phân tích nổi
- Thêm chuột ảo nhỏ gọn điều khiển bằng vùng trượt cảm ứng; con trỏ có thể nhấn, giữ và kéo-thả quân bằng chính luồng Pointer Events của bàn cờ, tránh thay thế đường kéo quân tối ưu sẵn có.
- Bảng chuột ảo có thể di chuyển, thu nhỏ, mở lại hoặc tắt; con trỏ được cập nhật theo `requestAnimationFrame` và dùng `transform` để hạn chế tái bố cục.
- Thêm tùy chọn nhận diện ngón trỏ qua camera: chụm ngón cái + ngón trỏ để giữ/kéo quân, tách để thả; nhận diện chạy trong Worker, ảnh không được gửi lên máy chủ. Tải thư viện/mô hình từ mạng khi bật camera (có thể tải lại khi bộ nhớ đệm hết hạn); vùng trượt cảm ứng vẫn là phương án dự phòng ngoại tuyến.
- Chuyển công cụ vẽ phân tích thành bảng nổi có tay nắm kéo, thu gọn, ẩn/hiện và chọn trực tiếp bốn màu xanh lá/đỏ/vàng/xanh dương; giữ thao tác mũi tên, khoanh ô và xóa dấu vẽ.
- Thêm kiểm thử hồi quy cho luồng chuột ảo và bảng phân tích nổi. Chưa chạy build Vite/Gradle hoặc đo độ trễ trên OPPO A17k vì cài dependencies bị treo trong môi trường; không khẳng định đã kiểm thử thiết bị thật.

## Chưa phát hành — giao diện v4: phòng đấu kiểu chess.com, nhạc nền mạng
- Màn bàn cờ chỉ còn: thanh trên, 2 thanh người chơi + đồng hồ, bàn cờ, thanh nút dưới. Thanh điều hướng/nhãn ẩn trong trận; nút ← về trang Thiết lập trận đấu (nơi có các nhãn Chơi/Bot/Câu đố...).
- Menu trận trượt lên (Nước đi · Phân tích · Thiết lập · Trang khác); trên máy tính là cột bên cố định.
- Bỏ toàn bộ nhạc ngoại tuyến (synth). Nhạc nền stream qua YouTube: remix / nhạc buồn TikTok / slowed; tự phát khi vào app, bài bị chặn nhúng tự chuyển bài kế, mini-player (trước/dừng/sau/tắt).
- Giao diện mới: header tối, thanh dưới nổi, trang thiết lập tối, thư viện nhạc.

## Chưa phát hành — sửa lỗi, đi trước vô hạn, giao diện dễ đọc
- Sửa 2 test fail: bản ZIP GitHub gọn không có `app/src/main/assets/sw.js`; test nay đọc `public/sw.js` khi bản sao Android vắng.
- Đi trước (premove) kiểu chess.com: xếp hàng vô hạn, nối nhiều nước (kể cả nhập thành, đi cùng quân hai lần); tự đi lần lượt, tự hủy cả hàng đợi khi đối thủ đi khác làm nước đầu không còn hợp lệ. Hủy bằng chuột phải, Esc, nút "Hủy n nước đi trước" hoặc chạm ô đã xếp.
- Nhập thành: bỏ nhãn O-O/O-O-O 8px đè lên ô; danh sách nước đi không xuống dòng, nhập thành dùng chữ đơn cách, nước gần nhất được tô.
- Quân trượt mượt khi bấm đi/bot đi (cả xe khi nhập thành), thả kéo quân vẫn tức thì; tôn trọng giảm chuyển động.
- Bảng màu navy/xanh dương/cyan thống nhất (`src/vila-polish.css`); số chỗ chữ thiếu tương phản giảm từ ~1.460 xuống ~130 (chủ yếu tọa độ trang trí trên bàn cờ).
- Viền xanh quanh nước bạn vừa đi, viền đỏ quanh nước đối thủ vừa đi (hai ô đi/đến, ô đến nháy nhẹ). Màu đi trước chuyển sang vàng hổ phách để không lẫn với viền đỏ.
- Nhãn phân tích kiểu chess.com theo xác suất thắng: Thiên tài (!!), Tuyệt vời (!), Tốt nhất, Xuất sắc, Tốt, Khai cuộc, Thiếu chính xác, Sai lầm, Bỏ lỡ, Sai lầm nghiêm trọng; huy hiệu tròn có màu. Thiên tài = hy sinh quân thật sự theo biến Stockfish; Tuyệt vời = nước duy nhất (MultiPV 2) hoặc lật ngược thế cờ.
- Mức phân tích ván mới "Cao nhất" (mặc định): Stockfish 19 Lite 8 giây/nước, MultiPV 2, Hash 64MB; có thể chọn Sâu/Chuẩn trong Cài đặt. Chưa có bản Full NNUE trong gói (cần tải ở bước build).
- Thêm: tự động phong Hậu, thông báo nước đi cho trình đọc màn hình (aria-live).
- Nâng chất lượng câu đố: nhánh dự phòng Stockfish phân tích MultiPV 3 và chỉ nhận đề khi nước giải hợp lệ, mang tính chiến thuật, điểm đủ tốt và vượt phương án kế tiếp tối thiểu 180 cp; bỏ qua đề mơ hồ/thông tin engine chưa đủ sâu.
- Đề Lichess có chủ đề chiếu hết trong 1 chấp nhận mọi nước đi hợp lệ dẫn đến chiếu hết, tránh đánh sai khi thế cờ có nhiều cách chiếu hết.
- Huy hiệu đề hiển thị độ khó/chủ đề thay vì số nửa nước của ván ngẫu nhiên; bổ sung kiểm thử cho các ngưỡng chất lượng.
- Sửa lỗi lộ đáp án: thẻ thông tin không còn hiển thị UCI của nước cần tìm trước khi người chơi đi; các chủ đề Lichess phổ biến được Việt hóa.

## v3.47.2 — Stockfish 10 nhanh hơn và gói GitHub gọn hơn

- Đấu trường: giới hạn thời gian Stockfish 10 khoảng 0,2–0,6 giây/nước; giảm timeout để dự phòng nhanh hơn.
- Đấu người: giới hạn Stockfish 10 ở tối đa 0,5 giây/nước; rút watchdog riêng cho engine cũ.
- Giữ Stockfish 10 và các fallback; không đổi cấu hình phân tích mạnh nhất.
- Giữ bản ZIP AI Studio trong `public/assets/aistudio`; Gradle tự khôi phục bản sao Android trong giai đoạn `preBuild`.
- Tăng versionName/versionCode, làm mới Service Worker và cache asset.

## v3.47.1 — giảm độ trễ Đấu trường AI và bỏ Stockfish 10 khỏi mặc định
- Đấu trường mặc định ghép Stockfish 19 với ViLa Rookie, không còn tự chọn Stockfish 10 cổ điển.
- Giảm ngân sách suy nghĩ mỗi nước của Đấu trường: Stockfish 19 dùng giới hạn 0,7–1,5 giây/nước; Stockfish 10 legacy dùng 0,3–1,2 giây/nước. Giảm nhịp nghỉ mặc định giữa nước còn 0,15 giây.
- Stockfish 10 vẫn có thể chọn thủ công để so sánh, được ghi nhãn là bản cũ/chậm hơn; không xóa tệp engine hoặc giấy phép.
- Đồng bộ thay đổi quan trọng trong JS bundle Android có sẵn, tăng version và Service Worker cache lên v3.47.1.
- QA tập trung: xem `docs/reports/TEST_REPORT_V3_47_1.md`. Chưa có build Vite/Gradle sạch do thiếu dependencies trong môi trường; không tuyên bố đã kiểm thử trên điện thoại thật.

## v3.47.0 — online cờ ngày, giao diện sáng và bot luyện người mới
- Thêm mốc 1 ngày và 2 ngày vào hàng đợi đấu trực tuyến; không thêm các mốc này vào thiết lập ván cục bộ.
- Thêm lựa chọn luyện người mới dựa trên Skill Level thấp của Stockfish, không giả lập Elo chính xác.
- Làm sáng giao diện câu đố/xem lại và tăng khả năng nhận chạm ở nút Đấu trường AI.
- Giữ nguyên Stockfish 19 Lite WASM và Stockfish 10 ASM.js hiện có; chưa có bản Full NNUE trong manifest.

## v3.46.4 — thiết lập trận riêng, vào bàn cờ sau khi bắt đầu

- Tách luồng chơi thành trang **Thiết lập trận đấu** và màn bàn cờ. Khi mới vào Chơi cờ, người dùng không còn phải cuộn qua bàn cờ để tìm phần thiết lập.
- Chọn chế độ, phong cách bot, màu quân, mức sức mạnh, thời gian trước khi tạo ván.
- Nút **Ván mới**, **Chơi lại**, **Thiết lập trận** và **Chơi nhanh** đưa người dùng về màn thiết lập; thao tác engine và đồng hồ được dừng khi rời trận.
- Giảm vùng cuộn thừa trên màn thiết lập di động; ẩn phần cài đặt trùng lặp trong cột phụ khi đang đấu.
- Tăng phiên bản/cache lên v3.46.4 để giảm nguy cơ giữ UI cũ trên thiết bị đã cài.

## v3.46.3 — đồng bộ bảng màu xanh dương/cyan, cache và Docker

- Đồng bộ màu giao diện theo logo: navy, xanh dương, cyan; giữ vàng cho phần thưởng.
- Sửa CSS bàn cờ để các theme do người dùng chọn tiếp tục áp dụng qua `--board-*`.
- Tăng phiên bản và Service Worker cache lên v3.46.3; đổi cache-bust biểu tượng lên v349.
- Thêm Dockerfile và `.dockerignore`; cập nhật test giao diện theo palette mới.
- Kiểm thử offline: chỉ xác nhận các bài test có thể chạy với dependency sẵn có; các bài cần `chess.js`/`express` phải được chạy ở môi trường cài dependency.

# Changelog

## v3.46.2 — logo thương hiệu mới và kỷ vật trong Cài đặt
- Dùng biểu tượng vương miện + mã xanh từ ảnh nguồn người dùng làm brand icon, favicon, PWA/app icon và các mật độ mipmap Android; giữ ảnh logo đầy đủ làm wordmark trong Cài đặt.
- Thêm ảnh tượng đài kỷ niệm vào riêng mục Cài đặt, tối ưu sang WebP và cache offline.
- Cập nhật cache key Service Worker để tránh icon cũ còn hiển thị trên Android/WebView; thêm manifest PWA và test hồi quy thương hiệu.
- QA: `test:static` 264/264; cú pháp JS/MJS 131/131; full test 266/270 do 4 test không nạp được dependency thiếu; `npm run build` chặn ở prebuild vì thiếu `chess.js`. Chi tiết tại `docs/reports/TEST_REPORT_V3_46_2.md`; chưa xác nhận APK.

## v3.46.1 — đối chiếu audit, dữ liệu khai cuộc dự phòng và cache đồng bộ
- Đồng bộ phiên bản ứng dụng/package/server và tăng cache-bust favicon để tránh dùng tài nguyên cũ sau cập nhật.
- Thay danh mục khai cuộc rỗng bằng 338 dòng khai cuộc dự phòng đã khử trùng lặp từ kho curation trong mã nguồn. Đây chỉ là bộ dự phòng, không giả làm dữ liệu Lichess đầy đủ; build phát hành vẫn bắt buộc nạp và xác thực ít nhất 3.000 dòng.
- Sửa thông báo khi danh mục JSON chỉ lặp lại biến đã có: ứng dụng vẫn cập nhật số liệu/chẩn đoán và báo thiếu dữ liệu thay vì âm thầm trả về.
- Sửa thứ tự lịch sử changelog/README, cập nhật nguồn câu đố và liên kết báo cáo QA hiện tại.
- QA: `npm run test:static` 261/261 đạt; 130/130 tệp JS/MJS qua `node --check`; `npm test` 263/267 với 4 test bị chặn do thiếu `chess.js`/`express`. `npm install` lỗi DNS `EAI_AGAIN`; production build/APK chưa xác minh. Xem `docs/reports/TEST_REPORT_V3_46_1.md`.

## v3.46.0 — giao diện mobile, đồng hồ nhanh và nhạc cờ vua
- Gom thiết lập trận, danh sách nước đi, phân tích và khai cuộc vào một menu Công cụ, tránh dàn hàng nút dài trên điện thoại.
- Bỏ dòng nhận diện khai cuộc bên dưới bàn cờ và thẻ gợi ý màu vàng; nước gợi ý vẫn được vẽ trực tiếp trên bàn cờ và hiển thị bằng thông báo ngắn.
- Thêm các nút chọn nhanh Siêu chớp 30 giây, Bullet 1+0, Blitz 3+2 và Rapid 10+0; vẫn giữ toàn bộ mốc thời gian trong danh sách thiết lập.
- Làm gọn thanh điều hướng trên màn hình hẹp, cải thiện thao tác kéo quân trên WebView và thêm lối tắt ghép trận người thật.
- Bỏ bản ghi Gymnopédie cũ khỏi nhạc tích hợp; các nhạc nền tích hợp là giai điệu tổng hợp nguyên bản chạy offline, còn nhạc từ YouTube chỉ phát khi người dùng chọn.
- Tăng version/cache key lên v3.46.0 và cập nhật kiểm thử hồi quy.
- QA bản này: `npm run test:static` 254/254; kiểm tra cú pháp 131/131 tệp JavaScript/MJS. `npm test` đạt 256/260; bốn test không khởi chạy vì môi trường thiếu `chess.js`/`express`. Chưa xác minh build APK hoặc thao tác trên thiết bị thật; xem `docs/reports/TEST_REPORT_V3_46_0.md`.

## v3.45.0 — độ an toàn đồng hồ và thao tác phong cấp
- Tính thời gian mỗi tick bằng hàm thuần có kiểm thử riêng; chặn giá trị thời gian `NaN`, không cho đồng hồ chạy tiếp trong ván đã kết thúc và không cộng thời gian khi đồng hồ bị rollback.
- Sửa race trong hộp chọn phong cấp: chụp ô xuất phát, FEN và epoch của ván trước khi mở hộp thoại; hủy nước đi nếu vị trí hoặc ván đã thay đổi thay vì dùng biến chọn quân có thể đã đổi.
- Khi Worker tìm nước ngoại tuyến bị treo/quá hạn, kết thúc Worker, dọn timeout của yêu cầu đang chờ và dùng tìm kiếm dự phòng nông có giới hạn thay vì để các yêu cầu sau mắc kẹt.
- Đưa avatar mã vương miện vào danh sách cache lõi của Service Worker để giao diện thương hiệu sẵn sàng ngoại tuyến ngay sau cài đặt.
- Xóa tệp tạm rỗng `public/test.tmp`; đồng bộ metadata package, giao diện, API health, user-agent và cache key lên v3.45.0.
- Kiểm thử: `test:static` 251/251 đạt; 128/128 tệp JS/MJS kiểm tra cú pháp đạt. Test tập trung đồng hồ, phong cấp bất đồng bộ và phục hồi Worker 9/9 đạt. `npm test` có 253/257 bài đạt, 4 bài không khởi chạy do thiếu `chess.js`/`express`; registry npm không phân giải được DNS trong môi trường này. Chưa xác nhận build APK hoặc thao tác trên thiết bị/máy chủ thật.

## v3.44.0 — nhận diện ViLa và giao diện màu sắc nhẹ
- Thêm ảnh mã đội vương miện do người dùng cung cấp làm dấu hiệu thương hiệu và avatar hồ sơ trên trang chủ.
- Thêm chuyển động màu bằng CSS nhẹ; không tải video và tôn trọng cài đặt giảm chuyển động của thiết bị.
- Giữ nguyên các luồng chơi cờ, đồng hồ xếp hạng, bạn bè/tìm kiếm, đấu trường, phân tích, câu đố, nhiệm vụ, cửa hàng và mini-game.
- Bổ sung CSS thích ứng cho avatar và hiệu ứng màu sắc.

## v3.43.0 — Stockfish 10 UCI handshake and mobile polish
- Parse each line of UCI output independently in the main Stockfish worker path. This handles legacy worker events that bundle `uciok`, `readyok`, and other lines into one event, with exact handshake matching and a longer startup watchdog.
- Added regression coverage for bundled/multiline UCI output, object-wrapped worker events and engine-health state; included engine-health tests in the static suite.
- Refined the analysis panel for small screens and mobile review metadata; kept the action toolbar in normal flow so it no longer obscures the lower match screen.
- The release workflow requires Stockfish 10, Stockfish 19 Lite/ASM and Full NNUE assets plus the Stockfish 10 license notice. Actual engine execution still must be confirmed by the GitHub build and a device run; the package dependency install could not complete in this offline environment.

## v3.42.0 — Engine recovery, puzzle service and mobile layout
- Stockfish 10 is a required dependency for release packaging; GitHub Actions fails early if the script or GPL notice is absent.
- Arena Stockfish 10 opponents retry using Stockfish 19 and then the VILA offline search core while validating every returned move against legal moves.
- Added a public puzzle proxy to the user's own backend with bounded recently-served puzzle IDs and daily-puzzle caching; client uses this server when configured and falls back to Lichess.
- Increased offline puzzle pool to 150 positions, remembered puzzle history to 15,000 positions, and puzzle pack downloads to 20 validated puzzles per batch.
- Fixed the mobile match action bar being cropped/overlaying content by placing it back into normal document flow; improved contrast of player cards and clock surfaces.
- Added five board cosmetics and four offline generated background music choices plus the optional online classical recording.
- Validation caveats for this line of work are consolidated in TEST_REPORT_V3_43_0.md; device-side play still needs GitHub APK build and a real-device run.

## v3.41.0 — VILA Atelier: thiết kế lại toàn bộ giao diện

- Thay ngôn ngữ giao diện tối xanh cũ bằng không gian sáng, phong cách editorial/studio: nền giấy, panel rõ cấp bậc, xanh lá làm màu hành động và điểm nhấn vàng cho phần giải đấu.
- Làm mới header, menu chức năng, thanh điều hướng mobile, màn chủ, bảng cờ, panel đồng hồ, danh sách nước đi, câu đố, khai cuộc, đấu trường, biểu đồ và cài đặt bằng lớp CSS riêng `src/vila-atelier.css`; giữ lại toàn bộ ID và bộ xử lý thao tác hiện có.
- Thiết kế lại thanh hành động ván cờ thành cụm 5 nút cảm ứng đồng đều; ẩn bottom navigation trong màn chơi trên điện thoại để không chồng lấp với thanh hành động.
- Bỏ Google Fonts tải từ xa để giảm yêu cầu mạng và tránh làm chậm khởi động offline; sử dụng font hệ thống.
- Đồng bộ metadata, API health, Service Worker, favicon cache-busting và test phiên bản lên 3.41.0.
- Bổ sung kiểm thử tĩnh cho lớp giao diện mới, breakpoint di động, offline-first typography và bảo toàn các hook chức năng.
- Đồng bộ các màn chuyên biệt vốn còn giữ tông cũ: phân tích và xem lại ván, lịch sử/PGN, ranked và câu đố, tiến trình/nhiệm vụ/cửa hàng, mạng xã hội, inbox, bảng xếp hạng/admin và hộp kết quả.
- Bổ sung kiểm thử tĩnh riêng cho các màn chuyên biệt; giữ nguyên module xử lý luật, engine và dữ liệu, tránh thay logic cờ chỉ để phục vụ thiết kế.
- QA cuối: test tĩnh 239/239; cú pháp 126/126 JS/MJS; 0 lỗi parse trong hai stylesheet. Full suite 241/245, 4 test không khởi chạy do thiếu dependency trong môi trường; không tuyên bố APK/device đã được nghiệm thu.

## v3.40.0 — kiểm tra UCI thật và khôi phục ván có kiểm chứng

- Thêm state machine kiểm tra khởi động Stockfish: chỉ đánh dấu sẵn sàng khi nhận `uciok` rồi `readyok`; `readyok` lạc chỗ và `bestmove` đến sớm không được tính là handshake thành công.
- Nút mã góc trên hiển thị thời gian khởi động trong tooltip, tên profile engine và thông báo lỗi cụ thể; trạng thái này phản ánh UCI handshake thật chứ không phải một nhãn giao diện đơn thuần.
- Bản lưu ván đang chơi dùng schema v3 kèm checksum FNV-1a, kiểm tra thời gian lưu, mode, nước đi, hướng quân, FEN, đồng hồ và kích thước snapshot trước khi replay. Snapshot v2 cũ vẫn được chấp nhận để khôi phục tương thích; nước đi vẫn được replay và FEN cuối phải khớp.
- Đồng bộ phiên bản package, giao diện, API health, cache Service Worker, tài liệu build và kiểm thử về 3.40.0. Sửa các kỳ vọng phiên bản cũ trong test để test hồi quy còn có thể chạy khi phát hành mới.
- Kiểm thử tĩnh 228/228 và cú pháp 121/121 đạt. Bộ test đầy đủ 230/234; bốn tệp test không khởi chạy do các dependency `chess.js`/`express` không có vì `npm install` bị timeout. Không tuyên bố build APK hoặc test thiết bị khi chưa thực hiện được.

## v3.38.0 — màn chọn người chơi, bàn công cụ gọn, kho câu đố và Cúp ViLa

- Đưa lựa chọn “Mới chơi / Đã hiểu luật” ra ngoài phần cài đặt thu gọn để hiển thị ngay trước bàn cờ trên điện thoại.
- Thanh bút chì được cố định trong luồng bố cục; bỏ lưu tọa độ kéo-thả cũ, gom mũi tên, khoanh ô, đổi màu và xóa vào cùng một cụm.
- Thu gọn thanh nút thao tác để nhãn không tràn và không bị kéo giãn trên màn hình nhỏ.
- Thêm biểu tượng mã Stockfish có trạng thái tải/sẵn sàng/lỗi; hiển thị tên phiên bản đầy đủ, trong đó đường tải Stockfish 10 vẫn dùng gói riêng và chuỗi fallback an toàn.
- Thêm bảng Cúp đấu trường, lưu bảng điểm giải vòng tròn và nhiệm vụ liên quan.
- Thêm mini-game Cờ ca-rô offline với bot tìm kiếm minimax tối ưu.
- Thêm kho câu đố Lichess đã xác minh, tải theo lô 10 đề và lưu tối đa 50 đề hợp lệ trên máy; không nhúng cả cơ sở dữ liệu nhiều triệu dòng vào APK.
- Cập nhật nhãn ký hiệu phân tích và thêm nhiệm vụ luyện tập/đấu trường/mini-game.

## v3.37.2 — sửa bố cục trận đấu Android

- Hiển thị bàn cờ rõ ngay cả trước khi bắt đầu; chuyển lựa chọn kinh nghiệm và nút bắt đầu thành thẻ nhỏ phía trên bàn cờ.
- Đặt lại vị trí cuộn khi chuyển màn hình để tránh thẻ đối thủ bị che bởi thanh đầu trang dính.
- Bổ sung vùng đệm nội dung phía dưới cho thanh thao tác cố định trên WebView di động.
- Tăng cache key Service Worker để lấy CSS/JS mới.

## v3.37.1 — sửa vòng đời Stockfish 10 trong Đấu trường

- Bổ sung hàng rào UCI `isready`/`readyok` trước mỗi tìm kiếm, reset `ucinewgame` đúng một lần mỗi ván thay vì mỗi nửa nước.
- Tách callback theo đúng Worker, tách từng dòng UCI nếu wrapper gộp nhiều dòng, huỷ Worker lỗi/timeout an toàn và cho phép khởi tạo lại ở lượt tiếp theo.
- Lỗi Stockfish 10 nay được ghi vào trạng thái Đấu trường trong khi nước dự phòng hợp lệ vẫn giúp ván đấu tiếp tục.
- Tăng phiên bản cache Service Worker lên 3.37.1 để tránh giữ mã cũ.
- Kiểm thử giả lập nhiều nước liên tiếp, vị trí sau bắt quân, dòng UCI gộp, timeout/khởi động lại và lỗi tạo Worker đồng bộ. Chưa tuyên bố engine thật đã chạy trên thiết bị Android trong môi trường này.

## v3.37.0 — Stockfish 10 Arena, review page tách riêng, thêm bộ quân

- Thêm đối thủ Stockfish 10 (gói npm alias `stockfish-10` / `10.0.2`) dùng worker UCI riêng để thi đấu ở Đấu trường, không tranh worker với Stockfish 19. Build Android bắt buộc kiểm tra script và giấy phép engine cũ trước khi đóng gói.
- Trang kết quả/xem lại được tách thành route riêng, chia bố cục bàn cờ phát lại và biến engine với biểu đồ lợi thế, biên bản theo cặp, nhãn nước đi, thống kê Trắng/Đen và tải PGN. Không tuyên bố dùng CAPS2 của Chess.com.
- Bổ sung 3 palette quân gốc VILA (Amethyst, Sapphire, Bronze) và 4 bộ quân được cấp phép từ Lichess (`kiwen-suwi`, `firi`, `totoy`, `shapes`), kèm credit/license khi build.
- Chốt phiên bản app/package/server/workflow ở 3.37.0; thêm test cho giao thức UCI giả lập, cổng build Stockfish 10, route review và gradient SVG.
- Các bài test tĩnh được chạy trong môi trường sửa đổi; `npm install`, test tích hợp phụ thuộc `chess.js`/`express`, Gradle và chạy trên Android vẫn phải được xác nhận qua GitHub Actions/thiết bị. Không đánh dấu APK đã build nếu chưa có artifact.


## v3.36.0 — Bot mạnh hơn, đánh giá minh bạch và xem lại có gợi ý

- Android build thêm Stockfish 19 Full NNUE cùng Lite và ASM-JS dự phòng; thiết bị có bộ nhớ/CPU phù hợp tự ưu tiên Full. Máy yếu giữ Lite để giảm rủi ro tràn bộ nhớ; vẫn có thể chọn Full thủ công.
- Mặc định nghĩ sâu hơn (độ sâu trần 30, đến 2,6 giây mỗi nước); cài đặt tùy chỉnh của người dùng được giữ nguyên khi cập nhật.
- Gỡ nhánh tự bỏ qua Stockfish bằng nước heuristic/ngẫu nhiên trong chế độ Elo thấp. Dưới ngưỡng UCI_Elo của Stockfish, engine dùng Skill Level 0–7 theo từng mức; số Elo thấp được ghi rõ là preset luyện tập, không phải xếp hạng benchmark.
- Phân tích toàn ván dùng ngân sách thời gian hợp lý hơn, ghi lại nước tốt nhất engine tìm thấy trước từng nước thật, lưu SAN gợi ý, độ sâu, điểm trước/sau và mức điểm đã mất. Biên bản nay ghép nước Trắng/Đen theo lượt, hỗ trợ nhảy tới thế cờ và tổng hợp nhãn riêng cho mỗi bên.
- Xử lý vị trí chiếu hết/hòa cuối ván và quy đổi mate score; không còn tự gắn nhãn “Thiên tài” chỉ vì một quân có thể bị ăn. Chỉ đánh dấu nước khai cuộc khi mức mất điểm vẫn nhỏ. Changelog ghi lại các thay đổi theo từng phiên bản; ZIP phát hành chỉ kèm báo cáo tương ứng với phiên bản hiện tại.
- Bỏ các báo cáo cũ khỏi ZIP phát hành; giữ bộ test hồi quy lịch sử cần thiết.


## v3.35.0 — sảnh Trang chủ, câu đố Lichess và trải nghiệm Android

- Sửa lỗi khởi động sai: ứng dụng nay mở ở **Trang chủ/Sảnh VILA**, không mở thẳng vào bàn cờ. “Chơi ngay” mới bắt đầu ván, còn tùy chỉnh ván đấu đi tới thiết lập.
- Thiết kế lại trang chủ thành dashboard có thẻ hồ sơ/Elo cục bộ, thanh lối tắt 5 chế độ, hero chơi cờ, thẻ câu đố ngày, các chế độ AI/câu đố/bài học/phân tích/online, khu luyện tập và mini-game. Điều hướng gọn, responsive và safe-area cho Android.
- Kết nối Lichess Daily Puzzle qua `/api/puzzle/daily` và câu đố huấn luyện lần lượt qua `/api/puzzle/next` với 5 mức độ; kiểm tra PGN và toàn bộ dòng giải bằng `chess.js`, cache theo ngày, timeout và phương án dự phòng ngoại tuyến. Câu đố nhiều nước tự chơi nước đáp của đối thủ và chuyển câu tiếp sau khi giải.
- Giữ/chỉnh sửa lại hồ sơ Đấu trường AI, trang phân tích/xem lại, kho khai cuộc, chơi offline bằng Stockfish, luồng online qua backend/Lichess. Giữ rõ khác biệt giữa engine thật và profile phong cách.
- Bổ sung test hồi quy ngăn việc quay lại mở trực tiếp vào bàn cờ, test dữ liệu câu đố và validate cache.
- Ghi lại giới hạn: nếu không có mạng, daily cache chỉ hoạt động sau lần tải thành công trước đó; nếu không có cache, tự dùng thế đố sinh ngoại tuyến. APK phải build trên GitHub Actions trước khi coi là phát hành.

## v3.34.0 — VILA mobile-first refresh

- Thay shell điều hướng bằng thanh chế độ 5 mục, menu chức năng gọn và bottom navigation dành cho Android. Bản 3.34.0 mở thẳng vào phòng chơi; đây là lỗi đã được sửa ở v3.35.0 để app khởi động tại Sảnh Trang chủ.
- Thiết kế lại Đấu trường AI theo bố cục dọc: hồ sơ hai bot, bàn cờ lớn, biên bản nước đi và thiết lập nâng cao có thể thu gọn. Giữ nguyên Stockfish, luật chess.js, chế độ đấu trận/giải vòng tròn và tải PGN.
- Thêm trung tâm Mini-game ngoại tuyến: Rubik 3×3 với trạng thái sticker thật, xoay mặt qua swipe/nút U/D/L/R/F/B, xáo trộn, hoàn tác và kiểm tra đã giải; thêm 2048 (phím/swipe/nút hướng), lật thẻ ghi nhớ và Trượt số 15 với xáo trộn bằng các bước hợp lệ.
- Câu đố Luyện tự do, Puzzle Rush và Sinh tồn tự động chuyển bài sau khi giải đúng; thử thách hằng ngày vẫn giữ nguyên chính sách một đề mỗi ngày.
- Thêm kiểm thử thuần Node cho xoay Rubik/đảo ngược/xáo trộn và logic 2048.
- Các bot phong cách vẫn là profile tìm kiếm VILA dựa trên engine cục bộ, không được quảng cáo là các engine neural độc lập. Cần hoàn tất npm test và GitHub Actions để xác nhận build APK trước phát hành.


## v3.33.0 — giao diện phòng đấu và độ trễ thao tác
- Làm mới phòng đấu theo tông xanh đêm, thẻ người chơi/đồng hồ, thanh chức năng riêng và thanh thao tác năm nút trên điện thoại.
- Giảm chi phí chọn quân: chỉ cập nhật các ô cờ đổi trạng thái; chỉ tính nước hợp lệ khi cử chỉ đã thành thao tác kéo.
- Dùng hình học bàn cờ đã cache để xác định ô thả, tránh hit-test DOM qua `elementFromPoint()` trong lúc kéo.
- Giữ các view/chức năng cũ; thêm nút hủy lựa chọn nước đi.
- Pin phiên bản cụ thể cho các dependency trực tiếp; ZIP phát hành hiện tại kèm báo cáo `TEST_REPORT_V3_37_0.md`; báo cáo của phiên bản cũ không được đóng gói lại.

## v3.32.0 — kiểm thử và độ tin cậy
- Sửa lỗi cú pháp trong `tests/visual-settings.test.js` khiến bộ kiểm thử tĩnh không thể khởi chạy đầy đủ.
- Chuẩn hóa kỳ vọng của test: `normalizeVisualSettings` chỉ giữ các tùy chọn giao diện mà module thực sự hỗ trợ; không giả định module này quản lý kiểu quân cờ.
- Đồng bộ phiên bản package, tiêu đề, API health, service-worker cache và nhận diện tác vụ tải tài nguyên sang 3.32.0.
- Thêm cổng kiểm tra cú pháp JavaScript toàn bộ `src`, `server`, `scripts`, `tests` vào quy trình nghiệm thu thủ công.
- Xác minh lại 169 test tĩnh và ghi rõ bốn test tích hợp bị chặn bởi dependency chưa cài trong môi trường.

## v3.31.0 — phòng đấu hợp nhất, thương hiệu mới và luyện tập mở rộng

- Tái thương hiệu toàn bộ giao diện web/Android thành **Cờ Vua ViLa**, icon mới và bảng màu xanh ngọc–vàng.
- Phòng đấu gom thao tác nhanh, thiết lập đối thủ, khai cuộc, danh sách nước và phân tích vào một màn hình.
- Sửa hoàn tác để khôi phục đúng clock snapshot trước nước đi; thêm Làm lại và lịch sử đồng hồ theo từng nửa nước đi.
- Có 18 profile bot offline cấu hình được chọn (bao gồm 6 profile mới: Mentor, Hunter, Sentinel, Strategist, Endgame Pro, Chaos), ngoài engine Stockfish; phân biệt rõ profile cấu hình với engine neural được train độc lập.
- Mở rộng lên 19 kiểu quân cờ: 14 kiểu nội bộ (1 PNG + 13 phối màu vector) và 5 bộ SVG nguồn mở được tải, kiểm tra giấy phép, đóng gói offline trong release GitHub.
- Thêm Luyện tự do, Đề hôm nay xác định theo ngày, Puzzle Rush 3 phút và Sinh tồn 3 mạng; chống kết quả Worker cũ ghi đè lượt hết giờ.
- Test: 166/167 bài kiểm thử tĩnh đạt; full suite 168/173 đạt (5 lỗi khởi tạo trong môi trường hiện tại).

## Lịch sử trước đó

Các thay đổi lịch sử từ các bản v3.x trước được gom vào các tệp nguồn, commit và kiểm thử hiện tại. Báo cáo audit/changelog lặp theo từng phiên bản cũ đã được loại khỏi ZIP để giảm nhiễu.

## 3.47.3 — Sửa test lỗi + nâng cấp chuột ảo
- Sửa test cũ `piece-artwork` (đang đòi thanh vẽ cố định, mâu thuẫn thiết kế v4 thanh vẽ nổi/kéo được).
- Chuột ảo: chạm nhanh trên bàn di = nhấn; chạm 2 lần rồi kéo = giữ/kéo quân; tăng tốc theo vận tốc ngón tay (chậm = chính xác, nhanh = đi xa); kẹp lại vị trí khi xoay/đổi kích thước màn hình; bỏ qua ngón tay thứ hai.

## 3.47.3 (tiếp) — Sửa bot Elo 500, nâng bot VILA, dựng lại Đấu trường AI
- **Bot Elo 500 (chế độ "luyện người mới") không chạy**: `scheduleBotMove` chỉ gọi Stockfish khi `mode === 'stockfish'`, nên chế độ `stockfish-beginner` không bao giờ nhận được nước đi. Đã sửa; thêm `resolveBotStrength` (luôn ép Elo 500, không phụ thuộc cài đặt đã lưu), watchdog và nước dự phòng cũng áp dụng cho chế độ này (dự phòng dùng bot yếu `rookie`/`mentor`, không dùng bot mạnh), tìm kiếm ngắn hơn ở Elo thấp, và trả lại cài đặt Stockfish cũ khi rời chế độ luyện người mới.
- **Bot VILA mạnh hơn**: mọi profile +1 độ sâu mặc định, ×1.5 số nút, ×1.3 thời gian; trần tìm kiếm 12 tầng / 600k nút; bảng chuyển vị lớn hơn; giảm sâu thêm cho nước yên lặng rất muộn (LMR); ngân sách `resolveOfflineSearchBudget` cao hơn; bot phong cách bám sát nước tốt nhất của Stockfish hơn (dung sai hẹp hơn).
- **Đấu trường AI dựng lại** (`src/arena-tournament.js`): 4 thể thức (1-1, vòng tròn, thách đấu, loại trực tiếp), 2–10 ván mỗi cặp, khai cuộc ghép cặp đổi màu, tạm dừng/tiếp tục, thanh tiến độ + thời gian còn lại, bảng xếp hạng trực tiếp (điểm, T/H/B, %, Elo tương đối) và bảng đối đầu, xử ván dài theo vật chất, PGN có Round/Date/Opening, tối đa 8 bot.

## Patch — Xem lại ván: gọn, phẳng, kiểu chess.com (review-chess)

- Trang xem lại ván bỏ tiêu đề dài, đoạn chú thích, chú giải ký hiệu, bảng "Số nửa nước/Engine" và các câu hướng dẫn thừa; ghi chú cách chấm điểm gập vào mục «ⓘ Cách chấm điểm».
- Giao diện phẳng cùng bảng màu chess.com như trang Phân tích/Câu đố (nút xanh có viền dưới, tab gạch chân, thẻ độ chính xác sáng/tối), gỡ nền kính và đổ bóng 3D cũ của riêng trang này (`src/review-chess.css`, lớp cuối của gói CSS).
- Khối rỗng tự ẩn khi chưa có dữ liệu (biểu đồ, giai đoạn, bảng chất lượng); nút «Phân tích toàn ván» là nút chính, «Dừng» chỉ hiện khi đang chạy.
- Trang «Từng nước»: ẩn thẻ kết quả để bàn cờ lên đầu, 4 phím điều hướng đều nhau, thẻ nhận xét một dòng, danh sách nước đi gọn không số eval.
- Cache service worker `chessplus-v3.69.1-fix6`.
