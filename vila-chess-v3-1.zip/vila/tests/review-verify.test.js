import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { applyVerifiedEvaluations, judgeMoveFromEvals, rowWinDropPct, selectPositionsToVerify } from '../src/review-verify.js';
import { resolveReviewPlan, resolveReviewMoveTimeMs } from '../src/engine-budgets.js';

const row = (ply, mover, before, after, extra = {}) => ({
  ply, mover, scoreBeforeWhiteCp: before, scoreWhiteCp: after, playedUci: `m${ply}`, bestMoveUci: extra.best ?? `x${ply}`,
  moveWasBest: false, bookMove: false, judgement: { key: 'good' }, bestMoveDepth: 12, engineDepth: 12, ...extra
});

test('rowWinDropPct is measured from the mover point of view and never negative', () => {
  assert.ok(rowWinDropPct(row(1, 'w', 0, -300)) > 20);
  assert.ok(rowWinDropPct(row(2, 'b', 0, 300)) > 20);
  assert.equal(rowWinDropPct(row(3, 'w', 0, 200)), 0);
  assert.equal(rowWinDropPct(row(4, 'w', null, 10)), null);
});

test('selectPositionsToVerify picks both positions around doubtful moves and skips best/book/clean moves', () => {
  const rows = [
    { ply: 0, scoreWhiteCp: 20 },
    row(1, 'w', 20, 18, { moveWasBest: true, best: 'm1' }),
    row(2, 'b', 18, 40),                    // tiny drop: not worth a re-search
    row(3, 'w', 40, -60),                   // real drop
    row(4, 'b', -60, 120, { bookMove: true }),
    row(5, 'w', 120, 119, { judgement: { key: 'brilliant' }, moveWasBest: true, best: 'm5' })
  ];
  assert.deepEqual(selectPositionsToVerify(rows, { maxFraction: 1, maxPositions: 99 }), [2, 3, 4, 5]);
});

test('selectPositionsToVerify honours the time cap and prefers the biggest drops', () => {
  const rows = [{ ply: 0, scoreWhiteCp: 0 }];
  for (let ply = 1; ply <= 30; ply += 1) rows.push(row(ply, ply % 2 ? 'w' : 'b', 0, ply % 2 ? -40 - ply * 5 : 40 + ply * 5));
  const picked = selectPositionsToVerify(rows, { maxFraction: 0.2, maxPositions: 99 });
  assert.ok(picked.length <= Math.ceil(31 * 0.2));
  assert.ok(picked.includes(29) || picked.includes(30), 'largest drop must be among the picks');
  assert.deepEqual(selectPositionsToVerify([], {}), []);
});

test('judgeMoveFromEvals gives Tốt nhất for the engine move and a blunder for a big drop', () => {
  const best = judgeMoveFromEvals({ scoreWhiteCp: 30, bestUci: 'e2e4', depth: 20 }, { scoreWhiteCp: 28, depth: 20 }, { mover: 'w', uci: 'e2e4' });
  assert.equal(best.judgement.key, 'best');
  const bad = judgeMoveFromEvals({ scoreWhiteCp: 30, bestUci: 'e2e4', depth: 20 }, { scoreWhiteCp: -400, depth: 20 }, { mover: 'w', uci: 'a2a3' });
  assert.equal(bad.judgement.key, 'blunder');
  assert.equal(judgeMoveFromEvals({ scoreWhiteCp: null }, { scoreWhiteCp: 0 }, { mover: 'w' }).judgement, null);
});

test('applyVerifiedEvaluations removes a label caused by a shallow-search artefact and re-judges the neighbour', () => {
  // Shallow pass thought the position after ply 3 was -250 for White (fake blunder); deeper search says -20.
  const rows = [
    { ply: 0, scoreWhiteCp: 25 },
    row(1, 'w', 25, 20, { judgement: { key: 'good' } }),
    row(2, 'b', 20, 22, { judgement: { key: 'good' } }),
    row(3, 'w', 22, -250, { judgement: { key: 'blunder' }, best: 'g1f3' }),
    row(4, 'b', -250, -240, { judgement: { key: 'good' }, best: 'b8c6' })
  ];
  const verified = new Map([
    [2, { scoreWhiteCp: 22, depth: 24, bestUci: 'g1f3', secondWhiteCp: -90, pv: ['g1f3', 'b8c6'] }],
    [3, { scoreWhiteCp: -20, depth: 24, bestUci: 'b8c6', pv: ['b8c6'] }]
  ]);
  const sanCalls = [];
  const changed = applyVerifiedEvaluations(rows, verified, { fenAt: ply => `fen${ply}`, uciPvToSan: (fen, pv) => { sanCalls.push([fen, pv.join(' ')]); return pv.map(m => m.toUpperCase()); } });
  assert.ok(changed >= 1);
  assert.notEqual(rows[3].judgement.key, 'blunder');
  assert.equal(rows[3].scoreWhiteCp, -20);
  assert.equal(rows[4].scoreBeforeWhiteCp, -20, 'next row must share the verified score');
  assert.equal(rows[3].bestMoveUci, 'g1f3');
  assert.deepEqual(rows[3].bestLineSan, ['G1F3', 'B8C6']);
  assert.ok(sanCalls.some(([fen]) => fen === 'fen2'), 'SAN of the best line is rebuilt from the position before the move');
  assert.equal(rows[1].judgement.key, 'good', 'untouched rows are left alone');
});

test('applyVerifiedEvaluations is a no-op without verified data', () => {
  const rows = [{ ply: 0, scoreWhiteCp: 0 }, row(1, 'w', 0, -30)];
  assert.equal(applyVerifiedEvaluations(rows, new Map()), 0);
  assert.equal(applyVerifiedEvaluations(null, new Map()), 0);
});

test('resolveReviewPlan: quick first pass, deeper verify pass, bounded', () => {
  for (const reviewQuality of ['fast', 'standard', 'deep', 'max']) {
    const plan = resolveReviewPlan({ reviewQuality });
    assert.ok(plan.firstMs >= 400 && plan.firstMs <= 3600);
    assert.ok(plan.verifyMs > plan.firstMs * 2 && plan.verifyMs <= 12000);
    assert.ok(plan.firstMs < resolveReviewMoveTimeMs({ reviewQuality }));
  }
});

test('main.js wires the verification phase before rows are built and keeps the first pass intact', () => {
  const src = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(src, /from '\.\/review-verify\.js'/);
  assert.match(src, /function startReviewVerification\(/);
  assert.match(src, /function finishVerifyPosition\(/);
  assert.match(src, /function endReviewVerification\(/);
  const finish = src.indexOf('function finishReviewPosition(');
  const branch = src.indexOf('if (session.verify?.active) { finishVerifyPosition(', finish);
  const rowsBuilt = src.indexOf('completedReviewRows.push({', finish);
  assert.ok(branch > finish && branch < rowsBuilt, 'verify branch must run before first-pass rows are appended');
  assert.match(src, /sacrifice: Boolean\(sacrifice\), secondBeforeWhiteCp/);
  assert.match(src, /reviewVerifyEnabled\(reviewSession\) && startReviewVerification\(\)/);
});
