import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { classifyCentipawnLoss, reviewSymbolDescription, MOVE_QUALITY_LABELS } from '../src/game-review.js';
import { layers, buildProfessionalCss } from '../scripts/build-professional-css.mjs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('move-quality wording is identical everywhere (no Chưa chuẩn, Chưa chính xác or bare Blunder)', () => {
  assert.equal(classifyCentipawnLoss(40).label, MOVE_QUALITY_LABELS.inaccuracy);
  assert.equal(classifyCentipawnLoss(400).label, MOVE_QUALITY_LABELS.blunder);
  assert.equal(MOVE_QUALITY_LABELS.inaccuracy, 'Thiếu chính xác');
  assert.equal(MOVE_QUALITY_LABELS.blunder, 'Sai lầm nghiêm trọng');
  assert.match(reviewSymbolDescription('blunder'), /^Sai lầm nghiêm trọng/);
  for (const file of ['src/main.js', 'src/game-review.js', 'README.md']) {
    const text = read(file);
    assert.doesNotMatch(text, /Chưa chuẩn|Chưa chính xác/, file);
  }
  assert.doesNotMatch(read('src/game-review.js'), /label: 'Blunder'/);
});

