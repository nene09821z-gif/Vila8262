import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

test('main.js wires chess.com UX module', () => {
  const main = read('src/main.js');
  assert.match(main, /from '\.\/chesscom-ux\.js'/);
  assert.match(main, /vila-professional\.css/);
  assert.match(main, /buildReviewDashboard/);
  assert.match(main, /botThinkDelayMs/);
  assert.match(main, /BOT_ELO_PRESETS/);
  assert.match(main, /puzzleStreakLabel/);
  assert.match(main, /LESSON_CATALOG/);
  assert.match(main, /clubHomeMarkup/);
  assert.match(main, /boardThemeSwatches|theme-swatch|BOARD_THEME_CATALOG/);
  assert.match(main, /renderOpeningExplorerPanel|openingExplorerContinuations/);
  assert.match(main, /currentView === 'lessons'|currentView === 'club'/);
});

test('index.html exposes club navigation', () => {
  const html = read('index.html');
  assert.match(html, /data-view="club"/);
  assert.match(html, /data-view="openings"/);
  assert.match(html, /data-view="friends"/);
});

test('professional runtime bundle ships specialist motion and action-bar rules', () => {
  const css = read('src/vila-professional.css');
  assert.match(css, /match-action-bar/);
  assert.match(css, /review-dashboard/);
  assert.match(css, /opening-explorer/);
  assert.match(css, /in-check/);
  assert.match(css, /lesson-grid/);
  assert.match(css, /bot-elo-chip/);
});

test('home one-tap block is removed and play opening explorer is wired', () => {
  const main = read('src/main.js');
  assert.doesNotMatch(main, /class="home-one-tap"/);
  assert.doesNotMatch(main, /data-home-fold|home-fold-head/);
  assert.match(main, /openingExplorerPanel/);
  assert.match(main, /renderOpeningExplorerPanel/);
});


test('Professional stylesheet is the single runtime style entrypoint', () => {
  const main = read('src/main.js');
  assert.match(main, /import '\.\/vila-professional\.css';/);
  assert.doesNotMatch(main, /vila-commercial\.css|vila-atelier\.css|vila-polish\.css|header-chesscom\.css/);
  const css = read('src/vila-professional.css');
  assert.match(css, /--vila-accent/);
  assert.match(css, /home-one-tap/);
  assert.match(css, /primary-btn/);
});
