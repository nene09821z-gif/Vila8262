import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createKeyedMutex } from '../server/ranked-chess.js';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const tick = (ms = 0) => new Promise(resolve => setTimeout(resolve, ms));

test('keyed mutex runs tasks for one key strictly one after another, in arrival order', async () => {
  const run = createKeyedMutex();
  const log = [];
  const task = (name, ms) => async () => { log.push(`start ${name}`); await tick(ms); log.push(`end ${name}`); return name; };
  const results = await Promise.all([run('m1', task('a', 15)), run('m1', task('b', 1)), run('m1', task('c', 5))]);
  assert.deepEqual(results, ['a', 'b', 'c']);
  assert.deepEqual(log, ['start a', 'end a', 'start b', 'end b', 'start c', 'end c']);
});

test('keyed mutex lets different matches run in parallel', async () => {
  const run = createKeyedMutex();
  const log = [];
  const slow = run('m1', async () => { log.push('m1 start'); await tick(20); log.push('m1 end'); });
  const fast = run('m2', async () => { log.push('m2 start'); await tick(1); log.push('m2 end'); });
  await Promise.all([slow, fast]);
  assert.deepEqual(log.slice(0, 2), ['m1 start', 'm2 start']);
  assert.ok(log.indexOf('m2 end') < log.indexOf('m1 end'));
});

test('a failing task rejects its own caller but never blocks the next one', async () => {
  const run = createKeyedMutex();
  const failing = run('m1', async () => { throw new Error('boom'); });
  const next = run('m1', async () => 'still runs');
  await assert.rejects(failing, /boom/);
  assert.equal(await next, 'still runs');
  assert.equal(await run('m1', () => 'sync task works too'), 'sync task works too');
});

test('double-submitted move: without the lock both pass the ply check, with it only one does', async () => {
  // Mirrors the /move handler: check expectedPly, await (audit/persist), then append the move.
  const makeMatch = () => ({ moves: [] });
  const submit = async (match, expectedPly) => {
    if (expectedPly !== match.moves.length) return 'rejected';
    await tick(2); // the handler awaits audit() between validation and the write
    match.moves.push('e4');
    return 'accepted';
  };
  const unsafe = makeMatch();
  const unsafeResults = await Promise.all([submit(unsafe, 0), submit(unsafe, 0)]);
  assert.deepEqual(unsafeResults, ['accepted', 'accepted'], 'documents the original race');
  assert.equal(unsafe.moves.length, 2);

  const run = createKeyedMutex();
  const safe = makeMatch();
  const safeResults = await Promise.all([run('m', () => submit(safe, 0)), run('m', () => submit(safe, 0))]);
  assert.deepEqual(safeResults, ['accepted', 'rejected']);
  assert.equal(safe.moves.length, 1);
});

test('keyed mutex forgets idle keys so a long-running server does not leak memory', async () => {
  const run = createKeyedMutex();
  for (let i = 0; i < 200; i += 1) await run(`match-${i}`, async () => i);
  // A key that finished must behave like a brand-new key.
  assert.equal(await run('match-0', async () => 'fresh'), 'fresh');
});

test('Node backend and Cloudflare Worker end ranked games through the same shared rules', () => {
  for (const [name, path] of [['node', 'server/social.js'], ['cloudflare', 'cloudflare/src/index.js']]) {
    const source = read(path);
    assert.match(source, /import \{ planRankedFinish \} from '\.\.?\/(?:\.\.\/)?src\/game-rules\.js'/, `${name} imports the shared plan`);
    assert.match(source, /planRankedFinish\(\{ result, reason, plyCount: \(match\.moves \|\| \[\]\)\.length, fen: match\.fen \|\| match\.startFen \}\)/, `${name} plans the finish from moves and fen`);
    assert.match(source, /plan\.status === 'aborted'/, `${name} handles aborted games`);
    assert.match(source, /match\.eloChanges = \{\};/, `${name} leaves ratings untouched when aborting`);
    assert.match(source, /match\.status === 'finished' \|\| match\.status === 'aborted'/, `${name} keeps aborted games visible to the opponent's next poll`);
    assert.doesNotMatch(source, /function\s+\w*insufficient\w*\s*\(/i, `${name} must not carry its own copy of the insufficient-material rule`);
  }
});

test('Node backend serialises every route that mutates an active ranked match', () => {
  const source = read('server/social.js');
  assert.match(source, /const withRankedMatchLock = createKeyedMutex\(\);/);
  for (const route of ['move', 'resign', 'abandon']) {
    assert.match(source, new RegExp(`router\\.post\\('/ranked/matches/:matchId/${route}', rankedLimiter, requireAuth, \\(req, res\\) => withRankedMatchLock\\(req\\.params\\.matchId, async \\(\\) => \\{`), `${route} is locked`);
  }
  assert.match(source, /if \(active\) return withRankedMatchLock\(active\.id, async \(\) => \{/, 'status polling shares the same lock');
  assert.match(source, /if \(active\.status !== 'active'\) return res\.json/, 'status re-checks the match inside the lock');
});

test('the app uses the shared flag rule for local games and shows aborted ranked games honestly', () => {
  const main = read('src/main.js');
  assert.match(main, /import \{ resolveFlagResult \} from '\.\/game-rules\.js';/);
  assert.match(main, /resolveFlagResult\(game\.fen\(\), clockFlagged\)/);
  assert.match(main, /match\.status === 'aborted'/);
  assert.match(main, /Ván bị huỷ vì chưa đủ hai nước đi/);
  assert.match(main, /timeout_vs_insufficient/);
  // An aborted game must never be presented as a loss.
  assert.match(main, /resultTitle = aborted \? 'VÁN BỊ HUỶ'/);
});
