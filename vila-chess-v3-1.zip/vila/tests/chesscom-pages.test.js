import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { PUZZLE_MODES, PUZZLE_DIFFICULTIES, formatCount, renderPuzzlePrompt } from '../src/pages/puzzle-page.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');

test('puzzle page exposes the five chess.com modes and five difficulty levels', () => {
  assert.deepEqual(PUZZLE_MODES.map(mode => mode.id), ['classic', 'daily', 'rush', 'survival', 'custom']);
  assert.equal(PUZZLE_DIFFICULTIES.length, 5);
});

test('puzzle helpers format counts and never show the solution in the prompt', () => {
  assert.equal(formatCount(1500), '1500');
  assert.equal(formatCount(120000), '120k');
  assert.equal(formatCount(1_200_000), '1.2tr');
  const html = renderPuzzlePrompt({ status: 'ready', turn: 'b', statusChip: 'Lượt 1' });
  assert.match(html, /Lượt Đen/);
  assert.doesNotMatch(html, /solutionUci|data-solution/);
});

test('the chess.com page stylesheet is the last layer of the generated bundle and fits phones', () => {
  const layers = read('../scripts/build-professional-css.mjs');
  assert.ok(layers.lastIndexOf('chesscom-pages.css') > layers.lastIndexOf('vila-professional-theme.css'));
  const bundle = read('../src/vila-professional.css');
  assert.ok(bundle.includes('.cp-modes') && !bundle.includes('.ap-bar'));
});
