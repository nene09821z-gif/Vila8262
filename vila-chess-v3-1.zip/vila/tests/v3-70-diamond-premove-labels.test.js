import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  DAY_MS, DIAMOND_PRICE_VND, DIAMOND_DURATION_DAYS, PAID_PLANS, effectivePlan, grantPlan, revokePlan,
  diamondDaysLeft, planStatusLabel, entitlementForClient, normalizeEntitlement
} from '../src/plans.js';
import { planPurchaseUi } from '../src/billing-client.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const main = read('src/main.js');
const worker = read('cloudflare/src/index.js');
const node = read('server/social.js');
const NOW = Date.UTC(2026, 10, 1);

test('Diamond plan outranks Premium and Pro, lasts one year and stacks on renewal', () => {
  assert.ok(PAID_PLANS.includes('diamond'));
  assert.equal(DIAMOND_DURATION_DAYS, 365);
  assert.ok(DIAMOND_PRICE_VND > 0);
  const pro = grantPlan({}, 'pro', NOW);
  const dia = grantPlan(pro, 'diamond', NOW);
  assert.equal(effectivePlan(dia, NOW), 'diamond');
  assert.equal(diamondDaysLeft(dia, NOW), 365);
  assert.equal(diamondDaysLeft(grantPlan(dia, 'diamond', NOW), NOW), 730, 'renewal adds on top of the remaining time');
  assert.notEqual(effectivePlan(dia, NOW + 400 * DAY_MS), 'diamond');
  assert.match(planStatusLabel(dia, NOW), /Kim Cương/);
  assert.equal(entitlementForClient(dia, NOW).plan, 'diamond');
  assert.equal(effectivePlan(revokePlan(dia, 'diamond'), NOW), 'pro');
  assert.equal(normalizeEntitlement({ diamondExpiresAt: 'junk' }).diamondExpiresAt, null);
});

test('purchase UI always offers Diamond (buy or renew)', () => {
  assert.equal(planPurchaseUi('free').diamond.show, true);
  assert.match(planPurchaseUi('diamond', 0, 5).diamond.label, /Gia hạn/);
  assert.equal(planPurchaseUi('diamond', 0, 5).diamond.expiringSoon, true);
  assert.equal(planPurchaseUi('diamond', 0, 200).diamond.expiringSoon, false);
});

test('both backends accept and confirm diamond purchase requests with a fixed price', () => {
  for (const src of [worker, node]) {
    assert.match(src, /diamond_1y/);
    assert.match(src, /confirm-diamond/);
    assert.match(src, /DIAMOND_PRICE_VND/);
    assert.match(src, /purchase_request_diamond_approved/);
  }
});

test('Diamond UI: plan card, admin grant, chat assistant and 3D tier badge', () => {
  assert.match(main, /data-plan-request="diamond"/);
  assert.match(main, /data-admin-plan="diamond"/);
  assert.match(main, /data-chat-plan-request="diamond"/);
  assert.match(main, /tier-badge label-3d tier-/);
});

test('ranked online board supports chess.com-style premove (queue, red squares, cancel, auto-fire)', () => {
  for (const token of ['rankedPremoveWindow', 'queueRankedPremove', 'rankedFirePremove', 'clearRankedPremoves', 'scheduleRankedPremoveFire', 'rankedPremoveChip']) {
    assert.ok(main.includes(token), `missing ${token}`);
  }
  assert.match(main, /takeNextPremove\(rankedChess/);
  assert.match(main, /getPremoveLegalMoves\(rankedChess/);
  assert.match(main, /contextmenu|button === 2/);
  assert.match(main, /expectedPly/);
});

test('3D label system covers review badges, board coordinates and premove squares', () => {
  const css = read('src/label-3d.css');
  for (const token of ['.label-3d', '.tier-diamond', '.rv-coord', '.coord', 'premove-from', 'premove-to', 'premove-ghost']) {
    assert.ok(css.includes(token), `label-3d.css must style ${token}`);
  }
  assert.match(read('scripts/build-professional-css.mjs'), /'label-3d\.css'/);
  assert.ok(read('src/vila-professional.css').includes('.label-3d'), 'bundle contains the new layer');
});

test('private chat redesign keeps the ids the app wires up and adds search + mobile single-pane', () => {
  for (const id of ['chatConversationList', 'chatRoomHeader', 'chatAdminPlanPanel', 'chatMessageList', 'chatSendForm', 'chatMessageText', 'chatSendButton', 'chatSearch', 'chatLayout']) {
    assert.ok(main.includes(`id="${id}"`), `chat must keep #${id}`);
  }
  const css = read('src/chat-direct.css');
  assert.match(css, /is-room-open/);
  assert.match(css, /body \.chat-page/);
  assert.match(read('scripts/build-professional-css.mjs'), /'chat-direct\.css'/);
});
