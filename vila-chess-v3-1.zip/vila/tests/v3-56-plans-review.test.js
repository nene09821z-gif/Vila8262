import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  DAY_MS, FREE_REVIEW_LIMIT, normalizeEntitlement, effectivePlan, reviewAccess, consumeFreeReview,
  grantPlan, revokePlan, daysLeft, planStatusLabel, entitlementForClient
} from '../src/plans.js';
import { classifyMoveQuality, computeWinPercentAccuracy, moveAccuracyFromWinPercents } from '../src/game-review.js';
import { computeGameAccuracy, buildReviewDashboard } from '../src/chesscom-ux.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const NOW = Date.UTC(2026, 9, 24);

test('free players get exactly one review, and that game stays viewable', () => {
  assert.equal(FREE_REVIEW_LIMIT, 1);
  let ent = normalizeEntitlement({});
  const first = reviewAccess(ent, 'g1', NOW);
  assert.deepEqual([first.allowed, first.reason, first.consumesFree], [true, 'free-trial', true]);
  ent = consumeFreeReview(ent, 'g1');
  assert.equal(reviewAccess(ent, 'g1', NOW).reason, 'free-same-game');
  const other = reviewAccess(ent, 'g2', NOW);
  assert.deepEqual([other.allowed, other.reason], [false, 'limit']);
  assert.equal(consumeFreeReview(ent, 'g1').freeReviewsUsed, 1, 'consuming twice for the same game is idempotent');
  assert.equal(reviewAccess(ent, '', NOW).allowed, false, 'an unnamed game cannot reuse the free slot');
});

test('Pro lasts 365 days, renewals stack, expiry falls back to free', () => {
  const pro = grantPlan({}, 'pro', NOW);
  assert.equal(pro.proExpiresAt, NOW + 365 * DAY_MS);
  assert.equal(effectivePlan(pro, NOW + 364 * DAY_MS), 'pro');
  assert.equal(effectivePlan(pro, pro.proExpiresAt), 'free', 'expires at the exact instant');
  assert.equal(daysLeft(pro, NOW), 365);
  const renewed = grantPlan(pro, 'pro', NOW + 100 * DAY_MS);
  assert.equal(renewed.proExpiresAt, NOW + 730 * DAY_MS, 'renewing while active adds a full year on top');
  const late = grantPlan(pro, 'pro', NOW + 400 * DAY_MS);
  assert.equal(late.proExpiresAt, NOW + 765 * DAY_MS, 'renewing after expiry starts from the renewal day');
  assert.equal(reviewAccess(pro, 'x', NOW).allowed, true);
  assert.equal(reviewAccess(pro, 'x', NOW + 366 * DAY_MS).reason, 'free-trial');
});

test('Premium is lifetime and a Pro grant or expiry never downgrades it', () => {
  let ent = grantPlan({}, 'premium', NOW);
  assert.equal(effectivePlan(ent, NOW + 50 * 365 * DAY_MS), 'premium');
  ent = grantPlan(ent, 'pro', NOW);
  assert.equal(effectivePlan(ent, NOW + 5 * 365 * DAY_MS), 'premium');
  assert.equal(planStatusLabel(ent, NOW), 'Premium · trọn đời');
  const revoked = revokePlan(ent, 'all');
  assert.equal(effectivePlan(revoked, NOW), 'free');
  assert.throws(() => grantPlan({}, 'gold'), /không hợp lệ/);
});

test('entitlement parsing tolerates junk and revoke keeps the used free review', () => {
  assert.deepEqual(normalizeEntitlement('garbage'), { premium: false, premiumExpiresAt: null, proExpiresAt: null, diamondExpiresAt: null, freeReviewsUsed: 0, freeReviewGameId: '' });
  assert.equal(normalizeEntitlement({ proExpiresAt: 'not a date' }).proExpiresAt, null);
  assert.equal(normalizeEntitlement({ freeReviewsUsed: -5 }).freeReviewsUsed, 0);
  const used = consumeFreeReview({}, 'g1');
  assert.equal(revokePlan(grantPlan(used, 'pro', NOW), 'pro').freeReviewsUsed, 1);
  const client = entitlementForClient(grantPlan({}, 'pro', NOW), NOW);
  assert.equal(client.plan, 'pro');
  assert.match(client.label, /Pro · còn 365 ngày/);
});

test('the engine\'s own best move is never labelled a mistake because of search-depth noise', () => {
  assert.equal(classifyMoveQuality({ moverBeforeCp: 150, moverAfterCp: 20, isBest: true }).key, 'best');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 150, moverAfterCp: 20, isBest: false }).key, 'mistake');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 400, moverAfterCp: -50, isBest: false }).key, 'missed-win');
  assert.equal(classifyMoveQuality({ moverBeforeCp: 0, moverAfterCp: -400, isBest: false }).key, 'blunder');
});

test('win-percent accuracy rewards clean play and punishes a blunder on the right side', () => {
  const mk = (ply, mover, before, after) => ({ ply, mover, scoreBeforeWhiteCp: before, scoreWhiteCp: after });
  const clean = computeWinPercentAccuracy([mk(1, 'w', 20, 22), mk(2, 'b', 22, 20), mk(3, 'w', 20, 25), mk(4, 'b', 25, 24)]);
  assert.ok(clean.white >= 99 && clean.black >= 99);
  const blunder = computeWinPercentAccuracy([mk(1, 'w', 20, 22), mk(2, 'b', 22, 400), mk(3, 'w', 400, 390), mk(4, 'b', 390, 380)]);
  assert.ok(blunder.black < 60 && blunder.white > 95, `black blundered: ${JSON.stringify(blunder)}`);
  assert.equal(moveAccuracyFromWinPercents(50, 55), 100);
  assert.ok(moveAccuracyFromWinPercents(80, 20) < 15);
  assert.equal(computeWinPercentAccuracy([]).white, null);
  assert.equal(computeWinPercentAccuracy([{ ply: 1, mover: 'w', scoreBeforeWhiteCp: null, scoreWhiteCp: 10 }]).white, null);
});

test('accuracy cards are no longer blank: rows carry `mover`, not `color`', () => {
  const rows = [{ ply: 1, mover: 'w', judgement: { key: 'best' } }, { ply: 2, mover: 'b', judgement: { key: 'blunder' } }];
  const label = computeGameAccuracy(rows);
  assert.equal(label.white, 100);
  assert.equal(label.black, 0);
  const scored = [{ ply: 1, mover: 'w', scoreBeforeWhiteCp: 20, scoreWhiteCp: 20, judgement: { key: 'best' } }];
  assert.equal(buildReviewDashboard(scored).accuracy.method, 'win-percent');
  assert.equal(buildReviewDashboard(rows).accuracy.method, 'label-weights');
});

test('wiring: review is gated, bound lines ignored, plans routed, server routes exist', () => {
  const main = read('src/main.js');
  assert.match(main, /requestReviewAccess\(\)\.then\(allowed => \{ if \(allowed\) runFullGameReview\(\); \}\)/);
  assert.match(main, /function runFullGameReview\(\)/);
  assert.match(main, /lowerbound\|upperbound/);
  assert.match(main, /else if \(currentView === 'plans'\) root\.innerHTML = renderPlansView\(\)/);
  assert.match(main, /data-admin-plan="premium"/);
  assert.match(read('index.html'), /data-view="plans"/);
  const server = read('server/social.js');
  assert.match(server, /router\.post\('\/me\/review-access', requireAuth/);
  assert.match(server, /router\.patch\('\/admin\/users\/:id\/plan', requireAuth, requireAdmin/);
  assert.match(server, /entitlement: entitlementForClient\(user\.entitlement\)/);
  assert.match(server, /res\.status\(access\.allowed \? 200 : 402\)/);
});
