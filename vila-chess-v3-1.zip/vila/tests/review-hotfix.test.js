import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { PHASE_ICONS } from '../src/review-screen.js';
import { looksLowEnd } from '../src/perf-governor.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('reviewKeyboardShortcutsBound is declared before use (fixes "is not defined" on review screen)', () => {
  const decl = main.search(/let reviewKeyboardShortcutsBound\s*=\s*false/);
  const use = main.indexOf('if (!reviewKeyboardShortcutsBound)');
  assert.ok(decl >= 0 && use > decl);
});

test('phase icons are inline SVG, not platform glyph characters', () => {
  for (const key of ['opening', 'middlegame', 'endgame']) {
    assert.match(PHASE_ICONS[key], /^<svg[\s\S]*<path/);
    assert.doesNotMatch(PHASE_ICONS[key], /[♔-♟]/);
  }
  const src = fs.readFileSync(new URL('../src/review-screen.js', import.meta.url), 'utf8');
  assert.doesNotMatch(src, /\['opening', 'Khai cuộc', '[♔-♟]'\]/);
});

test('phones and weak devices start in the lite performance tier', () => {
  const win = (extra = {}, coarse = true) => ({ navigator: { deviceMemory: 4, hardwareConcurrency: 8, ...extra }, matchMedia: q => ({ matches: q.includes('coarse') ? coarse : false }) });
  assert.equal(looksLowEnd(win()), true);
  assert.equal(looksLowEnd(win({ deviceMemory: 16, hardwareConcurrency: 16 }, false)), false);
  assert.equal(looksLowEnd(null), false);
});
