import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  REVIEW_TALLY, tallyMoves, badgeFor, phaseGrade, resultView, evalChartMarkup, summaryMarkup, replayMarkup,
  buildMovePairs, moveListMarkup, bannerFor, hintFor, landingMarkup
} from '../src/review-screen.js';

const read = file => fs.readFileSync(new URL('../' + file, import.meta.url), 'utf8');
const rows = [
  { ply: 1, mover: 'w', judgement: { key: 'brilliant' }, scoreWhiteCp: 20 },
  { ply: 2, mover: 'b', judgement: { key: 'inaccuracy' }, scoreWhiteCp: 60 },
  { ply: 3, mover: 'w', judgement: { key: 'best' }, scoreWhiteCp: 90 },
  { ply: 4, mover: 'b', judgement: { key: 'blunder' }, scoreWhiteCp: 400 },
  { ply: 5, mover: 'w', judgement: { key: 'book' }, scoreWhiteCp: 420 },
  { ply: 6, mover: 'w', judgement: { key: 'missed-win' }, scoreWhiteCp: 30 }
];

test('tally has the eight rows of the design in order', () => {
  assert.deepEqual(REVIEW_TALLY.map(r => r.label), [
    'Nước đi xuất sắc', 'Nước đi hay', 'Nước đi tốt nhất', 'Nước đi tốt',
    'Nước đi không rõ', 'Nước đi sai', 'Nước đi mắc lỗi', 'Nước đi bỏ lỡ'
  ]);
});

test('tallyMoves counts per side and folds book moves into "tốt nhất"', () => {
  const white = tallyMoves(rows, 'w');
  assert.equal(white.brilliant, 1);
  assert.equal(white.best, 2); // best + book
  assert.equal(white.miss, 1);
  const black = tallyMoves(rows, 'b');
  assert.equal(black.unclear, 1);
  assert.equal(black.blunder, 1);
  assert.equal(black.brilliant, 0);
});

test('phase grades and result view follow the viewer side', () => {
  assert.equal(phaseGrade(95).label, 'Tuyệt vời');
  assert.equal(phaseGrade(92).label, 'Xuất sắc');
  assert.equal(phaseGrade(88).label, 'Tốt');
  assert.equal(phaseGrade(null).label, '—');
  assert.equal(resultView({ token: '1-0', side: 'w' }).pill, 'Bạn thắng!');
  assert.equal(resultView({ token: '0-1', side: 'b' }).score, '1 - 0');
  assert.equal(resultView({ token: '1-0', side: 'b' }).pill, 'Bạn thua');
  assert.equal(resultView({ token: '1/2-1/2', side: 'w' }).pill, 'Hòa');
  assert.equal(resultView({ token: '1-0', side: 'w', human: false }).pill, 'Trắng thắng!');
});

test('every classification key has a badge', () => {
  for (const key of ['brilliant', 'great', 'best', 'excellent', 'good', 'book', 'inaccuracy', 'mistake', 'blunder', 'missed-win']) {
    assert.ok(badgeFor(key), key);
  }
  assert.equal(badgeFor('nonsense'), null);
});

test('eval chart draws axes, a green area and an end dot; flips for black', () => {
  const html = evalChartMarkup(rows, 'w');
  assert.match(html, /\+1\.0/); assert.match(html, /-1\.0/);
  assert.match(html, /rv2-chart-dot/);
  assert.match(evalChartMarkup([], 'w'), /is-empty/);
  assert.notEqual(evalChartMarkup(rows, 'w'), evalChartMarkup(rows, 'b'));
});

test('summary matches the design: brand, title, score, accuracy, tally, phases, CTA', () => {
  const html = summaryMarkup({
    result: { token: '1-0', side: 'w', human: true }, names: { you: 'tư duy k14', opp: 'ChessMaster' },
    accuracy: { you: 91.8, opp: 84.2 }, tally: tallyMoves(rows, 'w'), chartRows: rows, side: 'w', analyzed: true, reviewing: false,
    phases: { opening: { accuracy: 95 }, middlegame: { accuracy: 92 }, endgame: { accuracy: 88 } }
  });
  assert.match(html, /Chess<span>Plus<\/span>/);
  assert.doesNotMatch(html, /VILA/i);
  assert.match(html, /Tổng kết ván đấu/);
  assert.match(html, /1 - 0/); assert.match(html, /Bạn thắng!/);
  assert.match(html, /91\.8%/); assert.match(html, /84\.2%/);
  assert.match(html, /Khai cuộc/); assert.match(html, /Tuyệt vời/); assert.match(html, /\(95%\)/);
  assert.match(html, /id="reviewOpenReplay"[^>]*>[\s\S]*Xem lại ván đấu/);
  assert.equal((html.match(/rv2-tally-row/g) || []).length >= 8, true);
});

test('summary before analysis offers to analyse instead of replay', () => {
  const html = summaryMarkup({ result: { token: '*' }, names: {}, accuracy: {}, tally: {}, chartRows: [], side: 'w', analyzed: false });
  assert.match(html, /id="reviewGameBtn"/);
  assert.doesNotMatch(html, /id="reviewOpenReplay"/);
});

function positions() {
  return [
    { fen: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', ply: 0 },
    { fen: 'f1 b 0 1 x x', ply: 1, san: 'e4', mover: 'w', from: 'e2', to: 'e4' },
    { fen: 'f2 w 0 1 x 1', ply: 2, san: 'e5', mover: 'b', from: 'e7', to: 'e5' },
    { fen: 'f3 b 0 2 x 2', ply: 3, san: 'Nf3', mover: 'w', from: 'g1', to: 'f3' }
  ];
}

test('move pairs group white and black plies under one move number', () => {
  const pos = positions(); pos[1].fen = 'a b - - 0 1'; pos[2].fen = 'a w - - 0 2'; pos[3].fen = 'a b - - 1 2';
  pos[0].fen = 'a w - - 0 1'; pos[1].fen = 'a b - - 0 1'; pos[2].fen = 'a w - - 0 2';
  const pairs = buildMovePairs(pos, ply => ({ 3: { judgement: { key: 'best' } } })[ply] || null);
  assert.equal(pairs.length, 2);
  assert.equal(pairs[0].w.san, 'e4'); assert.equal(pairs[0].b.san, 'e5');
  assert.equal(pairs[1].w.san, 'Nf3'); assert.equal(pairs[1].b, null);
  const html = moveListMarkup(pairs, 3);
  assert.match(html, /rv2-row is-active/);
  assert.match(html, /data-review-ply="3"/);
  assert.match(html, /b-best/);
});

test('banner and hint describe the move and its quality', () => {
  const position = { ply: 3, san: 'Nf3', mover: 'w', from: 'g1', to: 'f3', prevFen: 'a w - - 0 12' };
  const banner = bannerFor({ judgement: { key: 'best' } }, position);
  assert.equal(banner.label, 'NƯỚC ĐI TỐT NHẤT');
  assert.equal(banner.chip, '12. Nf3');
  assert.match(hintFor({ judgement: { key: 'best' } }, position), /Nf3 là nước đi tốt nhất, giúp phát triển quân và kiểm soát trung tâm\./);
  assert.match(hintFor({ judgement: { key: 'mistake' }, bestMoveSan: 'd4' }, position), /Nước tốt hơn là d4/);
  assert.equal(bannerFor(null, { ply: 0 }).label, 'THẾ CỜ BẮT ĐẦU');
});

test('replay screen has banner, board, hint, list, controls and slider', () => {
  const pos = positions();
  const html = replayMarkup({ ply: 3, total: 3, positions: pos, rowByPly: () => ({ judgement: { key: 'best' } }), boardHtml: '<i></i>' });
  for (const id of ['reviewBanner', 'reviewReplayBoard', 'reviewHint', 'reviewMoveAnalysis', 'reviewPlayBtn', 'reviewSlider', 'reviewShare', 'reviewSettings', 'reviewBack']) {
    assert.match(html, new RegExp(`id="${id}"`), id);
  }
  for (const step of ['first', 'prev', 'next', 'last']) assert.match(html, new RegExp(`data-review-step="${step}"`));
  assert.match(html, /3 \/ 3/);
  assert.match(html, /Chess<span>Plus<\/span>/);
});

test('landing keeps the PGN box and saved-game list hooks', () => {
  const html = landingMarkup({ cardsHtml: '' });
  for (const id of ['reviewPgnInput', 'reviewPgnLoad', 'reviewPgnAnalyze', 'reviewLandingHistory', 'reviewBackHome']) assert.match(html, new RegExp(id));
});

test('wiring: old analysis page is gone and every entry point opens the new review', () => {
  const main = read('src/main.js');
  const html = read('index.html');
  assert.equal(fs.existsSync(new URL('../src/pages/analysis-page.js', import.meta.url)), false);
  assert.doesNotMatch(main, /renderCoachView|wireCoachActions|analysisPage|renderAnalysisPage/);
  assert.doesNotMatch(html, /data-view="coach"/);
  assert.match(main, /view === 'coach'\) \{[^}]*view = 'review'/);
  assert.match(main, /title: 'Phân tích', sub: 'Xem lại ván đấu', view: 'review'/);
  assert.match(main, /reviewScreenMode === 'replay'\) \{ setReviewScreen\('summary'\)/);
});

test('css: new layer is in the bundle and the old review layers / analysis rules are gone', () => {
  const bundle = read('src/vila-professional.css');
  assert.ok(bundle.includes('Professional stylesheet layer: review-screen.css'));
  for (const old of ['review-layers.css', 'review-polish.css', 'review-chess.css']) {
    assert.equal(fs.existsSync(new URL('../src/' + old, import.meta.url)), false, old);
    assert.ok(!bundle.includes('layer: ' + old), old);
  }
  assert.ok(!bundle.includes('.ap-page'));
});
