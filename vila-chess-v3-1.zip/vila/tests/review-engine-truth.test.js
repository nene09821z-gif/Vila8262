/**
 * End-to-end truth tests for game review, using the REAL Stockfish build that ships with the app.
 *
 * What is checked is the chain the review depends on:  engine score (side-to-move) -> white-perspective
 * centipawns -> mover-perspective -> win-chance drop -> label.  The classic way review goes wrong is a
 * perspective/sign slip that only shows up for one colour, so every scenario is also played mirrored
 * (colours swapped) and must receive the same verdict.
 */
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { startAnalysisServer } from '../analysis-server/src/index.js';
import { loadConfig } from '../analysis-server/src/config.js';
import { locateEngine } from '../analysis-server/src/engine-locator.js';
import { scoreSideToWhiteCentipawns } from '../src/game-review.js';
import { judgeMoveFromEvals } from '../src/review-verify.js';

const KEY = 'review-truth-key-0123456789-abcdef';
const engine = locateEngine({ PATH: '' });
const skip = !engine && 'Stockfish WebAssembly build not present';
let running = null;
let base = '';

before(async () => {
  if (!engine) return;
  const config = loadConfig({ ANALYSIS_API_KEYS: KEY, PORT: '0', ANALYSIS_CACHE_FILE: '', ANALYSIS_WORKERS: '1', ANALYSIS_LOG: '0' });
  running = await startAnalysisServer(config, { engine });
  base = `http://127.0.0.1:${running.address.port}`;
});
after(async () => { await running?.close(); });

const swapCase = text => [...text].map(ch => (ch === ch.toUpperCase() ? ch.toLowerCase() : ch.toUpperCase())).join('');
/** Colour-swapped copy of a position: ranks flipped, piece colours swapped, side to move swapped. */
export function mirrorFen(fen) {
  const [board, turn, castling, ep, half = '0', full = '1'] = fen.split(/\s+/);
  const flippedBoard = board.split('/').reverse().map(swapCase).join('/');
  const flippedCastling = castling === '-' ? '-' : [...swapCase(castling)].sort((a, b) => 'KQkq'.indexOf(a) - 'KQkq'.indexOf(b)).join('');
  const flippedEp = ep === '-' ? '-' : `${ep[0]}${9 - Number(ep[1])}`;
  return `${flippedBoard} ${turn === 'w' ? 'b' : 'w'} ${flippedCastling} ${flippedEp} ${half} ${full}`;
}
const mirrorUci = uci => [...uci.matchAll(/[a-h][1-8]/g)].map(m => `${m[0][0]}${9 - Number(m[0][1])}`).join('') + uci.slice(4);

async function analyze(fen) {
  const response = await fetch(`${base}/v1/analyze`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}` },
    body: JSON.stringify({ fen, quality: 'standard', multipv: 2 })
  });
  assert.equal(response.status, 200, `analyze ${fen}`);
  const data = await response.json();
  const turn = fen.split(/\s+/)[1];
  const [first, second] = data.lines;
  return {
    scoreWhiteCp: scoreSideToWhiteCentipawns(first.score, turn, first.scoreType),
    secondWhiteCp: second ? scoreSideToWhiteCentipawns(second.score, turn, second.scoreType) : null,
    depth: first.depth, bestUci: data.bestmove
  };
}

/** Review one move exactly like the app: evaluate before/after with the engine (terminal positions use fixed scores). */
async function reviewMove({ before, uci, after, terminalWhiteCp = null }) {
  const mover = before.split(/\s+/)[1];
  const evalBefore = await analyze(before);
  const evalAfter = terminalWhiteCp == null ? await analyze(after) : { scoreWhiteCp: terminalWhiteCp, depth: 99 };
  return { mover, ...judgeMoveFromEvals(evalBefore, evalAfter, { mover, uci }), evalBefore, evalAfter };
}

const SCENARIOS = [
  {
    name: 'capturing a free queen is the best move',
    before: '4k3/8/8/3q4/8/8/8/3QK3 w - - 0 1', uci: 'd1d5', after: '4k3/8/8/3Q4/8/8/8/4K3 b - - 0 1',
    keys: ['best', 'great'], bestMove: true
  },
  {
    name: 'leaving the queen en prise throws away a won game',
    before: '4k3/8/8/3q4/8/8/8/3QK3 w - - 0 1', uci: 'e1f2', after: '4k3/8/8/3q4/8/8/5K2/3Q4 b - - 1 1',
    keys: ['blunder', 'missed-win'], minLossCp: 500
  },
  {
    name: 'a normal opening move is not penalised',
    before: 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', uci: 'e2e4', after: 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1',
    keys: ['best', 'great', 'excellent', 'good', 'book'], maxLossCp: 40
  },
  {
    name: 'delivering mate is the best move',
    before: '7k/8/6K1/8/8/8/8/5Q2 w - - 0 1', uci: 'f1f8', after: '5Q1k/8/6K1/8/8/8/8/8 b - - 1 1', terminalWhiteCp: 10000,
    keys: ['best', 'great'], bestMove: true
  },
  {
    name: 'stalemating the opponent instead of mating is a serious error',
    before: '7k/8/6K1/8/8/8/8/5Q2 w - - 0 1', uci: 'f1f7', after: '7k/5Q2/6K1/8/8/8/8/8 b - - 1 1', terminalWhiteCp: 0,
    keys: ['blunder', 'missed-win']
  }
];

for (const scenario of SCENARIOS) {
  for (const colour of ['white', 'black']) {
    test(`review (${colour} to move): ${scenario.name}`, { skip }, async () => {
      const flip = colour === 'black';
      const move = flip
        ? { before: mirrorFen(scenario.before), uci: mirrorUci(scenario.uci), after: mirrorFen(scenario.after), terminalWhiteCp: scenario.terminalWhiteCp == null ? null : -scenario.terminalWhiteCp }
        : { before: scenario.before, uci: scenario.uci, after: scenario.after, terminalWhiteCp: scenario.terminalWhiteCp ?? null };
      const review = await reviewMove(move);
      assert.equal(review.mover, flip ? 'b' : 'w');
      const key = review.judgement?.key;
      assert.ok(scenario.keys.includes(key), `${scenario.name}: got "${key}" (loss ${review.lossCp}cp, before ${review.moverBeforeCp}, after ${review.moverAfterCp})`);
      if (scenario.bestMove) assert.equal(review.moveWasBest, true, 'the engine must pick the same move');
      if (scenario.minLossCp) assert.ok(review.lossCp >= scenario.minLossCp, `loss ${review.lossCp}cp should be at least ${scenario.minLossCp}`);
      if (scenario.maxLossCp != null) assert.ok(review.lossCp <= scenario.maxLossCp, `loss ${review.lossCp}cp should be at most ${scenario.maxLossCp}`);
    });
  }
}

test('mirroring a position negates the white-perspective score (no colour-dependent sign slips)', { skip }, async () => {
  const positions = [
    'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3',
    '4k3/8/8/3q4/8/8/8/3QK3 w - - 0 1',
    '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1',
    '8/8/8/4k3/8/8/4P3/4K3 w - - 0 1'
  ];
  for (const fen of positions) {
    const a = await analyze(fen);
    const b = await analyze(mirrorFen(fen));
    // Near-equal positions may legitimately wobble around zero; only decisive scores must flip sign.
    if (Math.abs(a.scoreWhiteCp) > 80 || Math.abs(b.scoreWhiteCp) > 80) assert.equal(Math.sign(a.scoreWhiteCp), -Math.sign(b.scoreWhiteCp), `sign of ${fen}: ${a.scoreWhiteCp} vs ${b.scoreWhiteCp}`);
    if (Math.abs(a.scoreWhiteCp) >= 9000) assert.ok(Math.abs(Math.abs(a.scoreWhiteCp) - Math.abs(b.scoreWhiteCp)) <= 40, `mate distance of ${fen}`);
    else assert.ok(Math.abs(a.scoreWhiteCp + b.scoreWhiteCp) <= 60, `score of ${fen}: ${a.scoreWhiteCp} vs ${b.scoreWhiteCp}`);
  }
});

test('mirror helpers are involutions', () => {
  const fen = 'r3k2r/8/8/8/3pP3/8/8/R3K2R b KQkq e3 0 1';
  assert.equal(mirrorFen(mirrorFen(fen)), fen);
  assert.equal(mirrorUci(mirrorUci('e7e8q')), 'e7e8q');
  assert.equal(mirrorUci('e2e4'), 'e7e5');
});
