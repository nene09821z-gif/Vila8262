import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/social-hub.css', import.meta.url), 'utf8');
const worker = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
const nodeBackend = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');

test('plan controls call the server-backed request API and clearly state no automatic Premium grant', () => {
  assert.match(main, /socialApi\('\/me\/purchase-requests'/);
  assert.match(main, /data-plan-request="pro"/);
  assert.match(main, /data-plan-request="premium"/);
  assert.match(main, /Premium hiện không bán trực tiếp/);
  assert.match(main, /không thanh toán và không tự kích hoạt gói/);
  assert.match(main, /Gửi vào chat admin/);
});

test('Messenger purchase assistant buttons have event handlers and queue actions call protected admin endpoints', () => {
  assert.match(main, /id="chatAdminPlanPanel"/);
  assert.match(main, /data-chat-plan-request="pro"/);
  assert.match(main, /data-chat-plan-open="premium"/);
  assert.match(main, /\$\$\('\[data-chat-plan-request\]'\)\.forEach[\s\S]*?requestPlanWithAdmin\(button\.dataset\.chatPlanRequest \|\| 'pro'\)/);
  assert.match(main, /data-chat-plan-request="diamond"/);
  assert.match(main, /\$\$\('\[data-chat-plan-open\]'\)\.forEach[\s\S]*?setView\('plans'\)/);
  assert.match(main, /data-purchase-decision/);
  assert.match(main, /\/admin\/purchase-requests\/\$\{encodeURIComponent\(id\)\}\/decision/);
  assert.match(worker, /if \(user\.role !== 'admin'\) return fail\('Bạn không có quyền quản trị\.', 403\)/);
  assert.match(nodeBackend, /router\.post\('\/admin\/purchase-requests\/:requestId\/decision', requireAuth, requireAdmin/);
  assert.match(nodeBackend, /rateLimit\(\{ name: 'purchase-request', max: 8, windowMs: 60 \* 60_000 \}\)/);
  assert.match(worker, /policies\.push\(\['purchase-request', 8, 3_600_000\]\)/);
  assert.match(css, /\.chat-admin-plan-panel/);
});
