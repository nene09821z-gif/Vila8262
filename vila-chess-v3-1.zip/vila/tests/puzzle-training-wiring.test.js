import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PUZZLE_BANK } from '../src/puzzle-bank.js';
import { emptyTrainingState, recordPuzzleResult, takeReviewPuzzle, REVIEW_BOX_INTERVALS_MS } from '../src/puzzle-training.js';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8') + ['puzzle-page.js'].map(f => readFileSync(new URL('../src/pages/' + f, import.meta.url), 'utf8')).join('\n');

test('main.js records puzzle outcomes and serves reviews outside rush/survival', () => {
  assert.match(main, /from '\.\/puzzle-training\.js'/);
  assert.match(main, /recordPuzzleOutcome\('failed', \{ countStats: false \}\)/, 'first wrong move queues the puzzle');
  assert.match(main, /recordPuzzleOutcome\(!puzzleState\.wrongCount && !puzzleState\.hintUsed \? 'clean' : 'assisted'/, 'solve outcome is graded');
  assert.match(main, /recordPuzzleOutcome\('failed', \{ once: true, final: true \}\)/, 'revealing the solution counts as a miss');
  assert.match(main, /!\['rush', 'survival'\]\.includes\(puzzleState\.playMode\)[\s\S]{0,200}takeReviewPuzzle/, 'reviews never interrupt timed modes');
  assert.match(main, /trainingHtml: puzzleTrainingPanelMarkup\(\)/, 'stats panel is rendered in the puzzle view');
  assert.match(main, /if \(lost\) \{[\s\S]{0,220}recordPuzzleOutcome\('failed', \{ once: true, final: true \}\)/, 'last survival life finalizes failed-result stats');
});

test('every bundled puzzle survives the miss -> review queue round trip unchanged', () => {
  for (const puzzle of PUZZLE_BANK) {
    const queued = recordPuzzleResult(emptyTrainingState(), puzzle, 'failed', { now: 0 });
    const { puzzle: review } = takeReviewPuzzle({ ...queued, sinceReview: 9 }, { now: REVIEW_BOX_INTERVALS_MS[0] });
    assert.ok(review, `review served for ${puzzle.fen}`);
    assert.deepEqual(review.moves, puzzle.moves, `review keeps the exact verified line for ${puzzle.fen}`);
    assert.equal(review.fen, puzzle.fen);
  }
});
