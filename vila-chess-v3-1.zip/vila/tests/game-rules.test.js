import test from 'node:test';
import assert from 'node:assert/strict';
import {
  FORFEIT_REASONS, RANKED_MIN_PLIES, hasInsufficientMatingMaterial, parseFenMaterial, planRankedFinish, resolveFlagResult
} from '../src/game-rules.js';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const fen = board => `${board} w - - 0 1`;

test('parseFenMaterial counts pieces and bishop square colours', () => {
  const m = parseFenMaterial(START);
  assert.deepEqual([m.w.p, m.w.n, m.w.b, m.w.r, m.w.q, m.w.k], [8, 2, 2, 2, 1, 1]);
  assert.deepEqual([m.b.p, m.b.n, m.b.b, m.b.r, m.b.q, m.b.k], [8, 2, 2, 2, 1, 1]);
  // c1 is a dark square and f1 a light square; the same holds mirrored for Black (c8 light, f8 dark).
  assert.equal(m.w.bishopsDark, 1); assert.equal(m.w.bishopsLight, 1);
  assert.equal(m.b.bishopsDark, 1); assert.equal(m.b.bishopsLight, 1);
});

test('parseFenMaterial rejects malformed boards instead of guessing', () => {
  for (const bad of ['', 'nonsense', '8/8/8/8/8/8/8', '9/8/8/8/8/8/8/8', '4k3/8/8/8/8/8/8/8', '4k3/8/8/8/8/8/8/4K2X', '4k3/8/8/8/8/8/8/4K4']) {
    assert.equal(parseFenMaterial(fen(bad)), null, bad);
  }
});

test('insufficient mating material: dead and impossible cases', () => {
  const cases = [
    ['4k3/8/8/8/8/8/8/4K3', 'w', true, 'bare kings'],
    ['4k3/8/8/8/8/8/8/3NK3', 'w', true, 'K+N vs K'],
    ['4k3/8/8/8/8/8/8/3BK3', 'w', true, 'K+B vs K'],
    ['4k3/8/8/8/8/4B3/8/2B1K3', 'w', true, 'K+B+B on the same colour vs K'],
    ['4k3/8/8/8/8/8/8/2B1KB2', 'w', false, 'K+B+B on opposite colours can mate'],
    ['4k3/8/8/8/8/8/8/2N1KN2', 'w', false, 'K+N+N can mate if the defender cooperates'],
    ['4k3/8/8/8/8/8/8/2B1KN2', 'w', false, 'K+B+N can mate'],
    ['4k3/8/8/8/8/8/4P3/4K3', 'w', false, 'a pawn can promote'],
    ['4k3/8/8/8/8/8/8/R3K3', 'w', false, 'rook'],
    ['4k3/8/8/8/8/8/8/Q3K3', 'w', false, 'queen'],
    // Opponent has a piece that could block its own king: a helpmate exists, so the lone minor is sufficient.
    ['4kn2/8/8/8/8/8/8/3BK3', 'w', false, 'K+B vs K+N'],
    ['4k3/4p3/8/8/8/8/8/3BK3', 'w', false, 'K+B vs K+P'],
    ['4k3/8/8/8/8/8/8/3NK3', 'b', true, 'a bare king cannot mate (black view)']
  ];
  for (const [board, color, expected, label] of cases) {
    assert.equal(hasInsufficientMatingMaterial(fen(board), color), expected, label);
  }
});

test('insufficient mating material is conservative on bad input', () => {
  assert.equal(hasInsufficientMatingMaterial('garbage', 'w'), false);
  assert.equal(hasInsufficientMatingMaterial(START, 'x'), false);
  assert.equal(hasInsufficientMatingMaterial(START, 'w'), false);
});

test('FIDE 6.9: flagging against a side that cannot mate is a draw, otherwise a loss', () => {
  // White flags. Black has only a king (cannot mate) while White has a queen.
  assert.deepEqual(resolveFlagResult(fen('4k3/8/8/8/8/8/8/Q3K3'), 'w'), { result: '1/2-1/2', reason: 'timeout_vs_insufficient', drawn: true, winner: null });
  // White flags, Black has K+N only vs a bare king: still a draw.
  assert.equal(resolveFlagResult(fen('3nk3/8/8/8/8/8/8/4K3'), 'w').result, '1/2-1/2');
  // White flags, Black has a rook: Black wins on time.
  assert.deepEqual(resolveFlagResult(fen('r3k3/8/8/8/8/8/8/4K3'), 'w'), { result: '0-1', reason: 'time_forfeit', drawn: false, winner: 'b' });
  // Black flags in the opening: White wins.
  assert.equal(resolveFlagResult(START, 'b').result, '1-0');
  // Black flags, White has K+B vs bare king: draw. Black flags with a pawn left for White: win.
  assert.equal(resolveFlagResult(fen('4k3/8/8/8/8/8/8/3BK3'), 'b').result, '1/2-1/2');
  assert.equal(resolveFlagResult(fen('4k3/8/8/8/8/8/4P3/4K3'), 'b').result, '1-0');
  // Unknown positions never hand out a draw by accident.
  assert.equal(resolveFlagResult('not a fen', 'w').result, '0-1');
  assert.equal(resolveFlagResult(START, 'z').result, '*');
});

test('ranked abort rule: forfeits before both sides moved never change ratings', () => {
  assert.equal(RANKED_MIN_PLIES, 2);
  for (const reason of FORFEIT_REASONS) {
    for (const plyCount of [0, 1]) {
      const plan = planRankedFinish({ result: '1-0', reason, plyCount, fen: START });
      assert.equal(plan.status, 'aborted', `${reason}@${plyCount}`);
      assert.equal(plan.result, null);
      assert.equal(plan.rated, false);
      assert.equal(plan.reason, 'aborted');
      assert.equal(plan.originalReason, reason);
    }
    const live = planRankedFinish({ result: '0-1', reason, plyCount: 2, fen: START });
    assert.equal(live.status, 'finished', `${reason}@2`);
    assert.equal(live.rated, true);
  }
});

test('ranked finish plan: board results are never aborted and flag rule applies', () => {
  assert.deepEqual(planRankedFinish({ result: '1-0', reason: 'checkmate', plyCount: 1, fen: START }), { status: 'finished', result: '1-0', reason: 'checkmate', rated: true });
  assert.deepEqual(planRankedFinish({ result: '1/2-1/2', reason: 'draw', plyCount: 0, fen: START }), { status: 'finished', result: '1/2-1/2', reason: 'draw', rated: true });
  // Black flags, White only has K+N: the game is drawn and rated as a draw.
  const draw = planRankedFinish({ result: '1-0', reason: 'time_forfeit', plyCount: 60, fen: fen('4k3/8/8/8/8/8/8/3NK3') });
  assert.deepEqual(draw, { status: 'finished', result: '1/2-1/2', reason: 'timeout_vs_insufficient', rated: true });
  // A normal flag keeps the proposed result.
  assert.deepEqual(planRankedFinish({ result: '0-1', reason: 'time_forfeit', plyCount: 40, fen: START }), { status: 'finished', result: '0-1', reason: 'time_forfeit', rated: true });
  // Resignation after the opening is a normal rated loss, whatever the material.
  assert.equal(planRankedFinish({ result: '1-0', reason: 'resignation', plyCount: 3, fen: fen('4k3/8/8/8/8/8/8/3NK3') }).result, '1-0');
  // Missing input never throws.
  assert.equal(planRankedFinish().status, 'finished');
});
