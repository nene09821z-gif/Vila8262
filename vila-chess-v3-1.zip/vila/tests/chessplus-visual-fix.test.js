import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = name => fs.readFileSync(new URL(`../${name}`, import.meta.url), 'utf8');

test('header shows ChessPlus branding and hides only the two requested upper-right shortcuts', () => {
  const html = read('index.html');
  const css = read('src/vila-professional-theme.css');
  assert.match(html, /id="chessplusBrand"/);
  assert.match(html, /chessplus-mark\.svg\?v=2/);
  assert.match(html, /chessplus\.com/);
  assert.match(css, /\.topbar #openInbox[\s\S]*?\.topbar #openSettings[\s\S]*?display: none !important/s);
  assert.match(css, /#chessplusBrand \.chessplus-mark[\s\S]*?aspect-ratio: 1 \/ 1/s);
});

test('home mall icon tiles have a fixed square box without changing the SVG icon artwork', () => {
  const css = read('src/vila-professional-theme.css');
  const icons = read('src/ui-icons.js');
  assert.match(css, /\.home-mall \.mall-shop > \.mall-ico[\s\S]*?width: 38px !important[\s\S]*?height: 38px !important/s);
  assert.match(css, /\.home-mall \.mall-shop > \.mall-ico > \.ui-ico[\s\S]*?width: 66% !important[\s\S]*?height: 66% !important/s);
  assert.match(icons, /export function uiIcon\(name\)/);
  assert.match(icons, /export function uiTile\(name/);
});

test('Settings no longer renders the obsolete images and the service worker cache is refreshed', () => {
  const main = read('src/main.js');
  const settings = main.slice(main.indexOf('function renderSettingsView()'), main.indexOf('function wireCommonActions()'));
  const sw = read('public/sw.js');
  assert.doesNotMatch(settings, /brand-showcase|memory-keepsake|vila-memory-monument/);
  assert.doesNotMatch(sw, /vila-memory-monument/);
  assert.match(sw, /chessplus-v3\.69\.1-fix11/);
  assert.match(sw, /chessplus-mark\.svg\?v=2/);
});

test('the four top header controls (account, music, engine status, menu) are forced visible while inbox and settings stay hidden', () => {
  const css = read('src/vila-professional-theme.css');
  const bundle = read('src/vila-professional.css');
  for (const id of ['accountShortcut', 'appMusicToggle', 'engineStatus', 'openMenu']) {
    assert.match(css, new RegExp(`html body \\.topbar \\.top-actions #${id}[\\s\\S]*?display: (?:inline-flex|inline-grid) !important`), `${id} is shown`);
  }
  assert.match(css, /html body \.topbar #openInbox,\s*html body \.topbar #openSettings \{\s*display: none !important/);
  assert.ok(bundle.includes('html body .topbar .top-actions #openMenu'), 'runtime bundle contains the header override');
});
