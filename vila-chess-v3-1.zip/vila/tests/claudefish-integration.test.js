import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { LegacyUciEngine } from '../src/legacy-uci-engine.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const source = path.join(root, 'engines', 'claudefish', 'claudefish.cpp');
const binary = path.join(process.env.TMPDIR || '/tmp', 'claudefish-single-test');
const hasGpp = spawnSync('g++', ['--version']).status === 0;
const wasmPath = path.join(root, 'public', 'claudefish', 'cf-engine.wasm');

test('Arena registers ClaudeFish with its own worker, fallback and stop handling', () => {
  const main = read('src/main.js');
  assert.match(main, /id: 'claudefish'.*ClaudeFish/);
  assert.match(main, /type: 'claudefish'/);
  assert.match(main, /claudefish\/claudefish-worker\.js/);
  assert.match(main, /label: 'ClaudeFish'/);
  assert.match(main, /claudeFishEngine\?\.stop\(\)/);
  assert.match(main, /getClaudeFishEngine\(\)\.newGame\(\)/);
  assert.match(read('src/bot-personas.js'), /claudefish:\s*\{ openingNames/);
});

test('ClaudeFish never falls back to Stockfish (arena and normal games)', () => {
  const main = read('src/main.js');
  const start = main.indexOf("if (player.type === 'claudefish') {");
  const end = main.indexOf("if (player.type === 'stockfish-legacy') {", start);
  assert.ok(start > 0 && end > start, 'ClaudeFish arena branch not found');
  const branch = main.slice(start, end);
  assert.doesNotMatch(branch, /requestStockfishUci|chooseStockfishBackedOfflineUci/);
  assert.match(branch, /chooseAlternateMoveAsync/);
  const fn = main.slice(main.indexOf('async function chooseClaudeFishPlayUci'), main.indexOf('async function requestClaudeFishUci'));
  assert.ok(fn.length > 100, 'chooseClaudeFishPlayUci not found');
  assert.doesNotMatch(fn, /requestStockfishUci|chooseStockfishBackedOfflineUci/);
  // normal games: ClaudeFish is an "AI đa phong cách" profile and skips the Stockfish-assisted path
  assert.match(main, /const independent = profile === 'claudefish'/);
  assert.match(main, /\(neural \|\| independent\) \? null : await chooseStockfishBackedOfflineUci/);
  assert.match(read('src/alternate-engine-core.js'), /id: 'claudefish'/);
  assert.match(main, /OFFLINE_ENGINE_CATALOG\.filter\(item => item\.id !== 'claudefish'\)/);
});

test('Worker loads the prebuilt WASM module and the service worker precaches both files', async () => {
  const worker = read('public/claudefish/claudefish-worker.js');
  assert.match(worker, /cf-engine\.wasm/);
  assert.match(worker, /cf_best/);
  const code = worker.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');   // comments may mention Stockfish; code must not
  assert.doesNotMatch(code, /importScripts|stockfish/i);
  const bytes = fs.readFileSync(wasmPath);
  assert.equal(bytes.subarray(0, 4).toString('hex'), '0061736d', 'cf-engine.wasm has an invalid WebAssembly header');
  assert.ok(bytes.length > 100_000, 'cf-engine.wasm is unexpectedly small');
  const exported = new Set(WebAssembly.Module.exports(new WebAssembly.Module(bytes)).map(item => item.name));
  for (const name of ['memory', 'cf_init', 'cf_newgame', 'cf_io', 'cf_usenn', 'cf_best']) assert.ok(exported.has(name), `wasm export ${name} missing`);
  const sw = read('public/sw.js');
  assert.match(sw, /claudefish\/claudefish-worker\.js/);
  assert.match(sw, /claudefish\/cf-engine\.wasm/);
  // The optional emscripten build script keeps its own, separate output names.
  const script = read('scripts/build-claudefish-wasm.sh');
  assert.match(script, /_claudefish_command/);
  assert.match(script, /engines\/claudefish\/claudefish\.cpp/);
  assert.match(fs.readFileSync(source, 'utf8'), /claudefish_command\(const char\*/);
});

/** Runs the real worker file in a vm sandbox (Node has no classic Worker): postMessage <-> onmessage like a browser. */
function sandboxWorkerFactory({ wasmStatus = 200 } = {}) {
  const code = read('public/claudefish/claudefish-worker.js');
  return () => {
    const w = { onmessage: null, onerror: null, terminate() {}, postMessage(line) { sandbox.onmessage({ data: line }); } };
    const sandbox = {
      postMessage: line => queueMicrotask(() => w.onmessage?.({ data: line })),
      fetch: async () => wasmStatus !== 200 ? { ok: false, status: wasmStatus } : {
        ok: true, status: 200,
        arrayBuffer: async () => { const b = fs.readFileSync(wasmPath); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }
      },
      // the worker rethrows load errors from a timer so Worker.onerror fires; emulate that here
      setTimeout: fn => { try { fn(); } catch (error) { queueMicrotask(() => w.onerror?.({ message: error.message })); } },
      WebAssembly, TextEncoder, TextDecoder, URL, performance, Date, Math, BigInt, DataView, Uint8Array, Promise, Error, Number, String, console
    };
    sandbox.self = sandbox;
    sandbox.location = { href: 'http://localhost/claudefish/claudefish-worker.js' };
    vm.createContext(sandbox);
    vm.runInContext(code, sandbox);
    return w;
  };
}

test('ClaudeFish WASM worker plays strong, legal moves through LegacyUciEngine (no Stockfish involved)', async () => {
  const engine = new LegacyUciEngine(sandboxWorkerFactory(), { label: 'ClaudeFish', initTimeoutMs: 15_000 });
  try {
    engine.newGame();
    const start = await engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.match(start.uci, /^[a-h][1-8][a-h][1-8][qrbn]?$/);
    assert.ok(['e2e4', 'd2d4', 'g1f3', 'b1c3', 'c2c4', 'e2e3', 'd2d3', 'g2g3'].includes(start.uci), `odd opening move ${start.uci}`);
    const mate = await engine.bestMove('6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(mate.uci, 'a1a8');                       // back-rank mate in one
    const win = await engine.bestMove('rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(win.uci, 'f3h4');                        // takes the hanging queen
    const promo = await engine.bestMove('8/P6k/8/8/8/8/8/K7 w - - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(promo.uci, 'a7a8q');                     // promotes to a queen
    const black = await engine.bestMove('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1', { moveTimeMs: 300, depth: 20 });
    assert.match(black.uci, /^[a-h][1-8][a-h][1-8]/);
    await assert.rejects(engine.bestMove('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1', { moveTimeMs: 200, depth: 6 }), /không trả về nước đi/);  // stalemate
  } finally { engine.dispose(); }
});

test('A missing cf-engine.wasm fails fast with a clear error so the arena can use its JS fallback', async () => {
  const engine = new LegacyUciEngine(sandboxWorkerFactory({ wasmStatus: 404 }), { label: 'ClaudeFish', initTimeoutMs: 15_000 });
  try {
    await assert.rejects(engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 200, depth: 6 }), /cf-engine\.wasm/);
  } finally { engine.dispose(); }
});

test('LegacyUciEngine labels errors with the engine name', async () => {
  const engine = new LegacyUciEngine(() => { throw new Error('boom'); }, { label: 'ClaudeFish' });
  await assert.rejects(engine.bestMove('bad fen'), /FEN không hợp lệ cho ClaudeFish/);
  engine.dispose();
  await assert.rejects(engine.ensureReady(), /ClaudeFish session was disposed/);
});

test('ClaudeFish single-thread build plays legal moves through LegacyUciEngine', { skip: !hasGpp && 'g++ not available' }, async () => {
  const build = spawnSync('g++', ['-O2', '-std=c++17', '-DCF_SINGLE_THREAD', '-o', binary, source], { encoding: 'utf8' });
  assert.equal(build.status, 0, build.stderr);
  // Worker-shaped shim: postMessage(line) -> child stdin, stdout lines -> onmessage({data}).
  const factory = () => {
    const child = spawn(binary);
    const w = { onmessage: null, onerror: null, postMessage: line => child.stdin.write(`${line}\n`), terminate: () => child.kill() };
    let buf = '';
    child.stdout.on('data', chunk => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); w.onmessage?.({ data: line }); }
    });
    return w;
  };
  const engine = new LegacyUciEngine(factory, { label: 'ClaudeFish', initTimeoutMs: 10_000 });
  try {
    engine.newGame();
    const start = await engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 300, depth: 8 });
    assert.match(start.uci, /^[a-h][1-8][a-h][1-8]$/);
    assert.ok(start.depth >= 1);
    // Mate in one for white: Qxf7#
    const mate = await engine.bestMove('r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1', { moveTimeMs: 300, depth: 6 });
    assert.equal(mate.uci, 'f3f7');
  } finally { engine.dispose(); }
});
