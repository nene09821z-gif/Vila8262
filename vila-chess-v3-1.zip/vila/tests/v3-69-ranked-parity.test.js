import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRankedFairPlayState, assessRankedFocusSignal } from '../src/ranked-fair-play.js';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const worker = readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
const node = readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');

const complexTurn = ply => ({ userId: 'u1', focusLostMs: 9000, focusCount: 2, turnDurationMs: 12000, legalMoveCount: 32, ply, now: 1_000_000 + ply });

test('focus telemetry stays silent for a couple of app switches', () => {
  const state = createRankedFairPlayState();
  assert.equal(assessRankedFocusSignal(state, complexTurn(10)).events.length, 0);
  assert.equal(assessRankedFocusSignal(state, complexTurn(12)).events.length, 0);
});

test('focus telemetry raises a review-only event after it recurs on complex turns', () => {
  const state = createRankedFairPlayState();
  assessRankedFocusSignal(state, complexTurn(10));
  assessRankedFocusSignal(state, complexTurn(12));
  const third = assessRankedFocusSignal(state, complexTurn(14));
  assert.equal(third.events.length, 1);
  assert.equal(third.events[0].type, 'repeated_focus_loss_on_complex_turns');
  assert.equal(third.events[0].severity, 'review');
  // cooldown: no spam on the very next turn
  assert.equal(assessRankedFocusSignal(state, complexTurn(16)).events.length, 0);
});

test('focus telemetry ignores simple positions, short absences and lying clients', () => {
  const state = createRankedFairPlayState();
  for (let i = 0; i < 6; i += 1) {
    assessRankedFocusSignal(state, { ...complexTurn(10 + i * 2), legalMoveCount: 8 });
    assessRankedFocusSignal(state, { ...complexTurn(10 + i * 2), focusLostMs: 800 });
    assessRankedFocusSignal(state, { ...complexTurn(10 + i * 2), focusLostMs: 99_999_999, turnDurationMs: 1500 });
  }
  assert.equal(state.focusLossTurns || 0, 0);
  assert.equal(state.signals, 0);
});

test('both servers feed the focus signal into the existing review-only fair-play events', () => {
  assert.match(worker, /assessRankedFocusSignal\(fairPlay\.state/);
  assert.match(node, /assessRankedFocusSignal\(fairPlay\.state/);
  assert.match(worker, /manual review only/);
});

test('ranked board reuses the practice board frame and square vocabulary', () => {
  assert.match(main, /class="board-frame"><div class="board-surface"><div class="chessboard ranked-board" id="rankedBoard"/);
  for (const token of ['last-mine', 'last-opp', 'last-landing', 'in-check', 'fx-capture', 'fx-castle', 'rank-coord', 'file-coord']) {
    const start = main.indexOf('function rankedBoardMarkup');
    assert.ok(main.slice(start, start + 4200).includes(token), `ranked board must emit ${token}`);
  }
});

test('ranked board never exposes hints, arrows or engine controls (premove is allowed, chess.com style)', () => {
  const start = main.indexOf('function rankedBoardMarkup');
  const body = main.slice(start, start + 6000);
  assert.doesNotMatch(body, /hintArrow|boardArrows|bestMove|engine/i);
  assert.match(body, /premove-from|premove-to|premove-ghost/);
  assert.match(main, /for \(const type of \['contextmenu', 'dragstart', 'copy'\]\)/);
});
