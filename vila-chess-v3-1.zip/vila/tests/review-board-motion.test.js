import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { planReviewMoves, reviewSlideMs } from '../src/review-board-motion.js';

const snap = entries => new Map(entries.map(([sq, key, x, y]) => [sq, { key, x, y }]));

test('a quiet pawn move slides from the old square', () => {
  const before = snap([['e2', 'wP', 200, 300], ['e7', 'bP', 200, 100]]);
  const after = snap([['e4', 'wP', 200, 200], ['e7', 'bP', 200, 100]]);
  const plan = planReviewMoves(before, after);
  assert.equal(plan.moves.length, 1);
  assert.deepEqual({ to: plan.moves[0].to, from: plan.moves[0].from, dy: plan.moves[0].dy }, { to: 'e4', from: 'e2', dy: 100 });
  assert.deepEqual(plan.captured, []);
});

test('a capture reports the captured square and still slides the capturer', () => {
  const before = snap([['e4', 'wP', 200, 200], ['d5', 'bP', 150, 150]]);
  const after = snap([['d5', 'wP', 150, 150]]);
  const plan = planReviewMoves(before, after);
  assert.equal(plan.moves.length, 1);
  assert.equal(plan.moves[0].from, 'e4');
  assert.deepEqual(plan.captured, ['d5']);
});

test('castling pairs king with king and rook with rook', () => {
  const before = snap([['e1', 'wK', 400, 700], ['h1', 'wR', 700, 700]]);
  const after = snap([['g1', 'wK', 600, 700], ['f1', 'wR', 500, 700]]);
  const plan = planReviewMoves(before, after);
  const byTo = Object.fromEntries(plan.moves.map(m => [m.to, m.from]));
  assert.deepEqual(byTo, { g1: 'e1', f1: 'h1' });
});

test('an unchanged board plans nothing and slide time stays in range', () => {
  const same = snap([['a1', 'wR', 0, 0]]);
  assert.equal(planReviewMoves(same, snap([['a1', 'wR', 0, 0]])).moves.length, 0);
  assert.ok(reviewSlideMs(0) >= 130 && reviewSlideMs(1) <= 260 && reviewSlideMs(9) === 260);
});

test('review board markup carries the data the motion helper needs and main.js wires it', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /data-square="\$\{square\}" role="gridcell"/);
  assert.match(main, /data-piece="\$\{piece\.color\}\$\{piece\.type\}"/);
  assert.match(main, /captureReviewBoard\(board\)/);
  assert.match(main, /animateReviewBoard\(board, motionBefore/);
  const css = fs.readFileSync(new URL('../src/review-screen.css', import.meta.url), 'utf8');
  assert.match(css, /\.rv-sliding/);
});
