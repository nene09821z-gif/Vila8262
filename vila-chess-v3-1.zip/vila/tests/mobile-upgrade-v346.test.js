import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const index = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const sound = fs.readFileSync(new URL('../src/sound.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/mobile-upgrade.css', import.meta.url), 'utf8');
const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('v3.46 mobile play UI keeps a single grouped tool menu and compact clock shortcuts', () => {
  assert.equal(pkg.version, '3.69.1');
  assert.match(main, /import '\.\/vila-professional\.css';/, 'mobile rules are included through the canonical consolidated runtime stylesheet');
  assert.match(main, /id="openMatchMenu"/);
  assert.match(main, /id="gameShowSetup"/);
  for (const tab of ['moves', 'analysis', 'setup', 'pages']) assert.ok(main.includes(`data-sheet-tab="${tab}"`), `missing match menu tab ${tab}`);
  for (const preset of ['1+0', '3+2', '10+0', '15+10']) assert.ok(main.includes(preset), `missing quick preset ${preset}`);
  assert.doesNotMatch(main, /<div class="opening-recognition"/);
  assert.doesNotMatch(main, /<section class="hint-card"/);
  assert.match(main, /toast\(`Gợi ý: \$\{move\.san\}/);
  assert.match(css, /#hintArrowHead path \{ fill: #2563eb/);
});

test('mobile bottom destinations expose home, achievements, matchmaking, library and More', () => {
  assert.match(index, /data-view="home" type="button"><svg class="cp-nav-ico"[^>]*><use href="#cp-nav-home"\/><\/svg><span>Trang chủ<\/span>/);
  assert.match(index, /data-view="achievements" type="button"><svg class="cp-nav-ico"[^>]*><use href="#cp-trophy"\/><\/svg><span>Thành tích<\/span>/);
  assert.match(index, /data-view="ranked" type="button"><svg class="cp-nav-ico"[^>]*><use href="#cp-swords"\/><\/svg><span>Ghép trận<\/span>/);
  assert.match(index, /data-view="history" type="button"><svg class="cp-nav-ico"[^>]*><use href="#cp-nav-folder"\/><\/svg><span>Thư viện<\/span>/);
  assert.match(index, /id="bottomMore"/);
});

test('background music is streamed online (no offline synth) and starts automatically', () => {
  assert.doesNotMatch(sound, /Gymnopedie_No\._1|CLASSICAL_MUSIC_URL|musicAudio|startSynthMusic|MUSIC_TRACKS/);
  const lib = fs.readFileSync(new URL('../src/music-library.js', import.meta.url), 'utf8');
  assert.ok((lib.match(/videoId:|listId:/g) || []).length >= 10, 'online music library has many tracks');
  assert.match(sound, /vila:music-error/);
  assert.match(main, /MUSIC_AUTOSTART_KEY\) !== 'false'/);
});
