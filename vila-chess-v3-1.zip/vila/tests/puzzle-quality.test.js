import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const generator = fs.readFileSync(new URL('../src/puzzle-generator.js', import.meta.url), 'utf8');
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8') + ['puzzle-page.js'].map(f => fs.readFileSync(new URL('../src/pages/' + f, import.meta.url), 'utf8')).join('\n');

test('offline puzzle generator rejects quiet positional moves as puzzle answers', () => {
  assert.match(generator, /A puzzle must present a visible tactical task/);
  assert.match(generator, /!rootMove\.captured && !rootMove\.promotion && !info\.mateInOne/);
  assert.match(generator, /if \(!played \|\| !probe\.isCheck\(\)\) continue/);
});

test('Stockfish fallback verifies tactical candidates against MultiPV alternatives', () => {
  assert.match(main, /multiPv: 3/);
  assert.match(main, /selectVerifiedTacticalCandidate\(position\.fen, variations, Chess/);
  assert.match(main, /minimumGapCp: 180/);
  assert.doesNotMatch(main, /if \(tactical \|\| attempt === 6\) break/);
});

test('puzzle history is supplemented with in-session exclusions', () => {
  assert.match(main, /const puzzleSessionSeen = new Set\(\)/);
  assert.match(main, /\[\.\.\.new Set\(\[\.\.\.loadPuzzleHistory\(scopedLS\), \.\.\.puzzleSessionSeen\]\)\]/);
  assert.match(main, /puzzleSessionSeen\.add\(offline\.fen\.trim\(\)\.split/);
});


test('puzzle room exposes classic, daily, rush and survival modes with stale-generation guards', () => {
  const activeMain = main;
  const dailyGenerator = fs.readFileSync(new URL('../src/puzzle-generator.js', import.meta.url), 'utf8');
  const client = fs.readFileSync(new URL('../src/puzzle-worker-client.js', import.meta.url), 'utf8');
  for (const mode of ['classic', 'daily', 'rush', 'survival']) assert.match(activeMain, new RegExp(`id: '${mode}'`));
  assert.match(activeMain, /data-puzzle-mode=/);
  assert.match(activeMain, /function finishPuzzleRush\(\)/);
  assert.match(activeMain, /function pausePuzzleRushTimer\(\)/);
  assert.match(activeMain, /function resumePuzzleRushTimer\(\)/);
  assert.match(activeMain, /generationToken !== puzzleGenerationEpoch/);
  assert.match(activeMain, /PUZZLE_DAILY_SOLVED_KEY/);
  assert.match(activeMain, /PUZZLE_RUSH_BEST_KEY/);
  assert.match(dailyGenerator, /function createSeededRandom/);
  assert.match(dailyGenerator, /export function generateDailyMatePuzzle/);
  assert.match(client, /generateDailyPuzzleInWorker/);
});

import { selectVerifiedTacticalCandidate, isMateInOneTheme, localizePuzzleTheme, localizePuzzleThemes } from '../src/puzzle-quality.js';

class FakePuzzleChess {
  static tactical = true;
  static checking = true;
  constructor() {}
  moves() {
    return [{ from: 'e2', to: 'e4', captured: FakePuzzleChess.tactical ? 'q' : undefined, san: 'Rxe4+' }];
  }
  move(move) {
    if (move?.from !== 'e2' || move?.to !== 'e4') return null;
    return { san: 'Rxe4+' };
  }
  isCheck() { return FakePuzzleChess.checking; }
  isCheckmate() { return false; }
}

const multipv = (secondScore = 0) => [
  { multipv: 1, uci: 'e2e4', score: 260, depth: 10 },
  { multipv: 2, uci: 'a2a3', score: secondScore, depth: 10 },
  { multipv: 3, uci: 'b2b3', score: secondScore - 20, depth: 9 },
];

test('Stockfish fallback accepts only a legal tactical move with a clear MultiPV gap', () => {
  const result = selectVerifiedTacticalCandidate('fake-fen', multipv(20), FakePuzzleChess);
  assert.equal(result?.uci, 'e2e4');
  assert.equal(result?.gapCp, 240);
  assert.equal(selectVerifiedTacticalCandidate('fake-fen', multipv(190), FakePuzzleChess), null);
  assert.equal(selectVerifiedTacticalCandidate('fake-fen', [{ multipv: 1, uci: 'e2e4', score: 260, depth: 10 }], FakePuzzleChess), null);
});

test('Stockfish fallback rejects non-tactical or shallow/inconsistent alternatives', () => {
  FakePuzzleChess.tactical = false;
  FakePuzzleChess.checking = false;
  assert.equal(selectVerifiedTacticalCandidate('fake-fen', multipv(20), FakePuzzleChess), null);
  FakePuzzleChess.tactical = true;
  FakePuzzleChess.checking = true;
  assert.equal(selectVerifiedTacticalCandidate('fake-fen', [
    { multipv: 1, uci: 'e2e4', score: 260, depth: 10 },
    { multipv: 2, uci: 'a2a3', score: 20, depth: 7 },
  ], FakePuzzleChess), null);
});

test('mate-in-one themes are recognized so alternative legal mates are accepted', () => {
  assert.equal(isMateInOneTheme(['fork', 'mateIn1']), true);
  assert.equal(isMateInOneTheme(['mateIn2', 'advantage']), false);
  assert.equal(isMateInOneTheme([]), false);
});


test('puzzle UI never exposes the expected UCI move before the player solves it', () => {
  assert.doesNotMatch(main, /<small>Nước đi<\/small><b>\$\{puzzleState\.solutionUci/);
  assert.match(main, /puzzlePrompt/);
});

test('Lichess theme labels are displayed in Vietnamese', () => {
  assert.equal(localizePuzzleTheme('fork'), 'Đòn chĩa đôi');
  assert.equal(localizePuzzleTheme('mateIn2'), 'Chiếu hết trong 2');
  assert.deepEqual(localizePuzzleThemes(['fork', 'mateIn1', 'fork']), ['Đòn chĩa đôi', 'Chiếu hết trong 1']);
});
