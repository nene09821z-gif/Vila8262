import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { layers } from '../scripts/build-professional-css.mjs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('mobile ChessPlus shell is the last CSS layer and is bundled', () => {
  assert.equal(layers.at(-1), 'mobile-chessplus.css');
  assert.ok(read('src/vila-professional.css').includes('/* Professional stylesheet layer: mobile-chessplus.css */'));
});

test('shared header carries the ChessPlus brand and an Elo chip on every screen', () => {
  const html = read('index.html');
  assert.match(html, /class="cp-top-brand"/);
  assert.match(html, /id="accountShortcutElo"/);
  assert.match(html, /id="cpTopTitle"/);
  assert.match(read('src/main.js'), /function syncTopbarProfile\(/);
});

test('hamburger sheet and cards use the home navy theme on all pages', () => {
  const css = read('src/mobile-chessplus.css');
  assert.match(css, /#mainMenu\.tabs\.menu-open\s*\{/);
  assert.match(css, /Tất cả chức năng/);
  assert.match(css, /\.panel/);
  assert.match(css, /#vilaAccountGate/);
});

test('home hero styles no longer hijack the puzzle page .cp-hero', () => {
  const css = read('src/home-chessplus.css');
  assert.doesNotMatch(css, /\n\.cp-hero \{/);
  assert.match(css, /\.cp-home \.cp-hero \{/);
});
