import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

function createHarness(env = {}) {
  const records = new Map();
  const sql = {
    exec(statement, ...args) {
      if (/^CREATE TABLE/i.test(statement)) return [];
      if (/^SELECT key, value FROM vila_records/i.test(statement)) {
        return [...records.entries()].map(([key, value]) => ({ key, value }));
      }
      if (/^INSERT INTO vila_records/i.test(statement)) {
        records.set(String(args[0]), String(args[1]));
        return [];
      }
      if (/^DELETE FROM vila_records/i.test(statement)) {
        records.delete(String(args[0]));
        return [];
      }
      throw new Error(`SQL statement not covered by test harness: ${statement}`);
    }
  };
  const makeState = () => ({
    storage: { sql, transactionSync: callback => callback() },
    blockConcurrencyWhile: callback => callback()
  });
  let object = new ChessState(makeState(), env);
  const binding = {
    idFromName: () => 'vila-global-test',
    get: () => ({ fetch: request => object.fetch(request) })
  };
  return {
    binding,
    records,
    restart() { object = new ChessState(makeState(), env); }
  };
}

function makeRequest(path, { method = 'GET', token = '', body } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return new Request(`https://vila-test.workers.dev${path}`, {
    method,
    headers,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

async function call(harness, path, options = {}) {
  const response = await worker.fetch(makeRequest(path, options), { CHESS_STATE: harness.binding });
  const data = await response.json();
  return { status: response.status, data };
}



const { publicKey, privateKey } = await crypto.subtle.generateKey({ name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' }, true, ['sign', 'verify']);
const pem = `-----BEGIN PRIVATE KEY-----\n${Buffer.from(await crypto.subtle.exportKey('pkcs8', privateKey)).toString('base64').match(/.{1,64}/g).join('\n')}\n-----END PRIVATE KEY-----\n`;
const ENV = {
  ADMIN_USERNAME: 'boss', ADMIN_PASSWORD: 'AdminPassword!12345',
  GOOGLE_SERVICE_ACCOUNT_JSON: JSON.stringify({ client_email: 'svc@vila.iam.gserviceaccount.com', private_key: pem, token_uri: 'https://oauth2.test/token' })
};
const PKG = 'com.aistudio.covuavila.vzrk';

/** Fake Google: token endpoint (verifies the RS256 JWT), purchases.products.get / acknowledge, voidedpurchases. */
function fakeGoogle() {
  const g = { purchases: new Map(), acked: [], voided: [], calls: [], tokenRequests: 0, jwtOk: null, failLookup: false };
  g.add = (token, o = {}) => g.purchases.set(token, { productId: o.productId || 'vila_pro_1y', purchaseState: 0, consumptionState: 0, acknowledgementState: 0, orderId: o.orderId || `GPA.${token}`, obfuscatedExternalAccountId: o.account || '', purchaseTimeMillis: String(Date.now()), ...o.raw });
  g.fetch = async (input, init = {}) => {
    const url = String(input); g.calls.push(`${init.method || 'GET'} ${url}`);
    const reply = (obj, status = 200) => new Response(JSON.stringify(obj), { status });
    if (url === 'https://oauth2.test/token') {
      g.tokenRequests++;
      const assertion = new URLSearchParams(init.body).get('assertion'); const [h, c, sig] = assertion.split('.');
      const claims = JSON.parse(Buffer.from(c, 'base64url').toString());
      g.jwtOk = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', publicKey, Buffer.from(sig, 'base64url'), new TextEncoder().encode(`${h}.${c}`))
        && claims.iss === 'svc@vila.iam.gserviceaccount.com' && claims.scope === 'https://www.googleapis.com/auth/androidpublisher' && claims.aud === 'https://oauth2.test/token';
      return g.jwtOk ? reply({ access_token: 'ya29.fake', expires_in: 3600 }) : reply({ error: 'invalid_grant' }, 400);
    }
    if (init.headers?.Authorization !== 'Bearer ya29.fake') return reply({ error: 'unauth' }, 401);
    const base = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${PKG}/`;
    if (!url.startsWith(base)) return reply({ error: 'wrong package' }, 404);
    const rest = url.slice(base.length);
    let m = rest.match(/^purchases\/products\/([^/]+)\/tokens\/([^/:]+):acknowledge$/);
    if (m) { const p = g.purchases.get(decodeURIComponent(m[2])); if (!p) return reply({}, 404); p.acknowledgementState = 1; g.acked.push(decodeURIComponent(m[2])); return reply({}); }
    m = rest.match(/^purchases\/products\/([^/]+)\/tokens\/([^/:]+)$/);
    if (m) { if (g.failLookup) return reply({ error: 'boom' }, 500); const p = g.purchases.get(decodeURIComponent(m[2])); return p && p.productId === decodeURIComponent(m[1]) ? reply(p) : reply({ error: 'not found' }, 404); }
    if (rest.startsWith('purchases/voidedpurchases')) return reply({ voidedPurchases: g.voided.map(t => ({ purchaseToken: t, orderId: `GPA.${t}`, voidedTimeMillis: String(Date.now()) })) });
    return reply({}, 404);
  };
  return g;
}
let google;
const realFetch = globalThis.fetch;
test.beforeEach(() => { google = fakeGoogle(); globalThis.fetch = (...a) => google.fetch(...a); });
test.afterEach(() => { globalThis.fetch = realFetch; });

const register = (h, name) => call(h, '/api/social/auth/register', { method: 'POST', body: { username: name, displayName: name, password: 'Password!1' } });
const verify = (h, token, productId, purchaseToken) => call(h, '/api/social/me/purchase/verify', { method: 'POST', token, body: { productId, purchaseToken } });
const cfg = (h, token) => call(h, '/api/social/me/billing-config', { token });
const review = (h, token, gameId) => call(h, '/api/social/me/review-access', { method: 'POST', token, body: { gameId } });
async function adminToken(h) { return (await call(h, '/api/social/auth/login', { method: 'POST', body: { username: 'boss', password: ENV.ADMIN_PASSWORD } })).data.token; }
async function setup(name = 'alice') {
  const h = createHarness(ENV); const u = await register(h, name);
  const c = await cfg(h, u.data.token);
  return { h, token: u.data.token, id: u.data.user.id, account: c.data.accountId, config: c.data };
}

test('billing-config: needs login, reports products and a stable per-account binding id', async () => {
  const h = createHarness(ENV);
  assert.equal((await cfg(h, '')).status, 401);
  const a = await register(h, 'alice'); const b = await register(h, 'bobby');
  const ca = await cfg(h, a.data.token), cb = await cfg(h, b.data.token);
  assert.equal(ca.data.enabled, true);
  assert.deepEqual(ca.data.products, { pro: 'vila_pro_1y', premium: 'vila_premium_lifetime', diamond: 'vila_diamond_1y' });
  assert.match(ca.data.accountId, /^[0-9a-f]{32}$/);
  assert.notEqual(ca.data.accountId, cb.data.accountId);
  assert.equal((await cfg(h, a.data.token)).data.accountId, ca.data.accountId);
  const off = createHarness({}); const x = await register(off, 'carol');
  assert.equal((await cfg(off, x.data.token)).data.enabled, false);
  assert.equal((await verify(off, x.data.token, 'vila_pro_1y', 'tok')).status, 503, 'never grants when billing is not configured');
});

test('Pro purchase: verified with Google (signed JWT), granted once, acknowledged server-side, asks client to consume', async () => {
  const { h, token, account } = await setup();
  google.add('tok-pro-1', { account });
  const r = await verify(h, token, 'vila_pro_1y', 'tok-pro-1');
  assert.equal(r.status, 201, JSON.stringify(r.data));
  assert.equal(google.jwtOk, true, 'service-account JWT was correctly RS256-signed');
  assert.equal(r.data.granted, true); assert.equal(r.data.plan, 'pro'); assert.equal(r.data.consume, true);
  assert.equal(r.data.entitlement.plan, 'pro'); assert.equal(r.data.entitlement.daysLeft, 365);
  assert.deepEqual(google.acked, ['tok-pro-1']);
  assert.equal((await review(h, token, 'any-game')).data.reason, 'pro');
  const again = await verify(h, token, 'vila_pro_1y', 'tok-pro-1');
  assert.equal(again.status, 200); assert.equal(again.data.alreadyGranted, true); assert.equal(again.data.granted, false);
  assert.equal(again.data.entitlement.daysLeft, 365, 'replaying the same token never adds time');
});

test('Pro renewal: a second purchase while active stacks to 730 days; survives restart', async () => {
  const { h, token, account } = await setup();
  google.add('t1', { account }); google.add('t2', { account });
  await verify(h, token, 'vila_pro_1y', 't1');
  const second = await verify(h, token, 'vila_pro_1y', 't2');
  assert.equal(second.data.entitlement.daysLeft, 730);
  h.restart();
  const me = await call(h, '/api/social/auth/me', { token });
  assert.equal(me.data.user.entitlement.daysLeft, 730);
  assert.equal((await verify(h, token, 'vila_pro_1y', 't2')).data.alreadyGranted, true, 'purchase ledger persisted');
});

test('Premium purchase: lifetime, server acknowledges (non-consumable, no consume)', async () => {
  const { h, token, account } = await setup();
  google.add('tok-prem', { account, productId: 'vila_premium_lifetime' });
  const r = await verify(h, token, 'vila_premium_lifetime', 'tok-prem');
  assert.equal(r.status, 201); assert.equal(r.data.plan, 'premium'); assert.equal(r.data.consume, false);
  assert.equal(r.data.entitlement.plan, 'premium');
  assert.deepEqual(google.acked, ['tok-prem']);
});

test('already-acknowledged purchases are not acknowledged twice', async () => {
  const { h, token, account } = await setup();
  google.add('acked', { account, raw: { acknowledgementState: 1 } });
  assert.equal((await verify(h, token, 'vila_pro_1y', 'acked')).status, 201);
  assert.deepEqual(google.acked, []);
});

test('forged, wrong-product, unknown and malformed purchases never grant anything', async () => {
  const { h, token, account } = await setup();
  assert.equal((await verify(h, token, 'vila_pro_1y', 'does-not-exist')).status, 404);
  google.add('real-premium', { account, productId: 'vila_premium_lifetime' });
  assert.equal((await verify(h, token, 'vila_pro_1y', 'real-premium')).status, 404, 'a Premium token cannot be presented as Pro');
  assert.equal((await verify(h, token, 'hacker_product', 'real-premium')).status, 400);
  assert.equal((await verify(h, token, 'vila_pro_1y', '')).status, 400);
  assert.equal((await verify(h, '', 'vila_pro_1y', 'x')).status, 401);
  const me = await call(h, '/api/social/auth/me', { token });
  assert.equal(me.data.user.entitlement.plan, 'free');
});

test('pending / canceled purchases are not granted; pending can be verified again later', async () => {
  const { h, token, account } = await setup();
  google.add('slow', { account, raw: { purchaseState: 2 } });
  const pending = await verify(h, token, 'vila_pro_1y', 'slow');
  assert.equal(pending.status, 202); assert.equal(pending.data.pending, true);
  assert.equal((await call(h, '/api/social/auth/me', { token })).data.user.entitlement.plan, 'free');
  google.purchases.get('slow').purchaseState = 0;
  assert.equal((await verify(h, token, 'vila_pro_1y', 'slow')).status, 201);
  google.add('cancelled', { account, raw: { purchaseState: 1 } });
  assert.equal((await verify(h, token, 'vila_pro_1y', 'cancelled')).status, 402);
});

test('a purchase token cannot be claimed by another account (binding + one-token-one-account)', async () => {
  const { h, token, account } = await setup('alice');
  const bob = await register(h, 'bobby');
  google.add('alice-token', { account });
  const stolen = await verify(h, bob.data.token, 'vila_pro_1y', 'alice-token');
  assert.equal(stolen.status, 403, 'Google says it was bought for another account');
  assert.equal((await call(h, '/api/social/auth/me', { token: bob.data.token })).data.user.entitlement.plan, 'free');
  assert.equal((await verify(h, token, 'vila_pro_1y', 'alice-token')).status, 201);
  const afterGrant = await verify(h, bob.data.token, 'vila_pro_1y', 'alice-token');
  assert.equal(afterGrant.status, 409, 'once recorded, the token is locked to the first account');
  assert.equal((await call(h, '/api/social/auth/me', { token: bob.data.token })).data.user.entitlement.plan, 'free');
});

test('purchases without our account binding are rejected (not bought through the app)', async () => {
  const { h, token } = await setup();
  google.add('no-binding', { account: '' });
  assert.equal((await verify(h, token, 'vila_pro_1y', 'no-binding')).status, 403);
});

test('same Google order under a different token is not granted twice', async () => {
  const { h, token, account } = await setup();
  google.add('a', { account, orderId: 'GPA.same' }); google.add('b', { account, orderId: 'GPA.same' });
  assert.equal((await verify(h, token, 'vila_pro_1y', 'a')).status, 201);
  assert.equal((await verify(h, token, 'vila_pro_1y', 'b')).status, 409);
});

test('Google outage never grants and never loses the purchase (client retries later)', async () => {
  const { h, token, account } = await setup();
  google.add('retry', { account }); google.failLookup = true;
  assert.equal((await verify(h, token, 'vila_pro_1y', 'retry')).status, 502);
  assert.equal((await call(h, '/api/social/auth/me', { token })).data.user.entitlement.plan, 'free');
  google.failLookup = false;
  assert.equal((await verify(h, token, 'vila_pro_1y', 'retry')).status, 201);
});

test('bad service-account signature is rejected by Google and nothing is granted', async () => {
  const other = await crypto.subtle.generateKey({ name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' }, true, ['sign', 'verify']);
  const badPem = `-----BEGIN PRIVATE KEY-----\n${Buffer.from(await crypto.subtle.exportKey('pkcs8', other.privateKey)).toString('base64')}\n-----END PRIVATE KEY-----`;
  const h = createHarness({ ...ENV, GOOGLE_SERVICE_ACCOUNT_JSON: JSON.stringify({ client_email: 'svc@vila.iam.gserviceaccount.com', private_key: badPem, token_uri: 'https://oauth2.test/token' }) });
  const u = await register(h, 'alice');
  const r = await verify(h, u.data.token, 'vila_pro_1y', 'x');
  assert.equal(r.status, 502); assert.equal(google.jwtOk, false);
});

test('refund: voided Pro removes only that purchase\'s year; voided Premium switches Premium off; sync is idempotent', async () => {
  const { h, token, account } = await setup();
  google.add('p1', { account }); google.add('p2', { account }); google.add('prem', { account, productId: 'vila_premium_lifetime' });
  for (const [prod, t] of [['vila_pro_1y', 'p1'], ['vila_pro_1y', 'p2'], ['vila_premium_lifetime', 'prem']]) assert.equal((await verify(h, token, prod, t)).status, 201);
  const admin = await adminToken(h);
  google.voided = ['p2'];
  let sync = await call(h, '/api/social/admin/billing/sync-voided', { method: 'POST', token: admin, body: {} });
  assert.deepEqual([sync.data.checked, sync.data.revoked], [1, 1]);
  let me = (await call(h, '/api/social/auth/me', { token })).data.user.entitlement;
  assert.equal(me.plan, 'premium'); assert.equal(me.daysLeft, 365, 'one of the two Pro years remains');
  sync = await call(h, '/api/social/admin/billing/sync-voided', { method: 'POST', token: admin, body: {} });
  assert.equal(sync.data.revoked, 0, 'second sync does nothing');
  google.voided = ['p2', 'prem', 'p1'];
  sync = await call(h, '/api/social/admin/billing/sync-voided', { method: 'POST', token: admin, body: {} });
  assert.equal(sync.data.revoked, 2);
  me = (await call(h, '/api/social/auth/me', { token })).data.user.entitlement;
  assert.equal(me.plan, 'free');
  assert.equal((await verify(h, token, 'vila_pro_1y', 'p1')).status, 409, 'a refunded token cannot be re-submitted');
  const log = (await call(h, '/api/social/admin/audit?limit=100', { token: admin })).data.events.map(e => e.action);
  assert.ok(log.includes('purchase_granted') && log.includes('purchase_voided'));
});

test('refund sync is admin-only and not reachable through the public /api/social prefix', async () => {
  const { h, token } = await setup();
  assert.equal((await call(h, '/api/social/admin/billing/sync-voided', { method: 'POST', token, body: {} })).status, 403);
  assert.equal((await call(h, '/api/social/admin/billing/sync-voided', { method: 'POST', body: {} })).status, 401);
  const cron = await call(h, '/api/social/__cron/sync-voided', { method: 'POST', body: {} });
  assert.equal(cron.status, 404, 'the cron-only route is not exposed to the outside');
});

test('scheduled(): the cron handler revokes refunded purchases', async () => {
  const { h, token, account } = await setup();
  google.add('c1', { account }); await verify(h, token, 'vila_pro_1y', 'c1');
  google.voided = ['c1'];
  await worker.scheduled({}, { ...ENV, CHESS_STATE: h.binding });
  assert.equal((await call(h, '/api/social/auth/me', { token })).data.user.entitlement.plan, 'free');
  await worker.scheduled({}, { CHESS_STATE: h.binding }); // unconfigured: silently does nothing
});

test('custom product ids and package name come from Worker variables', async () => {
  const h = createHarness({ ...ENV, PRO_PRODUCT_ID: 'my_pro', PREMIUM_PRODUCT_ID: 'my_premium' });
  const u = await register(h, 'alice');
  const c = (await cfg(h, u.data.token)).data;
  assert.deepEqual(c.products, { pro: 'my_pro', premium: 'my_premium', diamond: 'vila_diamond_1y' });
  google.add('x', { account: c.accountId, productId: 'my_pro' });
  assert.equal((await verify(h, u.data.token, 'my_pro', 'x')).status, 201);
  assert.equal((await verify(h, u.data.token, 'vila_pro_1y', 'x')).status, 400, 'default ids no longer accepted');
});

test('end to end: app purchase queue -> Worker -> Google (fake) -> plan active, native told to consume/acknowledge', async () => {
  const { createPurchaseQueue } = await import('../src/billing-client.js');
  const { h, token, account } = await setup();
  const finished = [];
  const api = async (path, opts = {}) => {
    const r = await call(h, `/api/social${path}`, { method: opts.method || 'GET', token, ...(opts.body ? { body: JSON.parse(opts.body) } : {}) });
    if (r.status >= 400) throw Object.assign(new Error(r.data.error), { status: r.status });
    return r.data;
  };
  const results = [], errors = [];
  const queue = createPurchaseQueue({ api, getBridge: () => ({ finish: (t, c) => finished.push([t, c]) }), onResult: r => results.push(r), onError: e => errors.push(e.status) });
  google.add('pro-e2e', { account }); google.add('prem-e2e', { account, productId: 'vila_premium_lifetime' });
  await queue.push({ productId: 'vila_pro_1y', purchaseToken: 'pro-e2e' });
  assert.equal(results[0].entitlement.plan, 'pro');
  await queue.push({ productId: 'vila_premium_lifetime', purchaseToken: 'prem-e2e' });
  assert.equal(results[1].entitlement.plan, 'premium');
  assert.deepEqual(finished, [['pro-e2e', true], ['prem-e2e', false]]);
  await queue.push({ productId: 'vila_pro_1y', purchaseToken: 'forged' });
  assert.deepEqual(errors, [404]);
  assert.equal(finished.length, 2, 'the forged token was never consumed or acknowledged');
});
