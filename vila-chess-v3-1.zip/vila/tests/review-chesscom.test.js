import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { evalBarWhitePercent, reviewPhaseOfPosition, computeReviewPhases, accuracyGrade, coachMessage, REVIEW_PHASE_LABELS } from '../src/game-review.js';
import { layers, buildProfessionalCss } from '../scripts/build-professional-css.mjs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('eval bar share stays inside 4–96 for centipawns and snaps to the edge for mate', () => {
  assert.equal(evalBarWhitePercent(0), 50);
  assert.ok(evalBarWhitePercent(300) > 70 && evalBarWhitePercent(300) <= 96);
  assert.equal(evalBarWhitePercent(2000), 96);
  assert.equal(evalBarWhitePercent(-2000), 4);
  assert.equal(evalBarWhitePercent(9990, 'mate'), 100);
  assert.equal(evalBarWhitePercent(-9990, 'mate'), 0);
  assert.equal(evalBarWhitePercent(null), 50);
});

test('game phases: first ten moves are opening, thin material is endgame', () => {
  assert.equal(reviewPhaseOfPosition('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w', 4), 'opening');
  assert.equal(reviewPhaseOfPosition('r1bq1rk1/ppp2ppp/2n5/3p4/3P4/2N5/PPP2PPP/R1BQ1RK1 w', 30), 'middlegame');
  assert.equal(reviewPhaseOfPosition('8/5pk1/6p1/8/8/6P1/5PK1/3R4 w', 50), 'endgame');
});

test('phase accuracy ignores unrated rows and grades each side separately', () => {
  const rows = [
    { ply: 1, mover: 'w', scoreBeforeWhiteCp: 20, scoreWhiteCp: 20 },
    { ply: 2, mover: 'b', scoreBeforeWhiteCp: 20, scoreWhiteCp: 600 },
    { ply: 3, mover: 'w', scoreBeforeWhiteCp: null, scoreWhiteCp: 10 }
  ];
  const phases = computeReviewPhases(rows, ['a', 'b', 'c']);
  assert.equal(phases.opening.w.moves, 1);
  assert.equal(phases.opening.w.grade.key, 'best');
  assert.equal(phases.opening.b.grade.key, 'blunder');
  assert.equal(phases.middlegame.w, null);
  assert.deepEqual(Object.keys(REVIEW_PHASE_LABELS), ['opening', 'middlegame', 'endgame']);
  assert.equal(accuracyGrade(null).label, '—');
});

test('coach message names the move and its quality in Vietnamese', () => {
  assert.equal(coachMessage({ san: 'Nf3', judgement: { key: 'best' } }), 'Nf3 là nước tốt nhất');
  assert.equal(coachMessage({ san: 'Qh5', judgement: { key: 'blunder' } }), 'Qh5 là sai lầm nghiêm trọng');
  assert.equal(coachMessage(null), '');
});

test('review screen wires the replay controls, share, slider and chart jump', () => {
  const main = read('src/main.js');
  for (const needle of ['reviewScreenMode', 'setReviewScreen', 'toggleReviewAutoplay', 'shareReviewPgn', 'safeReviewMarkup', 'syncReviewReplayChrome', 'reviewSlider']) {
    assert.ok(main.includes(needle), `main.js is missing ${needle}`);
  }
  assert.match(main, /setReviewScreen\('replay', 0\)/);
  assert.match(read('src/review-screen.js'), /data-graph-plies/);
});

test('review stylesheet covers every quality colour and stays in the bundle', () => {
  const css = read('src/review-screen.css');
  for (const key of ['brilliant', 'great', 'best', 'excellent', 'good', 'book', 'inaccuracy', 'mistake', 'missed-win', 'blunder']) {
    assert.ok(css.includes(`--rv-${key}:`), `no colour for ${key}`);
    assert.ok(css.includes(`.review-sq-${key} { --rv-c`), `no square tint for ${key}`);
  }
  assert.ok(layers.includes('review-screen.css'));
  assert.equal(read('src/vila-professional.css'), buildProfessionalCss());
});

test('repository stays LF-only and the Worker imports resolve (release sync check)', () => {
  assert.ok(fs.existsSync(new URL('../.gitattributes', import.meta.url)));
  const worker = read('cloudflare/src/index.js');
  assert.ok(!worker.includes('\r'), 'cloudflare/src/index.js must use LF line endings');
  for (const match of worker.matchAll(/from\s+['"](\.{1,2}\/[^'"]+)['"]/g)) {
    assert.ok(fs.existsSync(new URL(`../cloudflare/src/${match[1]}`, import.meta.url)), `Worker import ${match[1]} does not resolve`);
  }
});
