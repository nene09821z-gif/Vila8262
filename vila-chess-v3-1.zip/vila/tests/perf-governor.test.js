import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { summarizeFrames, decideTier, createPerfGovernor, PERF_KEY } from '../src/perf-governor.js';

const smooth = n => Array.from({ length: n }, () => 16.7);
const janky = n => Array.from({ length: n }, (_, i) => (i % 3 === 0 ? 70 : 17));

test('smooth 60 fps is not janky; stalls are', () => {
  const a = summarizeFrames(smooth(40));
  assert.equal(a.jankRatio, 0); assert.ok(a.fps > 55);
  const b = summarizeFrames(janky(40));
  assert.ok(b.jankRatio > 0.3 && b.p95Ms >= 70);
});

test('a 120 Hz or a naturally 30 fps device is judged against its own rhythm', () => {
  assert.equal(summarizeFrames(Array(40).fill(8.3)).jankRatio, 0);
  assert.equal(summarizeFrames(Array(40).fill(33.3)).jankRatio, 0);
});

test('lite needs two janky sessions of enough frames; never downgrades on thin data', () => {
  const bad = summarizeFrames(janky(30)); const good = summarizeFrames(smooth(30)); const thin = summarizeFrames(janky(5));
  assert.equal(decideTier([bad], 'full'), 'full');
  assert.equal(decideTier([bad, good, bad], 'full'), 'lite');
  assert.equal(decideTier([thin, thin, thin], 'full'), 'full');
  assert.equal(decideTier([good, good], 'lite'), 'lite');
});

function fakeEnv(search = '') {
  const frames = []; let id = 0; const store = new Map();
  const doc = { documentElement: { dataset: {} }, body: null, createElement: () => ({ style: {}, setAttribute() {} }) };
  const win = { location: { search } };
  return {
    doc, win, frames, store,
    storage: { getItem: k => store.get(k) ?? null, setItem: (k, v) => store.set(k, v) },
    raf: cb => { frames.push(cb); id += 1; return id; }, caf: () => {},
    run(deltas) { let t = 1000; for (const d of deltas) { t += d; const cb = frames.pop(); cb?.(t); } }
  };
}

test('governor switches to lite after two janky drags and remembers it', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf });
  assert.equal(gov.tier, 'full'); assert.equal(env.doc.documentElement.dataset.perf, 'full');
  for (let i = 0; i < 2; i += 1) { assert.ok(gov.begin('drag')); env.run(janky(31)); gov.end(); }
  assert.equal(gov.tier, 'lite'); assert.equal(env.doc.documentElement.dataset.perf, 'lite');
  assert.equal(env.store.get(PERF_KEY), 'lite');
  const next = createPerfGovernor({ win: env.win, doc: { documentElement: { dataset: {} } }, storage: env.storage, raf: env.raf, caf: env.caf });
  assert.equal(next.tier, 'lite');
});

test('smooth drags keep full; URL override wins and is not stored; labelled end is guarded', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf });
  for (let i = 0; i < 4; i += 1) { gov.begin('drag'); env.run(smooth(30)); gov.end(); }
  assert.equal(gov.tier, 'full');
  gov.begin('drag'); assert.equal(gov.end('slide'), null); assert.ok(gov.end('drag'));
  const forced = fakeEnv('?perf=lite');
  const g2 = createPerfGovernor({ win: forced.win, doc: forced.doc, storage: forced.storage, raf: forced.raf, caf: forced.caf });
  assert.equal(g2.tier, 'lite'); assert.equal(forced.store.has(PERF_KEY), false);
});

test('main.js wires the governor into drag and slide, and the lite layer is bundled', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /perfGovernor\.begin\('drag'\)/);
  assert.match(main, /perfGovernor\.begin\('slide'\)/);
  assert.ok((main.match(/perfGovernor\.end\(/g) || []).length >= 3);
  const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');
  assert.match(css, /html\[data-perf="lite"\]/);
});
