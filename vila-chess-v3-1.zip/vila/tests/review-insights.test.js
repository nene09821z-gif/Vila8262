import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildAnnotatedPgn } from '../src/review-insights.js';

const SANS = ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Nxd5', 'Nxf7', 'Kxf7', 'Qf3+', 'Ke6', 'Nc3', 'Ncb4'];
// evaluation after each ply, white perspective (cp)
const EVAL = [30, 25, 35, 30, 40, 35, 60, 20, 90, 0, -250, 120, 180, 150, 600, 700];
const judgement = { 11: 'blunder', 10: 'mistake', 9: 'great', 15: 'brilliant', 7: 'inaccuracy', 12: 'mistake' };
function rows() {
  return SANS.map((san, i) => ({
    ply: i + 1, mover: i % 2 === 0 ? 'w' : 'b', san,
    scoreBeforeWhiteCp: i ? EVAL[i - 1] : 20, scoreWhiteCp: EVAL[i], scoreType: 'cp',
    judgement: judgement[i + 1] ? { key: judgement[i + 1], label: judgement[i + 1] } : { key: 'good', label: 'Tốt' },
    bestMoveSan: 'Qe2', moveWasBest: false
  }));
}

test('annotated PGN carries headers, NAGs, evals and the better move', () => {
  const pgn = buildAnnotatedPgn(rows(), { headers: { White: 'An', Black: 'Bình' }, result: '1-0' });
  assert.match(pgn, /\[White "An"\]/); assert.match(pgn, /\[Result "1-0"\]/);
  const flat = pgn.replace(/\s+/g, ' ');
  assert.match(flat, /6\. Nxf7 \$4 \{ \[%eval -2\.50\] · blunder · Nên đi: Qe2 \}/);
  assert.match(flat, /8\. Nc3 \$3 \{[^}]*Nước thiên tài/);
  assert.match(flat, /1\. e4 \{ \[%eval 0\.30\] \} 1\.\.\. e5/);
  assert.match(pgn.trim(), /1-0$/);
  const quoted = buildAnnotatedPgn(rows(), { headers: { White: 'Nguy"ễn' } });
  assert.match(quoted, /\[White "Nguy\\"ễn"\]/);
  const custom = buildAnnotatedPgn(rows(), { startFen: '8/8/8/8/8/8/8/K6k w - - 0 1' });
  assert.match(custom, /\[SetUp "1"\]/); assert.match(custom, /\[FEN "8\/8\/8\/8\/8\/8\/8\/K6k w - - 0 1"\]/);
  assert.ok(!/ } }/.test(pgn));
});

test('annotated PGN stops at the first gap and handles mate evals', () => {
  const r = rows(); r.splice(5, 1);
  const pgn = buildAnnotatedPgn(r, {});
  assert.doesNotMatch(pgn, /Nxf7/);
  const mate = [{ ply: 1, mover: 'w', san: 'Qh5#', scoreWhiteCp: 10000, scoreType: 'mate', mateWhite: 0, judgement: { key: 'best' } }];
  assert.match(buildAnnotatedPgn(mate, {}), /\[%eval #0\]/);
});

