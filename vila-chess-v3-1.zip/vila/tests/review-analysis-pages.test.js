import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const screen = readFileSync(new URL('../src/review-screen.js', import.meta.url), 'utf8');

test('menu keeps only the Game Review destination (the old Analysis page is gone)', () => {
  assert.doesNotMatch(html, /data-view="coach"/);
  assert.match(html, /data-view="review"[^>]*>.*Xem lại ván \(Game Review\)/);
});

test('Game Review shows a game picker (recent games + PGN paste) when no finished game is loaded', () => {
  assert.match(main, /function reviewHasGame\(\)/);
  assert.match(main, /function renderReviewView\(\) \{\n  if \(!reviewHasGame\(\)\) return renderReviewLanding\(\);/);
  for (const id of ['reviewPgnInput', 'reviewPgnLoad', 'reviewPgnAnalyze', 'reviewBackHome', 'reviewLandingHistory']) {
    assert.ok(screen.includes(`id="${id}"`), `landing is missing #${id}`);
  }
  assert.match(main, /function wireReviewActions\(\) \{\n  if \(!reviewHasGame\(\)\) \{ wireReviewLanding\(\); return; \}/);
});

test('PGN import validates input, bounds its size and never silently replaces a live game', () => {
  const start = main.indexOf('function importPgnForReview(');
  const body = main.slice(start, main.indexOf('function wireReviewLanding()', start));
  assert.match(body, /60000/);
  assert.match(body, /probe\.loadPgn\(pgn\)/);
  assert.match(body, /PGN không hợp lệ/);
  assert.match(body, /confirmLeaveLiveGame\(\)/);
  assert.match(main, /function confirmLeaveLiveGame\(\)[\s\S]*window\.confirm/);
  assert.doesNotMatch(body, /innerHTML/, 'imported PGN text must never be written as HTML');
});

test('landing cards escape saved-game text', () => {
  const start = main.indexOf('function renderReviewLanding()');
  const body = main.slice(start, main.indexOf('function confirmLeaveLiveGame()', start));
  assert.match(body, /esc\(record\.title/);
  assert.match(body, /esc\(record\.id\)/);
  assert.match(body, /landingMarkup\(/);
});
