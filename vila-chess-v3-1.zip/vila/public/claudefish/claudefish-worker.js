/* ClaudeFish worker (WebAssembly, một luồng, KHÔNG dùng Stockfish).
 *
 * Nói UCI qua postMessage(string) / onmessage giống stockfish-10.js nên cắm thẳng vào LegacyUciEngine.
 * Engine là cf-engine.wasm (WASI, không cần emscripten): xuất cf_init / cf_newgame / cf_io / cf_usenn / cf_best.
 * Mọi lệnh được xử lý tuần tự (hàng đợi promise) nên `position` + `go` luôn đúng thứ tự dù wasm đang nạp. */
'use strict';
let x = null, mem = null, loading = null;
let fen = '';
const HASH_MB = 8;
const enc = new TextEncoder(), dec = new TextDecoder();
const dv = () => new DataView(mem.buffer);

const wasi = {
  environ_sizes_get: (a, b) => { dv().setUint32(a, 0, true); dv().setUint32(b, 0, true); return 0; },
  environ_get: () => 0,
  args_sizes_get: (a, b) => { dv().setUint32(a, 0, true); dv().setUint32(b, 0, true); return 0; },
  args_get: () => 0,
  clock_time_get: (id, prec, out) => {
    dv().setBigUint64(out, BigInt(Math.round((id === 0 ? Date.now() : performance.now()) * 1e6)), true); return 0;
  },
  fd_close: () => 0, fd_seek: () => 0, fd_fdstat_get: () => 0, fd_prestat_get: () => 8, fd_prestat_dir_name: () => 0,
  fd_write: (fd, iovs, n, nw) => {   // engine im lặng; nuốt hết đầu ra
    let t = 0; for (let i = 0; i < n; i++) t += dv().getUint32(iovs + i * 8 + 4, true);
    dv().setUint32(nw, t, true); return 0;
  },
  proc_exit: code => { throw new Error('engine thoát ' + code); },
  random_get: (p, n) => { const u = new Uint8Array(mem.buffer, p, n); for (let i = 0; i < n; i++) u[i] = (Math.random() * 256) | 0; return 0; }
};

async function load() {
  const url = new URL('cf-engine.wasm', self.location.href).href;
  const res = await fetch(url);
  if (!res.ok) throw new Error('không tải được cf-engine.wasm (HTTP ' + res.status + ')');
  const module = await WebAssembly.compile(await res.arrayBuffer());
  const imports = { wasi_snapshot_preview1: wasi };
  for (const im of WebAssembly.Module.imports(module)) {   // import lạ (tuỳ bản dựng) → trả "không hỗ trợ" thay vì lỗi nạp
    if (im.kind !== 'function') continue;
    imports[im.module] = imports[im.module] || {};
    if (!imports[im.module][im.name]) imports[im.module][im.name] = () => 52;
  }
  const instance = await WebAssembly.instantiate(module, imports);
  x = instance.exports; mem = x.memory;
  if (x._initialize) x._initialize();
  for (const name of ['cf_init', 'cf_newgame', 'cf_io', 'cf_best']) {
    if (typeof x[name] !== 'function') throw new Error('cf-engine.wasm thiếu hàm ' + name);
  }
  x.cf_init(HASH_MB);
}
function ensureLoaded() { return loading || (loading = load()); }

function search(ms, depth) {
  const io = x.cf_io(), b = enc.encode(fen);
  if (b.length > 400) return { error: 'FEN quá dài' };
  const u = new Uint8Array(mem.buffer, io, 512); u.set(b); u[b.length] = 0;
  const sc = x.cf_best(ms | 0, depth | 0);
  if (sc === -100000) return { error: 'FEN không hợp lệ' };
  if (sc === -100001) return { error: 'không còn nước đi hợp lệ' };
  const out = new Uint8Array(mem.buffer, io, 512); let e = 0; while (out[e]) e++;
  return { move: dec.decode(out.subarray(0, e)), score: sc };
}

async function handle(line) {
  const cmd = line.split(/\s+/)[0];
  if (cmd === 'uci') {
    await ensureLoaded();
    postMessage('id name ClaudeFish (WebAssembly)');
    postMessage('id author Claude');
    postMessage('option name UseNNUE type check default false');
    postMessage('uciok');
  } else if (cmd === 'isready') {
    await ensureLoaded();
    postMessage('readyok');
  } else if (cmd === 'ucinewgame') {
    await ensureLoaded(); x.cf_newgame();
  } else if (cmd === 'setoption') {
    const m = line.match(/^setoption\s+name\s+(.+?)\s+value\s+(\S+)/i);
    if (m && /^(usenn|nnue|usennue)$/i.test(m[1].replace(/\s+/g, '')) && x && x.cf_usenn) x.cf_usenn(/^(true|1|on)$/i.test(m[2]) ? 1 : 0);
    // Skill Level / Hash / Threads / MultiPV: ClaudeFish không có → bỏ qua (arena cấp cùng thời gian + độ sâu cho mọi engine)
  } else if (cmd === 'position') {
    const m = line.match(/^position\s+fen\s+(.+?)(?:\s+moves\b.*)?$/i);
    if (m) fen = m[1].trim();
    else if (/^position\s+startpos\s*$/i.test(line)) fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
    else postMessage('info string claudefish: chỉ hỗ trợ "position fen <FEN>"');
  } else if (cmd === 'go') {
    await ensureLoaded();
    const ms = Number(line.match(/\bmovetime\s+(\d+)/i)?.[1]) || 1000;
    const depth = Number(line.match(/\bdepth\s+(\d+)/i)?.[1]) || 0;
    const r = search(Math.max(20, ms), Math.min(60, depth));
    if (r.error) { postMessage('info string claudefish: ' + r.error); postMessage('bestmove 0000'); return; }
    const cp = Math.max(-30000, Math.min(30000, r.score));
    postMessage(`info depth 0 score cp ${cp} pv ${r.move}`);   // wasm không báo độ sâu đạt được → 0
    postMessage('bestmove ' + r.move);
  }
  // `stop`, `quit`, ...: tìm kiếm chạy đồng bộ theo movetime nên không có gì để ngắt
}

let chain = Promise.resolve();
self.onmessage = event => {
  const data = event && event.data;
  const text = typeof data === 'string' ? data : String(data && data.data !== undefined ? data.data : data);
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    chain = chain.then(() => handle(line)).catch(err => {
      // Lỗi nạp wasm → ném ra ngoài để Worker.onerror báo ngay (LegacyUciEngine đổi sang engine dự phòng), không chờ hết hạn.
      const text = 'ClaudeFish: ' + (err && err.message || err);
      postMessage('info string ' + text);
      setTimeout(() => { throw new Error(text); }, 0);
    });
  }
};
