import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { timingSafeEqual } from 'node:crypto';
import { createSocialRouter } from './social.js';
import { createPuzzleService } from './puzzle-service.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Permitted-Cross-Domain-Policies', 'none');
  if (req.path.startsWith('/api/')) {
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', "default-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'");
  }
  if (req.secure) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
// When running behind a trusted local reverse proxy, honor the forwarded client IP so
// per-IP rate limits apply to the real client instead of one shared bucket for all players.
if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);
else if (process.env.TRUST_PROXY !== '0') app.set('trust proxy', 'loopback');
const CORS_ORIGINS = [...new Set([
  'capacitor://localhost', 'https://localhost', 'ionic://localhost',
  ...(process.env.NODE_ENV === 'production' ? [] : ['http://localhost', 'http://localhost:5173', 'http://127.0.0.1:5173']),
  ...String(process.env.CORS_ORIGIN || '').split(',')
].map(value => value.trim()).filter(Boolean))];
const ACCESS_SECRET = process.env.TUBOR_ACCESS_TOKEN || '';
app.use('/api', (req, res, next) => {
  const origin = req.headers.origin;
  // Trình duyệt luôn gửi Origin cho POST/PATCH, kể cả khi app được chính server này phục vụ (cùng nguồn).
  // Cùng nguồn không phải yêu cầu chéo nguồn nên không được chặn nhầm khi CORS_ORIGIN chưa liệt kê tên miền của chính server.
  const sameOrigin = Boolean(origin && req.headers.host && origin === `${req.protocol}://${req.headers.host}`);
  if (origin && !sameOrigin && !CORS_ORIGINS.includes(origin)) return res.status(403).json({ error: 'Origin chưa được cho phép.' });
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Max-Age', '600');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  // Social endpoints use their own per-user signed session token. Do not make
  // sign-up/login depend on a shared secret embedded in the app.
  if (req.path.startsWith('/social/') || req.path.startsWith('/puzzles/')) return next();
  if (ACCESS_SECRET && req.path !== '/health') {
    const supplied = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const a = Buffer.from(supplied);
    const b = Buffer.from(ACCESS_SECRET);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(401).json({ error: 'Backend yêu cầu mã truy cập hợp lệ.' });
  }
  next();
});

// Throttle expensive proxy paths before reading/parsing request bodies.
const externalProxyBuckets = new Map();
function externalProxyLimit({ name, max, windowMs }) {
  return (req, res, next) => {
    const now = Date.now();
    const key = `${name}:${req.ip || req.socket?.remoteAddress || 'unknown'}`;
    const old = externalProxyBuckets.get(key);
    const bucket = !old || now - old.start >= windowMs ? { start: now, count: 0 } : old;
    bucket.count += 1;
    externalProxyBuckets.set(key, bucket);
    if (externalProxyBuckets.size > 5000) {
      for (const [entry, value] of externalProxyBuckets) if (now - value.start > windowMs) externalProxyBuckets.delete(entry);
      while (externalProxyBuckets.size > 5000) externalProxyBuckets.delete(externalProxyBuckets.keys().next().value);
    }
    if (bucket.count > max) {
      res.setHeader('Retry-After', String(Math.max(1, Math.ceil((windowMs - (now - bucket.start)) / 1000))));
      return res.status(429).json({ error: 'Quá nhiều yêu cầu tới dịch vụ tích hợp. Hãy thử lại sau.' });
    }
    next();
  };
}
app.use('/api/lichess', externalProxyLimit({ name: 'lichess-proxy', max: 20, windowMs: 60_000 }));
app.use('/api/openings/explorer', externalProxyLimit({ name: 'opening-proxy', max: 30, windowMs: 60_000 }));
app.use('/api/puzzles/next', externalProxyLimit({ name: 'puzzle-proxy', max: 30, windowMs: 60_000 }));

app.use(express.json({ limit: '1mb' }));

const PORT = Number(process.env.PORT || 8787);
// Bind only to loopback by default. Public deployments require an access token.
const HOST = process.env.HOST || (process.env.NODE_ENV === 'production' ? '0.0.0.0' : '127.0.0.1');
const isLoopbackHost = ['127.0.0.1', 'localhost', '::1'].includes(HOST.toLowerCase());
if (!isLoopbackHost && (!ACCESS_SECRET || Buffer.byteLength(ACCESS_SECRET, 'utf8') < 32 || ACCESS_SECRET.startsWith('REPLACE_'))) {
  console.error('[VILA] Refusing to expose the backend publicly without a real TUBOR_ACCESS_TOKEN of at least 32 bytes. Replace the sample secret in .env.');
  process.exit(1);
}

function sendUpstreamError(res, status, message) {
  return res.status(status).json({ error: message || 'Dịch vụ bên ngoài trả về lỗi.' });
}
function cleanString(value, max = 8000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Cờ Vua ViLa', version: '3.69.1', capabilities: ['offline-stockfish', 'stockfish10-arena-with-fallback', 'self-hosted-puzzle-proxy', 'offline-puzzles', 'lichess-daily-puzzle-cache', 'game-review-analysis-report', 'open-piece-sets', 'offline-mini-games', 'persistent-messenger', 'admin-purchase-queue', 'rate-limited-plan-requests'] }));

const puzzleService = createPuzzleService();
app.get('/api/puzzles/next', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try { res.json(await puzzleService.next(req.query.difficulty)); }
  catch (error) { res.status(502).json({ error: `Máy chủ câu đố: ${String(error?.message || error).slice(0, 260)}` }); }
});
app.get('/api/puzzles/daily', async (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300, stale-while-revalidate=60');
  try { res.json(await puzzleService.daily()); }
  catch (error) { res.status(502).json({ error: `Máy chủ câu đố: ${String(error?.message || error).slice(0, 260)}` }); }
});

// Persistent community accounts, friends, Top 100, and owner-only admin tools.
// The store lives outside public/static assets and must be included in backups.
app.use('/api/social', await createSocialRouter({ dataDir: path.join(root, 'data') }));

async function lichessRequest(pathname, token, options = {}) {
  const cleanToken = cleanString(token, 4000);
  if (!cleanToken) throw new Error('Hãy nhập Lichess personal access token. Token không được gửi vào mã nguồn công khai.');
  return fetch(`https://lichess.org${pathname}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${cleanToken}`,
      Accept: options.accept || 'application/json',
      ...(options.method === 'POST' ? { 'Content-Type': 'application/x-www-form-urlencoded' } : {}),
      ...(options.headers || {})
    },
    signal: options.signal || AbortSignal.timeout(30000)
  });
}

app.post('/api/lichess/account', async (req, res) => {
  try {
    const upstream = await lichessRequest('/api/account', req.body?.token);
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, username: data.username, title: data.title || '', perfs: data.perfs || {} });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-ai', async (req, res) => {
  try {
    const level = Math.max(1, Math.min(8, Number(req.body?.level || 3)));
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ level: String(level), 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random' });
    const upstream = await lichessRequest('/api/challenge/ai', req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.id, url: data.url, color: data.color, status: data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/challenge-user', async (req, res) => {
  try {
    const username = cleanString(req.body?.username, 80).replace(/^@/, '');
    if (!/^[a-zA-Z0-9_-]{2,30}$/.test(username)) return res.status(400).json({ error: 'Tên người chơi Lichess không hợp lệ.' });
    const limit = Math.max(0, Math.min(10800, Number(req.body?.clockLimit || 300)));
    const increment = Math.max(0, Math.min(180, Number(req.body?.clockIncrement || 0)));
    const form = new URLSearchParams({ rated: 'false', 'clock.limit': String(limit), 'clock.increment': String(increment), color: ['white', 'black', 'random'].includes(req.body?.color) ? req.body.color : 'random', variant: 'standard' });
    const upstream = await lichessRequest(`/api/challenge/${encodeURIComponent(username)}`, req.body?.token, { method: 'POST', body: form.toString() });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Lichess HTTP ${upstream.status}`);
    res.json({ id: data.challenge?.id || data.id, url: data.challenge?.url || data.url, status: data.challenge?.status || data.status, raw: data });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/move', async (req, res) => {
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    const move = cleanString(req.body?.move, 10);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(move)) return res.status(400).json({ error: 'Nước đi phải ở định dạng UCI, ví dụ e2e4.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/${gameId}/move/${move}` : `/api/board/game/${gameId}/move/${move}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'POST', body: '' });
    const text = await upstream.text();
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, text || `Lichess HTTP ${upstream.status}`);
    res.json({ ok: true, response: text });
  } catch (error) { res.status(400).json({ error: String(error.message || error) }); }
});

app.post('/api/lichess/stream', async (req, res) => {
  const upstreamController = new AbortController();
  let upstreamStream = null;
  // Aborting the response must also abort the fetch. Calling body.cancel()
  // after Readable.fromWeb locks the WebStream is not reliable.
  const abortUpstream = () => {
    if (!upstreamController.signal.aborted) upstreamController.abort();
    if (upstreamStream && !upstreamStream.destroyed) upstreamStream.destroy();
  };
  res.once('close', abortUpstream);
  try {
    const gameId = cleanString(req.body?.gameId, 100);
    if (!/^[a-zA-Z0-9]{8}$/.test(gameId)) return res.status(400).json({ error: 'Mã ván Lichess không hợp lệ.' });
    const apiMode = req.body?.apiMode === 'bot' ? 'bot' : 'board';
    const route = apiMode === 'bot' ? `/api/bot/game/stream/${gameId}` : `/api/board/game/stream/${gameId}`;
    const upstream = await lichessRequest(route, req.body?.token, { method: 'GET', accept: 'application/x-ndjson', signal: upstreamController.signal });
    if (upstreamController.signal.aborted) return;
    if (!upstream.ok || !upstream.body) {
      const message = await upstream.text().catch(() => 'Lichess không mở được luồng ván cờ.');
      if (!res.destroyed) return sendUpstreamError(res, upstream.status || 502, message.slice(0, 500));
      return;
    }
    res.status(200);
    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection', 'keep-alive');
    upstreamStream = Readable.fromWeb(upstream.body);
    upstreamStream.on('error', error => {
      if (upstreamController.signal.aborted || res.destroyed) return;
      if (!res.headersSent) res.status(502).json({ error: `Luồng Lichess bị lỗi: ${String(error.message || error).slice(0, 300)}` });
      else res.destroy(error);
    });
    upstreamStream.pipe(res);
  } catch (error) {
    if (upstreamController.signal.aborted || error?.name === 'AbortError' || res.destroyed) return;
    if (!res.headersSent) res.status(400).json({ error: String(error.message || error) });
    else res.destroy(error);
  }
});

app.get('/api/openings/explorer', async (req, res) => {
  try {
    const moves = cleanString(req.query.moves, 1000).split(',').filter(Boolean).slice(0, 40);
    if (moves.some(m => !/^[a-h][1-8][a-h][1-8][qrbn]?$/i.test(m))) return res.status(400).json({ error: 'Danh sách nước UCI không hợp lệ.' });
    const url = new URL('https://explorer.lichess.ovh/lichess');
    url.searchParams.set('variant', 'standard');
    url.searchParams.set('speeds[]', 'blitz');
    url.searchParams.set('ratings[]', '1600');
    url.searchParams.set('moves', moves.join(','));
    const upstream = await fetch(url, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(20000) });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return sendUpstreamError(res, upstream.status, data?.error || `Opening Explorer HTTP ${upstream.status}`);
    res.json(data);
  } catch (error) { res.status(502).json({ error: `Không lấy được dữ liệu khai cuộc: ${String(error.message || error)}` }); }
});

app.use((error, _req, res, _next) => {
  const status = Number(error?.status || error?.statusCode) || 500;
  if (status >= 500) console.error('[VILA API] Request failed:', String(error?.message || error).slice(0, 240));
  if (res.headersSent) return res.end();
  if (status === 413) return res.status(413).json({ error: 'Nội dung yêu cầu quá lớn.' });
  if (status === 400) return res.status(400).json({ error: 'Yêu cầu JSON không hợp lệ.' });
  return res.status(500).json({ error: 'Lỗi máy chủ nội bộ. Vui lòng thử lại sau.' });
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(root, 'dist')));
  app.get('/{*splat}', (_req, res) => res.sendFile(path.join(root, 'dist', 'index.html')));
}

const httpServer = app.listen(PORT, HOST, () => {
  console.log(`[Cờ Vua ViLa] API server listening on http://${HOST}:${PORT}`);
  if (process.env.NODE_ENV === 'production') console.log('[Cờ Vua ViLa] Production mode: serving dist/');
});

let shutdownStarted = false;
function gracefulShutdown(reason, exitCode = 0) {
  if (shutdownStarted) return;
  shutdownStarted = true;
  console.error(`[Cờ Vua ViLa] Shutdown requested (${reason}); closing HTTP listener.`);
  const hardStop = setTimeout(() => process.exit(exitCode || 1), 10_000);
  hardStop.unref();
  httpServer.close(() => { clearTimeout(hardStop); process.exit(exitCode); });
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('unhandledRejection', reason => {
  console.error('[Cờ Vua ViLa] Unhandled promise rejection; terminating so the process manager can restart safely:', reason);
  gracefulShutdown('unhandledRejection', 1);
});
process.on('uncaughtException', error => {
  console.error('[Cờ Vua ViLa] Uncaught exception; terminating so the process manager can restart safely:', error);
  gracefulShutdown('uncaughtException', 1);
});
