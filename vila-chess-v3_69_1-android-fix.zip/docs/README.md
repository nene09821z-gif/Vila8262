# Tài liệu ViLa Chess

Mục lục tự sinh từ thư mục `docs/`. Tài liệu chính ở gốc dự án: [README](../README.md) và [CHANGELOG](../CHANGELOG.md).

## Hướng dẫn cài đặt, triển khai, bảo mật

- [BILLING_SETUP_VI](guides/BILLING_SETUP_VI.md) — Thanh toán Google Play (cách A: mua một lần)
- [BUILD_ANDROID_GITHUB](guides/BUILD_ANDROID_GITHUB.md) — Build APK Cờ Vua ViLa v3.52.0 bằng GitHub Actions
- [ENGINE_HUB_SETUP](guides/ENGINE_HUB_SETUP.md) — Hồ sơ engine và bot của Cờ Vua ViLa
- [MONETIZATION](guides/MONETIZATION.md) — Cờ Vua ViLa — nhiệm vụ, phần thưởng ảo và nguyên tắc thương mại
- [MUSIC_CREDITS](guides/MUSIC_CREDITS.md) — Music source and release note
- [ONLINE_MATCHMAKING_DEPLOYMENT](guides/ONLINE_MATCHMAKING_DEPLOYMENT.md) — ViLa Chess — triển khai ghép trận Internet
- [PUZZLES_SOURCE](guides/PUZZLES_SOURCE.md) — Nguồn câu đố cờ vua — VILA Chess v3.69.1
- [PUZZLE_PACK_VI](guides/PUZZLE_PACK_VI.md) — Kho câu đố tích hợp: dựng kho từ Lichess và kiểm chứng bằng Stockfish
- [README_COMMERCIAL](guides/README_COMMERCIAL.md) — ViLa Chess Professional Edition v3.67.0
- [README_FULL_FIXED](guides/README_FULL_FIXED.md) — Cờ Vua ViLa v3.50.4 COMPLETE
- [README_SMOOTH_BOARD](guides/README_SMOOTH_BOARD.md) — Co Vua ViLa v3.52.0 — Smooth Board
- [SECURITY_HARDENING_V3_68](guides/SECURITY_HARDENING_V3_68.md) — VILA Chess — Security Hardening Patch
- [STOCKFISH_ANDROID_INTEGRATION](guides/STOCKFISH_ANDROID_INTEGRATION.md) — Stockfish Android ARM64 integration
- [TRIAL_CODES_SETUP_V3_65](guides/TRIAL_CODES_SETUP_V3_65.md) — VILA Chess v3.65.0 — thiết lập mã dùng thử

## Nhật ký thay đổi từng phiên bản (cũ)

- [CHANGELOG_V3_53](changelogs/CHANGELOG_V3_53.md) — v3.53 (from 3.52.1)
- [CHANGELOG_V3_54](changelogs/CHANGELOG_V3_54.md) — v3.54 (from 3.53)
- [CHANGELOG_V3_55](changelogs/CHANGELOG_V3_55.md) — v3.55 (from 3.54)
- [CHANGELOG_V3_56](changelogs/CHANGELOG_V3_56.md) — v3.56.0 (from 3.55)
- [CHANGELOG_V3_58_SOCIAL_PROFILE](changelogs/CHANGELOG_V3_58_SOCIAL_PROFILE.md) — ViLa Chess — Social/profile update
- [CHANGELOG_V3_59_DAILY_RANKED](changelogs/CHANGELOG_V3_59_DAILY_RANKED.md) — ViLa Chess v3.59 — Daily Ranked 1d
- [CHANGELOG_V3_62_MALL_HUB](changelogs/CHANGELOG_V3_62_MALL_HUB.md) — ViLa Chess v3.62 — Trung tâm VILA (home hub)
- [CHANGELOG_V3_62_PROFESSIONAL_UI](changelogs/CHANGELOG_V3_62_PROFESSIONAL_UI.md) — ViLa Chess v3.62.0 — Professional UI
- [CHANGELOG_V3_68_PUZZLES](changelogs/CHANGELOG_V3_68_PUZZLES.md) — Câu đố cờ — nâng cấp luyện tập thích ứng

## Báo cáo kiểm thử & QA theo phiên bản

- [FIX_REPORT_V3_52_0_SOCIAL_TEST](reports/FIX_REPORT_V3_52_0_SOCIAL_TEST.md) — Báo cáo sửa lỗi CI — VILA Chess Pro v3.52.0
- [NO_TERMUX_PATCH_REPORT](reports/NO_TERMUX_PATCH_REPORT.md) — Báo cáo bản vá — ViLa Chess Internet matchmaking
- [PUZZLE_INTEGRATION_QA_V3_68](reports/PUZZLE_INTEGRATION_QA_V3_68.md) — VILA Chess — Puzzle training integration QA
- [TEST_FIX_292_REPORT](reports/TEST_FIX_292_REPORT.md) — VILA Chess v3.67.0 — Test 292 correction
- [TEST_REPORT_ARENA_4_OPENINGS](reports/TEST_REPORT_ARENA_4_OPENINGS.md) — Test report — VILA Chess Arena: 4 khai cuộc riêng mỗi bot
- [TEST_REPORT_ARENA_ELO500](reports/TEST_REPORT_ARENA_ELO500.md) — Báo cáo kiểm thử — Elo 500, bot VILA, Đấu trường AI
- [TEST_REPORT_ARENA_FAIR_PLAY](reports/TEST_REPORT_ARENA_FAIR_PLAY.md) — Báo cáo kiểm thử — AI Arena toàn lực và công bằng
- [TEST_REPORT_MOUSE_HAND_ARROWS](reports/TEST_REPORT_MOUSE_HAND_ARROWS.md) — Báo cáo kiểm thử — Chuột ảo, nhận diện tay và mũi tên phân tích
- [TEST_REPORT_PUZZLE_QUALITY](reports/TEST_REPORT_PUZZLE_QUALITY.md) — Báo cáo rà soát chất lượng câu đố — 21/10/2026
- [TEST_REPORT_V3_45_0](reports/TEST_REPORT_V3_45_0.md) — Cờ Vua ViLa v3.45.0 — báo cáo kiểm tra
- [TEST_REPORT_V3_46_0](reports/TEST_REPORT_V3_46_0.md) — Kiểm thử Cờ Vua ViLa v3.46.0
- [TEST_REPORT_V3_46_1](reports/TEST_REPORT_V3_46_1.md) — Báo cáo kiểm thử Cờ Vua ViLa v3.46.1
- [TEST_REPORT_V3_46_2](reports/TEST_REPORT_V3_46_2.md) — Test report — Cờ Vua ViLa v3.46.2
- [TEST_REPORT_V3_46_3](reports/TEST_REPORT_V3_46_3.md) — Test report — Cờ Vua ViLa v3.46.3
- [TEST_REPORT_V3_46_4](reports/TEST_REPORT_V3_46_4.md) — Test report — Cờ Vua ViLa v3.46.4
- [TEST_REPORT_V3_47_0](reports/TEST_REPORT_V3_47_0.md) — ViLa Chess Pro v3.47.0 — báo cáo thay đổi
- [TEST_REPORT_V3_47_1](reports/TEST_REPORT_V3_47_1.md) — ViLa Chess Pro v3.47.1 — Arena response-time patch
- [TEST_REPORT_V3_47_2](reports/TEST_REPORT_V3_47_2.md) — ViLa Chess Pro v3.47.2 — báo cáo kiểm tra
- [TEST_REPORT_V3_49_1_ARENA_TESTS](reports/TEST_REPORT_V3_49_1_ARENA_TESTS.md) — Test report — v3.49.1: đồng bộ test Đấu trường với kho 4 khai cuộc riêng
- [TEST_REPORT_V3_49_2_UI_RUN](reports/TEST_REPORT_V3_49_2_UI_RUN.md) — Test report — chạy giao diện thật (Chromium 390×844, Stockfish wasm thật)
- [TEST_REPORT_V3_49_4](reports/TEST_REPORT_V3_49_4.md) — QA report — Cờ Vua ViLa v3.49.4
- [TEST_REPORT_V3_49_5](reports/TEST_REPORT_V3_49_5.md) — Test report — Cờ Vua ViLa v3.49.5
- [TEST_REPORT_V3_49_FIX](reports/TEST_REPORT_V3_49_FIX.md) — Báo cáo sửa lỗi — VILA Chess v3.49
- [TEST_REPORT_V3_50_0](reports/TEST_REPORT_V3_50_0.md) — Báo cáo kiểm thử VILA Chess v3.50.0
- [TEST_REPORT_V3_61_0](reports/TEST_REPORT_V3_61_0.md) — Báo cáo kiểm tra ViLa Chess v3.61.0
- [TEST_REPORT_V3_62_PRO_UI](reports/TEST_REPORT_V3_62_PRO_UI.md) — Báo cáo kiểm thử — ViLa Chess Professional Edition v3.62.0
- [TEST_REPORT_V3_63_0](reports/TEST_REPORT_V3_63_0.md) — Báo cáo kiểm thử — ViLa Chess v3.63.0
- [UI_CHAT_HOTFIX_NOTES](reports/UI_CHAT_HOTFIX_NOTES.md) — ViLa Chess UI and chat development hotfix (based on v3.61.0)
- [V3_64_QA_REPORT](reports/V3_64_QA_REPORT.md) — VILA Chess v3.64.0 — QA report
- [V3_65_TRIAL_CODES_QA_REPORT](reports/V3_65_TRIAL_CODES_QA_REPORT.md) — VILA Chess v3.65.0 — QA report
- [V3_66_1_FIX_REPORT](reports/V3_66_1_FIX_REPORT.md) — VILA Chess v3.66.1 — Test-failure fixes
- [V3_66_QA_REPORT](reports/V3_66_QA_REPORT.md) — VILA Chess v3.66.0 — QA report
- [V3_67_QA_REPORT](reports/V3_67_QA_REPORT.md) — VILA Chess v3.67.0 — QA & Release Report
