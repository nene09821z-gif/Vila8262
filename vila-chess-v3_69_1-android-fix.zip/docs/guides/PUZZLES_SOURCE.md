# Nguồn câu đố cờ vua — VILA Chess v3.69.1

## Nguồn dữ liệu

- Kho dữ liệu chính thức: <https://database.lichess.org/>
- Hướng dẫn câu đố Lichess: <https://lichess.org/training>
- API câu đố công khai dùng để tải trong ứng dụng: <https://lichess.org/api/puzzle/next?difficulty=normal>
- API câu đố trong ngày: <https://lichess.org/api/puzzle/daily>

Lichess Open Database công bố dữ liệu câu đố tải về theo giấy phép **CC0**. Ứng dụng lấy câu đố trực tiếp qua API và lưu một kho nhỏ đã xác thực trên thiết bị; không nhúng toàn bộ CSV nhiều triệu dòng vào ZIP/APK vì kích thước rất lớn.

## Cách ứng dụng sử dụng dữ liệu

1. Người dùng chủ động bấm **Tải thêm 50 câu về máy** khi có mạng. Ứng dụng tạo tối đa 50 yêu cầu lần lượt theo nhịp có khoảng nghỉ để tránh gửi dồn; vì vậy một lượt tải có thể mất gần một phút.
2. Ứng dụng lấy từng câu qua API công khai, giới hạn thời gian yêu cầu, xác minh PGN/FEN và kiểm tra từng nước lời giải bằng thư viện luật cờ `chess.js`.
3. Các thế cờ trùng nhau hoặc có lời giải không hợp lệ bị loại; kho cục bộ giữ tối đa 500 câu hợp lệ. “50 câu” là số yêu cầu tối đa của mỗi lượt, không phải cam kết thêm đủ 50 câu mới — có thể ít hơn nếu trùng, dữ liệu không hợp lệ hoặc API không sẵn sàng.
4. Các câu đã lưu được luân phiên để luyện ngoại tuyến. ZIP không bao gồm toàn bộ cơ sở dữ liệu nhiều triệu câu; dữ liệu chỉ tăng khi thiết bị tải thành công từ API. Lần tải đầu vẫn cần mạng; khi kho trống và không có mạng, ứng dụng dùng trình sinh câu đố ngoại tuyến hiện có.

## Phạm vi xác minh

Kiểm thử đơn vị xác minh giới hạn kho, loại vị trí trùng, luân phiên câu chưa dùng và cấu trúc API. Trong môi trường đóng gói bản này không thể truy cập `registry.npmjs.org`, vì vậy không thể cài dependencies để tải dữ liệu thật hoặc xác thực live API; cần chạy GitHub Actions/thiết bị có mạng để hoàn tất kiểm chứng tích hợp.
