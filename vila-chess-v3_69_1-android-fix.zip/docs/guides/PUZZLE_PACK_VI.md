# Kho câu đố tích hợp (Puzzle Pack)

Kho gồm tối đa vài chục nghìn câu đố từ cơ sở dữ liệu mở Lichess (CC0), đóng gói sẵn trong `public/puzzles/` và chạy hoàn toàn ngoại tuyến. App chọn câu **gần Elo câu đố của người chơi**, nhớ câu đã làm (theo tài khoản), lọc theo chủ đề, và dùng kho làm đề hằng ngày khi không có mạng. Thứ tự nguồn: câu cần ôn → **kho tích hợp** → API Lichess → kho đã lưu → ngân hàng mate Stockfish → tự sinh.

## Dựng kho
1. Tải `lichess_db_puzzle.csv.zst` từ https://database.lichess.org/#puzzles (≈ 250 MB).
2. `node scripts/build-puzzle-pack.mjs lichess_db_puzzle.csv.zst --max 40000`
   (Node ≥ 22.15 đọc trực tiếp `.zst`; nếu không, cài lệnh `zstd`.)
3. `npm run build` rồi dựng lại app/APK.

Tùy chọn: `--out <thư mục>`, `--min-popularity 90`, `--min-plays 1000`, `--max-deviation 85`, `--max-plies 12`, và kiểm chứng bằng Stockfish (`--verify-url`, `--verify-key`, `--verify-quality`, `--verify-concurrency`, `--keep-non-unique`).

Chọn lọc: lọc chất lượng, bỏ trùng thế, rồi chia đều theo dải Elo 100 điểm và theo chủ đề hiếm nhất của từng câu để chủ đề hiếm (smothered mate, zugzwang…) không bị "fork" lấn hết.

Nếu thư mục `public/puzzles/` chưa có, app tự bỏ qua kho và dùng các nguồn còn lại.

Định dạng: `index.json` (dải, số câu, chủ đề, kết quả kiểm chứng) và `band-<min>.json` gồm các hàng `[id, fen_trước_nước_đối_thủ, "uci …", elo, "chủ_đề …", độ_phổ_biến]`. Mọi câu được chơi lại từng nước bằng luật cờ trong app trước khi hiển thị.
