#!/usr/bin/env node
/**
 * Sinh sẵn giá trị cho các biến/bí mật của Worker. Chạy MỘT lần trên máy bạn:
 *   node cloudflare/scripts/generate-secrets.mjs [tên_admin] [giá_pro_vnd] [giá_premium_vnd]
 * Không gửi gì lên mạng và không ghi file. Sao chép kết quả vào Cloudflare rồi xoá khỏi màn hình/lịch sử.
 * Mã dùng thử được băm bằng HMAC-SHA256 giống hệt hàm hmacHex() trong src/index.js.
 */
import { randomBytes, createHmac } from 'node:crypto';

const adminUser = (process.argv[2] || 'vila_admin').toLowerCase();
const proPrice = process.argv[3] || '99000';
const premiumPrice = process.argv[4] || '299000';
if (!/^[a-z0-9._-]{3,24}$/.test(adminUser)) { console.error('Tên admin phải dài 3–24 ký tự: chữ thường, số, . _ -'); process.exit(1); }

const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
const randomText = length => Array.from(randomBytes(length), byte => alphabet[byte % alphabet.length]).join('');
const hexCode = bytes => randomBytes(bytes).toString('hex');

const adminPassword = `${randomText(8)}-${randomText(8)}-${randomText(8)}`; // 26 ký tự (≥ 14)
const tokenSecret = randomBytes(48).toString('base64url');                // TOKEN_SECRET: khoá ký phiên, nằm ngoài cơ sở dữ liệu
const trialSecret = hexCode(32);                                            // 64 ký tự (≥ 32)
const proCode = `pro-${hexCode(3)}-${hexCode(3)}`;
const premiumCode = `premium-${hexCode(3)}-${hexCode(3)}`;
const hmac = code => createHmac('sha256', trialSecret).update(code.toLowerCase()).digest('hex');

const rows = [
  ['ADMIN_USERNAME', 'Secret', adminUser],
  ['ADMIN_PASSWORD', 'Secret', adminPassword],
  ['TOKEN_SECRET', 'Secret', tokenSecret],
  ['VILA_TRIAL_CODE_SECRET', 'Secret', trialSecret],
  ['VILA_PRO_TRIAL_CODE_HMAC', 'Secret', hmac(proCode)],
  ['VILA_PREMIUM_TRIAL_CODE_HMAC', 'Secret', hmac(premiumCode)],
  ['PLAY_PRICE_VND_PRO', 'Text', proPrice],
  ['PLAY_PRICE_VND_PREMIUM', 'Text', premiumPrice],
  ['CORS_ORIGINS', 'Text', 'http://localhost:5173']
];
console.log('=== Dán vào Cloudflare: Worker → Settings → Variables and Secrets → Add ===\n');
for (const [name, type, value] of rows) console.log(`${name}\n  Loại : ${type}\n  Giá trị: ${value}\n`);
console.log('=== Mã dùng thử để phát cho người dùng (KHÔNG dán vào Cloudflare) ===');
console.log(`  Pro 5 ngày      : ${proCode}`);
console.log(`  Premium 1 tháng : ${premiumCode}\n`);
console.log('Lưu mật khẩu admin và hai mã ở nơi an toàn: Cloudflare không cho xem lại bí mật đã lưu.');
console.log('Không có Google Play thì bỏ qua GOOGLE_SERVICE_ACCOUNT_JSON; thêm riêng theo SECRETS_VI.md mục 5.');
