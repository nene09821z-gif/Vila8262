#!/usr/bin/env node
// Release sync check: run `npm run check:sync` before pushing to GitHub / deploying the Worker.
// It catches the problems that broke earlier uploads: a stale or loose Worker index.js, version drift,
// mixed CRLF/LF line endings, unresolved relative imports and a stale CSS bundle.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildProfessionalCss } from './build-professional-css.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const problems = [];
const fail = message => problems.push(message);

const version = JSON.parse(read('package.json')).version;
const versionFiles = ['index.html', 'public/sw.js', 'server/index.js', 'cloudflare/src/index.js', 'app/build.gradle.kts', 'README.md'];
for (const file of versionFiles) {
  if (!fs.existsSync(path.join(root, file))) continue;
  if (!read(file).includes(version)) fail(`${file} does not mention version ${version}`);
}

// Every relative import of the Worker and server must resolve on disk.
for (const file of ['cloudflare/src/index.js', 'cloudflare/src/billing.js', 'server/index.js']) {
  const dir = path.dirname(path.join(root, file));
  for (const match of read(file).matchAll(/from\s+['"](\.{1,2}\/[^'"]+)['"]/g)) {
    if (!fs.existsSync(path.resolve(dir, match[1]))) fail(`${file} imports ${match[1]} which does not exist (a loose copy of index.js outside cloudflare/src cannot resolve it)`);
  }
}

// Line endings: mixed CRLF/LF silently breaks diffs and some upload tools.
const scanned = [];
const walk = dir => {
  for (const entry of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
    if (['node_modules', 'dist', '.git', 'android'].includes(entry.name)) continue;
    const rel = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(rel);
    else if (/\.(js|mjs|css|json|html|toml|md)$/.test(entry.name) && !rel.startsWith(path.join('public', 'engine'))) scanned.push(rel);
  }
};
for (const dir of ['src', 'server', 'cloudflare', 'scripts', 'tests']) if (fs.existsSync(path.join(root, dir))) walk(dir);
for (const file of scanned) if (read(file).includes('\r')) fail(`${file} contains CRLF line endings (convert to LF)`);

if (read('src/vila-professional.css') !== buildProfessionalCss()) fail('src/vila-professional.css is stale: run `npm run build:professional-css`');

const big = scanned.filter(file => fs.statSync(path.join(root, file)).size > 25 * 1024 * 1024);
for (const file of big) fail(`${file} is larger than the 25 MB GitHub web-upload limit`);

if (problems.length) {
  console.error(`Sync check failed (${problems.length}):\n- ${problems.join('\n- ')}`);
  process.exit(1);
}
console.log(`Sync check OK: v${version}, ${scanned.length} source files, Worker imports resolve, CSS bundle current.`);
