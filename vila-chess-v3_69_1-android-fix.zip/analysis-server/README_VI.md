# Máy chủ Stockfish riêng cho Cờ Vua ViLa

Máy chủ này chạy **Stockfish bản gốc** (nhanh hơn bản WebAssembly trong điện thoại 10–30 lần) trên máy/VPS của bạn. App gửi vị trí lên, máy chủ trả về **điểm số thô của Stockfish** (cp/mate, nước tốt nhất, biến chính). Việc chấm "Tốt nhất / Sai lầm / Blunder…" vẫn do thuật toán trong app (`src/game-review.js`) quyết định, nên nhãn giống hệt dù engine chạy ở đâu.

Không phụ thuộc thư viện ngoài (chỉ cần Node ≥ 20 và Stockfish).

## Cách nó nhanh
- Nhiều tiến trình Stockfish chạy song song; một ván 80 nước được chia cho tất cả.
- Giới hạn tìm kiếm theo **số node** nên kết quả như nhau dù máy rảnh hay bận.
- Cache theo thế cờ (lưu đĩa): phân tích lại ván, hoặc ván cùng khai cuộc, gần như tức thì. Kết quả sâu hơn phục vụ được yêu cầu nông hơn.
- Yêu cầu giống nhau gửi cùng lúc chỉ tìm một lần. Yêu cầu lẻ được ưu tiên hơn phân tích cả ván.
- Engine treo/sập được thay thế và việc được chạy lại.

## Chạy nhanh bằng Docker
```bash
cd analysis-server
cp .env.example .env
node src/index.js --gen-key          # hoặc: docker run --rm node:22-slim node -e "console.log(require('crypto').randomBytes(24).toString('hex'))"
# dán khóa vừa tạo vào ANALYSIS_API_KEYS trong .env
docker compose up -d --build
curl http://127.0.0.1:8788/health
```

## Chạy không Docker
```bash
sudo apt install stockfish            # hoặc tải bản gốc mới nhất từ stockfishchess.org
export STOCKFISH_PATH=/usr/games/stockfish
export ANALYSIS_API_KEYS=$(node analysis-server/src/index.js --gen-key)
echo $ANALYSIS_API_KEYS               # lưu lại để dán vào app
node analysis-server/src/index.js
```
Không đặt `STOCKFISH_PATH` thì máy chủ tìm `stockfish` trong PATH, rồi mới dùng bản WebAssembly kèm dự án (chậm, chỉ để thử).

## HTTPS (bắt buộc để app trên điện thoại gọi được từ ngoài)
App chỉ nhận địa chỉ `https://`; `http://` chỉ cho localhost/mạng LAN (và WebView Android chặn http từ trang https, nên nên dùng https).
- **Cloudflare Tunnel** (không mở cổng): `docker compose --profile tunnel up -d` với `CLOUDFLARE_TUNNEL_TOKEN` trong `.env`, trỏ tunnel tới `http://analysis:8788`.
- **Caddy**: `phan-tich.ten-mien.example { reverse_proxy 127.0.0.1:8788 }`.
Thêm địa chỉ web app của bạn vào `ANALYSIS_CORS_ORIGIN` nếu chạy bản web (app Android đã được cho phép sẵn).

## Nối vào app
Cài đặt → **Máy chủ Stockfish riêng** → nhập địa chỉ và khóa → *Kiểm tra kết nối* → bật. Từ đó "Phân tích toàn ván" gửi lên máy chủ; nếu máy chủ lỗi/bận, app tự chạy tiếp bằng Stockfish trên máy. Mức *Chất lượng phân tích* trong Cài đặt chọn ngân sách tìm kiếm:

| Mức | Độ sâu tối đa | Node tối đa | Số biến |
|---|---|---|---|
| Nhanh | 14 | 250 nghìn | 1 |
| Tiêu chuẩn | 18 | 1,2 triệu | 2 |
| Sâu | 22 | 5 triệu | 2 |
| Tối đa | 26 | 20 triệu | 2 |

## Chỉnh hiệu năng
- `ANALYSIS_WORKERS` = số nhân CPU, `ANALYSIS_THREADS=1`: nhanh nhất cho phân tích cả ván.
- `ANALYSIS_HASH_MB` × `ANALYSIS_WORKERS` ≤ khoảng 60% RAM (máy chủ tự hạ nếu vượt).
- Dùng Stockfish có NNUE, build theo CPU (avx2/bmi2/avx512) cho tốc độ tốt nhất.

## API
Mọi đường dẫn `/v1/*` cần header `Authorization: Bearer <khóa>`.

| Phương thức | Đường dẫn | Mô tả |
|---|---|---|
| GET | `/health` | Công khai: tình trạng, tên engine, hàng đợi, cache. Không lộ khóa. |
| POST | `/v1/analyze` | `{fen, multipv?, quality?, nodes?, depth?}` → `{bestmove, lines[{multipv,depth,score,scoreType,nodes,pv}], cached}`. Điểm theo góc nhìn bên đi. Thế đã chiếu bí/hòa trả `terminal:true`. |
| POST | `/v1/review` | `{positions:[{fen, light?}], quality}` → luồng NDJSON: `position` (không theo thứ tự), `progress`, `done`. |
| POST | `/v1/puzzle/verify` | `{fen, moves, opponentFirst?, quality?, requireUnique?}` → Stockfish xác nhận từng nước giải của câu đố Lichess (đúng luật, là nước tốt nhất, duy nhất). |

Mã lỗi: 400 dữ liệu sai, 401 sai khóa, 413 quá lớn, 429 quá giới hạn / sai khóa nhiều lần, 503 máy chủ bận.

## Bảo mật
- Khóa tối thiểu 24 ký tự, so sánh thời gian cố định; sai khóa 20 lần/10 phút sẽ bị chặn tạm.
- Mọi FEN được kiểm tra nghiêm ngặt (vua, tốt, quyền nhập thành, bên không đi không bị chiếu…) trước khi đến Stockfish.
- Giới hạn: yêu cầu/phút theo khóa, số thế mỗi ván, số ván đồng thời, kích thước thân yêu cầu.
- Đừng mở cổng 8788 ra Internet trực tiếp; để tunnel/reverse proxy lo HTTPS. Mỗi người/thiết bị một khóa (`ANALYSIS_API_KEYS` nhận nhiều khóa), thu hồi bằng cách xóa khóa.
- Khóa lưu trong cài đặt của app trên thiết bị của bạn, chỉ gửi tới máy chủ bạn nhập.

## Kiểm chứng kho câu đố bằng máy chủ này
```bash
node scripts/build-puzzle-pack.mjs lichess_db_puzzle.csv.zst --max 40000 \
  --verify-url https://phan-tich.ten-mien.example --verify-key <khóa> --verify-quality standard
```
Chỉ những câu Stockfish xác nhận mới vào kho (thêm `--keep-non-unique` để chỉ cần nước giải đúng, không cần duy nhất). Xem `docs/guides/PUZZLE_PACK_VI.md`.

## Xử lý sự cố
- `/health` báo `engine: null`: Stockfish chưa chạy — kiểm tra `STOCKFISH_PATH`.
- App báo "Không kết nối được": sai địa chỉ, thiếu HTTPS, hoặc `ANALYSIS_CORS_ORIGIN` chưa có origin của web app.
- Báo "bận" (503): tăng `ANALYSIS_WORKERS` hoặc giảm mức chất lượng.
