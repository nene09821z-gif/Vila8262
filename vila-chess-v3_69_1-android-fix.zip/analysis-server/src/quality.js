/**
 * Search budgets. Searches are bounded by NODES first (deterministic: the same position gives the same
 * answer on a busy or an idle server), with depth and wall-clock limits as safety nets.
 */
export const QUALITY_PRESETS = Object.freeze({
  fast: Object.freeze({ rank: 1, depth: 14, nodes: 250_000, movetime: 2_500 }),
  standard: Object.freeze({ rank: 2, depth: 18, nodes: 1_200_000, movetime: 6_000 }),
  deep: Object.freeze({ rank: 3, depth: 22, nodes: 5_000_000, movetime: 15_000 }),
  max: Object.freeze({ rank: 4, depth: 26, nodes: 20_000_000, movetime: 40_000 }),
});
export const QUALITY_NAMES = Object.freeze(Object.keys(QUALITY_PRESETS));
export const MAX_MULTIPV = 5;
export const MIN_NODES = 1_000;

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export function normalizeQuality(value, fallback = 'standard') {
  return Object.hasOwn(QUALITY_PRESETS, value) ? value : fallback;
}

/**
 * @param {{quality?:string, multipv?:number, nodes?:number, depth?:number, light?:boolean}} request
 * @returns {{quality:string, rank:number, multipv:number, depth:number, nodes:number, movetime:number, custom:boolean}}
 */
export function resolveLimits(request = {}) {
  const quality = normalizeQuality(request.quality);
  const preset = QUALITY_PRESETS[quality];
  const multipv = clamp(Math.floor(Number(request.multipv) || 1), 1, MAX_MULTIPV);
  let { depth, nodes, movetime } = preset;
  // "light" positions (opening book moves, forced positions) do not need a full-strength search.
  if (request.light) { depth = Math.max(10, depth - 4); nodes = Math.max(MIN_NODES, Math.floor(nodes / 4)); movetime = Math.max(500, Math.floor(movetime / 3)); }
  // MultiPV splits the node budget across lines, so scale it to keep the best line as strong as with one line.
  nodes = Math.floor(nodes * (1 + 0.6 * (multipv - 1)));
  let custom = false;
  const ceiling = QUALITY_PRESETS.max;
  if (Number.isFinite(Number(request.nodes)) && request.nodes !== null && request.nodes !== '') { nodes = clamp(Math.floor(Number(request.nodes)), MIN_NODES, ceiling.nodes); custom = true; }
  if (Number.isFinite(Number(request.depth)) && request.depth !== null && request.depth !== '') { depth = clamp(Math.floor(Number(request.depth)), 1, 40); custom = true; }
  // A caller-chosen explicit budget is ranked by how much work it asks for, so cache reuse stays honest.
  const rank = custom ? rankForNodes(nodes) : preset.rank;
  return { quality, rank, multipv, depth, nodes, movetime: Math.min(movetime, ceiling.movetime), custom };
}

function rankForNodes(nodes) {
  if (nodes >= QUALITY_PRESETS.max.nodes) return 4;
  if (nodes >= QUALITY_PRESETS.deep.nodes) return 3;
  if (nodes >= QUALITY_PRESETS.standard.nodes) return 2;
  if (nodes >= QUALITY_PRESETS.fast.nodes) return 1;
  return 0; // tiny probes (health checks) never satisfy a real request from the cache
}
