#!/usr/bin/env node
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { generateKey } from './auth.js';
import { AnalysisCache } from './cache.js';
import { loadConfig } from './config.js';
import { locateEngine } from './engine-locator.js';
import { EnginePool } from './pool.js';
import { createAnalysisServer } from './server.js';
import { createAnalysisService } from './service.js';
import { UciEngine } from './uci.js';

/** Wire everything together. Exported so tests (and other Node apps) can embed the server. */
export async function startAnalysisServer(config, { engine = locateEngine(), logger = null } = {}) {
  if (!engine) throw new Error('Không tìm thấy Stockfish. Cài Stockfish rồi đặt STOCKFISH_PATH=/đường/dẫn/stockfish (xem analysis-server/README_VI.md).');
  const options = { Threads: config.threads, Hash: config.hashMb, UCI_AnalyseMode: 'true', 'Move Overhead': 0 };
  const pool = new EnginePool({ size: config.workers, maxQueue: config.maxQueue, createEngine: () => new UciEngine({ command: engine.command, args: engine.args, options }) });
  const engineName = await pool.warmUp(); // fail fast if Stockfish cannot start
  const cache = new AnalysisCache({ maxEntries: config.cacheEntries, file: config.cacheFile });
  const loaded = cache.load();
  cache.startAutosave();
  const service = createAnalysisService({ pool, cache });
  const app = createAnalysisServer({ config, service, pool, cache, logger });
  const address = await app.listen();
  return {
    address, engineName, engineKind: engine.kind, cachedEntries: loaded, pool, cache, service,
    async close() { await app.close(); await pool.close(); cache.stop(); },
  };
}

async function main() {
  if (process.argv.includes('--gen-key')) { console.log(generateKey()); return; }
  let config;
  try { config = loadConfig(); } catch (error) { console.error(`[VILA Analysis] ${error.message}`); process.exit(1); }
  const logger = config.log ? entry => { if (entry.level === 'error' || entry.status >= 400 || process.env.ANALYSIS_LOG_ALL === '1') console.log(JSON.stringify({ t: new Date().toISOString(), ...entry })); } : null;
  let running;
  try { running = await startAnalysisServer(config, { logger }); } catch (error) { console.error(`[VILA Analysis] ${error.message}`); process.exit(1); }
  console.log(`[VILA Analysis] ${running.engineName} (${running.engineKind}) · ${config.workers} engine · Hash ${config.hashMb} MB · cache ${running.cachedEntries} thế · nghe tại http://${config.host}:${running.address.port}`);
  if (running.engineKind === 'wasm') console.warn('[VILA Analysis] Đang dùng Stockfish WebAssembly (chậm). Cài Stockfish bản gốc và đặt STOCKFISH_PATH để nhanh gấp 10–30 lần.');
  let stopping = false;
  const stop = async signal => {
    if (stopping) return; stopping = true;
    console.log(`[VILA Analysis] ${signal}: đang tắt…`);
    const hard = setTimeout(() => process.exit(1), 10_000); hard.unref();
    await running.close(); process.exit(0);
  };
  process.on('SIGTERM', () => stop('SIGTERM')); process.on('SIGINT', () => stop('SIGINT'));
  process.on('unhandledRejection', reason => { console.error('[VILA Analysis] unhandledRejection:', reason); stop('unhandledRejection'); });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
