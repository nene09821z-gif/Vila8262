import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { delimiter, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

function onPath(name, env) {
  for (const dir of String(env.PATH || '').split(delimiter)) {
    const candidate = join(dir, name);
    if (dir && existsSync(candidate)) return candidate;
  }
  return null;
}

/** The Stockfish 19 lite WebAssembly build shipped with the app. Slow, single-threaded: a development/emergency fallback only. */
function bundledWasm() {
  const root = resolve(here, '..', '..', 'public', 'engine');
  const js = join(root, 'stockfish-19-lite-single.js');
  const wasm = join(root, 'stockfish-19-lite-single.wasm');
  if (!existsSync(js) || !existsSync(wasm)) return null;
  const dir = join(tmpdir(), 'vila-analysis-sf');
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'package.json'), '{}');
  copyFileSync(js, join(dir, 'sf.cjs')); copyFileSync(wasm, join(dir, 'sf.wasm'));
  return join(dir, 'sf.cjs');
}

/**
 * Decide which Stockfish to run.
 *  1. STOCKFISH_PATH (a native binary: recommended, 10-30x faster than WebAssembly)
 *  2. `stockfish` found on PATH
 *  3. the bundled WebAssembly build (only when this folder sits inside the app repository)
 * @returns {{command:string,args:string[],kind:'native'|'wasm'}|null}
 */
export function locateEngine(env = process.env) {
  if (env.STOCKFISH_PATH) {
    if (!existsSync(env.STOCKFISH_PATH)) throw new Error(`STOCKFISH_PATH không tồn tại: ${env.STOCKFISH_PATH}`);
    return { command: env.STOCKFISH_PATH, args: [], kind: 'native' };
  }
  const found = onPath('stockfish', env) || onPath('stockfish.exe', env);
  if (found) return { command: found, args: [], kind: 'native' };
  const wasm = bundledWasm();
  if (wasm) return { command: process.execPath, args: [wasm], kind: 'wasm' };
  return null;
}

/** Quick sanity check used by the CLI: `stockfish` answers `uci`. */
export function probeEngine(located, timeoutMs = 8000) {
  const run = spawnSync(located.command, located.args, { input: 'uci\nquit\n', encoding: 'utf8', timeout: timeoutMs });
  const name = /id name (.+)/.exec(run.stdout || '')?.[1]?.trim();
  return name || null;
}
