import os from 'node:os';
import path from 'node:path';
import { MIN_KEY_LENGTH } from './auth.js';

const int = (value, fallback, min, max) => {
  const n = Number(value);
  return Number.isFinite(n) && value !== '' && value != null ? Math.min(max, Math.max(min, Math.floor(n))) : fallback;
};
const list = value => String(value || '').split(',').map(item => item.trim()).filter(Boolean);
const LOOPBACK = new Set(['127.0.0.1', 'localhost', '::1']);

export const DEFAULT_CORS = ['capacitor://localhost', 'ionic://localhost', 'https://localhost', 'http://localhost', 'http://localhost:5173', 'http://127.0.0.1:5173'];

/** Read and validate configuration. Throws an Error with a Vietnamese message for anything unsafe. */
export function loadConfig(env = process.env, { cwd = process.cwd() } = {}) {
  const cpus = os.availableParallelism?.() || os.cpus().length || 1;
  const host = env.HOST || '127.0.0.1';
  const keys = [...new Set(list(env.ANALYSIS_API_KEYS || env.ANALYSIS_API_KEY))];
  const noAuth = env.ANALYSIS_ALLOW_NO_AUTH === '1';
  for (const key of keys) {
    if (key.length < MIN_KEY_LENGTH || key.startsWith('REPLACE_') || /\s/.test(key)) throw new Error(`Khóa truy cập phải dài tối thiểu ${MIN_KEY_LENGTH} ký tự, không chứa khoảng trắng và không phải khóa mẫu. Tạo khóa: node analysis-server/src/index.js --gen-key`);
  }
  if (!keys.length) {
    if (!(noAuth && LOOPBACK.has(host.toLowerCase()))) throw new Error('Chưa đặt ANALYSIS_API_KEYS. Tạo khóa bằng: node analysis-server/src/index.js --gen-key. (Chỉ khi chạy thử trên localhost mới được đặt ANALYSIS_ALLOW_NO_AUTH=1.)');
  }
  const workers = int(env.ANALYSIS_WORKERS, Math.max(1, Math.min(16, cpus - 1)), 1, 64);
  // Never let all engines together claim more than ~60% of RAM.
  const hashCeiling = Math.max(16, Math.floor((os.totalmem() / 1048576) * 0.6 / workers));
  return {
    host, port: int(env.PORT, 8788, 0, 65535), keys, noAuth: !keys.length,
    workers,
    threads: int(env.ANALYSIS_THREADS, 1, 1, 64),
    hashMb: Math.min(int(env.ANALYSIS_HASH_MB, 128, 1, 8192), hashCeiling),
    maxQueue: int(env.ANALYSIS_MAX_QUEUE, 2000, 10, 100_000),
    cacheEntries: int(env.ANALYSIS_CACHE_ENTRIES, 100_000, 100, 5_000_000),
    cacheFile: env.ANALYSIS_CACHE_FILE === '' ? '' : (env.ANALYSIS_CACHE_FILE || path.join(cwd, 'data', 'analysis-cache.jsonl')),
    ratePerMin: int(env.ANALYSIS_RATE_PER_MIN, 240, 1, 100_000),
    maxReviewPositions: int(env.ANALYSIS_MAX_REVIEW_POSITIONS, 400, 1, 2000),
    maxConcurrentReviews: int(env.ANALYSIS_MAX_CONCURRENT_REVIEWS, 2, 1, 32),
    maxBodyBytes: int(env.ANALYSIS_MAX_BODY_BYTES, 262_144, 1024, 4_194_304),
    corsOrigins: env.ANALYSIS_CORS_ORIGIN ? list(env.ANALYSIS_CORS_ORIGIN) : DEFAULT_CORS,
    trustProxy: env.TRUST_PROXY !== '0',
    log: env.ANALYSIS_LOG !== '0',
  };
}
