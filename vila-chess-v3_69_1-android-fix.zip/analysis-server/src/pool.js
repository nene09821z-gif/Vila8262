import { EngineError } from './uci.js';

export class QueueFullError extends Error {
  constructor() { super('Hàng đợi phân tích đã đầy.'); this.name = 'QueueFullError'; this.code = 'queue_full'; }
}

const RETRYABLE = new Set(['engine_exited', 'engine_down', 'engine_timeout', 'spawn_failed']);

/**
 * A fixed-size pool of Stockfish processes with a bounded two-level priority queue
 * (0 = interactive single-position requests, 1 = bulk game reviews).
 * A crashed or wedged engine is replaced transparently and its job is retried once.
 */
export class EnginePool {
  constructor({ size = 1, createEngine, maxQueue = 2000 } = {}) {
    if (typeof createEngine !== 'function') throw new TypeError('createEngine is required');
    this.size = Math.max(1, Math.floor(size)); this.createEngine = createEngine; this.maxQueue = Math.max(1, maxQueue);
    this.workers = []; this.queues = [[], []]; this.closed = false; this.restarts = 0; this.completed = 0; this.failures = 0; this.engineName = '';
  }

  get queued() { return this.queues[0].length + this.queues[1].length; }
  get busy() { return this.workers.filter(w => w.busy).length; }

  /** Start one engine eagerly so a broken installation fails at boot, not on the first request. */
  async warmUp() {
    const worker = await this.#spawnWorker();
    this.engineName = worker.engine.name;
    return worker.engine.name;
  }

  stats() {
    return { workers: this.size, started: this.workers.length, busy: this.busy, queued: this.queued, completed: this.completed, failures: this.failures, restarts: this.restarts, engine: this.engineName };
  }

  /** @returns {Promise<{bestmove:string|null, lines:object[], terminal:boolean}>} */
  run(job, { priority = 1, signal } = {}) {
    if (this.closed) return Promise.reject(new EngineError('Máy chủ đang tắt.', { code: 'shutting_down' }));
    if (signal?.aborted) return Promise.reject(new EngineError('Đã hủy.', { code: 'aborted' }));
    if (this.queued >= this.maxQueue) return Promise.reject(new QueueFullError());
    return new Promise((resolve, reject) => {
      const entry = { job, signal, resolve, reject, attempts: 0 };
      const level = priority <= 0 ? 0 : 1;
      this.queues[level].push(entry);
      entry.onAbort = () => {
        const queue = this.queues[level]; const at = queue.indexOf(entry);
        if (at >= 0) { queue.splice(at, 1); reject(new EngineError('Đã hủy.', { code: 'aborted' })); }
      };
      signal?.addEventListener?.('abort', entry.onAbort, { once: true });
      this.#pump();
    });
  }

  async #spawnWorker() {
    const engine = this.createEngine();
    const worker = { engine, busy: false, starting: true };
    this.workers.push(worker);
    try { await engine.start(); } catch (error) {
      this.workers.splice(this.workers.indexOf(worker), 1); engine.kill();
      throw error instanceof EngineError ? error : new EngineError(String(error?.message || error), { code: 'spawn_failed' });
    }
    worker.starting = false;
    return worker;
  }

  #next() { return this.queues[0].shift() || this.queues[1].shift() || null; }

  #pump() {
    if (this.closed) return;
    this.workers = this.workers.filter(w => w.starting || w.busy || w.engine.alive);
    while (this.queued > 0) {
      const idle = this.workers.find(w => !w.busy && !w.starting);
      if (idle) { this.#execute(idle, this.#next()); continue; }
      if (this.workers.length < this.size) { this.#startAndRun(this.#next()); continue; }
      return;
    }
  }

  async #startAndRun(entry) {
    try {
      const worker = await this.#spawnWorker();
      if (!this.engineName) this.engineName = worker.engine.name;
      this.#execute(worker, entry);
    } catch (error) {
      entry.signal?.removeEventListener?.('abort', entry.onAbort);
      this.failures += 1; entry.reject(error);
      this.#pump();
    }
  }

  async #execute(worker, entry) {
    worker.busy = true; entry.attempts += 1;
    entry.signal?.removeEventListener?.('abort', entry.onAbort);
    try {
      const result = await worker.engine.run(entry.job, entry.signal);
      this.completed += 1;
      worker.busy = false;
      entry.resolve(result);
    } catch (error) {
      worker.busy = false;
      const dead = !worker.engine.alive;
      if (dead) { this.workers.splice(this.workers.indexOf(worker), 1); this.restarts += 1; }
      const retry = error instanceof EngineError && RETRYABLE.has(error.code) && entry.attempts < 2 && !entry.signal?.aborted && !this.closed;
      if (retry) { this.queues[0].unshift(entry); } else { this.failures += error?.code === 'aborted' ? 0 : 1; entry.reject(error); }
    }
    this.#pump();
  }

  async close() {
    this.closed = true;
    for (const queue of this.queues) while (queue.length) queue.shift().reject(new EngineError('Máy chủ đang tắt.', { code: 'shutting_down' }));
    for (const worker of this.workers) worker.engine.quit();
    this.workers = [];
  }
}
