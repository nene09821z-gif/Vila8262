import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export const MIN_KEY_LENGTH = 24;
export const generateKey = () => randomBytes(24).toString('hex'); // 48 hex chars = 192 bits

const digest = value => createHash('sha256').update(value).digest();

/** Bearer-key authenticator: constant-time comparison against SHA-256 digests, so key length never leaks. */
export function createAuthenticator(keys) {
  const entries = keys.map(key => ({ hash: digest(key), id: createHash('sha256').update(key).digest('hex').slice(0, 8) }));
  return {
    size: entries.length,
    /** @returns {string|null} a short, non-reversible key id for logs and rate limits, or null when the key is wrong */
    verify(header) {
      const supplied = /^Bearer\s+(\S{1,512})$/i.exec(String(header || ''))?.[1];
      if (!supplied) return null;
      const hash = digest(supplied);
      let match = null;
      for (const entry of entries) if (timingSafeEqual(hash, entry.hash)) match = entry.id; // no early exit
      return match;
    },
  };
}

/** Sliding fixed-window counter map with bounded memory. */
export class WindowLimiter {
  constructor({ max, windowMs, maxKeys = 5000, now = () => Date.now() }) { this.max = max; this.windowMs = windowMs; this.maxKeys = maxKeys; this.now = now; this.buckets = new Map(); }

  /** Count one event for `key`. Returns { allowed, retryAfterSec }. */
  hit(key, cost = 1) {
    const t = this.now();
    let bucket = this.buckets.get(key);
    if (!bucket || t - bucket.start >= this.windowMs) bucket = { start: t, count: 0 };
    bucket.count += cost;
    this.buckets.set(key, bucket);
    if (this.buckets.size > this.maxKeys) {
      for (const [k, v] of this.buckets) if (t - v.start >= this.windowMs) this.buckets.delete(k);
      while (this.buckets.size > this.maxKeys) this.buckets.delete(this.buckets.keys().next().value);
    }
    const allowed = bucket.count <= this.max;
    return { allowed, retryAfterSec: allowed ? 0 : Math.max(1, Math.ceil((this.windowMs - (t - bucket.start)) / 1000)) };
  }

  /** Peek without counting: true once `max` events have been recorded in the current window. */
  blocked(key) {
    const bucket = this.buckets.get(key);
    return Boolean(bucket && this.now() - bucket.start < this.windowMs && bucket.count >= this.max);
  }
}
