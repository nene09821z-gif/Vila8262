import { fenKey, halfmoveClock, isUciMove, normalizeFen } from './fen.js';
import { resolveLimits } from './quality.js';
import { EngineError } from './uci.js';

/** Convert a UCI score (side-to-move view) to a comparable centipawn number; mates dominate. */
export function scoreToCp(line) {
  if (!line) return null;
  if (line.scoreType === 'mate') {
    if (line.score === 0) return -10000;
    return Math.sign(line.score) * (10000 - Math.min(999, Math.abs(line.score)) * 10);
  }
  return line.score;
}

const stripLine = line => ({ multipv: line.multipv, depth: line.depth, score: line.score, scoreType: line.scoreType, nodes: line.nodes, pv: line.pv });

export function createAnalysisService({ pool, cache, now = () => Date.now() } = {}) {
  const inflight = new Map(); // dedupe key -> { promise, waiters, controller }

  /**
   * Analyse one position. Identical concurrent requests share one search; a search is cancelled
   * only when every caller waiting for it has gone away.
   */
  async function analyze({ fen, multipv, quality, nodes, depth, light = false, priority = 0, signal } = {}) {
    const normalized = normalizeFen(fen);
    if (!normalized) throw Object.assign(new Error('FEN không hợp lệ.'), { code: 'bad_fen' });
    const limits = resolveLimits({ quality, multipv, nodes, depth, light });
    const key = fenKey(normalized);
    const cacheable = halfmoveClock(normalized) < 80; // near the 50-move rule the counter changes the score
    if (cacheable) {
      const hit = cache.get(key, { rank: limits.rank, multipv: limits.multipv });
      if (hit) return { bestmove: hit.bestmove, lines: hit.lines.map(stripLine), terminal: hit.terminal, cached: true, rank: hit.rank };
    }
    const shareKey = `${cacheable ? key : normalized}|${limits.rank}|${limits.multipv}|${limits.custom ? `${limits.nodes}/${limits.depth}` : ''}`;
    let shared = inflight.get(shareKey);
    if (!shared) {
      const controller = new AbortController();
      shared = { waiters: 0, controller, promise: null };
      shared.promise = pool.run({ fen: normalized, multipv: limits.multipv, depth: limits.depth, nodes: limits.nodes, movetime: limits.movetime }, { priority, signal: controller.signal })
        .then(result => {
          // A search that was stopped early returns a partial result; it must never be cached or served as final.
          if (controller.signal.aborted) throw new EngineError('Đã hủy.', { code: 'aborted' });
          if (!result.terminal && !result.lines.length) throw new EngineError('Stockfish không trả về nước đi.', { code: 'engine_empty' });
          const stored = { bestmove: result.bestmove, lines: result.lines.map(stripLine), terminal: result.terminal };
          if (cacheable) cache.set(key, { rank: limits.rank, multipv: limits.multipv, ...stored });
          return stored;
        })
        .finally(() => inflight.delete(shareKey));
      shared.promise.catch(() => {}); // callers handle the rejection; avoid an unhandled-rejection when all waiters left
      inflight.set(shareKey, shared);
    }
    shared.waiters += 1;
    let onAbort;
    try {
      const waiting = new Promise((_, reject) => {
        onAbort = () => reject(new EngineError('Đã hủy.', { code: 'aborted' }));
        if (signal?.aborted) onAbort(); else signal?.addEventListener?.('abort', onAbort, { once: true });
      });
      const result = await Promise.race([shared.promise, waiting]);
      return { ...result, cached: false, rank: limits.rank };
    } finally {
      signal?.removeEventListener?.('abort', onAbort);
      shared.waiters -= 1;
      if (shared.waiters <= 0) shared.controller.abort();
    }
  }

  /**
   * Stream a whole game. Positions are processed in parallel but at most `pool.size * 2` at a time,
   * so a long review never starves interactive requests (which have priority 0).
   */
  async function review({ positions, quality = 'standard', signal, onEvent }) {
    const started = now();
    const total = positions.length;
    const multipv = quality === 'fast' ? 1 : 2;
    let done = 0; let failed = 0; let cachedCount = 0; let cursor = 0;
    const lanes = Math.max(1, Math.min(total, pool.size * 2));
    const emit = event => { try { onEvent(event); } catch { /* the client went away */ } };
    const worker = async () => {
      while (cursor < total && !signal?.aborted) {
        const index = cursor; cursor += 1;
        const position = positions[index];
        try {
          const result = await analyze({ fen: position.fen, multipv, quality, light: Boolean(position.light), priority: 1, signal });
          if (result.cached) cachedCount += 1;
          emit({ type: 'position', index, bestmove: result.bestmove, lines: result.lines, cached: result.cached, ...(result.terminal ? { terminal: true } : {}) });
        } catch (error) {
          if (signal?.aborted) return;
          failed += 1;
          emit({ type: 'position', index, error: error.code || 'error' });
        }
        done += 1;
        emit({ type: 'progress', done, total });
      }
    };
    await Promise.all(Array.from({ length: lanes }, worker));
    if (!signal?.aborted) emit({ type: 'done', total, failed, cached: cachedCount, elapsedMs: now() - started });
    return { total, failed, cached: cachedCount };
  }

  /**
   * Check a Lichess-style puzzle with the engine.
   * `moves[0]` is the opponent's move that creates the puzzle (when `opponentFirst`), then the solver's
   * moves alternate with the replies. For every solver move the engine's best move must match (or be an
   * equally strong alternative) and, when `requireUnique`, the runner-up must be clearly worse.
   */
  async function verifyPuzzle({ fen, moves, opponentFirst = true, quality = 'standard', tolerance = 30, minGap = 120, requireUnique = true, signal }) {
    const normalized = normalizeFen(fen);
    if (!normalized) throw Object.assign(new Error('FEN không hợp lệ.'), { code: 'bad_fen' });
    if (!Array.isArray(moves) || moves.length < (opponentFirst ? 2 : 1) || moves.length > 24 || !moves.every(isUciMove)) throw Object.assign(new Error('Danh sách nước đi không hợp lệ.'), { code: 'bad_moves' });
    const limits = resolveLimits({ quality, multipv: 2 });
    // Every move must be legal at its turn; otherwise `position … moves …` would silently stop at the bad move.
    for (let i = 0; i < moves.length; i += 1) {
      const { legal } = await pool.run({ kind: 'legal', fen: normalized, moves: moves.slice(0, i) }, { priority: 0, signal });
      if (!legal.includes(moves[i])) return { ok: false, reason: 'illegal_move', unique: false, steps: [] };
    }
    const steps = [];
    let unique = true;
    for (let i = opponentFirst ? 1 : 0; i < moves.length; i += 2) {
      const prefix = moves.slice(0, i);
      const search = await pool.run({ fen: normalized, moves: prefix, multipv: 2, depth: limits.depth, nodes: limits.nodes * 2, movetime: limits.movetime }, { priority: 0, signal });
      const [best, second] = search.lines;
      if (!best) return { ok: false, reason: 'no_analysis', unique: false, steps };
      const bestCp = scoreToCp(best);
      let playedCp = bestCp;
      const isBest = best.pv[0] === moves[i];
      if (!isBest) {
        const probe = await pool.run({ fen: normalized, moves: prefix, multipv: 1, depth: limits.depth, nodes: limits.nodes, movetime: limits.movetime, searchMoves: [moves[i]] }, { priority: 0, signal });
        playedCp = scoreToCp(probe.lines[0]);
      }
      const loss = playedCp == null ? Infinity : bestCp - playedCp;
      const alternativeGap = second ? bestCp - scoreToCp(second) : Infinity;
      // "Unique" = no other move comes close to the solution move.
      const stepUnique = loss <= tolerance && alternativeGap >= minGap;
      if (!stepUnique) unique = false;
      steps.push({ index: i, played: moves[i], best: best.pv[0], isBest, lossCp: Math.round(loss), gapCp: Number.isFinite(alternativeGap) ? Math.round(alternativeGap) : null, unique: stepUnique });
      if (loss > tolerance) return { ok: false, reason: 'not_best', unique: false, steps };
    }
    const ok = !requireUnique || unique;
    return { ok, reason: ok ? 'verified' : 'not_unique', unique, steps };
  }

  return { analyze, review, verifyPuzzle };
}
