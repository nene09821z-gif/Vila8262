import { existsSync, readFileSync, renameSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

/**
 * LRU cache of finished analyses, keyed by position (FEN without move counters).
 * An entry computed at a higher quality rank / more MultiPV lines also satisfies weaker requests,
 * so re-reviewing a game, or reviewing a game that shares an opening, is nearly free.
 */
export class AnalysisCache {
  constructor({ maxEntries = 100_000, file = '' } = {}) {
    this.max = Math.max(100, maxEntries); this.file = file; this.map = new Map();
    this.hits = 0; this.misses = 0; this.dirty = false; this.timer = null;
  }

  get size() { return this.map.size; }

  get(key, { rank = 1, multipv = 1 } = {}) {
    const entry = this.map.get(key);
    if (!entry || entry.rank < rank || entry.multipv < multipv) { this.misses += 1; return null; }
    this.map.delete(key); this.map.set(key, entry); // refresh recency
    this.hits += 1;
    return { bestmove: entry.bestmove, lines: entry.lines.filter(line => line.multipv <= multipv), terminal: entry.terminal, rank: entry.rank };
  }

  set(key, { rank, multipv, bestmove, lines, terminal = false }) {
    if (rank < 1) return;
    const old = this.map.get(key);
    if (old && (old.rank > rank || (old.rank === rank && old.multipv >= multipv))) return; // never downgrade
    this.map.delete(key);
    this.map.set(key, { rank, multipv, bestmove, lines, terminal });
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
    this.dirty = true;
  }

  load() {
    if (!this.file || !existsSync(this.file)) return 0;
    let loaded = 0;
    for (const line of readFileSync(this.file, 'utf8').split('\n')) {
      if (!line.trim()) continue;
      try {
        const [key, entry] = JSON.parse(line);
        if (typeof key === 'string' && entry && Number.isInteger(entry.rank) && Array.isArray(entry.lines)) { this.map.set(key, entry); loaded += 1; }
      } catch { /* a torn last line after a crash is ignored */ }
    }
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
    this.dirty = false;
    return loaded;
  }

  /** Atomic snapshot (write temp file, then rename) so a crash never leaves a half-written cache. */
  save() {
    if (!this.file || !this.dirty) return false;
    mkdirSync(dirname(this.file), { recursive: true });
    const temp = `${this.file}.tmp`;
    writeFileSync(temp, `${[...this.map].map(item => JSON.stringify(item)).join('\n')}\n`);
    renameSync(temp, this.file);
    this.dirty = false;
    return true;
  }

  startAutosave(intervalMs = 60_000) {
    if (!this.file || this.timer) return;
    this.timer = setInterval(() => { try { this.save(); } catch (error) { console.error('[analysis] Không ghi được cache:', error.message); } }, intervalMs);
    this.timer.unref?.();
  }

  stop() { clearInterval(this.timer); this.timer = null; try { this.save(); } catch { /* best effort on shutdown */ } }

  stats() { return { entries: this.map.size, hits: this.hits, misses: this.misses }; }
}
