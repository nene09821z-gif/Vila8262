/**
 * Strict FEN validation without third-party dependencies.
 * A native Stockfish process can misbehave (or crash) on impossible positions, so every FEN
 * coming from the network is checked here before it reaches the engine.
 */
const PIECES = 'pnbrqkPNBRQK';
const KNIGHT = [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]];
const KING = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const ROOK_DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const BISHOP_DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];

export const MAX_FEN_LENGTH = 100;

function parseBoard(placement) {
  const ranks = placement.split('/');
  if (ranks.length !== 8) return null;
  const board = []; // board[rank 0 = 8th rank][file 0 = a]
  for (const rank of ranks) {
    const row = [];
    let previousWasDigit = false;
    for (const ch of rank) {
      if (ch >= '1' && ch <= '8') {
        if (previousWasDigit) return null;
        for (let i = 0; i < Number(ch); i += 1) row.push(null);
        previousWasDigit = true;
      } else if (PIECES.includes(ch)) { row.push(ch); previousWasDigit = false; } else return null;
    }
    if (row.length !== 8) return null;
    board.push(row);
  }
  return board;
}

/** True when `color` ('w'|'b') attacks square (r, f) on the board. */
function attacks(board, r, f, color) {
  const own = ch => ch && (color === 'w' ? ch === ch.toUpperCase() : ch === ch.toLowerCase());
  const at = (rr, ff) => (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 ? board[rr][ff] : undefined);
  // Pawns: white pawns attack toward rank index - 1 (upwards on the diagram).
  const pawnRow = color === 'w' ? r + 1 : r - 1;
  for (const df of [-1, 1]) if (at(pawnRow, f + df) === (color === 'w' ? 'P' : 'p')) return true;
  for (const [dr, df] of KNIGHT) { const ch = at(r + dr, f + df); if (own(ch) && ch.toLowerCase() === 'n') return true; }
  for (const [dr, df] of KING) { const ch = at(r + dr, f + df); if (own(ch) && ch.toLowerCase() === 'k') return true; }
  const slide = (dirs, kinds) => {
    for (const [dr, df] of dirs) {
      let rr = r + dr; let ff = f + df;
      while (at(rr, ff) !== undefined) {
        const ch = at(rr, ff);
        if (ch) { if (own(ch) && kinds.includes(ch.toLowerCase())) return true; break; }
        rr += dr; ff += df;
      }
    }
    return false;
  };
  return slide(ROOK_DIRS, 'rq') || slide(BISHOP_DIRS, 'bq');
}

function findPiece(board, piece) {
  const found = [];
  board.forEach((row, r) => row.forEach((ch, f) => { if (ch === piece) found.push([r, f]); }));
  return found;
}

/**
 * @returns {string|null} the canonical FEN (always six fields) or null when the position is not acceptable.
 */
export function normalizeFen(input) {
  if (typeof input !== 'string' || input.length > MAX_FEN_LENGTH) return null;
  const parts = input.trim().split(/\s+/);
  if (parts.length < 4 || parts.length > 6) return null;
  const [placement, side, castling, ep, half = '0', full = '1'] = parts;
  const board = parseBoard(placement);
  if (!board) return null;
  if (side !== 'w' && side !== 'b') return null;
  if (!/^(?:-|K?Q?k?q?)$/.test(castling) || castling === '') return null;
  if (!/^\d{1,3}$/.test(half) || Number(half) > 150 || !/^\d{1,4}$/.test(full) || Number(full) < 1) return null;

  const whiteKing = findPiece(board, 'K'); const blackKing = findPiece(board, 'k');
  if (whiteKing.length !== 1 || blackKing.length !== 1) return null;
  const count = ch => findPiece(board, ch).length;
  if (count('P') > 8 || count('p') > 8) return null;
  const pieceTotal = color => [...'pnbrqk'].reduce((sum, ch) => sum + count(color === 'w' ? ch.toUpperCase() : ch), 0);
  if (pieceTotal('w') > 16 || pieceTotal('b') > 16) return null;
  if (board[0].some(ch => ch === 'P' || ch === 'p') || board[7].some(ch => ch === 'P' || ch === 'p')) return null;

  const [wr, wf] = whiteKing[0]; const [br, bf] = blackKing[0];
  if (Math.abs(wr - br) <= 1 && Math.abs(wf - bf) <= 1) return null;
  // The side that is NOT to move can never be in check (the king would be capturable).
  if (side === 'w' ? attacks(board, br, bf, 'w') : attacks(board, wr, wf, 'b')) return null;

  if (castling !== '-') {
    const needs = { K: [7, 4, 7, 7, 'K', 'R'], Q: [7, 4, 7, 0, 'K', 'R'], k: [0, 4, 0, 7, 'k', 'r'], q: [0, 4, 0, 0, 'k', 'r'] };
    for (const right of castling) {
      const [kr, kf, rr, rf, king, rook] = needs[right];
      if (board[kr][kf] !== king || board[rr][rf] !== rook) return null;
    }
  }
  if (ep !== '-') {
    if (!/^[a-h][36]$/.test(ep)) return null;
    if ((side === 'w' && ep[1] !== '6') || (side === 'b' && ep[1] !== '3')) return null;
    // A pawn that just double-stepped must stand in front of the en-passant square.
    const file = ep.charCodeAt(0) - 97;
    const pawnRow = side === 'w' ? 3 : 4; // rank 5 for white to move, rank 4 for black to move
    if (board[pawnRow][file] !== (side === 'w' ? 'p' : 'P')) return null;
  }
  return [placement, side, castling, ep, String(Number(half)), String(Number(full))].join(' ');
}

/** Cache key: placement, side, castling, en-passant. Move counters do not change the evaluation (except near the 50-move rule). */
export function fenKey(fen) {
  return fen.split(' ').slice(0, 4).join(' ');
}

export function halfmoveClock(fen) {
  return Number(fen.split(' ')[4]) || 0;
}

const UCI_MOVE = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
export const isUciMove = move => typeof move === 'string' && UCI_MOVE.test(move);
