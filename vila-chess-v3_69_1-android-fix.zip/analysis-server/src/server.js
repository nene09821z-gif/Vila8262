import http from 'node:http';
import { createAuthenticator, WindowLimiter } from './auth.js';
import { normalizeFen } from './fen.js';
import { QUALITY_NAMES } from './quality.js';
import { QueueFullError } from './pool.js';

export const SERVER_NAME = 'vila-analysis';
export const SERVER_VERSION = '1.0.0';

class HttpError extends Error {
  constructor(status, code, message, headers = {}) { super(message); this.status = status; this.code = code; this.headers = headers; }
}

const LOOPBACK = /^(?:::1|::ffff:127\.\d+\.\d+\.\d+|127\.\d+\.\d+\.\d+)$/;

/**
 * @param {object} deps
 * @param {object} deps.config   see config.js
 * @param {object} deps.service  createAnalysisService()
 * @param {object} deps.pool     EnginePool (for health numbers)
 * @param {object} deps.cache    AnalysisCache (for health numbers)
 * @param {Function|null} [deps.logger]
 */
export function createAnalysisServer({ config, service, pool, cache, logger = null }) {
  const auth = createAuthenticator(config.keys);
  const perKey = new WindowLimiter({ max: config.ratePerMin, windowMs: 60_000 });
  const badAuth = new WindowLimiter({ max: 20, windowMs: 10 * 60_000 });
  const reviewsRunning = new Map();
  const startedAt = Date.now();

  const clientIp = req => {
    const remote = req.socket.remoteAddress || 'unknown';
    if (config.trustProxy && LOOPBACK.test(remote)) {
      const forwarded = String(req.headers['cf-connecting-ip'] || '').trim() || String(req.headers['x-forwarded-for'] || '').split(',').pop().trim();
      if (forwarded) return forwarded.slice(0, 64);
    }
    return remote;
  };

  function corsHeaders(req) {
    const origin = req.headers.origin;
    if (!origin) return {};
    const allowed = config.corsOrigins.includes('*') || config.corsOrigins.includes(origin);
    if (!allowed) return {};
    return {
      'Access-Control-Allow-Origin': config.corsOrigins.includes('*') ? '*' : origin,
      Vary: 'Origin',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Max-Age': '600',
      // Lets an https page reach a server on the home LAN (Chrome Private Network Access).
      ...(req.headers['access-control-request-private-network'] ? { 'Access-Control-Allow-Private-Network': 'true' } : {}),
    };
  }

  const baseHeaders = req => ({
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'", ...corsHeaders(req),
  });

  function sendJson(req, res, status, body, extra = {}) {
    const payload = JSON.stringify(body);
    res.writeHead(status, { ...baseHeaders(req), 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(payload), ...extra });
    res.end(payload);
  }

  function readJson(req) {
    return new Promise((resolve, reject) => {
      if (!/^application\/json\b/i.test(String(req.headers['content-type'] || ''))) return reject(new HttpError(415, 'unsupported_media_type', 'Cần Content-Type: application/json.'));
      let size = 0; const chunks = [];
      let tooLarge = false;
      req.on('data', chunk => {
        size += chunk.length;
        // Keep draining an oversized upload (so the client can read our 413) but stop buffering and cut off runaway streams.
        if (size > config.maxBodyBytes && !tooLarge) { tooLarge = true; chunks.length = 0; reject(new HttpError(413, 'too_large', 'Nội dung yêu cầu quá lớn.', { Connection: 'close' })); }
        if (size > config.maxBodyBytes * 16) { req.destroy(); return; }
        if (!tooLarge) chunks.push(chunk);
      });
      req.on('end', () => {
        if (tooLarge) return;
        try { const value = JSON.parse(Buffer.concat(chunks).toString('utf8') || 'null'); if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('not an object'); resolve(value); } catch { reject(new HttpError(400, 'bad_json', 'JSON không hợp lệ.')); }
      });
      req.on('error', () => reject(new HttpError(400, 'bad_request', 'Không đọc được yêu cầu.')));
    });
  }

  function authenticate(req) {
    if (config.noAuth) return 'local';
    const ip = clientIp(req);
    if (badAuth.blocked(ip)) throw new HttpError(429, 'rate_limited', 'Quá nhiều lần sai khóa. Thử lại sau.', { 'Retry-After': '600' });
    const id = auth.verify(req.headers.authorization);
    if (!id) { badAuth.hit(ip); throw new HttpError(401, 'unauthorized', 'Khóa truy cập không đúng.'); }
    return id;
  }

  function limit(keyId, cost = 1) {
    const result = perKey.hit(keyId, cost);
    if (!result.allowed) throw new HttpError(429, 'rate_limited', 'Vượt giới hạn yêu cầu; thử lại sau ít phút.', { 'Retry-After': String(result.retryAfterSec) });
  }

  const checkQuality = value => {
    if (value === undefined || value === null) return 'standard';
    if (!QUALITY_NAMES.includes(value)) throw new HttpError(400, 'bad_quality', `quality phải là một trong: ${QUALITY_NAMES.join(', ')}.`);
    return value;
  };

  const optionalNumber = (value, name, min, max) => {
    if (value === undefined || value === null) return undefined;
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) throw new HttpError(400, 'bad_param', `${name} phải là số trong khoảng ${min}–${max}.`);
    return value;
  };

  const abortOnClose = (req, res) => {
    const controller = new AbortController();
    res.on('close', () => { if (!res.writableEnded) controller.abort(); });
    return controller;
  };

  async function handleAnalyze(req, res, keyId) {
    limit(keyId);
    const body = await readJson(req);
    if (!normalizeFen(body.fen)) throw new HttpError(400, 'bad_fen', 'FEN không hợp lệ.');
    const controller = abortOnClose(req, res);
    const result = await service.analyze({
      fen: body.fen, quality: checkQuality(body.quality), multipv: optionalNumber(body.multipv, 'multipv', 1, 5),
      nodes: optionalNumber(body.nodes, 'nodes', 1, 1e9), depth: optionalNumber(body.depth, 'depth', 1, 60),
      light: body.light === true, priority: 0, signal: controller.signal,
    });
    sendJson(req, res, 200, { bestmove: result.bestmove, lines: result.lines, cached: result.cached, ...(result.terminal ? { terminal: true } : {}), engine: pool.engineName || undefined });
  }

  async function handleReview(req, res, keyId) {
    limit(keyId);
    const body = await readJson(req);
    const quality = checkQuality(body.quality);
    if (!Array.isArray(body.positions) || !body.positions.length) throw new HttpError(400, 'bad_positions', 'Thiếu danh sách positions.');
    if (body.positions.length > config.maxReviewPositions) throw new HttpError(413, 'too_many_positions', `Tối đa ${config.maxReviewPositions} thế cờ mỗi lần.`);
    const positions = body.positions.map((item, index) => {
      const fen = normalizeFen(item?.fen);
      if (!fen) throw new HttpError(400, 'bad_fen', `FEN không hợp lệ ở vị trí ${index}.`);
      return { fen, light: item.light === true };
    });
    if ((reviewsRunning.get(keyId) || 0) >= config.maxConcurrentReviews) throw new HttpError(429, 'too_many_reviews', 'Đang có quá nhiều phân tích cả ván chạy cùng lúc.', { 'Retry-After': '15' });
    // Reject up-front when the engines are saturated rather than accepting a review that cannot make progress.
    if (pool.queued >= config.maxQueue * 0.9) throw new HttpError(503, 'busy', 'Máy chủ phân tích đang bận.', { 'Retry-After': '10' });
    reviewsRunning.set(keyId, (reviewsRunning.get(keyId) || 0) + 1);
    const controller = abortOnClose(req, res);
    res.writeHead(200, { ...baseHeaders(req), 'Content-Type': 'application/x-ndjson; charset=utf-8', 'X-Accel-Buffering': 'no' });
    res.flushHeaders?.();
    // A blank line every 10 s keeps proxies (Cloudflare drops idle streams after ~100 s) and the app's idle timer happy while deep positions run.
    const heartbeat = setInterval(() => { if (!res.writableEnded) res.write('\n'); }, 10_000);
    heartbeat.unref?.();
    try {
      await service.review({ positions, quality, signal: controller.signal, onEvent: event => { if (!res.writableEnded && !res.destroyed) res.write(`${JSON.stringify(event)}\n`); } });
    } finally {
      clearInterval(heartbeat);
      reviewsRunning.set(keyId, Math.max(0, (reviewsRunning.get(keyId) || 1) - 1));
      if (!res.writableEnded) res.end();
    }
  }

  async function handleVerify(req, res, keyId) {
    limit(keyId, 3);
    const body = await readJson(req);
    const controller = abortOnClose(req, res);
    try {
      const result = await service.verifyPuzzle({
        fen: body.fen, moves: body.moves, opponentFirst: body.opponentFirst !== false, quality: checkQuality(body.quality),
        requireUnique: body.requireUnique !== false, tolerance: optionalNumber(body.tolerance, 'tolerance', 0, 500), minGap: optionalNumber(body.minGap, 'minGap', 0, 2000), signal: controller.signal,
      });
      sendJson(req, res, 200, result);
    } catch (error) {
      if (error.code === 'bad_fen' || error.code === 'bad_moves') throw new HttpError(400, error.code, error.message);
      throw error;
    }
  }

  function handleHealth(req, res) {
    const stats = pool.stats();
    sendJson(req, res, 200, {
      ok: true, app: SERVER_NAME, version: SERVER_VERSION, engine: stats.engine || null,
      workers: stats.workers, busy: stats.busy, queued: stats.queued, cache: cache.stats(), uptimeSec: Math.round((Date.now() - startedAt) / 1000), auth: !config.noAuth,
    });
  }

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    let status = 500; let keyId = '-';
    const path = String(req.url || '/').split('?')[0];
    try {
      if (req.method === 'OPTIONS') {
        const headers = corsHeaders(req);
        if (req.headers.origin && !headers['Access-Control-Allow-Origin']) throw new HttpError(403, 'origin_not_allowed', 'Origin chưa được cho phép.');
        res.writeHead(204, { ...baseHeaders(req) }); status = 204; return res.end();
      }
      if (path === '/health' && req.method === 'GET') { handleHealth(req, res); status = 200; return undefined; }
      const routes = { '/v1/analyze': handleAnalyze, '/v1/review': handleReview, '/v1/puzzle/verify': handleVerify };
      const handler = routes[path];
      if (!handler) throw new HttpError(404, 'not_found', 'Không có đường dẫn này.');
      if (req.method !== 'POST') throw new HttpError(405, 'method_not_allowed', 'Chỉ hỗ trợ POST.', { Allow: 'POST' });
      keyId = authenticate(req);
      await handler(req, res, keyId);
      status = res.statusCode;
    } catch (error) {
      if (error instanceof HttpError) { status = error.status; if (!res.headersSent) sendJson(req, res, error.status, { error: error.code, message: error.message }, error.headers); }
      else if (error instanceof QueueFullError || error?.code === 'queue_full') { status = 503; if (!res.headersSent) sendJson(req, res, 503, { error: 'busy', message: 'Máy chủ phân tích đang bận.' }, { 'Retry-After': '10' }); }
      else if (error?.code === 'aborted') { status = 499; }
      else if (error?.code === 'bad_fen') { status = 400; if (!res.headersSent) sendJson(req, res, 400, { error: 'bad_fen', message: error.message }); }
      else if (error?.code === 'shutting_down') { status = 503; if (!res.headersSent) sendJson(req, res, 503, { error: 'shutting_down', message: 'Máy chủ đang khởi động lại.' }, { 'Retry-After': '5' }); }
      else {
        status = 500; logger?.({ level: 'error', path, message: String(error?.message || error).slice(0, 300) });
        if (!res.headersSent) sendJson(req, res, 500, { error: 'engine_error', message: 'Stockfish gặp lỗi khi phân tích; thử lại.' });
        else res.destroy();
      }
    } finally {
      logger?.({ level: 'info', method: req.method, path, status, ms: Date.now() - started, key: keyId });
    }
  });
  server.headersTimeout = 20_000; server.requestTimeout = 60_000; server.keepAliveTimeout = 5_000;

  return {
    server,
    listen: (port = config.port, host = config.host) => new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, host, () => { server.off('error', reject); resolve(server.address()); }); }),
    close: () => new Promise(resolve => { server.closeAllConnections?.(); server.close(() => resolve()); }),
  };
}
