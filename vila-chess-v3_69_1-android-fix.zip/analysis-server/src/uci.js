import { spawn } from 'node:child_process';
import { isUciMove } from './fen.js';

export class EngineError extends Error {
  constructor(message, { code = 'engine_error' } = {}) { super(message); this.name = 'EngineError'; this.code = code; }
}

const INFO_PATTERN = /^info\b.*\bdepth (\d+)\b.*\bmultipv (\d+)\b.*\bscore (cp|mate) (-?\d+)(?: (lowerbound|upperbound))?(?:.*\bnodes (\d+))?(?:.*\bnps (\d+))?.*\bpv ((?:[a-h][1-8][a-h][1-8][qrbn]?\s*)+)$/;
const INFO_NO_MULTIPV = /^info\b.*\bdepth (\d+)\b.*\bscore (cp|mate) (-?\d+)(?: (lowerbound|upperbound))?(?:.*\bnodes (\d+))?(?:.*\bnps (\d+))?.*\bpv ((?:[a-h][1-8][a-h][1-8][qrbn]?\s*)+)$/;

/** Parse one UCI `info` line into a search line, or null for lines that are not a complete exact score. */
export function parseInfoLine(line) {
  let m = INFO_PATTERN.exec(line);
  let multipv; let depth; let scoreType; let score; let bound; let nodes; let nps; let pv;
  if (m) { [, depth, multipv, scoreType, score, bound, nodes, nps, pv] = m; } else {
    m = INFO_NO_MULTIPV.exec(line);
    if (!m) return null;
    multipv = '1'; [, depth, scoreType, score, bound, nodes, nps, pv] = m;
  }
  // Aspiration-window fail lines are only bounds, never a real score.
  if (bound) return null;
  const moves = pv.trim().split(/\s+/).filter(isUciMove);
  if (!moves.length) return null;
  return { multipv: Number(multipv), depth: Number(depth), score: Number(score), scoreType, nodes: Number(nodes || 0), nps: Number(nps || 0), pv: moves.slice(0, 24) };
}

/**
 * One UCI engine child process. Only one search runs at a time; the pool serialises access.
 * The engine is intentionally never given `ucinewgame` between positions of the same job so its hash stays warm.
 */
export class UciEngine {
  constructor({ command, args = [], options = {}, spawnImpl = spawn, startupTimeoutMs = 15_000 } = {}) {
    this.command = command; this.args = args; this.options = options; this.spawnImpl = spawnImpl; this.startupTimeoutMs = startupTimeoutMs;
    this.proc = null; this.buffer = ''; this.listeners = new Set(); this.alive = false; this.name = ''; this.busy = false;
  }

  async start() {
    if (this.alive) return this;
    this.proc = this.spawnImpl(this.command, this.args, { stdio: ['pipe', 'pipe', 'ignore'] });
    this.alive = true;
    this.proc.on('error', error => this.#die(new EngineError(`Không chạy được Stockfish: ${error.message}`, { code: 'spawn_failed' })));
    this.proc.on('exit', () => this.#die(new EngineError('Tiến trình Stockfish đã thoát.', { code: 'engine_exited' })));
    this.proc.stdin.on('error', () => {});
    this.proc.stdout.setEncoding('utf8');
    this.proc.stdout.on('data', chunk => {
      this.buffer += chunk;
      let index;
      while ((index = this.buffer.indexOf('\n')) >= 0) {
        const line = this.buffer.slice(0, index).trim(); this.buffer = this.buffer.slice(index + 1);
        if (line) for (const listener of [...this.listeners]) listener(line);
      }
    });
    const idLines = await this.#command('uci', /^uciok$/, this.startupTimeoutMs);
    this.name = (idLines.find(line => line.startsWith('id name ')) || '').slice(8).trim() || 'Stockfish';
    for (const [name, value] of Object.entries(this.options)) this.#send(`setoption name ${name} value ${value}`);
    await this.#command('isready', /^readyok$/, this.startupTimeoutMs);
    return this;
  }

  #send(text) { if (!this.alive || !this.proc?.stdin?.writable) throw new EngineError('Stockfish chưa sẵn sàng.', { code: 'engine_down' }); this.proc.stdin.write(`${text}\n`); }

  #die(error) {
    if (!this.alive) return;
    this.alive = false;
    for (const listener of [...this.listeners]) listener(null, error);
    this.listeners.clear();
  }

  /** Send `text` and collect lines until one matches `until`; rejects on timeout or engine death. */
  #command(text, until, timeoutMs) {
    return new Promise((resolve, reject) => {
      const lines = [];
      const finish = (error, value) => { clearTimeout(timer); this.listeners.delete(listener); error ? reject(error) : resolve(value); };
      const listener = (line, error) => {
        if (error) return finish(error);
        lines.push(line);
        if (until.test(line)) finish(null, lines);
      };
      const timer = setTimeout(() => { finish(new EngineError('Stockfish không phản hồi kịp.', { code: 'engine_timeout' })); this.kill(); }, timeoutMs);
      this.listeners.add(listener);
      try { this.#send(text); } catch (error) { finish(error); }
    });
  }

  /**
   * Run one search.
   * @param {{fen:string, moves?:string[], multipv?:number, depth:number, nodes:number, movetime:number, searchMoves?:string[]}} job
   * @param {AbortSignal} [signal]
   * @returns {Promise<{bestmove:string|null, lines:object[], terminal:boolean}>}
   */
  search(job, signal) {
    if (!this.alive) return Promise.reject(new EngineError('Stockfish chưa sẵn sàng.', { code: 'engine_down' }));
    if (this.busy) return Promise.reject(new EngineError('Engine đang bận.', { code: 'engine_busy' }));
    if (signal?.aborted) return Promise.reject(new EngineError('Đã hủy.', { code: 'aborted' }));
    this.busy = true;
    const multipv = Math.max(1, Math.floor(job.multipv || 1));
    const wallMs = job.movetime + 5_000;
    return new Promise((resolve, reject) => {
      const best = new Map(); // multipv -> deepest exact line
      let settled = false; let stopTimer = null;
      const finish = (error, value) => {
        if (settled) return; settled = true;
        clearTimeout(wallTimer); clearTimeout(stopTimer); this.listeners.delete(listener); signal?.removeEventListener?.('abort', onAbort);
        this.busy = false;
        error ? reject(error) : resolve(value);
      };
      const listener = (line, error) => {
        if (error) return finish(error);
        if (line.startsWith('info')) {
          const parsed = parseInfoLine(line);
          if (parsed && parsed.multipv <= multipv) { const old = best.get(parsed.multipv); if (!old || parsed.depth >= old.depth) best.set(parsed.multipv, parsed); }
        } else if (line.startsWith('bestmove')) {
          const move = line.split(/\s+/)[1];
          const bestmove = isUciMove(move) ? move : null;
          const lines = [...best.values()].sort((a, b) => a.multipv - b.multipv);
          finish(null, { bestmove, lines, terminal: !bestmove });
        }
      };
      const onAbort = () => { try { this.#send('stop'); } catch { /* engine already gone */ } stopTimer = setTimeout(() => { finish(new EngineError('Đã hủy.', { code: 'aborted' })); this.kill(); }, 1500); };
      // Hard wall-clock guard: a wedged engine must not hold a worker forever.
      const wallTimer = setTimeout(() => { finish(new EngineError('Stockfish vượt quá thời gian cho phép.', { code: 'engine_timeout' })); this.kill(); }, wallMs);
      this.listeners.add(listener);
      signal?.addEventListener?.('abort', onAbort, { once: true });
      try {
        this.#send(`setoption name MultiPV value ${multipv}`);
        this.#send(`position fen ${job.fen}${job.moves?.length ? ` moves ${job.moves.join(' ')}` : ''}`);
        // `searchmoves` swallows every following token, so it must be the LAST argument of `go`.
        const limits = `depth ${job.depth} nodes ${job.nodes} movetime ${job.movetime}`;
        this.#send(`go ${limits}${job.searchMoves?.length ? ` searchmoves ${job.searchMoves.join(' ')}` : ''}`);
      } catch (error) { finish(error); }
    });
  }

  /** Entry point used by the pool: `kind: 'legal'` lists legal moves, anything else is a search. */
  run(job, signal) {
    if (job.kind === 'legal') return this.legalMoves(job).then(legal => ({ legal }));
    return this.search(job, signal);
  }

  /** Legal moves of a position (`go perft 1`), used to validate move lists before they are trusted. */
  async legalMoves({ fen, moves = [] }) {
    if (!this.alive) throw new EngineError('Stockfish chưa sẵn sàng.', { code: 'engine_down' });
    if (this.busy) throw new EngineError('Engine đang bận.', { code: 'engine_busy' });
    this.busy = true;
    try {
      this.#send(`position fen ${fen}${moves.length ? ` moves ${moves.join(' ')}` : ''}`);
      const lines = await this.#command('go perft 1', /^Nodes searched:\s*\d+/i, 10_000);
      return lines.map(line => /^([a-h][1-8][a-h][1-8][qrbn]?):\s*\d+/.exec(line)?.[1]).filter(Boolean);
    } finally { this.busy = false; }
  }

  kill() {
    this.alive = false;
    try { this.proc?.kill('SIGKILL'); } catch { /* already dead */ }
    for (const listener of [...this.listeners]) listener(null, new EngineError('Stockfish đã bị dừng.', { code: 'engine_exited' }));
    this.listeners.clear();
  }

  quit() { try { this.#send('quit'); } catch { /* ignore */ } setTimeout(() => this.kill(), 300).unref?.(); }
}
