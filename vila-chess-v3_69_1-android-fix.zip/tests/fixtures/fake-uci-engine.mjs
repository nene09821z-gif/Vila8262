#!/usr/bin/env node
// Deterministic stand-in for Stockfish used by the analysis-server tests.
//   FAKE_SCRIPT      principal line, e.g. "e2e4 e7e5 g1f3": best move at ply n is script[n] when the moves so far follow the script
//   FAKE_GAP         centipawn gap between line 1 and line 2 (default 200)
//   FAKE_DELAY_MS    time every search takes (default 5)
//   FAKE_CRASH_FILE  if set and the file does not exist, create it and crash on the first `go` (tests engine recovery)
//   FAKE_LOG         append every received `go` line to this file (tests caching / de-duplication)
import { appendFileSync, existsSync, writeFileSync } from 'node:fs';
import readline from 'node:readline';

const script = (process.env.FAKE_SCRIPT || 'e2e4 e7e5 g1f3 b8c6').split(/\s+/);
const gap = Number(process.env.FAKE_GAP || 200);
const delay = Number(process.env.FAKE_DELAY_MS || 5);
const LEGAL = ['e2e4', 'e7e5', 'g1f3', 'b8c6', 'd2d4', 'd7d5', 'a2a3', 'h7h6', 'g8f6', 'd1d8'];
let multipv = 1; let fen = ''; let moves = [];
const out = line => process.stdout.write(`${line}\n`);
const hash = text => [...text].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7);

readline.createInterface({ input: process.stdin }).on('line', raw => {
  const line = raw.trim();
  const [cmd] = line.split(/\s+/);
  if (cmd === 'uci') { out('id name FakeFish 1'); out('uciok'); }
  else if (cmd === 'isready') out('readyok');
  else if (cmd === 'setoption') { const m = /name MultiPV value (\d+)/.exec(line); if (m) multipv = Number(m[1]); }
  else if (cmd === 'position') {
    const m = /^position fen (.+?)(?: moves (.+))?$/.exec(line);
    fen = m ? m[1] : ''; moves = m?.[2] ? m[2].split(/\s+/) : [];
  } else if (cmd === 'go' && /perft 1/.test(line)) {
    for (const move of LEGAL) out(`${move}: 1`);
    out(''); out(`Nodes searched: ${LEGAL.length}`);
  } else if (cmd === 'go') {
    if (process.env.FAKE_LOG) appendFileSync(process.env.FAKE_LOG, `${fen}|${moves.join(' ')}|${line}\n`);
    if (process.env.FAKE_CRASH_FILE && !existsSync(process.env.FAKE_CRASH_FILE)) { writeFileSync(process.env.FAKE_CRASH_FILE, 'x'); process.exit(1); }
    setTimeout(() => {
      if (fen.startsWith('7k/5Q2/6K1')) { out('info depth 0 score mate 0'); out('bestmove (none)'); return; }
      const follows = moves.every((move, i) => script[i] === move);
      const best = follows && script[moves.length] ? script[moves.length] : 'a2a3';
      const base = (hash(fen + moves.join(' ')) % 120) - 60;
      const searchMoves = /searchmoves (.+)$/.exec(line)?.[1]?.split(/\s+/);
      if (searchMoves) {
        const only = searchMoves[0];
        const score = only === best ? base : base - 300;
        out(`info depth 12 seldepth 14 multipv 1 score cp ${score} nodes 5000 nps 1000000 time 5 pv ${only}`);
        out(`bestmove ${only}`); return;
      }
      out(`info depth 8 seldepth 9 multipv 1 score cp ${base - 10} nodes 100 nps 1000000 time 1 pv ${best}`);
      out(`info depth 12 seldepth 14 multipv 1 score cp ${base} lowerbound nodes 4000 nps 1000000 time 4 pv ${best}`);
      for (let i = 1; i <= multipv; i += 1) {
        const move = i === 1 ? best : (LEGAL.find(m => m !== best && !m.startsWith('d1')) || 'd2d4');
        const score = base - (i - 1) * gap;
        out(`info depth 12 seldepth 14 multipv ${i} score cp ${score} nodes ${5000 * i} nps 1000000 hashfull 3 tbhits 0 time 5 pv ${move} ${i === 1 ? script.slice(moves.length + 1, moves.length + 3).join(' ') : ''}`.trim());
      }
      out(`bestmove ${best}`);
    }, delay);
  } else if (cmd === 'quit') process.exit(0);
});
