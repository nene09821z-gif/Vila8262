import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { normalizeFen, fenKey, halfmoveClock } from '../analysis-server/src/fen.js';
import { resolveLimits, QUALITY_PRESETS } from '../analysis-server/src/quality.js';
import { parseInfoLine, UciEngine } from '../analysis-server/src/uci.js';
import { AnalysisCache } from '../analysis-server/src/cache.js';
import { createAuthenticator, WindowLimiter, generateKey } from '../analysis-server/src/auth.js';
import { loadConfig } from '../analysis-server/src/config.js';
import { EnginePool, QueueFullError } from '../analysis-server/src/pool.js';
import { createAnalysisService, scoreToCp } from '../analysis-server/src/service.js';
import { startAnalysisServer } from '../analysis-server/src/index.js';
import { locateEngine } from '../analysis-server/src/engine-locator.js';
import { checkAnalysisServer, remoteReviewPositions, remoteAnalyzePosition, remoteLinesToUciInfo } from '../src/remote-analysis.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const FAKE = path.join(here, 'fixtures', 'fake-uci-engine.mjs');
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const MATED = '7k/5Q2/6K1/8/8/8/8/8 b - - 0 1';
const KEY = 'test-key-0123456789-abcdefghij';
const tmp = prefix => fs.mkdtempSync(path.join(os.tmpdir(), prefix));

function spawnWithEnv(cmd, args, opts, env) { return spawn(cmd, args, { ...opts, env: { ...process.env, ...env } }); }

/** Start the real HTTP server on a random port, backed by the fake engine. */
async function withServer(envOverrides = {}, configOverrides = {}, fn) {
  const dir = tmp('vila-as-');
  const fakeEnv = { FAKE_LOG: path.join(dir, 'go.log'), ...(envOverrides.fake || {}) };
  const config = { ...loadConfig({ ANALYSIS_API_KEYS: KEY, PORT: '0', ANALYSIS_CACHE_FILE: '', ANALYSIS_WORKERS: '2', ANALYSIS_LOG: '0', ...(envOverrides.env || {}) }), ...configOverrides };
  const saved = {};
  for (const [k, v] of Object.entries(fakeEnv)) { saved[k] = process.env[k]; process.env[k] = v; }
  const running = await startAnalysisServer(config, { engine: { command: process.execPath, args: [FAKE], kind: 'native' } });
  const base = `http://127.0.0.1:${running.address.port}`;
  const post = (route, body, { key = KEY, headers = {}, raw } = {}) => fetch(`${base}${route}`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}), ...headers }, body: raw ?? JSON.stringify(body) });
  try { await fn({ base, post, running, goLog: () => (fs.existsSync(fakeEnv.FAKE_LOG) ? fs.readFileSync(fakeEnv.FAKE_LOG, 'utf8').trim().split('\n').filter(Boolean) : []) }); }
  finally { await running.close(); for (const [k, v] of Object.entries(saved)) { if (v === undefined) delete process.env[k]; else process.env[k] = v; } fs.rmSync(dir, { recursive: true, force: true }); }
}

test('normalizeFen accepts real positions and rejects anything that could crash an engine', () => {
  assert.equal(normalizeFen(START), START);
  assert.equal(normalizeFen('4k3/8/8/8/8/8/8/4K3 w - -'), '4k3/8/8/8/8/8/8/4K3 w - - 0 1');
  assert.ok(normalizeFen('rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3'));
  for (const bad of [
    '', 'nonsense', null, 42, START.replace(' w ', ' x '),
    '4k3/8/8/8/8/8/8/8 w - - 0 1',                // no white king
    '4k3/8/8/8/8/8/8/4K2k w - - 0 1',             // two black kings
    '4k3/8/8/8/8/8/8/3kK3 w - - 0 1',             // kings adjacent
    '4k3/4R3/8/8/8/8/8/4K3 w - - 0 1',            // side NOT to move (black) is in check
    'p3k3/8/8/8/8/8/8/4K3 w - - 0 1',             // pawn on the eighth rank
    '4k3/8/8/8/8/8/8/4K3 w KQ - 0 1',             // castling rights without rooks
    START.replace('KQkq -', 'KQkq e3'),           // en passant square without the pawn
    '9/8/8/8/8/8/8/8 w - - 0 1', '44k3/8/8/8/8/8/8/4K3 w - - 0 1', `${START} extra extra`, `${START}${' '.repeat(200)}`,
  ]) assert.equal(normalizeFen(bad), null, String(bad));
  assert.equal(fenKey(START), 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -');
  assert.equal(halfmoveClock('4k3/8/8/8/8/8/8/4K3 w - - 37 60'), 37);
});

test('quality presets are node-bounded, MultiPV-scaled, and explicit budgets rank honestly', () => {
  const standard = resolveLimits({ quality: 'standard' });
  assert.equal(standard.nodes, QUALITY_PRESETS.standard.nodes);
  assert.ok(resolveLimits({ quality: 'standard', multipv: 2 }).nodes > standard.nodes);
  assert.ok(resolveLimits({ quality: 'deep', light: true }).nodes < QUALITY_PRESETS.deep.nodes);
  assert.equal(resolveLimits({ quality: 'bogus' }).quality, 'standard');
  assert.equal(resolveLimits({ multipv: 99 }).multipv, 5);
  const probe = resolveLimits({ nodes: 10_000 });
  assert.equal(probe.rank, 0, 'a tiny health probe must never satisfy a real request from the cache');
  assert.equal(resolveLimits({ nodes: 1e12 }).nodes, QUALITY_PRESETS.max.nodes, 'node budgets are capped');
});

test('parseInfoLine keeps exact scores only', () => {
  const ok = parseInfoLine('info depth 20 seldepth 28 multipv 2 score cp -34 nodes 123456 nps 1000000 hashfull 10 tbhits 0 time 123 pv e2e4 e7e5 g1f3');
  assert.deepEqual(ok, { multipv: 2, depth: 20, score: -34, scoreType: 'cp', nodes: 123456, nps: 1000000, pv: ['e2e4', 'e7e5', 'g1f3'] });
  assert.equal(parseInfoLine('info depth 5 score mate 3 pv d1d8').scoreType, 'mate');
  assert.equal(parseInfoLine('info depth 5 score mate 3 pv d1d8').multipv, 1);
  assert.equal(parseInfoLine('info depth 20 multipv 1 score cp 50 lowerbound nodes 1 pv e2e4'), null);
  assert.equal(parseInfoLine('info depth 20 multipv 1 score cp 50 upperbound nodes 1 pv e2e4'), null);
  assert.equal(parseInfoLine('info string NNUE evaluation using nn.nnue'), null);
  assert.equal(parseInfoLine('info depth 3 multipv 1 score cp 10 pv zz99'), null);
});

test('scoreToCp mirrors the app: mates dominate and shorter mates are larger', () => {
  assert.equal(scoreToCp({ scoreType: 'cp', score: 35 }), 35);
  assert.ok(scoreToCp({ scoreType: 'mate', score: 1 }) > scoreToCp({ scoreType: 'mate', score: 5 }));
  assert.ok(scoreToCp({ scoreType: 'mate', score: -1 }) < -9000);
  assert.equal(scoreToCp({ scoreType: 'mate', score: 0 }), -10000);
});

test('AnalysisCache: higher rank satisfies lower, never downgrades, evicts LRU, persists atomically', () => {
  const dir = tmp('vila-cache-');
  const file = path.join(dir, 'c.jsonl');
  const cache = new AnalysisCache({ maxEntries: 100, file });
  const line = n => ({ multipv: n, depth: 10, score: n, scoreType: 'cp', nodes: 1, pv: ['e2e4'] });
  cache.set('a', { rank: 2, multipv: 2, bestmove: 'e2e4', lines: [line(1), line(2)] });
  assert.equal(cache.get('a', { rank: 1, multipv: 1 }).lines.length, 1, 'extra MultiPV lines are trimmed for a weaker request');
  assert.equal(cache.get('a', { rank: 3, multipv: 1 }), null, 'a stronger request is a miss');
  assert.equal(cache.get('a', { rank: 2, multipv: 3 }), null);
  cache.set('a', { rank: 1, multipv: 1, bestmove: 'd2d4', lines: [line(1)] });
  assert.equal(cache.get('a', { rank: 2, multipv: 2 }).bestmove, 'e2e4', 'a weaker result never overwrites a stronger one');
  cache.set('probe', { rank: 0, multipv: 1, bestmove: 'e2e4', lines: [line(1)] });
  assert.equal(cache.size, 1, 'rank-0 probes are not cached');
  for (let i = 0; i < 150; i += 1) cache.set(`k${i}`, { rank: 1, multipv: 1, bestmove: 'e2e4', lines: [line(1)] });
  assert.equal(cache.size, 100);
  assert.equal(cache.get('a', { rank: 1, multipv: 1 }), null, 'the oldest entry was evicted');
  assert.equal(cache.save(), true);
  fs.appendFileSync(file, '{"torn json');
  const reloaded = new AnalysisCache({ maxEntries: 100, file });
  assert.equal(reloaded.load(), 100);
  assert.ok(reloaded.get('k149', { rank: 1, multipv: 1 }));
  assert.equal(fs.existsSync(`${file}.tmp`), false, 'the temp file is renamed away');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('authenticator uses constant-time digests and the limiter blocks bursts', () => {
  const key = generateKey();
  assert.equal(key.length, 48);
  const auth = createAuthenticator([key, 'second-key-with-enough-length']);
  assert.match(auth.verify(`Bearer ${key}`), /^[0-9a-f]{8}$/);
  assert.equal(auth.verify(`bearer ${key}`) !== null, true);
  assert.equal(auth.verify('Bearer wrong'), null);
  assert.equal(auth.verify(key), null);
  assert.equal(auth.verify(''), null);
  let t = 0;
  const limiter = new WindowLimiter({ max: 3, windowMs: 1000, now: () => t });
  assert.deepEqual([1, 2, 3, 4].map(() => limiter.hit('x').allowed), [true, true, true, false]);
  assert.equal(limiter.blocked('x'), true);
  t = 1500;
  assert.equal(limiter.hit('x').allowed, true, 'the window resets');
});

test('loadConfig refuses unsafe setups', () => {
  assert.throws(() => loadConfig({ HOST: '0.0.0.0' }), /ANALYSIS_API_KEYS/);
  assert.throws(() => loadConfig({ ANALYSIS_API_KEYS: 'short' }), /24/);
  assert.throws(() => loadConfig({ ANALYSIS_API_KEYS: `REPLACE_${'x'.repeat(30)}` }), /khóa mẫu|mẫu/);
  assert.throws(() => loadConfig({ HOST: '0.0.0.0', ANALYSIS_ALLOW_NO_AUTH: '1' }), /ANALYSIS_API_KEYS/, 'no-auth is only allowed on loopback');
  assert.equal(loadConfig({ ANALYSIS_ALLOW_NO_AUTH: '1' }).noAuth, true);
  const ok = loadConfig({ ANALYSIS_API_KEYS: `${KEY}, ${KEY}x`, ANALYSIS_WORKERS: '3', ANALYSIS_HASH_MB: '64' });
  assert.equal(ok.keys.length, 2); assert.equal(ok.workers, 3); assert.equal(ok.hashMb, 64);
});

test('pool runs jobs in parallel, serves interactive requests first, bounds the queue and recovers from a crash', async () => {
  const dir = tmp('vila-pool-');
  const crashFile = path.join(dir, 'crash');
  const make = env => () => new UciEngine({ command: process.execPath, args: [FAKE], spawnImpl: (c, a, o) => spawnWithEnv(c, a, o, env) });
  const job = fen => ({ fen, multipv: 1, depth: 10, nodes: 1000, movetime: 1000 });

  const pool = new EnginePool({ size: 2, createEngine: make({ FAKE_DELAY_MS: '40' }) });
  const order = [];
  const runs = [
    pool.run(job(START), { priority: 1 }).then(() => order.push('bulk1')),
    pool.run(job(START), { priority: 1 }).then(() => order.push('bulk2')),
    pool.run(job(START), { priority: 1 }).then(() => order.push('bulk3')),
    pool.run(job(START), { priority: 0 }).then(() => order.push('urgent')),
  ];
  await Promise.all(runs);
  assert.ok(order.indexOf('urgent') < order.indexOf('bulk3'), `interactive work jumps the queue: ${order}`);
  await pool.close();

  const small = new EnginePool({ size: 1, maxQueue: 1, createEngine: make({ FAKE_DELAY_MS: '60' }) });
  const first = small.run(job(START)); const second = small.run(job(START));
  await assert.rejects(small.run(job(START)), QueueFullError);
  await Promise.all([first, second]); await small.close();

  const crashing = new EnginePool({ size: 1, createEngine: make({ FAKE_CRASH_FILE: crashFile }) });
  const result = await crashing.run(job(START));
  assert.equal(result.bestmove, 'e2e4', 'the job is retried on a fresh engine after the first one crashed');
  assert.equal(crashing.stats().restarts, 1);
  await crashing.close();

  const aborting = new EnginePool({ size: 1, createEngine: make({ FAKE_DELAY_MS: '200' }) });
  const busy = aborting.run(job(START));
  const controller = new AbortController();
  const queued = aborting.run(job(START), { signal: controller.signal });
  controller.abort();
  await assert.rejects(queued, /hủy/);
  await busy; await aborting.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

test('service: cache hit, in-flight de-duplication and no caching of cancelled searches', async () => {
  const dir = tmp('vila-svc-');
  const log = path.join(dir, 'go.log');
  const pool = new EnginePool({ size: 2, createEngine: () => new UciEngine({ command: process.execPath, args: [FAKE], spawnImpl: (c, a, o) => spawnWithEnv(c, a, o, { FAKE_LOG: log, FAKE_DELAY_MS: '80' }) }) });
  const cache = new AnalysisCache({ maxEntries: 1000 });
  const service = createAnalysisService({ pool, cache });
  const goCount = () => (fs.existsSync(log) ? fs.readFileSync(log, 'utf8').trim().split('\n').length : 0);

  const [a, b] = await Promise.all([service.analyze({ fen: START, quality: 'fast' }), service.analyze({ fen: START, quality: 'fast' })]);
  assert.equal(goCount(), 1, 'two identical concurrent requests share one search');
  assert.deepEqual(a.lines, b.lines);
  const again = await service.analyze({ fen: START.replace(' 0 1', ' 5 9'), quality: 'fast' });
  assert.equal(again.cached, true, 'move counters do not change the cache key');
  assert.equal(goCount(), 1);
  const stronger = await service.analyze({ fen: START, quality: 'deep' });
  assert.equal(stronger.cached, false);
  assert.equal((await service.analyze({ fen: START, quality: 'standard' })).cached, true, 'a deeper stored result serves a shallower request');
  const nearDraw = await service.analyze({ fen: START.replace(' 0 1', ' 90 60'), quality: 'fast' });
  assert.equal(nearDraw.cached, false, 'positions near the 50-move rule bypass the cache');

  const other = '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1';
  const controller = new AbortController();
  const cancelled = service.analyze({ fen: other, quality: 'fast', signal: controller.signal });
  setTimeout(() => controller.abort(), 10);
  await assert.rejects(cancelled, /hủy/);
  await new Promise(resolve => setTimeout(resolve, 200));
  assert.equal(cache.get(fenKey(other), { rank: 1, multipv: 1 }), null, 'a cancelled search is never cached');
  await assert.rejects(service.analyze({ fen: 'garbage' }), /FEN/);
  await pool.close(); fs.rmSync(dir, { recursive: true, force: true });
});

test('HTTP: public health, bearer auth, validation, CORS and body limits', async () => {
  await withServer({}, {}, async ({ base, post }) => {
    const health = await (await fetch(`${base}/health`)).json();
    assert.equal(health.ok, true); assert.equal(health.engine, 'FakeFish 1'); assert.equal(health.auth, true);
    assert.equal(JSON.stringify(health).includes(KEY), false);

    assert.equal((await post('/v1/analyze', { fen: START }, { key: null })).status, 401);
    assert.equal((await post('/v1/analyze', { fen: START }, { key: 'wrong-key-wrong-key-wrong' })).status, 401);
    const ok = await post('/v1/analyze', { fen: START, multipv: 2, quality: 'fast' });
    assert.equal(ok.status, 200);
    assert.equal(ok.headers.get('cache-control'), 'no-store');
    assert.equal(ok.headers.get('x-content-type-options'), 'nosniff');
    const body = await ok.json();
    assert.equal(body.bestmove, 'e2e4'); assert.equal(body.lines.length, 2); assert.equal(body.cached, false);
    assert.equal((await (await post('/v1/analyze', { fen: START, multipv: 2, quality: 'fast' })).json()).cached, true);

    assert.equal((await post('/v1/analyze', { fen: 'nope' })).status, 400);
    assert.equal((await post('/v1/analyze', { fen: START, quality: 'turbo' })).status, 400);
    assert.equal((await post('/v1/analyze', { fen: START, multipv: 'x' })).status, 400);
    assert.equal((await post('/v1/analyze', null, { raw: '{broken' })).status, 400);
    assert.equal((await post('/v1/analyze', null, { raw: '[]' })).status, 400);
    assert.equal((await post('/v1/analyze', { fen: START }, { headers: { 'Content-Type': 'text/plain' } })).status, 415);
    assert.equal((await post('/v1/analyze', { fen: START, pad: 'x'.repeat(300_000) })).status, 413);
    assert.equal((await fetch(`${base}/v1/analyze`, { headers: { Authorization: `Bearer ${KEY}` } })).status, 405);
    assert.equal((await fetch(`${base}/nothing`)).status, 404);

    const allowed = await fetch(`${base}/v1/analyze`, { method: 'OPTIONS', headers: { Origin: 'https://localhost', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Private-Network': 'true' } });
    assert.equal(allowed.status, 204);
    assert.equal(allowed.headers.get('access-control-allow-origin'), 'https://localhost');
    assert.equal(allowed.headers.get('access-control-allow-private-network'), 'true');
    assert.equal((await fetch(`${base}/v1/analyze`, { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } })).status, 403);
    const actual = await post('/v1/analyze', { fen: START }, { headers: { Origin: 'https://evil.example' } });
    assert.equal(actual.headers.get('access-control-allow-origin'), null, 'unlisted origins get no CORS grant');
  });
});

test('HTTP: failed-auth throttling and per-key rate limits', async () => {
  await withServer({ env: { ANALYSIS_RATE_PER_MIN: '4' } }, {}, async ({ post }) => {
    const statuses = [];
    for (let i = 0; i < 5; i += 1) statuses.push((await post('/v1/analyze', { fen: START, quality: 'fast' })).status);
    assert.deepEqual(statuses, [200, 200, 200, 200, 429]);
    const limited = await post('/v1/analyze', { fen: START, quality: 'fast' });
    assert.ok(Number(limited.headers.get('retry-after')) >= 1);
  });
  await withServer({}, {}, async ({ post }) => {
    for (let i = 0; i < 20; i += 1) assert.equal((await post('/v1/analyze', { fen: START }, { key: 'wrong-key-wrong-key-wrong' })).status, 401);
    assert.equal((await post('/v1/analyze', { fen: START }, { key: 'wrong-key-wrong-key-wrong' })).status, 429, 'brute forcing the key is throttled');
    assert.equal((await post('/v1/analyze', { fen: START })).status, 429, 'even a right key is refused from a blocked address until the window passes');
  });
});

test('HTTP /v1/review streams NDJSON: out-of-order positions, progress, terminal positions, cache reuse', async () => {
  await withServer({}, {}, async ({ post, goLog }) => {
    const positions = [{ fen: START }, { fen: MATED }, { fen: START, light: true }, { fen: '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1' }];
    const response = await post('/v1/review', { positions, quality: 'standard' });
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-type'), /application\/x-ndjson/);
    const events = (await response.text()).split('\n').filter(Boolean).map(line => JSON.parse(line));
    const results = events.filter(e => e.type === 'position').sort((a, b) => a.index - b.index);
    assert.equal(results.length, 4);
    assert.equal(results[0].bestmove, 'e2e4');
    assert.equal(results[0].lines.length, 2, 'standard quality asks for MultiPV 2 so only-moves can be detected');
    assert.equal(results[1].terminal, true); assert.deepEqual(results[1].lines, []);
    const progress = events.filter(e => e.type === 'progress');
    assert.equal(progress.at(-1).done, 4);
    const done = events.at(-1);
    assert.equal(done.type, 'done'); assert.equal(done.total, 4); assert.equal(done.failed, 0);
    assert.ok(goLog().length <= 3, 'duplicate positions inside one game are searched once');

    const second = (await (await post('/v1/review', { positions, quality: 'fast' })).text()).split('\n').filter(Boolean).map(line => JSON.parse(line));
    assert.equal(second.at(-1).cached, 4, 'reviewing the same game again is served entirely from the cache');

    const fast = (await (await post('/v1/review', { positions: [{ fen: '4k3/8/8/8/8/8/3P4/4K3 w - - 0 1' }], quality: 'fast' })).text()).split('\n').filter(Boolean).map(line => JSON.parse(line));
    assert.equal(fast.find(e => e.type === 'position').lines.length, 1, 'fast quality uses a single line, like the on-device review');

    assert.equal((await post('/v1/review', { positions: [] })).status, 400);
    assert.equal((await post('/v1/review', { positions: [{ fen: 'bad' }] })).status, 400);
    assert.equal((await post('/v1/review', { positions: Array.from({ length: 401 }, () => ({ fen: START })) })).status, 413);
  });
});

test('HTTP /v1/puzzle/verify checks legality, best move and uniqueness', async () => {
  await withServer({ fake: { FAKE_SCRIPT: 'e2e4 e7e5 g1f3 b8c6' } }, {}, async ({ post }) => {
    const good = await (await post('/v1/puzzle/verify', { fen: START, moves: ['e2e4', 'e7e5', 'g1f3', 'b8c6'] })).json();
    assert.equal(good.ok, true); assert.equal(good.reason, 'verified'); assert.equal(good.steps.length, 2);
    const wrong = await (await post('/v1/puzzle/verify', { fen: START, moves: ['e2e4', 'd7d5'] })).json();
    assert.equal(wrong.ok, false); assert.equal(wrong.reason, 'not_best');
    const illegal = await (await post('/v1/puzzle/verify', { fen: START, moves: ['e2e4', 'a1a8'] })).json();
    assert.equal(illegal.reason, 'illegal_move');
    assert.equal((await post('/v1/puzzle/verify', { fen: START, moves: ['zz'] })).status, 400);
    assert.equal((await post('/v1/puzzle/verify', { fen: 'bad', moves: ['e2e4', 'e7e5'] })).status, 400);
  });
  await withServer({ fake: { FAKE_SCRIPT: 'e2e4 e7e5', FAKE_GAP: '20' } }, {}, async ({ post }) => {
    const loose = await (await post('/v1/puzzle/verify', { fen: START, moves: ['e2e4', 'e7e5'] })).json();
    assert.equal(loose.ok, false); assert.equal(loose.reason, 'not_unique');
    const lenient = await (await post('/v1/puzzle/verify', { fen: START, moves: ['e2e4', 'e7e5'], requireUnique: false })).json();
    assert.equal(lenient.ok, true);
  });
});

test('the app client (src/remote-analysis.js) speaks the server protocol', async () => {
  await withServer({}, {}, async ({ base }) => {
    assert.equal((await checkAnalysisServer({ url: base, key: KEY })).ok, true);
    const wrongKey = await checkAnalysisServer({ url: base, key: 'x'.repeat(32) });
    assert.equal(wrongKey.ok, false); assert.match(wrongKey.reason, /Khóa truy cập không đúng/);
    assert.equal((await checkAnalysisServer({ url: 'http://127.0.0.1:1', key: KEY, timeoutMs: 1500 })).ok, false);

    const single = await remoteAnalyzePosition({ url: base, key: KEY, fen: START, multipv: 2, quality: 'fast' });
    assert.equal(single.bestmove, 'e2e4'); assert.equal(single.lines.length, 2);
    const info = remoteLinesToUciInfo(single.lines);
    assert.match(info[0], /^info depth 12 multipv 1 score cp -?\d+ nodes \d+ pv e2e4/);

    const got = new Map(); const ticks = [];
    const summary = await remoteReviewPositions({
      url: base, key: KEY, quality: 'standard',
      positions: [{ fen: START }, { fen: '4k3/8/8/8/8/8/4P3/4K3 w - - 0 1' }, { fen: MATED }],
      onResult: (index, result) => got.set(index, result), onProgress: (done, total) => ticks.push([done, total]),
    });
    assert.equal(summary.total, 3); assert.equal(summary.failed, 0);
    assert.equal(got.size, 3); assert.equal(got.get(0).bestmove, 'e2e4'); assert.deepEqual(got.get(2).lines, []);
    assert.deepEqual(ticks.at(-1), [3, 3]);
    await assert.rejects(remoteReviewPositions({ url: base, key: 'x'.repeat(32), positions: [{ fen: START }] }), /Khóa truy cập/);
  });
});

test('real Stockfish: finds a back-rank mate, scores startpos sanely and verifies a puzzle', { skip: !locateEngine({ PATH: '' }) && 'Stockfish WebAssembly build not present' }, async () => {
  const engine = locateEngine({ PATH: '' });
  const config = loadConfig({ ANALYSIS_API_KEYS: KEY, PORT: '0', ANALYSIS_CACHE_FILE: '', ANALYSIS_WORKERS: '1', ANALYSIS_LOG: '0' });
  const running = await startAnalysisServer(config, { engine });
  const base = `http://127.0.0.1:${running.address.port}`;
  const post = (route, body) => fetch(`${base}${route}`, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}` }, body: JSON.stringify(body) }).then(r => r.json());
  try {
    assert.match(running.engineName, /Stockfish/);
    const mate = await post('/v1/analyze', { fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1', quality: 'fast' });
    assert.equal(mate.bestmove, 'd1d8'); assert.equal(mate.lines[0].scoreType, 'mate'); assert.equal(mate.lines[0].score, 1);
    const opening = await post('/v1/analyze', { fen: START, quality: 'fast', multipv: 2 });
    assert.equal(opening.lines.length, 2);
    assert.ok(Math.abs(opening.lines[0].score) < 100 && opening.lines[0].scoreType === 'cp');
    assert.ok(opening.lines[0].depth >= 8);
    const verified = await post('/v1/puzzle/verify', { fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1', moves: ['d1d8'], opponentFirst: false, quality: 'fast' });
    assert.equal(verified.ok, true, JSON.stringify(verified));
    const blunder = await post('/v1/puzzle/verify', { fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1', moves: ['g1h1'], opponentFirst: false, quality: 'fast' });
    assert.equal(blunder.ok, false); assert.equal(blunder.reason, 'not_best');
  } finally { await running.close(); }
});
