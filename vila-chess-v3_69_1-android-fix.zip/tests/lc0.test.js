import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Position, perft, START_FEN, moveToUci } from '../src/lc0/board.js';
import { encodePlanes, policyCell } from '../src/lc0/encode.js';
import { loadLc0Net } from '../src/lc0/weights.js';
import { Lc0Network } from '../src/lc0/network.js';
import { Lc0Search, replayGame } from '../src/lc0/mcts.js';
import { buildConvModule, createSimdConv, writeTapTable, TAP_TABLE_BYTES } from '../src/lc0/simd-kernel.js';
import { LC0_NETS, isLc0Profile } from '../src/lc0/lc0-client.js';

const netBytes = id => fs.readFileSync(new URL(`../public/lc0/${id}.pb.gz`, import.meta.url));

test('move generator matches the published perft counts', () => {
  assert.equal(perft(Position.fromFen(START_FEN), 3), 8902);
  assert.equal(perft(Position.fromFen('r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1'), 3), 97862);
  assert.equal(perft(Position.fromFen('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'), 4), 43238);
  assert.equal(perft(Position.fromFen('r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1'), 3), 9467);
});

test('FEN round-trips and repetition signatures differ by side/castling', () => {
  const fen = 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1';
  assert.equal(Position.fromFen(fen).fen(), fen);
  const a = Position.fromFen(fen); const b = Position.fromFen(fen.replace(' w ', ' b '));
  assert.notEqual(a.signature(), b.signature());
});

test('input planes: side to move is always "ours" and black sees a flipped board', () => {
  const white = encodePlanes([Position.fromFen(START_FEN)]);
  const black = encodePlanes([Position.fromFen('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1')]);
  assert.equal(white[0 * 64 + 8], 1, 'our pawn on a2');
  assert.equal(black[0 * 64 + 8], 1, 'black pawn a7 appears on our second rank');
  assert.equal(black[108 * 64], 1, 'black-to-move plane');
  assert.equal(white[108 * 64], 0);
  assert.equal(white[111 * 64 + 5], 1, 'constant plane');
});

test('policy cells: queen promotion uses the promotion plane, knight moves their own planes', () => {
  const pos = Position.fromFen('8/P7/8/8/8/8/6k1/K7 w - - 0 1');
  const queen = pos.parseUci('a7a8q');
  assert.ok(queen > 0);
  assert.equal(pos.parseUci('a7a8n') > 0, true);
  assert.equal(moveToUci(queen), 'a7a8q');
  assert.equal(policyCell(queen, 0, pos.board), (64 + 1 * 3 + 2) * 64 + 48);
  const start = Position.fromFen(START_FEN);
  assert.equal(policyCell(start.parseUci('g1f3'), 0, start.board), (56 + 7) * 64 + 6);
  assert.equal(policyCell(start.parseUci('e2e4'), 0, start.board), (0 * 7 + 1) * 64 + 12);
});

test('WASM-SIMD convolution kernel assembles, validates and matches the scalar reference', { skip: typeof WebAssembly === 'undefined' }, () => {
  assert.ok(WebAssembly.validate(buildConvModule()));
  const cin = 32; const cout = 32; const memory = new WebAssembly.Memory({ initial: 16 });
  const f = new Float32Array(memory.buffer); const i32 = new Int32Array(memory.buffer);
  let off = 0; const alloc = n => { const o = off; off += n * 4; return o; };
  const taps = alloc(TAP_TABLE_BYTES / 4); writeTapTable(i32, taps);
  const inP = alloc(64 * cin); const wP = alloc(9 * cin * cout); const bP = alloc(cout); const oP = alloc(64 * cout);
  let seed = 7; const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 2 ** 32; };
  for (let k = 0; k < 64 * cin; k += 1) f[(inP >> 2) + k] = rnd() < 0.4 ? 0 : rnd() * 2 - 1;
  for (let k = 0; k < 9 * cin * cout; k += 1) f[(wP >> 2) + k] = rnd() * 0.2 - 0.1;
  for (let k = 0; k < cout; k += 1) f[(bP >> 2) + k] = rnd() - 0.5;
  const conv = createSimdConv(memory); assert.ok(conv, 'kernel should be available on Node 22');
  conv(inP, cin, wP, bP, cout, oP, 1, taps);
  let maxErr = 0;
  for (let s = 0; s < 64; s += 1) for (let o = 0; o < cout; o += 1) {
    let sum = f[(bP >> 2) + o];
    for (let dr = -1; dr <= 1; dr += 1) for (let df = -1; df <= 1; df += 1) {
      const nf = (s & 7) + df; const nr = (s >> 3) + dr; if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
      const tap = (dr + 1) * 3 + df + 1; const n = nr * 8 + nf;
      for (let i = 0; i < cin; i += 1) sum += f[(inP >> 2) + n * cin + i] * f[(wP >> 2) + (tap * cin + i) * cout + o];
    }
    maxErr = Math.max(maxErr, Math.abs(Math.max(0, sum) - f[(oP >> 2) + s * cout + o]));
  }
  assert.ok(maxErr < 1e-4, `max error ${maxErr}`);
});

test('bundled Maia nets load and play sensible chess (SIMD and JS paths agree)', async () => {
  const parsed = await loadLc0Net(netBytes('maia-1500'));
  assert.equal(parsed.format.policy, 2);
  const fast = new Lc0Network(parsed, { simd: true }); const slow = new Lc0Network(parsed, { simd: false });
  const pos = Position.fromFen(START_FEN); const planes = encodePlanes([pos]);
  const a = fast.forward(planes); const b = slow.forward(planes);
  assert.ok(Math.abs(a.q - b.q) < 1e-3);
  const search = new Lc0Search(fast);
  const opening = await search.search({ fen: START_FEN }, { nodes: 1 });
  assert.ok(['e2e4', 'd2d4', 'g1f3', 'c2c4'].includes(opening.uci), `opening move ${opening.uci}`);
});

test('MCTS finds mate in one, takes a hanging queen and promotes', async () => {
  const net = new Lc0Network(await loadLc0Net(netBytes('maia-1900')));
  const search = new Lc0Search(net);
  const mate = await search.search({ fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4' }, { nodes: 200, timeMs: 3000 });
  assert.equal(mate.uci, 'h5f7');
  const promo = await search.search({ fen: '8/P7/8/8/8/8/6k1/K7 w - - 0 1' }, { nodes: 150, timeMs: 3000 });
  assert.equal(promo.uci, 'a7a8q');
  const history = replayGame(undefined, ['e2e4', 'e7e5', 'g1f3', 'b8c6']);
  assert.equal(history.length, 5);
  const reply = await search.search({ moves: ['e2e4', 'e7e5', 'g1f3', 'b8c6'] }, { nodes: 100, timeMs: 3000 });
  assert.ok(Position.fromFen(history[4].fen()).parseUci(reply.uci) >= 0, 'legal reply');
});

test('a game with a single legal move or none returns without searching', async () => {
  const net = new Lc0Network(await loadLc0Net(netBytes('maia-1100')));
  const search = new Lc0Search(net);
  const forced = await search.search({ fen: 'k7/8/8/8/8/8/6q1/7K w - - 0 1' }, { nodes: 50 });
  assert.equal(forced.nodes, 0);
  assert.equal(forced.uci, 'h1g2');
  assert.equal(await search.search({ fen: '7k/8/8/8/8/8/5q2/7K w - - 0 1' }, { nodes: 50 }), null, 'stalemate has no move');
});

test('engine catalog exposes the separate Lc0 nets and keeps the classical fallback', async () => {
  assert.deepEqual(LC0_NETS.map(n => n.id), ['lc0-maia-1100', 'lc0-maia-1500', 'lc0-maia-1900', 'lc0-custom']);
  for (const net of LC0_NETS.filter(n => n.file)) assert.ok(fs.existsSync(new URL(`../public/${net.file}`, import.meta.url)), net.file);
  assert.ok(isLc0Profile('lc0-maia-1500') && !isLc0Profile('lc0'));
  const core = fs.readFileSync(new URL('../src/alternate-engine-core.js', import.meta.url), 'utf8');
  assert.match(core, /\.\.\.LC0_NETS\.map/);
  const wrapper = fs.readFileSync(new URL('../src/alternate-engine.js', import.meta.url), 'utf8');
  assert.match(wrapper, /chooseLc0Move\(requested, fen, options\)/);
  assert.match(wrapper, /profile: 'lc0', engine: 'lc0'/);
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /const neural = isLc0Profile\(profile\)/);
  assert.match(main, /lc0Game: currentLc0Game\(\)/);
  const schema = fs.readFileSync(new URL('../src/settings-schema.js', import.meta.url), 'utf8');
  for (const id of LC0_NETS.map(n => n.id)) assert.ok(schema.includes(`'${id}'`), id);
});

test('every Lc0 file stays free of DOM globals so it can run inside the worker', () => {
  for (const file of ['board', 'encode', 'weights', 'network', 'simd-kernel', 'mcts', 'lc0-worker']) {
    const source = fs.readFileSync(new URL(`../src/lc0/${file}.js`, import.meta.url), 'utf8');
    assert.ok(!/\bdocument\.|\bwindow\.|localStorage/.test(source), `${file}.js uses a DOM global`);
  }
});
