import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { buildKeyMoments, buildNarrative, estimatePerformanceElo, findAdjacentKeyPly, engineLineFens, buildAnnotatedPgn } from '../src/review-insights.js';
import { insightsMarkup, momentCardMarkup, reviewToolsMarkup, lineBannerMarkup } from '../src/review-insights-view.js';

const SANS = ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Nxd5', 'Nxf7', 'Kxf7', 'Qf3+', 'Ke6', 'Nc3', 'Ncb4'];
// evaluation after each ply, white perspective (cp)
const EVAL = [30, 25, 35, 30, 40, 35, 60, 20, 90, 0, -250, 120, 180, 150, 600, 700];
const judgement = { 11: 'blunder', 10: 'mistake', 9: 'great', 15: 'brilliant', 7: 'inaccuracy', 12: 'mistake' };
function rows() {
  return SANS.map((san, i) => ({
    ply: i + 1, mover: i % 2 === 0 ? 'w' : 'b', san,
    scoreBeforeWhiteCp: i ? EVAL[i - 1] : 20, scoreWhiteCp: EVAL[i], scoreType: 'cp',
    judgement: judgement[i + 1] ? { key: judgement[i + 1], label: judgement[i + 1] } : { key: 'good', label: 'Tốt' },
    bestMoveSan: 'Qe2', moveWasBest: false
  }));
}

test('key moments pick the biggest mistakes and positives, in order, with the turning point flagged', () => {
  const moments = buildKeyMoments(rows());
  assert.ok(moments.length >= 3 && moments.length <= 6);
  assert.deepEqual(moments.map(m => m.ply), [...moments.map(m => m.ply)].sort((a, b) => a - b));
  const blunder = moments.find(m => m.ply === 11);
  assert.equal(blunder.kind, 'blunder'); assert.ok(blunder.swingPct > 15); assert.equal(blunder.bestSan, 'Qe2');
  assert.ok(moments.some(m => m.kind === 'brilliant' && m.ply === 15));
  assert.ok(moments.some(m => m.turning), 'one move must be marked as the turning point');
  for (const m of moments) assert.ok(m.severity > 0 && m.severity <= 1);
});

test('key moments tolerate empty, partial and malformed rows', () => {
  assert.deepEqual(buildKeyMoments([]), []);
  assert.deepEqual(buildKeyMoments(null), []);
  assert.doesNotThrow(() => buildKeyMoments([{ ply: 1 }, { ply: 2, mover: 'w', san: 'e4' }, null]));
});

test('performance Elo grows with accuracy and refuses tiny samples', () => {
  const a = estimatePerformanceElo(55, 20), b = estimatePerformanceElo(80, 20), c = estimatePerformanceElo(97, 20);
  assert.ok(a < b && b < c);
  assert.ok(estimatePerformanceElo(0, 20) >= 250 && estimatePerformanceElo(100, 20) <= 2850);
  assert.equal(estimatePerformanceElo(90, 3), null);
  assert.equal(estimatePerformanceElo(NaN, 30), null);
  assert.equal(estimatePerformanceElo(75, 30) % 25, 0);
});

test('narrative mentions the opening, the turning point, each side\'s worst mistake and the result', () => {
  const text = buildNarrative(rows(), { names: { w: 'An', b: 'Bình' }, opening: 'Ván Hai Mã', result: '1-0' }).map(l => l.text).join(' | ');
  assert.match(text, /Ván Hai Mã/);
  assert.match(text, /Bước ngoặt/);
  assert.match(text, /Sai lầm lớn nhất của An|Sai lầm lớn nhất của Bình/);
  assert.match(text, /thiên tài/);
  assert.match(text, /An \(Trắng\) thắng/);
  assert.deepEqual(buildNarrative(rows().slice(0, 3), {}), [], 'too short to narrate');
});

test('jumping between serious mistakes works both ways and ends cleanly', () => {
  const r = rows();
  assert.equal(findAdjacentKeyPly(r, 0, 1), 10);
  assert.equal(findAdjacentKeyPly(r, 10, 1), 11);
  assert.equal(findAdjacentKeyPly(r, 11, 1), 12);
  assert.equal(findAdjacentKeyPly(r, 12, 1), null);
  assert.equal(findAdjacentKeyPly(r, 11, -1), 10);
  assert.equal(findAdjacentKeyPly(r, 10, -1), null);
  assert.equal(findAdjacentKeyPly(r, 0, 1, { side: 'b' }), 10);
});

test('engineLineFens replays legal moves and stops at the first illegal one', () => {
  class Fake {
    constructor(fen) { this.f = fen; this.n = 0; }
    move({ from, to }) { if (from === 'z9') return null; this.n += 1; return { san: `m${this.n}`, from, to }; }
    fen() { return `${this.f}#${this.n}`; }
  }
  const steps = engineLineFens('start', ['e2e4', 'e7e5', 'g1f3'], Fake);
  assert.deepEqual(steps.map(s => s.san), ['m1', 'm2', 'm3']);
  assert.equal(steps[2].fen, 'start#3');
  assert.equal(engineLineFens('start', ['e2e4', 'bad', 'g1f3'], Fake).length, 1);
  assert.deepEqual(engineLineFens('', ['e2e4'], Fake), []);
  assert.deepEqual(engineLineFens('start', ['e2e4'], null), []);
});

test('annotated PGN carries headers, NAGs, evals and the better move', () => {
  const pgn = buildAnnotatedPgn(rows(), { headers: { White: 'An', Black: 'Bình' }, result: '1-0' });
  assert.match(pgn, /\[White "An"\]/); assert.match(pgn, /\[Result "1-0"\]/);
  const flat = pgn.replace(/\s+/g, ' ');
  assert.match(flat, /6\. Nxf7 \$4 \{ \[%eval -2\.50\] · blunder · Nên đi: Qe2 \}/);
  assert.match(flat, /8\. Nc3 \$3 \{[^}]*Nước thiên tài/);
  assert.match(flat, /1\. e4 \{ \[%eval 0\.30\] \} 1\.\.\. e5/);
  assert.match(pgn.trim(), /1-0$/);
  const quoted = buildAnnotatedPgn(rows(), { headers: { White: 'Nguy"ễn' } });
  assert.match(quoted, /\[White "Nguy\\"ễn"\]/);
  const custom = buildAnnotatedPgn(rows(), { startFen: '8/8/8/8/8/8/8/K6k w - - 0 1' });
  assert.match(custom, /\[SetUp "1"\]/); assert.match(custom, /\[FEN "8\/8\/8\/8\/8\/8\/8\/K6k w - - 0 1"\]/);
  assert.ok(!/ } }/.test(pgn));
});

test('annotated PGN stops at the first gap and handles mate evals', () => {
  const r = rows(); r.splice(5, 1);
  const pgn = buildAnnotatedPgn(r, {});
  assert.doesNotMatch(pgn, /Nxf7/);
  const mate = [{ ply: 1, mover: 'w', san: 'Qh5#', scoreWhiteCp: 10000, scoreType: 'mate', mateWhite: 0, judgement: { key: 'best' } }];
  assert.match(buildAnnotatedPgn(mate, {}), /\[%eval #0\]/);
});

test('views escape user text and expose jump targets', () => {
  const moments = buildKeyMoments(rows());
  const html = insightsMarkup({ analyzed: true, narrative: [{ tone: 'warn', icon: '⚠', text: '<img src=x onerror=1>' }], perf: { w: { accuracy: 81.2, elo: 1650 }, b: { accuracy: 60, elo: 900 } }, moments, names: { w: '<b>An</b>', b: 'Bình' } });
  assert.ok(!html.includes('<img'));
  assert.ok(!html.includes('<b>An</b>'));
  assert.match(html, /data-review-jump-ply="11"/);
  assert.match(html, /≈ 1650/);
  assert.match(insightsMarkup({ analyzed: false }), /Phân tích toàn ván/);
  assert.match(insightsMarkup({ analyzed: false, reviewing: true }), /đang phân tích/i);
  assert.match(momentCardMarkup({ ply: 3, moveNumber: 2, mover: 'w', san: 'Nf3', kind: 'turning', label: 'Bước ngoặt', swingPct: 20, beforePct: 60, afterPct: 40, severity: .4, bestSan: '', turning: true }), /Bước ngoặt/);
});

test('tools and line banner reflect state', () => {
  assert.match(reviewToolsMarkup({ canLine: false, hasRows: false }), /data-review-line="toggle" disabled/);
  assert.match(reviewToolsMarkup({ canLine: true, lineActive: true, hasRows: true }), /Thoát biến/);
  const banner = lineBannerMarkup({ label: '11. Nxf7', index: 2, playing: true, steps: [{ san: 'Qe2' }, { san: 'Nf6' }, { san: 'Nc3' }] });
  assert.match(banner, /Biến Stockfish từ nước 11\. Nxf7/); assert.match(banner, /Qe2/); assert.match(banner, /2\/3/);
  assert.equal(lineBannerMarkup(null), '');
});

test('main.js wires insights, key-mistake jumps, engine line preview and PGN export', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  for (const needle of ['id="reviewInsights"', 'id="reviewTools"', 'id="reviewLineBanner"', 'data-review-jump-ply', "data-review-export", 'startReviewLine', 'jumpToKeyMistake', 'buildAnnotatedPgn']) assert.ok(main.includes(needle), needle);
});
