import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { parseRow, passesFilters, selectBand, bandOf, packRow } from '../scripts/build-puzzle-pack.mjs';
import { normalizePackIndex, nearestBandIndex, bandSearchOrder, parsePackRow, themeOptions, preparePackEntry, createPuzzlePack, loadPackSeen, rememberPackSeen } from '../src/puzzle-pack.js';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const OPTS = { minPopularity: 90, minPlays: 1000, maxDeviation: 85, maxPlies: 12 };

/** Minimal stand-in for chess.js: accepts any move and changes the FEN, enough to test the plumbing. */
class FakeChess {
  constructor(fen = START) { this.value = fen; this.n = 0; }
  move() { this.n += 1; this.value = `${this.value.split(' ')[0]}${this.n} ${this.value.split(' ').slice(1).join(' ')}`; return { san: 'x' }; }
  fen() { return this.value; }
}

function csvLine(id, rating, themes, { pop = 95, plays = 5000, dev = 75, moves = 'e2e4 e7e5 g1f3' } = {}) {
  return `${id},${START},${moves},${rating},${dev},${pop},${plays},${themes},https://lichess.org/${id},`;
}

test('parseRow reads the Lichess CSV layout and skips the header', () => {
  assert.equal(parseRow('PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags'), null);
  const p = parseRow(csvLine('00sHx', 1500, 'fork middlegame'));
  assert.equal(p.id, '00sHx'); assert.equal(p.rating, 1500); assert.deepEqual(p.themes, ['fork', 'middlegame']);
  assert.deepEqual(p.moves, ['e2e4', 'e7e5', 'g1f3']);
});

test('passesFilters rejects unpopular, rarely played, uncertain or malformed puzzles', () => {
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork')), OPTS), true);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork', { pop: 40 })), OPTS), false);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork', { plays: 20 })), OPTS), false);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork', { dev: 200 })), OPTS), false);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork', { moves: 'e2e4' })), OPTS), false);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 1500, 'fork', { moves: 'e2e4 zz99' })), OPTS), false);
  assert.equal(passesFilters(parseRow(csvLine('aaaaa', 200, 'fork')), OPTS), false);
});

test('selectBand keeps rare themes instead of letting the common theme take every slot', () => {
  const rows = [];
  for (let i = 0; i < 50; i += 1) rows.push({ id: `f${i}`, themes: ['fork'], popularity: 99 - (i % 5), plays: 9000 });
  for (let i = 0; i < 3; i += 1) rows.push({ id: `s${i}`, themes: ['fork', 'smotheredMate'], popularity: 91, plays: 2000 });
  const rank = new Map([['smotheredMate', 0], ['fork', 1]]);
  const picked = selectBand(rows, rank, 10);
  assert.equal(picked.length, 10);
  assert.equal(picked.filter(p => p.themes.includes('smotheredMate')).length, 3);
});

test('bandOf clamps to the supported rating range', () => {
  assert.equal(bandOf(1234), 1200); assert.equal(bandOf(50), 400); assert.equal(bandOf(5000), 3200);
});

function fenFor(i) {
  const board = Array.from({ length: 8 }, () => Array(8).fill(1));
  board[0][i % 8] = 'k'; board[7][4] = 'K'; board[1 + (Math.floor(i / 64) % 6)][Math.floor(i / 8) % 8] = 'R';
  const rows = board.map(row => { let out = ''; let gap = 0; for (const cell of row) { if (cell === 1) gap += 1; else { if (gap) out += gap; gap = 0; out += cell; } } return out + (gap || ''); });
  return `${rows.join('/')} w - - 0 1`;
}

test('the build script produces an index and band files end to end', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pack-'));
  const csv = path.join(dir, 'puzzles.csv');
  const lines = ['PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags'];
  for (let i = 0; i < 300; i += 1) {
    lines.push(`id${String(i).padStart(4, '0')},${fenFor(i)},e2e4 e7e5 g1f3,${800 + (i % 10) * 100},70,95,4000,${i % 9 === 0 ? 'fork rare' : 'fork'},u,`);
  }
  fs.writeFileSync(csv, lines.join('\n'));
  const out = path.join(dir, 'out');
  const run = spawnSync(process.execPath, ['scripts/build-puzzle-pack.mjs', csv, '--max', '300', '--out', out], { encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr);
  const index = JSON.parse(fs.readFileSync(path.join(out, 'index.json'), 'utf8'));
  assert.ok(index.total > 0 && index.total <= 300);
  assert.equal(index.bandWidth, 100);
  assert.equal(index.bands.length, 10);
  const rows = JSON.parse(fs.readFileSync(path.join(out, index.bands[0].file), 'utf8'));
  assert.equal(rows[0].length, 6);
  assert.ok(rows.some(row => row[4].includes('rare')), 'rare theme must survive stratified selection');
  assert.ok(index.themes.rare > 0);
});

test('normalizePackIndex rejects unsafe file names and empty indexes', () => {
  assert.equal(normalizePackIndex(null), null);
  assert.equal(normalizePackIndex({ bands: [{ min: 400, file: '../evil.json', count: 3 }] }), null);
  const ok = normalizePackIndex({ bandWidth: 100, bands: [{ min: 1200, file: 'band-1200.json', count: 5 }, { min: 400, file: 'band-400.json', count: 5 }] });
  assert.deepEqual(ok.bands.map(b => b.min), [400, 1200]);
});

test('band selection starts at the player rating and widens alternately', () => {
  const index = normalizePackIndex({ bands: [400, 500, 600, 700, 800].map(min => ({ min, max: min + 99, file: `band-${min}.json`, count: 1 })) });
  assert.equal(nearestBandIndex(index, 640), 2);
  assert.equal(nearestBandIndex(index, 9000), 4);
  assert.deepEqual(bandSearchOrder(index, 640, 2), [2, 1, 3, 0, 4]);
});

test('parsePackRow validates UCI moves; themeOptions hides meta tags', () => {
  assert.equal(parsePackRow(['a', START, 'e2e4', 1000, 'fork', 90]), null);
  assert.equal(parsePackRow(['a', START, 'e2e4 xx', 1000, 'fork', 90]), null);
  assert.equal(parsePackRow(['abc', START, 'e2e4 e7e5', 1000, 'fork short', 90]).themes.length, 2);
  const themes = themeOptions({ themes: { fork: 500, short: 9000, pin: 10, mate: 800 } }, 30).map(t => t.theme);
  assert.deepEqual(themes, ['mate', 'fork']);
});

test('preparePackEntry plays the opponent move first and returns the player line', () => {
  const entry = parsePackRow(['Ab12c', START, 'e2e4 e7e5 g1f3 b8c6', 1400, 'fork mateIn2', 95]);
  const prepared = preparePackEntry(entry, FakeChess);
  assert.equal(prepared.id, 'Ab12c');
  assert.deepEqual(prepared.moves, ['e7e5', 'g1f3', 'b8c6']);
  assert.equal(prepared.opponentMove, 'e2e4');
  assert.equal(prepared.mateIn, 2);
  assert.equal(prepared.gameUrl, 'https://lichess.org/training/Ab12c');
  assert.equal(preparePackEntry(entry, null), null);
});

test('createPuzzlePack picks unseen puzzles near the rating and honours the theme filter', async () => {
  const rowsFor = min => [0, 1, 2, 3].map(i => [`p${min}${i}`, START, 'e2e4 e7e5 g1f3', min + i * 10, i === 3 ? 'pin' : 'fork', 95]);
  const files = {
    'index.json': { bandWidth: 100, total: 8, bands: [{ min: 1000, file: 'band-1000.json', count: 4 }, { min: 1100, file: 'band-1100.json', count: 4 }], themes: { fork: 6, pin: 2 } },
    'band-1000.json': rowsFor(1000), 'band-1100.json': rowsFor(1100),
  };
  const fetchImpl = async url => { const key = String(url).split('/').pop(); return files[key] ? { ok: true, json: async () => files[key] } : { ok: false, status: 404 }; };
  const pack = createPuzzlePack({ fetchImpl, baseUrl: './puzzles/' });
  const seen = new Set();
  const first = await pack.pick({ rating: 1010, seenIds: seen, rng: () => 0.5, ChessClass: FakeChess });
  assert.ok(first && first.rating >= 1000);
  seen.add(first.id);
  const pinOnly = await pack.pick({ rating: 1010, theme: 'pin', seenIds: seen, rng: () => 0.5, ChessClass: FakeChess });
  assert.ok(pinOnly.themes.includes('pin'));
  const none = await pack.pick({ rating: 1010, theme: 'doesNotExist', seenIds: seen, rng: () => 0.5, ChessClass: FakeChess });
  assert.equal(none, null);
  assert.deepEqual((await pack.themes()).map(t => t.theme), []); // counts below the default minimum of 30
  const daily = await pack.daily('2026-10-26', FakeChess);
  const again = await pack.daily('2026-10-26', FakeChess);
  assert.equal(daily.id, again.id);
});

test('createPuzzlePack returns null when the pack is not installed', async () => {
  const pack = createPuzzlePack({ fetchImpl: async () => ({ ok: false, status: 404 }) });
  assert.equal(await pack.pick({ ChessClass: FakeChess }), null);
  assert.equal(await pack.available(), false);
});

test('seen-id memory is bounded and survives corrupt storage', () => {
  const store = new Map();
  const storage = { getItem: k => store.get(k) ?? null, setItem: (k, v) => store.set(k, v) };
  const seen = loadPackSeen(storage);
  rememberPackSeen(storage, seen, 'abc');
  assert.deepEqual([...loadPackSeen(storage)], ['abc']);
  store.set('vila.chess.puzzles.packSeen.v1', '{not json');
  assert.equal(loadPackSeen(storage).size, 0);
});
