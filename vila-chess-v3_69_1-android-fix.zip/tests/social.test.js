import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createSocialRouter } from '../server/social.js';

async function request(base, route, options = {}) {
  const headers = { ...(options.headers || {}) };
  const response = await fetch(`${base}${route}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  return { status: response.status, data };
}

test('community registration, friends, Top 100 and admin authorization work end-to-end', async () => {
  const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 'vila-social-test-'));
  const oldEnv = {
    ADMIN_USERNAME: process.env.ADMIN_USERNAME,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD,
    ADMIN_EMAIL: process.env.ADMIN_EMAIL,
    ADMIN_INITIAL_ELO: process.env.ADMIN_INITIAL_ELO,
    SOCIAL_TOKEN_SECRET: process.env.SOCIAL_TOKEN_SECRET,
    NODE_ENV: process.env.NODE_ENV,
    RESEND_API_KEY: process.env.RESEND_API_KEY,
    RESET_EMAIL_FROM: process.env.RESET_EMAIL_FROM
  };
  process.env.ADMIN_USERNAME = 'owner_admin';
  process.env.ADMIN_PASSWORD = 'T3st-only-Adm1n-passphrase';
  process.env.ADMIN_EMAIL = 'owner-admin@example.test';
  process.env.ADMIN_INITIAL_ELO = '3200';
  process.env.SOCIAL_TOKEN_SECRET = 'test-only-secret-that-is-not-for-production-and-has-over-32-bytes';
  delete process.env.NODE_ENV;
  delete process.env.RESEND_API_KEY;
  delete process.env.RESET_EMAIL_FROM;
  let server;
  try {
    const app = express();
    app.use(express.json({ limit: '1mb' }));
    app.use('/api/social', await createSocialRouter({ dataDir: tempDir }));
    server = app.listen(0, '127.0.0.1');
    await new Promise((resolve, reject) => { server.once('listening', resolve); server.once('error', reject); });
    const base = `http://127.0.0.1:${server.address().port}/api/social`;

    const adminLogin = await request(base, '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'owner_admin', password: process.env.ADMIN_PASSWORD }) });
    assert.equal(adminLogin.status, 200);
    assert.equal(adminLogin.data.user.role, 'admin');
    assert.equal(adminLogin.data.user.entitlement?.plan, 'premium', 'admin has all premium-gated features unlocked');
    assert.equal(adminLogin.data.user.elo, 3200, 'a newly provisioned admin starts at the configured Elo seed');
    const adminHeaders = { Authorization: `Bearer ${adminLogin.data.token}`, 'Content-Type': 'application/json' };
    assert.equal((await request(base, '/me/review-access', { method: 'POST', headers: adminHeaders, body: JSON.stringify({ gameId: 'admin-review-test' }) })).status, 200, 'admin bypasses review quota');
    const overview = await request(base, '/admin/overview', { headers: adminHeaders });
    assert.equal(overview.status, 200);
    assert.equal(overview.data.admins, 1);

    const alice = await request(base, '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'alice_one', displayName: 'Alice One', email: 'alice@example.test', password: 'Alice-Strong-Pass-123', initialElo: 1000 }) });
    const bob = await request(base, '/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'bobby_two', displayName: 'Bobby Two', email: 'bobby@example.test', password: 'Bobby-Strong-Pass-456', initialElo: 1000 }) });
    assert.equal(alice.status, 201);
    assert.equal(bob.status, 201);
    assert.ok(Number.isInteger(alice.data.user.avatarId) && alice.data.user.avatarId >= 0 && alice.data.user.avatarId < 1000);
    assert.equal(bob.data.user.elo, 1000, 'the selected initial Elo is used by the account');
    assert.ok(Number.isInteger(bob.data.user.avatarId) && bob.data.user.avatarId >= 0 && bob.data.user.avatarId < 1000);
    assert.notEqual(alice.data.user.avatarId, bob.data.user.avatarId, 'avatar ids stay unique while unused designs remain');

    const aliceHeaders = { Authorization: `Bearer ${alice.data.token}`, 'Content-Type': 'application/json' };
    const bobHeaders = { Authorization: `Bearer ${bob.data.token}`, 'Content-Type': 'application/json' };

    const nicknameLogin = await request(base, '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'Alice One', password: 'Alice-Strong-Pass-123' }) });
    assert.equal(nicknameLogin.status, 200, 'players can sign in using their unique nickname');
    const accountForgot = await request(base, '/auth/forgot-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'alice@example.test' }) });
    assert.equal(accountForgot.status, 503, 'email recovery explains when the mail provider is not configured');

    const announcement = await request(base, '/admin/announcements', { method: 'POST', headers: adminHeaders, body: JSON.stringify({ title: 'Thông báo thử nghiệm', message: 'Hộp thư hệ thống đã sẵn sàng.' }) });
    assert.equal(announcement.status, 201);
    const appInbox = await request(base, '/inbox', { headers: aliceHeaders });
    assert.equal(appInbox.status, 200);
    assert.equal(appInbox.data.unread, 1);
    assert.equal(appInbox.data.announcements[0].title, 'Thông báo thử nghiệm');
    const markRead = await request(base, `/inbox/${announcement.data.announcement.id}/read`, { method: 'POST', headers: aliceHeaders, body: '{}' });
    assert.equal(markRead.status, 200);
    const readInbox = await request(base, '/inbox', { headers: aliceHeaders });
    assert.equal(readInbox.data.unread, 0);

    const search = await request(base, '/users/search?q=bob', { headers: aliceHeaders });
    assert.equal(search.status, 200);
    assert.equal(search.data.users[0].username, 'bobby_two');
    const publicProfile = await request(base, '/users/bobby_two', { headers: aliceHeaders });
    assert.equal(publicProfile.status, 200, 'a search result can open a server-backed public player profile');
    assert.equal(publicProfile.data.user.username, 'bobby_two');
    assert.equal('email' in publicProfile.data.user, false, 'public profiles do not reveal email');
    assert.equal((await request(base, '/users/not_a_real_user', { headers: aliceHeaders })).status, 404);

    const firstMessage = await request(base, `/messages/${bob.data.user.id}`, { method: 'POST', headers: aliceHeaders, body: JSON.stringify({ text: 'Chào bạn, đánh một ván nhé!' }) });
    assert.equal(firstMessage.status, 201, 'players can start a private conversation without needing a pre-existing friend link');
    const bobMessages = await request(base, `/messages/${alice.data.user.id}`, { headers: bobHeaders });
    assert.equal(bobMessages.status, 200);
    assert.equal(bobMessages.data.messages[0].text, 'Chào bạn, đánh một ván nhé!');
    assert.equal(bobMessages.data.messages[0].fromMe, false);
    const aliceConversations = await request(base, '/messages/conversations', { headers: aliceHeaders });
    assert.equal(aliceConversations.status, 200);
    assert.equal(aliceConversations.data.conversations[0].user.username, 'bobby_two');

    const submittedReport = await request(base, `/users/${bob.data.user.id}/report`, { method: 'POST', headers: aliceHeaders, body: JSON.stringify({ reason: 'cheating', details: 'Nghi dùng engine trong ván online.' }) });
    assert.equal(submittedReport.status, 201);
    assert.equal((await request(base, `/users/${bob.data.user.id}/report`, { method: 'POST', headers: aliceHeaders, body: JSON.stringify({ reason: 'cheating' }) })).status, 409, 'duplicate unresolved reports are rate-limited per reporter and target');
    const reportsForAdmin = await request(base, '/admin/reports?status=pending', { headers: adminHeaders });
    assert.equal(reportsForAdmin.status, 200);
    assert.ok(reportsForAdmin.data.reports.some(report => report.id === submittedReport.data.report.id));
    assert.equal((await request(base, '/admin/reports?status=pending', { headers: aliceHeaders })).status, 403, 'only admins can view moderation reports');
    const dismissReport = await request(base, `/admin/reports/${submittedReport.data.report.id}`, { method: 'PATCH', headers: adminHeaders, body: JSON.stringify({ action: 'dismiss' }) });
    assert.equal(dismissReport.status, 200);

    const sent = await request(base, '/friends/request', { method: 'POST', headers: aliceHeaders, body: JSON.stringify({ username: 'bobby_two' }) });
    assert.equal(sent.status, 201);
    const bobInbox = await request(base, '/friends', { headers: bobHeaders });
    assert.equal(bobInbox.data.incoming.length, 1);
    const accepted = await request(base, `/friends/${bobInbox.data.incoming[0].id}/accept`, { method: 'POST', headers: bobHeaders, body: '{}' });
    assert.equal(accepted.status, 200);
    const aliceFriends = await request(base, '/friends', { headers: aliceHeaders });
    assert.equal(aliceFriends.data.friends.length, 1);
    assert.equal(aliceFriends.data.friends[0].username, 'bobby_two');

    // Real server-ranked flow: queue two accounts, reject an illegal move,
    // apply the loser penalty once, and let the opponent retrieve the result.
    const aliceQueue = await request(base, '/ranked/queue', { method: 'POST', headers: aliceHeaders, body: '{}' });
    assert.equal(aliceQueue.status, 202);
    assert.equal(aliceQueue.data.queued, true);
    const bobMatch = await request(base, '/ranked/queue', { method: 'POST', headers: bobHeaders, body: '{}' });
    assert.equal(bobMatch.status, 201);
    assert.equal(bobMatch.data.match.status, 'active');
    const rankedId = bobMatch.data.match.id;
    const whiteUserId = bobMatch.data.match.players.w.id;
    const whiteHeaders = whiteUserId === alice.data.user.id ? aliceHeaders : bobHeaders;
    const illegalMove = await request(base, `/ranked/matches/${rankedId}/move`, { method: 'POST', headers: whiteHeaders, body: JSON.stringify({ from: 'e2', to: 'e5', expectedPly: 0 }) });
    assert.equal(illegalMove.status, 400, 'server must reject a move that breaks chess rules');
    const resigned = await request(base, `/ranked/matches/${rankedId}/resign`, { method: 'POST', headers: aliceHeaders, body: '{}' });
    assert.equal(resigned.status, 200);
    assert.equal(resigned.data.match.status, 'finished');
    assert.equal(resigned.data.match.resultReason, 'resignation');
    assert.ok(resigned.data.match.eloChanges.delta <= -25, 'resigning user receives a regular loss plus the 15-Elo penalty');
    const bobResult = await request(base, '/ranked/status', { headers: bobHeaders });
    assert.equal(bobResult.status, 200);
    assert.equal(bobResult.data.match.id, rankedId, 'the opponent must also receive the finished result panel');
    assert.equal(bobResult.data.match.status, 'finished');
    assert.ok(bobResult.data.match.eloChanges.delta >= 10);

    // Top 100 only lists players whose license an admin approved.
    const emptyBoard = await request(base, '/leaderboard?limit=100');
    assert.equal(emptyBoard.status, 200);
    assert.equal(emptyBoard.data.totalPlayers, 0, 'unlicensed accounts are not ranked');
    for (const [account, headers, code] of [[alice, aliceHeaders, 'VILA-ALICE-01'], [bob, bobHeaders, 'VILA-BOB-02']]) {
      const submitted = await request(base, '/me/license', { method: 'POST', headers, body: JSON.stringify({ holderName: account.data.user.username, licenseCode: code }) });
      assert.equal(submitted.status, 201);
      const approved = await request(base, `/admin/licenses/${account.data.user.id}/decision`, { method: 'POST', headers: adminHeaders, body: JSON.stringify({ decision: 'approve' }) });
      assert.equal(approved.status, 200);
    }
    const selfApproval = await request(base, `/admin/licenses/${adminLogin.data.user.id}/decision`, { method: 'POST', headers: adminHeaders, body: JSON.stringify({ decision: 'approve' }) });
    assert.ok([403, 409].includes(selfApproval.status), 'admin cannot approve their own license');
    const leaderboard = await request(base, '/leaderboard?limit=100');
    assert.equal(leaderboard.status, 200);
    assert.equal(leaderboard.data.totalPlayers, 2);
    assert.equal(leaderboard.data.users.length, 2);
    assert.equal('email' in leaderboard.data.users[0], false);
    assert.deepEqual(leaderboard.data.users.map(user => user.username).sort(), ['alice_one', 'bobby_two'].sort());

    const forbidden = await request(base, '/admin/overview', { headers: aliceHeaders });
    assert.equal(forbidden.status, 403);
    const banned = await request(base, `/admin/users/${alice.data.user.id}`, { method: 'PATCH', headers: { ...adminHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'ban', reason: 'test ban' }) });
    assert.equal(banned.status, 200);
    const bannedMe = await request(base, '/auth/me', { headers: aliceHeaders });
    assert.equal(bannedMe.status, 403);
    const unbanned = await request(base, `/admin/users/${alice.data.user.id}`, { method: 'PATCH', headers: { ...adminHeaders, 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'unban', reason: 'test complete' }) });
    assert.equal(unbanned.status, 200);
    const revokedToken = await request(base, '/auth/me', { headers: aliceHeaders });
    assert.equal(revokedToken.status, 401, 'ban should revoke any token issued before the ban, even after unban');

    const badPassword = await request(base, '/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'alice_one', password: 'incorrect-password' }) });
    assert.equal(badPassword.status, 401);
    const audit = await request(base, '/admin/audit?limit=20', { headers: adminHeaders });
    assert.equal(audit.status, 200);
    assert.ok(audit.data.events.some(event => event.action === 'user_banned'));
  } finally {
    if (server) await new Promise(resolve => server.close(resolve));
    await fs.rm(tempDir, { recursive: true, force: true });
    for (const [key, value] of Object.entries(oldEnv)) {
      if (value === undefined) delete process.env[key]; else process.env[key] = value;
    }
  }
});
