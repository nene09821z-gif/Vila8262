import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import {
  START_FEN, whiteScore, evalToWhitePercent, formatScore, pvToNumberedSan, replayLine, ANALYSIS_TABS,
} from '../src/pages/analysis-page.js';
import { PUZZLE_MODES, PUZZLE_DIFFICULTIES, formatCount, renderPuzzlePrompt } from '../src/pages/puzzle-page.js';

const read = file => fs.readFileSync(new URL(file, import.meta.url), 'utf8');

test('whiteScore flips engine scores so they are always from White\'s side', () => {
  assert.deepEqual(whiteScore({ raw: 50, scoreType: 'cp' }, START_FEN), { cp: 50, mate: null });
  assert.deepEqual(whiteScore({ raw: 50, scoreType: 'cp' }, START_FEN.replace(' w ', ' b ')), { cp: -50, mate: null });
  assert.equal(whiteScore({ raw: 3, scoreType: 'mate' }, START_FEN.replace(' w ', ' b ')).mate, -3);
});

test('evaluation bar percentage is symmetric, bounded and handles mate', () => {
  assert.equal(evalToWhitePercent({ cp: 0, mate: null }), 50);
  assert.equal(evalToWhitePercent({ cp: null, mate: 2 }), 100);
  assert.equal(evalToWhitePercent({ cp: null, mate: -1 }), 0);
  const up = evalToWhitePercent({ cp: 300, mate: null });
  const down = evalToWhitePercent({ cp: -300, mate: null });
  assert.ok(up > 50 && up < 100);
  assert.ok(Math.abs(up + down - 100) < 0.2);
  assert.ok(evalToWhitePercent({ cp: 99999, mate: null }) < 100);
});

test('formatScore prints pawns and mate distances', () => {
  assert.equal(formatScore({ cp: 125, mate: null }), '+1.3');
  assert.equal(formatScore({ cp: -40, mate: null }), '-0.4');
  assert.equal(formatScore({ cp: null, mate: -3 }), '-M3');
  assert.equal(formatScore(null), '—');
});

test('pvToNumberedSan numbers moves and stops at the first illegal move', () => {
  assert.equal(pvToNumberedSan(Chess, START_FEN, ['e2e4', 'e7e5', 'g1f3']), '1. e4 e5 2. Nf3');
  const afterE4 = new Chess(START_FEN); afterE4.move('e4');
  assert.equal(pvToNumberedSan(Chess, afterE4.fen(), ['e7e5', 'g1f3']), '1… e5 2. Nf3');
  assert.equal(pvToNumberedSan(Chess, START_FEN, ['e2e4', 'e2e4', 'g1f3']), '1. e4');
});

test('replayLine keeps legal SAN moves and drops everything after an illegal one', () => {
  const line = replayLine(Chess, START_FEN, ['e4', 'e5', 'Qh5', 'Zz9', 'Nc6']);
  assert.deepEqual(line.sans, ['e4', 'e5', 'Qh5']);
  assert.deepEqual(line.uci, ['e2e4', 'e7e5', 'd1h5']);
  assert.equal(line.fens.length, 4);
});

test('analysis page has engine, opening and game tabs', () => {
  assert.deepEqual(ANALYSIS_TABS.map(tab => tab.id), ['engine', 'opening', 'game']);
});

test('puzzle page exposes the five chess.com modes and five difficulty levels', () => {
  assert.deepEqual(PUZZLE_MODES.map(mode => mode.id), ['classic', 'daily', 'rush', 'survival', 'custom']);
  assert.equal(PUZZLE_DIFFICULTIES.length, 5);
});

test('puzzle helpers format counts and never show the solution in the prompt', () => {
  assert.equal(formatCount(1500), '1500');
  assert.equal(formatCount(120000), '120k');
  assert.equal(formatCount(1_200_000), '1.2tr');
  const html = renderPuzzlePrompt({ status: 'ready', turn: 'b', statusChip: 'Lượt 1' });
  assert.match(html, /Lượt Đen/);
  assert.doesNotMatch(html, /solutionUci|data-solution/);
});

test('the chess.com page stylesheet is the last layer of the generated bundle and fits phones', () => {
  const layers = read('../scripts/build-professional-css.mjs');
  assert.ok(layers.lastIndexOf('chesscom-pages.css') > layers.lastIndexOf('vila-professional-theme.css'));
  const bundle = read('../src/vila-professional.css');
  assert.ok(bundle.includes('.cp-modes') && bundle.includes('.ap-bar'));
});
