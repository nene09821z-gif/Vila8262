import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizePackIndex, createPuzzlePack } from '../src/puzzle-pack.js';
import { shuffleKey } from '../scripts/build-puzzle-pack.mjs';

const index = {
  version: 3, bandWidth: 100,
  bands: [{ min: 1000, max: 1099, file: 'band-1000.json', files: ['band-1000.json', 'band-1000-1.json', 'band-1000-2.json', '../evil.json', 'band-1000-1.json'], count: 4500 }],
  themes: { fork: 900, mateIn2: 400 },
};

test('shard lists are whitelisted, de-duplicated and always contain the first file', () => {
  const normalized = normalizePackIndex(index);
  assert.deepEqual(normalized.bands[0].files, ['band-1000.json', 'band-1000-1.json', 'band-1000-2.json']);
  assert.equal(normalized.total, 4500);
});

test('a v2 index without shard lists still works', () => {
  const normalized = normalizePackIndex({ bandWidth: 100, bands: [{ min: 500, max: 599, file: 'band-500.json', count: 10 }], themes: {} });
  assert.deepEqual(normalized.bands[0].files, ['band-500.json']);
});

test('pick walks through shards and downloads each file at most once', async () => {
  const fetched = [];
  const row = (id, rating) => [id, '4k3/8/8/8/8/8/8/R3K3 b - - 0 1', 'e8d8 a1a8', rating, 'backRankMate', 100];
  const files = {
    'index.json': index,
    'band-1000.json': [row('aaa1', 1010)], 'band-1000-1.json': [row('bbb2', 1020)], 'band-1000-2.json': [row('ccc3', 1030)],
  };
  const pack = createPuzzlePack({ fetchImpl: async url => { const name = url.split('/').pop(); fetched.push(name); return files[name] ? { ok: true, json: async () => files[name] } : { ok: false }; } });
  // A stand-in rules class that accepts every move keeps this test independent of chess.js.
  class Rules { constructor(fen) { this.f = fen; } move() { return { san: 'x' }; } fen() { return this.f; } }
  const seen = new Set(['aaa1', 'bbb2']);
  const picked = await pack.pick({ rating: 1020, seenIds: seen, ChessClass: Rules, rng: () => 0 });
  assert.equal(picked.id, 'ccc3');
  assert.equal(fetched.filter(name => name === 'band-1000.json').length, 1);
});

test('shuffleKey is stable and spreads ids', () => {
  assert.equal(shuffleKey('00sHx'), shuffleKey('00sHx'));
  assert.notEqual(shuffleKey('00sHx'), shuffleKey('00sHy'));
});
