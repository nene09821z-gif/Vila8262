import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { ghostTransform, ghostCenter, offsetFromPoint, landDurationMs, liftFor } from '../src/board-drag-fx.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const interact = fs.readFileSync(new URL('../src/board-interact.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/board-motion.css', import.meta.url), 'utf8');
const profileCss = fs.readFileSync(new URL('../src/profile.css', import.meta.url), 'utf8');

test('touch lifts the ghost above the finger, mouse keeps it centred', () => {
  assert.ok(liftFor('touch') > liftFor('mouse'));
  assert.match(ghostTransform(10, 20, 'touch'), /translate\(-50%,-62%\)/);
  assert.match(ghostTransform(10, 20, 'mouse'), /translate\(-50%,-50%\)/);
  assert.deepEqual(ghostCenter(100, 200, 50, 'mouse'), { x: 100, y: 200 });
  assert.equal(ghostCenter(100, 200, 50, 'touch').y, 194);
});

test('landing offset is measured from the square centre and duration stays in range', () => {
  assert.deepEqual(offsetFromPoint({ left: 0, top: 0, width: 40, height: 40 }, { x: 50, y: 10 }), { dx: 30, dy: -10 });
  assert.equal(landDurationMs(0, 0, 40), 90);
  assert.equal(landDurationMs(4000, 0, 40), 170);
});

test('every interactive board shares the smooth drag pipeline', () => {
  assert.match(main, /from '\.\/board-drag-fx\.js'/);
  assert.match(interact, /from '\.\/board-drag-fx\.js'/);
  for (const source of [main, interact]) {
    assert.match(source, /landPieceFromPoint\(/);
    assert.match(source, /returnGhost\(/);
    assert.match(source, /ghostTransform\(/);
  }
  assert.match(main, /function patchBoardCells\(/);
  assert.match(css, /\.square\.sliding[\s\S]*overflow: visible/);
});

test('text buttons are not squeezed into the 31px icon box (profile history / Tactical Lab)', () => {
  assert.match(profileCss, /\.tiny-btn\.tiny-btn-text\s*\{[^}]*width: auto[^}]*white-space: nowrap/);
  for (const attr of ['data-profile-go="history"', 'data-profile-go="puzzles"', 'data-profile-review=']) {
    assert.match(main, new RegExp(`class="tiny-btn tiny-btn-text" ${attr.replace(/[=]/g, '=')}`));
  }
});

test('pen tools are also reachable right under the board', () => {
  assert.match(main, /id="boardPenToggle"/);
  assert.match(main, /id="annotationToolsDockBoard"/);
  assert.match(main, /#boardPenToggle[\s\S]*toggleAnnotationToolsDock\('board'\)/);
});
