import test from 'node:test';
import assert from 'node:assert/strict';
import { pseudoPremoveMoves } from '../src/premove.js';

/** Minimal board that only needs get() and fen(): no chess.js required. */
function position(fen) {
  const [placement, , rights = '-'] = fen.split(' ');
  const map = new Map();
  placement.split('/').forEach((row, i) => {
    let file = 0;
    for (const ch of row) {
      if (/\d/.test(ch)) { file += Number(ch); continue; }
      map.set(`${'abcdefgh'[file]}${8 - i}`, { type: ch.toLowerCase(), color: ch === ch.toUpperCase() ? 'w' : 'b' });
      file += 1;
    }
  });
  return { get: sq => map.get(sq), fen: () => `${placement} w ${rights} - 0 1` };
}
const targets = (pos, color, from) => pseudoPremoveMoves(pos, color, from).map(m => `${m.to}${m.promotion || ''}`).sort();

test('a rook may premove through an enemy piece but not through its own', () => {
  const pos = position('4k3/8/8/8/r2PPp2/8/8/R3K3 w - - 0 1');
  const t = targets(pos, 'b', 'a4');
  assert.ok(t.includes('d4') && t.includes('e4'), 'slides onto and through the enemy pawn on d4');
  assert.ok(t.includes('f4') === false, 'but stops at its own pawn on f4');
  assert.ok(t.includes('a1'), 'the white rook on a1 is a capture target');
});

test('a pawn can premove diagonally onto an empty square and onto an enemy piece, never forward onto a piece', () => {
  const pos = position('4k3/8/8/3p4/4P3/8/8/4K3 w - - 0 1');
  const t = targets(pos, 'w', 'e4');
  assert.deepEqual(t, ['d5', 'e5', 'f5']);
  const blocked = position('4k3/8/8/4p3/4P3/8/8/4K3 w - - 0 1');
  assert.ok(!targets(blocked, 'w', 'e4').includes('e5'));
});

test('two-square pawn push needs both squares free and the start rank', () => {
  const pos = position('4k3/8/8/8/8/8/4P3/4K3 w - - 0 1');
  assert.deepEqual(targets(pos, 'w', 'e2'), ['d3', 'e3', 'e4', 'f3']);
});

test('promotion premoves come with every piece choice', () => {
  const pos = position('4k3/P7/8/8/8/8/8/4K3 w - - 0 1');
  assert.deepEqual(targets(pos, 'w', 'a7'), ['a8b', 'a8n', 'a8q', 'a8r', 'b8b', 'b8n', 'b8q', 'b8r']);
});

test('knights ignore blockers, own pieces and enemy kings are not targets', () => {
  const pos = position('4k3/8/3K4/8/4N3/8/8/8 w - - 0 1');
  const t = targets(pos, 'w', 'e4');
  assert.ok(t.includes('d6') === false, 'own king square excluded');
  assert.ok(t.includes('f6') && t.includes('c5') && t.includes('g3'));
  assert.equal(pseudoPremoveMoves(position('4k3/8/8/8/8/8/8/R3K3 w - - 0 1'), 'w', 'a1').some(m => m.to === 'e8'), false);
});

test('castling premoves need the right and the rook on its home square', () => {
  const pos = position('4k3/8/8/8/8/8/8/R3K2R w KQ - 0 1');
  const t = targets(pos, 'w', 'e1');
  assert.ok(t.includes('g1') && t.includes('c1'));
  const noRights = position('4k3/8/8/8/8/8/8/R3K2R w - - 0 1');
  assert.ok(!targets(noRights, 'w', 'e1').includes('g1'));
  const own = position('4k3/8/8/8/8/8/8/R3KB1R w KQ - 0 1');
  assert.ok(!targets(own, 'w', 'e1').includes('g1'), 'own bishop on f1 blocks');
});

test('bad input is ignored', () => {
  assert.deepEqual(pseudoPremoveMoves(null, 'w'), []);
  assert.deepEqual(pseudoPremoveMoves({}, 'w'), []);
  assert.deepEqual(pseudoPremoveMoves(position('4k3/8/8/8/8/8/8/4K3 w - - 0 1'), 'x'), []);
});
