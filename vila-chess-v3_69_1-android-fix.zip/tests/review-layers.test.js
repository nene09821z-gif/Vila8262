import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { classifyCentipawnLoss, reviewSymbolDescription, MOVE_QUALITY_LABELS } from '../src/game-review.js';
import { layers, buildProfessionalCss } from '../scripts/build-professional-css.mjs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('game review has two layers (Tổng quan, Từng nước) and keeps every legacy control id', () => {
  const main = read('src/main.js');
  assert.match(main, /review-layer-tabs/);
  assert.match(main, /reviewLayer-overview/);
  assert.match(main, /reviewLayer-moves/);
  assert.match(main, /review-upper-grid/);
  for (const id of ['evaluationGraph', 'reviewSideStats', 'reviewProgress', 'reviewMoveAnalysis', 'reviewReplayBoard', 'reviewMoveDetail', 'reviewReplayPosition', 'reviewGameBtn', 'stopReviewBtn', 'reviewDownloadPGN', 'reviewMistakeTrainingBtn', 'resultPlayAgain', 'mistakeTrainingPanel']) {
    assert.ok(main.includes(id), `missing review control ${id}`);
  }
  assert.match(main, /function setReviewLayer\(/);
  assert.match(main, /reviewLayer === 'moves' && document\.getElementById\('fullGameResult'\)/, 'Android Back must leave the move layer before leaving the page');
});

test('review layer stylesheet is part of the runtime bundle and a hidden layer stays hidden', () => {
  assert.ok(layers.includes('review-layers.css'));
  assert.equal(read('src/vila-professional.css'), buildProfessionalCss());
  assert.match(read('src/review-layers.css'), /\.review-layer\[hidden\]\{display:none!important\}/);
});

test('move-quality wording is identical everywhere (no Chưa chuẩn, Chưa chính xác or bare Blunder)', () => {
  assert.equal(classifyCentipawnLoss(40).label, MOVE_QUALITY_LABELS.inaccuracy);
  assert.equal(classifyCentipawnLoss(400).label, MOVE_QUALITY_LABELS.blunder);
  assert.equal(MOVE_QUALITY_LABELS.inaccuracy, 'Thiếu chính xác');
  assert.equal(MOVE_QUALITY_LABELS.blunder, 'Sai lầm nghiêm trọng');
  assert.match(reviewSymbolDescription('blunder'), /^Sai lầm nghiêm trọng/);
  for (const file of ['src/main.js', 'src/game-review.js', 'README.md']) {
    const text = read(file);
    assert.doesNotMatch(text, /Chưa chuẩn|Chưa chính xác/, file);
  }
  assert.doesNotMatch(read('src/game-review.js'), /label: 'Blunder'/);
});

test('centipawn loss is shown with an unambiguous unit (quân tốt, not the adjective tốt)', () => {
  const main = read('src/main.js');
  assert.match(main, /quân tốt/);
  assert.doesNotMatch(main, /mất \$\{lossText\} tốt/);
});
