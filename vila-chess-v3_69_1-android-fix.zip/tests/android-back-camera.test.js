import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const kotlin = read('app/src/main/java/com/example/MainActivity.kt');
const manifest = read('app/src/main/AndroidManifest.xml');
const main = read('src/main.js');

test('native Back asks the page first and only exits on a second press from the home screen', () => {
  assert.match(kotlin, /window\.handleAppBack\(\) === true/);
  assert.match(kotlin, /if \(result != "true"\) exitOrWarn\(\)/);
  assert.match(kotlin, /now - lastBackAt < 2000L/);
  assert.match(kotlin, /\(context as\? Activity\)\?\.finish\(\)/);
  // The old behaviour walked the WebView history and could leave the app from deep inside a screen.
  assert.doesNotMatch(kotlin, /canGoBack|goBack\(\)/);
});

test('hand-tracking camera: WebView grants only the camera, only to the app origin, after the Android permission', () => {
  assert.match(kotlin, /override fun onPermissionRequest\(request: PermissionRequest\?\)/);
  assert.match(kotlin, /startsWith\("https:\/\/appassets\.androidplatform\.net"\)/);
  assert.match(kotlin, /request\.resources\.all \{ it == PermissionRequest\.RESOURCE_VIDEO_CAPTURE \}/);
  assert.match(kotlin, /ContextCompat\.checkSelfPermission\(ctx, Manifest\.permission\.CAMERA\)/);
  assert.match(kotlin, /rememberLauncherForActivityResult\(ActivityResultContracts\.RequestPermission\(\)\)/);
  assert.match(kotlin, /cameraLauncher\.launch\(Manifest\.permission\.CAMERA\)/);
  assert.match(kotlin, /if \(granted\) request\.grant\(arrayOf\(PermissionRequest\.RESOURCE_VIDEO_CAPTURE\)\) else request\.deny\(\)/);
  assert.doesNotMatch(kotlin, /RESOURCE_AUDIO_CAPTURE/);
  assert.match(manifest, /android\.permission\.CAMERA/);
  assert.match(manifest, /android\.hardware\.camera"[^>]*android:required="false"/);
  assert.match(manifest, /android\.hardware\.camera\.front"[^>]*android:required="false"/);
});

test('camera errors tell the player what to do instead of showing a raw DOMException', () => {
  assert.match(main, /name === 'NotAllowedError' \|\| name === 'SecurityError'/);
  assert.match(main, /Cài đặt › Ứng dụng › Cờ Vua › Quyền › Camera/);
});

// ---- Behaviour of window.handleAppBack, run against a tiny fake DOM --------------------------------------
function loadHandler(initial = {}) {
  const match = main.match(/window\.handleAppBack = function handleAppBack\(\) \{[\s\S]*?\n\};\n/);
  assert.ok(match, 'handleAppBack must exist in src/main.js');
  const calls = [];
  const elements = new Map();
  const classes = new Set(initial.bodyClasses || []);
  const el = (id, extra = {}) => {
    const attrs = {};
    const set = new Set(extra.classes || []);
    const node = {
      classList: { contains: name => set.has(name), remove: name => set.delete(name), add: name => set.add(name) },
      setAttribute: (name, value) => { attrs[name] = value; },
      click: () => calls.push(`click:${id}`),
      attrs
    };
    elements.set(id, node);
    return node;
  };
  for (const id of initial.elements || []) el(id);
  if (initial.menuOpen) { el('mainMenu', { classes: ['menu-open'] }); el('openMenu'); }
  const context = vm.createContext({
    window: {}, currentView: initial.view || 'home', gameStarted: Boolean(initial.gameStarted),
    document: {
      body: { classList: { contains: name => classes.has(name), remove: name => classes.delete(name) } },
      getElementById: id => elements.get(id) || null,
      querySelector: selector => selector === '#vilaConfirmModal [data-confirm-cancel]' && initial.confirmOpen
        ? { click: () => calls.push('click:confirm-cancel') } : null
    },
    closeResultModal: () => { elements.delete('resultModal'); calls.push('closeResultModal'); },
    openMatchSetup: () => calls.push('openMatchSetup'),
    setView: view => calls.push(`setView:${view}`)
  });
  vm.runInContext(match[0], context);
  return { back: () => context.window.handleAppBack(), calls, classes };
}

test('Back on the home screen is not handled, so the native side asks for a second press', () => {
  const { back, calls } = loadHandler({ view: 'home' });
  assert.equal(back(), false);
  assert.deepEqual(calls, []);
});

test('Back inside any other screen goes to home instead of leaving the app', () => {
  for (const view of ['puzzles', 'profile', 'admin', 'friends', 'play']) {
    const { back, calls } = loadHandler({ view, gameStarted: false });
    assert.equal(back(), true, view);
    assert.deepEqual(calls, ['setView:home'], view);
  }
});

test('Back during a live match opens the match setup (which asks before ending the game)', () => {
  const { back, calls } = loadHandler({ view: 'play', gameStarted: true });
  assert.equal(back(), true);
  assert.deepEqual(calls, ['openMatchSetup']);
});

test('Back closes overlays before anything else: confirm dialog, result dialog, match menu, main menu, promotion', () => {
  let h = loadHandler({ view: 'play', gameStarted: true, confirmOpen: true });
  assert.equal(h.back(), true); assert.deepEqual(h.calls, ['click:confirm-cancel']);

  h = loadHandler({ view: 'play', gameStarted: true, elements: ['resultModal'] });
  assert.equal(h.back(), true); assert.deepEqual(h.calls, ['closeResultModal']);

  h = loadHandler({ view: 'play', gameStarted: true, bodyClasses: ['match-sheet-open'], elements: ['openMatchMenu'] });
  assert.equal(h.back(), true); assert.deepEqual(h.calls, ['click:openMatchMenu']);

  h = loadHandler({ view: 'puzzles', menuOpen: true });
  assert.equal(h.back(), true); assert.deepEqual(h.calls, []);
  assert.equal(h.back(), true); assert.deepEqual(h.calls, ['setView:home'], 'second Back leaves the screen');

  h = loadHandler({ view: 'play', gameStarted: true, elements: ['cancelPromotion'] });
  assert.equal(h.back(), true); assert.deepEqual(h.calls, ['click:cancelPromotion']);
});

test('a failure inside the handler never traps the player: it reports "not handled"', () => {
  const match = main.match(/window\.handleAppBack = function handleAppBack\(\) \{[\s\S]*?\n\};\n/)[0];
  const context = vm.createContext({ window: {}, get currentView() { throw new Error('boom'); } });
  vm.runInContext(match, context);
  assert.equal(context.window.handleAppBack(), false);
});
