import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

function pngSize(file) {
  const bytes = fs.readFileSync(path.join(root, file));
  assert.equal(bytes.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${file} must be a PNG`);
  assert.ok(bytes.length > 100, `${file} should not be an empty placeholder`);
  return { width: bytes.readUInt32BE(16), height: bytes.readUInt32BE(20) };
}

test('ChessPlus header branding is compact while app launcher assets remain intact', () => {
  const html = read('index.html');
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '3.69.1');
  assert.match(html, /class="chessplus-brand"/, 'header includes the compact ChessPlus brand lockup');
  assert.match(html, /class="chessplus-wordmark"[\s\S]*chessplus[\s\S]*\.com/);
  assert.match(html, /\.\/chessplus-mark\.svg\?v=2/);
  assert.match(html, /favicon\.ico\?v=354/);
  assert.match(html, /manifest\.webmanifest\?v=354/);
  assert.match(main, /chessplus-mark\.svg\?v=2/);
  assert.match(sw, /chessplus-app-icon\.png\?v=2/);
  assert.match(sw, /v3\.69\.1/);
  assert.ok(fs.existsSync(path.join(root, 'public/chessplus-mark.svg')));
  assert.ok(fs.existsSync(path.join(root, 'resources/branding/chessplus-app-icon.png')));
  assert.ok(pngSize('public/chessplus-app-icon.png').width >= 1024);
  assert.ok(fs.statSync(path.join(root, 'public/chessplus-app-icon.png')).size > 100000, 'source app icon must stay sharp at high resolution');
  assert.deepEqual(pngSize('public/pwa-icon-512.png'), { width: 512, height: 512 });
  assert.deepEqual(pngSize('public/pwa-icon-192.png'), { width: 192, height: 192 });
});

test('obsolete memorial artwork is removed from Settings and offline precache', () => {
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  const settings = main.slice(main.indexOf('function renderSettingsView()'), main.indexOf('function wireCommonActions()'));
  assert.doesNotMatch(settings, /brand-showcase|memory-keepsake|vila-memory-monument/);
  assert.doesNotMatch(sw, /vila-memory-monument/);
  assert.equal(fs.existsSync(path.join(root, 'public/vila-memory-monument.webp')), false);
  assert.match(sw, /chessplus-mark\.svg\?v=2/);
});

test('all Android launcher density icons were regenerated and stay valid square PNGs', () => {
  const expected = { mdpi: 48, hdpi: 72, xhdpi: 96, xxhdpi: 144, xxxhdpi: 192 };
  for (const [density, size] of Object.entries(expected)) {
    for (const name of ['ic_launcher.png', 'ic_launcher_round.png']) {
      const file = `resources/android-icons/mipmap-${density}/${name}`;
      assert.deepEqual(pngSize(file), { width: size, height: size }, `${file} should match Android density`);
    }
    // Adaptive-icon layers are 108dp, not 48dp: 108 * (density scale).
    const layer = Math.round(size * 108 / 48);
    const fg = `resources/android-icons/mipmap-${density}/ic_launcher_foreground.png`;
    assert.deepEqual(pngSize(fg), { width: layer, height: layer }, `${fg} should be a 108dp adaptive layer`);
    // The round icon must be a real circle, never a byte-for-byte copy of the square launcher icon.
    assert.notDeepEqual(
      fs.readFileSync(path.join(root, `resources/android-icons/mipmap-${density}/ic_launcher_round.png`)),
      fs.readFileSync(path.join(root, `resources/android-icons/mipmap-${density}/ic_launcher.png`)),
      `mipmap-${density}: ic_launcher_round.png must differ from ic_launcher.png`
    );
    // The Android project copy and the branding source copy must stay identical.
    for (const name of ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_foreground.png']) {
      assert.deepEqual(
        fs.readFileSync(path.join(root, `app/src/main/res/mipmap-${density}/${name}`)),
        fs.readFileSync(path.join(root, `resources/android-icons/mipmap-${density}/${name}`)),
        `app/ and resources/ copies of mipmap-${density}/${name} must match`
      );
    }
  }
  const manifest = JSON.parse(read('public/manifest.webmanifest'));
  assert.equal(manifest.name, 'Cờ Vua');
  assert.ok(manifest.icons.some(icon => icon.src === './pwa-icon-512.png?v=2'));
  assert.ok(manifest.icons.some(icon => icon.purpose === 'maskable' && icon.sizes === '512x512'), 'a maskable 512 icon is declared for Android');
  for (const icon of manifest.icons) {
    const file = `public/${icon.src.replace(/^\.\//, '').replace(/\?.*$/, '')}`;
    const side = Number(icon.sizes.split('x')[0]);
    assert.deepEqual(pngSize(file), { width: side, height: side }, `${file} matches its manifest size`);
  }
  const adaptive = read('resources/android-icons/mipmap-anydpi-v26/ic_launcher.xml');
  assert.match(adaptive, /@mipmap\/ic_launcher_foreground/);
});

test('legacy VILA avatar asset and archived project bundle are absent', () => {
  assert.equal(fs.existsSync(path.join(root, 'public/vila-chess-avatar.svg')), false);
  assert.equal(fs.existsSync(path.join(root, 'public/assets/aistudio/CO_VUA_VILA_V3_46_2_BRANDING_UPDATE_0a403a66.zip')), false);
});
