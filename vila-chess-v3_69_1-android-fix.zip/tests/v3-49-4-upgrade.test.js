import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

 test('v3.49.5 adds explicit move, pencil and knight-L tools without removing legacy tools', () => {
  const main = read('src/main.js');
  for (const tool of ['move', 'arrow', 'pencil', 'knight', 'circle']) {
    assert.match(main, new RegExp(`data-annotation-tool="${tool}"`), `missing ${tool} tool`);
  }
  assert.match(main, /getCoalescedEvents\(\)/, 'pencil should use coalesced pointer samples');
  assert.match(main, /requested === 'move'\) annotationTool = null/, 'move tool should explicitly exit drawing mode');
  assert.match(main, /if \(virtualMouseHeld\) virtualMouseSetHeld\(false\)/, 'switching tools should release a held virtual mouse');
  assert.match(main, /id="virtualMouseToolsToggle"/);
  assert.match(main, /id="openDrawingTools"/);
  assert.match(main, /id="annotationToolsDockMouse"/);
  assert.match(main, /id="annotationToolsDockMenu"/);
  assert.doesNotMatch(main, /board-annotation-toolbar-row/);
});

test('coordinate mini-game supports scoring, a persisted best streak and square tap controls', () => {
  const main = read('src/main.js');
  assert.match(main, /function renderCoordinateGame\(\)/);
  assert.match(main, /data-coordinate-square/);
  assert.match(main, /vila\.coordinate\.best/);
  assert.match(main, /function handleCoordinateSquare\(square\)/);
  assert.match(main, /id: 'coordinates', icon: '⌖', label: 'Tọa độ'/);
});

test('the legacy VILA avatar is removed and the ChessPlus mark is used offline', () => {
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  const mark = read('public/chessplus-mark.svg');
  assert.match(mark, /<title[^>]*>ChessPlus<\/title>/);
  assert.match(main, /chessplus-mark\.svg\?v=2/);
  assert.match(sw, /chessplus-mark\.svg\?v=2/);
  assert.equal(fs.existsSync(path.join(root, 'public/vila-chess-avatar.svg')), false);
});

test('pencil and knight annotations have visible per-color styling and review layout is tightened', () => {
  const css = read('src/vila-v4.css');
  for (const selector of ['.manual-pencil-green', '.manual-pencil-red', '.manual-pencil-yellow', '.manual-pencil-blue', '.manual-knight-green', '.coordinate-board']) {
    assert.ok(css.includes(selector), `missing ${selector}`);
  }
  assert.match(css, /game-review-page \.review-upper-grid\{gap:10px\}/);
});

test('release version and Stockfish 19 engine build requirements agree', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const workflow = read('.github/workflows/build-from-zip.yml');
  assert.equal(pkg.version, '3.69.1');
  const gradle = read('app/build.gradle.kts');
  assert.match(gradle, /versionCode = 17\s+versionName = "3\.69\.1"/);
  assert.equal(lock.packages[''].version, pkg.version);
  assert.match(workflow, /INCLUDE_STOCKFISH_FULL: '1'/);
  assert.match(workflow, /stockfish-19-single\.wasm/);
});
