import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
// Slim GitHub ZIPs omit duplicated static files under app/src/main/assets; fall back to public/.
const readAndroid = file => {
  const androidPath = path.join(root, file);
  if (fs.existsSync(androidPath)) return fs.readFileSync(androidPath, 'utf8');
  return read(file.replace('app/src/main/assets/', 'public/'));
};

test('a separate match setup is rendered before the chessboard', () => {
  const main = read('src/main.js');
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(main, /function renderPlayView\(\)\s*\{\s*if \(!gameStarted\) return renderMatchSetupView\(\);/);
  const setup = main.slice(main.indexOf('function renderMatchSetupView()'), main.indexOf('function renderPlayView()'));
  for (const id of ['modeSelect', 'gameBotProfile', 'colorSelect', 'skillSelect', 'clockPreset', 'randomBotElo', 'startGameOverlay']) {
    assert.ok(setup.includes(`id="${id}"`), `setup screen missing ${id}`);
  }
  assert.match(setup, /Bàn cờ sẽ xuất hiện khi bạn bắt đầu/);
});

test('new match and replay controls route back through setup instead of creating a game immediately', () => {
  const main = read('src/main.js');
  assert.match(main, /function openMatchSetup\([^)]*\)/);
  assert.match(main, /gameStarted = false;\s*setView\('play'\)/);
  assert.match(main, /\$\('#newGame'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#restartGameBtn'\)\?\.addEventListener\('click', openMatchSetup\)/);
  assert.match(main, /\$\('#gameShowSetup'\)\?\.addEventListener\('click', openMatchSetup\)/);
});

test('Android package must stage the fresh canonical web build, never a stale hashed auth bundle', () => {
  const html = read('index.html');
  const fallback = read('app/src/main/assets/index.html');
  const gradle = read('app/build.gradle.kts');
  const main = read('src/main.js');
  const sw = readAndroid('app/src/main/assets/sw.js');
  assert.match(html, /ViLa Chess .*v3\.69\.1/);
  assert.match(html, /src="\.\/src\/main\.js"/);
  assert.match(main, /function renderMatchSetupView\(\)/);
  assert.match(main, /function openMatchSetup\([^)]*\)/);
  assert.match(fallback, /giao diện web chưa được build/i);
  assert.doesNotMatch(fallback, /index-CYdsNhSO|data-social-oauth|Firebase Cloud Sync|Cấu hình Firebase/i);
  assert.match(gradle, /stageBuiltWebAssetsForAndroid/);
  assert.match(gradle, /webDist\.resolve\("index\.html"\)/);
  assert.match(sw, /chessplus-v3\.69\.1/);
  assert.equal(fs.existsSync(path.join(root, 'app/src/main/assets/assets/index-CYdsNhSO.js')), false);
});
