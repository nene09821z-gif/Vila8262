import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { tournamentBannerMarkup, tournamentPanelMarkup, licensePanelMarkup, adminLicensesMarkup, formatCountdown, formatVnSlot } from '../src/club-ui.js';

const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');

const baseTournament = { id: 'club-2026-11-01', startsAt: Date.UTC(2026, 10, 1, 13), endsAt: Date.UTC(2026, 10, 1, 14, 30), phase: 'upcoming', prize: '<b>Cúp</b>', entrants: 3, joined: false, myRow: null, standings: [], podium: null, pointsRule: 'Thắng 2' };

test('formatting uses Vietnam time regardless of device time zone', () => {
  assert.equal(formatVnSlot(Date.UTC(2026, 10, 1, 13)), 'Chủ nhật 01/11 · 20:00');
  assert.equal(formatCountdown(3 * 86400_000 + 3661_000), '3 ngày 01:01:01');
  assert.equal(formatCountdown(-5), '00:00:00');
});

test('banner: escapes admin-provided prize, adapts to login / joined / finished state', () => {
  const state = { tournament: baseTournament, history: [{ champion: { displayName: 'Hạ <i>Vy</i>' } }], offset: 0 };
  const guest = tournamentBannerMarkup(state, { esc, loggedIn: false });
  assert.match(guest, /data-club-go="friends"/);
  assert.doesNotMatch(guest, /<b>Cúp<\/b>/); assert.doesNotMatch(guest, /<i>Vy<\/i>/);
  assert.match(guest, /data-tournament-countdown="\d+"/);
  assert.match(tournamentBannerMarkup(state, { esc, loggedIn: true }), /data-club-action="join"/);
  const joined = tournamentBannerMarkup({ ...state, tournament: { ...baseTournament, joined: true, myRow: { rank: 2, points: 4, games: 3 } } }, { esc, loggedIn: true });
  assert.match(joined, /Đã đăng ký/); assert.match(joined, /hạng #2/); assert.doesNotMatch(joined, /data-club-action="join"/);
  const finished = tournamentBannerMarkup({ ...state, tournament: { ...baseTournament, phase: 'finished' } }, { esc, loggedIn: true });
  assert.doesNotMatch(finished, /data-tournament-countdown/);
  assert.match(tournamentBannerMarkup({ tournament: null, history: [] }, { esc, loggedIn: true }), /Đang tải/);
});

test('panel: register / cancel only before start, admin prize form only for admins', () => {
  const ctx = { esc, loggedIn: true, myId: 'me', isAdmin: false };
  assert.match(tournamentPanelMarkup({ tournament: baseTournament, history: [] }, ctx), /data-club-action="join"/);
  const joinedUpcoming = tournamentPanelMarkup({ tournament: { ...baseTournament, joined: true }, history: [] }, ctx);
  assert.match(joinedUpcoming, /data-club-action="leave"/);
  const joinedLive = tournamentPanelMarkup({ tournament: { ...baseTournament, phase: 'live', joined: true }, history: [] }, ctx);
  assert.doesNotMatch(joinedLive, /data-club-action="leave"/);
  assert.doesNotMatch(joinedUpcoming, /data-club-prize-form/);
  assert.match(tournamentPanelMarkup({ tournament: baseTournament, history: [] }, { ...ctx, isAdmin: true }), /data-club-prize-form/);
  const table = tournamentPanelMarkup({ tournament: { ...baseTournament, standings: [{ rank: 1, points: 6, games: 3, wins: 3, draws: 0, losses: 0, player: { id: 'me', displayName: 'Tôi' } }] }, history: [{ endsAt: baseTournament.endsAt, entrants: 3, champion: { displayName: 'Mai' } }] }, ctx);
  assert.match(table, /is-me/); assert.match(table, /👑 Mai/);
});

test('license panel: form only when a (re)submission is possible; no private data while pending', () => {
  const ctx = { esc };
  assert.match(licensePanelMarkup({ license: { status: 'none' }, loggedIn: true }, ctx), /data-license-form/);
  assert.doesNotMatch(licensePanelMarkup({ license: { status: 'pending', licenseCode: 'X-1' }, loggedIn: true }, ctx), /data-license-form/);
  assert.doesNotMatch(licensePanelMarkup({ license: { status: 'approved', licenseCode: 'X-1', holderName: 'A' }, loggedIn: true }, ctx), /data-license-form/);
  const rejected = licensePanelMarkup({ license: { status: 'rejected', reason: 'Ảnh mờ <x>' }, loggedIn: true }, ctx);
  assert.match(rejected, /data-license-form/); assert.match(rejected, /Ảnh mờ &lt;x&gt;/);
  assert.match(licensePanelMarkup({ loggedIn: false }, ctx), /Đăng nhập/);
});

test('admin queue: approve/reject on pending, revoke on approved, everything escaped', () => {
  const rows = [
    { user: { id: 'u1', displayName: '<img>', username: 'a', elo: 900, games: 2 }, license: { status: 'pending', holderName: 'A', licenseCode: 'C-1', note: '', reason: '' } },
    { user: { id: 'u2', displayName: 'B', username: 'b', elo: 1000, games: 0 }, license: { status: 'approved', holderName: 'B', licenseCode: 'C-2', note: '', reason: '' } }
  ];
  const html = adminLicensesMarkup({ rows, pending: 1, filter: 'pending' }, { esc });
  assert.match(html, /data-license-decide="approve" data-license-user="u1"/);
  assert.match(html, /data-license-decide="reject" data-license-user="u1"/);
  assert.match(html, /data-license-decide="revoke" data-license-user="u2"/);
  assert.doesNotMatch(html, /<img>/);
});

test('main.js wires banner (online arena), club page, leaderboard license panel, admin queue and tidy music', () => {
  assert.match(main, /import \{ createClubController \} from '\.\/club-ui\.js'/);
  assert.match(main, /club\.bannerHost\(\)\}\$\{renderRankedViewCore\(\)/);
  assert.match(main, /club\.panelHost\(\)/);
  assert.match(main, /\$\{club\.licenseHost\(\)\}<section class="panel server-top100-panel">/);
  assert.match(main, /void club\.loadAdminLicenses\(\)/);
  assert.match(main, /\$\('#clubLeaderboardBtn'\)\?\.addEventListener\('click', \(\) => setView\('leaderboard'\)\)/);
  assert.match(main, /<details class="music-more"/);
  for (const selector of ['.club-banner', '.club-table', '.license-badge', '.music-more']) assert.ok(css.includes(selector), `bundle lacks ${selector}`);
});
