import test from 'node:test';
import assert from 'node:assert/strict';
import { appendCatalogOnlyPrefixes, mergeOpeningEntries } from '../src/opening-catalog.js';

const seed = [
  { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] }
];

test('opening catalog merges unique valid SAN lines without mutating the curated seed', () => {
  const base = structuredClone(seed);
  const imported = [
    { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'] },
    { name: 'Khai cuộc Ý', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5'] },
    { name: 'Broken row', eco: 'C00', san: ['NOT-SAN'] },
    { name: 'Queen opening', eco: 'D00', san: ['d4', 'd5', 'c4', 'e6'] },
    { name: 'Catalogue-only prefix', eco: 'C50', san: ['e4', 'e5', 'Nf3', 'Nc6'], catalogOnly: true }
  ];
  const result = mergeOpeningEntries(base, imported, 100);
  assert.equal(result.length, 3);
  assert.equal(result[0].eco, 'C50');
  assert.equal(result[0].san.at(-1), 'Bb5');
  assert.equal(result[0].name, 'Khai cuộc Ý · C50');
  assert.equal(result[1].family, 'Mở d4');
  assert.equal(result[2].catalogOnly, true, 'intermediate paths must preserve the guard flag');
  assert.deepEqual(base, seed);
});

test('opening catalog enforces its cap and ignores malformed inputs', () => {
  assert.deepEqual(mergeOpeningEntries(null, []), []);
  const finalMoves = ['Nc3', 'Nd3', 'Nf3', 'Ng3', 'Nb3', 'Nh3', 'Ne3', 'Na3'];
  const imported = Array.from({ length: 10 }, (_, index) => ({
    name: `Line ${index}`, eco: 'B00', san: ['e4', 'a6', finalMoves[index % finalMoves.length]]
  }));
  const result = mergeOpeningEntries([], imported, 3);
  assert.equal(result.length, 3);
  assert.equal(mergeOpeningEntries([], [{ name: 'No moves', san: [] }]).length, 0);
});


test('catalog-only legal prefixes fill a catalogue target without pretending to be named openings', () => {
  const source = [
    { name: 'Line A', eco: 'C50', family: 'Mở e4', san: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'] },
    { name: 'Line B', eco: 'D10', family: 'Mở d4', san: ['d4', 'd5', 'c4', 'c6', 'Nf3', 'Nf6'] }
  ];
  const info = appendCatalogOnlyPrefixes(source, 6);
  assert.equal(info.namedOpeningCount, 2);
  assert.equal(source.length, 6);
  assert.equal(info.derivedPositionCount, 4);
  const lines = source.map(item => item.san.join(' '));
  assert.equal(new Set(lines).size, source.length, 'prefix rows must be distinct SAN paths');
  assert.ok(source.slice(2).every(item => item.catalogOnly === true));
  assert.ok(source.slice(2).every(item => /không phải tên khai cuộc ECO độc lập/.test(item.note)));
});
