import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { isLicensed, normalizeLicense, submitLicense, decideLicense, validateLicenseSubmission } from '../src/license.js';
import {
  sundayWindow, tournamentPhase, createTournament, joinTournament, leaveTournament, recordMatchResult, standings,
  finalizeTournament, ensureCurrentTournament, recordMatchInTournaments, tournamentView, tournamentHistory,
  ICT_OFFSET_MS, MAX_GAMES_PER_OPPONENT
} from '../src/club-tournament.js';

const ict = (y, m, d, h = 0, min = 0) => Date.UTC(y, m - 1, d, h, min) - ICT_OFFSET_MS;

test('license: unlicensed by default, only an admin-approved file counts, banned accounts never count', () => {
  const user = { id: 'u1' };
  assert.equal(isLicensed(user), false);
  assert.equal(normalizeLicense(undefined).status, 'none');
  assert.equal(submitLicense(user, { holderName: 'A', licenseCode: 'x' }).ok, false);
  const sent = submitLicense(user, { holderName: 'Nguyễn Văn A', licenseCode: 'VCF-2026/001', note: 'Giấy phép do CLB cấp' });
  assert.equal(sent.ok, true);
  assert.equal(user.license.status, 'pending');
  assert.equal(isLicensed(user), false, 'pending is not enough');
  assert.equal(submitLicense(user, { holderName: 'Nguyễn Văn A', licenseCode: 'VCF-2026/001' }).status, 409, 'cannot resubmit while pending');
  assert.equal(decideLicense(user, 'revoke', 'admin').ok, false, 'cannot revoke what was never approved');
  assert.equal(decideLicense(user, 'approve', 'admin').ok, true);
  assert.equal(isLicensed(user), true);
  assert.equal(isLicensed({ ...user, banned: true }), false);
  assert.equal(decideLicense(user, 'approve', 'admin').ok, false, 'approve only works on pending files');
  assert.equal(decideLicense(user, 'revoke', 'admin', 'Hết hạn').ok, true);
  assert.equal(isLicensed(user), false);
  assert.equal(submitLicense(user, { holderName: 'Nguyễn Văn A', licenseCode: 'VCF-2026/002' }).ok, true, 'can re-apply after revocation');
});

test('license: rejects junk input and ignores client-supplied status', () => {
  assert.equal(validateLicenseSubmission({ holderName: 'Ab', licenseCode: '<script>' }).ok, false);
  const user = { id: 'u2' };
  submitLicense(user, { holderName: 'Bình', licenseCode: 'ABC-123', status: 'approved', decidedBy: 'me' });
  assert.equal(user.license.status, 'pending');
  assert.equal(user.license.decidedBy, '');
  assert.equal(decideLicense(user, 'hack', 'admin').ok, false);
});

test('sundayWindow: Sunday 20:00–21:30 Vietnam time, rolls to next week after it ends', () => {
  // Wednesday 2026-10-28 -> Sunday 2026-11-01
  let win = sundayWindow(ict(2026, 10, 28, 9));
  assert.equal(win.id, 'club-2026-11-01');
  assert.equal(win.startsAt, ict(2026, 11, 1, 20));
  assert.equal(win.endsAt, ict(2026, 11, 1, 21, 30));
  // Sunday morning: still today's
  assert.equal(sundayWindow(ict(2026, 11, 1, 8)).id, 'club-2026-11-01');
  // Live
  assert.equal(sundayWindow(ict(2026, 11, 1, 21, 0)).id, 'club-2026-11-01');
  // Just after the end: next Sunday
  assert.equal(sundayWindow(ict(2026, 11, 1, 21, 30)).id, 'club-2026-11-08');
  // 2026-10-26 (today, Monday)
  assert.equal(sundayWindow(ict(2026, 10, 26, 13, 8)).id, 'club-2026-11-01');
  // UTC Saturday 18:00 is already Sunday 01:00 in Vietnam
  assert.equal(sundayWindow(Date.UTC(2026, 10, 7, 18)).id, 'club-2026-11-08');
});

function liveTournament() {
  const win = sundayWindow(ict(2026, 11, 1, 19));
  const t = createTournament(win);
  for (const id of ['a', 'b', 'c', 'd']) assert.equal(joinTournament(t, id, win.startsAt - 1000).ok, true);
  return t;
}
const match = (t, id, w, b, result, offsetMin = 5) => ({ id, ranked: true, status: 'finished', players: { w, b }, result, finishedAt: new Date(t.startsAt + offsetMin * 60_000).toISOString() });

test('tournament: join/leave rules', () => {
  const win = sundayWindow(ict(2026, 11, 1, 12));
  const t = createTournament(win);
  assert.equal(joinTournament(t, 'a', win.startsAt - 5000).ok, true);
  assert.equal(joinTournament(t, 'a', win.startsAt - 4000).status, 409, 'no double registration');
  assert.equal(leaveTournament(t, 'a', win.startsAt - 3000).ok, true);
  assert.equal(leaveTournament(t, 'a', win.startsAt - 3000).status, 404);
  joinTournament(t, 'a', win.startsAt - 2000);
  assert.equal(leaveTournament(t, 'a', win.startsAt + 1).status, 409, 'cannot withdraw once it started');
  assert.equal(joinTournament(t, 'late', win.startsAt + 60_000).ok, true, 'late registration while live is allowed');
  assert.equal(joinTournament(t, 'x', win.endsAt + 1).status, 409, 'finished tournaments are closed');
});

test('tournament scoring: win 2, draw 1, loss 0; only registered players score; only inside the window; once per match', () => {
  const t = liveTournament();
  assert.equal(recordMatchResult(t, match(t, 'm1', 'a', 'b', '1-0')), true);
  assert.equal(recordMatchResult(t, match(t, 'm1', 'a', 'b', '1-0')), false, 'same match is not counted twice');
  recordMatchResult(t, match(t, 'm2', 'c', 'd', '1/2-1/2'));
  recordMatchResult(t, match(t, 'm3', 'a', 'outsider', '0-1'));
  recordMatchResult(t, { ...match(t, 'm4', 'a', 'b', '1-0'), finishedAt: new Date(t.startsAt - 1000).toISOString() });
  recordMatchResult(t, { ...match(t, 'm5', 'a', 'b', '1-0'), finishedAt: new Date(t.endsAt + 1000).toISOString() });
  recordMatchResult(t, { ...match(t, 'm6', 'a', 'b', '1-0'), ranked: false });
  recordMatchResult(t, { ...match(t, 'm7', 'a', 'b', '1-0'), status: 'active' });
  const rows = Object.fromEntries(standings(t).map(row => [row.userId, row]));
  assert.deepEqual([rows.a.points, rows.a.games, rows.a.wins, rows.a.losses], [2, 2, 1, 1]);
  assert.deepEqual([rows.b.points, rows.b.games], [0, 1]);
  assert.deepEqual([rows.c.points, rows.c.draws], [1, 1]);
  assert.equal(rows.d.points, 1);
  assert.equal(standings(t)[0].userId, 'a');
});

test('tournament anti-farming: at most 3 scored games against the same opponent', () => {
  const t = liveTournament();
  for (let i = 0; i < 8; i++) recordMatchResult(t, match(t, `f${i}`, 'a', 'b', '1-0', 1 + i));
  const rows = Object.fromEntries(standings(t).map(row => [row.userId, row]));
  assert.equal(rows.a.games, MAX_GAMES_PER_OPPONENT);
  assert.equal(rows.a.points, 2 * MAX_GAMES_PER_OPPONENT);
});

test('tournament finalises once the window is over and only players with games can place', () => {
  const t = liveTournament();
  recordMatchResult(t, match(t, 'm1', 'a', 'b', '1-0'));
  recordMatchResult(t, match(t, 'm2', 'c', 'a', '1-0'));
  assert.equal(finalizeTournament(t, t.startsAt + 1000), false, 'not before the end');
  assert.equal(finalizeTournament(t, t.endsAt + 1), true);
  assert.equal(finalizeTournament(t, t.endsAt + 2), false, 'idempotent');
  // a and c both have 2 points and 1 win; c got there in fewer games, so c ranks first.
  assert.deepEqual(t.result.podium.map(row => row.userId), ['c', 'a', 'b']);
  assert.ok(!t.result.podium.some(row => row.userId === 'd'), 'd never played');
  assert.equal(recordMatchResult(t, match(t, 'late', 'a', 'b', '1-0')), false, 'a finalised tournament is frozen');
});

test('ensureCurrentTournament creates the week, finalises the past one, keeps its prize and exposes history', () => {
  const db = { tournaments: [] };
  const now1 = ict(2026, 10, 30, 10);
  const t1 = ensureCurrentTournament(db, now1);
  assert.equal(t1.id, 'club-2026-11-01');
  t1.prize = '500.000đ';
  joinTournament(t1, 'a', now1); joinTournament(t1, 'b', now1);
  const live = t1.startsAt + 10 * 60_000;
  assert.equal(tournamentPhase(t1, live), 'live');
  const m = { id: 'x1', ranked: true, status: 'finished', players: { w: 'a', b: 'b' }, result: '1-0', finishedAt: new Date(live).toISOString() };
  assert.equal(recordMatchInTournaments(db, m), true);
  const now2 = t1.endsAt + 3600_000;
  const t2 = ensureCurrentTournament(db, now2);
  assert.equal(t2.id, 'club-2026-11-08');
  assert.equal(t2.prize, '500.000đ', 'prize carries over');
  assert.equal(db.tournaments.find(t => t.id === t1.id).result.championId, 'a');
  const userOf = id => ({ id, displayName: id.toUpperCase(), username: id });
  const history = tournamentHistory(db, { userOf });
  assert.equal(history[0].champion.displayName, 'A');
  const view = tournamentView(t2, { userId: 'a', userOf, nowMs: now2 });
  assert.equal(view.phase, 'upcoming');
  assert.equal(view.joined, false);
  assert.equal(JSON.stringify(view).includes('"vs"'), false, 'no internal bookkeeping leaks to clients');
});

test('both backends and the client are wired to the license + tournament modules', () => {
  const worker = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
  const node = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');
  for (const source of [worker, node]) {
    assert.match(source, /isLicensed\(/);
    assert.match(source, /recordMatchInTournaments\(db, match\)/);
    assert.match(source, /\/tournaments\/current/);
    assert.match(source, /\/admin\/licenses/);
    assert.match(source, /Admin không thể tự duyệt/);
  }
  assert.match(worker, /filter\(item => isLicensed\(item\)\)/, 'worker leaderboard shows licensed players only');
  assert.match(node, /filter\(u => isLicensed\(u\)\)/, 'node leaderboard shows licensed players only');
  assert.match(worker, /tournament:\$\{item\.id\}/, 'worker persists tournaments');
});
