import test from 'node:test';
import assert from 'node:assert/strict';
import { arrowGeometry, reviewArrowMarkup, reviewArrowOverlayMarkup, squareCenter } from '../src/review-arrows.js';

test('squareCenter maps squares to board units with rank 8 on top', () => {
  assert.deepEqual(squareCenter('a8'), { x: 0.5, y: 0.5 });
  assert.deepEqual(squareCenter('h1'), { x: 7.5, y: 7.5 });
  assert.equal(squareCenter('i9'), null);
});

test('straight and diagonal arrows end inside the target square with the head tip near its centre', () => {
  for (const uci of ['e2e4', 'a1h8', 'h1a8', 'd8d1']) {
    const g = arrowGeometry(uci);
    const to = squareCenter(uci.slice(2, 4));
    assert.equal(g.knight, false);
    assert.equal(g.shaft.length, 2);
    const tip = g.head[0];
    assert.ok(Math.hypot(tip.x - to.x, tip.y - to.y) < 0.1, `${uci} tip should sit on the target centre`);
    const from = squareCenter(uci.slice(0, 2));
    assert.ok(Math.hypot(g.shaft[0].x - from.x, g.shaft[0].y - from.y) > 0.05, 'shaft starts just off the origin centre');
  }
});

test('knight moves are drawn as an L with the long leg first', () => {
  const horizontalFirst = arrowGeometry('b1c3'); // 1 file, 2 ranks -> file first (vertical)
  assert.equal(horizontalFirst.knight, true);
  assert.equal(horizontalFirst.shaft.length, 3);
  const bend = horizontalFirst.shaft[1];
  assert.equal(bend.x, squareCenter('b1').x);
  const wide = arrowGeometry('g1e2'); // 2 files, 1 rank -> rank first (horizontal)
  assert.equal(wide.shaft[1].y, squareCenter('g1').y);
});

test('promotion suffixes are accepted and bad input is rejected', () => {
  assert.ok(arrowGeometry('e7e8q'));
  for (const bad of ['', 'e2', 'e2e2', 'z1a1', null, undefined, 'e2e9']) assert.equal(arrowGeometry(bad), null);
  assert.equal(reviewArrowMarkup('nonsense', 'best'), '');
});

test('markup escapes labels and only accepts safe tone class names', () => {
  const html = reviewArrowMarkup('e2e4', 'played', 'a<b>"&', 'blun"der onclick=1');
  assert.ok(!html.includes('<b>'));
  assert.ok(html.includes('&lt;b&gt;&quot;&amp;'));
  assert.ok(!html.includes('review-arrow-tone-'));
  assert.match(reviewArrowMarkup('e2e4', 'played', '', 'blunder'), /review-arrow-tone-blunder/);
});

test('overlay: best arrow always on top, played arrow only for bad verdicts and never equal to best', () => {
  const base = { bestUci: 'g1f3', bestLabel: 'best', playedUci: 'a2a3', playedLabel: 'played' };
  const bad = reviewArrowOverlayMarkup({ ...base, verdictKey: 'blunder' });
  assert.ok(bad.indexOf('review-arrow-played') < bad.indexOf('review-arrow-best'));
  const fine = reviewArrowOverlayMarkup({ ...base, verdictKey: 'good' });
  assert.ok(!fine.includes('review-arrow-played'));
  assert.ok(fine.includes('review-arrow-best'));
  assert.ok(!reviewArrowOverlayMarkup({ ...base, verdictKey: 'mistake', showPlayed: false }).includes('review-arrow-played'));
  assert.ok(!reviewArrowOverlayMarkup({ ...base, playedUci: 'g1f3', verdictKey: 'mistake' }).includes('review-arrow-played'));
  assert.equal(reviewArrowOverlayMarkup({ bestUci: '' }), '');
  assert.match(bad, /viewBox="0 0 8 8"/);
});
