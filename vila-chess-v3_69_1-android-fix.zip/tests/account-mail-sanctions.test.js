import test, { mock } from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

const ADMIN = { ADMIN_USERNAME: 'vila_admin', ADMIN_PASSWORD: 'Safe-Admin-Password-1234' };
const MAIL = { RESEND_API_KEY: 're_test_key', MAIL_FROM: 'Cờ Vua ViLa <no-reply@vila.example>' };
const PHONE = 'Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36';
const LAPTOP = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36';

function createHarness(env = {}) {
  const records = new Map();
  const sql = { exec(statement, ...args) {
    if (/^CREATE TABLE/i.test(statement)) return [];
    if (/^SELECT key, value FROM vila_records/i.test(statement)) return [...records.entries()].map(([key, value]) => ({ key, value }));
    if (/^INSERT INTO vila_records/i.test(statement)) { records.set(String(args[0]), String(args[1])); return []; }
    if (/^DELETE FROM vila_records/i.test(statement)) { records.delete(String(args[0])); return []; }
    throw new Error(`SQL statement not covered by test harness: ${statement}`);
  } };
  const state = { storage: { sql, transactionSync: callback => callback() }, blockConcurrencyWhile: callback => callback() };
  const object = new ChessState(state, env);
  return { object, env, binding: { idFromName: () => 'mail-test', get: () => ({ fetch: request => object.fetch(request) }) } };
}
async function call(h, path, { method = 'GET', token = '', body, ip = '203.0.113.9', ua = PHONE, country = 'VN' } = {}) {
  const headers = { 'CF-Connecting-IP': ip, 'User-Agent': ua, 'CF-IPCountry': country };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await worker.fetch(new Request(`https://vila-test.workers.dev/api/social${path}`, { method, headers, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) }), { ...h.env, CHESS_STATE: h.binding });
  return { status: response.status, data: await response.json() };
}
const flush = async h => { if (h.object.lastMailTask) await h.object.lastMailTask; };
function stubMailApi({ status = 200, throws = false } = {}) {
  const sent = [];
  const original = globalThis.fetch;
  globalThis.fetch = async (url, init) => {
    if (String(url) !== 'https://api.resend.com/emails') throw new Error(`unexpected network call: ${url}`);
    if (throws) throw new Error('network down');
    const payload = JSON.parse(init.body);
    sent.push({ ...payload, authorization: init.headers.Authorization });
    return new Response('{}', { status });
  };
  return { sent, restore: () => { globalThis.fetch = original; } };
}
const register = async (h, username, extra = {}, options = {}) => (await call(h, '/auth/register', { method: 'POST', body: { username, displayName: extra.displayName || username.replace(/_/g, ' '), password: 'Player-Password-123', ...extra }, ...options }));
const loginAdmin = async h => (await call(h, '/auth/login', { method: 'POST', body: { username: ADMIN.ADMIN_USERNAME, password: ADMIN.ADMIN_PASSWORD }, ip: '198.51.100.1' })).data;

test('e-mail notifications: welcome, new-device sign-in, email change, password change', async () => {
  const api = stubMailApi();
  try {
    const h = createHarness({ ...ADMIN, ...MAIL });
    const reg = await register(h, 'mail_alice', { email: 'alice@example.com' });
    assert.equal(reg.status, 201);
    await flush(h);
    assert.equal(api.sent.length, 1);
    assert.deepEqual(api.sent[0].to, ['alice@example.com']);
    assert.equal(api.sent[0].from, MAIL.MAIL_FROM);
    assert.equal(api.sent[0].authorization, 'Bearer re_test_key');
    assert.match(api.sent[0].subject, /liên kết/);
    assert.match(api.sent[0].text, /@mail_alice/);
    assert.match(api.sent[0].text, /bỏ qua email này/, 'a welcome notice must not tell a stranger to change a password');

    // Same phone, same country: not a new device, so no e-mail.
    assert.equal((await call(h, '/auth/login', { method: 'POST', body: { username: 'mail_alice', password: 'Player-Password-123' } })).status, 200);
    await flush(h);
    assert.equal(api.sent.length, 1);

    // A laptop in another country is new: alert with masked IP only.
    const laptop = await call(h, '/auth/login', { method: 'POST', body: { username: 'alice@example.com', password: 'Player-Password-123' }, ua: LAPTOP, country: 'US', ip: '8.8.4.4' });
    assert.equal(laptop.status, 200);
    await flush(h);
    assert.equal(api.sent.length, 2);
    assert.match(api.sent[1].subject, /thiết bị mới/);
    assert.match(api.sent[1].text, /Windows · Chrome/);
    assert.match(api.sent[1].text, /Quốc gia: US/);
    assert.match(api.sent[1].text, /IP: 8\.8\.\*\.\*/);
    assert.doesNotMatch(api.sent[1].text + api.sent[1].html, /8\.8\.4\.4/);
    assert.match(api.sent[1].text, /đổi mật khẩu/);

    // Re-linking another address notifies both: the new one and (as a security notice) the previous one.
    const token = laptop.data.token;
    const change = await call(h, '/account/email', { method: 'PATCH', token, body: { email: 'alice2@example.com', password: 'Player-Password-123' } });
    assert.equal(change.status, 200, JSON.stringify(change.data));
    await flush(h);
    const toNew = api.sent.find(mail => mail.to[0] === 'alice2@example.com');
    const toOld = api.sent.filter(mail => mail.to[0] === 'alice@example.com').at(-1);
    assert.match(toNew.subject, /đã được liên kết/);
    assert.match(toOld.subject, /vừa bị thay đổi/);
    assert.match(toOld.text, /al\*{4}@example\.com/);
    assert.doesNotMatch(toOld.text, /alice2@example\.com/, 'the old address only sees a masked new address');

    const before = api.sent.length;
    const password = await call(h, '/account/password', { method: 'PATCH', token, body: { currentPassword: 'Player-Password-123', newPassword: 'Another-Password-456' }, ua: LAPTOP, country: 'US', ip: '8.8.4.4' });
    assert.equal(password.status, 200);
    await flush(h);
    assert.equal(api.sent.length, before + 1);
    assert.deepEqual(api.sent.at(-1).to, ['alice2@example.com']);
    assert.match(api.sent.at(-1).subject, /mật khẩu/);
  } finally { api.restore(); }
});

test('e-mail notifications are capped per recipient so the sign-up form cannot spam an inbox', async () => {
  const api = stubMailApi();
  try {
    const h = createHarness({ ...ADMIN, ...MAIL });
    await register(h, 'cap_user', { email: 'victim@example.com' });
    for (let index = 0; index < 6; index += 1) {
      const login = await call(h, '/auth/login', { method: 'POST', body: { username: 'cap_user', password: 'Player-Password-123' }, ua: `Mozilla/5.0 (Windows NT 10.0) Chrome/1${index}0.0`, country: ['US', 'DE', 'FR', 'JP', 'BR', 'IN'][index], ip: `192.0.2.${index + 1}` });
      assert.equal(login.status, 200, 'sign-in itself is never blocked by the mail limit');
    }
    await flush(h);
    assert.equal(api.sent.length, 4);
  } finally { api.restore(); }
});

test('without mail configuration, or when the mail provider fails, account actions still succeed', async () => {
  const api = stubMailApi();
  try {
    const plain = createHarness({ ...ADMIN });
    assert.equal((await register(plain, 'plain_user', { email: 'plain@example.com' })).status, 201);
    assert.equal((await call(plain, '/auth/login', { method: 'POST', body: { username: 'plain_user', password: 'Player-Password-123' }, ua: LAPTOP, country: 'US' })).status, 200);
    assert.equal(api.sent.length, 0);
    const health = await worker.fetch(new Request('https://vila-test.workers.dev/api/social/health'), { ...plain.env, CHESS_STATE: plain.binding });
    assert.equal((await health.json()).mail, 'not-configured');
  } finally { api.restore(); }

  const failing = stubMailApi({ status: 500 });
  const quiet = mock.method(console, 'error', () => {});
  try {
    const h = createHarness({ ...ADMIN, ...MAIL });
    assert.equal((await register(h, 'fail_user', { email: 'fail@example.com' })).status, 201);
    await flush(h);
    assert.equal(failing.sent.length, 1);
    assert.ok(quiet.mock.calls.some(item => String(item.arguments[0]).includes('[VILA mail]')), 'delivery failure is logged');
  } finally { failing.restore(); quiet.mock.restore(); }

  const offline = stubMailApi({ throws: true });
  const quiet2 = mock.method(console, 'error', () => {});
  try {
    const h = createHarness({ ...ADMIN, ...MAIL });
    assert.equal((await register(h, 'offline_user', { email: 'offline@example.com' })).status, 201);
    await flush(h);
  } finally { offline.restore(); quiet2.mock.restore(); }
});

test('admin can send a test e-mail; players cannot, and it is rate limited', async () => {
  const api = stubMailApi();
  try {
    const unconfigured = createHarness({ ...ADMIN });
    const adminA = await loginAdmin(unconfigured);
    assert.equal((await call(unconfigured, '/admin/email/test', { method: 'POST', token: adminA.token, body: { to: 'me@example.com' } })).status, 503);

    const h = createHarness({ ...ADMIN, ...MAIL });
    const admin = await loginAdmin(h);
    const player = (await register(h, 'mail_player')).data;
    assert.equal((await call(h, '/admin/email/test', { method: 'POST', token: player.token, body: { to: 'me@example.com' } })).status, 403);
    assert.equal((await call(h, '/admin/email/test', { method: 'POST', token: admin.token, body: { to: 'not-an-email' } })).status, 400);
    const ok = await call(h, '/admin/email/test', { method: 'POST', token: admin.token, body: { to: 'owner@example.com' } });
    assert.equal(ok.status, 200);
    assert.match(ok.data.message, /ow\*+@example\.com/);
    assert.deepEqual(api.sent.at(-1).to, ['owner@example.com']);
    for (let index = 0; index < 4; index += 1) await call(h, '/admin/email/test', { method: 'POST', token: admin.token, body: { to: 'owner@example.com' } });
    assert.equal((await call(h, '/admin/email/test', { method: 'POST', token: admin.token, body: { to: 'owner@example.com' } })).status, 429);
  } finally { api.restore(); }
});

test('admin sanctions: timed ban, mute, force logout, rating reset — with validation and expiry', async () => {
  mock.timers.enable({ apis: ['Date'], now: Date.now() });
  try {
    const h = createHarness({ ...ADMIN });
    let admin = await loginAdmin(h);
    const alice = (await register(h, 'sanction_alice')).data;
    const bob = (await register(h, 'sanction_bob')).data;
    const patch = (id, body, token = admin.token) => call(h, `/admin/users/${id}`, { method: 'PATCH', token, body });

    // Validation and permissions.
    assert.equal((await patch(alice.user.id, { action: 'ban' }, bob.token)).status, 403);
    assert.equal((await patch(alice.user.id, { action: 'ban', hours: 0 })).status, 400);
    assert.equal((await patch(alice.user.id, { action: 'ban', hours: 'abc' })).status, 400);
    assert.equal((await patch(alice.user.id, { action: 'ban', hours: 999999 })).status, 400);
    assert.equal((await patch(alice.user.id, { action: 'explode' })).status, 400);
    assert.equal((await patch(admin.user.id, { action: 'ban' })).status, 403, 'admins cannot be sanctioned');

    // Timed ban: signed out immediately, blocked with a remaining time, released automatically.
    const banned = await patch(alice.user.id, { action: 'ban', hours: 2, reason: 'spam' });
    assert.equal(banned.status, 200);
    assert.ok(banned.data.user.bannedUntil);
    assert.equal((await call(h, '/auth/me', { token: alice.token })).status, 401);
    const blocked = await call(h, '/auth/login', { method: 'POST', body: { username: 'sanction_alice', password: 'Player-Password-123' } });
    assert.equal(blocked.status, 403);
    assert.match(blocked.data.error, /tạm thời, còn khoảng 2 giờ/);
    mock.timers.tick(3 * 3_600_000);
    const back = await call(h, '/auth/login', { method: 'POST', body: { username: 'sanction_alice', password: 'Player-Password-123' } });
    assert.equal(back.status, 200, JSON.stringify(back.data));

    // A ban without hours is permanent.
    await patch(bob.user.id, { action: 'ban' });
    mock.timers.tick(400 * 24 * 3_600_000);
    assert.equal((await call(h, '/auth/login', { method: 'POST', body: { username: 'sanction_bob', password: 'Player-Password-123' } })).status, 403);
    admin = await loginAdmin(h); // tokens last 30 days, so sign in again after the long wait
    assert.equal((await patch(bob.user.id, { action: 'unban' })).status, 200);
    const bob2 = (await call(h, '/auth/login', { method: 'POST', body: { username: 'sanction_bob', password: 'Player-Password-123' } })).data;
    assert.ok(bob2.token);

    // Mute blocks chatting with players and friend requests, but never contacting an admin (appeals).
    const aliceToken = (await call(h, '/auth/login', { method: 'POST', body: { username: 'sanction_alice', password: 'Player-Password-123' } })).data.token;
    assert.equal((await patch(alice.user.id, { action: 'mute', hours: 1, reason: 'flood' })).status, 200);
    const mutedDm = await call(h, `/messages/${bob.user.id}`, { method: 'POST', token: aliceToken, body: { text: 'hi' } });
    assert.equal(mutedDm.status, 403);
    assert.match(mutedDm.data.error, /flood/);
    assert.equal((await call(h, '/friends/request', { method: 'POST', token: aliceToken, body: { username: 'sanction_bob' } })).status, 403);
    assert.equal((await call(h, `/messages/${admin.user.id}`, { method: 'POST', token: aliceToken, body: { text: 'please review' } })).status, 201);
    assert.ok((await call(h, '/auth/me', { token: aliceToken })).data.user.mutedUntil);
    assert.equal((await patch(alice.user.id, { action: 'unmute' })).status, 200);
    assert.equal((await call(h, `/messages/${bob.user.id}`, { method: 'POST', token: aliceToken, body: { text: 'hi again' } })).status, 201);
    await patch(alice.user.id, { action: 'mute', hours: 1 });
    mock.timers.tick(2 * 3_600_000);
    assert.equal((await call(h, `/messages/${bob.user.id}`, { method: 'POST', token: aliceToken, body: { text: 'after expiry' } })).status, 201, 'mute expires by itself');

    // Force logout and rating reset.
    assert.equal((await patch(alice.user.id, { action: 'logout' })).status, 200);
    assert.equal((await call(h, '/auth/me', { token: aliceToken })).status, 401);
    const reset = await patch(alice.user.id, { action: 'reset-rating' });
    assert.equal(reset.status, 200);
    assert.deepEqual(Object.values(reset.data.user.ratingsByCategory).sort(), [500, 500, 500, 500]);
  } finally { mock.timers.reset(); }
});

test('admin account detail shows devices, reports, strikes and a recent activity trail', async () => {
  const h = createHarness({ ...ADMIN });
  const admin = await loginAdmin(h);
  const alice = (await register(h, 'detail_alice', { email: 'detail@example.com' })).data;
  const bob = (await register(h, 'detail_bob')).data;
  await call(h, '/auth/login', { method: 'POST', body: { username: 'detail_alice', password: 'Player-Password-123' }, ua: LAPTOP, country: 'US' });
  assert.equal((await call(h, `/users/${alice.user.id}/report`, { method: 'POST', token: bob.token, body: { reason: 'spam', details: 'x' } })).status, 201);

  assert.equal((await call(h, `/admin/users/${alice.user.id}`, { token: bob.token })).status, 403);
  assert.equal((await call(h, '/admin/users/not-a-user', { token: admin.token })).status, 404);
  const detail = await call(h, `/admin/users/${alice.user.id}`, { token: admin.token });
  assert.equal(detail.status, 200);
  assert.equal(detail.data.user.email, 'detail@example.com');
  assert.deepEqual(detail.data.devices.map(item => item.label), ['Android · Chrome', 'Windows · Chrome']);
  assert.deepEqual(detail.data.reports, { against: 1, pendingAgainst: 1, filed: 0 });
  assert.equal(detail.data.strikes, 0);
  assert.ok(detail.data.recentActivity.some(item => item.action === 'login_success' && /new device/.test(item.detail)));
  assert.equal(JSON.stringify(detail.data).includes('passwordHash'), false);
  assert.equal(JSON.stringify(detail.data).includes('salt'), false);
});

test('abuse limits: message flood auto-mutes, friend-request flood is capped, search is throttled', async () => {
  mock.timers.enable({ apis: ['Date'], now: Date.now() });
  try {
    const h = createHarness({ ...ADMIN });
    const admin = await loginAdmin(h);
    const spammer = (await register(h, 'flood_spammer', {}, { ip: '198.51.100.20' })).data;
    const victim = (await register(h, 'flood_victim', {}, { ip: '198.51.100.21' })).data;
    const send = () => call(h, `/messages/${victim.user.id}`, { method: 'POST', token: spammer.token, body: { text: 'spam' }, ip: '198.51.100.20' });
    for (let index = 0; index < 30; index += 1) assert.equal((await send()).status, 201, `message ${index + 1}`);
    assert.equal((await send()).status, 429);
    mock.timers.tick(61_000);
    for (let index = 0; index < 30; index += 1) assert.equal((await send()).status, 201);
    assert.equal((await send()).status, 429);
    mock.timers.tick(61_000);
    for (let index = 0; index < 30; index += 1) assert.equal((await send()).status, 201);
    assert.equal((await send()).status, 429, 'third violation inside an hour');
    const muted = await send();
    assert.equal(muted.status, 403, 'now auto-muted');
    assert.match(muted.data.error, /Tự động: thao tác quá nhanh/);
    const detail = await call(h, `/admin/users/${spammer.user.id}`, { token: admin.token });
    assert.ok(detail.data.user.mutedUntil);
    assert.ok(detail.data.recentActivity.some(item => item.action === 'auto_mute'));
    mock.timers.tick(31 * 60_000);
    assert.equal((await send()).status, 201, 'auto-mute lasts 30 minutes');

    // Friend requests: 20 per hour per account.
    const sender = (await register(h, 'friend_sender', {}, { ip: '198.51.100.30' })).data;
    const targets = [];
    for (let index = 0; index < 21; index += 1) targets.push(`friend_target_${index}`);
    for (let index = 0; index < targets.length; index += 1) await register(h, targets[index], {}, { ip: `198.51.101.${index + 1}` });
    for (let index = 0; index < 20; index += 1) {
      const result = await call(h, '/friends/request', { method: 'POST', token: sender.token, body: { username: targets[index] }, ip: '198.51.100.30' });
      assert.equal(result.status, 201, `request ${index + 1}: ${JSON.stringify(result.data)}`);
    }
    assert.equal((await call(h, '/friends/request', { method: 'POST', token: sender.token, body: { username: targets[20] }, ip: '198.51.100.30' })).status, 429);

    // Search: 60 per minute per account; admins are exempt.
    const searcher = (await register(h, 'busy_searcher', {}, { ip: '198.51.100.40' })).data;
    let throttled = 0;
    for (let index = 0; index < 65; index += 1) {
      const result = await call(h, '/users/search?q=friend', { token: searcher.token, ip: `198.51.102.${index + 1}` });
      if (result.status === 429) throttled += 1;
    }
    assert.equal(throttled, 5);
    assert.equal((await call(h, '/users/search?q=friend', { token: admin.token, ip: '198.51.102.200' })).status, 200);
  } finally { mock.timers.reset(); }
});

test('names that impersonate staff are refused for players but not for the configured admin', async () => {
  const h = createHarness({ ...ADMIN });
  for (const [username, displayName] of [['admin_helper', 'Helper'], ['normal_name', 'Admin Vila'], ['normal_two', 'Hỗ Trợ Viên'], ['normal_three', 'Quản Trị Viên'], ['staff_bot', 'Bot'], ['normal_four', 'Official ViLa']]) {
    const result = await register(h, username, { displayName });
    assert.equal(result.status, 400, `${username}/${displayName}`);
    assert.match(result.data.error, /dễ bị nhầm/);
  }
  const fine = (await register(h, 'plain_player', { displayName: 'Kỳ Thủ Nhỏ' }));
  assert.equal(fine.status, 201);
  const rename = await call(h, '/profile', { method: 'PATCH', token: fine.data.token, body: { displayName: 'Support Team', bio: '' } });
  assert.equal(rename.status, 400);
  const keep = await call(h, '/profile', { method: 'PATCH', token: fine.data.token, body: { displayName: 'Kỳ Thủ Lớn', bio: 'xin chào' } });
  assert.equal(keep.status, 200);
  const admin = await loginAdmin(h);
  assert.equal(admin.user.role, 'admin');
});

test('admin page exposes the new moderation controls and calls only routes the Worker implements', async () => {
  const { readFileSync } = await import('node:fs');
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  const worker = readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
  for (const marker of ['data-admin-mod=', 'data-admin-detail=', 'adminModerationBlock(u)', "socialApi('/admin/email/test'", 'id="adminMailTestForm"']) assert.ok(main.includes(marker), marker);
  for (const action of ['ban', 'mute', 'unmute', 'logout', 'reset-rating']) {
    assert.ok(main.includes(`button('`) && main.includes(`'${action}'`), `client offers ${action}`);
    assert.ok(worker.includes(`action === '${action}'`), `worker handles ${action}`);
  }
  assert.match(worker, /params\[1\] === 'users' && params\.length === 3\) \{\s*\n\s*const required = this\.needUser\(user\);[\s\S]{0,200}Bạn không có quyền quản trị/);
});
