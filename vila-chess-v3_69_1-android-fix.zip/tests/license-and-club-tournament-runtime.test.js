import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

// Runtime checks against the real Worker + Durable Object code (in-memory SQL harness).
function createHarness(env = {}) {
  const records = new Map();
  const sql = { exec(statement, ...args) {
    if (/^CREATE TABLE/i.test(statement)) return [];
    if (/^SELECT key, value FROM vila_records/i.test(statement)) return [...records.entries()].map(([key, value]) => ({ key, value }));
    if (/^INSERT INTO vila_records/i.test(statement)) { records.set(String(args[0]), String(args[1])); return []; }
    if (/^DELETE FROM vila_records/i.test(statement)) { records.delete(String(args[0])); return []; }
    throw new Error(`SQL statement not covered by test harness: ${statement}`);
  } };
  const state = { storage: { sql, transactionSync: cb => cb() }, blockConcurrencyWhile: cb => cb() };
  const object = new ChessState(state, env);
  return { records, binding: { idFromName: () => 'license-club', get: () => ({ fetch: request => object.fetch(request) }) } };
}
async function call(h, path, { method = 'GET', token = '', body } = {}) {
  const headers = {}; if (token) headers.Authorization = `Bearer ${token}`; if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await worker.fetch(new Request(`https://vila-test.workers.dev/api/social${path}`, { method, headers, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) }), { CHESS_STATE: h.binding });
  return { status: response.status, data: await response.json() };
}
const ADMIN = { ADMIN_USERNAME: 'vila_admin', ADMIN_PASSWORD: 'Safe-Admin-Password-1234' };
const register = async (h, username) => (await call(h, '/auth/register', { method: 'POST', body: { username, displayName: username, password: 'Player-Password-123', initialElo: 1000 } })).data;

test('runtime: leaderboard only lists players an admin has certified; players cannot self-approve', async () => {
  const h = createHarness(ADMIN);
  const alice = await register(h, 'alice_lic'); const bob = await register(h, 'bob_lic');
  const admin = (await call(h, '/auth/login', { method: 'POST', body: { username: 'vila_admin', password: ADMIN.ADMIN_PASSWORD } })).data;
  assert.ok(alice.token && bob.token && admin.token);

  assert.equal((await call(h, '/leaderboard')).data.users.length, 0, 'nobody is licensed yet — nobody is ranked, not even the admin');
  assert.equal((await call(h, '/me/license')).status, 401);
  assert.equal((await call(h, '/me/license', { token: alice.token })).data.license.status, 'none');
  assert.equal((await call(h, '/me/license', { method: 'POST', token: alice.token, body: { holderName: 'A', licenseCode: '!' } })).status, 400);

  const sent = await call(h, '/me/license', { method: 'POST', token: alice.token, body: { holderName: 'Alice Nguyễn', licenseCode: 'VCF-2026/001', status: 'approved' } });
  assert.equal(sent.status, 201, JSON.stringify(sent.data));
  assert.equal(sent.data.license.status, 'pending', 'client cannot choose its own status');
  assert.equal((await call(h, '/me/license', { method: 'POST', token: alice.token, body: { holderName: 'Alice Nguyễn', licenseCode: 'VCF-2026/001' } })).status, 409);
  assert.equal((await call(h, '/leaderboard')).data.users.length, 0, 'pending is not enough');

  assert.equal((await call(h, '/admin/licenses', { token: bob.token })).status, 403);
  assert.equal((await call(h, `/admin/licenses/${alice.user.id}/decision`, { method: 'POST', token: alice.token, body: { decision: 'approve' } })).status, 403, 'a player cannot approve herself');
  const queue = await call(h, '/admin/licenses?status=pending', { token: admin.token });
  assert.equal(queue.data.pending, 1);
  assert.equal(queue.data.licenses[0].user.username, 'alice_lic');

  assert.equal((await call(h, `/admin/licenses/${alice.user.id}/decision`, { method: 'POST', token: admin.token, body: { decision: 'bogus' } })).status, 400);
  const ok = await call(h, `/admin/licenses/${alice.user.id}/decision`, { method: 'POST', token: admin.token, body: { decision: 'approve' } });
  assert.equal(ok.status, 200, JSON.stringify(ok.data));
  const board = await call(h, '/leaderboard');
  assert.deepEqual(board.data.users.map(user => user.username), ['alice_lic']);
  assert.equal(board.data.users[0].rank, 1);
  assert.equal(board.data.users[0].licensed, true);
  assert.equal('licenseCode' in board.data.users[0], false, 'license details never leak into public profiles');
  assert.equal(JSON.stringify(board.data).includes('VCF-2026'), false);

  // Admin cannot approve their own license.
  await call(h, '/me/license', { method: 'POST', token: admin.token, body: { holderName: 'Admin', licenseCode: 'ADM-001' } });
  assert.equal((await call(h, `/admin/licenses/${admin.user.id}/decision`, { method: 'POST', token: admin.token, body: { decision: 'approve' } })).status, 403);

  // Revoking removes her from the board again; decisions are audited.
  assert.equal((await call(h, `/admin/licenses/${alice.user.id}/decision`, { method: 'POST', token: admin.token, body: { decision: 'revoke', reason: 'Hết hạn' } })).status, 200);
  assert.equal((await call(h, '/leaderboard')).data.users.length, 0);
  assert.equal((await call(h, '/me/license', { token: alice.token })).data.license.reason, 'Hết hạn');
  const audit = JSON.stringify((await call(h, '/admin/audit?limit=100', { token: admin.token })).data);
  assert.match(audit, /license_approved/); assert.match(audit, /license_revoked/);
});

test('runtime: Sunday club tournament — public view, registration rules, admin prize, persisted across restarts', async () => {
  const h = createHarness(ADMIN);
  const alice = await register(h, 'alice_cup'); const bob = await register(h, 'bob_cup');
  const admin = (await call(h, '/auth/login', { method: 'POST', body: { username: 'vila_admin', password: ADMIN.ADMIN_PASSWORD } })).data;

  const anon = await call(h, '/tournaments/current');
  assert.equal(anon.status, 200);
  const t = anon.data.tournament;
  assert.match(t.id, /^club-\d{4}-\d{2}-\d{2}$/);
  assert.ok(['upcoming', 'live'].includes(t.phase));
  assert.equal(t.joined, false);
  assert.equal(new Date(t.startsAt + 7 * 3600_000).getUTCDay(), 0, 'tournament is on a Sunday (Vietnam time)');
  assert.equal(new Date(t.startsAt + 7 * 3600_000).getUTCHours(), 20);

  assert.equal((await call(h, '/tournaments/current/join', { method: 'POST' })).status, 401);
  const joined = await call(h, '/tournaments/current/join', { method: 'POST', token: alice.token });
  assert.equal(joined.status, 201, JSON.stringify(joined.data));
  assert.equal(joined.data.tournament.joined, true);
  assert.equal((await call(h, '/tournaments/current/join', { method: 'POST', token: alice.token })).status, 409);
  await call(h, '/tournaments/current/join', { method: 'POST', token: bob.token });

  const asAlice = (await call(h, '/tournaments/current', { token: alice.token })).data.tournament;
  assert.equal(asAlice.entrants, 2); assert.equal(asAlice.joined, true); assert.equal(asAlice.myRow.rank >= 1, true);
  assert.equal((await call(h, '/tournaments/current')).data.tournament.joined, false, 'anonymous viewers are never "joined"');
  assert.equal(JSON.stringify(asAlice).includes('"vs"'), false);

  if (t.phase === 'upcoming') {
    assert.equal((await call(h, '/tournaments/current/leave', { method: 'POST', token: bob.token })).status, 200);
    assert.equal((await call(h, '/tournaments/current/leave', { method: 'POST', token: bob.token })).status, 404);
  }

  assert.equal((await call(h, '/admin/tournaments/current/prize', { method: 'POST', token: alice.token, body: { prize: 'Tự đặt giải' } })).status, 403);
  assert.equal((await call(h, '/admin/tournaments/current/prize', { method: 'POST', token: admin.token, body: { prize: 'x' } })).status, 400);
  assert.equal((await call(h, '/admin/tournaments/current/prize', { method: 'POST', token: admin.token, body: { prize: '1.000.000đ + danh hiệu' } })).status, 200);
  assert.equal((await call(h, '/tournaments/current')).data.tournament.prize, '1.000.000đ + danh hiệu');

  assert.ok([...h.records.keys()].some(key => key.startsWith('tournament:club-')), 'tournament is stored in the durable object');
});
