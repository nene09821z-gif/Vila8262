import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('v3.69.1 version, cache generation and Android fresh-build gate are aligned', () => {
  const pkg = JSON.parse(read('package.json'));
  const lock = JSON.parse(read('package-lock.json'));
  const gradle = read('app/build.gradle.kts');
  const html = read('index.html');
  const androidFallback = read('app/src/main/assets/index.html');
  const sw = read('public/sw.js');
  assert.equal(pkg.version, '3.69.1');
  assert.equal(lock.packages[''].version, pkg.version);
  assert.match(gradle, /versionCode = 17\s+versionName = "3\.69\.1"/);
  assert.match(html, /ViLa Chess .*v3\.69\.1/);
  assert.match(androidFallback, /Cờ Vua/);
  assert.match(androidFallback, /giao diện web chưa được build/i);
  assert.match(gradle, /stageBuiltWebAssetsForAndroid/);
  assert.match(sw, /chessplus-v3\.69\.1/);
  assert.match(html, /favicon\.ico\?v=354/);
  assert.match(sw, /favicon\.ico\?v=354/);
});

test('a tap from a stale board cannot select on a newly restored or restarted position', () => {
  const main = read('src/main.js');
  const start = main.indexOf('const finish = async event => {', main.indexOf('function wireBoardPointerDrag'));
  const end = main.indexOf("board.addEventListener('contextmenu'", start);
  const finish = main.slice(start, end);
  const guard = finish.indexOf('isMoveContextCurrent(state, { epoch: gameEpoch, fen: game.fen() })');
  assert.ok(guard >= 0);
  assert.ok(guard < finish.indexOf('handleSquareClick(state.from)'));
  assert.ok(guard < finish.indexOf('const choices = to ? state.legal.filter'));
});

test('analysis tools stay docked in the mouse/menu panels and drawing remains opt-in', () => {
  const main = read('src/main.js');
  const css = read('src/vila-v4.css');
  assert.match(main, /function toggleAnnotationToolsDock\(location = 'mouse'\)/);
  assert.match(main, /target\.append\(widget\)/);
  assert.match(main, /if \(requested === 'move'\) annotationTool = null/);
  assert.match(css, /html body \.board-annotation-widget\.annotation-tool-docked\s*\{[^}]*position: relative !important/s);
  assert.match(css, /\.annotation-tools-dock\[hidden\]/);
  assert.match(css, /\.virtual-mouse-panel\.has-annotation-tools/);
});

test('mini-games remain offline-capable and the old avatar asset is removed', () => {
  const puzzle = read('src/mini-games.js');
  const main = read('src/main.js');
  const sw = read('public/sw.js');
  for (const token of ['move2048', 'createScrambledSlidingPuzzle', 'moveSlidingPuzzleTile', 'applyRubikMove']) assert.ok(puzzle.includes(token));
  assert.match(main, /chessplus-mark\.svg\?v=2/);
  assert.match(sw, /chessplus-mark\.svg\?v=2/);
  assert.equal(fs.existsSync(new URL('../public/vila-chess-avatar.svg', import.meta.url)), false);
});
