import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  ACCOUNT_SCOPED_KEYS, GUEST_SCOPE, SCOPE_MIGRATION_FLAG, accountScopeOf, createScopedStorage,
  filterOwnedRecords, mergeAccountGames, migrateLegacyAccountData, scopedKey
} from '../src/account-scope.js';

const memory = (seed = {}) => {
  const map = new Map(Object.entries(seed));
  return { getItem: k => (map.has(k) ? map.get(k) : null), setItem: (k, v) => map.set(k, String(v)), removeItem: k => map.delete(k), map };
};

test('scope ids are per user and sanitised', () => {
  assert.equal(accountScopeOf(null), GUEST_SCOPE);
  assert.equal(accountScopeOf({}), GUEST_SCOPE);
  assert.equal(accountScopeOf({ id: 'abc-1' }), 'u-abc-1');
  assert.equal(accountScopeOf({ id: 'a::acct:b/../x' }), 'u-aacctb..x');
  assert.ok(!accountScopeOf({ id: 'x::acct:y' }).includes('::'));
});

test('two accounts on one device never see each other\'s games, Elo or plan', () => {
  const store = memory();
  let scope = 'u-alice';
  const ls = createScopedStorage(store, () => scope);
  ls.setItem('vila.chess.saved-games.v1', '["alice-game"]');
  ls.setItem('vila.chess.entitlement.v1', '{"premium":true}');
  scope = 'u-bob';
  assert.equal(ls.getItem('vila.chess.saved-games.v1'), null);
  assert.equal(ls.getItem('vila.chess.entitlement.v1'), null);
  ls.setItem('vila.chess.saved-games.v1', '["bob-game"]');
  scope = 'u-alice';
  assert.equal(ls.getItem('vila.chess.saved-games.v1'), '["alice-game"]');
  scope = GUEST_SCOPE;
  assert.equal(ls.getItem('vila.chess.saved-games.v1'), null);
  ls.removeItem('vila.chess.saved-games.v1');
  scope = 'u-bob';
  assert.equal(ls.getItem('vila.chess.saved-games.v1'), '["bob-game"]');
});

test('legacy shared keys move to the device owner once and are removed', () => {
  const store = memory({ 'vila.chess.saved-games.v1': JSON.stringify([{ id: 'g1', pgn: '1. e4', signature: 's1' }]), 'chessbot.local.rating.v1': '{"elo":1500}', 'tubor.chess.settings.v1': '{}' });
  const first = migrateLegacyAccountData(store, 'u-alice');
  assert.equal(first.migrated, true);
  assert.equal(store.getItem('vila.chess.saved-games.v1'), null);
  assert.equal(store.getItem('chessbot.local.rating.v1'), null);
  assert.equal(store.getItem('tubor.chess.settings.v1'), '{}', 'device-wide settings are untouched');
  const games = JSON.parse(store.getItem(scopedKey('vila.chess.saved-games.v1', 'u-alice')));
  assert.equal(games[0].owner, 'u-alice');
  assert.equal(store.getItem(scopedKey('chessbot.local.rating.v1', 'u-alice')), '{"elo":1500}');
  assert.equal(store.getItem(scopedKey('chessbot.local.rating.v1', 'u-bob')), null);
  assert.equal(store.getItem(SCOPE_MIGRATION_FLAG), 'u-alice');
  store.setItem('chessbot.local.rating.v1', '{"elo":999}');
  assert.equal(migrateLegacyAccountData(store, 'u-bob').migrated, false, 'runs only once');
  assert.equal(store.getItem(scopedKey('chessbot.local.rating.v1', 'u-bob')), null);
});

test('scoped key list covers the data that used to leak', () => {
  for (const key of ['vila.chess.saved-games.v1', 'chessbot.local.rating.v1', 'vila.chess.entitlement.v1', 'vila.chess.local-game-recovery.v1', 'vila.chess.notifications.v1', 'vila.chess.puzzles.rating.v1']) assert.ok(ACCOUNT_SCOPED_KEYS.includes(key), key);
});

test('merge keeps only this account\'s games, de-duplicated and newest first', () => {
  const g = (id, owner, date) => ({ id, pgn: '1. e4', signature: `sig-${id}`, owner, date });
  const merged = mergeAccountGames([g('a', 'u-me', '2026-01-01'), g('x', 'u-other', '2026-03-01')], [g('a', undefined, '2026-01-01'), g('b', undefined, '2026-02-01'), g('y', 'u-other', '2026-04-01')], 'u-me');
  assert.deepEqual(merged.map(item => item.id), ['b', 'a']);
  assert.ok(merged.every(item => item.owner === 'u-me'));
  assert.deepEqual(filterOwnedRecords([{ id: 1 }, { id: 2, owner: 'u-me' }, { id: 3, owner: 'u-no' }], 'u-me').map(i => i.id), [1, 2]);
});

test('main.js routes every per-person key through the scoped storage and never archives replays', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  for (const key of ['GAME_HISTORY_KEY', 'LOCAL_GAME_RECOVERY_KEY', 'RATING_KEY', 'RATING_HISTORY_KEY', 'ENTITLEMENT_KEY', 'DAILY_PROGRESS_KEY', 'LIFETIME_KEY', 'LESSON_PROGRESS_KEY', 'NOTIFICATIONS_KEY']) {
    assert.ok(!new RegExp(`localStorage\\.(getItem|setItem|removeItem)\\(${key}\\b`).test(main), `${key} must use scopedLS`);
  }
  assert.match(main, /manualGameResult\?\.reason === 'saved-replay' && existing < 0\) return;/);
  assert.match(main, /reloadAccountScopedState\(previousScope, nextScope\)/);
  const social = fs.readFileSync(new URL('../server/social.js', import.meta.url), 'utf8');
  assert.match(social, /g\.ownerId && String\(g\.ownerId\) !== String\(req\.socialUser\.id\)/);
  const worker = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
  assert.match(worker, /game\.ownerId && String\(game\.ownerId\) !== String\(user\.id\)/);
});
