import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { verifyPicked } from '../scripts/build-puzzle-pack.mjs';
import { loadConfig } from '../analysis-server/src/config.js';
import { startAnalysisServer } from '../analysis-server/src/index.js';

const FAKE = path.join(path.dirname(fileURLToPath(import.meta.url)), 'fixtures', 'fake-uci-engine.mjs');
const KEY = 'verify-key-0123456789-abcdefgh';
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

test('verifyPicked keeps only engine-confirmed puzzles and counts connection errors as drops', async () => {
  const picks = [{ id: 'a', fen: START, moves: ['e2e4', 'e7e5'] }, { id: 'b', fen: START, moves: ['e2e4', 'd7d5'] }, { id: 'c', fen: START, moves: ['e2e4', 'e7e5'] }];
  const fetchImpl = async (_url, init) => {
    const body = JSON.parse(init.body);
    if (body.moves[1] === 'd7d5') return { ok: true, status: 200, json: async () => ({ ok: false }) };
    return picks.length && body.moves[1] === 'e7e5' && fetchImpl.calls++ === 1 ? { ok: false, status: 503 } : { ok: true, status: 200, json: async () => ({ ok: true }) };
  };
  fetchImpl.calls = 0;
  const result = await verifyPicked(picks, { url: 'http://x/', key: KEY, fetchImpl, concurrency: 1 });
  assert.equal(result.checked, 3); assert.equal(result.kept.length, 1); assert.equal(result.errors, 1); assert.equal(result.dropped, 2);
  await assert.rejects(verifyPicked(picks, { url: 'http://x', key: 'bad', fetchImpl: async () => ({ ok: false, status: 401 }) }), /Khóa/);
});

test('build script with --verify-url drops puzzles the Stockfish server does not confirm', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pack-verify-'));
  process.env.FAKE_SCRIPT = 'e2e4 e7e5 g1f3';
  const config = loadConfig({ ANALYSIS_API_KEYS: KEY, PORT: '0', ANALYSIS_CACHE_FILE: '', ANALYSIS_WORKERS: '2', ANALYSIS_LOG: '0' });
  const running = await startAnalysisServer(config, { engine: { command: process.execPath, args: [FAKE], kind: 'native' } });
  try {
    const lines = ['PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags'];
    for (let i = 0; i < 40; i += 1) {
      const good = i % 2 === 0; // odd puzzles claim d7d5 is the solution, which the engine rejects
      lines.push(`id${String(i).padStart(4, '0')},${START.replace(/^[^ ]+/, `rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR`)},${good ? 'e2e4 e7e5 g1f3' : 'e2e4 d7d5 g1f3'},${900 + (i % 5) * 100},70,95,4000,fork,u,`);
    }
    const csv = path.join(dir, 'p.csv'); fs.writeFileSync(csv, lines.join('\n'));
    const out = path.join(dir, 'out');
    // identical FENs are de-duplicated by the builder, so keep this test about the verify stage only: one position per band is enough.
    const run = await new Promise(resolve => {
      const child = spawn(process.execPath, ['scripts/build-puzzle-pack.mjs', csv, '--max', '300', '--out', out, '--verify-url', `http://127.0.0.1:${running.address.port}`, '--verify-key', KEY, '--verify-quality', 'fast']);
      let stderr = ''; child.stderr.on('data', d => { stderr += d; }); child.on('close', status => resolve({ status, stderr }));
    });
    assert.equal(run.status === 0 || /Không có câu nào/.test(run.stderr), true, run.stderr);
    if (run.status === 0) {
      const index = JSON.parse(fs.readFileSync(path.join(out, 'index.json'), 'utf8'));
      assert.equal(index.verified.engine, 'VILA Stockfish server');
      for (const band of index.bands) for (const row of JSON.parse(fs.readFileSync(path.join(out, band.file), 'utf8'))) assert.equal(row[2], 'e2e4 e7e5 g1f3');
    }
  } finally { delete process.env.FAKE_SCRIPT; await running.close(); fs.rmSync(dir, { recursive: true, force: true }); }
});
