import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { squareAtPoint, slideFromMove } from '../src/board-interact.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8') + ['puzzle-page.js', 'analysis-page.js'].map(f => fs.readFileSync(new URL('../src/pages/' + f, import.meta.url), 'utf8')).join('\n');
const interact = fs.readFileSync(new URL('../src/board-interact.js', import.meta.url), 'utf8');
const liveCss = fs.readFileSync(new URL('../src/board-live.css', import.meta.url), 'utf8');
const profileCss = fs.readFileSync(new URL('../src/profile.css', import.meta.url), 'utf8');

const rect = { left: 100, top: 50, width: 400, height: 400, right: 500, bottom: 450 };

test('squareAtPoint maps pixels to squares for both orientations and rejects outside points', () => {
  assert.equal(squareAtPoint(105, 55, rect, 'w'), 'a8');
  assert.equal(squareAtPoint(495, 445, rect, 'w'), 'h1');
  assert.equal(squareAtPoint(105, 55, rect, 'b'), 'h1');
  assert.equal(squareAtPoint(495, 445, rect, 'b'), 'a8');
  assert.equal(squareAtPoint(99, 55, rect, 'w'), '');
  assert.equal(squareAtPoint(300, 451, rect, 'w'), '');
});

test('slideFromMove returns the rook leg for castling and null for incomplete moves', () => {
  assert.deepEqual(slideFromMove({ from: 'e2', to: 'e4', flags: 'b' }), { from: 'e2', to: 'e4', extra: null });
  assert.deepEqual(slideFromMove({ from: 'e1', to: 'g1', flags: 'k' }).extra, { from: 'h1', to: 'f1' });
  assert.deepEqual(slideFromMove({ from: 'e8', to: 'c8', flags: 'q' }).extra, { from: 'a8', to: 'd8' });
  assert.equal(slideFromMove(null), null);
});

test('puzzles accept any legal move: wrong moves are shown with a red badge and rolled back', () => {
  assert.match(main, /function handleWrongPuzzleMove\(/);
  assert.match(main, /puzzleState\.wrongShown = true; puzzleState\.moveVerdict = 'bad'/);
  assert.match(main, /try \{ puzzleGame\.undo\(\); \} catch \{\}/);
  assert.match(main, /puzzle-badge/);
  assert.doesNotMatch(main, /<span class="puzzle-tag">/);
  assert.match(liveCss, /\.puzzle-badge\.is-bad|\.puzzle-square \.puzzle-badge\.is-bad/);
});

test('after a puzzle is solved or revealed the board is a free sandbox with undo', () => {
  assert.match(main, /function puzzleBoardIsFree\(\)/);
  assert.match(main, /\['solved', 'revealed', 'idle'\]/);
  assert.match(main, /function playPuzzleFreeMove\(/);
  assert.match(main, /function undoPuzzleFreeMove\(/);
  assert.match(main, /id="puzzleUndo"/);
  assert.doesNotMatch(main, /puzzleState\.status !== 'ready' \? 'disabled'/);
});

test('puzzle and ranked boards patch the board instead of re-rendering the whole page per move', () => {
  const submitRanked = main.slice(main.indexOf('async function submitRankedMove('), main.indexOf('function puzzleBoardIsFree()'));
  assert.match(submitRanked, /refreshRankedLive\(/);
  assert.doesNotMatch(submitRanked.split('try {\n    const data')[0], /renderView\(\)/);
  const poll = main.slice(main.indexOf('async function refreshRankedStatus('), main.indexOf('function syncRankedTimers()'));
  assert.match(poll, /rankedMoveBusy/);
  assert.match(poll, /refreshRankedLive\(next\.match/);
  const answer = main.slice(main.indexOf('async function submitPuzzleAnswer('), main.indexOf('function wireRankedActions()'));
  assert.match(answer, /refreshPuzzleBoard\(/);
});

test('ranked board has drag and drop, slide animation, and promotion keeps the origin square', () => {
  assert.match(main, /attachBoardDrag\(\$\('#rankedBoard'\)/);
  assert.match(main, /async function rankedPlayMove\(from, to, options, viaDrag\)/);
  assert.match(interact, /slideBoardPiece/);
  assert.doesNotMatch(main, /submitRankedMove\(rankedSelected, square, type\)/);
  assert.doesNotMatch(main, /<span class="ranked-move-tag">/);
});

test('profile page is reachable from the avatar corner and shows ratings, record and friends', () => {
  assert.match(main, /setView\(socialState\.user \? 'profile' : 'friends'\)/);
  assert.match(main, /currentView === 'profile'\) root\.innerHTML = renderProfileView\(\)/);
  assert.match(main, /function wireProfileActions\(\)/);
  for (const key of ['bullet', 'blitz', 'rapid', 'daily']) assert.ok(main.includes(`key: '${key}'`), `rating card ${key}`);
  assert.match(main, /profile-wdl/);
  assert.match(profileCss, /\.profile-rating-grid/);
});
