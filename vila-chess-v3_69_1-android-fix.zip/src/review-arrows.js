/**
 * Game-review arrows (pure geometry + markup, no DOM access so it can be unit-tested).
 *
 * Design goals
 *  - readable on both light and dark squares: every arrow sits on a soft dark halo;
 *  - one translucent group per arrow, so overlapping parts never double the opacity;
 *  - knight moves are drawn as an "L" (long leg first) instead of a diagonal through other pieces;
 *  - a small origin dot marks the starting square, so short arrows still show where they begin;
 *  - the played move (when it was a mistake) is drawn thinner and tinted by its verdict,
 *    underneath the engine's better move, which keeps the green arrow the focal point.
 * All coordinates are in board units (0..8, rank 8 at the top, files a..h left to right).
 */

const SQUARE_RE = /^[a-h][1-8]$/;
export const REVIEW_ARROW_KINDS = {
  best: { shaft: 0.17, headLength: 0.42, headWidth: 0.56, startGap: 0.16, tipGap: 0.03, dot: 0.1 },
  played: { shaft: 0.11, headLength: 0.34, headWidth: 0.42, startGap: 0.16, tipGap: 0.05, dot: 0.07 }
};

export function squareCenter(square) {
  if (!SQUARE_RE.test(String(square || ''))) return null;
  return { x: square.charCodeAt(0) - 96 - 0.5, y: 8.5 - Number(square[1]) };
}

const fmt = value => Number(value.toFixed(3));
const pt = point => `${fmt(point.x)},${fmt(point.y)}`;

/** Compute the polyline (shaft), triangular head and origin dot for a UCI move such as "g1f3". */
export function arrowGeometry(uci, kind = 'best') {
  const move = String(uci || '').toLowerCase();
  if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)) return null;
  const from = squareCenter(move.slice(0, 2));
  const to = squareCenter(move.slice(2, 4));
  if (!from || !to || (from.x === to.x && from.y === to.y)) return null;
  const spec = REVIEW_ARROW_KINDS[kind] || REVIEW_ARROW_KINDS.best;

  const adx = Math.abs(to.x - from.x), ady = Math.abs(to.y - from.y);
  const knight = (adx === 1 && ady === 2) || (adx === 2 && ady === 1);
  // Long leg first: a 2-file jump moves along the rank first, a 2-rank jump along the file first.
  const bend = adx === 2 ? { x: to.x, y: from.y } : { x: from.x, y: to.y };
  const way = knight ? [from, bend, to] : [from, to];

  const last = way[way.length - 1], prev = way[way.length - 2];
  const lastLen = Math.hypot(last.x - prev.x, last.y - prev.y) || 1;
  const ux = (last.x - prev.x) / lastLen, uy = (last.y - prev.y) / lastLen;
  const headLength = Math.min(spec.headLength, lastLen * 0.8);
  const tip = { x: last.x - ux * spec.tipGap, y: last.y - uy * spec.tipGap };
  const base = { x: tip.x - ux * headLength, y: tip.y - uy * headLength };
  const nx = -uy, ny = ux;
  const head = [
    tip,
    { x: base.x + nx * spec.headWidth / 2, y: base.y + ny * spec.headWidth / 2 },
    { x: base.x - nx * spec.headWidth / 2, y: base.y - ny * spec.headWidth / 2 }
  ];

  const second = way[1];
  const firstLen = Math.hypot(second.x - from.x, second.y - from.y) || 1;
  const gap = Math.min(spec.startGap, firstLen * 0.3);
  const start = { x: from.x + (second.x - from.x) / firstLen * gap, y: from.y + (second.y - from.y) / firstLen * gap };
  const shaft = [start, ...way.slice(1, -1), base];
  return { move, knight, shaft, head, origin: from, spec };
}

/** SVG markup for one arrow. `tone` is a verdict key (blunder, mistake…) that only tints "played" arrows. */
export function reviewArrowMarkup(uci, kind = 'best', label = '', tone = '') {
  const geo = arrowGeometry(uci, kind);
  if (!geo) return '';
  const { spec } = geo;
  const shaft = geo.shaft.map(pt).join(' ');
  const head = geo.head.map(pt).join(' ');
  const safeTone = /^[a-z-]+$/.test(String(tone)) ? tone : '';
  const title = label ? `<title>${String(label).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]))}</title>` : '';
  const halo = spec.shaft + 0.07;
  return `<g class="review-arrow review-arrow-${kind}${safeTone ? ` review-arrow-tone-${safeTone}` : ''}${geo.knight ? ' is-knight' : ''}" data-move="${geo.move}">${title}`
    + `<polyline class="rva-halo" points="${shaft}" style="stroke-width:${fmt(halo)}"/><polygon class="rva-halo rva-halo-head" points="${head}"/>`
    + `<polyline class="rva-shaft" points="${shaft}" style="stroke-width:${fmt(spec.shaft)}"/><polygon class="rva-head" points="${head}"/>`
    + `<circle class="rva-origin" cx="${fmt(geo.origin.x)}" cy="${fmt(geo.origin.y)}" r="${fmt(spec.dot)}"/></g>`;
}

/** Verdicts for which the played move is worth showing next to the engine's better move. */
const SHOW_PLAYED_FOR = new Set(['inaccuracy', 'mistake', 'missed-win', 'blunder']);

/**
 * Whole overlay: returns '' when there is nothing to draw.
 * @param {{bestUci?: string, bestLabel?: string, playedUci?: string, playedLabel?: string, verdictKey?: string, showPlayed?: boolean}} input
 */
export function reviewArrowOverlayMarkup({ bestUci = '', bestLabel = '', playedUci = '', playedLabel = '', verdictKey = '', showPlayed = true } = {}) {
  const best = bestUci ? reviewArrowMarkup(bestUci, 'best', bestLabel) : '';
  if (!best) return '';
  const played = showPlayed && playedUci && playedUci !== bestUci && SHOW_PLAYED_FOR.has(verdictKey)
    ? reviewArrowMarkup(playedUci, 'played', playedLabel, verdictKey)
    : '';
  return `<svg class="review-replay-arrows" viewBox="0 0 8 8" preserveAspectRatio="none" role="img" aria-label="Mũi tên nước tốt hơn do Stockfish đề xuất">${played}${best}</svg>`;
}
