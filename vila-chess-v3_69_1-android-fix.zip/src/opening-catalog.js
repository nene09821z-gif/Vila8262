/** Normalize and merge the optional bundled ECO catalog without mutating the curated seed. */
function openingFamily(name, san) {
  const label = String(name || '').toLowerCase();
  if (/defen[cs]e|defense|defence|countergambit|counter attack|counterattack/.test(label)) return 'Phòng thủ';
  if (/gambit|attack|sacrifice|trap/.test(label)) return 'Tấn công';
  const first = Array.isArray(san) ? String(san[0] || '') : '';
  if (first.startsWith('e')) return 'Mở e4';
  if (first.startsWith('d')) return 'Mở d4';
  return 'Mở c4';
}

function formatSanLine(san) {
  return san.map((move, index) => `${index % 2 === 0 ? `${Math.floor(index / 2) + 1}. ` : ''}${move}`).join(' ');
}


/**
 * Add unique intermediate SAN paths from already-validated named opening lines until the
 * searchable catalogue reaches `targetCount`. These rows are for replay/search only; consumers
 * that drive move choice or opening recognition must ignore `catalogOnly` entries.
 * The caller must supply legal lines (the build importer validates SAN with chess.js first).
 */
export function appendCatalogOnlyPrefixes(openings, targetCount = 4000) {
  if (!Array.isArray(openings)) return { namedOpeningCount: 0, derivedPositionCount: 0 };
  const namedOpeningCount = openings.length;
  const target = Math.max(0, Math.min(12000, Math.floor(Number(targetCount) || 4000)));
  if (openings.length >= target) return { namedOpeningCount, derivedPositionCount: 0 };

  const originalLines = openings.slice();
  const seenLines = new Set(originalLines.filter(item => Array.isArray(item?.san)).map(item => item.san.join(' ')));
  const names = new Set(originalLines.map(item => String(item?.name || '').trim().toLocaleLowerCase()).filter(Boolean));

  for (const source of originalLines) {
    if (openings.length >= target) break;
    if (!Array.isArray(source?.san) || source.san.length < 5) continue;
    for (let plies = 4; plies < source.san.length && openings.length < target; plies += 1) {
      const san = source.san.slice(0, plies).map(move => String(move || '').trim());
      if (san.some(move => !move)) continue;
      const key = san.join(' ');
      if (seenLines.has(key)) continue;
      seenLines.add(key);

      const tail = san.slice(-4).join(' ');
      const rootName = `Đường dẫn ECO ${String(source.eco || 'ECO')} · ${tail}`;
      let name = rootName;
      let suffix = 2;
      while (names.has(name.toLocaleLowerCase())) name = `${rootName} · ${san.length} nửa nước (${suffix++})`;
      names.add(name.toLocaleLowerCase());

      openings.push({
        name,
        family: ['Mở e4', 'Mở d4', 'Phòng thủ', 'Tấn công', 'Mở c4'].includes(source.family) ? source.family : openingFamily(source.name, san),
        eco: /^[A-E]\d{2}$/.test(String(source.eco || '')) ? String(source.eco) : 'ECO',
        line: formatSanLine(san),
        san,
        note: `Đường đi trung gian hợp lệ lấy từ biến nguồn “${String(source.name || 'khai cuộc') }”; đây là điểm phát lại, không phải tên khai cuộc ECO độc lập.`,
        source: 'Lichess chess-openings · CC0-1.0 · derived legal prefix',
        catalogOnly: true
      });
    }
  }

  return { namedOpeningCount, derivedPositionCount: openings.length - namedOpeningCount };
}

/**
 * Return entries safe to append to OPENINGS. Duplicate move lines are omitted;
 * duplicate labels get a stable ECO/move suffix so catalogue IDs remain unique.
 */
export function mergeOpeningEntries(baseOpenings, importedOpenings, maxTotal = 5000) {
  if (!Array.isArray(baseOpenings) || !Array.isArray(importedOpenings)) return [];
  const baseLines = new Set();
  const names = new Set();
  for (const item of baseOpenings) {
    if (Array.isArray(item?.san)) baseLines.add(item.san.join(' '));
    if (item?.name) names.add(String(item.name).trim().toLocaleLowerCase());
  }

  const additions = [];
  const cap = Math.max(baseOpenings.length, Math.min(12000, Number(maxTotal) || 5000));
  for (const raw of importedOpenings) {
    if (baseOpenings.length + additions.length >= cap) break;
    if (!raw || typeof raw !== 'object' || !Array.isArray(raw.san)) continue;
    const san = raw.san.map(move => String(move || '').trim());
    if (!san.length || san.length > 60 || san.some(move => !/^[KQRBN]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?[+#]?$|^O-O(?:-O)?[+#]?$/.test(move))) continue;
    const lineKey = san.join(' ');
    if (baseLines.has(lineKey)) continue;

    const eco = /^[A-E]\d{2}$/.test(String(raw.eco || '')) ? String(raw.eco) : 'ECO';
    const originalName = String(raw.name || 'Khai cuộc chưa đặt tên').trim().slice(0, 180);
    let name = originalName;
    if (names.has(name.toLocaleLowerCase())) name = `${originalName} · ${eco}`;
    if (names.has(name.toLocaleLowerCase())) name = `${name} · ${san.slice(0, 6).join(' ')}`;
    let suffix = 2;
    const rootName = name;
    while (names.has(name.toLocaleLowerCase())) name = `${rootName} (${suffix++})`;

    const line = String(raw.line || formatSanLine(san)).slice(0, 1200);
    additions.push({
      name,
      family: ['Mở e4', 'Mở d4', 'Phòng thủ', 'Tấn công', 'Mở c4'].includes(raw.family) ? raw.family : openingFamily(name, san),
      eco,
      line,
      san,
      note: String(raw.note || `Biến ${eco} trong cơ sở dữ liệu khai cuộc mở.`).slice(0, 260),
      source: String(raw.source || 'Lichess ECO · CC0'),
      ...(raw.catalogOnly === true ? { catalogOnly: true } : {})
    });
    names.add(name.toLocaleLowerCase());
    baseLines.add(lineKey);
  }
  return additions;
}
