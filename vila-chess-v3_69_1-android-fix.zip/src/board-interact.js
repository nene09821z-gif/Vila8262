/**
 * Shared interaction helpers for the secondary boards (ranked match + puzzles).
 *
 * The practice board (`#board`) already has drag & drop and a FLIP slide animation. These helpers
 * give the ranked and puzzle boards the same feel without re-rendering the whole page:
 *   - attachBoardDrag(): pointer-driven tap-to-select AND drag-and-drop with a floating ghost piece
 *   - slideBoardPiece(): one-shot FLIP slide of a piece that has just moved
 */
import { slideDurationMs, SLIDE_EASING, slideKeyframes } from './board-motion.js';
import { ghostTransform, landPieceFromPoint, returnGhost } from './board-drag-fx.js';

const FILES_W = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

/** Square under a viewport point, honouring board orientation. '' when outside the board. */
export function squareAtPoint(clientX, clientY, rect, orientation = 'w') {
  if (!rect?.width || !rect?.height || clientX < rect.left || clientY < rect.top || clientX >= rect.right || clientY >= rect.bottom) return '';
  const col = Math.max(0, Math.min(7, Math.floor((clientX - rect.left) / rect.width * 8)));
  const row = Math.max(0, Math.min(7, Math.floor((clientY - rect.top) / rect.height * 8)));
  const white = orientation !== 'b';
  const file = white ? FILES_W[col] : FILES_W[7 - col];
  const rank = white ? 8 - row : row + 1;
  return `${file}${rank}`;
}

function cellOf(board, attr, square) {
  return board.querySelector(`[${attr}="${square}"]`);
}

/**
 * Slide the piece now standing on `to` from the cell it came from. Call right after the board HTML
 * was rebuilt. Castling passes `extra` for the rook. No-ops when motion is reduced/unsupported.
 */
export function slideBoardPiece(board, attr, slide) {
  if (!board || !slide || !slide.from || !slide.to) return;
  if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) return;
  for (const part of [slide, slide.extra]) {
    if (!part?.from || !part?.to) continue;
    const fromCell = cellOf(board, attr, part.from);
    const toCell = cellOf(board, attr, part.to);
    const piece = toCell?.querySelector('.piece');
    if (!fromCell || !toCell || !piece || typeof piece.animate !== 'function') continue;
    const a = fromCell.getBoundingClientRect();
    const b = toCell.getBoundingClientRect();
    const dx = a.left - b.left;
    const dy = a.top - b.top;
    if (!dx && !dy) continue;
    toCell.classList.add('sliding');
    piece.classList.add('is-sliding');
    const duration = slideDurationMs(dx, dy, { min: 150, max: 260, base: 140 });
    const animation = piece.animate(slideKeyframes(dx, dy), { duration, easing: SLIDE_EASING, fill: 'none' });
    const done = () => { toCell.classList.remove('sliding'); piece.classList.remove('is-sliding'); };
    animation.addEventListener('finish', done);
    animation.addEventListener('cancel', done);
  }
}

/** Slide descriptor for a chess.js verbose move (adds the rook for castling). */
export function slideFromMove(move) {
  if (!move?.from || !move?.to) return null;
  const slide = { from: move.from, to: move.to, extra: null };
  const flags = String(move.flags || '');
  if (/[kq]/.test(flags)) {
    const rank = move.to[1];
    const kingSide = flags.includes('k');
    slide.extra = { from: `${kingSide ? 'h' : 'a'}${rank}`, to: `${kingSide ? 'f' : 'd'}${rank}` };
  }
  return slide;
}

/**
 * Tap-to-select + drag-and-drop on a delegated board element (survives innerHTML rebuilds).
 *
 * cfg:
 *   attr           data attribute holding the square, e.g. 'data-ranked-square'
 *   orientation()  'w' | 'b'
 *   getPiece(sq)   chess.js piece or null
 *   canDrag(piece, sq)  may this piece be picked up right now?
 *   getLegal(sq)   verbose legal moves from sq
 *   onTap(sq)      tap / click on a square (select, or move to a highlighted target)
 *   onDrop(from, to, moves)  drop on a legal target; `moves` are the matching verbose moves
 *   pieceMarkup(piece)       inner HTML for the ghost
 *   onDragStart(from, moves) / onDragEnd()  optional visual hooks
 */
export function attachBoardDrag(board, cfg) {
  if (!board || board.dataset.dragAttached === 'true') return;
  board.dataset.dragAttached = 'true';
  const { attr } = cfg;
  let drag = null;
  let ghost = null;
  let frame = 0;
  let latest = null;

  const clearGhost = () => {
    if (frame) { cancelAnimationFrame(frame); frame = 0; }
    ghost?.remove();
    ghost = null;
    document.body.classList.remove('board-dragging');
  };
  const clearHover = () => board.querySelectorAll('.drag-over,.drag-source').forEach(node => node.classList.remove('drag-over', 'drag-source'));

  board.addEventListener('pointerdown', event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    const cell = event.target?.closest?.(`[${attr}]`);
    if (!cell || !board.contains(cell)) return;
    const from = cell.getAttribute(attr);
    const piece = cfg.getPiece(from);
    const draggable = Boolean(piece && cfg.canDrag(piece, from));
    drag = {
      pointerId: event.pointerId, from, piece, draggable,
      x: event.clientX, y: event.clientY, moved: false, moves: null,
      boardRect: board.getBoundingClientRect(), hover: ''
    };
    try { board.setPointerCapture(event.pointerId); } catch {}
    if (event.pointerType === 'mouse') event.preventDefault?.();
  }, { passive: false });

  board.addEventListener('pointermove', event => {
    const state = drag;
    if (!state || state.pointerId !== event.pointerId || !state.draggable) return;
    if (!state.moved) {
      if (Math.hypot(event.clientX - state.x, event.clientY - state.y) < (event.pointerType === 'mouse' ? 3 : 5)) return;
      const moves = cfg.getLegal(state.from) || [];
      if (!moves.length) { state.draggable = false; return; }
      state.moved = true;
      state.moves = moves;
      state.boardRect = board.getBoundingClientRect();
      // The hook may repaint the squares (to show legal targets), so mark the source afterwards.
      cfg.onDragStart?.(state.from, moves);
      cellOf(board, attr, state.from)?.classList.add('drag-source');
      ghost = document.createElement('span');
      ghost.className = `drag-ghost piece ${state.piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
      ghost.innerHTML = cfg.pieceMarkup(state.piece);
      const size = state.boardRect.width / 8;
      state.pointerType = event.pointerType || 'touch';
      ghost.style.cssText = `position:fixed;left:0;top:0;z-index:2000;pointer-events:none;--drag-size:${size.toFixed(2)}px;width:${size.toFixed(2)}px;height:${size.toFixed(2)}px;transform:${ghostTransform(event.clientX, event.clientY, state.pointerType)}`;
      document.body.appendChild(ghost);
      document.body.classList.add('board-dragging');
    }
    event.preventDefault?.();
    latest = { x: event.clientX, y: event.clientY };
    // Move the ghost right now (cheap transform write) so it never trails the finger by a frame;
    // only the hover highlight is deferred to the next animation frame.
    if (ghost) ghost.style.transform = ghostTransform(latest.x, latest.y, state.pointerType);
    if (!frame) frame = requestAnimationFrame(() => {
      frame = 0;
      const current = drag;
      if (!current?.moved || !ghost || !latest) return;
      const hover = squareAtPoint(latest.x, latest.y, current.boardRect, cfg.orientation());
      if (hover !== current.hover) {
        if (current.hover) cellOf(board, attr, current.hover)?.classList.remove('drag-over');
        current.hover = hover;
        if (hover && current.moves.some(move => move.to === hover)) cellOf(board, attr, hover)?.classList.add('drag-over');
      }
    });
  }, { passive: false });

  const finish = event => {
    const state = drag;
    if (!state || state.pointerId !== event.pointerId) return;
    drag = null;
    const releasedGhost = ghost;
    ghost = null;
    if (frame) { cancelAnimationFrame(frame); frame = 0; }
    document.body.classList.remove('board-dragging');
    board.querySelectorAll('.drag-over').forEach(node => node.classList.remove('drag-over'));
    const dispose = () => { releasedGhost?.remove(); clearHover(); };
    if (event.type === 'pointercancel') { dispose(); if (state.moved) cfg.onDragEnd?.(); return; }
    if (!state.moved) {
      dispose();
      // A plain tap: resolve against the square under the finger when it was lifted.
      const upCell = squareAtPoint(event.clientX, event.clientY, state.boardRect, cfg.orientation()) || state.from;
      cfg.onTap(upCell === state.from ? state.from : upCell);
      return;
    }
    const target = squareAtPoint(event.clientX, event.clientY, board.getBoundingClientRect(), cfg.orientation());
    const matching = target ? state.moves.filter(move => move.to === target) : [];
    if (matching.length) {
      dispose();
      cfg.onDrop(state.from, target, matching);
      // The piece now stands on `target` (or will after an async repaint): land it from the release point.
      landPieceFromPoint(() => cellOf(board, attr, target), { x: event.clientX, y: event.clientY }, { pointerType: state.pointerType });
    } else {
      // Illegal drop: glide the ghost back to its square, then restore the normal selection state.
      const home = cellOf(board, attr, state.from)?.getBoundingClientRect();
      const restore = () => { clearHover(); cfg.onDragEnd?.(); cfg.onTap(state.from); };
      if (home && releasedGhost) returnGhost(releasedGhost, home, { pointerType: state.pointerType, onDone: restore });
      else { dispose(); restore(); }
    }
  };
  board.addEventListener('pointerup', finish, { passive: false });
  board.addEventListener('pointercancel', finish, { passive: true });

  // Keyboard activation (Enter/Space on a focused square) arrives as a click with detail 0.
  board.addEventListener('click', event => {
    if (event.detail !== 0) return;
    const cell = event.target?.closest?.(`[${attr}]`);
    if (cell && board.contains(cell)) cfg.onTap(cell.getAttribute(attr));
  });
}
