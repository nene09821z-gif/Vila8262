/**
 * Analysis page (v3.70) — chess.com-style analysis board, phone first.
 * Pure helpers + markup. main.js owns the Stockfish worker and the state; everything here is testable in Node.
 */
const escDefault = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
export const ANALYSIS_TABS = Object.freeze([
  { id: 'engine', label: 'Engine' },
  { id: 'opening', label: 'Khai cuộc' },
  { id: 'game', label: 'Ván cờ' }
]);

/** Engine score (side-to-move POV) → White-POV { cp, mate }. */
export function whiteScore(line, fen) {
  const turn = String(fen || '').split(/\s+/)[1] === 'b' ? -1 : 1;
  const raw = Number(line?.raw ?? line?.score ?? 0) || 0;
  if (line?.scoreType === 'mate') return { cp: null, mate: raw === 0 ? -turn : raw * turn };
  return { cp: raw * turn, mate: null };
}

/** Percentage of the bar that belongs to White (logistic curve like chess engines' win-rate model). */
export function evalToWhitePercent(score) {
  if (!score) return 50;
  if (score.mate !== null && score.mate !== undefined) return score.mate > 0 ? 100 : score.mate < 0 ? 0 : 50;
  const cp = Math.max(-2000, Math.min(2000, Number(score.cp) || 0));
  return Math.round(1000 / (1 + Math.exp(-cp / 400))) / 10;
}

export function formatScore(score) {
  if (!score) return '—';
  if (score.mate !== null && score.mate !== undefined) return `${score.mate < 0 ? '-' : '+'}M${Math.abs(score.mate)}`;
  const pawns = (Number(score.cp) || 0) / 100;
  return `${pawns > 0 ? '+' : ''}${pawns.toFixed(1)}`;
}

/** Convert a UCI principal variation to numbered SAN ("12. Nf3 Nc6 13. d4"). Stops at the first illegal move. */
export function pvToNumberedSan(ChessClass, fen, pv, limit = 10) {
  const chess = new ChessClass(fen);
  const parts = [];
  let first = true;
  for (const uci of (pv || []).slice(0, limit)) {
    let move = null;
    const number = Number(chess.fen().split(/\s+/)[5]) || 1;
    const white = chess.turn() === 'w';
    try { move = chess.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) }); } catch { move = null; }
    if (!move) break;
    if (white) parts.push(`${number}.`);
    else if (first) parts.push(`${number}…`);
    parts.push(move.san);
    first = false;
  }
  return parts.join(' ');
}

/** Replay SAN moves from a start FEN; returns { fens, sans, uci }. Drops everything after the first illegal move. */
export function replayLine(ChessClass, startFen, sans) {
  const chess = new ChessClass(startFen);
  const fens = [chess.fen()]; const ok = []; const uci = [];
  for (const san of sans) {
    let move = null;
    try { move = chess.move(san); } catch { move = null; }
    if (!move) break;
    ok.push(move.san); uci.push(`${move.from}${move.to}${move.promotion || ''}`); fens.push(chess.fen());
  }
  return { fens, sans: ok, uci };
}

export function squareCenter(square, orientation = 'w') {
  const file = square.charCodeAt(0) - 97; const rank = Number(square[1]) - 1;
  return orientation === 'w' ? { x: file + 0.5, y: 7 - rank + 0.5 } : { x: 7 - file + 0.5, y: rank + 0.5 };
}

export function arrowMarkup(uci, orientation, className) {
  if (!/^[a-h][1-8][a-h][1-8]/.test(uci || '')) return '';
  const a = squareCenter(uci.slice(0, 2), orientation); const b = squareCenter(uci.slice(2, 4), orientation);
  const dx = b.x - a.x; const dy = b.y - a.y; const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len; const uy = dy / len; const head = 0.42;
  const tx = b.x - ux * head; const ty = b.y - uy * head;
  const nx = -uy * 0.24; const ny = ux * 0.24;
  return `<g class="${className}"><line x1="${a.x}" y1="${a.y}" x2="${tx}" y2="${ty}" /><polygon points="${b.x},${b.y} ${tx + nx},${ty + ny} ${tx - nx},${ty - ny}" /></g>`;
}

export function renderBoard(vm, esc = escDefault) {
  const { chess, orientation, selected, targets, lastMove, pieceHtml, showCoordinates } = vm;
  const ranks = orientation === 'w' ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];
  const files = orientation === 'w' ? ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'] : ['h', 'g', 'f', 'e', 'd', 'c', 'b', 'a'];
  const targetMap = new Map((targets || []).map(move => [move.to, move]));
  const inCheck = chess.isCheck(); const turn = chess.turn();
  let html = '';
  for (let row = 0; row < 8; row += 1) for (let col = 0; col < 8; col += 1) {
    const rank = ranks[row]; const file = files[col]; const sq = `${file}${rank}`;
    const piece = chess.get(sq);
    const classes = ['ap-square', (file.charCodeAt(0) - 97 + rank) % 2 ? 'dark' : 'light',
      selected === sq ? 'selected' : '', targetMap.has(sq) ? (piece ? 'capture-target' : 'legal-target') : '',
      lastMove && (lastMove.from === sq || lastMove.to === sq) ? 'last' : '',
      inCheck && piece?.type === 'k' && piece.color === turn ? 'in-check' : ''].filter(Boolean).join(' ');
    html += `<button type="button" class="${classes}" data-ap-square="${sq}" aria-label="${sq}${piece ? ` ${piece.color === 'w' ? 'Trắng' : 'Đen'} ${piece.type}` : ''}">${piece ? `<span class="piece ${piece.color === 'w' ? 'white-piece' : 'black-piece'}">${pieceHtml(piece)}</span>` : ''}${showCoordinates && col === 0 ? `<span class="coord rank-coord">${rank}</span>` : ''}${showCoordinates && row === 7 ? `<span class="coord file-coord">${file}</span>` : ''}</button>`;
  }
  return html;
}

export function renderArrows(vm) {
  if (!vm.showArrows || !vm.lines?.length) return '';
  const parts = [];
  vm.lines.slice(0, 3).forEach((line, index) => { const move = line.pv?.[0]; if (move) parts.push(arrowMarkup(move, vm.orientation, index === 0 ? 'ap-arrow best' : 'ap-arrow alt')); });
  return parts.reverse().join('');
}

export function renderEvalBar(vm) {
  const white = evalToWhitePercent(vm.score);
  const whiteAtBottom = vm.orientation === 'w';
  const text = vm.scoreLabel || formatScore(vm.score);
  const whiteLeads = white >= 50;
  return `<div class="ap-evalbar ${whiteAtBottom ? '' : 'is-flipped'}" id="apEvalBar" role="img" aria-label="Đánh giá ${text}"><i class="ap-eval-fill" style="height:${white}%"></i><span class="ap-eval-text ${whiteLeads ? 'on-white' : 'on-black'}">${text}</span></div>`;
}

export function renderLines(vm, esc = escDefault) {
  if (!vm.engineOn) return '<div class="ap-line-empty">Engine đang tắt. Bật lại ở thẻ Engine.</div>';
  if (!vm.lines?.length) return `<div class="ap-line-empty">${esc(vm.engineMessage || 'Stockfish đang phân tích…')}</div>`;
  return vm.lines.map((line, index) => {
    const score = whiteScore(line, vm.fen);
    const text = formatScore(score);
    return `<button type="button" class="ap-line" data-ap-line="${index}"><b class="ap-score ${score.mate !== null ? (score.mate < 0 ? 'neg' : 'pos') : (score.cp < 0 ? 'neg' : 'pos')}">${esc(text)}</b><span class="ap-pv">${esc(line.san || '')}</span></button>`;
  }).join('');
}

export function renderMoveChips(vm, esc = escDefault) {
  const { sans, ply, startFen } = vm;
  if (!sans.length) return '<span class="ap-moves-empty">Chưa có nước đi — hãy đi thử trên bàn cờ hoặc tải một ván.</span>';
  const startNumber = Number(String(startFen).split(/\s+/)[5]) || 1;
  const blackFirst = String(startFen).split(/\s+/)[1] === 'b';
  let html = '';
  sans.forEach((san, index) => {
    const whiteMove = blackFirst ? index % 2 === 1 : index % 2 === 0;
    const number = startNumber + Math.floor((index + (blackFirst ? 1 : 0)) / 2);
    if (whiteMove) html += `<span class="ap-num">${number}.</span>`;
    else if (index === 0) html += `<span class="ap-num">${number}…</span>`;
    html += `<button type="button" class="ap-move${index + 1 === ply ? ' is-current' : ''}${vm.deviatedFrom !== null && index >= vm.deviatedFrom ? ' is-var' : ''}" data-ap-ply="${index + 1}">${esc(san)}</button>`;
  });
  return html;
}

function panelEngine(vm, esc) {
  const seg = (items, current, attr) => items.map(item => `<button type="button" class="cp-seg${item === current ? ' is-on' : ''}" ${attr}="${item}" aria-pressed="${item === current}">${item}</button>`).join('');
  const sw = (id, label, on) => `<label class="cp-switch"><input type="checkbox" id="${id}" ${on ? 'checked' : ''}><span>${label}</span></label>`;
  return `<div class="ap-settings">
    ${sw('apToggleEngine', 'Bật engine Stockfish', vm.engineOn)}
    ${sw('apToggleBar', 'Thanh đánh giá', vm.showEvalBar)}
    ${sw('apToggleArrows', 'Mũi tên nước tốt nhất', vm.showArrows)}
    <p class="cp-sheet-label">Số biến hiển thị</p><div class="cp-segs">${seg([1, 2, 3], vm.multiPv, 'data-ap-multipv')}</div>
    <p class="cp-sheet-label">Độ sâu tối đa</p><div class="cp-segs">${seg([12, 16, 20, 24], vm.depth, 'data-ap-depth')}</div>
    <p class="cp-muted">Điểm +/− tính theo Trắng. Đây là đánh giá của Stockfish, không phải điểm CAPS của Chess.com.</p></div>`;
}

function panelOpening(vm, esc) {
  const o = vm.opening;
  return `<div class="ap-opening"><div class="ap-opening-name"><b>${esc(o ? o.name : (vm.sans.length ? 'Chưa nhận diện khai cuộc' : 'Thế khởi đầu'))}</b>${o?.eco ? `<span class="cp-tag">${esc(o.eco)}</span>` : ''}</div>
    ${o?.detail ? `<p class="cp-muted">${esc(o.detail)}</p>` : ''}
    <button type="button" class="cp-ghost" id="apExplorer">Tra nước phổ biến (Lichess)</button>
    <div id="apExplorerResults" class="ap-explorer" aria-live="polite"><span class="cp-muted">Cần mạng. Thống kê từ cơ sở dữ liệu ván cờ công khai.</span></div></div>`;
}

function panelGame(vm, esc) {
  const saved = (vm.savedGames || []).slice(0, 12).map(game => `<button type="button" class="ap-saved" data-ap-saved="${esc(game.id)}"><b>${esc(game.title)}</b><small>${esc(game.sub)}</small></button>`).join('');
  return `<div class="ap-load">
    <div class="ap-load-row"><button type="button" class="cp-ghost" id="apLoadCurrent">Ván đang chơi</button><button type="button" class="cp-ghost" id="apLoadStart">Thế khởi đầu</button><button type="button" class="cp-ghost" id="apCopyFen">Chép FEN</button><button type="button" class="cp-ghost" id="apCopyPgn">Chép PGN</button></div>
    <p class="cp-sheet-label">Dán PGN hoặc FEN</p>
    <textarea id="apPasteBox" class="ap-paste" rows="3" placeholder="1. e4 e5 2. Nf3 … hoặc rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" spellcheck="false"></textarea>
    <button type="button" class="cp-primary" id="apLoadPaste">Tải vào bàn phân tích</button>
    <p class="cp-sheet-label">Ván đã lưu</p>
    <div class="ap-saved-list">${saved || '<span class="cp-muted">Chưa có ván nào được lưu.</span>'}</div></div>`;
}

export function renderAnalysisPage(vm, { esc = escDefault } = {}) {
  const tabs = ANALYSIS_TABS.map(tab => `<button type="button" role="tab" class="ap-tab${vm.tab === tab.id ? ' is-active' : ''}" aria-selected="${vm.tab === tab.id}" data-ap-tab="${tab.id}">${esc(tab.label)}</button>`).join('');
  const panel = vm.tab === 'opening' ? panelOpening(vm, esc) : vm.tab === 'game' ? panelGame(vm, esc) : panelEngine(vm, esc);
  const atStart = vm.ply <= 0; const atEnd = vm.ply >= vm.sans.length;
  return `<section class="cp-page ap-page">
  <header class="ap-head"><div><h1>Phân tích</h1><small id="apOpeningLine">${esc(vm.openingLabel)}</small></div><span class="ap-chip" id="apEngineChip">${esc(vm.engineChip)}</span></header>
  <div class="ap-stage">${vm.showEvalBar ? renderEvalBar(vm) : ''}
    <div class="ap-board-wrap"><div id="apBoard" class="ap-board" role="grid" aria-label="Bàn cờ phân tích">${renderBoard(vm, esc)}</div><svg class="ap-arrows" id="apArrows" viewBox="0 0 8 8" aria-hidden="true">${renderArrows(vm)}</svg></div></div>
  <div class="ap-lines" id="apLines">${renderLines(vm, esc)}</div>
  <div class="ap-moves" id="apMoves" aria-label="Danh sách nước đi">${renderMoveChips(vm, esc)}</div>
  <nav class="ap-tabs" role="tablist" aria-label="Công cụ phân tích">${tabs}</nav>
  <div class="ap-panel" id="apPanel">${panel}</div>
  <div class="ap-bar" role="toolbar" aria-label="Điều hướng nước đi">
    <button type="button" class="ap-nav" id="apFirst" aria-label="Về đầu" ${atStart ? 'disabled' : ''}>⏮</button>
    <button type="button" class="ap-nav" id="apPrev" aria-label="Nước trước" ${atStart ? 'disabled' : ''}>◀</button>
    <button type="button" class="ap-nav" id="apNext" aria-label="Nước sau" ${atEnd ? 'disabled' : ''}>▶</button>
    <button type="button" class="ap-nav" id="apLast" aria-label="Đến cuối" ${atEnd ? 'disabled' : ''}>⏭</button>
    <button type="button" class="ap-nav" id="apFlip" aria-label="Lật bàn cờ">⇅</button>
    <button type="button" class="cp-primary ap-review" id="apReview">Xem lại</button>
  </div>
</section>`;
}
