/**
 * Puzzle page (v3.70) — chess.com-style, phone first.
 * Pure markup: main.js owns the state and passes a view-model. Every id the puzzle logic relies on
 * (#puzzleBoard, #puzzleFeedback, #puzzleHint, …) is kept so the game logic is shared with the old page.
 */
export const PUZZLE_MODES = Object.freeze([
  { id: 'classic', label: 'Xếp hạng', icon: '♞' },
  { id: 'daily', label: 'Hằng ngày', icon: '☀' },
  { id: 'rush', label: 'Rush', icon: '⚡' },
  { id: 'survival', label: 'Sinh tồn', icon: '♥' },
  { id: 'custom', label: 'Tuỳ chỉnh', icon: '⚙' }
]);

export const PUZZLE_DIFFICULTIES = Object.freeze([
  { id: 'easiest', label: 'Rất dễ' },
  { id: 'easier', label: 'Dễ' },
  { id: 'normal', label: 'Vừa' },
  { id: 'harder', label: 'Khó' },
  { id: 'hardest', label: 'Rất khó' }
]);

const escDefault = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

export function formatCount(n) {
  const value = Math.max(0, Math.floor(Number(n) || 0));
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1).replace('.0', '')}tr`;
  if (value >= 10_000) return `${Math.round(value / 1000)}k`;
  return String(value);
}

function modeTabs(vm, esc) {
  return `<nav class="cp-modes" role="tablist" aria-label="Chế độ câu đố">${PUZZLE_MODES.map(mode => {
    const active = mode.id === 'custom' ? vm.customOpen : (!vm.customOpen && vm.playMode === mode.id);
    return `<button type="button" role="tab" class="cp-mode${active ? ' is-active' : ''}" aria-selected="${active}" ${mode.id === 'custom' ? 'data-puzzle-custom' : `data-puzzle-mode="${mode.id}"`}><span aria-hidden="true">${mode.icon}</span>${esc(mode.label)}</button>`;
  }).join('')}</nav>`;
}

function customSheet(vm, esc) {
  if (!vm.customOpen) return '';
  const themes = (vm.themes || []).slice(0, 60).map(item => `<button type="button" class="cp-chip${vm.customTheme === item.theme ? ' is-on' : ''}" data-puzzle-theme="${esc(item.theme)}" aria-pressed="${vm.customTheme === item.theme}">${esc(item.label)}<small>${esc(formatCount(item.count))}</small></button>`).join('');
  const diffs = PUZZLE_DIFFICULTIES.map(d => `<button type="button" class="cp-seg${vm.customDifficulty === d.id ? ' is-on' : ''}" data-puzzle-difficulty="${d.id}" aria-pressed="${vm.customDifficulty === d.id}">${esc(d.label)}</button>`).join('');
  return `<section class="cp-sheet" aria-label="Tuỳ chỉnh câu đố">
    <div class="cp-sheet-head"><b>Tuỳ chỉnh câu đố</b><button type="button" class="cp-x" data-puzzle-custom-close aria-label="Đóng">×</button></div>
    <p class="cp-sheet-label">Độ khó so với điểm của bạn (${esc(vm.rating)})</p>
    <div class="cp-segs" role="group">${diffs}</div>
    <p class="cp-sheet-label">Chủ đề <small>${esc(formatCount(vm.packTotal))} câu trong kho</small></p>
    <div class="cp-chips"><button type="button" class="cp-chip${vm.customTheme ? '' : ' is-on'}" data-puzzle-theme="" aria-pressed="${!vm.customTheme}">Tất cả</button>${themes || '<span class="cp-muted">Đang tải danh sách chủ đề…</span>'}</div>
    <label class="cp-switch"><input type="checkbox" id="puzzleMissedOnly" ${vm.missedOnly ? 'checked' : ''}><span>Chỉ ôn câu đã sai <small>(${esc(vm.reviewQueue)} câu)</small></span></label>
    <p class="cp-sheet-label">Rush</p>
    <div class="cp-segs" role="group"><button type="button" class="cp-seg" data-puzzle-rush="3">Rush 3 phút</button><button type="button" class="cp-seg" data-puzzle-rush="5">Rush 5 phút</button></div>
    <button type="button" class="cp-primary" id="puzzleCustomStart">Bắt đầu</button>
  </section>`;
}

export function renderPuzzlePrompt(vm, esc = escDefault) {
  const loading = vm.status === 'loading';
  const ready = vm.status === 'ready';
  const turnWord = vm.turn === 'b' ? 'Đen' : 'Trắng';
  const body = ready
    ? `<span class="cp-turn ${vm.turn === 'b' ? 'is-black' : 'is-white'}" aria-hidden="true"></span><b>Lượt ${turnWord}</b><span>Tìm nước tốt nhất</span>`
    : loading ? '<b>Đang chuẩn bị câu đố…</b>'
    : vm.status === 'solved' ? '<b class="cp-ok">Chính xác!</b><span>Bạn đã giải xong</span>'
    : vm.status === 'revealed' ? '<b>Đã xem lời giải</b>'
    : vm.status === 'locked' ? '<b>Hết lượt miễn phí</b>'
    : vm.status === 'finished' ? '<b>Kết thúc lượt chơi</b>'
    : '<b>Chọn một chế độ để bắt đầu</b>';
  return `${body}<span class="cp-chip-small" id="puzzleStatusChip">${esc(vm.statusChip)}</span>`;
}

export function renderPuzzlePage(vm, { esc = escDefault } = {}) {
  const loading = vm.status === 'loading';
  const ready = vm.status === 'ready';
  const delta = vm.ratingChange;
  const deltaHtml = Number.isFinite(delta) && delta !== 0 ? `<span class="cp-delta ${delta > 0 ? 'is-up' : 'is-down'}">${delta > 0 ? '+' : ''}${delta}</span>` : '';
  const runBar = ['rush', 'survival', 'daily'].includes(vm.playMode) ? `<div class="cp-run" id="puzzleModeStatus" role="status">${esc(vm.modeStatus)}</div>` : '<div class="cp-run is-hidden" id="puzzleModeStatus" role="status">' + esc(vm.modeStatus) + '</div>';
  const nextLabel = loading ? 'Đang tải…' : vm.status === 'locked' ? 'Xem gói để luyện tiếp' : vm.nextLabel;
  const meta = [vm.theme, vm.level].filter(Boolean).map(text => `<span class="cp-tag">${esc(text)}</span>`).join('');
  return `<section class="cp-page cp-puzzles" data-puzzle-mode-active="${esc(vm.playMode)}">
  <header class="cp-hero">
    <div class="cp-stat cp-rating"><small>Điểm câu đố</small><b id="puzzleRatingValue">${esc(vm.rating)}</b>${deltaHtml}</div>
    <div class="cp-stat"><small>Chuỗi đúng</small><b><span aria-hidden="true">🔥</span> <span id="puzzleStreakValue">${esc(vm.streak)}</span></b></div>
    <div class="cp-stat"><small>Đã giải</small><b id="puzzleSolvedCount">${esc(vm.solved)}</b></div>
  </header>
  ${modeTabs(vm, esc)}
  ${customSheet(vm, esc)}
  ${runBar}
  <div class="cp-prompt" id="puzzlePrompt">${renderPuzzlePrompt(vm, esc)}</div>
  <div class="puzzle-board-wrap cp-board-wrap"><div id="puzzleBoard" class="puzzle-board" role="grid" aria-label="Bàn cờ câu đố">${vm.boardHtml}</div></div>
  <div class="cp-meta">${meta}</div>
  <div id="puzzleFeedback" class="cp-feedback ${esc(vm.feedbackClass)}" aria-live="polite">${esc(vm.message)}</div>
  <div class="cp-dock" role="toolbar" aria-label="Thao tác câu đố">
    <button type="button" class="cp-tool" id="puzzleHint" ${ready ? '' : 'disabled'}><i aria-hidden="true">💡</i><span>Gợi ý</span></button>
    <button type="button" class="cp-tool" id="puzzleShowAnswer" ${ready ? '' : 'disabled'}><i aria-hidden="true">👁</i><span>Lời giải</span></button>
    <button type="button" class="cp-tool" id="puzzleUndo" ${vm.canUndo ? '' : 'disabled'}><i aria-hidden="true">↶</i><span>Hoàn tác</span></button>
    <button type="button" class="cp-tool" id="puzzleAnalyze" ${vm.rootFen ? '' : 'disabled'}><i aria-hidden="true">📊</i><span>Phân tích</span></button>
    <button type="button" class="cp-primary cp-next" id="puzzleNextQuick" ${loading ? 'disabled aria-busy="true"' : ''}>${esc(nextLabel)}</button>
  </div>
  <button type="button" class="cp-hidden-action" id="puzzleNew" tabindex="-1" aria-hidden="true"></button>
  <span class="sr-only" id="puzzleAttempts">${esc(vm.attempts)}</span><span class="sr-only" id="puzzleStreakBanner">${esc(vm.streakLabel)}</span>
  <div id="puzzleAnalysisResult" class="cp-analysis" aria-live="polite">${esc(vm.analysisText)}</div>
  ${vm.quotaHtml}
  <details class="cp-card" ${vm.trainingHtml ? 'open' : ''}><summary>Tiến bộ &amp; chủ đề cần luyện</summary>${vm.trainingHtml || '<p class="cp-muted">Giải vài câu để thấy thống kê chủ đề mạnh/yếu.</p>'}</details>
  <section class="cp-card cp-pack"><div><b>Kho câu đố</b><small><strong>${esc(formatCount(vm.packTotal))}</strong> câu trong ứng dụng · <strong id="puzzlePoolCount">${esc(vm.poolCount)}</strong>/${esc(vm.poolLimit)} đã lưu từ Lichess</small></div>
    <button type="button" id="puzzleDownloadPack" class="cp-ghost" ${vm.packBusy ? 'disabled' : ''}>${vm.packBusy ? 'Đang tải…' : '⇩ Tải thêm 50'}</button>
    <span id="puzzlePackStatus" class="cp-muted" role="status">${esc(vm.packStatus)}</span></section>
  <select id="puzzlePackTheme" class="sr-only" aria-label="Lọc câu đố theo chủ đề"><option value="">Tất cả chủ đề</option>${vm.themeOptionsHtml}</select>
  <button type="button" class="cp-ghost cp-back" id="puzzleBackToPlay">Quay lại bàn chơi ↗</button>
</section>`;
}
