// Giải đấu trường câu lạc bộ mỗi Chủ nhật (giờ Việt Nam, UTC+7).
// - Mỗi tuần có đúng một giải, id = `club-YYYY-MM-DD` (ngày Chủ nhật theo giờ VN).
// - Người chơi đăng ký trước; trong khung giờ thi đấu họ chơi các trận XẾP HẠNG ONLINE bình thường
//   (ghép trận có sẵn). Mỗi trận xếp hạng kết thúc trong khung giờ được cộng điểm giải: thắng 2, hòa 1, thua 0.
// - Chống cày điểm: mỗi cặp đối thủ chỉ tính tối đa MAX_GAMES_PER_OPPONENT trận; mỗi trận chỉ tính một lần.
// - Điểm được cộng ngay khi trận kết thúc (không phụ thuộc số trận còn lưu), kết thúc giải thì chốt top 3.
// Module thuần: không I/O, không phụ thuộc chess.js — dùng chung Worker, máy chủ Node và giao diện.

export const ICT_OFFSET_MS = 7 * 3600_000;
export const WEEK_MS = 7 * 24 * 3600_000;
export const TOURNAMENT_START_HOUR = 20;      // 20:00 giờ VN
export const TOURNAMENT_DURATION_MIN = 90;    // đến 21:30
export const MAX_GAMES_PER_OPPONENT = 3;
export const MAX_ENTRIES = 500;
export const MAX_KEPT_TOURNAMENTS = 60;
export const POINTS = Object.freeze({ win: 2, draw: 1, loss: 0 });
export const DEFAULT_PRIZE = 'Nhà vô địch Chủ nhật: huy hiệu & banner vinh danh trong đấu trường online';

const pad = n => String(n).padStart(2, '0');

/** Window of the tournament that is running now or, if this week's is over, the next Sunday's. */
export function sundayWindow(nowMs = Date.now()) {
  const shifted = new Date(nowMs + ICT_OFFSET_MS);
  const daysToSunday = (7 - shifted.getUTCDay()) % 7;
  let startsAt = Date.UTC(shifted.getUTCFullYear(), shifted.getUTCMonth(), shifted.getUTCDate() + daysToSunday, TOURNAMENT_START_HOUR) - ICT_OFFSET_MS;
  let endsAt = startsAt + TOURNAMENT_DURATION_MIN * 60_000;
  if (nowMs >= endsAt) { startsAt += WEEK_MS; endsAt += WEEK_MS; }
  return { id: tournamentIdFor(startsAt), startsAt, endsAt };
}

export function tournamentIdFor(startsAtMs) {
  const d = new Date(startsAtMs + ICT_OFFSET_MS);
  return `club-${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
}

export function tournamentPhase(t, nowMs = Date.now()) {
  if (!t) return 'none';
  if (nowMs < t.startsAt) return 'upcoming';
  if (nowMs < t.endsAt) return 'live';
  return 'finished';
}

export function createTournament(win, prize = DEFAULT_PRIZE, nowIso = new Date().toISOString()) {
  return { id: win.id, startsAt: win.startsAt, endsAt: win.endsAt, prize: String(prize || DEFAULT_PRIZE).slice(0, 200), entries: [], scores: {}, counted: [], result: null, createdAt: nowIso };
}

/** Tolerant normaliser for records loaded from storage. */
export function normalizeTournament(raw) {
  if (!raw || typeof raw !== 'object' || typeof raw.id !== 'string') return null;
  const startsAt = Number(raw.startsAt), endsAt = Number(raw.endsAt);
  if (!Number.isFinite(startsAt) || !Number.isFinite(endsAt) || endsAt <= startsAt) return null;
  return {
    id: raw.id, startsAt, endsAt, prize: String(raw.prize || DEFAULT_PRIZE).slice(0, 200),
    entries: Array.isArray(raw.entries) ? raw.entries.filter(e => e && typeof e.userId === 'string') : [],
    scores: raw.scores && typeof raw.scores === 'object' && !Array.isArray(raw.scores) ? raw.scores : {},
    counted: Array.isArray(raw.counted) ? raw.counted.filter(id => typeof id === 'string') : [],
    result: raw.result && typeof raw.result === 'object' ? raw.result : null,
    createdAt: typeof raw.createdAt === 'string' ? raw.createdAt : new Date(startsAt).toISOString()
  };
}

export function isEntered(t, userId) { return Boolean(t?.entries?.some(entry => entry.userId === userId)); }

export function joinTournament(t, userId, nowMs = Date.now()) {
  if (!t || tournamentPhase(t, nowMs) === 'finished') return { ok: false, status: 409, error: 'Giải này đã kết thúc.' };
  if (isEntered(t, userId)) return { ok: false, status: 409, error: 'Bạn đã đăng ký giải này rồi.' };
  if (t.entries.length >= MAX_ENTRIES) return { ok: false, status: 409, error: 'Giải đã đủ số người đăng ký.' };
  t.entries.push({ userId, joinedAt: new Date(nowMs).toISOString() });
  return { ok: true };
}

/** Withdrawing is only possible before the first move of the tournament — nobody can dodge a bad score mid-event. */
export function leaveTournament(t, userId, nowMs = Date.now()) {
  if (!t || !isEntered(t, userId)) return { ok: false, status: 404, error: 'Bạn chưa đăng ký giải này.' };
  if (tournamentPhase(t, nowMs) !== 'upcoming') return { ok: false, status: 409, error: 'Giải đã bắt đầu, không thể hủy đăng ký.' };
  t.entries = t.entries.filter(entry => entry.userId !== userId);
  return { ok: true };
}

function emptyScore() { return { points: 0, games: 0, wins: 0, draws: 0, losses: 0, vs: {} }; }

/** Credits one finished ranked match to a live tournament. Returns true when at least one player scored. */
export function recordMatchResult(t, match) {
  if (!t || t.result || !match || match.ranked !== true || match.status !== 'finished') return false;
  const finishedMs = Date.parse(match.finishedAt || '');
  if (!Number.isFinite(finishedMs) || finishedMs < t.startsAt || finishedMs >= t.endsAt) return false;
  const matchId = String(match.id || '');
  if (!matchId || t.counted.includes(matchId)) return false;
  const white = match.players?.w, black = match.players?.b;
  if (!white || !black || white === black) return false;
  const outcome = match.result === '1-0' ? { [white]: 'win', [black]: 'loss' }
    : match.result === '0-1' ? { [white]: 'loss', [black]: 'win' }
    : { [white]: 'draw', [black]: 'draw' };
  let scored = false;
  for (const [me, opp] of [[white, black], [black, white]]) {
    if (!isEntered(t, me)) continue;
    const row = t.scores[me] = { ...emptyScore(), ...(t.scores[me] || {}), vs: { ...(t.scores[me]?.vs || {}) } };
    if ((row.vs[opp] || 0) >= MAX_GAMES_PER_OPPONENT) continue;
    row.vs[opp] = (row.vs[opp] || 0) + 1;
    const kind = outcome[me];
    row.games += 1;
    row.points += POINTS[kind];
    if (kind === 'win') row.wins += 1; else if (kind === 'draw') row.draws += 1; else row.losses += 1;
    scored = true;
  }
  t.counted.push(matchId);
  if (t.counted.length > 2000) t.counted = t.counted.slice(-2000);
  return scored;
}

/** Sorted standings: points, then wins, then fewer games (better efficiency), then who registered first. */
export function standings(t) {
  const joined = new Map((t?.entries || []).map((entry, index) => [entry.userId, index]));
  return (t?.entries || []).map(entry => {
    const row = { ...emptyScore(), ...(t.scores?.[entry.userId] || {}) };
    return { userId: entry.userId, points: row.points, games: row.games, wins: row.wins, draws: row.draws, losses: row.losses, order: joined.get(entry.userId) };
  }).sort((a, b) => b.points - a.points || b.wins - a.wins || a.games - b.games || a.order - b.order)
    .map(({ order, ...row }, index) => ({ rank: index + 1, ...row }));
}

/** Freezes the podium once the window is over. Idempotent. Only players who actually played can place. */
export function finalizeTournament(t, nowMs = Date.now(), nowIso = new Date(nowMs).toISOString()) {
  if (!t || t.result || tournamentPhase(t, nowMs) !== 'finished') return false;
  const podium = standings(t).filter(row => row.games > 0).slice(0, 3).map((row, index) => ({ ...row, rank: index + 1 }));
  t.result = { finalizedAt: nowIso, entrants: t.entries.length, podium, championId: podium[0]?.userId || null };
  return true;
}

/**
 * Keeps the store consistent: finalises finished tournaments, makes sure the current window exists and prunes old ones.
 * Returns the current (live or upcoming) tournament. `db.tournaments` is the array the backends persist.
 */
export function ensureCurrentTournament(db, nowMs = Date.now()) {
  db.tournaments = (Array.isArray(db.tournaments) ? db.tournaments : []).map(normalizeTournament).filter(Boolean);
  for (const t of db.tournaments) finalizeTournament(t, nowMs);
  const win = sundayWindow(nowMs);
  let current = db.tournaments.find(t => t.id === win.id);
  if (!current) {
    const lastPrize = [...db.tournaments].sort((a, b) => b.startsAt - a.startsAt)[0]?.prize;
    current = createTournament(win, lastPrize || DEFAULT_PRIZE, new Date(nowMs).toISOString());
    db.tournaments.push(current);
  }
  db.tournaments.sort((a, b) => a.startsAt - b.startsAt);
  if (db.tournaments.length > MAX_KEPT_TOURNAMENTS) db.tournaments = db.tournaments.slice(-MAX_KEPT_TOURNAMENTS);
  return db.tournaments.find(t => t.id === win.id);
}

/** Called by the backends right after a ranked match finishes. */
export function recordMatchInTournaments(db, match, nowMs = Date.now()) {
  if (!Array.isArray(db.tournaments) || !match) return false;
  let any = false;
  for (const t of db.tournaments) if (recordMatchResult(t, match)) any = true;
  return any;
}

/** Public view for the client. `userOf(id)` returns { id, displayName, username, avatarId } or null. */
export function tournamentView(t, { userId = '', userOf = () => null, nowMs = Date.now(), top = 10 } = {}) {
  if (!t) return null;
  const phase = tournamentPhase(t, nowMs);
  const name = id => { const u = userOf(id); return u ? { id: u.id, displayName: u.displayName || u.username || 'Người chơi', username: u.username || '', avatarId: u.avatarId ?? 0 } : { id, displayName: 'Tài khoản đã xóa', username: '', avatarId: 0 }; };
  const table = standings(t).map(row => ({ ...row, player: name(row.userId) }));
  return {
    id: t.id, startsAt: t.startsAt, endsAt: t.endsAt, phase, prize: t.prize,
    entrants: t.entries.length, joined: Boolean(userId) && isEntered(t, userId),
    myRow: userId ? table.find(row => row.userId === userId) || null : null,
    standings: table.slice(0, top).map(({ userId: _u, ...row }) => row),
    podium: t.result ? t.result.podium.map(row => ({ ...row, player: name(row.userId) })).map(({ userId: _u, ...row }) => row) : null,
    pointsRule: `Thắng ${POINTS.win} · hòa ${POINTS.draw} · thua ${POINTS.loss} (tối đa ${MAX_GAMES_PER_OPPONENT} ván / đối thủ)`
  };
}

/** Last finished tournaments with a champion, newest first. */
export function tournamentHistory(db, { userOf = () => null, limit = 8 } = {}) {
  return (db.tournaments || []).filter(t => t.result).sort((a, b) => b.startsAt - a.startsAt).slice(0, limit).map(t => {
    const view = tournamentView(t, { userOf, nowMs: t.endsAt + 1, top: 3 });
    return { id: t.id, endsAt: t.endsAt, entrants: t.entries.length, prize: t.prize, champion: view.podium?.[0]?.player || null, podium: view.podium || [] };
  });
}
