/**
 * Hand-assembled WebAssembly SIMD kernel for the 3×3 convolutions that dominate Lc0 inference.
 * The module is built at runtime from a few opcodes (no binary file to ship); if the engine has no WASM-SIMD the
 * caller falls back to the plain JS loops in network.js. Output channels must be a multiple of 16.
 *
 * conv(inPtr, cin, wPtr, bPtr, cout, outPtr, relu, tapsPtr)
 *   in : [64 squares][cin] f32     w : [9 taps][cin][cout] f32     out : [64 squares][cout] f32
 *   taps: per square `count, (tap, neighbourSquare) × 9` as i32, written once by `writeTapTable`.
 */
const TAP_STRIDE_INTS = 19;
export const TAP_TABLE_BYTES = 64 * TAP_STRIDE_INTS * 4;

export function writeTapTable(i32, byteOffset) {
  let o = byteOffset >> 2;
  for (let s = 0; s < 64; s += 1) {
    const f = s & 7; const r = s >> 3; let count = 0; const base = o;
    o += 1;
    for (let dr = -1; dr <= 1; dr += 1) for (let df = -1; df <= 1; df += 1) {
      const nf = f + df; const nr = r + dr;
      if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) { i32[o] = (dr + 1) * 3 + (df + 1); i32[o + 1] = nr * 8 + nf; o += 2; count += 1; }
    }
    i32[base] = count;
    o = base + TAP_STRIDE_INTS;
  }
}

const u = n => { const out = []; let v = n >>> 0; do { let b = v & 0x7f; v >>>= 7; if (v) b |= 0x80; out.push(b); } while (v); return out; };
const s32 = n => { const out = []; let v = n | 0; for (;;) { const b = v & 0x7f; v >>= 7; if ((v === 0 && !(b & 0x40)) || (v === -1 && (b & 0x40))) { out.push(b); return out; } out.push(b | 0x80); } };
const section = (id, bytes) => [id, ...u(bytes.length), ...bytes];
const vec = items => [...u(items.length), ...items.flat()];

export function buildConvModule() {
  const I32 = 0x7f; const F32 = 0x7d; const V128 = 0x7b;
  // locals: params 0..7, then i32 locals
  const [pIn, pCin, pW, pB, pCout, pOut, pRelu, pTaps] = [0, 1, 2, 3, 4, 5, 6, 7];
  const L = { s: 8, list: 9, cnt: 10, ob: 11, t: 12, tap: 13, n: 14, xp: 15, wp: 16, i: 17, x: 18 /* f32 */, a0: 19, a1: 20, a2: 21, a3: 22, xv: 23, zero: 24 };
  const get = i => [0x20, ...u(i)]; const set = i => [0x21, ...u(i)]; const tee = i => [0x22, ...u(i)];
  const ci = n => [0x41, ...s32(n)];
  const add = [0x6a]; const mul = [0x6c]; const shl = [0x74];
  const ltS = [0x48]; const geS = [0x4e];
  const ld32 = (off = 0) => [0x28, 2, ...u(off)];
  const ldF = (off = 0) => [0x2a, 2, ...u(off)];
  const vld = (off = 0) => [0xfd, ...u(0x00), 2, ...u(off)];
  const vst = (off = 0) => [0xfd, ...u(0x0b), 2, ...u(off)];
  const vsplat = [0xfd, ...u(0x13)]; const vadd = [0xfd, ...u(0xe4)]; const vmul = [0xfd, ...u(0xe6)]; const vmax = [0xfd, ...u(0xe9)];
  const f32ne = [0x5c];
  const loopWhileLt = (counter, limit, body) => [0x02, 0x40, 0x03, 0x40, ...get(counter), ...limit, ...geS, 0x0d, 1, ...body, 0x0c, 0, 0x0b, 0x0b];
  const acc = [L.a0, L.a1, L.a2, L.a3];

  const innerI = [
    ...get(L.xp), ...ldF(), ...set(L.x),
    ...get(L.x), 0x43, 0, 0, 0, 0, ...f32ne, 0x04, 0x40,
    ...get(L.x), ...vsplat, ...set(L.xv),
    ...acc.flatMap((a, k) => [...get(a), ...get(L.xv), ...get(L.wp), ...vld(16 * k), ...vmul, ...vadd, ...set(a)]),
    0x0b,
    ...get(L.xp), ...ci(4), ...add, ...set(L.xp),
    ...get(L.wp), ...get(pCout), ...ci(2), ...shl, ...add, ...set(L.wp),
    ...get(L.i), ...ci(1), ...add, ...set(L.i)
  ];
  const innerTap = [
    ...get(L.list), ...get(L.t), ...ci(3), ...shl, ...add, ...ld32(4), ...set(L.tap),
    ...get(L.list), ...get(L.t), ...ci(3), ...shl, ...add, ...ld32(8), ...set(L.n),
    ...get(pIn), ...get(L.n), ...get(pCin), ...mul, ...ci(2), ...shl, ...add, ...set(L.xp),
    ...get(pW), ...get(L.tap), ...get(pCin), ...mul, ...get(pCout), ...mul, ...get(L.ob), ...add, ...ci(2), ...shl, ...add, ...set(L.wp),
    ...ci(0), ...set(L.i),
    ...loopWhileLt(L.i, get(pCin), innerI),
    ...get(L.t), ...ci(1), ...add, ...set(L.t)
  ];
  const perBlock = [
    ...acc.flatMap((a, k) => [...get(pB), ...get(L.ob), ...ci(2), ...shl, ...add, ...vld(16 * k), ...set(a)]),
    ...ci(0), ...set(L.t),
    ...loopWhileLt(L.t, get(L.cnt), innerTap),
    // optional ReLU
    ...get(pRelu), 0x04, 0x40, ...acc.flatMap(a => [...get(a), ...get(L.zero), ...vmax, ...set(a)]), 0x0b,
    ...acc.flatMap((a, k) => [...get(pOut), ...get(L.s), ...get(pCout), ...mul, ...get(L.ob), ...add, ...ci(2), ...shl, ...add, ...get(a), ...vst(16 * k)]),
    ...get(L.ob), ...ci(16), ...add, ...set(L.ob)
  ];
  const perSquare = [
    ...get(pTaps), ...get(L.s), ...ci(TAP_STRIDE_INTS * 4), ...mul, ...add, ...set(L.list),
    ...get(L.list), ...ld32(), ...set(L.cnt),
    ...ci(0), ...set(L.ob),
    ...loopWhileLt(L.ob, get(pCout), perBlock),
    ...get(L.s), ...ci(1), ...add, ...set(L.s)
  ];
  const body = [
    // locals: 11 i32 (s..i = 8..17), 1 f32 (18), 5 v128 (19..23 = a0..a3, xv) + zero (24)
    ...vec([[...u(10), I32], [...u(1), F32], [...u(6), V128]]),
    // zero = splat(0.0)
    0x43, 0, 0, 0, 0, ...vsplat, ...set(L.zero),
    ...ci(0), ...set(L.s),
    ...loopWhileLt(L.s, ci(64), perSquare),
    0x0b
  ];
  const funcBody = [...u(body.length), ...body];
  const bytes = [
    0x00, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00,
    ...section(1, vec([[0x60, ...vec(Array(8).fill([I32])), 0x00]])),
    ...section(2, vec([[...u(3), ...Array.from('env', c => c.charCodeAt(0)), ...u(3), ...Array.from('mem', c => c.charCodeAt(0)), 0x02, 0x00, ...u(1)]])),
    ...section(3, vec([[0x00]])),
    ...section(7, vec([[...u(4), ...Array.from('conv', c => c.charCodeAt(0)), 0x00, 0x00]])),
    ...section(10, vec([funcBody]))
  ];
  return new Uint8Array(bytes);
}

/** Compile the kernel against `memory`; returns `conv(...)` or null when the engine lacks WASM-SIMD. */
export function createSimdConv(memory) {
  try {
    if (typeof WebAssembly === 'undefined') return null;
    const bytes = buildConvModule();
    if (!WebAssembly.validate(bytes)) return null;
    const instance = new WebAssembly.Instance(new WebAssembly.Module(bytes), { env: { mem: memory } });
    return instance.exports.conv;
  } catch { return null; }
}
