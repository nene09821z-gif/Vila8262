/**
 * Lc0 input encoding (classical 112-plane format) and the AZ-style policy-plane mapping.
 * Everything is expressed from the side-to-move's point of view; for black the board is flipped vertically.
 */
import { N, moveFrom, moveTo, movePromo } from './board.js';

const SQ = 64;
const HISTORY = 8;
const flipSq = (sq, flip) => (flip ? sq ^ 56 : sq);

/**
 * @param {Position[]} history oldest → newest; the last entry is the position to evaluate
 * @param {boolean} fillMissing true when the game began from a custom FEN (history older than the start is padded
 *   with copies of the first position, as lc0 does); a standard game leaves those planes empty
 */
export function encodePlanes(history, fillMissing = false, out = new Float32Array(112 * SQ)) {
  out.fill(0);
  const cur = history[history.length - 1];
  const us = cur.side; const flip = us === 1;
  for (let i = 0; i < HISTORY; i += 1) {
    let idx = history.length - 1 - i;
    if (idx < 0) { if (!fillMissing) break; idx = 0; }
    const pos = history[idx]; const base = i * 13 * SQ;
    for (let sq = 0; sq < SQ; sq += 1) {
      const v = pos.board[sq]; if (!v) continue;
      const mine = ((v >> 3) & 1) === us;
      const plane = (mine ? 0 : 6) + (v & 7) - 1;
      out[base + plane * SQ + flipSq(sq, flip)] = 1;
    }
    let repeated = false;
    const sig = pos.signature();
    for (let j = 0; j < idx; j += 1) if (history[j].signature() === sig) { repeated = true; break; }
    if (repeated) out.fill(1, base + 12 * SQ, base + 13 * SQ);
  }
  const aux = 104 * SQ; const c = cur.castling;
  const weK = us ? 4 : 1; const weQ = us ? 8 : 2; const theyK = us ? 1 : 4; const theyQ = us ? 2 : 8;
  if (c & weQ) out.fill(1, aux, aux + SQ);
  if (c & weK) out.fill(1, aux + SQ, aux + 2 * SQ);
  if (c & theyQ) out.fill(1, aux + 2 * SQ, aux + 3 * SQ);
  if (c & theyK) out.fill(1, aux + 3 * SQ, aux + 4 * SQ);
  if (us) out.fill(1, aux + 4 * SQ, aux + 5 * SQ);
  out.fill(Math.min(cur.halfmove, 99) / 99, aux + 5 * SQ, aux + 6 * SQ);
  out.fill(1, aux + 7 * SQ, aux + 8 * SQ);
  return out;
}

const QUEEN_DIRS = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]; // N NE E SE S SW W NW as (file, rank)
const KNIGHT_DIRS = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];

/**
 * Output cell (`plane * 64 + fromSquare`) holding the policy logit of `move`, or -1 if it cannot be expressed.
 * Planes 0..55 queen-like moves (8 directions × 7 steps), 56..63 knight moves, 64..72 promotions
 * (direction NW/N/NE × rook/bishop/QUEEN); a knight promotion shares the plain pawn-move plane.
 * (Verified against real Maia weights: the queen promotion logit lives in the promotion planes.)
 */
export function policyCell(move, side, board) {
  const flip = side === 1;
  const from = flipSq(moveFrom(move), flip); const to = flipSq(moveTo(move), flip);
  const df = (to & 7) - (from & 7); const dr = (to >> 3) - (from >> 3);
  const promo = movePromo(move);
  if (promo && promo !== N) {
    const dir = df < 0 ? 0 : df === 0 ? 1 : 2;
    const piece = promo === 4 ? 0 : promo === 3 ? 1 : 2; // rook, bishop, queen
    return (64 + dir * 3 + piece) * SQ + from;
  }
  const piece = board[moveFrom(move)] & 7;
  if (piece === N) {
    const k = KNIGHT_DIRS.findIndex(d => d[0] === df && d[1] === dr);
    return k < 0 ? -1 : (56 + k) * SQ + from;
  }
  const steps = Math.max(Math.abs(df), Math.abs(dr));
  const sf = Math.sign(df); const sr = Math.sign(dr);
  const k = QUEEN_DIRS.findIndex(d => d[0] === sf && d[1] === sr);
  if (k < 0 || steps < 1 || steps > 7 || (df !== 0 && dr !== 0 && Math.abs(df) !== Math.abs(dr))) return -1;
  return (k * 7 + steps - 1) * SQ + from;
}
