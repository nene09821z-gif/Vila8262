/**
 * Main-thread side of the Lc0 engines. One worker per neural net ("neuron"), created on demand; selecting another
 * net retires the previous worker so only one network sits in memory at a time. Any failure resolves to `null`
 * so the caller can fall back to a classical engine and the game never stalls.
 */
export const LC0_NETS = Object.freeze([
  { id: 'lc0-maia-1100', file: 'lc0/maia-1100.pb.gz', label: 'Lc0 · Maia 1100', short: 'Lc0 Maia 1100', hint: 'mạng nơ-ron Lc0 · đánh như người ~1100 Elo', elo: 1100 },
  { id: 'lc0-maia-1500', file: 'lc0/maia-1500.pb.gz', label: 'Lc0 · Maia 1500', short: 'Lc0 Maia 1500', hint: 'mạng nơ-ron Lc0 · đánh như người ~1500 Elo', elo: 1500 },
  { id: 'lc0-maia-1900', file: 'lc0/maia-1900.pb.gz', label: 'Lc0 · Maia 1900', short: 'Lc0 Maia 1900', hint: 'mạng nơ-ron Lc0 · mạnh nhất trong bộ Maia, tìm kiếm MCTS', elo: 1900 },
  { id: 'lc0-custom', file: null, label: 'Lc0 · Mạng của bạn', short: 'Lc0 (mạng nạp riêng)', hint: 'nạp tệp .pb / .pb.gz bất kỳ (T60, T70, Maia…) trong Cài đặt', elo: null }
]);
export const LC0_IDS = Object.freeze(LC0_NETS.map(net => net.id));
export const isLc0Profile = id => LC0_IDS.includes(String(id || ''));
export const lc0NetInfo = id => LC0_NETS.find(net => net.id === id) || null;

const DB_NAME = 'vila-lc0'; const STORE = 'nets'; const CUSTOM_KEY = 'custom';
/** One entry per net: { id, worker, ready, info, error, pending, seq }. At most MAX_LIVE nets stay in memory (LRU). */
const MAX_LIVE = 2;
const entries = new Map();
let lastStats = null; let lastError = ''; let lastId = null;

function openDb() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') { reject(new Error('Thiết bị không hỗ trợ IndexedDB.')); return; }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function idb(mode, fn) {
  const db = await openDb();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode); const store = tx.objectStore(STORE); const req = fn(store);
      tx.oncomplete = () => resolve(req?.result); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
    });
  } finally { db.close(); }
}
/** Save a user-supplied `.pb` / `.pb.gz` net (validated by actually loading it in a worker). */
export async function importCustomLc0Net(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (bytes.length < 1000) throw new Error('Tệp quá nhỏ để là mạng Lc0.');
  await idb('readwrite', store => store.put({ name: file.name, bytes, savedAt: Date.now() }, CUSTOM_KEY));
  retire('lc0-custom');
  return { name: file.name, size: bytes.length };
}
export async function customLc0NetName() { try { return (await idb('readonly', store => store.get(CUSTOM_KEY)))?.name || ''; } catch { return ''; } }
export async function removeCustomLc0Net() { await idb('readwrite', store => store.delete(CUSTOM_KEY)); retire('lc0-custom'); }

function retire(id) {
  const entry = entries.get(id); if (!entry) return;
  entries.delete(id);
  try { entry.worker?.terminate(); } catch { /* already gone */ }
  for (const [, p] of entry.pending) { clearTimeout(p.timer); p.resolve(null); }
  entry.pending.clear();
}
export function disposeLc0() { for (const id of [...entries.keys()]) retire(id); }
export const getLastLc0Stats = () => lastStats;
export function lc0Status() {
  const entry = entries.get(lastId);
  return { id: lastId, loaded: !!entry?.info, info: entry?.info || null, error: entry?.error || lastError };
}

function createWorker(entry) {
  const worker = new Worker(new URL('./lc0-worker.js', import.meta.url), { type: 'module' });
  worker.addEventListener('message', event => {
    const msg = event.data || {}; const p = entry.pending.get(msg.id);
    if (!p) return;
    entry.pending.delete(msg.id); clearTimeout(p.timer);
    if (msg.type === 'error') p.reject(new Error(msg.message)); else p.resolve(msg);
  });
  worker.addEventListener('error', event => { lastError = event?.message || 'Worker Lc0 gặp lỗi.'; retire(entry.id); });
  return worker;
}
function call(entry, message, timeoutMs, transfer = []) {
  return new Promise((resolve, reject) => {
    const id = ++entry.seq;
    const timer = setTimeout(() => { entry.pending.delete(id); reject(new Error('Lc0 không phản hồi đúng hạn.')); }, timeoutMs);
    entry.pending.set(id, { resolve, reject, timer });
    try { entry.worker.postMessage({ ...message, id }, transfer); } catch (error) { clearTimeout(timer); entry.pending.delete(id); reject(error); }
  });
}

/** Make sure the worker for `id` is running with its net loaded. Resolves to the net info, or null on failure. */
export function preloadLc0(id) {
  const net = lc0NetInfo(id);
  if (!net || typeof Worker === 'undefined') return Promise.resolve(null);
  lastId = id; lastError = '';
  const existing = entries.get(id);
  if (existing) { entries.delete(id); entries.set(id, existing); return existing.ready; } // refresh LRU order
  while (entries.size >= MAX_LIVE) retire(entries.keys().next().value);
  const entry = { id, worker: null, ready: null, info: null, error: '', pending: new Map(), seq: 0 };
  entries.set(id, entry);
  try { entry.worker = createWorker(entry); } catch (error) { lastError = String(error?.message || error); entries.delete(id); return Promise.resolve(null); }
  entry.ready = (async () => {
    let message;
    if (net.file) message = { type: 'load', url: new URL(net.file, document.baseURI).href };
    else {
      const saved = await idb('readonly', store => store.get(CUSTOM_KEY));
      if (!saved?.bytes) throw new Error('Chưa nạp mạng Lc0 riêng. Hãy chọn tệp .pb / .pb.gz.');
      message = { type: 'load', bytes: saved.bytes.buffer.slice(saved.bytes.byteOffset, saved.bytes.byteOffset + saved.bytes.byteLength) };
    }
    const reply = await call(entry, message, 60000, message.bytes ? [message.bytes] : []);
    entry.info = reply.info; return reply.info;
  })().catch(error => { lastError = entry.error = String(error?.message || error); retire(id); return null; });
  return entry.ready;
}

/**
 * Ask Lc0 for a move. `options`: { lc0Game: {startFen, moves}, maxTimeMs, lc0Nodes, temperature }.
 * Returns the UCI string, or null if the engine is unavailable (caller falls back).
 */
export async function chooseLc0Move(profile, fen, options = {}) {
  const info = await preloadLc0(profile);
  const entry = entries.get(profile);
  if (!info || !entry) return null;
  const timeMs = Math.max(200, Math.min(6000, Number(options.maxTimeMs) || 2000));
  const nodes = Math.max(1, Math.min(20000, Number(options.lc0Nodes) || 4000));
  try {
    const game = options.lc0Game?.moves ? { startFen: options.lc0Game.startFen, moves: options.lc0Game.moves } : { fen };
    const reply = await call(entry, { type: 'search', game, options: { nodes, timeMs, temperature: options.temperature ?? 0, policyTemp: options.policyTemp ?? 1 } }, timeMs + 5000);
    const r = reply.result;
    if (!r?.uci) return null;
    lastStats = { depth: r.depth, nodes: r.nodes, elapsedMs: r.elapsedMs, nps: r.nps, score: r.score, at: Date.now(), engine: profile };
    return r.uci;
  } catch (error) {
    lastError = entry.error = String(error?.message || error);
    if (/phản hồi/.test(lastError)) retire(profile); else try { entry.worker?.postMessage({ type: 'stop' }); } catch { /* noop */ }
    return null;
  }
}
export function stopLc0() { for (const entry of entries.values()) { try { entry.worker?.postMessage({ type: 'stop' }); } catch { /* noop */ } } }
