/**
 * PUCT Monte-Carlo tree search driven by an Lc0 network (same scheme as lc0: policy priors, WDL/scalar value,
 * relative first-play-urgency). Runs inside a worker; `search` is async only so a `stop` message can interrupt it.
 */
import { Position, START_FEN, moveToUci, movePromo, Q } from './board.js';
import { encodePlanes, policyCell } from './encode.js';

const CP_SCALE = 111.714640912; const CP_ARG = 1.5620688421;
export const qToCp = q => Math.round(CP_SCALE * Math.tan(CP_ARG * Math.max(-0.999, Math.min(0.999, q))));

class Node {
  constructor(parent, move, prior, pos) {
    this.parent = parent; this.move = move; this.prior = prior; this.pos = pos || null;
    this.n = 0; this.w = 0; this.children = null; this.terminal = null; this.virtual = 0;
  }
  get q() { return this.n ? this.w / this.n : 0; }
}

/** Build the position list (oldest → newest) from a start FEN and UCI moves. */
export function replayGame(startFen, ucis = []) {
  let pos = Position.fromFen(startFen || START_FEN);
  const list = [pos];
  for (const uci of ucis) {
    const m = pos.parseUci(uci);
    if (m < 0) throw new Error(`Nước đi không hợp lệ trong lịch sử: ${uci}`);
    pos = pos.play(m); list.push(pos);
  }
  return list;
}

export class Lc0Search {
  constructor(network) { this.net = network; this.stopped = false; this.planes = new Float32Array(112 * 64); }
  stop() { this.stopped = true; }

  historyFor(node, gameHistory) {
    const out = [];
    for (let n = node; n && out.length < 8; n = n.parent) out.push(n.pos);
    for (let k = gameHistory.length - 2; k >= 0 && out.length < 8; k -= 1) out.push(gameHistory[k]);
    return out.reverse();
  }

  /** Expand `node` with the network; returns the value from the side to move's point of view. */
  evaluate(node, gameHistory, fillMissing, policyTemp) {
    const pos = node.pos;
    const moves = pos.legalMoves();
    if (!moves.length) { node.terminal = pos.inCheck() ? -1 : 0; return node.terminal; }
    if (pos.halfmove >= 100 || pos.insufficientMaterial()) { node.terminal = 0; return 0; }
    const sig = pos.signature(); let seen = 0; let inTree = false;
    for (let a = node.parent; a; a = a.parent) if (a.sig === sig) { seen += 1; inTree = true; }
    for (let k = 0; k < gameHistory.length - 1; k += 1) if (gameHistory[k].signature() === sig) seen += 1;
    if (seen >= 2 || (inTree && seen >= 1)) { node.terminal = 0; return 0; }
    const v = this.net.forward(encodePlanes(this.historyFor(node, gameHistory), fillMissing, this.planes));
    const list = [];
    for (const m of moves) {
      if (movePromo(m) && movePromo(m) !== Q) continue; // under-promotions are never searched (the engine always queens)
      const cell = policyCell(m, pos.side, pos.board);
      if (cell >= 0) list.push({ m, logit: this.net.policyLogit(cell) });
    }
    if (!list.length) { node.terminal = 0; return 0; }
    let max = -Infinity; for (const it of list) if (it.logit > max) max = it.logit;
    let sum = 0; for (const it of list) { it.e = Math.exp((it.logit - max) / policyTemp); sum += it.e; }
    node.children = list.map(it => new Node(node, it.m, it.e / sum, null)).sort((a, b) => b.prior - a.prior);
    return v.q;
  }

  /**
   * @param {{startFen?: string, moves?: string[], fen?: string}} game
   * @param {{nodes?:number, timeMs?:number, cpuct?:number, fpu?:number, policyTemp?:number, temperature?:number, onInfo?:Function}} opts
   */
  async search(game, opts = {}) {
    this.stopped = false;
    const startFen = game.startFen || game.fen || START_FEN;
    const gameHistory = game.fen && !game.moves ? [Position.fromFen(game.fen)] : replayGame(startFen, game.moves || []);
    const fillMissing = Position.fromFen(startFen).signature() !== Position.fromFen(START_FEN).signature();
    const rootPos = gameHistory[gameHistory.length - 1];
    const maxNodes = Math.max(1, Math.floor(opts.nodes ?? 800)); const timeMs = Math.max(30, opts.timeMs ?? 2000);
    const cpuct = opts.cpuct ?? 1.745; const fpuRed = opts.fpu ?? 0.44; const policyTemp = Math.max(0.1, opts.policyTemp ?? 1.0);
    const root = new Node(null, 0, 1, rootPos); root.sig = rootPos.signature();
    const legal = rootPos.legalMoves();
    if (!legal.length) return null;
    if (legal.length === 1) return { uci: moveToUci(legal[0]), nodes: 0, score: 0, depth: 0, elapsedMs: 0, nps: 0, pv: [moveToUci(legal[0])] };
    this.evaluate(root, gameHistory, fillMissing, policyTemp);
    root.n = 1;
    let mate = null;
    const start = performance.now(); let maxDepth = 0; let depthSum = 0; let lastYield = start; let nodes = 0;
    while (nodes < maxNodes - 1 && !this.stopped) {
      let node = root; let depth = 0;
      while (node.children && node.terminal === null) {
        let best = null; let bestScore = -Infinity;
        let visitedPolicy = 0; for (const c of node.children) if (c.n) visitedPolicy += c.prior;
        const fpu = -node.q - fpuRed * Math.sqrt(visitedPolicy);
        const sqrtN = Math.sqrt(Math.max(1, node.n));
        for (const c of node.children) {
          const q = c.n ? -c.q : fpu;
          const score = q + cpuct * c.prior * sqrtN / (1 + c.n);
          if (score > bestScore) { bestScore = score; best = c; }
        }
        node = best; depth += 1;
        if (!node.pos) { node.pos = node.parent.pos.play(node.move); node.sig = node.pos.signature(); }
        if (!node.n) break;
      }
      let value;
      if (node.terminal !== null) value = node.terminal;
      else if (!node.children) value = this.evaluate(node, gameHistory, fillMissing, policyTemp);
      else value = -node.q; // already expanded and visited (rare); reuse its mean
      // `value` is from node.pos side-to-move view; backpropagate alternating sign
      for (let n = node; n; n = n.parent) { n.n += 1; n.w += value; value = -value; }
      nodes += 1; depthSum += depth; if (depth > maxDepth) maxDepth = depth;
      if (node.terminal === -1 && node.parent === root) { mate = node; break; } // checkmate found: nothing can beat it
      if ((nodes & 7) === 0) {
        const now = performance.now();
        if (now - start >= timeMs) break;
        if (now - lastYield > 40) { lastYield = now; await new Promise(resolve => setTimeout(resolve, 0)); }
      }
    }
    const elapsed = Math.max(1, performance.now() - start);
    // choose: most visits, tie-break by prior (policy-only play at nodes=1 picks the top prior)
    const ranked = [...root.children].sort((a, b) => b.n - a.n || b.prior - a.prior);
    let pick = mate || ranked[0];
    const temperature = opts.temperature ?? 0;
    if (!mate && temperature > 0 && ranked.length > 1) {
      const weights = ranked.map(c => Math.pow(Math.max(c.n, 1e-3) + c.prior, 1 / temperature));
      let r = (opts.random ? opts.random() : Math.random()) * weights.reduce((a, b) => a + b, 0);
      for (let i = 0; i < ranked.length; i += 1) { r -= weights[i]; if (r <= 0) { pick = ranked[i]; break; } }
    }
    const pv = []; for (let n = pick; n && n.children && pv.length < 12; n = [...n.children].sort((a, b) => b.n - a.n)[0]) { pv.push(moveToUci(n.move)); if (!n.children[0]?.n) break; }
    if (!pv.length) pv.push(moveToUci(pick.move));
    const q = pick.n ? -pick.q : root.q;
    return { uci: moveToUci(pick.move), nodes: nodes + 1, depth: nodes ? Math.round(depthSum / nodes) : 0, seldepth: maxDepth, elapsedMs: Math.round(elapsed), nps: Math.round(nodes / (elapsed / 1000)), score: qToCp(q), q, pv };
  }
}
