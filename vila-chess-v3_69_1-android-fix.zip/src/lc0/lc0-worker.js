/**
 * Dedicated Web Worker for ONE Lc0 neural net. Each net runs in its own worker, so loading, inference and
 * search never touch the UI thread or another net's memory.
 *
 *  → { type:'load', id, url? , bytes? }                       ← { type:'loaded', id, info } | { type:'error', id, message }
 *  → { type:'search', id, game, options }                      ← { type:'result', id, result } | { type:'error', id, message }
 *  → { type:'stop' }
 */
import { loadLc0Net } from './weights.js';
import { Lc0Network } from './network.js';
import { Lc0Search } from './mcts.js';

let search = null;
let network = null;
let current = null; // the search in flight (a new request stops it and waits for it to finish)

self.addEventListener('message', async event => {
  const msg = event.data || {};
  if (msg.type === 'stop') { search?.stop(); return; }
  if (msg.type === 'load') {
    try {
      let bytes = msg.bytes ? new Uint8Array(msg.bytes) : null;
      if (!bytes) {
        const response = await fetch(msg.url);
        if (!response.ok) throw new Error(`Không tải được mạng Lc0 (HTTP ${response.status}).`);
        bytes = new Uint8Array(await response.arrayBuffer());
      }
      const parsed = await loadLc0Net(bytes);
      network = new Lc0Network(parsed, { simd: msg.simd !== false });
      search = new Lc0Search(network);
      // Warm the JIT / WASM so the first real move is not slow.
      network.forward(new Float32Array(112 * 64));
      self.postMessage({ type: 'loaded', id: msg.id, info: network.info });
    } catch (error) {
      network = null; search = null;
      self.postMessage({ type: 'error', id: msg.id, message: String(error?.message || error) });
    }
    return;
  }
  if (msg.type === 'search') {
    if (!search) { self.postMessage({ type: 'error', id: msg.id, message: 'Mạng Lc0 chưa được nạp.' }); return; }
    if (current) { search.stop(); await current.catch(() => {}); }
    current = (async () => {
      try {
        const result = await search.search(msg.game, msg.options || {});
        self.postMessage({ type: 'result', id: msg.id, result });
      } catch (error) {
        self.postMessage({ type: 'error', id: msg.id, message: String(error?.message || error) });
      }
    })();
    await current; current = null;
  }
});
