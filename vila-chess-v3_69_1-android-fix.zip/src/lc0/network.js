/**
 * Forward pass for Lc0 residual-tower nets.
 *  - Fast path: hand-assembled WebAssembly SIMD kernel for the 3×3 convolutions (see simd-kernel.js).
 *  - Fallback: plain JS loops that skip zero inputs (works on any WebView).
 * Activations are channel-last ([64 squares][channels]); all tensors live in ONE buffer so the WASM kernel and the
 * JS code see the same memory. The policy head is evaluated only for the legal moves.
 */
import { createSimdConv, writeTapTable, TAP_TABLE_BYTES } from './simd-kernel.js';

const SQ = 64;
const relu = v => (v > 0 ? v : 0);
const mish = v => v * Math.tanh(Math.log1p(Math.exp(v)));
const swish = v => v / (1 + Math.exp(-v));
const selu = v => 1.0507009873554805 * (v > 0 ? v : 1.6732632423543772 * (Math.exp(v) - 1));
const ACTIVATIONS = [relu, mish, relu, selu, swish];

const TAPS = (() => {
  const table = [];
  for (let s = 0; s < SQ; s += 1) {
    const f = s & 7; const r = s >> 3; const list = [];
    for (let dr = -1; dr <= 1; dr += 1) for (let df = -1; df <= 1; df += 1) {
      const nf = f + df; const nr = r + dr;
      if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) list.push([(dr + 1) * 3 + (df + 1), nr * 8 + nf]);
    }
    table.push(list);
  }
  return table;
})();

function packConv3(w, cin, cout, dst) {
  for (let o = 0; o < cout; o += 1) for (let i = 0; i < cin; i += 1) for (let t = 0; t < 9; t += 1) dst[(t * cin + i) * cout + o] = w[(o * cin + i) * 9 + t];
  return dst;
}

function jsConv3(input, cin, packed, bias, cout, output, act) {
  for (let s = 0; s < SQ; s += 1) {
    const base = s * cout;
    for (let o = 0; o < cout; o += 1) output[base + o] = bias[o];
    for (const [tap, n] of TAPS[s]) {
      const inBase = n * cin; const wBase = tap * cin * cout;
      for (let i = 0; i < cin; i += 1) {
        const x = input[inBase + i];
        if (x === 0) continue;
        const wi = wBase + i * cout;
        for (let o = 0; o < cout; o += 1) output[base + o] += x * packed[wi + o];
      }
    }
    if (act) for (let o = 0; o < cout; o += 1) output[base + o] = act(output[base + o]);
  }
}

export class Lc0Network {
  /** @param {object} net parsed weights  @param {{simd?: boolean}} options */
  constructor(net, { simd = true } = {}) {
    const C = net.filters;
    this.C = C; this.act = ACTIVATIONS[net.format.activation] || relu; this.wdl = net.format.value === 2;
    this.planes = net.policy.b.length; this.policyOut = net.policy; this.value = net.value;
    this.valueChannels = net.value.conv.b.length; this.hidden = net.value.fc1b.length; this.outputs = net.value.fc2b.length;
    // --- memory plan (floats): packed conv weights + biases + activation buffers + tap table
    const convs = [{ cin: 112, cout: C, src: net.input }];
    for (const block of net.blocks) { convs.push({ cin: C, cout: C, src: block.c1 }, { cin: C, cout: C, src: block.c2 }); }
    if (net.policy1) convs.push({ cin: C, cout: C, src: net.policy1 });
    let floats = TAP_TABLE_BYTES / 4;
    for (const c of convs) floats += 9 * c.cin * c.cout + c.cout;
    floats += SQ * 112 + 4 * SQ * C + 64;
    const bytes = Math.max(65536, (floats * 4 + 65535) & ~65535);
    const canSimd = simd && C % 16 === 0 && net.blocks.every(block => block.c1.b.length % 16 === 0);
    let memory = null; let conv = null;
    if (canSimd && typeof WebAssembly !== 'undefined') {
      try { memory = new WebAssembly.Memory({ initial: bytes / 65536 }); conv = createSimdConv(memory); } catch { memory = null; conv = null; }
    }
    this.simd = !!conv; this.convFn = conv;
    const buffer = memory ? memory.buffer : new ArrayBuffer(bytes);
    const f32 = new Float32Array(buffer); const i32 = new Int32Array(buffer);
    let cursor = 0;
    const alloc = n => { const off = cursor; cursor += (n + 3) & ~3; return { off: off * 4, arr: f32.subarray(off, off + n) }; };
    this.tapsOff = alloc(TAP_TABLE_BYTES / 4).off; writeTapTable(i32, this.tapsOff);
    const pack = c => {
      const w = alloc(9 * c.cin * c.cout); packConv3(c.src.w, c.cin, c.cout, w.arr);
      const b = alloc(c.cout); b.arr.set(c.src.b);
      return { w, b, cin: c.cin, cout: c.cout };
    };
    let k = 0;
    this.input = pack(convs[k++]);
    this.blocks = net.blocks.map(block => ({ c1: pack(convs[k++]), c2: pack(convs[k++]), se: block.se }));
    this.policy1 = net.policy1 ? pack(convs[k++]) : null;
    this.bufIn = alloc(SQ * 112); this.bufA = alloc(SQ * C); this.bufB = alloc(SQ * C); this.bufT = alloc(SQ * C); this.bufPol = alloc(SQ * C);
    this.info = { filters: C, blocks: net.blocks.length, se: !!net.blocks[0].se, wdl: this.wdl, simd: this.simd, bytes: net.bytes };
  }

  conv(inBuf, layer, outBuf, act) {
    if (this.convFn) this.convFn(inBuf.off, layer.cin, layer.w.off, layer.b.off, layer.cout, outBuf.off, act ? 1 : 0, this.tapsOff);
    else jsConv3(inBuf.arr, layer.cin, layer.w.arr, layer.b.arr, layer.cout, outBuf.arr, act ? this.act : null);
  }

  /** `planes`: Float32Array(112*64) plane-major. Returns `{ win, draw, loss, q }` (side-to-move view). */
  forward(planes) {
    const C = this.C; const act = this.act;
    const input = this.bufIn.arr;
    for (let p = 0; p < 112; p += 1) for (let s = 0; s < SQ; s += 1) input[s * 112 + p] = planes[p * SQ + s];
    // The WASM kernel applies ReLU only; other activations are applied in JS after the (linear) conv.
    const kernelAct = this.act === relu;
    const run = (src, layer, dst, wantAct) => {
      this.conv(src, layer, dst, wantAct && kernelAct);
      if (wantAct && !kernelAct) { const a = dst.arr; for (let i = 0; i < SQ * layer.cout; i += 1) a[i] = act(a[i]); }
    };
    run(this.bufIn, this.input, this.bufA, true);
    let x = this.bufA; let t = this.bufT; const y = this.bufB;
    for (const block of this.blocks) {
      run(x, block.c1, y, true);
      run(y, block.c2, t, false);
      const ta = t.arr; const xa = x.arr; const se = block.se;
      if (se) {
        const hid = se.b1.length; const pooled = new Float32Array(C);
        for (let s = 0; s < SQ; s += 1) for (let c = 0; c < C; c += 1) pooled[c] += ta[s * C + c];
        for (let c = 0; c < C; c += 1) pooled[c] /= SQ;
        const h = new Float32Array(hid);
        for (let j = 0; j < hid; j += 1) { let sum = se.b1[j]; for (let c = 0; c < C; c += 1) sum += se.w1[j * C + c] * pooled[c]; h[j] = relu(sum); }
        const gate = new Float32Array(C); const shift = new Float32Array(C);
        for (let j = 0; j < 2 * C; j += 1) {
          let sum = se.b2[j]; for (let q = 0; q < hid; q += 1) sum += se.w2[j * hid + q] * h[q];
          if (j < C) gate[j] = 1 / (1 + Math.exp(-sum)); else shift[j - C] = sum;
        }
        for (let s = 0; s < SQ; s += 1) for (let c = 0; c < C; c += 1) ta[s * C + c] = act(gate[c] * ta[s * C + c] + shift[c] + xa[s * C + c]);
      } else for (let i = 0; i < SQ * C; i += 1) ta[i] = act(ta[i] + xa[i]);
      const next = t; t = x; x = next;
    }
    const xa = x.arr;
    // value head: 1×1 conv → activation → flatten (channel-major) → FC → FC
    const vc = this.valueChannels; const flat = new Float32Array(vc * SQ);
    const vw = this.value.conv.w; const vb = this.value.conv.b;
    for (let s = 0; s < SQ; s += 1) for (let o = 0; o < vc; o += 1) {
      let sum = vb[o]; const wo = o * C;
      for (let i = 0; i < C; i += 1) sum += vw[wo + i] * xa[s * C + i];
      flat[o * SQ + s] = act(sum);
    }
    const hid = new Float32Array(this.hidden); const w1 = this.value.fc1w; const n1 = flat.length;
    for (let j = 0; j < this.hidden; j += 1) {
      let sum = this.value.fc1b[j]; const wj = j * n1;
      for (let i = 0; i < n1; i += 1) { const v = flat[i]; if (v !== 0) sum += w1[wj + i] * v; }
      hid[j] = act(sum);
    }
    const out = new Float32Array(this.outputs);
    for (let j = 0; j < this.outputs; j += 1) { let sum = this.value.fc2b[j]; for (let i = 0; i < this.hidden; i += 1) sum += this.value.fc2w[j * this.hidden + i] * hid[i]; out[j] = sum; }
    // policy trunk, then sparse reads in policyLogit()
    if (this.policy1) run(x, this.policy1, this.bufPol, true); else this.bufPol.arr.set(xa);
    if (this.wdl) {
      const m = Math.max(out[0], out[1], out[2]);
      const e0 = Math.exp(out[0] - m); const e1 = Math.exp(out[1] - m); const e2 = Math.exp(out[2] - m); const z = e0 + e1 + e2;
      return { win: e0 / z, draw: e1 / z, loss: e2 / z, q: (e0 - e2) / z };
    }
    const q = Math.tanh(out[0]);
    return { win: (1 + q) / 2, draw: 0, loss: (1 - q) / 2, q };
  }

  /** Raw policy logit for output cell `plane*64 + square` (valid after `forward`). */
  policyLogit(cell) {
    const C = this.C; const plane = Math.floor(cell / SQ); const s = cell % SQ;
    const w = this.policyOut.w; const pol = this.bufPol.arr; let sum = this.policyOut.b[plane];
    for (const [tap, n] of TAPS[s]) {
      const nBase = n * C; const wBase = plane * C * 9 + tap;
      for (let i = 0; i < C; i += 1) sum += w[wBase + i * 9] * pol[nBase + i];
    }
    return sum;
  }
}
