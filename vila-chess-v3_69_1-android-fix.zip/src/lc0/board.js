/**
 * Minimal, fast chess rules for the Lc0 worker (no chess.js: the search needs millions of make-move calls).
 * Squares are 0..63 with a1 = 0, b1 = 1 … h8 = 63. Pieces: 1..6 = P N B R Q K, +8 for black.
 * A move is an int: from | to << 6 | promo << 12 (promo = 2..5 for N B R Q, 0 for none).
 */
export const P = 1, N = 2, B = 3, R = 4, Q = 5, K = 6;
export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const KNIGHT = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
const KING = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]];
const DIAG = [[1, 1], [1, -1], [-1, -1], [-1, 1]];
const ORTH = [[0, 1], [1, 0], [0, -1], [-1, 0]];
const PIECE_CHARS = { p: P, n: N, b: B, r: R, q: Q, k: K };

export const moveFrom = m => m & 63;
export const moveTo = m => (m >> 6) & 63;
export const movePromo = m => (m >> 12) & 7;
export const sqName = s => String.fromCharCode(97 + (s & 7)) + String.fromCharCode(49 + (s >> 3));
export function moveToUci(m) { return sqName(moveFrom(m)) + sqName(moveTo(m)) + (movePromo(m) ? 'xnbrq'[movePromo(m) - 1] : ''); }

export class Position {
  constructor() {
    this.board = new Int8Array(64);
    this.side = 0; // 0 white, 1 black
    this.castling = 0; // 1 WK, 2 WQ, 4 BK, 8 BQ
    this.ep = -1;
    this.halfmove = 0;
    this.fullmove = 1;
    this.key = '';
  }
  clone() {
    const p = new Position();
    p.board = this.board.slice(); p.side = this.side; p.castling = this.castling; p.ep = this.ep;
    p.halfmove = this.halfmove; p.fullmove = this.fullmove;
    return p;
  }
  /** Position identity for repetition (board, side, castling, en-passant square). */
  signature() {
    // Two independent 32-bit FNV-1a hashes folded into one safe integer (collisions are practically impossible).
    let h1 = 0x811c9dc5; let h2 = 0x9747b28c; const b = this.board;
    for (let i = 0; i < 64; i += 1) { const v = b[i]; h1 = Math.imul(h1 ^ v, 0x01000193); h2 = Math.imul(h2 ^ (v + i * 17), 0x85ebca6b); }
    const extra = this.side | (this.castling << 1) | ((this.ep + 1) << 5);
    h1 = Math.imul(h1 ^ extra, 0x01000193); h2 = Math.imul(h2 ^ extra, 0x85ebca6b);
    return (h1 >>> 0) * 2097152 + ((h2 >>> 0) & 0x1fffff);
  }
  static fromFen(fen) {
    const parts = String(fen || START_FEN).trim().split(/\s+/);
    if (parts.length < 2) throw new Error('FEN không hợp lệ');
    const pos = new Position();
    const rows = parts[0].split('/');
    if (rows.length !== 8) throw new Error('FEN không hợp lệ');
    for (let r = 0; r < 8; r += 1) {
      let file = 0;
      for (const ch of rows[r]) {
        if (ch >= '1' && ch <= '8') file += Number(ch);
        else {
          const type = PIECE_CHARS[ch.toLowerCase()];
          if (!type || file > 7) throw new Error('FEN không hợp lệ');
          pos.board[(7 - r) * 8 + file] = type | (ch === ch.toLowerCase() ? 8 : 0);
          file += 1;
        }
      }
      if (file !== 8) throw new Error('FEN không hợp lệ');
    }
    pos.side = parts[1] === 'b' ? 1 : 0;
    const c = parts[2] || '-';
    if (c.includes('K')) pos.castling |= 1; if (c.includes('Q')) pos.castling |= 2;
    if (c.includes('k')) pos.castling |= 4; if (c.includes('q')) pos.castling |= 8;
    if (parts[3] && parts[3] !== '-') pos.ep = (parts[3].charCodeAt(0) - 97) + (parts[3].charCodeAt(1) - 49) * 8;
    pos.halfmove = Number(parts[4]) || 0;
    pos.fullmove = Number(parts[5]) || 1;
    return pos;
  }
  fen() {
    let out = '';
    for (let r = 7; r >= 0; r -= 1) {
      let empty = 0;
      for (let f = 0; f < 8; f += 1) {
        const v = this.board[r * 8 + f];
        if (!v) { empty += 1; continue; }
        if (empty) { out += empty; empty = 0; }
        const ch = 'pnbrqk'[(v & 7) - 1];
        out += v & 8 ? ch : ch.toUpperCase();
      }
      if (empty) out += empty;
      if (r) out += '/';
    }
    const cas = (this.castling & 1 ? 'K' : '') + (this.castling & 2 ? 'Q' : '') + (this.castling & 4 ? 'k' : '') + (this.castling & 8 ? 'q' : '');
    return `${out} ${this.side ? 'b' : 'w'} ${cas || '-'} ${this.ep >= 0 ? sqName(this.ep) : '-'} ${this.halfmove} ${this.fullmove}`;
  }
  kingSquare(color) {
    const target = K | (color ? 8 : 0);
    for (let i = 0; i < 64; i += 1) if (this.board[i] === target) return i;
    return -1;
  }
  /** Is square `sq` attacked by `byColor`? */
  attacked(sq, byColor) {
    const b = this.board; const base = byColor ? 8 : 0;
    const f = sq & 7; const r = sq >> 3;
    // pawns
    const pr = byColor ? r + 1 : r - 1;
    if (pr >= 0 && pr < 8) {
      if (f > 0 && b[pr * 8 + f - 1] === (P | base)) return true;
      if (f < 7 && b[pr * 8 + f + 1] === (P | base)) return true;
    }
    for (const [df, dr] of KNIGHT) { const nf = f + df, nr = r + dr; if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] === (N | base)) return true; }
    for (const [df, dr] of KING) { const nf = f + df, nr = r + dr; if (nf >= 0 && nf < 8 && nr >= 0 && nr < 8 && b[nr * 8 + nf] === (K | base)) return true; }
    for (const [df, dr] of DIAG) {
      let nf = f + df, nr = r + dr;
      while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) { const v = b[nr * 8 + nf]; if (v) { if (v === (B | base) || v === (Q | base)) return true; break; } nf += df; nr += dr; }
    }
    for (const [df, dr] of ORTH) {
      let nf = f + df, nr = r + dr;
      while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) { const v = b[nr * 8 + nf]; if (v) { if (v === (R | base) || v === (Q | base)) return true; break; } nf += df; nr += dr; }
    }
    return false;
  }
  inCheck() { const k = this.kingSquare(this.side); return k >= 0 && this.attacked(k, this.side ^ 1); }

  pseudoMoves() {
    const out = []; const b = this.board; const us = this.side; const base = us ? 8 : 0;
    const push = (from, to, promo = 0) => out.push(from | (to << 6) | (promo << 12));
    for (let from = 0; from < 64; from += 1) {
      const v = b[from];
      if (!v || ((v & 8) !== base)) continue;
      const type = v & 7; const f = from & 7; const r = from >> 3;
      if (type === P) {
        const dir = us ? -1 : 1; const startRank = us ? 6 : 1; const lastRank = us ? 0 : 7;
        const nr = r + dir;
        if (nr < 0 || nr > 7) continue;
        const addPawn = to => { if ((to >> 3) === lastRank) { for (let p = Q; p >= N; p -= 1) push(from, to, p); } else push(from, to); };
        if (!b[nr * 8 + f]) {
          addPawn(nr * 8 + f);
          if (r === startRank && !b[(r + 2 * dir) * 8 + f]) push(from, (r + 2 * dir) * 8 + f);
        }
        for (const df of [-1, 1]) {
          const nf = f + df; if (nf < 0 || nf > 7) continue;
          const to = nr * 8 + nf; const target = b[to];
          if (target && (target & 8) !== base) addPawn(to);
          else if (!target && to === this.ep) push(from, to);
        }
      } else if (type === N || type === K) {
        for (const [df, dr] of type === N ? KNIGHT : KING) {
          const nf = f + df, nr = r + dr;
          if (nf < 0 || nf > 7 || nr < 0 || nr > 7) continue;
          const t = b[nr * 8 + nf];
          if (!t || (t & 8) !== base) push(from, nr * 8 + nf);
        }
        if (type === K) {
          const homeRank = us ? 7 : 0;
          if (from === homeRank * 8 + 4 && !this.attacked(from, us ^ 1)) {
            const ks = us ? 4 : 1; const qs = us ? 8 : 2;
            if ((this.castling & ks) && !b[homeRank * 8 + 5] && !b[homeRank * 8 + 6] && b[homeRank * 8 + 7] === (R | base)
              && !this.attacked(homeRank * 8 + 5, us ^ 1) && !this.attacked(homeRank * 8 + 6, us ^ 1)) push(from, homeRank * 8 + 6);
            if ((this.castling & qs) && !b[homeRank * 8 + 3] && !b[homeRank * 8 + 2] && !b[homeRank * 8 + 1] && b[homeRank * 8] === (R | base)
              && !this.attacked(homeRank * 8 + 3, us ^ 1) && !this.attacked(homeRank * 8 + 2, us ^ 1)) push(from, homeRank * 8 + 2);
          }
        }
      } else {
        const dirs = type === B ? DIAG : type === R ? ORTH : DIAG.concat(ORTH);
        for (const [df, dr] of dirs) {
          let nf = f + df, nr = r + dr;
          while (nf >= 0 && nf < 8 && nr >= 0 && nr < 8) {
            const t = b[nr * 8 + nf];
            if (!t) push(from, nr * 8 + nf);
            else { if ((t & 8) !== base) push(from, nr * 8 + nf); break; }
            nf += df; nr += dr;
          }
        }
      }
    }
    return out;
  }
  /** Returns a new Position after `move` (assumes the move is pseudo-legal). */
  play(move) {
    const p = this.clone(); const b = p.board;
    const from = moveFrom(move), to = moveTo(move), promo = movePromo(move);
    const piece = b[from]; const type = piece & 7; const captured = b[to];
    b[to] = piece; b[from] = 0;
    if (type === P && to === this.ep && !captured) b[this.side ? to + 8 : to - 8] = 0;
    if (promo) b[to] = promo | (this.side ? 8 : 0);
    if (type === K && Math.abs(to - from) === 2) {
      const rank = from >> 3;
      if (to > from) { b[rank * 8 + 5] = b[rank * 8 + 7]; b[rank * 8 + 7] = 0; } else { b[rank * 8 + 3] = b[rank * 8]; b[rank * 8] = 0; }
    }
    const clear = sq => { if (sq === 4) p.castling &= ~3; else if (sq === 60) p.castling &= ~12; else if (sq === 7) p.castling &= ~1; else if (sq === 0) p.castling &= ~2; else if (sq === 63) p.castling &= ~4; else if (sq === 56) p.castling &= ~8; };
    clear(from); clear(to);
    p.ep = type === P && Math.abs(to - from) === 16 ? (from + to) >> 1 : -1;
    p.halfmove = type === P || captured ? 0 : this.halfmove + 1;
    if (this.side) p.fullmove += 1;
    p.side = this.side ^ 1;
    return p;
  }
  legalMoves() {
    const out = [];
    for (const m of this.pseudoMoves()) {
      const next = this.play(m);
      const k = next.kingSquare(this.side);
      if (k >= 0 && !next.attacked(k, this.side ^ 1)) out.push(m);
    }
    return out;
  }
  /** Insufficient material (K vs K, K+minor vs K, same-colour bishops only). */
  insufficientMaterial() {
    let minors = 0; const bishopSquares = [];
    for (let i = 0; i < 64; i += 1) {
      const t = this.board[i] & 7;
      if (!t || t === K) continue;
      if (t === P || t === R || t === Q) return false;
      minors += 1; if (t === B) bishopSquares.push(((i >> 3) + (i & 7)) & 1);
    }
    if (minors <= 1) return true;
    return minors === bishopSquares.length && bishopSquares.every(c => c === bishopSquares[0]);
  }
  /** Resolve a UCI string against the legal move list (returns the move int or -1). */
  parseUci(uci) {
    const s = String(uci || '');
    if (s.length < 4) return -1;
    const from = (s.charCodeAt(0) - 97) + (s.charCodeAt(1) - 49) * 8;
    const to = (s.charCodeAt(2) - 97) + (s.charCodeAt(3) - 49) * 8;
    const promo = s[4] ? 'xnbrq'.indexOf(s[4].toLowerCase()) : 0; // 1..4 = n b r q  →  piece codes 2..5
    const wanted = promo > 0 ? promo + 1 : 0;
    for (const m of this.legalMoves()) if (moveFrom(m) === from && moveTo(m) === to && movePromo(m) === wanted) return m;
    return -1;
  }
}

export function perft(pos, depth) {
  if (depth === 0) return 1;
  const moves = pos.legalMoves();
  if (depth === 1) return moves.length;
  let n = 0;
  for (const m of moves) n += perft(pos.play(m), depth - 1);
  return n;
}
