/**
 * Reader for Leela Chess Zero weight files (`.pb` / `.pb.gz`, the `pblczero.Net` protobuf).
 * Supports the convolutional ("residual tower") family: classical or SE residual blocks, convolution (AZ-style)
 * policy head, scalar or WDL value head. Batch-norm parameters are folded into the convolutions here, so the
 * runtime only ever sees weights + biases. Attention/transformer nets are rejected with a clear message.
 */
const NET_FORMAT_SE = new Set([2, 4]);

function readVarint(buf, pos) {
  let result = 0; let shift = 0; let byte;
  do { byte = buf[pos.o++]; result += (byte & 0x7f) * 2 ** shift; shift += 7; } while (byte & 0x80);
  return result;
}
/** Parse one protobuf message level into `{ field -> [values] }`; length-delimited values stay as subarrays. */
function parseMessage(buf) {
  const fields = new Map(); const pos = { o: 0 };
  const view = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  while (pos.o < buf.length) {
    const tag = readVarint(buf, pos); const field = Math.floor(tag / 8); const wire = tag & 7;
    let value;
    if (wire === 0) value = readVarint(buf, pos);
    else if (wire === 1) { value = view.getFloat64(pos.o, true); pos.o += 8; }
    else if (wire === 5) { value = { f32: view.getFloat32(pos.o, true), u32: view.getUint32(pos.o, true) }; pos.o += 4; }
    else if (wire === 2) { const len = readVarint(buf, pos); value = buf.subarray(pos.o, pos.o + len); pos.o += len; }
    else throw new Error(`Tệp trọng số Lc0 không hợp lệ (wire ${wire}).`);
    if (!fields.has(field)) fields.set(field, []);
    fields.get(field).push(value);
  }
  return fields;
}
const first = (m, f) => m?.get(f)?.[0];

function decodeLayer(bytes, defaultEncoding) {
  if (!bytes) return null;
  const m = parseMessage(bytes);
  const min = first(m, 1)?.f32 ?? 0; const max = first(m, 2)?.f32 ?? 0;
  const params = first(m, 3);
  if (!params) return null;
  const encoding = first(m, 4) || defaultEncoding || 1;
  const copy = params.slice(); // own, aligned buffer
  if (encoding === 4) return new Float32Array(copy.buffer, 0, copy.byteLength / 4);
  if (encoding === 1) {
    const n = copy.byteLength >> 1; const u16 = new Uint16Array(copy.buffer, 0, n); const out = new Float32Array(n);
    const range = max - min;
    for (let i = 0; i < n; i += 1) out[i] = min + (u16[i] / 65535) * range;
    return out;
  }
  if (encoding === 2 || encoding === 3) {
    const n = copy.byteLength >> 1; const u16 = new Uint16Array(copy.buffer, 0, n); const out = new Float32Array(n);
    const tmp = new DataView(new ArrayBuffer(4));
    for (let i = 0; i < n; i += 1) {
      if (encoding === 3) { tmp.setUint32(0, u16[i] << 16); out[i] = tmp.getFloat32(0); } else {
        const h = u16[i]; const s = h & 0x8000 ? -1 : 1; const e = (h >> 10) & 31; const f = h & 1023;
        out[i] = e === 0 ? s * 2 ** -14 * (f / 1024) : e === 31 ? (f ? NaN : s * Infinity) : s * 2 ** (e - 15) * (1 + f / 1024);
      }
    }
    return out;
  }
  throw new Error('Kiểu mã hóa trọng số Lc0 chưa được hỗ trợ.');
}

/** ConvBlock → `{ w, b }` with batch-norm folded in (lc0 stores bn variance in bn_stddivs; eps = 1e-5). */
function decodeConvBlock(bytes, enc) {
  const m = parseMessage(bytes);
  const w = decodeLayer(first(m, 1), enc);
  let b = decodeLayer(first(m, 2), enc);
  const means = decodeLayer(first(m, 3), enc); const vars = decodeLayer(first(m, 4), enc);
  const gammas = decodeLayer(first(m, 5), enc); const betas = decodeLayer(first(m, 6), enc);
  if (!w) throw new Error('Thiếu trọng số tích chập.');
  const outputs = (b?.length) || means?.length || 0;
  if (means && vars) {
    const per = w.length / means.length; b = b ? Float32Array.from(b) : new Float32Array(means.length);
    for (let o = 0; o < means.length; o += 1) {
      const gamma = gammas ? gammas[o] : 1; const beta = betas ? betas[o] : 0;
      const scale = gamma / Math.sqrt(vars[o] + 1e-5);
      for (let i = 0; i < per; i += 1) w[o * per + i] *= scale;
      b[o] = beta + (b[o] - means[o]) * scale;
    }
  }
  return { w, b: b || new Float32Array(outputs) };
}

export async function gunzipIfNeeded(bytes) {
  if (bytes[0] !== 0x1f || bytes[1] !== 0x8b) return bytes;
  if (typeof DecompressionStream === 'undefined') throw new Error('Thiết bị chưa hỗ trợ giải nén .gz — hãy dùng tệp .pb đã giải nén.');
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** Parse a (already gunzipped) `pblczero.Net` buffer. */
export function parseLc0Net(raw) {
  const net = parseMessage(raw);
  const fmt = first(net, 4); const fmtMsg = fmt ? parseMessage(fmt) : null;
  const weightsEncoding = first(fmtMsg, 1) || 1;
  const nf = first(fmtMsg, 2) ? parseMessage(first(fmtMsg, 2)) : new Map();
  const format = {
    input: first(nf, 1) || 1, output: first(nf, 2) || 1, network: first(nf, 3) || 1,
    policy: first(nf, 4) || 1, value: first(nf, 5) || 1, movesLeft: first(nf, 6) || 1,
    activation: first(nf, 7) || 0
  };
  const wBytes = first(net, 10);
  if (!wBytes) throw new Error('Tệp không chứa trọng số mạng (có thể là mạng ONNX — chưa được hỗ trợ).');
  if (format.network >= 6 || format.policy === 3) throw new Error('Mạng Lc0 dùng kiến trúc attention/transformer; trình chạy này hỗ trợ mạng residual (SE) kiểu T60/T70 và Maia.');
  if (format.input !== 1 && format.input !== 0) throw new Error(`Định dạng đầu vào Lc0 ${format.input} chưa được hỗ trợ.`);
  const w = parseMessage(wBytes);
  const conv = f => (first(w, f) ? decodeConvBlock(first(w, f), weightsEncoding) : null);
  const layer = f => decodeLayer(first(w, f), weightsEncoding);
  const input = conv(1);
  const filters = input.b.length;
  if (!filters || input.w.length !== 112 * 9 * filters) throw new Error('Cấu trúc mạng đầu vào không khớp (cần 112 mặt phẳng).');
  const blocks = (w.get(2) || []).map(bytes => {
    const m = parseMessage(bytes);
    const se = first(m, 3) ? parseMessage(first(m, 3)) : null;
    return {
      c1: decodeConvBlock(first(m, 1), weightsEncoding), c2: decodeConvBlock(first(m, 2), weightsEncoding),
      se: se ? { w1: decodeLayer(first(se, 1), weightsEncoding), b1: decodeLayer(first(se, 2), weightsEncoding), w2: decodeLayer(first(se, 3), weightsEncoding), b2: decodeLayer(first(se, 4), weightsEncoding) } : null
    };
  });
  if (!blocks.length) throw new Error('Mạng không có khối residual.');
  if (blocks.some(block => block.se) !== NET_FORMAT_SE.has(format.network) && blocks.some(block => block.se) === false && NET_FORMAT_SE.has(format.network)) {
    throw new Error('Thiếu khối SE trong tệp mạng.');
  }
  const policy1 = conv(11); const policy = conv(3);
  if (!policy || (format.policy === 2 && !policy1)) throw new Error('Mạng thiếu đầu policy kiểu tích chập; chỉ hỗ trợ mạng policy convolution.');
  if (first(w, 4)) throw new Error('Mạng dùng đầu policy FC cổ điển (đời cũ) — chưa được hỗ trợ; hãy dùng mạng convolution (T60/T70, Maia…).');
  const value = { conv: conv(6), fc1w: layer(7), fc1b: layer(8), fc2w: layer(9), fc2b: layer(10) };
  if (!value.conv || !value.fc1w || !value.fc2w) throw new Error('Mạng thiếu đầu value.');
  return { format, filters, input, blocks, policy1, policy, value, bytes: raw.length };
}

export async function loadLc0Net(bytes) {
  return parseLc0Net(await gunzipIfNeeded(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)));
}
