/**
 * Drag & drop feel for every board (practice, ranked, puzzles).
 *
 * - The ghost is moved synchronously inside pointermove (no one-frame requestAnimationFrame lag).
 * - Touch lifts the piece above the fingertip; a mouse keeps it centred under the cursor.
 * - After a drop the real piece "lands" from where the ghost was released (short FLIP animation)
 *   instead of teleporting to the middle of the square.
 * - A rejected drop glides the ghost back to its origin square.
 *
 * Pure geometry helpers are exported separately so they can be unit-tested in Node.
 */

export const DRAG_SCALE = 1.08;
/** Fraction of the piece height placed ABOVE the pointer. 0.5 = centred, 0.62 = lifted. */
export const LIFT_TOUCH = 0.62;
export const LIFT_MOUSE = 0.5;
export const LAND_EASING = 'cubic-bezier(0.2, 0.9, 0.25, 1)';

export function liftFor(pointerType) {
  return pointerType === 'mouse' ? LIFT_MOUSE : LIFT_TOUCH;
}

/** CSS transform that centres a ghost horizontally on the pointer and lifts it vertically. */
export function ghostTransform(x, y, pointerType = 'touch', scale = DRAG_SCALE) {
  const lift = liftFor(pointerType) * 100;
  return `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) translate(-50%,-${lift}%) scale(${scale})`;
}

/** Viewport centre of a ghost of `size` px whose pointer is at (x, y). */
export function ghostCenter(x, y, size, pointerType = 'touch') {
  return { x, y: y + (0.5 - liftFor(pointerType)) * size };
}

/** Offset (dx, dy) that moves a piece resting in `rect` back to a viewport point. */
export function offsetFromPoint(rect, point) {
  if (!rect || !point) return { dx: 0, dy: 0 };
  return { dx: point.x - (rect.left + rect.width / 2), dy: point.y - (rect.top + rect.height / 2) };
}

/** Landing duration: tiny when the piece is dropped almost on the square, a bit longer when far. */
export function landDurationMs(dx, dy, size = 48) {
  const dist = Math.hypot(dx, dy);
  const rel = size > 0 ? dist / size : 0;
  return Math.round(Math.min(170, Math.max(90, 90 + rel * 38)));
}

function reducedMotion() {
  return typeof window !== 'undefined' && Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches);
}

/**
 * Animate the piece standing in `cell` from the viewport point where the ghost was released.
 * `getCell` is re-evaluated for up to `tries` animation frames because some boards repaint
 * asynchronously after a drop (ranked boards wait for the server, puzzles wait for validation).
 */
export function landPieceFromPoint(getCell, point, { pointerType = 'touch', tries = 4, onStart } = {}) {
  if (!point || reducedMotion() || typeof requestAnimationFrame !== 'function') return;
  const attempt = left => {
    const cell = getCell();
    const piece = cell?.querySelector?.('.piece');
    if (!cell || !piece || typeof piece.animate !== 'function') {
      if (left > 0) requestAnimationFrame(() => attempt(left - 1));
      return;
    }
    if (piece.dataset.landed === '1') return;
    const rect = cell.getBoundingClientRect();
    if (!rect.width) return;
    const center = ghostCenter(point.x, point.y, rect.width, pointerType);
    const { dx, dy } = offsetFromPoint(rect, center);
    piece.dataset.landed = '1';
    if (Math.abs(dx) < 1.5 && Math.abs(dy) < 1.5) return;
    cell.classList.add('sliding');
    piece.classList.add('is-landing');
    onStart?.(cell, piece);
    const animation = piece.animate(
      [
        { translate: `${dx.toFixed(1)}px ${dy.toFixed(1)}px`, scale: String(DRAG_SCALE) },
        { translate: '0px 0px', scale: '1' }
      ],
      { duration: landDurationMs(dx, dy, rect.width), easing: LAND_EASING, fill: 'none' }
    );
    const done = () => { cell.classList.remove('sliding'); piece.classList.remove('is-landing'); delete piece.dataset.landed; };
    animation.addEventListener('finish', done);
    animation.addEventListener('cancel', done);
  };
  attempt(tries);
}

/** Glide a ghost back to the centre of `targetRect`, then remove it. */
export function returnGhost(ghost, targetRect, { pointerType = 'touch', offsetLeft = 0, offsetTop = 0, onDone } = {}) {
  const finish = () => { ghost?.remove(); onDone?.(); };
  if (!ghost || !targetRect || reducedMotion() || typeof ghost.animate !== 'function') { finish(); return; }
  const size = targetRect.width;
  const cx = targetRect.left + size / 2 - offsetLeft;
  const cy = targetRect.top + size / 2 - offsetTop;
  const lift = liftFor(pointerType);
  const from = ghost.style.transform;
  // Ghost is centred horizontally on x and `lift` of its height above y. Aim its centre at the square.
  const to = `translate3d(${cx.toFixed(1)}px,${(cy + (lift - 0.5) * size).toFixed(1)}px,0) translate(-50%,-${(lift * 100).toFixed(0)}%) scale(1)`;
  const animation = ghost.animate([{ transform: from }, { transform: to }], { duration: 150, easing: LAND_EASING, fill: 'forwards' });
  animation.addEventListener('finish', finish);
  animation.addEventListener('cancel', finish);
}
