// Giấy phép thi đấu: người chơi đăng ký, admin duyệt. Chỉ tài khoản đã được admin chứng nhận
// ("approved") mới xuất hiện trên bảng xếp hạng. Module thuần (không I/O) — dùng chung cho
// Worker Cloudflare, máy chủ Node tự chạy và giao diện.

export const LICENSE_STATUSES = Object.freeze(['none', 'pending', 'approved', 'rejected', 'revoked']);
export const LICENSE_DECISIONS = Object.freeze(['approve', 'reject', 'revoke']);
export const LICENSE_LABELS = Object.freeze({
  none: 'Chưa đăng ký',
  pending: 'Đang chờ admin duyệt',
  approved: 'Đã được cấp phép',
  rejected: 'Bị từ chối',
  revoked: 'Đã bị thu hồi'
});

const text = (value, max) => typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max) : '';
const CODE_RE = /^[\p{L}\p{N}][\p{L}\p{N} ._\/-]{1,38}[\p{L}\p{N}]$/u;

/** Always returns a complete, safe license object (also for legacy users that have none). */
export function normalizeLicense(raw) {
  const value = raw && typeof raw === 'object' ? raw : {};
  const status = LICENSE_STATUSES.includes(value.status) ? value.status : 'none';
  return {
    status,
    holderName: text(value.holderName, 60),
    licenseCode: text(value.licenseCode, 40),
    note: text(value.note, 300),
    submittedAt: typeof value.submittedAt === 'string' ? value.submittedAt : null,
    decidedAt: typeof value.decidedAt === 'string' ? value.decidedAt : null,
    decidedBy: typeof value.decidedBy === 'string' ? value.decidedBy : '',
    reason: text(value.reason, 200)
  };
}

/** True only when an admin has approved the license and the account is not banned. */
export function isLicensed(user) {
  return Boolean(user && !user.banned && normalizeLicense(user.license).status === 'approved');
}

/** Validates what the player typed. Never asks for ID/card numbers — only the permit code issued by the organiser. */
export function validateLicenseSubmission(body) {
  const holderName = text(body?.holderName, 60);
  const licenseCode = text(body?.licenseCode, 40);
  const note = text(body?.note, 300);
  if (holderName.length < 2) return { ok: false, error: 'Nhập họ tên người giữ giấy phép (ít nhất 2 ký tự).' };
  if (!CODE_RE.test(licenseCode)) return { ok: false, error: 'Mã giấy phép / chứng nhận dài 3–40 ký tự (chữ, số, dấu . _ - /).' };
  return { ok: true, value: { holderName, licenseCode, note } };
}

/** Player submits (or re-submits after a rejection/revocation). Returns { ok, license } or { ok:false, error, status }. */
export function submitLicense(user, body, nowIso = new Date().toISOString()) {
  const current = normalizeLicense(user?.license);
  if (current.status === 'pending') return { ok: false, status: 409, error: 'Hồ sơ giấy phép của bạn đang chờ admin duyệt.' };
  if (current.status === 'approved') return { ok: false, status: 409, error: 'Tài khoản đã được cấp giấy phép.' };
  const checked = validateLicenseSubmission(body);
  if (!checked.ok) return { ok: false, status: 400, error: checked.error };
  user.license = { ...checked.value, status: 'pending', submittedAt: nowIso, decidedAt: null, decidedBy: '', reason: '' };
  return { ok: true, license: normalizeLicense(user.license) };
}

/** Admin decision. approve/reject need a pending file; revoke needs an approved one. */
export function decideLicense(user, decision, adminId, reason = '', nowIso = new Date().toISOString()) {
  if (!LICENSE_DECISIONS.includes(decision)) return { ok: false, status: 400, error: 'Quyết định không hợp lệ.' };
  const current = normalizeLicense(user?.license);
  if (decision === 'revoke') {
    if (current.status !== 'approved') return { ok: false, status: 409, error: 'Chỉ thu hồi được giấy phép đã duyệt.' };
  } else if (current.status !== 'pending') {
    return { ok: false, status: 409, error: 'Hồ sơ này không ở trạng thái chờ duyệt.' };
  }
  const status = decision === 'approve' ? 'approved' : decision === 'reject' ? 'rejected' : 'revoked';
  user.license = { ...current, status, decidedAt: nowIso, decidedBy: String(adminId || ''), reason: text(reason, 200) };
  return { ok: true, license: normalizeLicense(user.license) };
}
