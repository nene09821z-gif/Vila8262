/**
 * Review insights (pure functions, no DOM): everything the "Điểm nhấn" page and the move-page tools need.
 *  - buildKeyMoments: the few plies that decided the game (mistakes, brilliant finds, the turning point)
 *  - buildNarrative: a short Vietnamese story of the game built from the evaluation curve
 *  - estimatePerformanceElo: rough rating implied by an accuracy percentage (a reference, not a measurement)
 *  - findAdjacentKeyPly: jump to the previous / next serious mistake
 *  - engineLineFens: replay an engine line from a position (chess rules injected, so it is testable)
 *  - buildAnnotatedPgn: PGN with NAGs, [%eval] and comments for sharing or opening in other tools
 * Rows are the objects produced by the full-game review (ply, mover, san, judgement, scoreWhiteCp, ...).
 */
import { winChance } from './game-review.js';

const NEGATIVE = new Set(['inaccuracy', 'mistake', 'missed-win', 'blunder']);
export const SERIOUS_KEYS = Object.freeze(['mistake', 'missed-win', 'blunder']);
const sideName = mover => (mover === 'b' ? 'Đen' : 'Trắng');
const finite = value => Number.isFinite(Number(value)) && value !== null && value !== '';

/** Win chance (0–100) of the side that just moved, before and after its move. */
function moverWin(row) {
  if (!finite(row?.scoreBeforeWhiteCp) || !finite(row?.scoreWhiteCp)) return null;
  const sign = row.mover === 'b' ? -1 : 1;
  return { before: winChance(sign * Number(row.scoreBeforeWhiteCp)), after: winChance(sign * Number(row.scoreWhiteCp)) };
}
const usable = rows => (Array.isArray(rows) ? rows : []).filter(row => row && row.ply > 0 && row.san && (row.mover === 'w' || row.mover === 'b')).sort((a, b) => a.ply - b.ply);
const moveLabel = row => `${Math.ceil(row.ply / 2)}${row.mover === 'b' ? '...' : '.'} ${row.san}`;

/**
 * @returns {Array<{ply:number, moveNumber:number, mover:'w'|'b', san:string, kind:string, swingPct:number, beforePct:number, afterPct:number, severity:number, bestSan:string, label:string, turning:boolean}>}
 */
export function buildKeyMoments(rows, { limit = 6, minSwing = 8 } = {}) {
  const list = usable(rows);
  const items = [];
  for (const row of list) {
    const win = moverWin(row);
    if (!win) continue;
    const swing = win.before - win.after; // > 0 = the mover lost chances
    const key = row.judgement?.key || '';
    let kind = '';
    if (key === 'blunder') kind = 'blunder';
    else if (key === 'mistake') kind = 'mistake';
    else if (key === 'missed-win') kind = 'missed';
    else if (key === 'brilliant') kind = 'brilliant';
    else if (key === 'great') kind = 'great';
    if (NEGATIVE.has(key) && key !== 'inaccuracy' && swing < minSwing) kind = '';
    // Turning point: the evaluation changes sides in one move.
    const whiteBefore = winChance(row.scoreBeforeWhiteCp), whiteAfter = winChance(row.scoreWhiteCp);
    const flips = (whiteBefore >= 56 && whiteAfter <= 44) || (whiteBefore <= 44 && whiteAfter >= 56);
    items.push({ row, win, swing, kind, flips, flipSize: Math.abs(whiteAfter - whiteBefore) });
  }
  const chosen = new Map();
  const negatives = items.filter(item => ['blunder', 'mistake', 'missed'].includes(item.kind)).sort((a, b) => b.swing - a.swing).slice(0, 4);
  for (const item of negatives) chosen.set(item.row.ply, item);
  const positives = items.filter(item => ['brilliant', 'great'].includes(item.kind))
    .sort((a, b) => (a.kind === b.kind ? (b.win.after - b.win.before) - (a.win.after - a.win.before) : a.kind === 'brilliant' ? -1 : 1)).slice(0, 2);
  for (const item of positives) chosen.set(item.row.ply, item);
  const turn = items.filter(item => item.flips).sort((a, b) => b.flipSize - a.flipSize)[0];
  if (turn) chosen.set(turn.row.ply, { ...(chosen.get(turn.row.ply) || turn), turning: true });
  const out = [...chosen.values()].map(item => {
    const { row, win, swing } = item;
    const kind = item.kind || 'turning';
    const label = { blunder: 'Sai lầm nghiêm trọng', mistake: 'Sai lầm', missed: 'Bỏ lỡ cơ hội thắng', brilliant: 'Nước thiên tài', great: 'Nước tuyệt vời', turning: 'Bước ngoặt' }[kind];
    return {
      ply: row.ply, moveNumber: Math.ceil(row.ply / 2), mover: row.mover, san: row.san, kind, label,
      swingPct: Math.round(swing * 10) / 10, beforePct: Math.round(win.before), afterPct: Math.round(win.after),
      severity: Math.max(0.06, Math.min(1, Math.abs(swing) / 60)), bestSan: row.moveWasBest ? '' : String(row.bestMoveSan || ''), turning: Boolean(item.turning)
    };
  }).sort((a, b) => a.ply - b.ply);
  // Keep the most important when over the limit: negatives by swing, then positives, then the turning point.
  if (out.length <= limit) return out;
  const rank = m => (m.turning ? 3000 : 0) + (['blunder', 'mistake', 'missed'].includes(m.kind) ? 1000 + m.swingPct : m.kind === 'brilliant' ? 900 : 800);
  return out.sort((a, b) => rank(b) - rank(a)).slice(0, limit).sort((a, b) => a.ply - b.ply);
}

const ELO_TABLE = [[0, 250], [30, 400], [45, 650], [55, 850], [65, 1100], [72, 1350], [78, 1600], [84, 1850], [89, 2100], [93, 2350], [96.5, 2600], [100, 2850]];
/** Rough rating implied by an accuracy percentage. Only a reference: the mapping is a smooth curve, not a measurement. */
export function estimatePerformanceElo(accuracy, moves = 0) {
  const value = Number(accuracy);
  if (!Number.isFinite(value) || (moves && moves < 8)) return null;
  const x = Math.max(0, Math.min(100, value));
  for (let i = 1; i < ELO_TABLE.length; i += 1) {
    const [x1, y1] = ELO_TABLE[i];
    if (x <= x1) { const [x0, y0] = ELO_TABLE[i - 1]; return Math.round((y0 + (y1 - y0) * (x - x0) / (x1 - x0)) / 25) * 25; }
  }
  return ELO_TABLE[ELO_TABLE.length - 1][1];
}

/**
 * Short story of the game. Returns [{tone:'info'|'good'|'warn', icon:string, text:string}].
 * @param {{opening?:string, result?:string, names?:{w:string,b:string}}} meta
 */
export function buildNarrative(rows, meta = {}) {
  const list = usable(rows).filter(row => finite(row.scoreWhiteCp));
  const names = meta.names || { w: 'Trắng', b: 'Đen' };
  const out = [];
  if (list.length < 6) return out;
  if (meta.opening) out.push({ tone: 'info', icon: '📖', text: `Khai cuộc: ${meta.opening}.` });

  const series = list.map(row => winChance(row.scoreWhiteCp));
  const whiteLead = series.filter(v => v >= 60).length / series.length;
  const blackLead = series.filter(v => v <= 40).length / series.length;
  const pct = v => `${Math.round(v * 100)}%`;
  if (whiteLead >= 0.5) out.push({ tone: 'info', icon: '⚖', text: `${names.w} (Trắng) giữ lợi thế rõ ràng trong ${pct(whiteLead)} số nước của ván.` });
  else if (blackLead >= 0.5) out.push({ tone: 'info', icon: '⚖', text: `${names.b} (Đen) giữ lợi thế rõ ràng trong ${pct(blackLead)} số nước của ván.` });
  else out.push({ tone: 'info', icon: '⚖', text: `Hai bên giằng co khá cân bằng: Trắng hơn ${pct(whiteLead)}, Đen hơn ${pct(blackLead)} số nước.` });

  const moments = buildKeyMoments(rows, { limit: 12 });
  const turning = moments.find(m => m.turning);
  if (turning) {
    const who = turning.mover === 'b' ? names.b : names.w;
    out.push({ tone: 'warn', icon: '↯', text: `Bước ngoặt ở nước ${moveLabel({ ply: turning.ply, mover: turning.mover, san: turning.san })} của ${who}: thế cờ đổi chiều khi cơ hội thắng của người đi nước này đi từ ${turning.beforePct}% xuống ${turning.afterPct}%.` });
  }
  for (const side of ['w', 'b']) {
    const worst = moments.filter(m => m.mover === side && ['blunder', 'mistake', 'missed'].includes(m.kind)).sort((a, b) => b.swingPct - a.swingPct)[0];
    if (worst) {
      const who = side === 'b' ? names.b : names.w;
      out.push({ tone: 'warn', icon: '⚠', text: `Sai lầm lớn nhất của ${who}: ${moveLabel({ ply: worst.ply, mover: side, san: worst.san })}, mất ${Math.round(worst.swingPct)}% cơ hội thắng${worst.bestSan ? `. Nước tốt hơn: ${worst.bestSan}` : ''}.` });
    }
  }
  const star = moments.filter(m => m.kind === 'brilliant' || m.kind === 'great').sort((a, b) => (a.kind === 'brilliant' ? 0 : 1) - (b.kind === 'brilliant' ? 0 : 1))[0];
  if (star) {
    const who = star.mover === 'b' ? names.b : names.w;
    out.push({ tone: 'good', icon: '✦', text: `Điểm sáng: ${who} có ${star.kind === 'brilliant' ? 'nước thiên tài' : 'nước tuyệt vời'} ${moveLabel({ ply: star.ply, mover: star.mover, san: star.san })}.` });
  }
  const bad = side => list.filter(row => row.mover === side && ['mistake', 'blunder', 'missed-win'].includes(row.judgement?.key)).length;
  if (!bad('w') && !bad('b')) out.push({ tone: 'good', icon: '✔', text: 'Không có sai lầm nặng nào từ cả hai bên, một ván đánh rất sạch.' });
  const token = meta.result;
  if (token === '1-0') out.push({ tone: 'info', icon: '🏁', text: `Kết quả: ${names.w} (Trắng) thắng.` });
  else if (token === '0-1') out.push({ tone: 'info', icon: '🏁', text: `Kết quả: ${names.b} (Đen) thắng.` });
  else if (token === '1/2-1/2') out.push({ tone: 'info', icon: '🏁', text: 'Kết quả: hòa.' });
  return out;
}

/** Previous/next ply (by the mover filter) whose move was a serious mistake. Returns null when there is none. */
export function findAdjacentKeyPly(rows, currentPly, direction = 1, { keys = SERIOUS_KEYS, side = '' } = {}) {
  const wanted = new Set(keys);
  const plies = usable(rows).filter(row => wanted.has(row.judgement?.key) && (!side || row.mover === side)).map(row => row.ply);
  const now = Number(currentPly) || 0;
  if (direction >= 0) return plies.find(ply => ply > now) ?? null;
  return [...plies].reverse().find(ply => ply < now) ?? null;
}

/**
 * Replay an engine line. `ChessClass` is chess.js-compatible (constructor(fen), move({from,to,promotion}), fen()).
 * @returns {Array<{fen:string, san:string, uci:string, from:string, to:string}>} entry i is the position after move i
 */
export function engineLineFens(startFen, ucis, ChessClass) {
  const out = [];
  if (!startFen || !Array.isArray(ucis) || typeof ChessClass !== 'function') return out;
  let board;
  try { board = new ChessClass(startFen); } catch { return out; }
  for (const uci of ucis.slice(0, 12)) {
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(String(uci))) break;
    let made = null;
    try { made = board.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {}) }); } catch { made = null; }
    if (!made) break;
    out.push({ fen: board.fen(), san: made.san, uci, from: made.from || uci.slice(0, 2), to: made.to || uci.slice(2, 4) });
  }
  return out;
}

const NAG = { brilliant: 3, great: 1, inaccuracy: 6, mistake: 2, 'missed-win': 2, blunder: 4 };
const cleanComment = text => String(text || '').replace(/[{}\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
const headerValue = text => String(text ?? '?').replace(/[\\"\r\n]/g, ch => (ch === '"' || ch === '\\' ? `\\${ch}` : ' '));
function evalTag(row) {
  if (!finite(row.scoreWhiteCp)) return '';
  if (row.scoreType === 'mate' || Math.abs(Number(row.scoreWhiteCp)) >= 9900) {
    const n = finite(row.mateWhite) ? Math.abs(Number(row.mateWhite)) : 0;
    return `[%eval #${Number(row.scoreWhiteCp) < 0 ? '-' : ''}${n}]`;
  }
  return `[%eval ${(Number(row.scoreWhiteCp) / 100).toFixed(2)}]`;
}

/**
 * PGN with Stockfish annotations. Moves come from the reviewed rows (must start at ply 1 and be contiguous).
 * @param {{headers?:Record<string,string>, startFen?:string, result?:string}} options
 */
export function buildAnnotatedPgn(rows, { headers = {}, startFen = '', result = '*' } = {}) {
  const list = usable(rows);
  const moves = [];
  for (const row of list) { if (row.ply !== moves.length + 1) break; moves.push(row); }
  const token = ['1-0', '0-1', '1/2-1/2', '*'].includes(result) ? result : '*';
  const base = { Event: 'ViLa Chess', Site: 'ViLa Chess', Date: new Date().toISOString().slice(0, 10).replace(/-/g, '.'), Round: '-', White: 'Trắng', Black: 'Đen', ...headers, Result: token };
  const standard = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  const head = Object.entries(base).map(([k, v]) => `[${k.replace(/[^A-Za-z0-9_]/g, '')} "${headerValue(v)}"]`);
  if (startFen && startFen !== standard) head.push('[SetUp "1"]', `[FEN "${headerValue(startFen)}"]`);
  head.push('[Annotator "ViLa Chess · Stockfish"]');
  const parts = moves.map(row => {
    const number = row.mover === 'b' ? `${Math.ceil(row.ply / 2)}...` : `${Math.ceil(row.ply / 2)}.`;
    const nag = NAG[row.judgement?.key] ? ` $${NAG[row.judgement.key]}` : '';
    const notes = [];
    const tag = evalTag(row); if (tag) notes.push(tag);
    if (row.judgement?.label && NEGATIVE.has(row.judgement.key)) notes.push(cleanComment(row.judgement.label));
    if (!row.moveWasBest && row.bestMoveSan && NEGATIVE.has(row.judgement?.key)) notes.push(`Nên đi: ${cleanComment(row.bestMoveSan)}`);
    if (row.judgement?.key === 'brilliant') notes.push('Nước thiên tài');
    return `${number} ${row.san}${nag}${notes.length ? ` { ${notes.join(' · ')} }` : ''}`;
  });
  const body = parts.join(' ');
  // wrap at ~80 columns without splitting a comment's braces across lines unpredictably
  const wrapped = body.replace(/(.{1,78})(\s+|$)/g, '$1\n').trim();
  return `${head.join('\n')}\n\n${wrapped}${wrapped ? ' ' : ''}${token}\n`;
}
