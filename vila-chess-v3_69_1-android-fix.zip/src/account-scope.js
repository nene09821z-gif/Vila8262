/**
 * Per-account storage scope (v3.69).
 *
 * Before this version, every account that signed in on the same browser/phone shared ONE set of localStorage
 * keys, so games, Elo, puzzle progress, notifications and even the plan entitlement of account A showed up
 * under account B — and "cloud sync" then uploaded A's games to B's server history.
 *
 * Every per-person key is now stored as `<base key>::acct:<scope>` where scope is `u-<userId>` for a signed-in
 * account and `guest` when nobody is signed in. Pure helpers only (no DOM, no globals) so they are unit-tested.
 */
export const GUEST_SCOPE = 'guest';
export const SCOPE_SEPARATOR = '::acct:';
export const SCOPE_MIGRATION_FLAG = 'vila.chess.account-scope-migrated.v1';

/** Base keys whose value belongs to one person. Anything NOT listed here stays device-wide (settings, theme, music…). */
export const ACCOUNT_SCOPED_KEYS = Object.freeze([
  'vila.chess.saved-games.v1',
  'vila.chess.local-game-recovery.v1',
  'chessbot.local.rating.v1',
  'chessbot.local.rating.history.v1',
  'vila.chess.entitlement.v1',
  'vila.chess.daily-progress.v1',
  'vila.chess.lifetime.v1',
  'vila.chess.lesson-progress.v1',
  'vila.chess.notifications.v1',
  'vila.chess.mistake-training.v1',
  'vila.chess.puzzles.history.v1',
  'vila.chess.puzzles.training.v1',
  'vila.chess.puzzles.rating.v1',
  'vila.chess.puzzles.freeUsed.v1',
  'vila.chess.puzzles.rush-best.v1',
  'vila.chess.puzzles.daily-solved-date.v1',
  'vila.chess.puzzles.solved.v1',
  'vila.chess.puzzles.streak.v1',
  'vila.chess.puzzles.bestStreak.v1'
]);

/** `u-<id>` for a signed-in user, `guest` otherwise. The id is sanitised so it can never break out of the key. */
export function accountScopeOf(user) {
  const id = String(user?.id ?? '').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 64);
  return id ? `u-${id}` : GUEST_SCOPE;
}

export function scopedKey(base, scope = GUEST_SCOPE) {
  return `${base}${SCOPE_SEPARATOR}${scope || GUEST_SCOPE}`;
}

/**
 * localStorage-shaped view whose keys are re-scoped on every call, so a long-lived reference keeps following
 * the signed-in account. Modules that accept a `storage` argument can be handed this object unchanged.
 */
export function createScopedStorage(storage, getScope) {
  const real = () => storage ?? globalThis.localStorage;
  const key = base => scopedKey(base, getScope());
  return {
    getItem: base => real().getItem(key(base)),
    setItem: (base, value) => real().setItem(key(base), value),
    removeItem: base => real().removeItem(key(base))
  };
}

/** Keep only records that belong to `scope` (records saved before v3.69 carry no owner and are kept). */
export function filterOwnedRecords(records, scope) {
  if (!Array.isArray(records)) return [];
  return records.filter(item => item && (!item.owner || item.owner === scope));
}

/** Merge cloud games into the local list: de-duplicate by signature, newest first, owner-checked, capped. */
export function mergeAccountGames(local, remote, scope, limit = 100) {
  const seen = new Set();
  const out = [];
  for (const item of [...filterOwnedRecords(local, scope), ...filterOwnedRecords(remote, scope)]) {
    if (!item || !item.id || !item.pgn || !item.signature || seen.has(item.signature)) continue;
    seen.add(item.signature);
    out.push({ ...item, owner: scope });
  }
  out.sort((a, b) => (Date.parse(b.date) || 0) - (Date.parse(a.date) || 0));
  return out.slice(0, limit);
}

/**
 * One-time move of the old shared keys into the scope of whoever owned the device when the update installed.
 * `ownerScope` is the cached signed-in account (or guest). Values already present in the scoped key win, and the
 * legacy key is always removed so it can never leak into another account again.
 */
export function migrateLegacyAccountData(storage, ownerScope, keys = ACCOUNT_SCOPED_KEYS) {
  const moved = [];
  try {
    if (storage.getItem(SCOPE_MIGRATION_FLAG)) return { migrated: false, moved };
    for (const base of keys) {
      const legacy = storage.getItem(base);
      if (legacy == null) continue;
      const target = scopedKey(base, ownerScope);
      if (storage.getItem(target) == null) {
        if (base === 'vila.chess.saved-games.v1') {
          let rows = null;
          try { rows = JSON.parse(legacy); } catch { rows = null; }
          storage.setItem(target, Array.isArray(rows) ? JSON.stringify(rows.map(row => row && typeof row === 'object' ? { owner: ownerScope, ...row } : row)) : legacy);
        } else storage.setItem(target, legacy);
        moved.push(base);
      }
      storage.removeItem(base);
    }
    storage.setItem(SCOPE_MIGRATION_FLAG, ownerScope);
    return { migrated: true, moved };
  } catch {
    return { migrated: false, moved };
  }
}
