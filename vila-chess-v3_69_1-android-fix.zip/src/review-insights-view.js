/** HTML for the review "Điểm nhấn" page and the move-page tools. Pure string builders (no DOM), styled in review-layers.css. */
const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ESC[ch]);

const KIND_META = {
  blunder: { symbol: '??', tone: 'blunder', cls: 'is-bad' },
  mistake: { symbol: '?', tone: 'mistake', cls: 'is-bad' },
  missed: { symbol: '×', tone: 'missed-win', cls: 'is-bad' },
  brilliant: { symbol: '!!', tone: 'brilliant', cls: 'is-good' },
  great: { symbol: '!', tone: 'great', cls: 'is-good' },
  turning: { symbol: '↯', tone: 'turning', cls: 'is-turn' }
};

export function momentCardMarkup(moment) {
  const meta = KIND_META[moment.kind] || KIND_META.turning;
  const sideLabel = moment.mover === 'b' ? 'Đen' : 'Trắng';
  const dots = moment.mover === 'b' ? '...' : '.';
  const good = meta.cls === 'is-good';
  const delta = good
    ? `<span class="rv-moment-delta is-up">Cơ hội thắng ${moment.beforePct}% → ${moment.afterPct}%</span>`
    : `<span class="rv-moment-delta">${moment.swingPct > 0 ? '−' : '+'}${Math.abs(Math.round(moment.swingPct))}% cơ hội thắng · ${moment.beforePct}% → ${moment.afterPct}%</span>`;
  const bar = good ? '' : `<span class="rv-moment-bar" aria-hidden="true"><i style="width:${Math.round(moment.severity * 100)}%"></i></span>`;
  const better = moment.bestSan && !good ? `<span class="rv-moment-better">Nên đi <b>${esc(moment.bestSan)}</b></span>` : '<span class="rv-moment-better"></span>';
  const turning = moment.turning && moment.kind !== 'turning' ? '<em class="rv-moment-flag">Bước ngoặt</em>' : '';
  return `<button type="button" class="rv-moment ${meta.cls}" data-review-jump-ply="${Number(moment.ply)}" style="--rv-c:var(--rv-${meta.tone},#8fc13e)" aria-label="${esc(`${moment.label}, nước ${moment.moveNumber}${dots} ${moment.san} của ${sideLabel}. Bấm để xem trên bàn cờ.`)}">
    <span class="rv-moment-top"><b class="rv-moment-badge" aria-hidden="true">${esc(meta.symbol)}</b><span class="rv-moment-who">${sideLabel} · nước ${moment.moveNumber}</span>${turning}</span>
    <span class="rv-moment-san">${moment.moveNumber}${dots} ${esc(moment.san)}</span>
    <span class="rv-moment-label">${esc(moment.label)}</span>${bar}${delta}${better}
    <span class="rv-moment-go" aria-hidden="true">Xem ›</span></button>`;
}

function performanceChip(side, names, perf) {
  const info = perf[side] || {};
  const elo = info.elo ? `≈ ${info.elo}` : '—';
  const acc = Number.isFinite(info.accuracy) ? `${info.accuracy}%` : '—';
  return `<div class="rv-perf-chip rv-perf-${side}"><span class="rv-perf-name"><i class="rv-chip rv-chip-${side}" aria-hidden="true"></i>${esc(side === 'w' ? names.w : names.b)}</span><b class="rv-perf-elo">${esc(elo)}</b><small>Elo ước tính · chính xác ${esc(acc)}</small></div>`;
}

/**
 * @param {{narrative:Array, perf:{w:object,b:object}, moments:Array, names:{w:string,b:string}, analyzed:boolean, reviewing:boolean}} data
 */
export function insightsMarkup({ narrative = [], perf = {}, moments = [], names = { w: 'Trắng', b: 'Đen' }, analyzed = false, reviewing = false } = {}) {
  if (!analyzed) {
    return `<div class="rv-insights-empty"><b>✦ Điểm nhấn của ván</b><p>${reviewing ? 'Stockfish đang phân tích… tóm tắt, Elo ước tính và các khoảnh khắc then chốt sẽ hiện ở đây ngay khi có đủ dữ liệu.' : 'Chạy “Phân tích toàn ván” để mở khóa tóm tắt thông minh, Elo ước tính từng bên và danh sách khoảnh khắc then chốt (bấm để nhảy tới nước đó).'}</p></div>`;
  }
  const story = narrative.length
    ? `<ul class="rv-story">${narrative.map(line => `<li class="rv-story-${esc(line.tone || 'info')}"><span class="rv-story-icon" aria-hidden="true">${esc(line.icon || '•')}</span><span>${esc(line.text)}</span></li>`).join('')}</ul>`
    : '';
  const perfRow = (perf.w?.elo || perf.b?.elo)
    ? `<div class="rv-perf" aria-label="Elo ước tính theo độ chính xác">${performanceChip('w', names, perf)}${performanceChip('b', names, perf)}</div><p class="rv-note">Elo ước tính chỉ là tham khảo, quy đổi từ độ chính xác của ván này; không phải Elo chính thức.</p>`
    : '';
  const cards = moments.length
    ? `<div class="rv-moments-head"><b>Khoảnh khắc then chốt</b><span>Vuốt ngang ›</span></div><div class="rv-moments" role="list">${moments.map(m => `<div role="listitem">${momentCardMarkup(m)}</div>`).join('')}</div>`
    : '<p class="rv-note">Chưa có khoảnh khắc nào đủ lớn để nêu ra.</p>';
  return `<div class="rv-insights-head"><small class="eyebrow">ĐIỂM NHẤN CỦA VÁN</small></div>${story}${perfRow}${cards}`;
}

/** Tool row on the "Từng nước" page. */
export function reviewToolsMarkup({ canLine = false, lineActive = false, hasRows = false } = {}) {
  const dis = hasRows ? '' : ' disabled';
  return `<div class="rv-tools" role="toolbar" aria-label="Công cụ xem lại">
    <button type="button" class="rv-tool" data-review-jump="prev"${dis} title="Về sai lầm trước đó (phím [)">⏮ Sai lầm trước</button>
    <button type="button" class="rv-tool" data-review-jump="next"${dis} title="Tới sai lầm kế tiếp (phím ])">Sai lầm sau ⏭</button>
    <button type="button" class="rv-tool rv-tool-accent${lineActive ? ' is-on' : ''}" data-review-line="toggle" ${canLine ? '' : 'disabled'} aria-pressed="${lineActive}" title="Chạy biến tốt nhất của Stockfish ngay trên bàn cờ">${lineActive ? '■ Thoát biến' : '▶ Chạy biến engine'}</button>
    <button type="button" class="rv-tool" data-review-export="copy"${dis}>Sao chép PGN + đánh giá</button>
    <button type="button" class="rv-tool" data-review-export="download"${dis}>⭳ Tải PGN + đánh giá</button></div>`;
}

/** Banner above the board while an engine line is being previewed. */
export function lineBannerMarkup(line) {
  if (!line) return '';
  const total = line.steps.length;
  const shown = line.steps.slice(0, line.index).map((s, i) => `<span class="${i === line.index - 1 ? 'is-now' : ''}">${esc(s.san)}</span>`).join(' ');
  return `<div class="rv-line-banner" role="status"><span class="rv-line-title">Biến Stockfish từ nước ${esc(line.label)}</span><span class="rv-line-moves">${shown || '<span>Thế cờ trước nước đi</span>'}</span><span class="rv-line-ctl"><button type="button" data-review-line="prev" aria-label="Lùi một nước trong biến"${line.index <= 0 ? ' disabled' : ''}>‹</button><button type="button" data-review-line="play" aria-label="${line.playing ? 'Tạm dừng' : 'Tự chạy biến'}">${line.playing ? '⏸' : '▶'}</button><button type="button" data-review-line="next" aria-label="Tiến một nước trong biến"${line.index >= total ? ' disabled' : ''}>›</button><em>${line.index}/${total}</em></span></div>`;
}
