import { chooseAlternateMove, analyzeAlternateMove } from './alternate-engine-core.js';
import { chooseLc0Move, getLastLc0Stats, isLc0Profile, preloadLc0 } from './lc0/lc0-client.js';
export { isLc0Profile, preloadLc0, importCustomLc0Net, customLc0NetName, removeCustomLc0Net, lc0Status, stopLc0 } from './lc0/lc0-client.js';
import { importCustomLc0Net, customLc0NetName, removeCustomLc0Net, lc0Status, stopLc0 } from './lc0/lc0-client.js';
export { ALTERNATE_ENGINE_PROFILES, OFFLINE_ENGINE_CATALOG, OFFLINE_ENGINE_IDS, offlineEngineShortName, chooseAlternateMove, analyzeAlternateMove } from './alternate-engine-core.js';


let offlineWorker = null;
let offlineRequestSequence = 0;
let lastOfflineStats = null;
/** Depth / nodes / speed of the most recent offline search, for the speed chip. */
export function getLastOfflineEngineStats() {
  const neural = getLastLc0Stats();
  return neural && (!lastOfflineStats || neural.at >= lastOfflineStats.at) ? neural : lastOfflineStats;
}
const offlineRequests = new Map();

function runOfflineSync(fen, options) {
  const result = analyzeAlternateMove(fen, options);
  if (result) lastOfflineStats = { depth: result.depth, nodes: result.nodes, elapsedMs: result.elapsedMs, nps: result.nps, score: result.score, at: Date.now() };
  return result?.uci || null;
}

function resolveOfflineFallback(pending) {
  // Do not turn a missing/failed Worker into a multi-second UI-thread search on Android.
  // This emergency path is intentionally shallow; the normal path uses the full worker search.
  try {
    pending.resolve(runOfflineSync(pending.fen, {
      ...pending.options,
      depth: Math.min(3, Number(pending.options?.depth) || 3),
      maxNodes: Math.min(10000, Number(pending.options?.maxNodes) || 10000),
      maxTimeMs: Math.min(100, Number(pending.options?.maxTimeMs) || 100)
    }));
  } catch (error) { pending.reject(error); }
}

/** Retire a failed or wedged worker so queued requests never remain stuck behind it. */
function retireOfflineWorker(worker) {
  try { worker?.terminate(); } catch { /* worker may already have stopped */ }
  if (offlineWorker === worker) offlineWorker = null;
  for (const [id, pending] of offlineRequests) {
    offlineRequests.delete(id);
    clearTimeout(pending.timeout);
    resolveOfflineFallback(pending);
  }
}

function createOfflineWorker() {
  if (typeof Worker === 'undefined') return null;
  try {
    const worker = new Worker(new URL('./alternate-engine-worker.js', import.meta.url), { type: 'module' });
    worker.addEventListener('message', event => {
      const data = event.data || {};
      const pending = offlineRequests.get(data.id);
      if (!pending) return;
      offlineRequests.delete(data.id);
      clearTimeout(pending.timeout);
      if (data.error) pending.reject(new Error(data.error));
      else {
        if (data.stats) lastOfflineStats = { ...data.stats, at: Date.now() };
        pending.resolve(data.uci || null);
      }
    });
    worker.addEventListener('error', () => retireOfflineWorker(worker));
    return worker;
  } catch {
    return null;
  }
}

/** Prefer a module worker so deeper searches do not freeze the board animation. */
export async function chooseAlternateMoveAsync(fen, options = {}) {
  const requested = String(options.profile || options.engine || '');
  if (isLc0Profile(requested)) {
    // Real Lc0 neural net in its own worker; any failure falls back to the classical Leela-style engine below.
    const uci = await chooseLc0Move(requested, fen, options);
    if (uci) return uci;
    options = { ...options, profile: 'lc0', engine: 'lc0' };
  }
  return chooseClassicAlternateMoveAsync(fen, options);
}

function chooseClassicAlternateMoveAsync(fen, options = {}) {
  const worker = offlineWorker || (offlineWorker = createOfflineWorker());
  if (!worker) {
    try {
      // Worker creation can be blocked in a restricted WebView; keep the last-resort
      // synchronous calculation short so moving a piece never freezes the entire screen.
      return Promise.resolve(runOfflineSync(fen, {
        ...options,
        depth: Math.min(3, Number(options?.depth) || 3),
        maxNodes: Math.min(10000, Number(options?.maxNodes) || 10000),
        maxTimeMs: Math.min(100, Number(options?.maxTimeMs) || 100)
      }));
    } catch (error) { return Promise.reject(error); }
  }
  const id = ++offlineRequestSequence;
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (!offlineRequests.has(id)) return;
      // The worker runs synchronous search code; a timed-out search can otherwise
      // block every later request. Terminate it and return bounded shallow fallbacks.
      retireOfflineWorker(worker);
    }, Math.max(4000, Math.min(10000, Number(options.maxTimeMs || 1000) + 3500)));
    offlineRequests.set(id, { resolve, reject, timeout, fen, options });
    try { worker.postMessage({ id, fen, options }); }
    catch (error) {
      offlineRequests.delete(id);
      clearTimeout(timeout);
      reject(error);
    }
  });
}
