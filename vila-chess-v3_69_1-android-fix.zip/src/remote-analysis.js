/**
 * Client for the private VILA analysis server (analysis-server/).
 * Pure helpers + fetch wrappers with injected fetch so they can be unit-tested without a DOM.
 * The server returns raw UCI scores; the app keeps its own move-classification algorithm
 * (src/game-review.js), so labels stay identical whether Stockfish runs on the phone or on the server.
 */

const PRIVATE_HOST = /^(?:localhost|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|[a-z0-9-]+\.local)$/i;
export const REMOTE_QUALITIES = Object.freeze({ fast: 'fast', standard: 'standard', deep: 'deep', max: 'max' });

/** Accepts https:// URLs; plain http:// only for localhost / LAN / *.local. Returns '' when unusable. */
export function normalizeAnalysisServerUrl(text) {
  const raw = String(text || '').trim();
  if (!raw || raw.length > 300) return '';
  try {
    const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
    if (url.username || url.password) return '';
    if (url.protocol === 'http:' && !PRIVATE_HOST.test(url.hostname)) return '';
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return '';
    return `${url.protocol}//${url.host}`;
  } catch { return ''; }
}

export function remoteAnalysisConfigured(settings) {
  return Boolean(settings?.analysisServerEnabled && normalizeAnalysisServerUrl(settings.analysisServerUrl) && String(settings.analysisServerKey || '').length >= 16);
}

const authHeaders = key => ({ Authorization: `Bearer ${String(key).trim()}` });

function withTimeout(signal, ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  const relay = () => controller.abort();
  signal?.addEventListener?.('abort', relay, { once: true });
  return { signal: controller.signal, done() { clearTimeout(timer); signal?.removeEventListener?.('abort', relay); } };
}

/** GET /health (public) then a tiny authenticated request so a wrong key is reported immediately. */
export async function checkAnalysisServer({ url, key, fetchImpl = globalThis.fetch, timeoutMs = 6000 } = {}) {
  const base = normalizeAnalysisServerUrl(url);
  if (!base) return { ok: false, reason: 'Địa chỉ máy chủ không hợp lệ (cần https://…).' };
  const guard = withTimeout(null, timeoutMs);
  try {
    const health = await fetchImpl(`${base}/health`, { cache: 'no-store', signal: guard.signal });
    if (!health.ok) return { ok: false, reason: `Máy chủ trả về HTTP ${health.status}.` };
    const info = await health.json();
    if (!info?.ok) return { ok: false, reason: 'Phản hồi /health không hợp lệ.' };
    const probe = await fetchImpl(`${base}/v1/analyze`, {
      method: 'POST', cache: 'no-store', signal: guard.signal,
      headers: { 'Content-Type': 'application/json', ...authHeaders(key) },
      body: JSON.stringify({ fen: '4k3/8/8/8/8/8/8/4K3 w - - 0 1', nodes: 10000 }),
    });
    if (probe.status === 401) return { ok: false, reason: 'Khóa truy cập không đúng.' };
    if (probe.status === 429) return { ok: true, info, note: 'Máy chủ đang giới hạn tốc độ.' };
    if (!probe.ok) return { ok: false, reason: `Phân tích thử lỗi HTTP ${probe.status}.` };
    return { ok: true, info };
  } catch (error) {
    return { ok: false, reason: error?.name === 'AbortError' ? 'Máy chủ không phản hồi kịp.' : 'Không kết nối được máy chủ.' };
  } finally { guard.done(); }
}

/** Parse NDJSON text (or a chunk buffer) into objects; ignores blank/garbled lines. */
export function parseNdjson(text) {
  const out = [];
  for (const line of String(text || '').split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try { out.push(JSON.parse(trimmed)); } catch { /* partial line from an interrupted stream */ }
  }
  return out;
}

/** Convert server lines to UCI `info` strings so the app's existing receiveReviewInfo() code can consume them. */
export function remoteLinesToUciInfo(lines) {
  return (Array.isArray(lines) ? lines : []).filter(line => line && Number.isFinite(line.depth) && Number.isFinite(line.score) && ['cp', 'mate'].includes(line.scoreType) && Array.isArray(line.pv) && line.pv.length)
    .map(line => `info depth ${line.depth} multipv ${line.multipv || 1} score ${line.scoreType} ${Math.round(line.score)} nodes ${line.nodes || 0} pv ${line.pv.join(' ')}`);
}

/**
 * Stream a full-game review. `positions` = [{ fen, light? }]. Results arrive out of order:
 * onResult(index, { bestmove, lines, cached }) is called per position, onProgress(done, total) as they complete.
 * Resolves with { total, failed, cached, elapsedMs }.
 */
export async function remoteReviewPositions({ url, key, positions, quality = 'standard', fetchImpl = globalThis.fetch, onResult, onProgress, signal, idleTimeoutMs = 60000 }) {
  const base = normalizeAnalysisServerUrl(url);
  if (!base) throw new Error('Địa chỉ máy chủ phân tích không hợp lệ.');
  const idle = { timer: null };
  const controller = new AbortController();
  const relay = () => controller.abort();
  signal?.addEventListener?.('abort', relay, { once: true });
  const arm = () => { clearTimeout(idle.timer); idle.timer = setTimeout(() => controller.abort(), idleTimeoutMs); };
  arm();
  let summary = null;
  const handle = event => {
    if (event.type === 'position' && Number.isInteger(event.index)) { if (!event.error) onResult?.(event.index, { bestmove: event.bestmove || null, lines: event.lines || [], cached: Boolean(event.cached) }); }
    else if (event.type === 'progress') onProgress?.(event.done, event.total);
    else if (event.type === 'done') summary = event;
  };
  try {
    const response = await fetchImpl(`${base}/v1/review`, {
      method: 'POST', cache: 'no-store', signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...authHeaders(key) },
      body: JSON.stringify({ positions: positions.map(p => ({ fen: p.fen, ...(p.light ? { light: true } : {}) })), quality: REMOTE_QUALITIES[quality] || 'standard' }),
    });
    if (response.status === 401) throw new Error('Khóa truy cập máy chủ phân tích không đúng.');
    if (response.status === 429 || response.status === 503) throw new Error('Máy chủ phân tích đang bận; thử lại sau ít phút.');
    if (!response.ok) throw new Error(`Máy chủ phân tích trả về HTTP ${response.status}.`);
    const reader = response.body?.getReader?.();
    if (reader) {
      const decoder = new TextDecoder();
      let buffer = '';
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        arm();
        buffer += decoder.decode(value, { stream: true });
        const cut = buffer.lastIndexOf('\n');
        if (cut >= 0) { parseNdjson(buffer.slice(0, cut)).forEach(handle); buffer = buffer.slice(cut + 1); }
      }
      parseNdjson(buffer).forEach(handle);
    } else {
      parseNdjson(await response.text()).forEach(handle);
    }
  } catch (error) {
    if (signal?.aborted) throw Object.assign(new Error('aborted'), { aborted: true });
    if (error?.name === 'AbortError') throw new Error('Máy chủ phân tích ngừng phản hồi.');
    throw error;
  } finally { clearTimeout(idle.timer); signal?.removeEventListener?.('abort', relay); }
  if (!summary) throw new Error('Luồng phân tích bị ngắt giữa chừng.');
  return summary;
}

/** One-position analysis (used for the 3-variant panel). Returns { bestmove, lines } or throws. */
export async function remoteAnalyzePosition({ url, key, fen, multipv = 3, quality = 'standard', fetchImpl = globalThis.fetch, signal, timeoutMs = 30000 }) {
  const base = normalizeAnalysisServerUrl(url);
  if (!base) throw new Error('Địa chỉ máy chủ phân tích không hợp lệ.');
  const guard = withTimeout(signal, timeoutMs);
  try {
    const response = await fetchImpl(`${base}/v1/analyze`, {
      method: 'POST', cache: 'no-store', signal: guard.signal,
      headers: { 'Content-Type': 'application/json', ...authHeaders(key) },
      body: JSON.stringify({ fen, multipv, quality: REMOTE_QUALITIES[quality] || 'standard' }),
    });
    if (!response.ok) throw new Error(`Máy chủ phân tích trả về HTTP ${response.status}.`);
    const body = await response.json();
    if (!Array.isArray(body?.lines)) throw new Error('Phản hồi phân tích không hợp lệ.');
    return { bestmove: body.bestmove || null, lines: body.lines, cached: Boolean(body.cached) };
  } finally { guard.done(); }
}
