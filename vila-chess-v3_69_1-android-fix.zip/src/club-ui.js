// Giao diện cho: (1) đăng ký giấy phép thi đấu + admin duyệt, (2) đấu trường câu lạc bộ Chủ nhật + banner.
// Markup là hàm thuần (dễ test); controller nhận các hàm của main.js (api, esc, toast…) nên không import vòng.
import { LICENSE_LABELS } from './license.js';

const pad = n => String(n).padStart(2, '0');
const ICT = 7 * 3600_000;

export function formatCountdown(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(total / 86400), h = Math.floor((total % 86400) / 3600), m = Math.floor((total % 3600) / 60), s = total % 60;
  return d > 0 ? `${d} ngày ${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(h)}:${pad(m)}:${pad(s)}`;
}
/** "Chủ nhật 01/11 · 20:00" in Vietnam time, whatever the device time zone is. */
export function formatVnSlot(ms) {
  const d = new Date(ms + ICT);
  return `Chủ nhật ${pad(d.getUTCDate())}/${pad(d.getUTCMonth() + 1)} · ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}
export function formatVnClock(ms) { const d = new Date(ms + ICT); return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`; }

const PHASE_TEXT = { upcoming: 'Sắp diễn ra', live: 'ĐANG DIỄN RA', finished: 'Đã kết thúc' };

function tickerAttrs(t, offset) {
  if (t.phase === 'finished') return '';
  const target = t.phase === 'live' ? t.endsAt : t.startsAt;
  return `data-tournament-countdown="${Number(target)}" data-tournament-offset="${Number(offset) || 0}"`;
}

/** Banner shown on top of the online arena (ranked) screen. */
export function tournamentBannerMarkup(state, { esc, loggedIn }) {
  const t = state?.tournament;
  if (!t) {
    return `<section class="club-banner is-quiet" aria-label="Đấu trường câu lạc bộ"><span class="club-banner-icon" aria-hidden="true">🏆</span><div class="club-banner-copy"><small>ĐẤU TRƯỜNG CLB · MỖI CHỦ NHẬT</small><b>${state?.error ? 'Chưa tải được thông tin giải' : 'Đang tải thông tin giải…'}</b></div></section>`;
  }
  const last = state.history?.[0];
  const champion = last?.champion ? `<span class="club-banner-champ">👑 Nhà vô địch tuần trước: <b>${esc(last.champion.displayName)}</b></span>` : '';
  const timer = t.phase === 'finished' ? '' : `<span class="club-banner-timer"><small>${t.phase === 'live' ? 'Còn lại' : 'Bắt đầu sau'}</small><b ${tickerAttrs(t, state.offset)}>--:--:--</b></span>`;
  const mine = t.myRow ? `<span class="club-banner-me">Bạn: hạng #${t.myRow.rank} · ${t.myRow.points} điểm · ${t.myRow.games} ván</span>` : '';
  let action;
  if (!loggedIn) action = '<button type="button" class="primary-btn" data-club-go="friends">Đăng nhập để đăng ký</button>';
  else if (t.phase === 'finished') action = '<button type="button" class="secondary-btn" data-club-go="club">Xem kết quả</button>';
  else if (t.joined) action = '<button type="button" class="secondary-btn" data-club-go="club">✓ Đã đăng ký · Xem bảng điểm</button>';
  else action = '<button type="button" class="primary-btn" data-club-action="join">Đăng ký tham gia</button>';
  return `<section class="club-banner phase-${esc(t.phase)}" aria-label="Đấu trường câu lạc bộ Chủ nhật">
    <span class="club-banner-icon" aria-hidden="true">🏆</span>
    <div class="club-banner-copy"><small>ĐẤU TRƯỜNG CLB · MỖI CHỦ NHẬT · ${esc(PHASE_TEXT[t.phase] || '')}</small><b>${esc(formatVnSlot(t.startsAt))}–${esc(formatVnClock(t.endsAt))} (giờ VN)</b><span class="club-banner-prize">🎁 ${esc(t.prize)}</span>${champion}${mine}</div>
    ${timer}<div class="club-banner-actions">${action}<small>${t.entrants} người đã đăng ký</small></div></section>`;
}

function standingsTable(rows, esc, myId) {
  if (!rows?.length) return '<div class="empty-state small-empty">Chưa có ai đăng ký.</div>';
  return `<div class="club-table-wrap"><table class="club-table"><thead><tr><th>#</th><th>Người chơi</th><th>Điểm</th><th>Ván</th><th>T/H/B</th></tr></thead><tbody>${rows.map(row => `<tr class="${row.player?.id && row.player.id === myId ? 'is-me' : ''}"><td>${row.rank <= 3 && row.games > 0 ? ['🥇', '🥈', '🥉'][row.rank - 1] : row.rank}</td><td>${esc(row.player?.displayName || '—')}</td><td><b>${row.points}</b></td><td>${row.games}</td><td>${row.wins}/${row.draws}/${row.losses}</td></tr>`).join('')}</tbody></table></div>`;
}

/** Full registration + standings panel shown on the Club page. */
export function tournamentPanelMarkup(state, { esc, loggedIn, myId = '', isAdmin = false }) {
  const t = state?.tournament;
  if (!t) return `<section class="panel club-arena" data-tournament-slot="panel"><div class="empty-state">${esc(state?.error || 'Đang tải đấu trường…')}</div></section>`;
  const history = (state.history || []).map(item => `<li><span>${esc(formatVnSlot(item.endsAt - 90 * 60_000).replace(/ · .*/, ''))}</span><b>${item.champion ? `👑 ${esc(item.champion.displayName)}` : 'Không có người thắng'}</b><small>${item.entrants} người</small></li>`).join('');
  let action;
  if (!loggedIn) action = '<button type="button" class="primary-btn" data-club-go="friends">Đăng nhập để đăng ký</button>';
  else if (t.phase === 'finished') action = '<span class="field-hint">Giải đã kết thúc. Giải tuần sau sẽ mở đăng ký ngay.</span>';
  else if (t.joined && t.phase === 'upcoming') action = '<button type="button" class="secondary-btn" data-club-action="leave">Hủy đăng ký</button><button type="button" class="primary-btn" data-club-go="ranked">Vào đấu trường online</button>';
  else if (t.joined) action = '<button type="button" class="primary-btn" data-club-go="ranked">⚔ Vào đấu trường online</button>';
  else action = `<button type="button" class="primary-btn" data-club-action="join">${t.phase === 'live' ? 'Đăng ký & vào thi đấu' : 'Đăng ký tham gia'}</button>`;
  const podium = t.podium?.length ? `<div class="club-podium">${t.podium.map(row => `<span class="club-podium-item rank-${row.rank}">${['🥇', '🥈', '🥉'][row.rank - 1]} <b>${esc(row.player.displayName)}</b> <small>${row.points} điểm</small></span>`).join('')}</div>` : '';
  const prizeEdit = isAdmin ? `<form class="club-prize-form" data-club-prize-form><label class="field-label" for="clubPrizeInput">Giải thưởng tuần này (admin)</label><div class="yt-music-row"><input id="clubPrizeInput" class="field" name="prize" maxlength="200" value="${esc(t.prize)}"/><button class="secondary-btn" type="submit">Lưu</button></div></form>` : '';
  return `<section class="panel club-arena" data-tournament-slot="panel" aria-label="Đấu trường câu lạc bộ Chủ nhật">
    <div class="panel-heading"><div><small class="eyebrow">ĐẤU TRƯỜNG CLB · MỖI CHỦ NHẬT</small><h2>Giải Chủ nhật · ${esc(PHASE_TEXT[t.phase] || '')}</h2></div><span class="context-icon">🏆</span></div>
    <p class="club-arena-when"><b>${esc(formatVnSlot(t.startsAt))}–${esc(formatVnClock(t.endsAt))}</b> (giờ Việt Nam)${t.phase === 'finished' ? '' : ` · <span ${tickerAttrs(t, state.offset)}>--:--:--</span>`}</p>
    <p class="club-arena-prize">🎁 <b>Giải thưởng:</b> ${esc(t.prize)}</p>
    <p class="field-hint">Đăng ký trước, rồi trong khung giờ giải hãy ghép trận ở “Đấu xếp hạng”. Mỗi ván xếp hạng online được máy chủ xác minh trong giờ giải sẽ tính điểm. ${esc(t.pointsRule)}. Top 3 người có điểm cao nhất được vinh danh.</p>
    ${podium}
    <div class="button-row club-arena-actions">${action}</div>
    ${t.myRow ? `<p class="club-arena-me">Thành tích của bạn: hạng <b>#${t.myRow.rank}</b> · ${t.myRow.points} điểm · ${t.myRow.games} ván (${t.myRow.wins} thắng / ${t.myRow.draws} hòa / ${t.myRow.losses} thua)</p>` : ''}
    <h3 class="club-sub">Bảng điểm · ${t.entrants} người đăng ký</h3>
    ${standingsTable(t.standings, esc, myId)}
    ${prizeEdit}
    <h3 class="club-sub">Nhà vô địch các tuần trước</h3>
    ${history ? `<ul class="club-history">${history}</ul>` : '<div class="empty-state small-empty">Chưa có giải nào kết thúc.</div>'}
  </section>`;
}

/** Player-facing license card on the leaderboard page. */
export function licensePanelMarkup({ license, loggedIn, error = '' }, { esc }) {
  const status = license?.status || 'none';
  const head = `<div class="panel-heading"><div><small class="eyebrow">GIẤY PHÉP THI ĐẤU</small><h2>Điều kiện lên bảng xếp hạng</h2></div><span class="context-icon">🪪</span></div>`;
  const why = '<p class="field-hint">Chỉ tài khoản đã đăng ký giấy phép và được admin chứng nhận mới xuất hiện trong Top người chơi. Bạn vẫn chơi, ghép trận và nhận Elo bình thường khi chưa có giấy phép. Đừng nhập số CCCD/thẻ ngân hàng — chỉ nhập mã giấy phép/chứng nhận do ban tổ chức cấp.</p>';
  if (!loggedIn) return `<section class="panel license-panel" data-license-slot>${head}${why}<button type="button" class="primary-btn" data-club-go="friends">Đăng nhập để đăng ký giấy phép</button></section>`;
  if (!license) return `<section class="panel license-panel" data-license-slot>${head}<div class="empty-state small-empty">${esc(error || 'Đang tải trạng thái giấy phép…')}</div></section>`;
  const badge = `<span class="license-badge status-${esc(status)}">${esc(LICENSE_LABELS[status] || status)}</span>`;
  if (status === 'approved') return `<section class="panel license-panel" data-license-slot>${head}<p>${badge} Bạn đang hiển thị trên bảng xếp hạng.</p><p class="field-hint">Mã: ${esc(license.licenseCode)} · Người giữ: ${esc(license.holderName)}</p></section>`;
  if (status === 'pending') return `<section class="panel license-panel" data-license-slot>${head}<p>${badge}</p><p class="field-hint">Hồ sơ ${esc(license.licenseCode)} đã gửi. Admin sẽ duyệt; khi được chứng nhận bạn sẽ tự xuất hiện trên bảng xếp hạng.</p></section>`;
  const reason = (status === 'rejected' || status === 'revoked') && license.reason ? `<p class="field-hint">Lý do: ${esc(license.reason)}. Bạn có thể sửa và gửi lại.</p>` : '';
  return `<section class="panel license-panel" data-license-slot>${head}<p>${badge}</p>${reason}${why}
    <form class="license-form" data-license-form>
      <label class="field-label" for="licenseHolder">Họ tên người giữ giấy phép</label><input id="licenseHolder" class="field" name="holderName" maxlength="60" required autocomplete="name" value="${esc(license.holderName || '')}"/>
      <label class="field-label" for="licenseCode">Mã giấy phép / chứng nhận</label><input id="licenseCode" class="field" name="licenseCode" maxlength="40" required autocomplete="off" placeholder="VD: VCF-2026/001" value="${esc(license.licenseCode || '')}"/>
      <label class="field-label" for="licenseNote">Ghi chú cho admin (không bắt buộc)</label><textarea id="licenseNote" class="field" name="note" maxlength="300" rows="2">${esc(license.note || '')}</textarea>
      ${error ? `<div class="field-hint license-error" role="alert">${esc(error)}</div>` : ''}
      <button class="primary-btn" type="submit">Gửi hồ sơ cho admin</button>
    </form></section>`;
}

/** Admin review queue. */
export function adminLicensesMarkup({ rows, pending, filter, error }, { esc }) {
  const tabs = ['pending', 'approved', 'rejected', 'revoked'].map(key => `<button type="button" class="${filter === key ? 'primary-btn' : 'secondary-btn'}" data-license-filter="${key}">${esc(LICENSE_LABELS[key])}</button>`).join('');
  const list = error ? `<div class="empty-state small-empty">${esc(error)}</div>` : !rows?.length ? '<div class="empty-state small-empty">Không có hồ sơ nào ở trạng thái này.</div>'
    : `<ul class="admin-license-list">${rows.map(({ user, license }) => `<li class="admin-license-row"><div><b>${esc(user.displayName)}</b> <small>@${esc(user.username)} · Elo ${Number(user.elo) || '—'} · ${Number(user.games) || 0} ván</small><div>${esc(license.holderName)} · <code>${esc(license.licenseCode)}</code></div>${license.note ? `<small>${esc(license.note)}</small>` : ''}${license.reason ? `<small>Lý do: ${esc(license.reason)}</small>` : ''}</div><div class="admin-license-actions">${license.status === 'pending' ? `<button type="button" class="primary-btn" data-license-decide="approve" data-license-user="${esc(user.id)}">Duyệt</button><button type="button" class="secondary-btn" data-license-decide="reject" data-license-user="${esc(user.id)}">Từ chối</button>` : ''}${license.status === 'approved' ? `<button type="button" class="secondary-btn" data-license-decide="revoke" data-license-user="${esc(user.id)}">Thu hồi</button>` : ''}</div></li>`).join('')}</ul>`;
  return `<section class="panel admin-licenses" id="adminLicensesPanel"><div class="panel-heading"><div><small class="eyebrow">GIẤY PHÉP THI ĐẤU</small><h2>Duyệt giấy phép (${Number(pending) || 0} chờ)</h2></div><span class="context-icon">🪪</span></div><p class="field-hint">Chỉ người được duyệt ở đây mới lên bảng xếp hạng. Admin không thể tự duyệt giấy phép của chính mình.</p><div class="button-row license-filters">${tabs}</div>${list}</section>`;
}

/**
 * Controller. `deps`: { api(path, options), esc, toast, getUser(), goto(view), isLoggedIn() }.
 * One delegated click listener handles every data-club-* control, so re-rendering views never loses handlers.
 */
export function createClubController(deps) {
  const { api, esc, toast, getUser, goto, isLoggedIn } = deps;
  const state = { tournament: null, history: [], offset: 0, error: '', loadedAt: 0, loading: null };
  const license = { value: null, error: '', loadedAt: 0 };
  const admin = { rows: [], pending: 0, filter: 'pending', error: '' };
  let ticker = null;

  const ctx = () => ({ esc, loggedIn: isLoggedIn(), myId: getUser()?.id || '', isAdmin: getUser()?.role === 'admin' });

  function paintTournament() {
    document.querySelectorAll('[data-tournament-slot="banner"]').forEach(node => { node.innerHTML = tournamentBannerMarkup(state, ctx()); });
    document.querySelectorAll('[data-tournament-slot="panel-host"]').forEach(node => { node.innerHTML = tournamentPanelMarkup(state, ctx()); });
    tick();
    if (!ticker) ticker = setInterval(tick, 1000);
  }
  function tick() {
    const nodes = document.querySelectorAll('[data-tournament-countdown]');
    if (!nodes.length) { if (ticker) { clearInterval(ticker); ticker = null; } return; }
    nodes.forEach(node => {
      const target = Number(node.dataset.tournamentCountdown), offset = Number(node.dataset.tournamentOffset) || 0;
      const left = target - (Date.now() + offset);
      node.textContent = left <= 0 ? 'Đang cập nhật…' : formatCountdown(left);
      if (left <= 0 && Date.now() - state.loadedAt > 5000) void loadTournament(true);
    });
  }
  async function loadTournament(force = false) {
    // Always paint what we already know first, so a re-render of the view never shows an empty banner while refreshing.
    paintTournament();
    if (state.loading) return state.loading;
    if (!force && state.tournament && Date.now() - state.loadedAt < 20_000) return;
    state.loading = (async () => {
      try {
        const data = await api('/tournaments/current');
        state.tournament = data.tournament || null; state.history = Array.isArray(data.history) ? data.history : [];
        state.offset = Number(data.serverNow) ? Number(data.serverNow) - Date.now() : 0;
        state.error = ''; state.loadedAt = Date.now();
      } catch (error) { state.error = error.message || 'Không tải được giải đấu.'; if (!state.tournament) state.history = []; }
      finally { state.loading = null; paintTournament(); }
    })();
    return state.loading;
  }
  async function tournamentAction(kind) {
    try {
      const data = await api(`/tournaments/current/${kind}`, { method: 'POST', body: '{}' });
      if (data.tournament) { state.tournament = data.tournament; state.loadedAt = Date.now(); }
      toast(data.message || 'Đã cập nhật.', 'success');
    } catch (error) { toast(error.message || 'Không thực hiện được.', 'error'); await loadTournament(true); }
    paintTournament();
  }

  function paintLicense() {
    document.querySelectorAll('[data-license-host]').forEach(node => { node.innerHTML = licensePanelMarkup({ license: license.value, loggedIn: isLoggedIn(), error: license.error }, { esc }); });
  }
  async function loadLicense(force = false) {
    if (!isLoggedIn()) { license.value = null; paintLicense(); return; }
    paintLicense();
    if (!force && license.value && Date.now() - license.loadedAt < 15_000) return;
    try { const data = await api('/me/license'); license.value = data.license; license.error = ''; license.loadedAt = Date.now(); }
    catch (error) { license.error = error.message || 'Không tải được trạng thái giấy phép.'; }
    paintLicense();
  }
  async function submitLicenseForm(form) {
    const body = Object.fromEntries(new FormData(form).entries());
    try {
      const data = await api('/me/license', { method: 'POST', body: JSON.stringify(body) });
      license.value = data.license; license.error = ''; license.loadedAt = Date.now();
      toast(data.message || 'Đã gửi hồ sơ.', 'success');
    } catch (error) { license.error = error.message || 'Không gửi được hồ sơ.'; license.value = { ...(license.value || {}), status: license.value?.status || 'none', holderName: body.holderName || '', licenseCode: body.licenseCode || '', note: body.note || '' }; }
    paintLicense();
  }

  async function loadAdminLicenses() {
    if (getUser()?.role !== 'admin') return;
    const page = document.querySelector('.admin-page');
    if (!page) return;
    let host = document.getElementById('adminLicensesHost');
    if (!host) { host = document.createElement('div'); host.id = 'adminLicensesHost'; host.dataset.adminLicensesHost = '1'; page.insertBefore(host, page.children[1] || null); }
    try { const data = await api(`/admin/licenses?status=${encodeURIComponent(admin.filter)}`); admin.rows = data.licenses || []; admin.pending = data.pending || 0; admin.error = ''; }
    catch (error) { admin.rows = []; admin.error = error.message || 'Không tải được hồ sơ giấy phép.'; }
    host.innerHTML = adminLicensesMarkup({ ...admin }, { esc });
  }
  async function decide(userId, decision) {
    let reason = '';
    if (decision !== 'approve') { reason = window.prompt(decision === 'reject' ? 'Lý do từ chối (người chơi sẽ thấy):' : 'Lý do thu hồi (người chơi sẽ thấy):', '') ; if (reason === null) return; }
    try { const data = await api(`/admin/licenses/${encodeURIComponent(userId)}/decision`, { method: 'POST', body: JSON.stringify({ decision, reason }) }); toast(data.message || 'Đã cập nhật.', 'success'); }
    catch (error) { toast(error.message || 'Không cập nhật được.', 'error'); }
    await loadAdminLicenses();
  }

  document.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target : null;
    if (!target) return;
    const act = target.closest('[data-club-action]');
    if (act) { event.preventDefault(); void tournamentAction(act.dataset.clubAction === 'leave' ? 'leave' : 'join'); return; }
    const go = target.closest('[data-club-go]');
    if (go) { event.preventDefault(); goto(go.dataset.clubGo); return; }
    const decideBtn = target.closest('[data-license-decide]');
    if (decideBtn) { event.preventDefault(); void decide(decideBtn.dataset.licenseUser, decideBtn.dataset.licenseDecide); return; }
    const filter = target.closest('[data-license-filter]');
    if (filter) { event.preventDefault(); admin.filter = filter.dataset.licenseFilter; void loadAdminLicenses(); }
  });
  document.addEventListener('submit', event => {
    const form = event.target instanceof Element ? event.target : null;
    if (!form) return;
    if (form.matches('[data-license-form]')) { event.preventDefault(); void submitLicenseForm(form); }
    else if (form.matches('[data-club-prize-form]')) {
      event.preventDefault();
      const prize = String(new FormData(form).get('prize') ?? form.querySelector('input')?.value ?? '');
      api('/admin/tournaments/current/prize', { method: 'POST', body: JSON.stringify({ prize }) }).then(() => { toast('Đã lưu giải thưởng.', 'success'); return loadTournament(true); }).catch(error => toast(error.message || 'Không lưu được.', 'error'));
    }
  });

  return { loadTournament, paintTournament, loadLicense, paintLicense, loadAdminLicenses, state, bannerHost: () => '<div data-tournament-slot="banner"></div>', panelHost: () => '<div data-tournament-slot="panel-host"></div>', licenseHost: () => '<div data-license-host></div>' };
}
