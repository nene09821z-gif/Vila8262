import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Chess } from 'chess.js';
import { createOpeningIntel } from '../src/opening-intel.js';
import { prewarmOpeningTrie, recognizeOpening } from '../src/opening-recognition.js';
import { prewarmOpeningBook } from '../src/opening-book.js';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

/** Manual timer queue so slices can be stepped one at a time without waiting. */
function fakeTimers() {
  const realSet = globalThis.setTimeout;
  const realClear = globalThis.clearTimeout;
  const queue = [];
  globalThis.setTimeout = (callback, delay = 0) => { const timer = { callback, delay }; queue.push(timer); return timer; };
  globalThis.clearTimeout = timer => { const index = queue.indexOf(timer); if (index >= 0) queue.splice(index, 1); };
  return {
    queue,
    /** Runs the next scheduled callback and returns the delay it was scheduled with. */
    runNext() { const timer = queue.shift(); if (!timer) return null; timer.callback(); return timer.delay; },
    restore() { globalThis.setTimeout = realSet; globalThis.clearTimeout = realClear; }
  };
}

function catalogue(count = 40) {
  const lines = [['e4', 'e5', 'Nf3', 'Nc6'], ['d4', 'd5', 'c4', 'e6'], ['c4', 'e5', 'Nc3', 'Nf6'], ['Nf3', 'd5', 'g3', 'Nf6']];
  return Array.from({ length: count }, (_, index) => {
    const moves = lines[index % lines.length];
    return { eco: `X${index}`, name: `Line ${index}`, san: [...moves], moves: moves.join(' '), pgn: moves.join(' ') };
  });
}

function countingChess(counter) {
  return class CountingChess extends Chess {
    constructor(...args) { super(...args); counter.lines += 1; }
  };
}

test('opening index warm-up works in time slices instead of one long blocking loop', () => {
  const timers = fakeTimers();
  try {
    const counter = { lines: 0 };
    let clock = 0;
    const intel = createOpeningIntel(catalogue(40), countingChess(counter));
    // Every clock read costs 2 ms, so a 5 ms budget fits only a few lines per slice.
    intel.warm(40, { budgetMs: 5, gapMs: 30, startDelayMs: 100, now: () => (clock += 2), inputPending: () => false });
    assert.equal(counter.lines, 0, 'nothing runs synchronously');
    assert.equal(timers.queue.length, 1);

    const sizes = [];
    let guard = 0;
    while (timers.queue.length && guard++ < 200) {
      const before = counter.lines;
      timers.runNext();
      sizes.push(counter.lines - before);
    }
    assert.ok(sizes.every(size => size >= 1 && size <= 4), `every slice stays tiny, got ${sizes}`);
    assert.ok(sizes.length >= 10, 'the work is spread over many slices');
    assert.equal(counter.lines, 40, 'every catalogue line is still indexed');
  } finally { timers.restore(); }
});

test('opening index warm-up steps aside while a piece is being dragged', () => {
  const timers = fakeTimers();
  try {
    const counter = { lines: 0 };
    let busy = true;
    const intel = createOpeningIntel(catalogue(8), countingChess(counter));
    intel.warm(40, { budgetMs: 5, startDelayMs: 0, busyGapMs: 140, isBusy: () => busy, now: () => 0, inputPending: () => false });
    for (let i = 0; i < 4; i += 1) assert.equal(timers.runNext(), i === 0 ? 0 : 140);
    assert.equal(counter.lines, 0, 'no lines are processed while the board is busy');
    busy = false;
    timers.runNext();
    assert.ok(counter.lines > 0, 'work resumes as soon as the drag ends');
  } finally { timers.restore(); }
});

test('opening index warm-up yields immediately when the browser reports pending input', () => {
  const timers = fakeTimers();
  try {
    const counter = { lines: 0 };
    const intel = createOpeningIntel(catalogue(8), countingChess(counter));
    intel.warm(40, { budgetMs: 1000, startDelayMs: 0, now: () => 0, inputPending: () => true });
    timers.runNext();
    assert.equal(counter.lines, 1, 'one line per slice (guaranteed progress) while input is waiting');
  } finally { timers.restore(); }
});

test('prewarming the opening tries is harmless and does not change recognition', () => {
  const openings = catalogue(12);
  const before = recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6'], openings);
  prewarmOpeningTrie(openings);
  prewarmOpeningBook(openings);
  prewarmOpeningTrie(null);
  prewarmOpeningBook(undefined);
  assert.deepEqual(recognizeOpening(['e4', 'e5', 'Nf3', 'Nc6'], openings), before);
});

test('main.js starts the index paused-while-dragging and prewarms the tries at boot', () => {
  const main = read('src/main.js');
  assert.match(main, /intel\.warm\(40, \{ isBusy: \(\) => Boolean\(document\.body\?\.classList\.contains\('board-dragging'\)\) \}\)/);
  assert.match(main, /initEngine\(\);\nscheduleOpeningPrewarm\(\);/);
  assert.match(main, /if \(hint\.textContent !== hintText\) hint\.textContent = hintText;/);
});

test('the puzzle board updates squares in place instead of rebuilding all 64 on every pick-up and drop', () => {
  const main = read('src/main.js');
  assert.match(main, /function morphBoardMarkup\(board, markup\)/);
  assert.match(main, /function refreshPuzzleBoard\(slide = null\) \{[^}]*morphBoardMarkup\(board, renderPuzzleBoardMarkup\(\)\)/s);
  assert.doesNotMatch(main, /board\.innerHTML = renderPuzzleBoardMarkup\(\)/);
});
