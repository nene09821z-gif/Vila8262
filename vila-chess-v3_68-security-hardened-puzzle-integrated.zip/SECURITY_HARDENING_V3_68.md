# VILA Chess — Security Hardening Patch

## What changed

- Cloudflare Worker CORS now uses an explicit allowlist (`CORS_ORIGINS`) instead of reflecting every supplied `Origin`. Without a configured variable, only the native app origins `https://localhost`, `capacitor://localhost` and `ionic://localhost` are allowed. Add exact web frontend origin(s), comma-separated, in Cloudflare Worker Variables if the web app is hosted elsewhere or during Vite development. Native app origins remain allowed. Do not use `*`.
- API responses add `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, a restrictive API-only CSP and HSTS on HTTPS.
- Request bodies are streamed and cancelled once they exceed 64 KiB, even when `Content-Length` is missing or misleading; JSON parsing occurs only after the bounded read completes. Bearer tokens over 4 KiB are rejected.
- Login has a persisted failed-attempt limiter keyed by SHA-256 of the normalized account identity, complementing existing per-IP limits. When the failure threshold is reached, further incorrect passwords are throttled, but a correct password is still allowed; this avoids attackers locking a victim out by submitting their username repeatedly. Audit records store only a short hash prefix for login failures, not the submitted username/email.
- Expensive Lichess, opening-explorer and puzzle proxy routes have an additional per-IP, per-isolate rate cap and `Retry-After`; the Node server version has matching API headers, explicit CORS rejection, and proxy throttles.
- Unhandled backend exceptions are logged server-side and return a generic API error instead of exposing internal exception text.
- Existing protections remain: signed/expiring bearer sessions, session-version revocation, password hashing, server-authoritative legal chess moves, turn/order checks, stale-ply rejection, server-authoritative clocks/results/Elo, and admin-role checks.

## Important deployment step

The in-memory proxy throttle in a Worker is best-effort because isolates can restart or scale independently; it is not a DDoS shield. In Cloudflare Dashboard, add Rate Limiting/WAF rules appropriate to your plan for `/api/lichess/*`, `/api/openings/explorer`, `/api/puzzles/next`, `/api/social/auth/login` and `/api/social/auth/register`. Keep Durable Object rate limiting enabled. Configure `CORS_ORIGINS` with exact deployed frontend origins if the browser app is not hosted on `localhost`/Capacitor.

Do not commit `ADMIN_PASSWORD`, service-account JSON, email provider keys, tokens or production secrets into Git/ZIP files. Use Cloudflare secrets/environment configuration. Use a unique administrator password of at least 14 characters, and rotate it if it was shared publicly.

## Verification status

- JavaScript syntax checks: run for patched Worker and Node server files.
- Security regression tests added for origin allowlisting, response headers, proxy rate limiting and account-identity login throttling.
- Full npm test suite and production Android/APK build must run in GitHub Actions because this working environment does not have the project npm dependencies installed and network access to the npm registry is not assumed. Do not interpret the source ZIP as a deployed or penetration-tested service.

## Test record for this ZIP

- Syntax validation: 216 JavaScript/MJS files passed `node --check`.
- Static security/CI regressions: 14/14 passed.
- Cloudflare proxy, body-size, and security-header runtime tests: 8/8 passed.
- Hashed identity login throttle and anti-account-lockout runtime test: 1/1 passed.
- Dependency caveat: the complete npm dependency install could not be performed offline because `yauzl@2.10.0` was not cached. The runtime-only security/proxy tests used a temporary import stub for the `chess.js` module; those test paths do not invoke chess rules. The stub was removed and is not included in this ZIP.
- Not run: the complete regression suite, Vite production build, Gradle/APK build, tests against deployed Cloudflare, live penetration testing and two-device matchmaking test.
