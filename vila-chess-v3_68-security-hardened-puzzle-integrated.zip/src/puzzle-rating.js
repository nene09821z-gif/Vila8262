/** Chess.com-style puzzle rating: Elo expectation vs the puzzle's own rating, with first-try,
 *  hint and speed adjustments. Pure functions (no DOM / chess.js) so they are unit-tested. */
export const PUZZLE_RATING_START = 800;
export const PUZZLE_RATING_MIN = 100;
export const PUZZLE_RATING_MAX = 3200;
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

export function expectedScore(playerRating, puzzleRating) {
  return 1 / (1 + 10 ** ((puzzleRating - playerRating) / 400));
}

/** Larger steps while the rating is still settling, smaller once it is established. */
export function kFactor(gamesPlayed) {
  const n = Math.max(0, Math.floor(Number(gamesPlayed) || 0));
  return n < 20 ? 40 : n < 100 ? 24 : 16;
}

/** Rough rating for a bundled mate puzzle: longer forced mates are harder. */
export function estimateBankRating(puzzle) {
  const mateIn = Math.max(1, Math.min(6, Number(puzzle?.mateIn) || 2));
  return 700 + (mateIn - 1) * 380;
}

/** Score in [0,1]: 1 = solved first try, no hint; partial credit for slips; 0 = failed / revealed. */
export function puzzleScore({ solved, wrongCount = 0, hintUsed = false, solveMs = 0, parMs = 20000 } = {}) {
  if (!solved) return 0;
  if (wrongCount > 0) return 0.25;
  if (hintUsed) return 0.5;
  const speed = solveMs > 0 && solveMs < parMs ? 0.1 * (1 - solveMs / parMs) : 0;
  return Math.min(1, 0.9 + speed + 0.0001);
}

export function updatePuzzleRating({ rating = PUZZLE_RATING_START, games = 0 } = {}, puzzleRating, score) {
  const current = clamp(Number(rating) || PUZZLE_RATING_START, PUZZLE_RATING_MIN, PUZZLE_RATING_MAX);
  const target = clamp(Number(puzzleRating) || current, PUZZLE_RATING_MIN, PUZZLE_RATING_MAX);
  const delta = Math.round(kFactor(games) * (clamp(Number(score) || 0, 0, 1) - expectedScore(current, target)));
  return { rating: clamp(current + delta, PUZZLE_RATING_MIN, PUZZLE_RATING_MAX), delta, games: Math.floor(Number(games) || 0) + 1 };
}

/** Pick the unseen puzzle whose rating is closest to the player's (with a little randomness). */
export function pickByRating(items, playerRating, seenKeys = new Set(), keyOf = item => item.fen, ratingOf = estimateBankRating, rng = Math.random) {
  const unseen = (items || []).filter(item => !seenKeys.has(keyOf(item)));
  if (!unseen.length) return null;
  const ranked = unseen
    .map(item => ({ item, gap: Math.abs(ratingOf(item) - playerRating) }))
    .sort((a, b) => a.gap - b.gap);
  const bestGap = ranked[0].gap;
  const close = ranked.filter(entry => entry.gap <= bestGap + 100);
  return close[Math.min(close.length - 1, Math.floor(rng() * close.length))].item;
}

export function loadPuzzleRating(storage, key = 'vila.chess.puzzles.rating.v1') {
  try {
    const parsed = JSON.parse(storage?.getItem?.(key) || 'null');
    if (parsed && Number.isFinite(parsed.rating)) return { rating: clamp(parsed.rating, PUZZLE_RATING_MIN, PUZZLE_RATING_MAX), games: Math.max(0, Math.floor(parsed.games) || 0) };
  } catch { /* ignore corrupted value */ }
  return { rating: PUZZLE_RATING_START, games: 0 };
}

export function savePuzzleRating(storage, state, key = 'vila.chess.puzzles.rating.v1') {
  try { storage?.setItem?.(key, JSON.stringify({ rating: state.rating, games: state.games })); } catch { /* ignore */ }
}
