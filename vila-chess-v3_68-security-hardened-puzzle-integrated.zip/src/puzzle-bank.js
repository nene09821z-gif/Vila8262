/**
 * Bundled forced-mate puzzles (mate in 2-4). Each entry was mined from Stockfish 19 self-play and
 * re-verified at depth 20 (scripts/audit-puzzle-bank.mjs): every player move except the last is the only mating try, replies are best defences, and
 * `moves` is the full principal line [player, reply, player, ...] ending in checkmate.
 */
export const PUZZLE_BANK = [
  {"fen": "1r1Q4/6pp/p1N1Pk2/P7/4bp2/2P5/1p1q2P1/5K2 b - - 0 41", "moves": ["b8d8", "c6d8", "b2b1q"], "mateIn": 2},
  {"fen": "2r5/5k2/1p5p/5p2/Q1pr4/3n2qP/1P6/5R1K b - - 10 40", "moves": ["g3h3", "h1g1", "c8g8"], "mateIn": 2},
  {"fen": "3b2k1/2p2pp1/8/4P1q1/1P6/8/r3R3/7K b - - 1 41", "moves": ["a2e2", "e5e6", "g5g2"], "mateIn": 2},
  {"fen": "3rr1k1/1p4p1/5QR1/p1B4p/1P2pP2/P3p2P/5q2/2K5 b - - 1 41", "moves": ["d8d1", "c1d1", "f2d2"], "mateIn": 2},
  {"fen": "6kR/5pp1/1N2n3/r1b5/4bP2/P6P/4K3/r1q5 b - - 1 35", "moves": ["g8h8", "b6d5", "c1d1"], "mateIn": 2},
  {"fen": "7Q/8/6p1/5pk1/p6p/1pPRR2P/1qBKN1P1/8 w - - 2 46", "moves": ["e3g3", "h4g3", "d3g3"], "mateIn": 2},
  {"fen": "k7/2r5/pR5r/P1Pp4/4q3/4P3/4K3/8 b - - 1 56", "moves": ["h6h2", "e2e1", "e4h1"], "mateIn": 2},
  {"fen": "r1b3kr/pppp3p/2n2Qp1/5p2/3P4/2P2N2/P1PB1PPP/R3K2R w KQ - 0 17", "moves": ["d2h6", "c6d4", "f6g7"], "mateIn": 2},
  {"fen": "r4Q2/1p1k4/p2p4/2pBp3/2P4P/1P4p1/P2R4/4K3 w - - 2 37", "moves": ["d5e6", "d7e6", "d2d6"], "mateIn": 2},
  {"fen": "r5k1/3n2bp/1p2p1p1/pPP5/P1N1n2q/N1P2KP1/1B2Q3/R4R2 b - - 0 27", "moves": ["h4g3", "f3e4", "d7c5"], "mateIn": 2},
  {"fen": "rnb1Qbk1/2qpp2N/p1p5/1p4P1/3P2P1/2P5/PP1NBP2/2R1K3 w - - 3 23", "moves": ["e8f8", "g8h7", "e2d3"], "mateIn": 2},
  {"fen": "2k2B2/p1p5/1P1r1pr1/4p2p/6q1/1RNPQ3/P1P2PbK/2R5 b - - 0 30", "moves": ["g4h4", "e3h3", "h4h3", "h2g1", "h3h1"], "mateIn": 3},
  {"fen": "2r2k1r/R7/4p3/1pp1PpB1/3b3P/P2P2Q1/1P3P2/6K1 w - - 0 35", "moves": ["g5h6", "f8e8", "g3g6", "e8d8", "h6g5"], "mateIn": 3},
  {"fen": "4k3/7Q/3p4/8/P7/1P1BP2p/1q5N/4R2K w - - 2 53", "moves": ["d3b5", "e8f8", "e1f1", "b2f2", "f1f2"], "mateIn": 3},
  {"fen": "5R2/7k/4r3/6p1/1p1B4/1P4K1/3p4/3B4 w - - 0 49", "moves": ["d1c2", "e6e4", "c2e4", "h7h6", "f8h8"], "mateIn": 3},
  {"fen": "5k2/p1pn4/3pb2p/4q1P1/7P/Pr3B2/6K1/8 b - - 0 59", "moves": ["b3b2", "g2f1", "e5g3", "g5h6", "g3f2"], "mateIn": 3},
  {"fen": "6k1/2R5/4p1p1/p2bP1Q1/p6p/7P/1P1Nq1P1/4K3 w - - 9 43", "moves": ["e1e2", "d5c4", "d2c4", "g8f8", "g5d8"], "mateIn": 3},
  {"fen": "6r1/2k3q1/8/pQ1p4/5KP1/1P2P3/P2N1P2/8 b - - 0 43", "moves": ["g7g5", "f4g3", "g5g4", "g3h2", "g4g2"], "mateIn": 3},
  {"fen": "7k/pb4p1/1p2r2p/1P4qP/5pPR/P1r1nP2/2P5/2R3K1 b - g3 0 38", "moves": ["g5h4", "c1f1", "h4g3", "g1h1", "g3g2"], "mateIn": 3},
  {"fen": "8/1p6/4Pk1p/8/p3r2P/P7/1P1K1Pq1/8 b - - 5 41", "moves": ["g2f2", "d2c3", "e4d4", "b2b3", "f2d2"], "mateIn": 3},
  {"fen": "8/5k1p/3bp2P/6p1/3Q2B1/4P1P1/1P3PK1/2B5 w - - 1 36", "moves": ["d4d6", "e6e5", "g4h5", "f7g8", "d6d8"], "mateIn": 3},
  {"fen": "8/8/2BK2k1/7p/5Q2/3N4/7r/8 w - - 5 57", "moves": ["d3e5", "g6g7", "f4f7", "g7h6", "f7g6"], "mateIn": 3},
  {"fen": "B4k2/7p/8/p6K/b5P1/8/3q4/8 b - - 3 53", "moves": ["h7h6", "h5g6", "d2g5", "g6h7", "g5g7"], "mateIn": 3},
  {"fen": "r1b2k2/1p4p1/p1q4r/P4pBn/1PQP3p/2PP3P/6P1/4R1K1 w - - 0 29", "moves": ["g5e7", "f8e8", "c4g8", "e8d7", "g8d8"], "mateIn": 3},
  {"fen": "2RB4/8/3R1pk1/p5Pp/P5r1/5BP1/P5P1/6K1 w - - 0 39", "moves": ["d6f6", "g6g7", "c8c7", "g7g8", "f3d5", "g8h8", "f6f8"], "mateIn": 4},
  {"fen": "7k/5pq1/4p2p/p1p4Q/P1P2P1P/1P1r2p1/6K1/8 b - - 0 47", "moves": ["d3d2", "h5e2", "d2e2", "g2f3", "e2f2", "f3e3", "g7d4"], "mateIn": 4},
  {"fen": "8/ppkr4/8/6RP/3p4/4PPK1/8/1qq5 b - - 1 43", "moves": ["c1g1", "g3h4", "b1e1", "h4h3", "g1g5", "h3h2", "e1h4"], "mateIn": 4},
  {"fen": "2b2rk1/5pp1/p1nq1b1p/3p4/P7/4Q1PP/1r4B1/K7 b - - 0 32", "moves": ["b2b3", "a1a2", "d6a3"], "mateIn": 2},
  {"fen": "3r4/1Qp1kn1p/p4r2/4p3/3p1q2/1Pp5/P1P5/1K4R1 b - - 5 37", "moves": ["f4f1", "g1f1", "f6f1"], "mateIn": 2},
  {"fen": "1r4k1/3pn3/p3p1p1/1p6/PPPq1rPp/8/K5B1/7R b - - 1 32", "moves": ["f4f2", "a2a3", "d4b2"], "mateIn": 2},
  {"fen": "b5k1/2R2ppp/8/8/P2P2Pq/4P1RP/1P2BP2/4K3 w - - 0 30", "moves": ["c7c8", "h4d8", "c8d8"], "mateIn": 2},
  {"fen": "r3k3/1p3qp1/p2B4/5Q2/4r3/8/PPP2PP1/2K1R3 w - - 3 30", "moves": ["e1e4", "e8d8", "f5f7", "a8c8", "e4e8"], "mateIn": 3},
  {"fen": "8/2p3k1/1p4p1/1P3nBp/p2P1N2/P2B1P2/6K1/2R1R3 w - - 8 35", "moves": ["c1c7", "f5e7", "e1e7", "g7f8", "c7c8"], "mateIn": 3},
  {"fen":"7Q/3q4/2k2bp1/8/3p4/3b1p2/P4P2/6K1 b - - 0 43","moves":["d7g4","g1h2","g4g2"],"mateIn":2},
  {"fen":"Q5n1/5ppk/1p6/5n2/7p/4qR1P/4r1P1/7K b - - 1 43","moves":["e2e1","f3f1","e1f1","h1h2","e3g1"],"mateIn":3},
  {"fen":"r1b2r2/pp1n1pp1/2p2B1k/2bp4/3P4/5N1P/P1Q2PP1/qN3RK1 w - - 2 15","moves":["f6g5","h6h5","g2g4"],"mateIn":2},
  {"fen":"2kr1b1r/1p4pp/p7/4Bb2/P2Qq3/7P/1P1K2P1/R6R b - - 2 26","moves":["f8b4","d2c1","e4c2"],"mateIn":2},
  {"fen":"rn2k2r/p4p1p/1pb1p1pn/6q1/3QP3/2N5/PP3PPP/3RKB1R w K - 0 17","moves":["d4h8","h6g8","h8g8","e8e7","g8d8"],"mateIn":3},
  {"fen":"r2qk2r/p2n3p/1p1P1npQ/2p1p1N1/2P5/5b1P/PPB2PP1/R3R1K1 w kq - 0 21","moves":["c2g6","h7g6","h6g6","e8f8","g5e6"],"mateIn":3},
  {"fen":"7k/2p4p/p7/1pb2p2/5q2/6PP/P2R1P1K/1B2r3 b - - 0 34","moves":["f4d2","h3h4","d2f2","h2h3","e1h1"],"mateIn":3},
  {"fen":"7k/2p2r2/8/p2P2Q1/7P/4B1P1/q4NK1/3R3R w - - 1 29","moves":["e3d4","h8h7","g5h5","h7g8","h5h8"],"mateIn":3},
  {"fen":"r6k/5p1p/1pb1p3/6QP/B1p1P3/1Pp2P2/5P2/2K5 w - - 1 34","moves":["h5h6","a8g8","g5f6","g8g7","f6g7"],"mateIn":3},
  {"fen":"4kn1r/p2p1ppp/8/q6P/1B6/4PbP1/1P3K1Q/2r4R b k - 2 26","moves":["c1c2","f2f1","a5a6","h2e2","a6e2","f1g1","e2f2"],"mateIn":4},
  {"fen":"1q4rr/1b3p2/p1kPpQ1b/1p3P2/7p/P1NR4/1PP1B1PP/1K1R4 w - - 1 23","moves":["e2f3","c6d7","f6e7","d7c8","d6d7","c8c7","d7d8q"],"mateIn":4},
  {"fen":"r7/r4k2/P5RQ/3nqpB1/3pB3/7P/1P3PP1/4R1K1 w - - 4 43","moves":["e4d5","f7e8","g6g8","e8d7","h6c6"],"mateIn":3},
  {"fen":"8/Q7/P2r2k1/1p2R2p/1P3Pq1/6P1/1Pn3BP/1R5K w - - 0 38","moves":["g2e4","g4f5","e4f5","g6h6","a7h7"],"mateIn":3},
  {"fen":"1r3rk1/7p/3p2p1/p1PNb2n/1pP3Pq/1P2Pp1P/P1Q2P2/3RRK2 b - - 1 33","moves":["h4h3","f1g1","h3g2"],"mateIn":2},
  {"fen":"8/5p1k/pp3Qbb/2P1B3/3p4/1P6/q7/5K2 b - - 6 45","moves":["g6d3","f1g1","h6e3","g1h1","d3e4","f6f3","e4f3"],"mateIn":4},
  {"fen":"r4rk1/1p4p1/7p/1B1pq1P1/Pp2b2P/1R3p2/1Pn5/5KR1 b - - 1 27","moves":["e4d3","f1f2","e5h2","g1g2","f3g2"],"mateIn":3},
  {"fen":"r1b2rk1/pp1p2pp/2nb1p2/q1pN3P/2BpPP2/6B1/PPP2KP1/R2Q3R w - - 5 17","moves":["d5e7","g8h8","e7g6","h7g6","h5g6"],"mateIn":3},
  {"fen":"1q6/4kp2/p3pp2/5Q2/8/1p1n1P1r/5P2/1R2R1K1 b - - 1 34","moves":["b8h2","g1f1","h2f2"],"mateIn":2},
  {"fen":"5rk1/1p1N2pp/4p3/2b2p1n/8/1P1B4/P5PP/2q2R1K b - - 0 27","moves":["h5g3","h2g3","c1h6"],"mateIn":2},
  {"fen":"5r2/p4kp1/3pp2p/8/2b1Rq2/2B5/1P3nPP/5QK1 b - - 1 35","moves":["f2h3","g2h3","f4f1"],"mateIn":2},
  {"fen":"rbb3k1/5pp1/2p1r3/p1Pp4/1P4Pq/P1N2Q2/3RB1P1/5RK1 b - - 3 25","moves":["b8h2","g1h1","h2g3","h1g1","h4h2"],"mateIn":3},
  {"fen":"3rnk2/1p4pQ/2b1Bb2/1N1pp3/p7/8/PRPB2PP/1R3K2 w - - 1 29","moves":["h7g8","f8e7","g8f7"],"mateIn":2},
  {"fen":"2r1k2r/ppp2q2/4p3/4P1Q1/2P1b2n/B2R2P1/P3Bp1K/3R4 b - - 1 33","moves":["h4f3","h2g2","f3e1","g2f1","e4g2"],"mateIn":3},
  {"fen":"rn6/2p5/1pPqk3/8/pP6/P2p4/4r2P/4R1K1 b - - 1 38","moves":["d6h2","g1f1","h2h1"],"mateIn":2},
  {"fen":"8/1kpn3p/p2q1n1p/p7/6r1/1P6/4QK2/2R5 b - - 1 44","moves":["d6g3","f2f1","g3g1"],"mateIn":2},
  {"fen":"2k5/5p1N/n2r4/B1p2p2/8/1P2P1R1/2P1q3/7K b - - 1 42","moves":["e2f1","h1h2","d6h6","g3h3","h6h3"],"mateIn":3},
  {"fen":"4rBk1/p5Pp/5p2/4n3/3Pp3/1q1NKbP1/6B1/7R b - - 6 43","moves":["b3d3","e3f4","d3d2","f4f5","d2g5"],"mateIn":3},
  {"fen":"1Q6/5p1k/2P1bP1p/2p1B3/p1P3p1/P7/5PPP/3R2K1 w - - 6 38","moves":["b8b1","e6f5","b1f5","h7g8","d1d8"],"mateIn":3},
  {"fen":"2Bkr3/5p2/8/p2pB2p/P4P1P/6q1/3p1b2/Q6K b - - 1 37","moves":["g3f3","h1h2","f2g3","h2g1","f3f2","g1h1","f2h2"],"mateIn":4},
  {"fen":"r7/7r/bp2p1kP/3pb1P1/3np3/1Pp5/8/R1K4R b - - 1 33","moves":["e5f4","c1d1","a6e2","d1e1","f4g3"],"mateIn":3},
  {"fen":"1k6/2p2ppp/B7/Ppbrr3/6QP/2P1R3/2P2PP1/R1B2K2 w - - 0 24","moves":["g4c8","b8a7","c8b7"],"mateIn":2},
  {"fen":"1r2k2r/R7/n3p3/3pP1Q1/3N4/q1P4P/2PK1P2/6R1 w - - 3 32","moves":["g5g6","e8d8","d4c6","d8c8","g6e6"],"mateIn":3},
  {"fen":"3q1rk1/p4ppp/8/3ppP2/8/Pn2KPPN/1r5P/4R3 b - - 11 26","moves":["d8b6","e3d3","b6d4"],"mateIn":2},
  {"fen":"4r1rk/3Q3p/4Np2/1P1p1p2/p1pP1p1P/5q2/2K5/4R3 b - - 0 38","moves":["g8g2","c2b1","f3b3","b1a1","g2a2"],"mateIn":3},
  {"fen":"3k4/p1qn1pp1/2r4p/4r3/7P/6Q1/KP6/4r3 b - - 1 43","moves":["c6a6","g3a3","c7c4","b2b3","c4c2"],"mateIn":3},
  {"fen":"b1r1k3/5p2/1p2pBq1/2p5/4P1p1/Q7/PPP2PP1/3RR1K1 w - - 3 32","moves":["a3a6","c8b8","a6a7","g6f6","a7b8","e8e7","b8d8"],"mateIn":4},
  {"fen":"5r2/5k1p/p3n2P/Pp2Pp2/1Pb2p2/2R4P/3r4/6K1 b - - 6 41","moves":["f8g8","g1h1","c4d5","c3f3","d5f3"],"mateIn":3},
  {"fen":"4k2N/p1p3pp/2pbp3/3P4/4bP1q/P3P1n1/3B4/4Q1K1 b - - 0 34","moves":["h4h1","g1f2","h1g2"],"mateIn":2},
  {"fen":"4rr1k/ppp4p/3P1p2/5q2/1P4R1/5P2/7P/7K b - - 2 35","moves":["f5f3","g4g2","e8e1"],"mateIn":2},
  {"fen":"8/p1k2p1p/p5P1/5b2/5p1P/PPq5/K4P2/8 b - - 4 38","moves":["c3c2","a2a1","c2b1"],"mateIn":2},
  {"fen":"8/2Q3p1/p7/1b6/1k2P3/2p3P1/pB2BP2/3RK3 w - - 2 38","moves":["c7c3","b4a4","c3a3"],"mateIn":2},
  {"fen":"3r1k2/6b1/r7/2pb1q2/8/P1P2P2/1P4P1/K3R3 b - - 1 34","moves":["a6a3","b2a3","g7c3"],"mateIn":2},
  {"fen":"2k1r3/p1p5/2q1r3/5ppp/R2p2P1/Q1P4P/8/6K1 b - - 0 42","moves":["e6e2","a4a7","c6g2"],"mateIn":2},
  {"fen":"1k5N/6pp/p1Q5/3p1p2/B2P4/4P3/PP1K1PPP/7R w - - 4 25","moves":["c6b6","b8c8","h1c1"],"mateIn":2},
  {"fen":"7k/6p1/p2p3p/2n5/P2p1r2/7P/1PP2pP1/5K2 b - - 1 37","moves":["c5e4","g2g4","e4g3","f1g2","f2f1q","g2g3","f1f2"],"mateIn":4},
  {"fen":"6rk/p5qp/1pp5/3b2n1/3p1p2/P2B4/1PPN1RP1/5RK1 b - - 2 34","moves":["g5h3","g1h2","g7g3","h2h1","d5g2","f2g2","g3g2"],"mateIn":4},
  {"fen":"r5k1/6p1/8/4q2P/1p4bB/p4n2/P3R1K1/8 b - - 0 40","moves":["e5h2","g2f1","h2g1"],"mateIn":2},
  {"fen":"R7/p4kp1/4p3/5p2/6r1/BP2P3/2P5/4KRq1 b - - 6 40","moves":["g1e3","e1d1","g4d4"],"mateIn":2},
  {"fen":"4r1k1/p4pp1/3p1b1p/p4N2/b5P1/P3BP1P/1P1K3Q/q3R3 b - - 4 37","moves":["a1b2","d2d3","a4b5"],"mateIn":2},
  {"fen":"8/Q7/4p1k1/5bP1/7p/4P3/4NRBK/2r5 w - - 0 45","moves":["e2f4","g6g5","a7g7","f5g6","g7g6"],"mateIn":3},
  {"fen":"2R3B1/8/p1P3p1/7k/1p3B2/2P2P2/7K/4n3 w - - 0 44","moves":["g8f7","e1f3","h2g3","f3g5","c8h8","g5h7","h8h7"],"mateIn":4},
  {"fen":"4nk2/5b1p/2r4r/8/1P5P/5P2/8/R6K b - - 1 36","moves":["c6g6","a1a2","f7a2","f3f4","h6h4"],"mateIn":3},
  {"fen":"k3q3/1p6/6r1/3NB1p1/1b2P2p/3q3P/P4PK1/2r5 b - - 0 43","moves":["d3e4","f2f3","e4c2"],"mateIn":2},
  {"fen":"r1b3k1/2q3pp/2p1p3/4p3/p1Q3Pb/2P4P/PP5K/r7 b - - 3 28","moves":["e5e4","h2g2","c7g3"],"mateIn":2},
  {"fen":"4r1k1/R3b2p/5p2/3p3q/1p2nB2/4P2p/2p2PP1/N1R3K1 b - - 1 39","moves":["h3h2","f4h2","h5d1","c1d1","c2d1q"],"mateIn":3},
  {"fen":"4k1n1/3b4/4pr1p/2B3q1/pQ4P1/P6P/P5B1/4R1K1 w - - 1 43","moves":["b4b8","d7c8","b8c8","e8f7","c8f8","f7g6","f8g8"],"mateIn":4},
  {"fen":"r6r/2P3kp/5np1/1B2Q3/P2PP2n/8/6q1/4K3 b - - 4 44","moves":["h4f3","e1d1","g2d2"],"mateIn":2},
  {"fen":"r5k1/1q3ppp/p4n2/1pQ5/3r2b1/BP2PnN1/5PK1/2R4R b - - 2 23","moves":["f3h4","g2f1","b7g2","f1e1","h4f3","e1e2","d4d2"],"mateIn":4},
  {"fen":"1kb5/6R1/2B4p/2p1p3/1p2P1nP/1pP5/PB3R1P/4K3 w - - 2 35","moves":["f2f8","b3a2","g7b7","b8a8","f8c8"],"mateIn":3},
  {"fen":"6k1/1p3rp1/p3p2B/3qp3/P1r5/1P4R1/K4P2/8 b - - 0 41","moves":["f7f2","h6d2","d5d2","a2a3","d2c1"],"mateIn":3},
  {"fen":"4k3/3n3p/8/3P3P/q4b2/8/5P2/1K6 b - - 9 42","moves":["a4b3","b1a1","f4e5"],"mateIn":2},
  {"fen":"6k1/p2r1pp1/2b3N1/2P5/1K4nP/4q3/P5P1/8 b - - 1 38","moves":["d7d4","b4a5","d4a4"],"mateIn":2},
  {"fen":"2k3r1/1pp5/p7/3q1P2/5K1p/PPP2P2/7P/R7 b - - 0 32","moves":["d5d2","f4e5","d2d6","e5e4","g8e8"],"mateIn":3},
  {"fen":"2RR1bk1/1p3pp1/1r5p/8/8/4BQPP/5KP1/8 w - - 0 35","moves":["d8f8","g8h7","f3f5","b6g6","f8h8"],"mateIn":3},
  {"fen":"2kr1b1r/1p2p1pp/8/p1P1PpN1/1n4P1/1b2B3/RP2KP1P/5B1R b - - 0 19","moves":["b3d1","e2e1","b4c2"],"mateIn":2},
  {"fen":"2kr4/1pp3R1/4r3/5p2/3n3p/5p1P/P2qNK2/5R2 b - - 1 36","moves":["d2e3","f2e1","e3e2"],"mateIn":2},
  {"fen":"r5k1/6p1/7p/1pqb4/5n1P/3p1PP1/PP5K/3R1R2 b - - 2 29","moves":["c5c2","d1d2","c2d2","f1f2","d2f2","h2h1","d5f3"],"mateIn":4},
  {"fen":"5rk1/pp2p2p/2n1p1p1/2P5/8/P1r4P/5Pq1/3KR3 b - - 1 23","moves":["g2d5","d1e2","d5d3"],"mateIn":2},
  {"fen":"N1r3bk/1p5p/3B4/p1PPN3/8/1P4Q1/P4PPP/4R1K1 w - - 1 32","moves":["e5f7","g8f7","d6e5"],"mateIn":2},
  {"fen":"6k1/8/pp1p4/2pP1K1p/P1PB4/8/2Pbq1P1/8 b - - 3 39","moves":["g8f7","d4c5","e2g4"],"mateIn":2},
  {"fen":"R7/1k5b/pP2p3/4P2p/3n1pp1/1P1P4/2Q2P1R/7K w - - 5 41","moves":["c2c7","b7a8","c7a7"],"mateIn":2},
  {"fen":"6k1/7p/p3r3/P2Q2p1/3B1p2/2P2P2/5PqP/2RKR3 w - - 4 36","moves":["d5e6","g8f8","e6e8"],"mateIn":2},
  {"fen":"6k1/1n2Q3/2b4p/1p3P2/pB5p/1Pp3rP/P1P1R2K/5R2 w - - 4 44","moves":["e7f8","g8h7","e2e7","g3g7","e7g7"],"mateIn":3},
  {"fen":"8/1p3ppk/7p/1pR5/4bP2/4P2P/r2r4/4QK2 b - - 5 42","moves":["e4d3","f1g1","d2g2","g1h1","g2h2","h1g1","a2g2"],"mateIn":4},
  {"fen":"7k/q7/7p/P3pQp1/2BpP3/1P4PP/2PB2P1/1R5K w - - 2 37","moves":["f5f8","h8h7","f8g8"],"mateIn":2},
  {"fen":"1k6/R2R2pp/P7/2P2p2/4p3/1pb3P1/2P2P1P/6K1 w - - 0 45","moves":["d7b7","b8c8","a7a8"],"mateIn":2},
  {"fen":"4k3/3p1p2/p3p2p/Bp2P2p/8/3b4/PP3b1r/2RKR3 w - - 0 31","moves":["c1c8","e8e7","a5d8","e7e8","d8h4"],"mateIn":3},
  {"fen":"6k1/7p/2p3p1/2n1P1P1/1R6/6K1/1PB1q3/R4b2 b - - 3 37","moves":["e2g2","g3f4","c5e6","f4e3","g2e2"],"mateIn":3},
  {"fen":"rn1qr1k1/8/1pp2b2/1PP2Bpb/p7/P3BnP1/5P2/5K2 b - - 0 41","moves":["d8d1","f1g2","d1g1","g2h3","g1f1"],"mateIn":3},
  {"fen":"3k3r/p4p2/6p1/3PQ2p/8/5N2/PP1RB1PP/R1B2K2 w - - 1 27","moves":["e5d6","d8c8","e2a6"],"mateIn":2},
  {"fen":"2krr3/1b3p2/1pnb2pp/p7/2PP2P1/1P3B1P/PB2qPK1/3R2R1 b - - 1 23","moves":["e2f3","g2f1","f3e2","f1g2","c6d4"],"mateIn":3},
  {"fen":"3r3Q/1pk2p2/6q1/p2R4/8/P7/5PP1/6K1 w - - 1 33","moves":["h8d8","c7c6","d8d7","c6b6","d5b5","b6a7","d7b7"],"mateIn":4},
  {"fen":"6k1/1p2Q2p/3P4/6p1/1P4P1/P7/7P/1B1b3K w - - 9 43","moves":["b1a2","d1b3","a2b3","g8h8","e7e5"],"mateIn":3},
  {"fen":"5b1k/6pp/p7/4p1KP/p5P1/1q2PQ1r/5r2/2R5 b - - 5 37","moves":["f2f3","c1c3","f8e7"],"mateIn":2},
  {"fen":"r2R4/1b3R1p/1p2k3/1p6/8/1p2BNKp/P1P4P/3R4 w - - 0 32","moves":["f3g5","e6e5","e3d4"],"mateIn":2},
  {"fen":"6k1/6bp/pp4p1/2q2p2/P2R3Q/7R/3n2PP/6K1 b - - 6 43","moves":["g7d4","h4d4","c5d4","h3e3","d4e3","g1h1","e3e1"],"mateIn":4},
  {"fen":"5rk1/5ppQ/7p/4P3/pP6/P5P1/1n1r1q1P/4b2K b - - 3 34","moves":["g8h7","h2h3","f2f1"],"mateIn":2},
  {"fen":"5r2/p2k2pp/1n6/1p2Pp2/P7/3q3P/6P1/R1K4R b - - 3 30","moves":["f8c8","c1b2","c8c2","b2b1","d3b3"],"mateIn":3},
  {"fen":"2R5/k7/2B5/1p6/8/P7/2P5/1R5K w - - 1 45","moves":["b1b5","a7a6","c8a8"],"mateIn":2},
  {"fen":"3rr1k1/2p3p1/1p6/pq1nP2p/3K2bN/P1p4P/6R1/6R1 b - - 5 38","moves":["c7c5","d4e4","b5c4"],"mateIn":2},
  {"fen":"2q3rk/1p3p1n/5r2/6p1/1Q6/PP3p2/5P1P/5RK1 b - - 0 36","moves":["c8h3","b4g4","h3g4","g1h1","g4g2"],"mateIn":3},
  {"fen":"r2r2k1/1p5p/5pp1/1RBp4/pP2b3/P4q2/7P/R1K5 b - - 3 33","moves":["f3c3","c1d1","e4f3"],"mateIn":2},
  {"fen":"2R2b2/2R5/p3k3/1r3Np1/3B3P/p3PP2/6P1/6K1 w - - 2 37","moves":["c8e8","f8e7","e8e7","e6f5","g2g4","f5g6","c7c6"],"mateIn":4},
  {"fen":"1N4k1/3R3p/1bB3p1/5p2/1P2p3/2B4P/2K3P1/8 w - - 7 45","moves":["c6d5","g8f8","c3g7","f8e8","d5f7"],"mateIn":3},
  {"fen":"3N2k1/B2Q1p2/4pPpp/3b4/2p1P3/6b1/4BP1P/3R2K1 w - - 0 32","moves":["d7f7","g8h8","f7g7"],"mateIn":2},
  {"fen":"2r5/1pk2p2/p7/P7/1q1p1r2/2pR3P/5P2/3K2R1 b - - 1 38","moves":["b4b1","d1e2","c8e8","d3e3","d4d3"],"mateIn":3},
  {"fen":"4k2r/1p5p/p1n2pp1/2P3P1/3r3P/5b2/PP1b1P2/R1B1qBKR b k - 0 21","moves":["d4g4","g1h2","e1f2","f1g2","f2g2"],"mateIn":3},
  {"fen":"4Q3/3R2pk/5b2/1P6/3PN3/6BP/2q2PPK/8 w - - 5 43","moves":["e4f6","h7h6","e8h5"],"mateIn":2},
  {"fen":"2kr4/pp5p/2ppb2n/P2P1p2/R3PB1q/5B1P/1PP2Pr1/3QR2K b - - 1 21","moves":["h4h3","f4h2","h3h2"],"mateIn":2},
  {"fen":"3r4/p1R3p1/4pk2/2p2pR1/2P2P1P/P1r1PK2/5P2/8 w - - 4 32","moves":["c7g7","c3e3","f2e3","d8h8","g5g6"],"mateIn":3},
  {"fen":"r6r/p1nkpp1p/3p3b/2p1P2p/3p4/NP1q2P1/P4P2/R3K1R1 b - - 5 22","moves":["h6d2","e1d1","d2b4","d1c1","b4a3"],"mateIn":3},
  {"fen":"7k/2r2P1p/3b2p1/p7/P7/7P/1K3P2/4q2B b - - 0 45","moves":["e1d2","b2b3","c7c3"],"mateIn":2},
  {"fen":"5rk1/1Q2R1p1/1p3r1p/p2P4/3b4/5P1P/P5P1/5R1K w - - 0 45","moves":["e7g7","g8h8","g7h7","h8g8","b7g7"],"mateIn":3}
];

const keyOf = fen => String(fen || '').trim().split(/\s+/).slice(0, 4).join(' ');
export function puzzleBankKey(puzzle) { return keyOf(puzzle?.fen); }

/** Pick an unseen bank puzzle whose mate length suits the tier (0-1: mate in 2, 2: up to 3, 3: up to 4). */
export function pickBankPuzzle(seenKeys = new Set(), tier = 0, rng = Math.random) {
  const maxMate = Math.max(2, Math.min(4, 2 + Math.floor(Number(tier) / 1.5)));
  const unseen = PUZZLE_BANK.filter(item => !seenKeys.has(keyOf(item.fen)));
  if (!unseen.length) return null;
  const suited = unseen.filter(item => item.mateIn <= maxMate);
  const pool = suited.length ? suited : unseen;
  // Prefer the hardest suited length so progress is felt, but keep some variety.
  const hardest = Math.max(...pool.map(item => item.mateIn));
  const top = pool.filter(item => item.mateIn === hardest);
  const chosen = rng() < 0.65 && top.length ? top : pool;
  return chosen[Math.floor(rng() * chosen.length)];
}

/** Deterministic daily puzzle from the verified bank (same date => same puzzle for every player). */
export function pickDailyBankPuzzle(dateKey) {
  const text = `covua-vila-bank:${String(dateKey || '').slice(0, 10)}`;
  let hash = 2166136261;
  for (let i = 0; i < text.length; i += 1) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
  return PUZZLE_BANK[hash % PUZZLE_BANK.length];
}
