/** Small on-device crash journal: keeps the last few uncaught errors so a phone user can copy a report.
 * Pure functions take the storage object as an argument so they are unit-testable without a browser. */
export const CRASH_LOG_KEY = 'vila.chess.crash-log.v1';
export const CRASH_LOG_LIMIT = 20;

const clip = (value, max) => String(value ?? '').slice(0, max);

/** Remove anything that looks like a credential before it can reach storage or a copied report. */
export function scrubSecrets(text) {
  return String(text ?? '')
    .replace(/Bearer\s+[A-Za-z0-9._~+/=-]{8,}/gi, 'Bearer [ẩn]')
    .replace(/(social_token|token|password|mat_khau|secret|authorization)=([^&\s"']+)/gi, '$1=[ẩn]')
    .replace(/("(?:token|password|secret|authorization)"\s*:\s*")[^"]*(")/gi, '$1[ẩn]$2');
}

export function readCrashes(storage) {
  try {
    const parsed = JSON.parse(storage?.getItem(CRASH_LOG_KEY) || '[]');
    return Array.isArray(parsed) ? parsed.filter(item => item && typeof item === 'object').slice(-CRASH_LOG_LIMIT) : [];
  } catch { return []; }
}

/** Record one error. Identical consecutive errors are merged into a counter so a render loop cannot flood storage. */
export function recordCrash(storage, entry, now = Date.now()) {
  const record = {
    t: now,
    kind: clip(entry?.kind || 'error', 24),
    message: scrubSecrets(clip(entry?.message || 'Lỗi không rõ', 400)),
    where: scrubSecrets(clip(entry?.where || '', 160)),
    stack: scrubSecrets(clip(entry?.stack || '', 900)),
    view: clip(entry?.view || '', 40),
    version: clip(entry?.version || '', 24),
    count: 1,
  };
  const list = readCrashes(storage);
  const last = list[list.length - 1];
  if (last && last.message === record.message && last.where === record.where && now - last.t < 60_000) {
    last.count = (last.count || 1) + 1;
    last.t = now;
  } else {
    list.push(record);
  }
  const trimmed = list.slice(-CRASH_LOG_LIMIT);
  try { storage?.setItem(CRASH_LOG_KEY, JSON.stringify(trimmed)); } catch { /* storage full or disabled */ }
  return trimmed;
}

export function clearCrashes(storage) {
  try { storage?.removeItem(CRASH_LOG_KEY); } catch { /* ignore */ }
}

export function formatCrashReport(list, env = {}) {
  const lines = [
    'VILA CHESS · BÁO CÁO LỖI',
    `Phiên bản: ${clip(env.version, 24) || 'không rõ'}`,
    `Thiết bị: ${scrubSecrets(clip(env.userAgent, 200)) || 'không rõ'}`,
    `Số lỗi đã ghi: ${list.length}`,
    '',
  ];
  list.slice().reverse().forEach((item, index) => {
    const when = new Date(item.t).toISOString().replace('T', ' ').slice(0, 19);
    lines.push(`#${index + 1} [${when}] ${item.kind}${item.count > 1 ? ` ×${item.count}` : ''}${item.view ? ` · màn ${item.view}` : ''}`);
    lines.push(item.message);
    if (item.where) lines.push(`tại ${item.where}`);
    if (item.stack) lines.push(item.stack);
    lines.push('');
  });
  return lines.join('\n').trim();
}
