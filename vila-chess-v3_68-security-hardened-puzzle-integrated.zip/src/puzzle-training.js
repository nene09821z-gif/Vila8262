/**
 * Adaptive puzzle training: spaced-repetition review of missed puzzles plus per-theme weakness stats.
 * Pure functions (state in -> state out) with a thin localStorage wrapper, so everything is unit-tested
 * without a DOM. Used by the Puzzle view in main.js.
 *
 * Review queue: a Leitner system. A puzzle you miss goes to box 0 and comes back after a short wait; every clean
 * re-solve moves it up one box (longer wait); a miss sends it back to box 0. Clean-solving the last box
 * graduates it out of the queue.
 */
export const PUZZLE_TRAINING_KEY = 'vila.chess.puzzles.training.v1';
export const REVIEW_QUEUE_LIMIT = 150;
export const REVIEW_BOX_INTERVALS_MS = Object.freeze([3 * 60_000, 24 * 3_600_000, 3 * 24 * 3_600_000, 7 * 24 * 3_600_000, 21 * 24 * 3_600_000]);
/** A due review is served at most once every N puzzles so reviews never crowd out new material. */
export const REVIEW_EVERY = 3;
const TAG_LIMIT = 80;

const fenKey = fen => String(fen || '').trim().split(/\s+/).slice(0, 4).join(' ');
const finite = (value, fallback = 0) => (Number.isFinite(Number(value)) ? Number(value) : fallback);

export function emptyTrainingState() {
  return { v: 1, queue: [], stats: { total: 0, clean: 0, assisted: 0, failed: 0, solveMs: 0, cleanTimed: 0, byTag: {} }, sinceReview: 0 };
}

/** Theme tags used for weakness statistics, e.g. ['mateIn3', 'fork']. */
export function puzzleTags(puzzle) {
  const tags = [];
  const mateIn = Math.floor(finite(puzzle?.mateIn));
  if (mateIn >= 1 && mateIn <= 9) tags.push(`mateIn${mateIn}`);
  const themes = Array.isArray(puzzle?.themes) ? puzzle.themes : [];
  for (const theme of themes.slice(0, 6)) {
    const tag = String(theme || '').trim().replace(/[^A-Za-z0-9]/g, '').slice(0, 32);
    if (tag && !tags.includes(tag)) tags.push(tag);
  }
  return tags;
}

function sanitizeEntry(raw) {
  const fen = String(raw?.fen || '').trim();
  const moves = Array.isArray(raw?.moves) ? raw.moves.filter(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(String(move))).map(String) : [];
  if (!fen || !moves.length || moves.length !== (Array.isArray(raw?.moves) ? raw.moves.length : -1)) return null;
  const box = Math.max(0, Math.min(REVIEW_BOX_INTERVALS_MS.length - 1, Math.floor(finite(raw.box))));
  return {
    key: fenKey(fen), fen, moves,
    mateIn: Math.max(0, Math.min(9, Math.floor(finite(raw.mateIn)))),
    themes: Array.isArray(raw.themes) ? raw.themes.map(String).slice(0, 8) : [],
    rating: Number.isFinite(Number(raw.rating)) && raw.rating !== null ? Number(raw.rating) : null,
    box, due: finite(raw.due), misses: Math.max(0, Math.floor(finite(raw.misses))),
  };
}

/** Defensive normaliser: unknown/corrupt storage content never throws and never grows unbounded. */
export function normalizeTrainingState(raw) {
  const base = emptyTrainingState();
  if (!raw || typeof raw !== 'object') return base;
  const seen = new Set();
  for (const item of Array.isArray(raw.queue) ? raw.queue : []) {
    const entry = sanitizeEntry(item);
    if (!entry || seen.has(entry.key)) continue;
    seen.add(entry.key); base.queue.push(entry);
  }
  base.queue = base.queue.slice(-REVIEW_QUEUE_LIMIT);
  const stats = raw.stats && typeof raw.stats === 'object' ? raw.stats : {};
  for (const field of ['total', 'clean', 'assisted', 'failed', 'solveMs', 'cleanTimed']) base.stats[field] = Math.max(0, finite(stats[field]));
  const byTag = stats.byTag && typeof stats.byTag === 'object' ? stats.byTag : {};
  for (const [tag, value] of Object.entries(byTag).slice(0, TAG_LIMIT)) {
    if (!/^[A-Za-z0-9]{1,32}$/.test(tag)) continue;
    const attempts = Math.max(0, Math.floor(finite(value?.n))), clean = Math.max(0, Math.min(attempts, Math.floor(finite(value?.clean))));
    if (attempts) base.stats.byTag[tag] = { n: attempts, clean };
  }
  base.sinceReview = Math.max(0, Math.min(1000, Math.floor(finite(raw.sinceReview))));
  return base;
}

/**
 * Record how a puzzle ended.
 *  outcome 'clean'    – solved with no wrong move and no hint
 *  outcome 'assisted' – solved but with a slip or a hint
 *  outcome 'failed'   – a wrong move was made (first slip) or the solution was revealed
 * Stats count each puzzle once per final outcome; pass `countStats:false` for an intermediate 'failed' mark.
 */
export function recordPuzzleResult(state, puzzle, outcome, { now = Date.now(), solveMs = 0, countStats = true } = {}) {
  const next = normalizeTrainingState(state);
  const entry = sanitizeEntry({ ...puzzle, box: 0, due: 0 });
  if (!entry || !['clean', 'assisted', 'failed'].includes(outcome)) return next;
  if (countStats) {
    const stats = next.stats;
    stats.total += 1; stats[outcome] += 1;
    if (outcome === 'clean' && finite(solveMs) > 0) { stats.solveMs += Math.min(10 * 60_000, finite(solveMs)); stats.cleanTimed += 1; }
    for (const tag of puzzleTags(puzzle)) {
      if (!stats.byTag[tag] && Object.keys(stats.byTag).length >= TAG_LIMIT) continue;
      const slot = stats.byTag[tag] || (stats.byTag[tag] = { n: 0, clean: 0 });
      slot.n += 1; if (outcome === 'clean') slot.clean += 1;
    }
  }
  const index = next.queue.findIndex(item => item.key === entry.key);
  const existing = index >= 0 ? next.queue[index] : null;
  if (outcome === 'failed') {
    const updated = { ...entry, misses: (existing?.misses || 0) + 1, box: 0, due: now + REVIEW_BOX_INTERVALS_MS[0] };
    if (existing) next.queue.splice(index, 1);
    next.queue.push(updated);
  } else if (outcome === 'assisted') {
    // Solved with help: keep it in the queue at its current box (or start it at box 0) and re-schedule that box.
    const box = existing ? existing.box : 0;
    const updated = { ...entry, misses: existing?.misses || 0, box, due: now + REVIEW_BOX_INTERVALS_MS[box] };
    if (existing) next.queue.splice(index, 1);
    next.queue.push(updated);
  } else if (existing) {
    if (existing.box >= REVIEW_BOX_INTERVALS_MS.length - 1) next.queue.splice(index, 1);
    else { existing.box += 1; existing.due = now + REVIEW_BOX_INTERVALS_MS[existing.box]; }
  }
  next.queue = next.queue.slice(-REVIEW_QUEUE_LIMIT);
  return next;
}

export function dueReviewCount(state, now = Date.now()) {
  return normalizeTrainingState(state).queue.filter(item => item.due <= now).length;
}

/**
 * Decide whether the next puzzle should be a review. Returns { puzzle, state } where `puzzle` is null when a normal
 * puzzle should be served. Each call counts as one served puzzle for pacing.
 */
export function takeReviewPuzzle(state, { now = Date.now(), skipKeys = new Set(), every = REVIEW_EVERY } = {}) {
  const next = normalizeTrainingState(state);
  const due = next.queue.filter(item => item.due <= now && !skipKeys.has(item.key)).sort((a, b) => a.due - b.due);
  if (!due.length || next.sinceReview + 1 < Math.max(1, every)) { next.sinceReview = Math.min(1000, next.sinceReview + 1); return { puzzle: null, state: next }; }
  next.sinceReview = 0;
  const chosen = due[0];
  return { puzzle: { fen: chosen.fen, moves: [...chosen.moves], mateIn: chosen.mateIn, themes: [...chosen.themes], rating: chosen.rating, initialPly: 0, review: true, reviewBox: chosen.box, reviewMisses: chosen.misses }, state: next };
}

/** Weakest themes first (needs at least `minAttempts` tries so one slip does not label a theme "weak"). */
export function weakestTags(state, { minAttempts = 3, limit = 3 } = {}) {
  const byTag = normalizeTrainingState(state).stats.byTag;
  return Object.entries(byTag)
    .filter(([, value]) => value.n >= minAttempts && value.clean / value.n < 0.75)
    .map(([tag, value]) => ({ tag, attempts: value.n, clean: value.clean, rate: value.clean / value.n }))
    .sort((a, b) => a.rate - b.rate || b.attempts - a.attempts)
    .slice(0, Math.max(0, limit));
}

export function trainingSummary(state, now = Date.now()) {
  const data = normalizeTrainingState(state);
  const { total, clean, cleanTimed, solveMs } = data.stats;
  return {
    total, clean, assisted: data.stats.assisted, failed: data.stats.failed,
    accuracy: total ? Math.round((clean / total) * 100) : null,
    avgCleanSolveSec: cleanTimed ? Math.round(solveMs / cleanTimed / 1000) : null,
    reviewQueue: data.queue.length, reviewDue: data.queue.filter(item => item.due <= now).length,
    weakest: weakestTags(data),
  };
}

export function loadTrainingState(storage = globalThis.localStorage, key = PUZZLE_TRAINING_KEY) {
  try { return normalizeTrainingState(JSON.parse(storage?.getItem?.(key) || 'null')); } catch { return emptyTrainingState(); }
}

export function saveTrainingState(state, storage = globalThis.localStorage, key = PUZZLE_TRAINING_KEY) {
  const clean = normalizeTrainingState(state);
  try { storage?.setItem?.(key, JSON.stringify(clean)); } catch { /* storage full or blocked: training is best-effort */ }
  return clean;
}
