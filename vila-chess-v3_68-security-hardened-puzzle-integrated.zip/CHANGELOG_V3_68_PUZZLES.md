# Câu đố cờ — nâng cấp luyện tập thích ứng

## Mới
- **Ôn lại câu đã sai (lặp lại ngắt quãng, kiểu Leitner)** — `src/puzzle-training.js`.
  Câu sai nước đầu, xem lời giải hoặc giải có gợi ý sẽ vào hàng chờ ôn. Giải sạch (không sai, không gợi ý) thì
  câu lùi xa dần: 3 phút → 1 ngày → 3 ngày → 7 ngày → 21 ngày rồi "tốt nghiệp". Sai lại thì về hộp đầu.
  Câu ôn chỉ chen vào tối đa 1/3 số câu, chỉ khi đến hạn, và không bao giờ xuất hiện trong Puzzle Rush / Sinh tồn / Thử thách ngày.
- **Bảng thống kê luyện tập** trong màn Puzzle: số câu đã làm, tỉ lệ giải sạch, thời gian trung bình, số câu ôn đến hạn
  và **chủ đề yếu nhất** (cần ≥ 3 lần làm, tỉ lệ giải sạch < 75%).
- Kho đề chiếu hết đã xác minh bằng Stockfish 19 tăng từ 33 lên 136 câu (+103: 47 mate-in-2, 41 mate-in-3, 15 mate-in-4), mỗi câu được kiểm lại ở depth 20: nước đầu duy nhất, đối thủ đi phòng thủ tốt nhất.

## Kiểm thử
- `tests/puzzle-training.test.js` (10 test) và `tests/puzzle-training-wiring.test.js` (2 test), đã thêm vào `npm run test:static`.
- Dữ liệu lưu ở `vila.chess.puzzles.training.v1` (localStorage), có giới hạn kích thước và chịu được dữ liệu hỏng.
