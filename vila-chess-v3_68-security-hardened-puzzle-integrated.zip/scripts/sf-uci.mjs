// Tiny Stockfish UCI driver for Node (audit/mining tools only; not shipped to the browser).
// Usage: const sf = await StockfishNode.start(enginePath); await sf.analyse(fen, {depth, multipv});
import { spawn } from 'node:child_process';
import { copyFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

/** Copies the bundled lite build to a temp CommonJS folder (package.json is "type":"module"). */
export function prepareEngine() {
  const dir = join(tmpdir(), 'vila-sf-node');
  mkdirSync(dir, { recursive: true });
  writeFileSync(join(dir, 'package.json'), '{}');
  copyFileSync(join(here, '../public/engine/stockfish-19-lite-single.js'), join(dir, 'sf.cjs'));
  copyFileSync(join(here, '../public/engine/stockfish-19-lite-single.wasm'), join(dir, 'sf.wasm'));
  return join(dir, 'sf.cjs');
}

export class StockfishNode {
  static async start(path = prepareEngine()) {
    const sf = new StockfishNode(path);
    await sf.send('uci', /uciok/);
    await sf.send('isready', /readyok/);
    return sf;
  }
  constructor(path) {
    this.proc = spawn(process.execPath, [path], { stdio: ['pipe', 'pipe', 'ignore'] });
    this.buffer = '';
    this.waiters = [];
    this.proc.stdout.on('data', chunk => {
      this.buffer += chunk;
      let index;
      while ((index = this.buffer.indexOf('\n')) >= 0) {
        const line = this.buffer.slice(0, index).trim();
        this.buffer = this.buffer.slice(index + 1);
        for (const waiter of [...this.waiters]) waiter(line);
      }
    });
  }
  write(cmd) { this.proc.stdin.write(`${cmd}\n`); }
  send(cmd, until) {
    return new Promise(resolve => {
      const lines = [];
      const waiter = line => {
        lines.push(line);
        if (until.test(line)) { this.waiters = this.waiters.filter(w => w !== waiter); resolve(lines); }
      };
      this.waiters.push(waiter);
      this.write(cmd);
    });
  }
  /** Returns MultiPV results from the side-to-move view: [{multipv, depth, cp|mate, pv:[uci...]}]. */
  async analyse(fen, { depth = 16, multipv = 3, moves = [] } = {}) {
    this.write('ucinewgame');
    this.write(`setoption name MultiPV value ${multipv}`);
    this.write(`position fen ${fen}${moves.length ? ` moves ${moves.join(' ')}` : ''}`);
    const lines = await this.send(`go depth ${depth}`, /^bestmove/);
    const last = new Map();
    for (const line of lines) {
      const m = line.match(/^info depth (\d+).* multipv (\d+) score (cp|mate) (-?\d+).* pv (.+)$/);
      if (m) last.set(Number(m[2]), { multipv: Number(m[2]), depth: Number(m[1]), [m[3]]: Number(m[4]), pv: m[5].split(' ') });
    }
    return [...last.values()].sort((a, b) => a.multipv - b.multipv);
  }
  /** FEN after replaying `moves` from `fen` (uses the engine's own legal-move code via "d"). */
  async fenAfter(fen, moves = []) {
    this.write(`position fen ${fen}${moves.length ? ` moves ${moves.join(' ')}` : ''}`);
    const lines = await this.send('d', /^Checkers:/);
    const row = lines.find(line => line.startsWith('Fen:'));
    return row ? row.slice(4).trim() : null;
  }
  /** Plays one move chosen by the engine itself (weak skill = varied, error-prone games). */
  async quickMoves(fen, { multipv = 4, depth = 6 } = {}) {
    return this.analyse(fen, { depth, multipv });
  }
  quit() { try { this.write('quit'); } catch { /* ignore */ } this.proc.kill(); }
}
