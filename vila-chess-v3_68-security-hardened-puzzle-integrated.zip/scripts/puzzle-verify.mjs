// Shared verifier for forced-mate puzzles. A puzzle is { fen, moves:[player, reply, player, ...], mateIn }.
// A puzzle is "clean" when, judged by Stockfish at the given depth:
//  * the player is mated-in-exactly `mateIn` from the root and the stored line follows it;
//  * at every player move except the last, the stored move is the ONLY move that keeps the forced
//    mate within the remaining length (the last move may have several mates: the app accepts any);
//  * every stored opponent reply is a best (longest-resisting) defence.
export async function verifyMatePuzzle(sf, puzzle, depth = 20) {
  const problems = [];
  const { fen, moves, mateIn } = puzzle;
  if (moves.length !== 2 * mateIn - 1) return [`line length ${moves.length} does not match mate in ${mateIn}`];
  for (let ply = 0; ply < moves.length && problems.length === 0; ply += 1) {
    const prefix = moves.slice(0, ply);
    if (ply % 2 === 0) {
      const remaining = mateIn - ply / 2;
      const lines = await sf.analyse(fen, { depth, multipv: remaining > 1 ? 2 : 1, moves: prefix });
      const top = lines[0];
      if (top?.mate !== remaining) { problems.push(`ply ${ply}: expected mate ${remaining}, got ${JSON.stringify(top)}`); break; }
      if (remaining > 1) {
        if (top.pv[0] !== moves[ply]) problems.push(`ply ${ply}: stored ${moves[ply]} but engine best ${top.pv[0]}`);
        const alt = lines[1];
        if (alt && alt.mate > 0 && alt.mate <= remaining) problems.push(`ply ${ply}: second mating move ${alt.pv[0]} (mate ${alt.mate})`);
      } else {
        const final = await sf.analyse(fen, { depth: 4, multipv: 1, moves: [...prefix, moves[ply]] });
        if (final.length) problems.push(`ply ${ply}: final move ${moves[ply]} is not checkmate`);
      }
    } else {
      const lines = await sf.analyse(fen, { depth, multipv: 40, moves: prefix });
      const top = lines[0];
      const remaining = mateIn - (ply + 1) / 2;
      if (top?.mate !== -remaining) { problems.push(`ply ${ply}: expected opponent mated in ${remaining}, got ${JSON.stringify(top)}`); break; }
      const bestDefences = lines.filter(line => line.mate === top.mate).map(line => line.pv[0]);
      if (!bestDefences.includes(moves[ply])) problems.push(`ply ${ply}: stored reply ${moves[ply]} is not a best defence (${bestDefences.join(',')})`);
    }
  }
  return problems;
}
