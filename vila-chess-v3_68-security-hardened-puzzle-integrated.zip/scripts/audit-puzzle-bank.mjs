// Audits the bundled puzzle bank with real Stockfish 19 (see puzzle-verify.mjs for the rules).
// Run: node scripts/audit-puzzle-bank.mjs   (AUDIT_DEPTH=20 by default; ~4-6 minutes for 40+ puzzles)
import { PUZZLE_BANK } from '../src/puzzle-bank.js';
import { StockfishNode } from './sf-uci.mjs';
import { verifyMatePuzzle } from './puzzle-verify.mjs';

const DEPTH = Number(process.env.AUDIT_DEPTH || 20);
const sf = await StockfishNode.start();
let bad = 0;

for (const [index, puzzle] of PUZZLE_BANK.entries()) {
  const problems = await verifyMatePuzzle(sf, puzzle, DEPTH);
  if (problems.length) bad += 1;
  console.log(`${problems.length ? 'BAD' : 'OK '} #${index} mate-in-${puzzle.mateIn} ${puzzle.fen.split(' ')[0].slice(0, 20)} ${problems.join(' | ')}`);
}
sf.quit();
// (pass list is printed in the log; see OK lines)
console.log(`\n${PUZZLE_BANK.length - bad}/${PUZZLE_BANK.length} puzzles verified at depth ${DEPTH}`);
process.exit(bad ? 1 : 0);
