// Mines forced-mate puzzles from Stockfish self-play and keeps only ones that pass puzzle-verify.mjs.
// Usage: node scripts/mine-puzzles.mjs <seconds> <outFile.json> [seed]
import { writeFileSync } from 'node:fs';
import { PUZZLE_BANK } from '../src/puzzle-bank.js';
import { StockfishNode } from './sf-uci.mjs';
import { verifyMatePuzzle } from './puzzle-verify.mjs';

const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const seconds = Number(process.argv[2] || 120);
const out = process.argv[3] || '/tmp/mined.json';
let seed = Number(process.argv[4] || 1) >>> 0 || 1;
const rnd = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
const key = fen => fen.split(' ').slice(0, 4).join(' ');
const seen = new Set(PUZZLE_BANK.map(p => key(p.fen)));
const found = [];
const deadline = Date.now() + seconds * 1000;
const sf = await StockfishNode.start();
const score = l => l.mate != null ? (l.mate > 0 ? 100000 - l.mate : -100000 - l.mate) : l.cp;

while (Date.now() < deadline) {
  const moves = [];
  for (let ply = 0; ply < 90 && Date.now() < deadline; ply += 1) {
    const lines = await sf.analyse(START, { depth: 5, multipv: 4, moves });
    if (!lines.length) break;
    // Error-prone play: usually a near-best move, sometimes a weaker one, so mating chances appear.
    const pool = rnd() < 0.25 ? lines : lines.filter(l => score(lines[0]) - score(l) < 150);
    moves.push(pool[Math.floor(rnd() * pool.length)].pv[0]);
    if (ply < 16 || ply % 2 === 1 && rnd() < 0.5) continue;
    const fen = await sf.fenAfter(START, moves);
    if (!fen || seen.has(key(fen))) continue;
    const screen = await sf.analyse(fen, { depth: 10, multipv: 2 });
    const top = screen[0];
    if (top?.mate == null || top.mate < 2 || top.mate > 4) continue;
    const second = screen[1];
    if (second && second.mate > 0 && second.mate <= top.mate) continue;
    // Build the stored line from the engine's own best play, then verify it strictly.
    const line = [];
    for (let i = 0; i < 2 * top.mate - 1; i += 1) {
      const r = await sf.analyse(fen, { depth: 16, multipv: 1, moves: line });
      if (!r[0]) break;
      line.push(r[0].pv[0]);
    }
    const puzzle = { fen, moves: line, mateIn: top.mate };
    if ((await verifyMatePuzzle(sf, puzzle, 20)).length === 0) {
      seen.add(key(fen)); found.push(puzzle);
      writeFileSync(out, JSON.stringify(found));
      console.log(`found #${found.length} mate-in-${top.mate} ${fen}`);
    }
    break; // start a fresh game after each candidate attempt to maximise variety
  }
}
sf.quit();
writeFileSync(out, JSON.stringify(found));
console.log(`done: ${found.length}`);
