# VILA Chess — Puzzle training integration QA

## Integrated changes

- Added `src/puzzle-training.js`: bounded local training history, miss queue, Leitner-style review intervals, solve accuracy, average clean solve time, and weak-theme estimates.
- Merged the puzzle-training wiring into `src/main.js`: persist puzzle outcomes, serve review puzzles in untimed modes at a paced interval, keep reviews out of Puzzle Rush and Survival, and render the training summary in the puzzle view.
- Added 96 curated positions to `src/puzzle-bank.js`; the bank now contains 136 unique normalized positions.
- Added the training styles to `src/achievements.css` and regenerated `src/vila-professional.css`, the CSS bundle imported by the app.
- Registered the new training regression tests and the bank-integrity test in `package.json`'s `test:static` command.
- Fixed the Survival last-life path to record a final failed attempt, and ensured absent puzzle ratings remain `null` rather than becoming `0`.

## Verification completed

- Puzzle-focused test run: 44/44 passed.
- Additional release/stability regression run: 42/42 passed.
- `node --check` passed for `src/main.js`, `src/puzzle-training.js`, and `src/puzzle-bank.js`.
- Puzzle bank format check: 136 entries, 136 unique normalized positions, valid UCI strings, and line lengths consistent with each declared mate length.
- Stockfish 19 Lite verification: all 136/136 entries passed the project verifier at depth 20. Per-position results are in `reports/puzzle-bank-audit-depth20.txt`.
- CSS bundle check: `.puzzle-training-stats` exists in generated `src/vila-professional.css`.

## Build limitation

A full Vite/Android build was **not completed locally**. `npm ci --ignore-scripts --no-audit --no-fund` timed out because requests to `registry.npmjs.org` failed with `EAI_AGAIN` (DNS/network resolution). Therefore this report does not claim a successful APK build or device test. The existing GitHub build workflows were preserved so the project can be built in an environment where npm dependencies can be downloaded.
