import test from 'node:test';
import assert from 'node:assert/strict';
import worker from '../cloudflare/src/index.js';

const env = { CORS_ORIGINS: 'https://vila.example' };
function req(path, { origin = 'https://vila.example', method = 'GET', body, ip = '198.51.100.77' } = {}) {
  const headers = { 'CF-Connecting-IP': ip };
  if (origin) headers.Origin = origin;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return new Request(`https://vila-test.workers.dev${path}`, {
    method, headers, ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

test('security headers are returned and disallowed origins cannot use browser API access', async () => {
  const denied = await worker.fetch(req('/api/health', { origin: 'https://attacker.example' }), env);
  assert.equal(denied.status, 403);
  assert.equal(denied.headers.get('Access-Control-Allow-Origin'), null);
  assert.equal(denied.headers.get('X-Content-Type-Options'), 'nosniff');
  assert.equal(denied.headers.get('X-Frame-Options'), 'DENY');
  assert.match(denied.headers.get('Content-Security-Policy'), /default-src 'none'/);
  assert.equal(denied.headers.get('Strict-Transport-Security'), 'max-age=31536000; includeSubDomains');

  const allowed = await worker.fetch(req('/api/health'), env);
  assert.equal(allowed.status, 200);
  assert.equal(allowed.headers.get('Access-Control-Allow-Origin'), 'https://vila.example');
  assert.equal((await allowed.json()).ok, true);
});

test('CORS preflight rejects unapproved origins', async () => {
  const response = await worker.fetch(req('/api/social/auth/login', { method: 'OPTIONS', origin: 'https://attacker.example' }), env);
  assert.equal(response.status, 403);
  assert.equal(response.headers.get('Access-Control-Allow-Origin'), null);
});

test('Lichess proxy has an edge request cap and Retry-After response', async () => {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  globalThis.fetch = async () => {
    upstreamCalls++;
    return new Response(JSON.stringify({ id: 'test-id', username: 'Tester', perfs: {} }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  };
  try {
    let last;
    for (let i = 0; i < 21; i++) {
      last = await worker.fetch(req('/api/lichess/account', {
        method: 'POST', body: { token: 'fake-token' }, ip: '198.51.100.212'
      }), env);
      if (i < 20) assert.equal(last.status, 200);
    }
    assert.equal(last.status, 429);
    assert.ok(Number(last.headers.get('Retry-After')) > 0);
    assert.equal(upstreamCalls, 20, 'the blocked request must not contact Lichess');
  } finally { globalThis.fetch = originalFetch; }
});


test('streamed JSON body is capped even when Content-Length is absent', async () => {
  const originalFetch = globalThis.fetch;
  let upstreamCalls = 0;
  globalThis.fetch = async () => {
    upstreamCalls++;
    return new Response(JSON.stringify({ id: 'should-not-run', username: 'tester', perfs: {} }), { status: 200 });
  };
  try {
    const payload = JSON.stringify({ token: 'not-a-real-token', padding: 'x'.repeat(66_000) });
    const request = new Request('https://vila-test.workers.dev/api/lichess/account', {
      method: 'POST',
      headers: { Origin: 'https://vila.example', 'Content-Type': 'application/json', 'CF-Connecting-IP': '198.51.100.88' },
      body: payload
    });
    assert.equal(request.headers.get('Content-Length'), null, 'test must exercise streamed length enforcement');
    const response = await worker.fetch(request, env);
    assert.equal(response.status, 400);
    assert.match((await response.json()).error, /quá lớn/i);
    assert.equal(upstreamCalls, 0, 'oversized body must not contact upstream');
  } finally { globalThis.fetch = originalFetch; }
});
