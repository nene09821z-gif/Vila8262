import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { resolveReviewMoveTimeMs } from '../src/engine-budgets.js';
import { DEFAULTS, normalizeSettings } from '../src/settings-schema.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');

test('full-game review defaults to a fast ~1s/position tier and legacy implicit max migrates', () => {
  assert.equal(DEFAULTS.reviewQuality, 'fast');
  assert.ok(resolveReviewMoveTimeMs({ reviewQuality: 'fast', analysisMoveTimeMs: 2600 }) <= 1200);
  assert.ok(resolveReviewMoveTimeMs({ reviewQuality: 'fast', analysisMoveTimeMs: 1000 }) >= 600);
  assert.equal(normalizeSettings({ reviewQuality: 'max' }).reviewQuality, 'fast');
  assert.equal(normalizeSettings({ reviewQuality: 'max', reviewQualityPreferenceSet: true }).reviewQuality, 'max');
  assert.equal(resolveReviewMoveTimeMs({ reviewQuality: 'max' }), 8000, 'max stays opt-in');
});

test('review uses one lane and short book-move searches in fast mode', () => {
  assert.match(main, /settings\.reviewQuality === 'fast'\) \? 1 : 2/);
  assert.match(main, /position\.bookMove \? Math\.min\(resolveReviewMoveTimeMs\(settings\), 450\)/);
});

test('match action bar exposes a quick analysis button wired to review or mid-game analysis', () => {
  assert.match(main, /id="analyzeQuickBtn"/);
  assert.match(main, /\$\('#analyzeQuickBtn'\)\?\.addEventListener/);
  assert.match(main, /rankedFairPlayLocked\(\)\) \{ rankedFairPlayNotice\(\); return; \}\n    const finished/);
});

test('Rubik patches the DOM in place, supports live drag, tap-to-turn, timer and best time', () => {
  for (const token of ['function updateRubikDom', 'function formatRubikTime', 'startRubikTimerIfArmed', "vila.rubik.best", "stage.addEventListener('pointermove'"]) {
    assert.ok(main.includes(token), `missing ${token}`);
  }
  assert.match(css, /\.rubik-stage\s*\{[^}]*touch-action:none/s);
});

test('online matchmaking polish styles are present and respect reduced motion', () => {
  assert.match(css, /\.ranked-queue-orbit/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
});

test('ranked matches move optimistically, poll fast and block export while live', () => {
  assert.match(main, /Optimistic: show the legal move at once/);
  assert.match(main, /rankedMatchState\?\.match\?\.status === 'active' \? 800 : 1800/);
  assert.match(main, /for \(const type of \['copy', 'cut', 'paste', 'contextmenu', 'dragstart', 'selectstart'\]\)/);
  assert.match(main, /^installRankedFairPlayGuards\(\);$/m);
  assert.match(css, /body\.ranked-fairplay/);
});

test('premove fires after the bot slide instead of in the same frame', () => {
  assert.match(main, /const PREMOVE_FIRE_DELAY_MS = 170/);
  assert.match(main, /function isPremoveShown\(\)/);
  assert.match(main, /setTimeout\(firePremove, delay\)/);
  assert.match(main, /if \(gameEpoch !== armedEpoch\) \{ premoveQueue = \[\]/);
});

test('puzzle selection retries more, rotates unused puzzles randomly and varies themes', () => {
  assert.match(main, /attempt < 6 && Date\.now\(\) < loadDeadline; attempt \+= 1\) \{\n        const requestController/);
  assert.match(main, /puzzleRecentThemes\.slice\(-2\)\.includes\(candidate\.theme\)/);
  assert.match(main, /Math\.floor\(puzzleState\.solvedCount \/ 3\)/);
});

import { PUZZLE_BANK, pickBankPuzzle, puzzleBankKey } from '../src/puzzle-bank.js';

test('bundled mate puzzle bank is well-formed and unique', () => {
  assert.ok(PUZZLE_BANK.length >= 25, "only puzzles that pass scripts/audit-puzzle-bank.mjs are kept");
  const keys = new Set();
  for (const item of PUZZLE_BANK) {
    assert.ok([2, 3, 4].includes(item.mateIn));
    assert.equal(item.moves.length, 2 * item.mateIn - 1, 'line is player move, reply, ... ending with the mating move');
    assert.ok(item.moves.every(move => /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(move)));
    assert.match(item.fen, /^[^ ]+ [wb] [KQkq-]+ [a-h1-8-]+ \d+ \d+$/);
    keys.add(puzzleBankKey(item));
  }
  assert.equal(keys.size, PUZZLE_BANK.length);
});

test('bank picker never returns a seen puzzle, respects tier and eventually runs out', () => {
  const seen = new Set();
  const early = pickBankPuzzle(seen, 0, () => 0.1);
  assert.ok(early.mateIn <= 2);
  const picked = new Set();
  for (let i = 0; i < PUZZLE_BANK.length; i += 1) {
    const item = pickBankPuzzle(seen, 3, Math.random);
    assert.ok(item && !seen.has(puzzleBankKey(item)));
    seen.add(puzzleBankKey(item)); picked.add(puzzleBankKey(item));
  }
  assert.equal(picked.size, PUZZLE_BANK.length);
  assert.equal(pickBankPuzzle(seen, 3), null);
});
