import test from 'node:test';
import assert from 'node:assert/strict';
import {
  emptyTrainingState, recordPuzzleResult, takeReviewPuzzle, weakestTags, trainingSummary, dueReviewCount,
  normalizeTrainingState, loadTrainingState, saveTrainingState, puzzleTags, REVIEW_BOX_INTERVALS_MS, REVIEW_QUEUE_LIMIT,
} from '../src/puzzle-training.js';

const P1 = { fen: '7k/8/8/8/8/8/5PPP/R5K1 w - - 0 1', moves: ['a1a8'], mateIn: 1, themes: ['backRankMate', 'mateIn1'] };
const P2 = { fen: '6k1/5ppp/8/8/8/8/5PPP/3R2K1 w - - 0 1', moves: ['d1d8'], mateIn: 1, themes: ['backRankMate'] };
const T0 = 1_000_000;

test('puzzleTags combines mate length and sanitized themes without duplicates', () => {
  assert.deepEqual(puzzleTags({ mateIn: 3, themes: ['fork', 'fork', 'x y!'] }), ['mateIn3', 'fork', 'xy']);
  assert.deepEqual(puzzleTags({}), []);
});

test('a missed puzzle enters box 0 and is due after the first interval', () => {
  const state = recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0 });
  assert.equal(state.queue.length, 1);
  assert.equal(state.queue[0].box, 0);
  assert.equal(state.queue[0].due, T0 + REVIEW_BOX_INTERVALS_MS[0]);
  assert.equal(dueReviewCount(state, T0), 0);
  assert.equal(dueReviewCount(state, T0 + REVIEW_BOX_INTERVALS_MS[0]), 1);
});

test('clean re-solves climb the boxes and graduate the puzzle at the top', () => {
  let state = recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0 });
  for (let box = 1; box < REVIEW_BOX_INTERVALS_MS.length; box += 1) {
    state = recordPuzzleResult(state, P1, 'clean', { now: T0 });
    assert.equal(state.queue[0].box, box);
    assert.equal(state.queue[0].due, T0 + REVIEW_BOX_INTERVALS_MS[box]);
  }
  state = recordPuzzleResult(state, P1, 'clean', { now: T0 });
  assert.equal(state.queue.length, 0, 'top-box clean solve graduates the puzzle');
});

test('a miss sends a climbed puzzle back to box 0 and counts misses; assisted keeps the box', () => {
  let state = recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0 });
  state = recordPuzzleResult(state, P1, 'clean', { now: T0 });
  state = recordPuzzleResult(state, P1, 'assisted', { now: T0 });
  assert.equal(state.queue[0].box, 1);
  state = recordPuzzleResult(state, P1, 'failed', { now: T0 });
  assert.equal(state.queue[0].box, 0);
  assert.equal(state.queue[0].misses, 2);
});

test('a never-failed puzzle solved clean is not queued, but is counted in the stats', () => {
  const state = recordPuzzleResult(emptyTrainingState(), P2, 'clean', { now: T0, solveMs: 8000 });
  assert.equal(state.queue.length, 0);
  assert.deepEqual([state.stats.total, state.stats.clean], [1, 1]);
  assert.equal(trainingSummary(state).avgCleanSolveSec, 8);
});

test('countStats:false lets a first-slip mark queue the puzzle without double counting the final result', () => {
  let state = recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0, countStats: false });
  state = recordPuzzleResult(state, P1, 'assisted', { now: T0 });
  assert.equal(state.stats.total, 1);
  assert.equal(state.stats.assisted, 1);
  assert.equal(state.stats.failed, 0);
  assert.equal(state.queue.length, 1);
});

test('review pacing: due puzzles appear at most every REVIEW_EVERY puzzles and only when due', () => {
  let state = recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0 });
  const due = T0 + REVIEW_BOX_INTERVALS_MS[0];
  let r = takeReviewPuzzle(state, { now: due - 1, every: 3 });
  assert.equal(r.puzzle, null, 'not yet due');
  r = takeReviewPuzzle(r.state, { now: due, every: 3 });
  assert.equal(r.puzzle, null, 'pacing: 2nd puzzle since last review');
  r = takeReviewPuzzle(r.state, { now: due, every: 3 });
  assert.ok(r.puzzle, 'third call serves the review');
  assert.equal(r.puzzle.review, true);
  assert.deepEqual(r.puzzle.moves, P1.moves);
  assert.equal(r.state.sinceReview, 0);
  const skip = takeReviewPuzzle({ ...r.state, sinceReview: 5 }, { now: due, skipKeys: new Set([r.state.queue[0].key]) });
  assert.equal(skip.puzzle, null, 'puzzles seen this session can be skipped');
});

test('weakest themes need enough attempts and a low clean rate', () => {
  let state = emptyTrainingState();
  for (let i = 0; i < 4; i += 1) state = recordPuzzleResult(state, { ...P1, fen: `${P1.fen}${i}` }, i === 0 ? 'clean' : 'failed', { now: T0 });
  state = recordPuzzleResult(state, { ...P2, themes: ['fork'], mateIn: 0 }, 'failed', { now: T0 });
  const weak = weakestTags(state);
  assert.ok(weak.some(item => item.tag === 'backRankMate' && item.attempts === 4 && item.clean === 1));
  assert.ok(!weak.some(item => item.tag === 'fork'), 'one attempt is not enough evidence');
});

test('normalizeTrainingState survives corrupt data and bounds the queue', () => {
  assert.deepEqual(normalizeTrainingState('garbage'), emptyTrainingState());
  const queue = Array.from({ length: REVIEW_QUEUE_LIMIT + 20 }, (_, i) => ({ fen: `8/8/8/8/8/8/8/K6${i % 9 + 1} w - - 0 ${i}`, moves: ['a1a2'], box: 99, due: 'x' }));
  queue.push({ fen: '', moves: ['a1a2'] }, { fen: 'x', moves: ['zz'] }, null);
  const state = normalizeTrainingState({ queue, stats: { total: -5, byTag: { 'bad tag!': { n: 1 }, fork: { n: 2, clean: 9 } } } });
  assert.ok(state.queue.length <= REVIEW_QUEUE_LIMIT);
  assert.ok(state.queue.every(item => item.box <= REVIEW_BOX_INTERVALS_MS.length - 1 && Number.isFinite(item.due)));
  assert.equal(state.stats.total, 0);
  assert.deepEqual(state.stats.byTag, { fork: { n: 2, clean: 2 } });
});

test('load/save round-trips through storage and tolerates a throwing storage', () => {
  const data = new Map();
  const storage = { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value) };
  const saved = saveTrainingState(recordPuzzleResult(emptyTrainingState(), P1, 'failed', { now: T0 }), storage);
  assert.equal(loadTrainingState(storage).queue.length, saved.queue.length);
  const broken = { getItem() { throw new Error('blocked'); }, setItem() { throw new Error('full'); } };
  assert.deepEqual(loadTrainingState(broken), emptyTrainingState());
  assert.doesNotThrow(() => saveTrainingState(saved, broken));
});
