import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { expectedScore, kFactor, puzzleScore, updatePuzzleRating, pickByRating, estimateBankRating, loadPuzzleRating, savePuzzleRating, PUZZLE_RATING_START } from '../src/puzzle-rating.js';
import { PUZZLE_BANK } from '../src/puzzle-bank.js';

test('expected score is 0.5 at equal rating and monotonic', () => {
  assert.equal(expectedScore(1000, 1000), 0.5);
  assert.ok(expectedScore(1400, 1000) > 0.9 && expectedScore(600, 1000) < 0.1);
});
test('K factor shrinks as games accumulate', () => {
  assert.ok(kFactor(0) > kFactor(50) && kFactor(50) > kFactor(500));
});
test('scores: first try > hint > slip > fail; speed bonus only for clean fast solves', () => {
  const fast = puzzleScore({ solved: true, solveMs: 3000 });
  const slow = puzzleScore({ solved: true, solveMs: 60000 });
  assert.ok(fast > slow && slow >= 0.9 && fast <= 1);
  assert.ok(slow > puzzleScore({ solved: true, hintUsed: true }));
  assert.ok(puzzleScore({ solved: true, hintUsed: true }) > puzzleScore({ solved: true, wrongCount: 1 }));
  assert.equal(puzzleScore({ solved: false }), 0);
});
test('rating rises on a hard solve, falls on an easy fail, stays in bounds', () => {
  const up = updatePuzzleRating({ rating: 800, games: 30 }, 1400, 1);
  assert.ok(up.delta > 15 && up.rating > 800 && up.games === 31);
  const down = updatePuzzleRating({ rating: 1200, games: 30 }, 700, 0);
  assert.ok(down.delta < -15 && down.rating < 1200);
  assert.equal(updatePuzzleRating({ rating: 100, games: 0 }, 100, 0).rating >= 100, true);
});
test('picks the unseen puzzle closest to the player rating', () => {
  const key = p => p.fen;
  const low = pickByRating(PUZZLE_BANK, 700, new Set(), key, estimateBankRating, () => 0);
  const high = pickByRating(PUZZLE_BANK, 1500, new Set(), key, estimateBankRating, () => 0);
  assert.ok(estimateBankRating(low) < estimateBankRating(high));
  const seen = new Set(PUZZLE_BANK.map(key));
  assert.equal(pickByRating(PUZZLE_BANK, 900, seen, key), null);
});
test('rating persistence survives bad storage', () => {
  const store = new Map();
  const storage = { getItem: k => store.get(k) ?? null, setItem: (k, v) => store.set(k, v) };
  assert.equal(loadPuzzleRating(storage).rating, PUZZLE_RATING_START);
  savePuzzleRating(storage, { rating: 1234, games: 7 });
  assert.deepEqual(loadPuzzleRating(storage), { rating: 1234, games: 7 });
  store.set('vila.chess.puzzles.rating.v1', '{oops');
  assert.equal(loadPuzzleRating(storage).rating, PUZZLE_RATING_START);
  assert.equal(loadPuzzleRating(null).games, 0);
});
test('main.js wires rating into solve, wrong move, hint and bank selection', () => {
  const src = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  for (const needle of ['updatePuzzleRating(', 'pickByRating(', 'hintUsed = true', 'wrongCount']) assert.ok(src.includes(needle), needle);
});
