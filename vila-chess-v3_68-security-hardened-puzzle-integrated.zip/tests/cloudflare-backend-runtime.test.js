import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

function createHarness(env = {}) {
  const records = new Map();
  const sql = {
    exec(statement, ...args) {
      if (/^CREATE TABLE/i.test(statement)) return [];
      if (/^SELECT key, value FROM vila_records/i.test(statement)) {
        return [...records.entries()].map(([key, value]) => ({ key, value }));
      }
      if (/^INSERT INTO vila_records/i.test(statement)) {
        records.set(String(args[0]), String(args[1]));
        return [];
      }
      if (/^DELETE FROM vila_records/i.test(statement)) {
        records.delete(String(args[0]));
        return [];
      }
      throw new Error(`SQL statement not covered by test harness: ${statement}`);
    }
  };
  const makeState = () => ({
    storage: { sql, transactionSync: callback => callback() },
    blockConcurrencyWhile: callback => callback()
  });
  let object = new ChessState(makeState(), env);
  const binding = {
    idFromName: () => 'vila-global-test',
    get: () => ({ fetch: request => object.fetch(request) })
  };
  return {
    binding,
    records,
    restart() { object = new ChessState(makeState(), env); }
  };
}

function makeRequest(path, { method = 'GET', token = '', body } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return new Request(`https://vila-test.workers.dev${path}`, {
    method,
    headers,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

async function call(harness, path, options = {}) {
  const response = await worker.fetch(makeRequest(path, options), { CHESS_STATE: harness.binding });
  const data = await response.json();
  return { status: response.status, data };
}

test('Cloudflare backend runtime: health, auth, random matchmaking, legal move, persistence and resign', async () => {
  const harness = createHarness();
  let result = await call(harness, '/api/health');
  assert.equal(result.status, 200);
  assert.equal(result.data.ok, true);

  result = await call(harness, '/api/social/health');
  assert.equal(result.status, 200);
  assert.equal(result.data.status, 'online');

  result = await call(harness, '/api/social/ranked/status');
  assert.equal(result.status, 401, 'ranked endpoints require an authenticated account');

  const alice = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'alice', displayName: 'Alice', password: 'Password!1', initialElo: 1000 }
  });
  assert.equal(alice.status, 201, JSON.stringify(alice.data));
  assert.ok(alice.data.token);
  assert.equal(alice.data.user.username, 'alice');

  const bob = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'bob', displayName: 'Bob', password: 'Password!2', initialElo: 1000 }
  });
  assert.equal(bob.status, 201, JSON.stringify(bob.data));
  assert.ok(bob.data.token);

  const queued = await call(harness, '/api/social/ranked/queue', {
    method: 'POST', token: alice.data.token, body: { timeControl: '3+2' }
  });
  assert.equal(queued.status, 202);
  assert.equal(queued.data.queued, true);

  const paired = await call(harness, '/api/social/ranked/queue', {
    method: 'POST', token: bob.data.token, body: { timeControl: '3+2' }
  });
  assert.equal(paired.status, 201, JSON.stringify(paired.data));
  assert.ok(paired.data.match?.id);

  const aliceStatus = await call(harness, '/api/social/ranked/status', { token: alice.data.token });
  const bobStatus = await call(harness, '/api/social/ranked/status', { token: bob.data.token });
  assert.equal(aliceStatus.data.match.id, bobStatus.data.match.id);
  assert.notEqual(aliceStatus.data.match.color, bobStatus.data.match.color);

  const white = aliceStatus.data.match.color === 'w' ? alice : bob;
  const black = aliceStatus.data.match.color === 'b' ? alice : bob;
  const matchId = aliceStatus.data.match.id;

  const illegal = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: white.data.token, body: { from: 'e2', to: 'e5', expectedPly: 0 }
  });
  assert.equal(illegal.status, 400, 'server rejects an illegal chess move');

  const accepted = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: white.data.token, body: { from: 'e2', to: 'e4', expectedPly: 0 }
  });
  assert.equal(accepted.status, 200, JSON.stringify(accepted.data));
  assert.equal(accepted.data.match.moves.length, 1);
  assert.equal(accepted.data.match.fen.split(' ')[1], 'b');

  const stale = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: black.data.token, body: { from: 'e7', to: 'e5', expectedPly: 0 }
  });
  assert.equal(stale.status, 409, 'stale ply is rejected rather than overwriting a move');

  // Recreate the Durable Object from persisted rows to emulate a cold start.
  harness.restart();
  const persisted = await call(harness, '/api/social/auth/me', { token: alice.data.token });
  assert.equal(persisted.status, 200, JSON.stringify(persisted.data));
  assert.equal(persisted.data.user.username, 'alice');

  const resigned = await call(harness, `/api/social/ranked/matches/${matchId}/resign`, {
    method: 'POST', token: white.data.token, body: {}
  });
  assert.equal(resigned.status, 200, JSON.stringify(resigned.data));
  assert.equal(resigned.data.match.status, 'finished');
  assert.ok(harness.records.size > 0, 'the DO storage persisted account and match rows');
});


test('Cloudflare social additions: public profiles, private messages, moderation reports and admin entitlement', async () => {
  const harness = createHarness({
    ADMIN_USERNAME: 'vila_admin',
    ADMIN_PASSWORD: 'Safe-Admin-Password-1234',
    ADMIN_INITIAL_ELO: '3200'
  });
  const alice = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'social_alice', displayName: 'Social Alice', password: 'Alice-Password-123', initialElo: 1000 }
  });
  const bob = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'social_bob', displayName: 'Social Bob', password: 'Bob-Password-1234', initialElo: 500 }
  });
  assert.equal(alice.status, 201, JSON.stringify(alice.data));
  assert.equal(bob.status, 201, JSON.stringify(bob.data));
  assert.equal(alice.data.user.elo, 1000);
  assert.equal(bob.data.user.elo, 500);

  const profile = await call(harness, '/api/social/users/social_bob', { token: alice.data.token });
  assert.equal(profile.status, 200);
  assert.equal(profile.data.user.username, 'social_bob');
  assert.equal('email' in profile.data.user, false);

  const sent = await call(harness, `/api/social/messages/${bob.data.user.id}`, {
    method: 'POST', token: alice.data.token, body: { text: 'Xin chào từ Worker' }
  });
  assert.equal(sent.status, 201, JSON.stringify(sent.data));
  const history = await call(harness, `/api/social/messages/${alice.data.user.id}`, { token: bob.data.token });
  assert.equal(history.status, 200);
  assert.equal(history.data.messages[0].text, 'Xin chào từ Worker');
  const conversations = await call(harness, '/api/social/messages/conversations', { token: alice.data.token });
  assert.equal(conversations.status, 200);
  assert.equal(conversations.data.conversations[0].user.username, 'social_bob');

  const report = await call(harness, `/api/social/users/${bob.data.user.id}/report`, {
    method: 'POST', token: alice.data.token, body: { reason: 'cheating', details: 'Nghi sử dụng engine trong trận xếp hạng.' }
  });
  assert.equal(report.status, 201, JSON.stringify(report.data));
  assert.equal((await call(harness, '/api/social/admin/reports?status=pending', { token: alice.data.token })).status, 403);

  const admin = await call(harness, '/api/social/auth/login', {
    method: 'POST', body: { username: 'vila_admin', password: 'Safe-Admin-Password-1234' }
  });
  assert.equal(admin.status, 200, JSON.stringify(admin.data));
  assert.equal(admin.data.user.role, 'admin');
  assert.equal(admin.data.user.entitlement?.plan, 'premium');
  assert.equal((await call(harness, '/api/social/me/review-access', {
    method: 'POST', token: admin.data.token, body: { gameId: 'admin-review' }
  })).status, 200);

  const reports = await call(harness, '/api/social/admin/reports?status=pending', { token: admin.data.token });
  assert.equal(reports.status, 200);
  assert.ok(reports.data.reports.some(item => item.id === report.data.report.id));
  const ban = await call(harness, `/api/social/admin/reports/${report.data.report.id}`, {
    method: 'PATCH', token: admin.data.token, body: { action: 'ban', reason: 'Vi phạm đã được xác minh trong test.' }
  });
  assert.equal(ban.status, 200, JSON.stringify(ban.data));
  const bannedLogin = await call(harness, '/api/social/auth/login', {
    method: 'POST', body: { username: 'social_bob', password: 'Bob-Password-1234' }
  });
  assert.equal(bannedLogin.status, 403);
});


test('security hardening: failed logins are throttled without enabling username-only account lockout', async () => {
  const harness = createHarness();
  const registered = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'security_user', displayName: 'Security User', password: 'Security-Password-42', initialElo: 500 }
  });
  assert.equal(registered.status, 201, JSON.stringify(registered.data));
  for (let i = 0; i < 10; i++) {
    const result = await call(harness, '/api/social/auth/login', {
      method: 'POST', body: { username: 'security_user', password: 'wrong-password' }
    });
    assert.equal(result.status, i === 9 ? 429 : 401, `failed attempt ${i + 1}: ${JSON.stringify(result.data)}`);
  }
  const blocked = await call(harness, '/api/social/auth/login', {
    method: 'POST', body: { username: 'security_user', password: 'still-wrong-password' }
  });
  assert.equal(blocked.status, 429, 'additional failed attempts remain throttled');
  const rateKeys = [...harness.records.keys()].filter(key => key.startsWith('rate:'));
  assert.ok(rateKeys.some(key => key.includes('identity-login%3A')), 'identity limiter is persisted without storing the raw username/email');
  const valid = await call(harness, '/api/social/auth/login', {
    method: 'POST', body: { username: 'security_user', password: 'Security-Password-42' }
  });
  assert.equal(valid.status, 200, 'a user who knows the correct password must not be locked out by an attacker');
});
