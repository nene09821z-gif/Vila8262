import test from 'node:test';
import assert from 'node:assert/strict';
import { CRASH_LOG_KEY, CRASH_LOG_LIMIT, scrubSecrets, readCrashes, recordCrash, clearCrashes, formatCrashReport } from '../src/crash-log.js';

const memoryStorage = () => {
  const data = new Map();
  return { getItem: key => (data.has(key) ? data.get(key) : null), setItem: (key, value) => data.set(key, String(value)), removeItem: key => data.delete(key) };
};

test('scrubSecrets hides bearer tokens, token query values and JSON secrets', () => {
  const out = scrubSecrets('Authorization: Bearer abcdefghijklmnop12345 url?social_token=SECRET123&x=1 {"password":"hunter2"}');
  assert.doesNotMatch(out, /abcdefghijklmnop12345|SECRET123|hunter2/);
  assert.match(out, /\[ẩn\]/);
});

test('recordCrash stores entries and merges identical consecutive errors', () => {
  const storage = memoryStorage();
  recordCrash(storage, { message: 'boom', where: 'main.js:10' }, 1000);
  recordCrash(storage, { message: 'boom', where: 'main.js:10' }, 2000);
  recordCrash(storage, { message: 'other' }, 3000);
  const list = readCrashes(storage);
  assert.equal(list.length, 2);
  assert.equal(list[0].count, 2);
  assert.equal(list[1].message, 'other');
});

test('recordCrash keeps only the newest CRASH_LOG_LIMIT entries and survives bad storage', () => {
  const storage = memoryStorage();
  for (let i = 0; i < CRASH_LOG_LIMIT + 7; i += 1) recordCrash(storage, { message: `e${i}` }, 1000 + i * 100_000);
  const list = readCrashes(storage);
  assert.equal(list.length, CRASH_LOG_LIMIT);
  assert.equal(list.at(-1).message, `e${CRASH_LOG_LIMIT + 6}`);
  storage.setItem(CRASH_LOG_KEY, '{not json');
  assert.deepEqual(readCrashes(storage), []);
  assert.deepEqual(readCrashes(null), []);
});

test('formatCrashReport lists newest first and clearCrashes empties the journal', () => {
  const storage = memoryStorage();
  recordCrash(storage, { message: 'first', view: 'play' }, 1_700_000_000_000);
  recordCrash(storage, { message: 'second', stack: 'at x (a.js:1:1)' }, 1_700_000_100_000);
  const report = formatCrashReport(readCrashes(storage), { version: '3.67.1', userAgent: 'Android test' });
  assert.ok(report.indexOf('second') < report.indexOf('first'));
  assert.match(report, /Phiên bản: 3\.67\.1/);
  clearCrashes(storage);
  assert.deepEqual(readCrashes(storage), []);
});
