import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PUZZLE_BANK, pickDailyBankPuzzle, pickBankPuzzle } from '../src/puzzle-bank.js';

const key = fen => fen.split(' ').slice(0, 4).join(' ');

test('bank entries are well-formed and unique', () => {
  assert.ok(PUZZLE_BANK.length >= 20);
  assert.equal(new Set(PUZZLE_BANK.map(p => key(p.fen))).size, PUZZLE_BANK.length);
  for (const p of PUZZLE_BANK) {
    assert.ok(p.mateIn >= 2 && p.mateIn <= 4);
    assert.equal(p.moves.length, 2 * p.mateIn - 1, `line length for ${p.fen}`);
    for (const m of p.moves) assert.match(m, /^[a-h][1-8][a-h][1-8][qrbn]?$/);
  }
});

test('daily bank puzzle is deterministic per date and varies across dates', () => {
  assert.equal(pickDailyBankPuzzle('2026-10-24'), pickDailyBankPuzzle('2026-10-24'));
  const picks = new Set(Array.from({ length: 30 }, (_, d) => key(pickDailyBankPuzzle(`2026-11-${String(d + 1).padStart(2, '0')}`).fen)));
  assert.ok(picks.size >= 8);
});

test('bank picker avoids seen puzzles', () => {
  const first = pickBankPuzzle(new Set(), 0, () => 0.1);
  assert.ok(!pickBankPuzzle(new Set([key(first.fen)]), 0, () => 0.1) || key(pickBankPuzzle(new Set([key(first.fen)]), 0, () => 0.1).fen) !== key(first.fen));
});

test('main.js accepts any checkmate on the last move and uses the bank for daily puzzles', () => {
  const src = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.ok(src.includes('expectedIndex >= line.length - 1'));
  assert.match(src, /pickDailyBankPuzzle\(puzzleState\.dailyDate/);
});
