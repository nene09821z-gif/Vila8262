import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('v3.67.1 Back button steps through screens and protects a live game', () => {
  const main = read('src/main.js');
  assert.match(main, /history\.pushState\(\{ vilaView: view \}/);
  assert.match(main, /addEventListener\('popstate'/);
  assert.match(main, /navigatingFromHistory/);
  assert.match(main, /Bấm Back lần nữa để rời ván/);
});

test('v3.67.1 account settings use collapsible sections and review text is readable on phones', () => {
  const main = read('src/main.js');
  const css = read('src/vila-professional.css');
  assert.equal((main.match(/class="account-section"/g) || []).length, 3);
  assert.match(css, /\.account-section > summary/);
  assert.match(css, /html body \.review-ply-san \{ font-size: 15px; \}/);
  assert.match(css, /html body select\.field \{ -webkit-appearance: none/);
});

test('v3.67.1 brand intro shows on every launch and can be skipped', () => {
  const intro = read('src/vila-intro.js');
  assert.doesNotMatch(intro, /localStorage/);
  assert.match(intro, /addEventListener\('click', leave\)/);
  assert.match(intro, /Chạm để bỏ qua/);
});

test('v3.67.1 crash journal is wired to global handlers and the system-health page', () => {
  const main = read('src/main.js');
  assert.match(main, /from '\.\/crash-log\.js'/);
  assert.match(main, /addEventListener\('unhandledrejection'/);
  assert.match(main, /renderCrashJournalMarkup\(\)/);
  assert.match(main, /id="copyCrashReport"/);
});
