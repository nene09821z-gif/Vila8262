import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = name => fs.readFileSync(path.join(root, name), 'utf8');
const pkg = JSON.parse(read('package.json'));

test('v3.37 is a distinct, versioned release with the required and separately licensed older engine package', () => {
  assert.equal(pkg.version, '3.66.0');
  assert.equal(pkg.dependencies['stockfish-10'], 'npm:stockfish.js@10.0.2');
  assert.equal(pkg.optionalDependencies?.['stockfish-10'], undefined);
  const legacy = read('src/legacy-uci-engine.js');
  const main = read('src/main.js');
  assert.match(legacy, /uciok/);
  assert.match(legacy, /awaitingReady/);
  assert.match(legacy, /this\.worker !== worker/);
  assert.match(legacy, /#retireWorker/);
  assert.match(main, /Stockfish 10 · (?:engine )?(?:cổ điển|bản cũ)/);
  assert.match(main, /new LegacyUciEngine/);
  assert.match(main, /getLegacyArenaEngine\(\)\.newGame\(\)/);
  assert.match(main, /arenaEngineWarning/);
  assert.match(main, /Stockfish 10 không khởi chạy; đã chuyển sang Stockfish 19/);
  assert.match(main, /VILA offline fallback/);
  assert.match(main, /tự thử lại ở lượt sau/);
});

test('Android build requires Stockfish 19 full and Stockfish 10 legacy files plus their license and manifest flags', () => {
  for (const workflow of ['.github/workflows/build-android.yml', '.github/workflows/build-from-zip.yml']) {
    const text = read(workflow);
    assert.match(text, /REQUIRE_STOCKFISH_10: '1'/, `${workflow} must require the older engine`);
    assert.match(text, /test -s public\/engine\/stockfish-10\.js/);
    assert.match(text, /STOCKFISH-10-LICENSE\.txt/);
    assert.match(text, /m\.sf10Version !== '10\.0\.2'/);
  }
  assert.match(read('scripts/copy-engine.mjs'), /STOCKFISH-10-LICENSE\.txt/);
});

test('game review is its own responsive route with replay, graph, paired move list, analysis and PGN', () => {
  const main = read('src/main.js');
  const css = read('src/style.css');
  assert.match(main, /else if \(currentView === 'review'\) root\.innerHTML = renderReviewView\(\)/);
  assert.match(main, /function renderReviewView\(\)/);
  assert.match(main, /review-upper-grid/);
  for (const selector of ['#evaluationGraph', '#reviewReplayBoard', '#reviewMoveAnalysis', '#reviewMoveDetail', '#reviewDownloadPGN', '#reviewGameBtn']) assert.ok(main.includes(selector.slice(1)), `missing review control ${selector}`);
  assert.match(css, /\.game-review-page/);
  assert.match(css, /\.review-upper-grid\{display:grid/);
  assert.match(main, /CAPS2/);
});

test('the additional original piece palettes have their inline SVG gradients and permissive piece sets list', () => {
  const index = read('index.html'); const pieces = read('src/pieces.js'); const fetcher = read('scripts/fetch-piece-sets.mjs');
  for (const id of ['amethyst','sapphire','bronze']) for (const side of ['w','b']) {
    assert.ok(index.includes(`vp-grad-${id}-${side}`), `index missing gradient ${id}-${side}`);
  }
  for (const id of ['kiwen-suwi','firi','totoy','shapes']) {
    assert.match(pieces, new RegExp(`id: '${id}'`));
    assert.match(fetcher, new RegExp(`id: '${id}'`));
  }
  assert.match(fetcher, /CC-BY-SA-4\.0/);
  assert.match(read('public/piece-sets/CREDITS.md'), /not affiliated with or endorsed by Lichess/);
});
