import test from 'node:test';
import assert from 'node:assert/strict';
import { createHmac } from 'node:crypto';
import fs from 'node:fs';
import { DAY_MS, PRO_CODE_TRIAL_DURATION_MS, PREMIUM_CODE_TRIAL_DURATION_MS, effectivePlan, grantProCodeTrial, grantPremiumCodeTrial, grantProTrial, planStatusLabel } from '../src/plans.js';

const read = path => fs.readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const secret = 'vila-tests-only-not-a-production-secret-at-all-2026';
const hmac = value => createHmac('sha256', secret).update(value.toLowerCase(), 'utf8').digest('hex');

test('Pro and Premium code trial durations and expiry are server-defined', () => {
  const now = 1_800_000_000_000;
  const pro = grantProCodeTrial({}, now);
  assert.equal(PRO_CODE_TRIAL_DURATION_MS, 5 * DAY_MS);
  assert.equal(pro.proExpiresAt, now + 5 * DAY_MS);
  const premium = grantPremiumCodeTrial({}, now);
  assert.equal(PREMIUM_CODE_TRIAL_DURATION_MS, 60_000);
  assert.equal(premium.premium, true);
  assert.equal(premium.premiumExpiresAt, now + 60_000);
  assert.equal(effectivePlan(premium, now + 59_999), 'premium');
  assert.equal(effectivePlan(premium, now + 60_000), 'free');
  assert.match(planStatusLabel(premium, now), /Premium dùng thử/);
  assert.equal(effectivePlan({ ...premium, proExpiresAt: now + 10_000 }, now + 60_000), 'free');
  assert.equal(effectivePlan({ ...premium, proExpiresAt: now + 50_000 }, now + 40_000), 'premium');
  const restoredPro = grantProTrial(premium, now + 60_000);
  assert.equal(restoredPro.proExpiresAt, now + 60_000 + 3 * 60 * 60 * 1000, 'an expired Premium preview must not block a later Pro grant');
});

test('trial codes are HMAC-SHA-256 only and validated in backend routes', () => {
  assert.match(hmac('AdminVila'), /^[a-f0-9]{64}$/);
  assert.equal(hmac('AdminVila'), hmac('adminvila'));
  assert.notEqual(hmac('AdminVila'), hmac('99vila'));
  const nodeBackend = read('server/social.js');
  const worker = read('cloudflare/src/index.js');
  assert.match(nodeBackend, /router\.post\('\/me\/redeem-code', requireAuth, trialCodeLimiter/);
  assert.match(nodeBackend, /createHmac\('sha256', config\.secret\)/);
  assert.match(nodeBackend, /safeEqual\(digest, config\.proHash\)/);
  assert.match(nodeBackend, /trialCodeRedemptions/);
  assert.match(worker, /path === '\/me\/redeem-code'/);
  assert.match(worker, /await hmacHex\(secret, code\)/);
  assert.match(worker, /constantTimeEqual\(digest, proHash\)/);
  assert.match(worker, /trialCodeRedemptions/);
  assert.match(worker, /trial-code', 5, 900_000/);
});

test('v3.65 UI has a separate code entry page and a first-launch vector knight intro, not plaintext codes', () => {
  const main = read('src/main.js');
  const html = read('index.html');
  const intro = read('src/vila-intro.js');
  const css = read('src/vila-intro.css');
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.version, '3.66.0');
  assert.match(html, /data-view="redeem"/);
  assert.match(main, /socialApi\('\/me\/redeem-code'/);
  assert.match(main, /schedulePremiumPreviewExpiry\(result\.user\.entitlement\)/);
  assert.match(main, /Premium Preview đã hết hạn/);
  assert.match(main, /showVilaIntro\(\)/);
  assert.match(intro, /INTRO_DURATION_MS = 5000/);
  assert.match(intro, /<svg class="vila-intro-knight"/);
  assert.match(intro, /localStorage\.getItem\(INTRO_KEY\)/);
  assert.match(css, /prefers-reduced-motion\s*:\s*reduce/);
  assert.doesNotMatch(main, /AdminVila|99vila/);
  assert.doesNotMatch(intro, /AdminVila|99vila/);
});
