# ViLa Chess Professional Edition v3.66.0 — Xem lại nâng cấp, bàn học online & bot dễ

## v3.66.0 — Mũi tên phân tích, xem lại, bàn học trực tuyến và kho câu đố

- Thêm lớp SVG mũi tên nước đã đi (vàng) và nước Stockfish gợi ý (cyan) vào bàn xem lại; thêm phím mũi tên trái/phải và Home/End để tua nhanh. Nước gợi ý được xác thực hợp lệ trên thế cờ hiện tại.
- Lưu riêng nước tốt nhất của thế cờ sau mỗi nước để mũi tên không nhầm với phương án trước khi người chơi đi.
- Sửa trải nghiệm nhập mã trên di động: ô văn bản có bàn phím phù hợp, không dựng lại toàn trang khi vừa gửi và giữ trạng thái rõ trong lúc xác minh.
- Bổ sung tra cứu nước phổ biến trực tuyến trên trang huấn luyện qua API Opening Explorer của Lichess, và link mở bàn phân tích Lichess.
- Tăng kho câu đố lưu ngoại tuyến từ 200 lên tối đa 500 câu; mỗi lần yêu cầu tải thêm 50 câu, có giãn cách truy vấn để hạn chế quá tải. Dữ liệu câu đố Lichess được phát hành theo CC0. Chỉ tải theo từng lô, không tải toàn bộ cơ sở dữ liệu nhiều triệu câu.
- Làm mức Elo 500 nhẹ hơn: vẫn dùng Stockfish Skill Level 0 với thời gian/độ sâu thấp, cộng một xác suất nhỏ chọn nước hợp lệ khác để mô phỏng sai sót người mới. Đây là mức tập luyện ước lượng, không bảo đảm rating 500 đã benchmark.

Kiểm thử trọng tâm v3.66.0: xem báo cáo `V3_66_QA_REPORT.md`. Build web/APK và kiểm thử end-to-end vẫn phụ thuộc việc cài đủ npm dependencies và cấu hình backend.


## v3.65.0 — cài đặt, bot, ghép trận và bảng tổng kết

- Thiết kế lại trang Cài đặt theo nhóm: bàn cờ/quân cờ, cách chơi, bot/phân tích, đồng hồ, âm thanh và trải nghiệm hỗ trợ.
- Thêm tùy chọn tọa độ, đánh dấu nước đi cuối, nước đi trước, quân đã ăn, hoạt ảnh, tự phong hậu, xác nhận đầu hàng và thông báo hỗ trợ tiếp cận.
- Thêm bảng chọn nhanh sức mạnh bot cùng cấu hình engine, độ sâu, thời gian nghĩ, chất lượng phân tích và đồng hồ mặc định; tùy chọn khai cuộc có thể bật/tắt.
- Ghép trận có biểu tượng người chơi/địa cầu kiểu tile 3D xanh; bảng thiết lập sức mạnh có robot 3D và nút Elo chọn nhanh.
- Bảng xác nhận đầu hàng/thoát trận và bảng tổng kết dùng chung nhận diện VILA thay hộp thoại trình duyệt thô.
- Nhận diện khai cuộc chuẩn hóa SAN để không bị lệch vì dấu chiếu, dấu đánh giá hoặc ký hiệu nhập thành `0-0`/`O-O`.
- Tùy chọn âm thanh: Soft, Wood, Neon và Mute; mặc định giữ hành vi âm thanh Soft.
- Bộ khai cuộc đi kèm trong source vẫn là dữ liệu dự phòng, không phải bộ đầy đủ 3.000+ dòng. Không tuyên bố kho đầy đủ nếu chưa bổ sung và kiểm tra dữ liệu.
- Thêm trang nhập mã riêng: `AdminVila` cho Pro dùng thử 5 ngày và `99vila` cho Premium Preview 60 giây; thời hạn được tính ở backend, không cấp quyền bằng localStorage.
- Mã xác minh HMAC-SHA-256; backend cần cấu hình 3 secret theo `TRIAL_CODES_SETUP_V3_65.md`. Mỗi loại mã chỉ đổi một lần/tài khoản; endpoint giới hạn tốc độ.
- Lần đầu mở phiên bản này hiện quân mã VILA 3D bằng SVG nội tuyến trong khoảng 5 giây; không dùng ảnh ngoài, nên không phụ thuộc URL ảnh.
- QA: xem `V3_65_TRIAL_CODES_QA_REPORT.md`. Chưa xác minh được build web/APK sạch vì môi trường thiếu dependencies (`chess.js`, `express`).

## v3.63.0 — yêu cầu gói qua máy chủ, Pro 3 giờ và chat admin

- Nâng dùng thử Pro bằng xu lên **50.000 xu / 3 giờ**; hiển thị thời hạn còn lại trong trang gói. Gói xu là quyền cục bộ trên thiết bị, không phải thanh toán tiền thật.
- Pro có luồng **gửi yêu cầu 1.000đ cho 3 giờ**; chỉ admin được xác nhận sau khi tự kiểm tra thanh toán thì backend mới cấp quyền. Không tự nhận tiền hoặc tự mở Pro khi người dùng chỉ bấm nút.
- Premium không bán/kích hoạt trực tiếp: gửi đề xuất 1.000–100.000đ (bước 1.000đ) cho admin; admin trao đổi riêng, không tự động cấp Premium.
- Thêm hàng đợi yêu cầu mua được bảo vệ bằng quyền admin, chống gửi dồn 8 yêu cầu/giờ, gộp yêu cầu trùng cùng gói đang chờ, ghi audit và nhắn người dùng qua hộp thư.
- Đồng bộ Node backend và Cloudflare Durable Object; sửa việc chưa serialize hộp thư và yêu cầu mua vào storage nên dữ liệu nay được giữ qua lần khởi động lại trong test.
- Thêm panel trợ lý gói trong chat admin và thao tác duyệt/từ chối/thông báo có hành động thật qua API. Đây là bot phản hồi theo quy tắc, không giả vờ là mô hình AI hay hệ thống thanh toán.
- Cải tiến an toàn theo hướng xác thực, giới hạn tần suất, quyền máy chủ và nhật ký kiểm toán; không có cơ chế né ban của nền tảng bên ngoài.
- Kiểm tra mục tiêu: xem `TEST_REPORT_V3_63_0.md`. **Chưa xác minh build Vite/APK sạch** do môi trường hiện tại không cài được dependencies đầy đủ; không coi các bài bị chặn là pass.

## v3.62.0 — hệ thống giao diện Professional thống nhất

- Gom toàn bộ stylesheet hiện được dùng vào một điểm nạp duy nhất `src/vila-professional.css`, giữ thứ tự quy tắc component để hạn chế hồi quy; `src/main.js` không còn nạp nhiều stylesheet cạnh tranh riêng lẻ.
- Thêm bộ design token navy/xanh dương/cyan/vàng, cải thiện tương phản và độ đọc trên hồ sơ, bảng xếp hạng, biểu mẫu, chat, dashboard và màn đấu.
- Chuẩn hóa thẻ/nhãn huy hiệu theo hiệu ứng 3D: gradient vật liệu, highlight cạnh, viền nổi và bóng đổ; huy hiệu top 3 có màu kim loại riêng.
- Cải thiện layout responsive, vùng an toàn Android, thanh điều hướng, chat trên màn hình nhỏ và khoảng cách thông báo để giảm che khuất nội dung.
- Không đổi logic luật cờ, engine, tài khoản, backend, ghép trận hay schema dữ liệu.
- Chưa xác minh build Vite/APK sạch trong môi trường này do `npm ci` bị timeout khi lấy dependency; xem `TEST_REPORT_V3_62_PRO_UI.md` để biết những kiểm tra đã chạy và giới hạn còn lại.

## Tài liệu nền của phiên bản trước: Cờ Vua ViLa v3.61.0

## v3.61.0

- Dùng chung danh mục thời gian đấu cho giao diện, backend Node và Cloudflare Worker.
- Khi tải lại lúc chờ ghép trận, ứng dụng khôi phục đúng mốc thời gian và loại Elo; backend thiếu lựa chọn mặc định Daily 1d.
- Anti-cheat dùng thời gian lượt đi và số nước hợp lệ do máy chủ tự tính để gửi tín hiệu rà soát; không tự động khóa tài khoản.
- Sửa avatar Cloudflare ổn định, đồng bộ phiên bản release và cache offline; Android versionCode là 10.
- Đã chạy 56 bài kiểm thử mục tiêu: 56/56 đạt, cùng kiểm tra cú pháp bốn module JavaScript. Báo cáo và giới hạn xác minh: `TEST_REPORT_V3_61_0.md`; chưa xác nhận build Vite/APK sạch hoặc ghép trận Internet bằng hai tài khoản thật do npm ci bị timeout và Worker chưa được triển khai từ môi trường này.

## v3.50.0 — kéo quân, chuột ảo, review và mini-game

- Tinh chỉnh luồng kéo quân để gom cập nhật theo khung hình, giảm truy vấn bố cục lặp lại và tránh giật khi di chuyển nhanh.
- Tách thanh công cụ phân tích thành Di chuyển quân, Mũi tên, Bút chì tự do, đường chữ L quân Mã, Khoanh ô và lựa chọn màu. Chọn **Di chuyển quân** để thoát chế độ vẽ.
- Sửa luồng chuột ảo khi đổi công cụ: tự thả thao tác giữ, cho phép nhấn/vẽ bằng Pointer Events, không bắt buộc chạm đúng quân cờ nếu đang vẽ.
- Thêm mini-game ngoại tuyến **Phản xạ tọa độ**, có điểm, chuỗi liên tiếp và kỷ lục lưu trên thiết bị.
- Thêm avatar thương hiệu VILA dạng SVG và đưa vào cache offline; giảm khoảng cách các khối chính trong trang xem lại trận.
- Engine: giữ Stockfish 19 NNUE Full/Lite và ASM-JS dự phòng trong build GitHub Actions. Stockfish 19 là bản ổn định mới nhất đang được phát hành chính thức; các bản `dev` mới hơn vẫn là pre-release. Không nhúng Leela WebAssembly thử nghiệm khi đường chạy cùng mạng nơ-ron chưa được tích hợp/kiểm chứng cho WebView Android. Nguồn: [Stockfish Releases](https://github.com/official-stockfish/Stockfish/releases) và [Lc0 browser backend status](https://lczero.org/contribute/gsoc/2026/).
- Kết quả kiểm tra nguồn: các bài test tĩnh bàn cờ/chuột ảo, thanh vẽ, xem lại, mini-game và cấu hình engine đã chạy. Build Vite/Gradle và đo độ trễ trên thiết bị Android chưa xác minh do registry npm không truy cập được trong môi trường này. Xem `TEST_REPORT_V3_50_0.md`.

### Đưa ZIP lên GitHub từ điện thoại

1. Tải `vila-chess-pro-v3.52.0-github-source.zip` và tải ZIP lên thư mục gốc repository.
2. Vào **Actions** → **Cờ Vua ViLa build from ZIP/source** → **Run workflow**. Workflow cài dependencies, chạy test, tạo gói engine Full NNUE và build APK.
3. Nếu workflow báo lỗi, mở trang chạy workflow và đọc bước đầu tiên màu đỏ trong Summary/Logs. ZIP nguồn không tự bảo đảm APK đã build thành công.


## Ghép trận online không yêu cầu người chơi cài đặt máy chủ

Ứng dụng tích hợp sẵn URL Cloudflare của dự án; người chơi không cần nhập Worker URL/API key/mã phòng. Backend Worker dùng Durable Object SQLite nằm trong [`cloudflare/`](cloudflare/) và phải được chủ dự án deploy một lần trước khi ghép trận Internet sử dụng được. Xem [`ONLINE_MATCHMAKING_DEPLOYMENT.md`](ONLINE_MATCHMAKING_DEPLOYMENT.md) để biết quy trình triển khai và kiểm thử thật. Trạng thái “Active” của Worker cũ chưa chứng minh đã có backend ViLa.

## v3.47.2 — Stockfish 10 nhanh hơn và gói GitHub gọn hơn

- Giới hạn Stockfish 10 ở khoảng 0,2–0,6 giây/nước trong Đấu trường; giới hạn tối đa 0,5 giây/nước khi đấu người.
- Rút timeout khởi tạo và watchdog của engine cũ để không bị chờ quá lâu; giữ Stockfish 10 để so sánh.
- Gói AI Studio 6,3 MB chỉ được lưu một lần trong mã nguồn; Gradle tự chép vào tài nguyên Android khi build.
- Báo cáo lịch sử của bản đó: `TEST_REPORT_V3_47_2.md`.

## v3.47.1 — bỏ Stockfish 10 khỏi mặc định và giảm thời gian mỗi nước

- Đấu trường mặc định dùng Stockfish 19 Lite cùng ViLa Rookie; Stockfish 10 cũ còn ở lựa chọn thủ công để so sánh.
- Ngân sách Đấu trường được giảm: SF19 dùng 0,7–1,5 giây/nước, SF10 dùng 0,3–1,2 giây/nước, thời gian nghỉ mặc định 0,15 giây.
- Đồng bộ thay đổi vào JS bundle Android hiện có; xem `TEST_REPORT_V3_47_1.md`. Đây chưa phải APK mới được build sạch trên máy thật.

## v3.47.0 — bảng màu xanh dương/cyan, theme bàn cờ và Docker

- Đồng bộ màu giao diện theo logo: navy đậm, xanh dương làm màu chính, cyan làm điểm nhấn và vàng dành cho phần thưởng.
- Sửa CSS bàn cờ dùng biến `--board-*`, tránh ép màu bằng `!important` khiến theme do người dùng chọn không đổi được.
- Đồng bộ CSS được đóng gói trong Android, cache-bust biểu tượng/stylesheet và Service Worker cache lên v3.47.0.
- Thêm `Dockerfile` và `.dockerignore`; bản Docker cài dependency trước khi copy mã nguồn để script `postinstall` không chạy quá sớm.
- QA hiện tại: xem [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md). Bản ZIP **không phải APK đã build**; cần cài dependencies và hoàn tất build Android trên môi trường có mạng/Android SDK.
- Kết quả đo được trong môi trường offline: `npm run test:static` 266/266 đạt; kiểm tra cú pháp JavaScript/MJS 132/132 đạt. `npm test` còn 4 test không nạp được `chess.js`/`express`; build web, Docker và APK chưa được xác minh trong phiên này.

## v3.46.1 — rà soát bản phát hành và khôi phục dữ liệu khai cuộc dự phòng

- Đồng bộ metadata bản phát hành và cache-bust favicon; sửa thứ tự lịch sử changelog/README và tiêu đề nguồn câu đố.
- Thay `public/openings-eco.json` rỗng bằng 338 dòng khai cuộc dự phòng đã loại trùng. Dữ liệu này không được gắn nhãn nhầm là kho Lichess CC0 đầy đủ.
- Chặn pipeline phát hành nếu kho khai cuộc trong source hoặc `dist` chưa đạt tối thiểu 3.000 dòng hợp lệ; sửa thông báo khi JSON chỉ có biến trùng.
- Kết quả kiểm thử dữ liệu khai cuộc nằm trong [`TEST_REPORT_V3_46_1.md`](TEST_REPORT_V3_46_1.md).

---

## v3.46.0 — giao diện mobile, đồng hồ nhanh và phòng đấu gọn hơn

- Gom các tác vụ thiết lập, danh sách nước, phân tích và khai cuộc vào menu **Công cụ**; bỏ dải nút chức năng dài trùng lặp trên màn hình chơi.
- Bỏ nhãn nhận diện khai cuộc ngay dưới bàn cờ và thẻ gợi ý màu vàng. Gợi ý vẫn đánh dấu nước đi bằng mũi tên trên bàn cờ và thông báo ngắn.
- Thêm lối chọn nhanh Siêu chớp 30 giây, Bullet 1+0, Blitz 3+2 và Rapid 10+0; các mốc khác vẫn ở mục thiết lập.
- Làm gọn thanh điều hướng nhỏ, giữ nút tài khoản dễ truy cập và thêm thẻ ghép trận người thật trong trang chủ.
- Loại bỏ bản nhạc Gymnopédie cũ khỏi nhạc tích hợp; thay bằng các chủ đề tổng hợp nguyên bản chạy offline. Nhạc bên ngoài chỉ phát khi người dùng chủ động chọn.
- Chưa coi ghép trận online là hoạt động thật chỉ dựa vào giao diện: cần triển khai backend và có đối thủ đang chờ. APK không được coi là đã build thành công nếu chưa chạy pipeline Android.

### QA v3.46.0 (lịch sử)

Xem [`TEST_REPORT_V3_46_0.md`](TEST_REPORT_V3_46_0.md) để đối chiếu kết quả của bản trước. Báo cáo kiểm thử của bản hiện tại là [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md); [`TEST_REPORT_V3_46_1.md`](TEST_REPORT_V3_46_1.md) là báo cáo lịch sử.
---

## v3.45.0 — sửa an toàn thao tác và phục hồi engine offline

- Đồng hồ dùng phép tính tick thuần, có kiểm tra thời gian lùi, giá trị không hợp lệ và chặn về 0; trạng thái đã kết thúc không tiếp tục trừ thời gian.
- Hộp chọn phong cấp chụp ô đi, FEN và phiên ván; nếu bàn cờ đổi trong lúc hộp thoại đang mở thì yêu cầu cũ bị hủy, tránh đi nhầm quân/ô.
- Worker tìm nước offline bị treo/quá hạn sẽ bị kết thúc; các yêu cầu đang chờ được dọn và nhận phương án tìm kiếm nông có giới hạn để tránh làm bot kẹt mãi.
- Avatar mã vương miện được thêm vào cache lõi Service Worker; metadata phát hành và hướng dẫn build được đồng bộ v3.45.0.

### QA v3.45.0

- `npm run test:static`: **251/251 đạt**.
- Kiểm tra cú pháp JavaScript/MJS: **128/128 tệp đạt**.
- Kiểm thử tập trung đồng hồ, phong cấp bất đồng bộ và phục hồi Worker: **9/9 đạt**.
- `npm test`: **253/257 đạt**; 4 test không khởi chạy vì môi trường không có `chess.js`/`express` và không truy cập được npm registry. Chưa xác nhận build APK hoặc kiểm tra trực tiếp trên Android.
- Chi tiết: [`TEST_REPORT_V3_45_0.md`](TEST_REPORT_V3_45_0.md).

VILA là ứng dụng cờ vua web đóng gói bằng Capacitor cho Android. ZIP này là **mã nguồn để build**, không phải APK đã biên dịch.


## Nâng cấp v3.40.0

- Chip Stockfish chỉ báo sẵn sàng sau UCI handshake hợp lệ `uciok` → `readyok`; khi đã sẵn sàng, chạm chip để xem thời gian khởi động/profile trong thông báo.
- Lưu ván đang chơi dùng snapshot có checksum; ván hỏng, quá hạn, sai mode, nước đi/đồng hồ sai định dạng bị từ chối trước khi nạp; snapshot v2 cũ vẫn tương thích.
- Giữ các chế độ cờ, phân tích, câu đố, đấu trường, Rubik và mini-game hiện có; thay đổi tập trung vào tính đúng đắn, khả năng khôi phục và kiểm thử hồi quy.
- Test tĩnh: 233/233; cú pháp: 123/123; full suite: 235/239 do bốn tệp test thiếu dependency trong môi trường đóng gói. Build APK và UCI với binary thật còn chờ chạy trên GitHub Actions.


## Tính năng nền tảng từ v3.37.0

### Engine và sức mạnh bot
- Stockfish 19 Full NNUE được đưa vào quy trình build Android cùng bản Lite và ASM-JS dự phòng. Full single-threaded có kích thước khoảng 94 MB và không cần cross-origin isolation; Lite nhẹ hơn đáng kể nhưng yếu hơn. [Tài liệu Stockfish.js và các biến thể engine](https://github.com/nmrugg/stockfish.js/blob/master/README.md).
- Chế độ tự động ưu tiên Full NNUE khi WebView báo bộ nhớ thiết bị từ khoảng 2 GiB và ít nhất 4 lõi; máy yếu hơn chọn Lite. Nếu Full không khởi tạo được, ứng dụng có chuỗi dự phòng Lite rồi ASM-JS.
- Bot không còn bỏ lượt Stockfish để đi ngẫu nhiên/heuristic chỉ nhằm giả lập Elo thấp. Dưới ngưỡng UCI_Elo, VILA dùng Skill Level 0–7 của Stockfish; các mức Elo thấp là preset luyện tập, **không phải rating được benchmark**.
- Mặc định tìm kiếm sâu hơn (depth tối đa 30, tối đa 2,6 giây mỗi nước); cài đặt tùy chỉnh đã lưu của người chơi được giữ lại.

### Đấu trường có hai thế hệ Stockfish
- Đấu trường có Stockfish 19 Full NNUE và Stockfish 10 cổ điển như hai đối thủ độc lập. Stockfish 10 được phân phối từ gói `stockfish.js@10.0.2`, chạy UCI trong Web Worker riêng, có giới hạn thời gian và kiểm tra tính hợp lệ của nước đi. Đây là engine đời cũ dùng để so sánh, không được quảng bá là mạnh hơn Stockfish hiện tại.
- Bản Android release bắt buộc xác nhận đủ script Stockfish 10 và giấy phép GPL đi kèm; thiếu một trong hai thì build dừng trước khi ghi đè thư mục engine.

### Xem lại ván và phân tích
- Xem lại từng nửa nước với nút về đầu/trước/sau/cuối, bàn cờ có tô nước cuối, biểu đồ lợi thế và biên bản ghép theo cặp Trắng/Đen. Chạm một nước để nhảy đến đúng thế cờ.
- Phân tích từng nước lưu điểm trước/sau theo góc nhìn Trắng, mức mất điểm theo bên vừa đi, độ sâu engine, nước tốt nhất tìm thấy ở thế trước và biến chính SAN. Panel hiển thị nhãn và số lượng chất lượng nước đi riêng cho Trắng và Đen.
- Phân tích toàn ván, gợi ý nước, phân tích 3 biến và trợ lý cờ chạy ở mức sức mạnh tối đa của engine, không thừa hưởng giới hạn Elo của bot trong ván.
- Các nhãn “Tốt nhất”, “Xuất sắc”, “Tốt”, “Chưa chính xác”, “Sai lầm”, “Blunder”, “Khai cuộc” và “Bỏ lỡ cơ hội thắng” là **heuristic VILA dựa trên điểm Stockfish**, không tuyên bố dùng cùng công thức phân loại độc quyền của Chess.com. Nước “Thiên tài” không được tự gán chỉ vì có quân bị tấn công.

### Giao diện, bài tập và game giải trí
- App mở vào **sảnh Trang chủ VILA**, không mở thẳng bàn cờ. Từ sảnh mới chọn Chơi, Bot, Câu đố, Bài học, Phân tích, Đấu trường AI, lịch sử hoặc mini-game.
- Giao diện ưu tiên điện thoại: xanh đêm/xanh lá mang thương hiệu VILA, điều hướng đáy, vùng chạm lớn, safe-area Android và bàn cờ responsive. Bố cục lấy cảm hứng từ ứng dụng cờ hiện đại, không sao chép logo hoặc tài sản thương hiệu riêng của Chess.com.
- Giữ thư viện khai cuộc ECO cục bộ, tra cứu tên/ECO/nước đi và các biến. Workflow kiểm tra ngưỡng dữ liệu khai cuộc trước build.
- Câu đố ngày sử dụng Lichess API, xác minh dòng nước bằng `chess.js`, lưu cache ngày và có bài ngoại tuyến khi không có mạng. Luyện tự do, Rush và Sinh tồn tự chuyển bài sau khi giải; bộ đố offline có độ khó tăng dần theo tiến trình.
- Bốn mini-game ngoại tuyến: Rubik 3×3 xoay mặt bằng vuốt hoặc nút U/D/L/R/F/B, xáo trộn/hoàn tác/làm mới; 2048; lật thẻ nhớ; Trượt số 15 với xáo trộn chỉ bằng nước đi hợp lệ.
- Giữ các chức năng sẵn có: nhập/xuất PGN, lịch sử cục bộ, đồng hồ, hoàn tác/làm lại, chú thích mũi tên/ô cờ, khai cuộc, profile bot offline, nhạc nền và các luồng online đã tích hợp.

## Bản vá v3.37.2 — bố cục trận đấu trên Android

- Chuyển lời mời bắt đầu khỏi lớp phủ che mờ bàn cờ thành thẻ gọn nằm giữa thông tin đối thủ và bàn cờ.
- Đưa cửa sổ cuộn về đầu trang khi chuyển màn hình hoặc quay lại chơi từ màn xem lại.
- Bảo đảm vùng đệm cuối trang đủ cho thanh thao tác trận đấu cố định, tránh che nội dung cuối trên WebView di động.
- Tăng phiên bản Service Worker để thiết bị không tiếp tục dùng CSS/JS cũ sau khi cập nhật.

## Bản vá v3.37.1 — Stockfish 10 Đấu trường
- Đồng bộ UCI bằng `isready`/`readyok` trước từng lệnh `position`/`go`; reset `ucinewgame` chỉ một lần cho mỗi ván để không xóa bảng băm ở mọi nửa nước.
- Cô lập callback theo đúng Worker và dỡ callback trước khi huỷ worker timeout/lỗi, ngăn `bestmove` cũ làm hoàn tất lượt mới. Worker lỗi hoặc timeout được huỷ an toàn và tự khởi tạo lại ở lượt kế tiếp; lỗi Stockfish 10 được giữ rõ trên trạng thái Đấu trường khi dùng nước dự phòng.
- Bản phát hành tăng phiên bản Service Worker để thiết bị không giữ mã JavaScript cũ trong cache.

## Online và offline
- Chơi với Stockfish, luyện bài và mini-game chạy cục bộ sau khi các engine cần thiết đã được tải/cache.
- Câu đố ngày và dữ liệu mở rộng cần internet; cache cục bộ được dùng khi có sẵn.
- Xếp hạng/cộng đồng/server yêu cầu backend và tài khoản đã cấu hình. Không đăng nhập hay backend thì những luồng phụ thuộc server không thể hoạt động đầy đủ.
- Engine Full NNUE khoảng 94 MB; workflow build nhúng nó để tăng sức mạnh, vì vậy APK lớn hơn. Trên máy yếu có thể dùng Lite hoặc để chế độ tự động chọn phù hợp.

## Build APK bằng GitHub Actions

1. Giải nén ZIP và đẩy **toàn bộ nội dung bên trong** lên một GitHub repository, giữ nguyên thư mục `.github/workflows/`.
2. Mở tab **Actions** và chạy workflow **Cờ Vua ViLa Android build**. Workflow này cũng chạy khi có push/PR.
3. Runner cài Node.js 22 và Java 21; cài package, kiểm tra cú pháp, chạy `npm test`, tải tài nguyên engine/bộ quân/kho khai cuộc, build web, sync Capacitor và chạy `./gradlew assembleDebug`.
4. Chỉ khi các bước bắt buộc đều thành công, tải artifact **`covua-vila-debug-apk`**. Artifact `test-report` giúp xem lỗi test, còn `covua-vila-android-gradle-source` là gói mã nguồn Gradle do workflow sinh ra.
5. Workflow **Cờ Vua ViLa build from ZIP/source** là lựa chọn chạy thủ công riêng; nó không chạy trùng trên mỗi lần push.

### Lệnh cục bộ

```bash
npm install --no-audit --no-fund
npm run test:static
npm test
npm run build
npm run android:init
```

`npm run build` cần các package Node và tải dữ liệu build lần đầu. Đối với build Android cần môi trường Java/Android phù hợp hoặc dùng GitHub Actions.

## Báo cáo kiểm thử

Xem [`TEST_REPORT_V3_46_4.md`](TEST_REPORT_V3_46_4.md) để biết kết quả mới nhất và các giới hạn kiểm thử. GitHub Actions phải hoàn tất cài dependencies, toàn bộ test, build web và build Gradle trước khi có thể coi APK là đã build thành công.

## Nguồn câu đố

Nguồn, license và cách tải kho câu đố theo lô được ghi trong [`PUZZLES_SOURCE.md`](PUZZLES_SOURCE.md). Dữ liệu Lichess được tải theo yêu cầu; không đóng gói cả cơ sở dữ liệu nhiều triệu câu vào APK.

## Nguồn và giấy phép

- Stockfish.js: [repository và README](https://github.com/nmrugg/stockfish.js); engine GPLv3, giấy phép được copy kèm asset khi build.
- Lichess API và dữ liệu công khai: [API](https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml), [Open Database](https://database.lichess.org/) (câu đố dữ liệu công khai CC0). Bản này dùng API daily/cache, không nhúng toàn bộ kho hàng triệu câu đố.
- Các bộ quân SVG và giấy phép nguồn được liệt kê trong [`public/piece-sets/CREDITS.md`](public/piece-sets/CREDITS.md).
- Ý tưởng giao diện Rubik tương tác có tham khảo [Cubing.js](https://js.cubing.net/cubing/); logic xoay trong dự án này được hiện thực nội bộ, không tải thư viện từ CDN.



## v3.47.0 update (2026-10-20)
- Added online-only correspondence controls: 1 day and 2 days per player. Local games keep their existing clock presets.
- Added a Stockfish-powered beginner training preset targeting the lowest supported skill tier; it is not a separate engine binary or a calibrated Elo guarantee.
- Improved readability of puzzle/review panels and touch reliability of AI Arena controls.
- Engine package remains Stockfish 19 Lite WASM plus Stockfish 10 legacy ASM.js. The manifest does not include a Full Stockfish 19 build.
