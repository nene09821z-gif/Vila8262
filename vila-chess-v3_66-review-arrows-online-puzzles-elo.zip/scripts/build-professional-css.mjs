import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'src');
const layers = [
  'style.css',
  'mobile-upgrade.css',
  'chesscom-polish.css',
  'board-motion.css',
  'board-live.css',
  'profile.css',
  'lessons.css',
  'vila-v4.css',
  'account-gate.css',
  'achievements.css',
  'social-hub.css',
  'vila-professional-theme.css',
];
const header = `/* ViLa Professional runtime bundle v3.66.0.\n   Includes core structure + specialist feature modules + ONE authoritative theme.\n   Legacy global skin overlays (atelier, polish, commercial and old header skin) have been removed. */\n\n`;
const output = layers.map(file => {
  const content = fs.readFileSync(path.join(src, file), 'utf8').trim();
  return `/* Professional stylesheet layer: ${file} */\n${content}\n`;
}).join('\n');
fs.writeFileSync(path.join(src, 'vila-professional.css'), header + output, 'utf8');
console.log(`Built src/vila-professional.css from ${layers.length} owned layers.`);
