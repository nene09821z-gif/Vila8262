/** Skill-0 is not a calibrated 500 Elo rating; this small handicap makes the easy preset visibly weaker. */
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;

export function chooseBeginnerMove(bestMove, legalMoves, random = Math.random, deviationChance = 0.14) {
  const legal = [...new Set((Array.isArray(legalMoves) ? legalMoves : [])
    .map(move => String(typeof move === 'string' ? move : move?.uci || '').toLowerCase())
    .filter(move => UCI_RE.test(move)))];
  if (!legal.length) return null;
  const best = String(bestMove || '').toLowerCase();
  if (!legal.includes(best)) return legal[0];
  let draw = 1;
  try { draw = Number(random()); } catch {}
  draw = Number.isFinite(draw) ? Math.max(0, Math.min(0.999999, draw)) : 1;
  if (legal.length < 2 || draw >= Math.max(0, Math.min(0.5, Number(deviationChance) || 0))) return best;
  const alternatives = legal.filter(move => move !== best);
  if (!alternatives.length) return best;
  let choice = 0.5;
  try { choice = Number(random()); } catch {}
  choice = Number.isFinite(choice) ? Math.max(0, Math.min(0.999999, choice)) : 0.5;
  return alternatives[Math.floor(choice * alternatives.length)] || best;
}
