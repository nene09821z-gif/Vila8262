/* Optional camera hand tracking, isolated from the UI thread. Camera frames are processed locally.
 *
 * This MUST stay a classic (non-module) worker: MediaPipe loads its WebAssembly glue with importScripts(),
 * which module workers reject. The MediaPipe bundle, WASM and hand model are bundled with the app under
 * /mediapipe/ (see scripts/fetch-hand-model.mjs); the CDN is only a fallback when those files are missing. */
const VISION_VERSION = '0.10.14';
const CDN_BASE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}`;
const CDN_MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
const MIN_MODEL_BYTES = 1_000_000;
const MIN_BUNDLE_CHARS = 50_000;
let handLandmarker = null;
let busy = false;

function sources(localBase) {
  return [
    { name: 'tích hợp sẵn', bundle: `${localBase}vision_bundle.js`, wasm: `${localBase}wasm`, model: `${localBase}hand_landmarker.task` },
    { name: 'CDN', bundle: `${CDN_BASE}/vision_bundle.cjs`, wasm: `${CDN_BASE}/wasm`, model: CDN_MODEL }
  ];
}

async function download(url, label) {
  const response = await fetch(url, { signal: AbortSignal.timeout(60000) });
  if (!response.ok) throw new Error(`${label}: HTTP ${response.status}`);
  return response;
}

// The bundle is fetched and run from a Blob so a wrong MIME type on the host (.cjs, WebView asset server)
// cannot make importScripts() refuse it. It is CommonJS, so it needs a temporary `module`/`exports`; both are
// removed afterwards because MediaPipe's WASM glue changes behaviour when it sees them.
async function loadBundle(url) {
  const text = await (await download(url, 'thư viện nhận diện')).text();
  if (text.length < MIN_BUNDLE_CHARS || !text.includes('HandLandmarker')) throw new Error('thư viện nhận diện không hợp lệ');
  const blobUrl = URL.createObjectURL(new Blob([text], { type: 'text/javascript' }));
  const holder = { exports: {} };
  self.module = holder;
  self.exports = holder.exports;
  try { importScripts(blobUrl); }
  finally {
    delete self.module;
    delete self.exports;
    URL.revokeObjectURL(blobUrl);
  }
  const api = holder.exports;
  if (!api?.FilesetResolver || !api?.HandLandmarker) throw new Error('thư viện nhận diện thiếu HandLandmarker');
  return api;
}

async function loadModel(url) {
  const bytes = new Uint8Array(await (await download(url, 'mô hình bàn tay')).arrayBuffer());
  if (bytes.byteLength < MIN_MODEL_BYTES) throw new Error('mô hình bàn tay không hợp lệ');
  return bytes;
}

async function createLandmarker(api, vision, modelBytes) {
  const options = delegate => ({
    baseOptions: { modelAssetBuffer: modelBytes, delegate },
    runningMode: 'VIDEO', numHands: 1,
    minHandDetectionConfidence: 0.55,
    minHandPresenceConfidence: 0.5,
    minTrackingConfidence: 0.55
  });
  try { return await api.HandLandmarker.createFromOptions(vision, options('GPU')); }
  catch (gpuError) { return await api.HandLandmarker.createFromOptions(vision, options('CPU')); }
}

async function initialise(baseUrl) {
  const localBase = /^https?:/.test(String(baseUrl || '')) ? String(baseUrl).replace(/\/?$/, '/') : new URL('../mediapipe/', self.location.href).href;
  const failures = [];
  for (const source of sources(localBase)) {
    try {
      const api = await loadBundle(source.bundle);
      const vision = await api.FilesetResolver.forVisionTasks(source.wasm);
      const modelBytes = await loadModel(source.model);
      handLandmarker = await createLandmarker(api, vision, modelBytes);
      return;
    } catch (error) {
      failures.push(`${source.name}: ${String(error?.message || error).slice(0, 80)}`);
    }
  }
  throw new Error(failures.join(' · ') || 'Không tải được mô hình nhận diện tay.');
}

self.onmessage = async event => {
  const data = event.data || {};
  if (data.type === 'init') {
    try {
      await initialise(data.baseUrl);
      self.postMessage({ type: 'ready' });
    } catch (error) {
      self.postMessage({ type: 'fatal', error: String(error?.message || error || 'Không tải được mô hình nhận diện tay.') });
    }
    return;
  }
  if (data.type !== 'frame' || !handLandmarker || busy || !data.bitmap) {
    data.bitmap?.close?.();
    return;
  }
  busy = true;
  const bitmap = data.bitmap;
  try {
    const result = handLandmarker.detectForVideo(bitmap, Number(data.timestamp) || performance.now());
    const points = result?.landmarks?.[0];
    if (points?.[8] && points?.[4]) {
      const tip = points[8];
      const thumb = points[4];
      self.postMessage({
        type: 'landmarks',
        point: { x: tip.x, y: tip.y },
        pinchDistance: Math.hypot(tip.x - thumb.x, tip.y - thumb.y),
        confidence: Number(result?.handednesses?.[0]?.[0]?.score || 0)
      });
    } else {
      self.postMessage({ type: 'no-hand' });
    }
  } catch (error) {
    self.postMessage({ type: 'frame-error', error: String(error?.message || error || 'Lỗi nhận diện khung hình.') });
  } finally {
    bitmap.close?.();
    busy = false;
  }
};
