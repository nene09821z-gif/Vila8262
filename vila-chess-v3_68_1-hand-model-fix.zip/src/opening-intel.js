import { recognizeOpening, normalizeOpeningSan } from './opening-recognition.js';

/**
 * Smart opening recognition.
 *
 * Differences from the plain SAN-prefix trie in opening-recognition.js:
 *  - works on POSITIONS, so transpositions (1.Nf3 d5 2.d4 → Queen's-pawn lines) are recognised;
 *  - names the opening from the very first move (generic first-move names) and only commits to a
 *    specific name when the position is unambiguous, otherwise reports "forming" + likely names;
 *  - remembers the last book position, so after a deviation it still shows the opening and says
 *    where the player left theory and what the book recommended;
 *  - exposes the next book moves for the current position and a per-ply book/out-of-book map
 *    for game review.
 *
 * The Chess constructor is injected so the module stays pure and unit-testable.
 */

const FIRST_MOVE_NAMES = Object.freeze({
  e4: { name: 'Khai cuộc Tốt Vua', eco: 'B00', family: 'Mở e4' },
  d4: { name: 'Khai cuộc Tốt Hậu', eco: 'A40', family: 'Mở d4' },
  c4: { name: 'Khai cuộc Anh', eco: 'A10', family: 'Mở c4' },
  Nf3: { name: 'Khai cuộc Réti / Zukertort', eco: 'A04', family: 'Mở c4' },
  g3: { name: 'Khai cuộc Hungary (King’s Fianchetto)', eco: 'A00', family: 'Mở c4' },
  b3: { name: 'Khai cuộc Larsen (Nimzo-Larsen)', eco: 'A01', family: 'Mở c4' },
  f4: { name: 'Khai cuộc Bird', eco: 'A02', family: 'Mở c4' },
  b4: { name: 'Khai cuộc Ba Lan (Sokolsky)', eco: 'A00', family: 'Mở c4' },
  Nc3: { name: 'Khai cuộc Dunst (Mã c3)', eco: 'A00', family: 'Mở e4' }
});

const positionKey = chess => String(chess.fen()).split(' ').slice(0, 4).join(' ');
const plyLabel = ply => `${Math.ceil(ply / 2)}${ply % 2 ? '' : '…'}`;

function newNode() {
  return { exact: null, first: null, names: new Map(), moves: new Map() };
}

function topNames(map, limit = 3) {
  return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([name]) => name);
}

export function createOpeningIntel(openings, ChessCtor) {
  const nodes = new Map();
  let cursor = 0;
  let ready = false;
  let timer = null;

  const nodeFor = key => {
    let node = nodes.get(key);
    if (!node) { node = newNode(); nodes.set(key, node); }
    return node;
  };

  function addLine(opening) {
    const line = opening?.san;
    if (!Array.isArray(line) || !line.length) return;
    let chess;
    try { chess = new ChessCtor(); } catch { return; }
    let before = positionKey(chess);
    for (let i = 0; i < line.length; i += 1) {
      try { if (!chess.move(line[i])) return; } catch { return; }
      const san = normalizeOpeningSan(line[i]);
      const parent = nodeFor(before);
      const next = parent.moves.get(san) || { san, count: 0, names: new Map() };
      next.count += 1;
      next.names.set(opening.name, (next.names.get(opening.name) || 0) + 1);
      parent.moves.set(san, next);
      before = positionKey(chess);
      const node = nodeFor(before);
      node.names.set(opening.name, (node.names.get(opening.name) || 0) + 1);
      if (!node.first) node.first = opening;
      if (i === line.length - 1 && !node.exact) node.exact = opening;
    }
  }

  /** Synchronous full build (tests, small catalogues). */
  function buildAll() {
    while (cursor < openings.length) addLine(openings[cursor++]);
    ready = true;
  }

  /** Non-blocking build: a few lines per tick so the UI never freezes. */
  function warm(chunk = 40) {
    if (ready || timer) return;
    const step = () => {
      timer = null;
      const end = Math.min(openings.length, cursor + chunk);
      while (cursor < end) addLine(openings[cursor++]);
      if (cursor >= openings.length) { ready = true; return; }
      timer = setTimeout(step, 0);
    };
    timer = setTimeout(step, 0);
  }

  function walk(history) {
    const chess = new ChessCtor();
    const steps = [];
    let key = positionKey(chess);
    for (let i = 0; i < history.length; i += 1) {
      try { if (!chess.move(history[i])) break; } catch { break; }
      const parentKey = key;
      key = positionKey(chess);
      steps.push({ ply: i + 1, san: String(history[i]), key, parentKey, node: nodes.get(key) || null });
    }
    return steps;
  }

  const nextMovesAt = key => {
    const node = nodes.get(key);
    if (!node) return [];
    return [...node.moves.values()].sort((a, b) => b.count - a.count).slice(0, 5)
      .map(m => ({ san: m.san, count: m.count, name: topNames(m.names, 1)[0] || '' }));
  };

  function nameOf(node) {
    if (node.exact) return { opening: node.exact, confident: true };
    if (node.names.size === 1) return { opening: node.first, confident: true };
    return { opening: null, confident: false };
  }

  /**
   * Analyse a SAN history. Returns null when nothing can be said.
   * Shape is a superset of the old recognizeOpening() result (name, eco, family, line, note).
   */
  function analyze(history = [], { startFen = null, safe = false } = {}) {
    if (!Array.isArray(history) || !history.length || startFen) return null;
    if (!ready) {
      // Index still warming up: fall back to the SAN-prefix trie so the UI is never blank.
      const hit = recognizeOpening(history, openings, { minPlies: 1 });
      if (hit) return { ...hit, status: 'book', plies: history.length, transposed: false, nextMoves: [], possible: [], detail: hit.eco ? `Mã ECO ${hit.eco}` : '' };
      const first = FIRST_MOVE_NAMES[history[0]];
      return first ? { ...first, status: 'forming', plies: history.length, nextMoves: [], possible: [], detail: 'Đang hình thành' } : null;
    }
    const steps = walk(history);
    if (!steps.length) return null;
    const current = steps[steps.length - 1];
    let lastConfident = null; // { opening, ply }
    for (const step of steps) {
      if (!step.node) continue;
      const named = nameOf(step.node);
      if (named.confident) lastConfident = { opening: named.opening, ply: step.ply, key: step.key };
    }
    const inBook = Boolean(current.node);
    const plies = history.length;
    const base = { plies, nextMoves: inBook && !safe ? nextMovesAt(current.key) : [], possible: [], transposed: false, deviationPly: null, deviatedMove: null };

    if (inBook) {
      const named = nameOf(current.node);
      if (named.confident) {
        const opening = named.opening;
        const prefix = (opening.san || []).slice(0, plies).map(normalizeOpeningSan).join(' ');
        const played = history.map(normalizeOpeningSan).join(' ');
        const transposed = (opening.san || []).length >= plies && prefix !== played;
        const exact = Boolean(current.node.exact);
        return {
          ...opening, ...base, status: 'book', transposed,
          detail: `${opening.eco ? `Mã ECO ${opening.eco} · ` : ''}${transposed ? 'chuyển thế từ nhánh khác' : exact ? 'đúng sách khai cuộc' : 'đang đi theo sách khai cuộc'}`
        };
      }
      // Several named lines still pass through this position → keep the broad name, list what it may become.
      const inherited = lastConfident?.opening || FIRST_MOVE_NAMES[history[0]] || null;
      const possible = topNames(current.node.names, 3);
      return inherited ? { ...inherited, ...base, status: 'forming', possible: safe ? [] : possible, detail: safe ? 'Đang hình thành' : `Đang hình thành · có thể thành: ${possible.join(', ')}` } : null;
    }

    // Left the book: keep the last confident name and say where/what.
    if (!lastConfident) {
      const first = FIRST_MOVE_NAMES[history[0]];
      return first ? { ...first, ...base, status: 'unknown', detail: 'Thế cờ ngoài sách khai cuộc' } : null;
    }
    const deviationPly = lastConfident.ply + 1;
    const recommended = nextMovesAt(lastConfident.key).map(m => m.san);
    if (!recommended.length) {
      // The catalogue simply ends here: this is the end of known theory, not a mistake.
      return { ...lastConfident.opening, ...base, status: 'ended', bookPlies: lastConfident.ply, detail: `Đã đi hết sách khai cuộc (đến nước ${plyLabel(lastConfident.ply)})` };
    }
    return {
      ...lastConfident.opening, ...base, status: 'deviated', bookPlies: lastConfident.ply, deviationPly,
      deviatedMove: history[deviationPly - 1] || null, nextMoves: safe ? [] : nextMovesAt(lastConfident.key),
      detail: `Rời sách ở nước ${plyLabel(deviationPly)} (${history[deviationPly - 1] || '?'})${recommended.length && !safe ? ` · sách đi: ${recommended.slice(0, 3).join(', ')}` : ''}`
    };
  }

  /** Per-ply book map for game review. */
  function annotate(history = []) {
    if (!ready || !Array.isArray(history)) return [];
    return walk(history).map(step => {
      const named = step.node ? nameOf(step.node) : null;
      return { ply: step.ply, san: step.san, inBook: Boolean(step.node), name: named?.opening?.name || null, eco: named?.opening?.eco || null };
    });
  }

  return { analyze, annotate, nextMovesAt: key => nextMovesAt(key), warm, buildAll, get ready() { return ready; }, get size() { return nodes.size; } };
}
