/**
 * Bundle the MediaPipe hand-tracking runtime and model into public/mediapipe/ so the "chuột tay" feature
 * works offline and inside the Android WebView. Files are validated (size) and written atomically.
 * A failed download only warns (the Worker falls back to the CDN at run time) unless
 * REQUIRE_HAND_MODEL=1 or --required is set. SKIP_HAND_MODEL=1 skips the step entirely.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const outputRoot = process.env.HAND_MODEL_OUTPUT_DIR ? path.resolve(process.env.HAND_MODEL_OUTPUT_DIR) : path.join(root, 'public', 'mediapipe');
const VERSION = '0.10.14';
const cdn = (process.env.MEDIAPIPE_CDN || `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VERSION}`).replace(/\/$/, '');
const modelUrl = process.env.MEDIAPIPE_MODEL_URL || 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
const required = process.env.REQUIRE_HAND_MODEL === '1' || process.argv.includes('--required');

if (process.env.SKIP_HAND_MODEL === '1') {
  console.log('[Cờ Vua ViLa] SKIP_HAND_MODEL=1: bỏ qua việc đóng gói mô hình nhận diện tay.');
  process.exit(0);
}

// `rename` makes the CommonJS bundle a .js file so every asset server hands it out with a JavaScript MIME type.
const files = [
  { url: `${cdn}/vision_bundle.cjs`, dest: 'vision_bundle.js', minBytes: 50_000, mustInclude: 'HandLandmarker' },
  { url: `${cdn}/wasm/vision_wasm_internal.js`, dest: 'wasm/vision_wasm_internal.js', minBytes: 5_000 },
  { url: `${cdn}/wasm/vision_wasm_internal.wasm`, dest: 'wasm/vision_wasm_internal.wasm', minBytes: 1_000_000 },
  { url: `${cdn}/wasm/vision_wasm_nosimd_internal.js`, dest: 'wasm/vision_wasm_nosimd_internal.js', minBytes: 5_000 },
  { url: `${cdn}/wasm/vision_wasm_nosimd_internal.wasm`, dest: 'wasm/vision_wasm_nosimd_internal.wasm', minBytes: 1_000_000 },
  { url: modelUrl, dest: 'hand_landmarker.task', minBytes: 1_000_000 }
];

async function isValid(file, destination) {
  try {
    const stat = await fs.stat(destination);
    if (stat.size < file.minBytes) return false;
    if (file.mustInclude) return (await fs.readFile(destination, 'utf8')).includes(file.mustInclude);
    return true;
  } catch { return false; }
}

async function download(file, destination) {
  let lastError;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const response = await fetch(file.url, { signal: AbortSignal.timeout(120000), headers: { 'user-agent': 'co-vua-vila-hand-model/3.68.1' } });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const bytes = Buffer.from(await response.arrayBuffer());
      if (bytes.length < file.minBytes) throw new Error(`tệp quá nhỏ (${bytes.length} byte)`);
      if (file.mustInclude && !bytes.toString('utf8').includes(file.mustInclude)) throw new Error('nội dung không đúng');
      await fs.mkdir(path.dirname(destination), { recursive: true });
      const temporary = `${destination}.part`;
      await fs.writeFile(temporary, bytes);
      await fs.rename(temporary, destination);
      return;
    } catch (error) { lastError = error; }
  }
  throw lastError;
}

const errors = [];
let downloaded = 0;
for (const file of files) {
  const destination = path.join(outputRoot, file.dest);
  if (await isValid(file, destination)) continue;
  try { await download(file, destination); downloaded += 1; }
  catch (error) { errors.push(`${file.dest}: ${String(error?.message || error)}`); }
}

if (!errors.length) {
  await fs.writeFile(path.join(outputRoot, 'NOTICE.txt'), [
    `MediaPipe Tasks Vision ${VERSION} (runtime and WebAssembly) and the Hand Landmarker model are provided by Google under the Apache License 2.0.`,
    'https://github.com/google-ai-edge/mediapipe · https://ai.google.dev/edge/mediapipe/solutions/vision/hand_landmarker',
    'These files are processed on-device; camera frames are never sent to a server.',
    ''
  ].join('\n'));
  console.log(`[Cờ Vua ViLa] Mô hình nhận diện tay sẵn sàng trong public/mediapipe (${downloaded} tệp mới).`);
} else {
  const message = `[Cờ Vua ViLa] Chưa đóng gói đủ mô hình nhận diện tay (${errors.join('; ')}). Ứng dụng sẽ thử tải từ CDN khi chạy.`;
  if (required) { console.error(message); process.exit(1); }
  console.warn(message);
}
