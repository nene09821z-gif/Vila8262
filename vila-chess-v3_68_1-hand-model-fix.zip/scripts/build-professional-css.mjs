import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'src');
export const layers = [
  'style.css',
  'mobile-upgrade.css',
  'chesscom-polish.css',
  'board-motion.css',
  'board-live.css',
  'profile.css',
  'lessons.css',
  'vila-v4.css',
  'account-gate.css',
  'achievements.css',
  'social-hub.css',
  'vila-professional-theme.css',
];
export const header = `/* ViLa Professional runtime bundle v3.68.1.\n   Includes core structure + specialist feature modules + ONE authoritative theme.\n   Legacy global skin overlays (atelier, polish, commercial and old header skin) have been removed. */\n\n`;

/** Pure function: returns the exact text the runtime bundle must contain. */
export function buildProfessionalCss(sourceDir = src) {
  const output = layers.map(file => {
    const content = fs.readFileSync(path.join(sourceDir, file), 'utf8').trim();
    return `/* Professional stylesheet layer: ${file} */\n${content}\n`;
  }).join('\n');
  return header + output;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  fs.writeFileSync(path.join(src, 'vila-professional.css'), buildProfessionalCss(), 'utf8');
  console.log(`Built src/vila-professional.css from ${layers.length} owned layers.`);
}
