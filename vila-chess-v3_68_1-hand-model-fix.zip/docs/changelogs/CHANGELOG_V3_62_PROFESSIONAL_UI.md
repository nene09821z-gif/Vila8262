# ViLa Chess v3.62.0 — Professional UI

## Phạm vi
- Một CSS entrypoint trong `src/main.js`: `src/vila-professional.css`, có thể tái tạo bằng `npm run build:professional-css`. Bundle giữ thứ tự stylesheet/component đang dùng rồi đặt design system chính thức ở cuối.
- Xóa tận gốc các skin toàn cục cũ `vila-atelier.css`, `vila-polish.css`, `vila-commercial.css`, `header-chesscom.css` và xóa đoạn CSS light-mode lỗi thời khỏi `style.css`; giữ lại các module chuyên biệt có chức năng.
- Chuyển hiệu ứng chờ ghép trận, fair-play, premove chip và ký hiệu nước đi cần thiết sang theme Professional để không làm mất chức năng khi loại skin cũ.
- Màu thương hiệu thống nhất: navy sâu, xanh dương chủ đạo, cyan cho tương tác, vàng cho giải thưởng.
- Bề mặt/thẻ có phân cấp; chữ phụ tăng tương phản; controls giữ hit-area thân thiện với Android.
- Huy hiệu và nhãn dùng hiệu ứng 3D beveled (gradient, cạnh sáng, bóng sâu), huy chương Top 3 có vật liệu vàng/bạc/đồng.
- Responsive cho dashboard, trang hồ sơ/bảng xếp hạng, chat, màn chơi, toast, nhạc nổi và bottom navigation.
- Web theme-color/color-scheme cập nhật sang dark; Android versionName 3.62.0, versionCode 11.

## Bảo toàn chức năng
- Không sửa `src/main.js` ngoài việc thay cụm import CSS bằng một import duy nhất.
- Không thay đổi luồng luật cờ, nước đi, engine, tài khoản/chat API, ghép trận hay dữ liệu xếp hạng.
- Các stylesheet component cần cho chức năng vẫn nằm trong source; runtime nạp giao diện qua một entrypoint duy nhất. Các skin tổng thể cũ không còn trong source và không được nạp.

## Trạng thái kiểm thử
Xem `../reports/TEST_REPORT_V3_62_PRO_UI.md`.
