# v3.56.0 (from 3.55)
- Fixed: the "Câu lạc bộ" tab showed the Settings page. The Club and Lessons screens had been pasted inside `adoptSocialCallback()` (login callback), where `app` is undefined, so they never rendered. They are now real routed views (`renderClubView`, `renderLessonsView`) with their own wiring.
- New: real lesson content for all 9 chapters (explanation, key points, diagram position, caption), a lesson reader with a static board diagram, completion tracking, a progress bar, and a new "Bài học" tab. The old placeholder ("content will come in a later release") is gone.
- New: daily mission "Hoàn thành một bài học" (event `lesson_done`).
- Cleanup: removed two dead `typeof … !== 'undefined'` guards for names that never existed (`selectedClockPreset`, `applyBoardTheme`).
- Release hygiene: package.json, package-lock, index.html title, service worker cache key, Android versionName 3.56.0 / versionCode 9 and server/cloud health strings were still on 3.52.0; all are now aligned and the tests that pin them were updated.
- Tests: tests/v3-56-lessons-club.test.js (4 tests). Suite: 380 pass, 9 fail, 3 skipped. The 9 failures are only `Cannot find package 'chess.js'/'express'` — dependencies not installable in the offline sandbox; run `npm install` locally to execute them.

## Plans + review accuracy audit (v3.56 continued)
- New plans: Free (1 full-game review, that game stays viewable), Pro (365 days, renewals stack), Premium (lifetime). Pure logic in `src/plans.js`; plans only unlock review access and never touch bot strength, Elo or results.
- App: "Phân tích toàn ván" is gated (`requestReviewAccess` -> `runFullGameReview`); new "Gói Pro & Premium" tab; admin can grant Pro/Premium per user.
- Express backend: `POST /api/social/me/review-access` (consumes the free review per account, 402 when exhausted) and `PATCH /api/social/admin/users/:id/plan` (grant/revoke, audited); `entitlement` returned in the signed-in user.
- Review audit fixes:
  1. Accuracy cards always showed "—": rows carry `mover` but `computeGameAccuracy` read only `color`.
  2. The engine's own best move could be labelled Mistake/Blunder when the "after" search disagreed in depth; an `isBest` move now caps the drop.
  3. Stockfish `lowerbound`/`upperbound` info lines were accepted as exact scores; they are now ignored in the review.
  4. Accuracy % now uses the win-percent model (per-move 103.17*exp(-0.04354*drop)-3.17, volatility-weighted + harmonic mean) instead of fixed per-label weights; label weights remain as a fallback.
- Not done: real payments (Google Play Billing + server verification) and the same two routes in the Cloudflare Worker backend.

## Cloudflare Worker: plan routes (done)
- `cloudflare/src/index.js` now has the same plan API as the Express server, using the shared `src/plans.js`: `POST /api/social/me/review-access` (402 when the free review is used up), `PATCH /api/social/admin/users/:id/plan` (admin grant/revoke, audited) and `entitlement` on every signed-in user payload.
- Before this, the deployed Worker answered 404 to these routes, so the app silently fell back to the on-device quota (clearable by reinstalling). Plans were only enforced on the Express dev server.
- Tests: tests/cloudflare-plans.test.js (9 tests: free quota, same-game reopen, per-account isolation, admin-only grant, Pro 365 days + stacking + expiry, Premium lifetime, revoke, audit, restart persistence).
- Deploy note: the Worker imports `../../src/plans.js`, so Workers Builds must clone the whole repo (Root directory `cloudflare` is fine; uploading only the `cloudflare/` folder is not).
- Next: Google Play Billing + server-side purchase verification (a `POST /me/purchase/verify` route that calls grantPlan).

## Google Play Billing, plan A (one-time purchases)
- Worker: `GET /me/billing-config`, `POST /me/purchase/verify` (verifies the token with the Play Developer API using a service-account RS256 JWT; checks purchased state, product, account binding via obfuscatedAccountId, one token = one account, one order = one grant; acknowledges server-side), refund sync (`POST /admin/billing/sync-voided` + cron every 6 h) using `refundPurchase` (removes only that purchase's year).
- App: `src/billing-client.js` + Gói tab: buy Pro (renewals stack) / Premium, localized prices, "Khôi phục giao dịch", expiry nudge at <= 14 days. Consume (Pro) / acknowledge (Premium) happen only after the server accepted the token.
- Android: `PlayBilling.kt` (Billing Library 7.1.1) behind `AndroidBridge.billing*`.
- Setup and device test checklist: ../guides/BILLING_SETUP_VI.md.
- Tests: tests/cloudflare-billing.test.js (17), tests/billing-client.test.js (7).
- Not verified here: Kotlin compile and a real Play purchase (needs Play Console + a device).
