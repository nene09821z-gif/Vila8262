# ViLa Chess Professional Edition v3.67.0

## v3.67.0 — Review arrows, online study and beginner-strength tuning

- Separate SVG arrows for the played move and engine suggestion; keyboard replay controls.
- Mobile-friendly activation-code entry that keeps the input mounted during redemption.
- Lichess Opening Explorer lookup on the coach/study page.
- Offline puzzle cache expanded to 500 validated entries, with 50-puzzle download batches.
- Elo 500 remains an approximate beginner-training preset, not a benchmark-calibrated rating.


## v3.65.0 — Cài đặt nâng cao và giao diện thương hiệu
- Cài đặt được chia nhóm bàn cờ/quân cờ, gameplay, bot/phân tích, đồng hồ, âm thanh và hỗ trợ tiếp cận.
- Có công tắc tọa độ, nước đi trước, quân đã ăn, premove, xác nhận đầu hàng, âm thanh và thư viện khai cuộc.
- Chọn nhanh Elo bot; cấu hình engine, độ sâu, thời gian nghĩ, mức phân tích và đồng hồ mặc định.
- Ghép trận và bảng xác nhận/tổng kết dùng lớp giao diện VILA đồng bộ, responsive.
- Nhận diện khai cuộc chuẩn hóa SAN để xử lý dấu chiếu/nhập thành nhất quán. Danh mục kèm theo vẫn là bộ dự phòng, chưa đạt ngưỡng 3.000 dòng.
- Trang mã dùng thử: `AdminVila` mở Pro 5 ngày; `99vila` mở Premium Preview 60 giây. Cần cấu hình HMAC secret phía backend theo `TRIAL_CODES_SETUP_V3_65.md`; không nhúng mã trong bundle frontend.
- Intro thương hiệu: quân mã VILA dạng SVG nội tuyến với hoạt ảnh 3D khoảng 5 giây khi khởi chạy lần đầu.
- Kiểm tra và giới hạn xác minh: `../reports/V3_65_TRIAL_CODES_QA_REPORT.md`.

## v3.63.0 — Cửa hàng Pro/Premium và Messenger admin
- Dùng thử Pro: 50.000 xu cho 3 giờ, được tính bằng tiến trình cục bộ của tài khoản/thiết bị.
- Yêu cầu Pro: 1.000đ / 3 giờ; nút chỉ gửi yêu cầu đến máy chủ, admin phải kiểm tra thanh toán và xác nhận trước khi quyền được cấp.
- Premium: gửi đề xuất 1.000–100.000đ, không bán hoặc kích hoạt tự động; trao đổi với admin qua chat riêng.
- Quyết định gói được kiểm tra quyền ở backend, chống spam theo giới hạn, ghi audit và lưu yêu cầu/tin nhắn trong Cloudflare Durable Object.
- Chat có trợ lý tự động theo quy tắc; đây không phải LLM và không xác minh giao dịch ngân hàng tự động.

## Giao diện Professional
- `src/main.js` chỉ nạp một stylesheet runtime: `src/vila-professional.css`.
- `src/vila-professional.css` được tạo từ CSS nền, module tính năng và một theme thống nhất; các lớp skin toàn cục cũ đã được loại khỏi runtime.
- Ngôn ngữ thiết kế: navy/blue/cyan/gold, chữ tương phản cao, thẻ và huy hiệu có chiều sâu 3D, layout responsive, safe-area cho Android.
- Giữ các hệ thống cờ vua, premove, tài khoản, ghép trận, hồ sơ, cộng đồng, chat, bài tập, engine và phân tích; bổ sung luồng yêu cầu gói và duyệt ở máy chủ như mô tả trên.

## GitHub Android build
Push toàn bộ mã nguồn lên GitHub → Actions → `Cờ Vua ViLa Android build` → chạy workflow build Android. Chỉ phát hành APK nếu workflow hoàn tất thành công và kiểm tra được artifact.

## Kiểm tra cục bộ
```bash
npm install
npm run build
npm test
```

Nếu môi trường không tải được dependencies, cần báo rõ lỗi đó; kiểm thử tĩnh không thay thế cho build APK hoặc kiểm thử trực tiếp trên thiết bị.
