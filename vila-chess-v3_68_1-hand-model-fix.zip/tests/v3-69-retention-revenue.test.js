import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createDailyState, claimStreakChest, streakChestInfo, STREAK_CHEST_REWARDS } from '../src/daily-progress.js';

const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const worker = readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');

test('streak chest pays once per day and grows over the 7-day cycle', () => {
  const day = new Date(2026, 9, 25, 10);
  const state = createDailyState(day);
  const first = claimStreakChest(state, day);
  assert.equal(first.ok, true);
  assert.equal(first.reward, STREAK_CHEST_REWARDS[0]);
  assert.equal(first.state.coins, STREAK_CHEST_REWARDS[0]);
  const again = claimStreakChest(first.state, day);
  assert.equal(again.ok, false);
  assert.equal(streakChestInfo(first.state, day).claimed, true);
});

test('day 7 of the cycle also grants a streak freeze', () => {
  const day = new Date(2026, 9, 25, 10);
  const state = { ...createDailyState(day), streak: 7 };
  const result = claimStreakChest(state, day);
  assert.equal(result.ok, true);
  assert.equal(result.freeze, true);
  assert.equal(result.state.inventory.streakFreezes, 1);
});

test('admin revenue is admin-only and counts only approved requests', () => {
  const start = worker.indexOf("path === '/admin/revenue'");
  assert.ok(start > 0);
  const route = worker.slice(start, start + 2600);
  assert.match(route, /user\.role !== 'admin'/);
  assert.match(route, /item\.status === 'approved'/);
  assert.match(main, /loadAdminRevenue/);
});

test('home exposes collapsible folds, admin shortcut and streak chest', () => {
  assert.match(main, /data-home-fold/);
  assert.match(main, /data-home-admin/);
  assert.match(main, /data-streak-chest/);
});

test('worker creates the admin lazily when secrets are added after the Durable Object started', () => {
  assert.match(worker, /lastAdminBootstrapTry/);
  assert.match(worker, /this\.env\.ADMIN_USERNAME && this\.env\.ADMIN_PASSWORD/);
});
