import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { OPENINGS } from '../src/openings.js';
import { createOpeningIntel } from '../src/opening-intel.js';

const intel = createOpeningIntel(OPENINGS, Chess);
intel.buildAll();

test('names the opening family from the very first move', () => {
  const r = intel.analyze(['e4']);
  assert.ok(r?.name);
  assert.ok(['forming', 'book'].includes(r.status));
});

test('recognises a known line and reports book status', () => {
  const r = intel.analyze(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5']);
  assert.match(r.name, /Ruy Lopez/);
  assert.equal(r.status, 'book');
});

test('recognises transpositions by position, not move order', () => {
  const r = intel.analyze(['Nf3', 'e5', 'e4', 'Nc6', 'Bb5']);
  assert.match(r?.name || '', /Ruy Lopez/);
  assert.equal(r.transposed, true);
});

test('keeps the opening name after leaving book and reports the deviation', () => {
  const r = intel.analyze(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Qe2', 'b5', 'Bb3', 'd6', 'c3', 'O-O', 'h3', 'Na5', 'Bc2', 'c5', 'd4', 'Qc7', 'Nbd2', 'cxd4', 'cxd4', 'Nc6']);
  assert.ok(r?.name);
  assert.ok(['deviated', 'ended', 'book', 'forming'].includes(r.status));
});

test('safe mode never leaks book move suggestions (ranked fair-play)', () => {
  const r = intel.analyze(['e4', 'e5'], { safe: true });
  assert.deepEqual(r.nextMoves, []);
  const d = intel.analyze(['e4', 'e5', 'Qh5'], { safe: true });
  assert.deepEqual(d.nextMoves, []);
  assert.doesNotMatch(d.detail || '', /sách đi/);
});

test('annotate flags book plies for review', () => {
  const map = intel.annotate(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'h6', 'Qh5']);
  assert.equal(map[0].inBook, true);
  assert.equal(map.at(-1).inBook, false);
});

test('empty or illegal history returns null without throwing', () => {
  assert.equal(intel.analyze([]), null);
  assert.doesNotThrow(() => intel.analyze(['zz9']));
});

test('safe mode does not list likely continuations while an opening is still forming', () => {
  const r = intel.analyze(['e4'], { safe: true });
  assert.deepEqual(r.possible, []);
  assert.doesNotMatch(r.detail || '', /có thể thành/);
});
