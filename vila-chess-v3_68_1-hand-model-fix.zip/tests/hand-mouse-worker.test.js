import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import vm from 'node:vm';
import { spawnSync, spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const workerSource = read('src/hand-mouse-worker.js');

test('hand worker is a classic worker (MediaPipe needs importScripts, which module workers forbid)', () => {
  const main = read('src/main.js');
  assert.match(main, /new Worker\(new URL\('\.\/hand-mouse-worker\.js', import\.meta\.url\), \{ name: 'vila-hand-cursor' \}\)/);
  assert.doesNotMatch(main, /hand-mouse-worker\.js', import\.meta\.url\), \{ type: 'module'/);
  assert.match(main, /postMessage\(\{ type: 'init', baseUrl: new URL\('mediapipe\/', document\.baseURI\)\.href \}\)/);
  assert.match(workerSource, /importScripts\(/);
  assert.doesNotMatch(workerSource, /await import\(|^import |\bexport /m);
});

test('MediaPipe runtime and model are bundled at build time and cached offline', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.match(pkg.scripts.prebuild, /fetch-hand-model\.mjs/);
  assert.match(pkg.scripts['test:static'], /hand-mouse-worker\.test\.js/);
  assert.match(read('public/sw.js'), /\(engine\|pieces\|piece-sets\|assets\|mediapipe\)/);
  assert.match(read('.gitignore'), /\/public\/mediapipe\//);
});

// ---- Behavioural test: run the real worker source in a fake worker scope --------------------------------
const BUNDLE = `/* fake vision bundle HandLandmarker */${'x'.repeat(60_000)}`;
const MODEL = new Uint8Array(1_200_000);

function makeWorld(routes, { gpuFails = false } = {}) {
  const log = { fetched: [], imported: [], posted: [], created: [], scopeDuringImport: [] };
  const blobs = new Map();
  class FakeBlob { constructor(parts, options) { this.text = parts.join(''); this.type = options?.type; } }
  class FakeURL extends URL {
    static createObjectURL(blob) { const id = `blob:fake/${blobs.size}`; blobs.set(id, blob); return id; }
    static revokeObjectURL() {}
  }
  const context = vm.createContext({
    URL: FakeURL, Blob: FakeBlob, AbortSignal, Uint8Array, ArrayBuffer, Math, Number, String, Error, Promise, Object, RegExp,
    performance: { now: () => 1 }, console
  });
  context.self = context;
  context.location = { href: 'https://localhost/assets/hand-mouse-worker-abc.js' };
  // JSON round-trip: objects built inside the vm context belong to another realm, which deepEqual rejects.
  context.postMessage = message => log.posted.push(JSON.parse(JSON.stringify(message)));
  context.fetch = async url => {
    log.fetched.push(url);
    const route = routes(url);
    if (!route) return { ok: false, status: 404 };
    return { ok: true, status: 200, text: async () => route.text, arrayBuffer: async () => route.bytes.buffer.slice(route.bytes.byteOffset, route.bytes.byteOffset + route.bytes.byteLength) };
  };
  context.importScripts = blobUrl => {
    log.imported.push(blobUrl);
    assert.ok(blobs.get(blobUrl).text.includes('HandLandmarker'));
    log.scopeDuringImport.push({ module: typeof context.module, exports: typeof context.exports });
    // Behave like vision_bundle.cjs: attach the API to `exports`.
    context.exports.FilesetResolver = { forVisionTasks: async wasm => ({ wasm }) };
    context.exports.HandLandmarker = {
      createFromOptions: async (vision, options) => {
        log.created.push({ vision, delegate: options.baseOptions.delegate, buffer: options.baseOptions.modelAssetBuffer });
        if (gpuFails && options.baseOptions.delegate === 'GPU') throw new Error('GPU unavailable');
        return { detectForVideo: () => ({ landmarks: [[]], handednesses: [] }) };
      }
    };
  };
  vm.runInContext(workerSource, context);
  const init = async baseUrl => { await context.onmessage({ data: { type: 'init', baseUrl } }); return log.posted.at(-1); };
  return { context, log, init };
}

const LOCAL = 'https://localhost/mediapipe/';
const localRoutes = url => url === `${LOCAL}vision_bundle.js` ? { text: BUNDLE } : url === `${LOCAL}hand_landmarker.task` ? { bytes: MODEL } : null;

test('worker loads the bundled MediaPipe files first and never touches the network', async () => {
  const { context, log, init } = makeWorld(localRoutes);
  assert.deepEqual(await init(LOCAL), { type: 'ready' });
  assert.deepEqual(log.fetched, [`${LOCAL}vision_bundle.js`, `${LOCAL}hand_landmarker.task`]);
  assert.deepEqual(log.scopeDuringImport, [{ module: 'object', exports: 'object' }]);
  // MediaPipe's WASM glue changes behaviour when it sees module/exports, so they must be gone afterwards.
  assert.equal(typeof context.module, 'undefined');
  assert.equal(typeof context.exports, 'undefined');
  assert.equal(log.created[0].vision.wasm, `${LOCAL}wasm`);
  assert.equal(log.created[0].delegate, 'GPU');
  assert.equal(log.created[0].buffer.byteLength, MODEL.byteLength);
});

test('worker falls back to the CPU delegate when the GPU delegate cannot start', async () => {
  const { log, init } = makeWorld(localRoutes, { gpuFails: true });
  assert.deepEqual(await init(LOCAL), { type: 'ready' });
  assert.deepEqual(log.created.map(item => item.delegate), ['GPU', 'CPU']);
});

test('worker falls back to the CDN when the bundled model is missing', async () => {
  const cdn = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14';
  const routes = url => url === `${LOCAL}vision_bundle.js` ? { text: BUNDLE }
    : url === `${cdn}/vision_bundle.cjs` ? { text: BUNDLE }
    : url.startsWith('https://storage.googleapis.com/mediapipe-models/hand_landmarker/') ? { bytes: MODEL } : null;
  const { log, init } = makeWorld(routes);
  assert.deepEqual(await init(LOCAL), { type: 'ready' });
  assert.ok(log.fetched.includes(`${cdn}/vision_bundle.cjs`));
  assert.ok(log.fetched.some(url => url.endsWith('hand_landmarker.task') && url.startsWith('https://storage.googleapis.com/')));
  assert.equal(log.created.at(-1).vision.wasm, `${cdn}/wasm`);
});

test('a server that answers 200 with an HTML page instead of the files is rejected, not trusted', async () => {
  const html = { text: '<!doctype html><title>index</title>', bytes: new TextEncoder().encode('<!doctype html>') };
  const { init } = makeWorld(() => html);
  const result = await init(LOCAL);
  assert.equal(result.type, 'fatal');
  assert.match(result.error, /tích hợp sẵn: thư viện nhận diện không hợp lệ/);
  assert.match(result.error, /CDN: thư viện nhận diện không hợp lệ/);
});

test('when everything fails the fatal message names both sources and the reason', async () => {
  const { init } = makeWorld(() => null);
  const result = await init(LOCAL);
  assert.equal(result.type, 'fatal');
  assert.match(result.error, /tích hợp sẵn: thư viện nhận diện: HTTP 404/);
  assert.match(result.error, /CDN: thư viện nhận diện: HTTP 404/);
});

test('without a base URL the worker resolves the bundled folder next to its own assets directory', async () => {
  const { log, init } = makeWorld(url => url === 'https://localhost/mediapipe/vision_bundle.js' ? { text: BUNDLE } : url === 'https://localhost/mediapipe/hand_landmarker.task' ? { bytes: MODEL } : null);
  assert.deepEqual(await init(undefined), { type: 'ready' });
  assert.equal(log.fetched[0], 'https://localhost/mediapipe/vision_bundle.js');
});

test('frames are turned into fingertip and pinch landmarks only after the model is ready', async () => {
  const { context, log, init } = makeWorld(localRoutes);
  const closed = [];
  const bitmap = () => ({ close: () => closed.push(true) });
  await context.onmessage({ data: { type: 'frame', bitmap: bitmap(), timestamp: 5 } });
  assert.equal(log.posted.length, 0, 'ignores frames before init');
  await init(LOCAL);
  // swap in a landmarker that sees a hand
  context.exports = {};
  const points = Array.from({ length: 21 }, () => ({ x: 0, y: 0 }));
  points[8] = { x: 0.5, y: 0.5 }; points[4] = { x: 0.5, y: 0.53 };
  vm.runInContext('handLandmarker = { detectForVideo: () => ({ landmarks: [PTS], handednesses: [[{ score: 0.9 }]] }) }', Object.assign(context, { PTS: points }));
  await context.onmessage({ data: { type: 'frame', bitmap: bitmap(), timestamp: 6 } });
  const landmarks = log.posted.at(-1);
  assert.equal(landmarks.type, 'landmarks');
  assert.deepEqual(landmarks.point, { x: 0.5, y: 0.5 });
  assert.ok(Math.abs(landmarks.pinchDistance - 0.03) < 1e-9);
  assert.equal(closed.length, 2, 'every bitmap is closed');
});

// ---- scripts/fetch-hand-model.mjs against a local fake CDN ------------------------------------------------
function startFakeCdn({ missingModel = false } = {}) {
  const hits = [];
  const server = http.createServer((request, response) => {
    hits.push(request.url);
    const url = request.url;
    if (url.endsWith('vision_bundle.cjs')) return response.end(BUNDLE);
    if (url.endsWith('.js')) return response.end('x'.repeat(6_000));
    if (url.endsWith('.wasm')) return response.end(Buffer.alloc(1_100_000));
    if (url.endsWith('.task') && !missingModel) return response.end(Buffer.alloc(1_100_000));
    response.statusCode = 404; response.end('missing');
  });
  return new Promise(resolve => server.listen(0, '127.0.0.1', () => resolve({ server, hits, base: `http://127.0.0.1:${server.address().port}` })));
}
function runScript(env, args = []) {
  return new Promise(resolve => {
    const child = spawn(process.execPath, [path.join(root, 'scripts/fetch-hand-model.mjs'), ...args], { env: { ...process.env, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '';
    child.stdout.on('data', chunk => { output += chunk; });
    child.stderr.on('data', chunk => { output += chunk; });
    child.on('close', code => resolve({ code, output }));
  });
}

test('fetch-hand-model downloads, validates, skips files it already has, and writes a licence notice', async () => {
  const { server, hits, base } = await startFakeCdn();
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'hand-model-'));
  try {
    const env = { MEDIAPIPE_CDN: base, MEDIAPIPE_MODEL_URL: `${base}/hand_landmarker.task`, HAND_MODEL_OUTPUT_DIR: out };
    const first = await runScript(env);
    assert.equal(first.code, 0, first.output);
    for (const file of ['vision_bundle.js', 'wasm/vision_wasm_internal.js', 'wasm/vision_wasm_internal.wasm', 'wasm/vision_wasm_nosimd_internal.js', 'wasm/vision_wasm_nosimd_internal.wasm', 'hand_landmarker.task', 'NOTICE.txt']) {
      assert.ok(fs.existsSync(path.join(out, file)), `${file} should exist`);
    }
    assert.ok(!fs.readdirSync(out, { recursive: true }).some(name => String(name).endsWith('.part')), 'no temporary files left behind');
    assert.match(fs.readFileSync(path.join(out, 'NOTICE.txt'), 'utf8'), /Apache License 2\.0/);
    const hitsAfterFirst = hits.length;
    assert.equal((await runScript(env)).code, 0);
    assert.equal(hits.length, hitsAfterFirst, 'second run reuses valid files');
  } finally { server.close(); fs.rmSync(out, { recursive: true, force: true }); }
});

test('fetch-hand-model only warns on failure unless REQUIRE_HAND_MODEL=1, and SKIP_HAND_MODEL=1 does nothing', async () => {
  const { server, base } = await startFakeCdn({ missingModel: true });
  const out = fs.mkdtempSync(path.join(os.tmpdir(), 'hand-model-'));
  try {
    const env = { MEDIAPIPE_CDN: base, MEDIAPIPE_MODEL_URL: `${base}/hand_landmarker.task`, HAND_MODEL_OUTPUT_DIR: out };
    const soft = await runScript(env);
    assert.equal(soft.code, 0, soft.output);
    assert.match(soft.output, /hand_landmarker\.task: HTTP 404/);
    assert.ok(!fs.existsSync(path.join(out, 'NOTICE.txt')));
    assert.equal((await runScript({ ...env, REQUIRE_HAND_MODEL: '1' })).code, 1);
    const skipDir = path.join(out, 'skipped');
    const skipped = await runScript({ ...env, SKIP_HAND_MODEL: '1', HAND_MODEL_OUTPUT_DIR: skipDir });
    assert.equal(skipped.code, 0);
    assert.ok(!fs.existsSync(skipDir));
  } finally { server.close(); fs.rmSync(out, { recursive: true, force: true }); }
});
