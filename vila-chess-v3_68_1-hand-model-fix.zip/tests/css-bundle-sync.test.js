import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { buildProfessionalCss, layers } from '../scripts/build-professional-css.mjs';

const src = new URL('../src/', import.meta.url);
const bundle = fs.readFileSync(new URL('vila-professional.css', src), 'utf8');

test('src/vila-professional.css is exactly what the layer files produce (run `npm run build:professional-css`)', () => {
  const expected = buildProfessionalCss();
  if (bundle !== expected) {
    // Locate the first diverging layer so the failure message is actionable.
    const stale = layers.find(file => {
      const block = fs.readFileSync(new URL(file, src), 'utf8').trim();
      return !bundle.includes(block);
    });
    assert.fail(`Runtime CSS bundle is stale${stale ? ` — layer "${stale}" changed` : ''}. Run: npm run build:professional-css`);
  }
});

test('every CSS layer exists, is non-empty and has balanced braces', () => {
  for (const file of layers) {
    const css = fs.readFileSync(new URL(file, src), 'utf8').replace(/\/\*[\s\S]*?\*\//g, '');
    assert.ok(css.trim().length > 0, `${file} is empty`);
    const open = (css.match(/\{/g) || []).length;
    const close = (css.match(/\}/g) || []).length;
    assert.equal(open, close, `${file} has unbalanced braces (${open} vs ${close})`);
  }
});

test('the app imports only the bundle plus the intro stylesheet', () => {
  const main = fs.readFileSync(new URL('main.js', src), 'utf8');
  const imports = [...main.matchAll(/import\s+['"]\.\/([\w.-]+\.css)['"]/g)].map(m => m[1]);
  assert.deepEqual(imports, ['vila-professional.css', 'vila-intro.css']);
});

test('no layer is hand-edited only in the bundle: every bundle layer marker maps to a source layer', () => {
  const markers = [...bundle.matchAll(/\/\* Professional stylesheet layer: ([\w.-]+) \*\//g)].map(m => m[1]);
  assert.deepEqual(markers, layers);
});
