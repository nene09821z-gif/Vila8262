/**
 * Client for the bundled VILA puzzle pack (public/puzzles/, built by scripts/build-puzzle-pack.mjs from the CC0 Lichess database).
 * Everything is static JSON served with the app: no network service, works offline, and every puzzle is
 * re-validated move by move with the app's chess rules before it is ever shown.
 */
import { uciToMove } from './lichess-puzzle.js';

export const PACK_SEEN_KEY = 'vila.chess.puzzles.packSeen.v1';
export const PACK_SEEN_LIMIT = 20000;
export const DEFAULT_PACK_URL = './puzzles/';

const SAFE_FILE = /^band-\d{3,4}\.json$/;
const THEME_RE = /^[A-Za-z0-9]{2,32}$/;
const ID_RE = /^[A-Za-z0-9_-]{3,12}$/;
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
const FEN_RE = /^[1-8pnbrqkPNBRQK/]{15,80} [wb] (?:-|[KQkq]{1,4}) (?:-|[a-h][36]) \d+ \d+$/;
/** Tags describing a puzzle's length or origin rather than its idea: not useful as a training filter. */
const META_THEMES = new Set(['short', 'long', 'veryLong', 'oneMove', 'master', 'masterVsMaster', 'superGM']);
/** Lichess' own difficulty offsets (relative to the player's puzzle rating). */
const DIFFICULTY_OFFSET = Object.freeze({ easiest: -600, easier: -300, normal: 0, harder: 300, hardest: 600 });

const finiteInt = value => (Number.isFinite(Number(value)) && value !== '' && value !== null ? Math.floor(Number(value)) : null);

export function ratingForDifficulty(baseRating, difficulty = 'normal') {
  const base = Number.isFinite(Number(baseRating)) ? Number(baseRating) : 1200;
  return Math.max(400, Math.min(3300, base + (DIFFICULTY_OFFSET[difficulty] ?? 0)));
}

/** Validate index.json. File names are whitelisted so a tampered index cannot make the app fetch an arbitrary path. */
export function normalizePackIndex(raw) {
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.bands)) return null;
  const bandWidth = Math.max(10, Math.min(500, finiteInt(raw.bandWidth) ?? 100));
  const byMin = new Map();
  for (const band of raw.bands) {
    const min = finiteInt(band?.min); const count = finiteInt(band?.count);
    if (min === null || min < 0 || min > 4000 || !count || count < 1 || typeof band.file !== 'string' || !SAFE_FILE.test(band.file)) continue;
    byMin.set(min, { min, max: finiteInt(band.max) ?? min + bandWidth - 1, file: band.file, count });
  }
  const bands = [...byMin.values()].sort((a, b) => a.min - b.min);
  if (!bands.length) return null;
  const themes = {};
  if (raw.themes && typeof raw.themes === 'object') {
    for (const [name, count] of Object.entries(raw.themes)) if (THEME_RE.test(name) && finiteInt(count) > 0) themes[name] = finiteInt(count);
  }
  return {
    version: finiteInt(raw.version) ?? 1, generated: typeof raw.generated === 'string' ? raw.generated.slice(0, 10) : '',
    bandWidth, total: bands.reduce((sum, band) => sum + band.count, 0), bands, themes,
    verified: raw.verified && typeof raw.verified === 'object' ? { checked: finiteInt(raw.verified.checked) ?? 0, kept: finiteInt(raw.verified.kept) ?? 0, engine: String(raw.verified.engine || '').slice(0, 60) } : null,
  };
}

const centerOf = band => (band.min + band.max + 1) / 2;

/** Index of the band closest to `rating` (clamped to the ends of the pack). */
export function nearestBandIndex(index, rating) {
  const target = Number.isFinite(Number(rating)) ? Number(rating) : 1200;
  let best = 0; let bestGap = Infinity;
  index.bands.forEach((band, i) => { const gap = Math.abs(centerOf(band) - target); if (gap < bestGap) { best = i; bestGap = gap; } });
  return best;
}

/** Band indexes to try, closest first, widening up and down, limited to `radius` bands around the nearest. */
export function bandSearchOrder(index, rating, radius = 3) {
  const target = Number.isFinite(Number(rating)) ? Number(rating) : 1200;
  const nearest = nearestBandIndex(index, target);
  return index.bands.map((band, i) => ({ i, gap: Math.abs(centerOf(band) - target) }))
    .filter(item => Math.abs(item.i - nearest) <= radius)
    .sort((a, b) => a.gap - b.gap || a.i - b.i).map(item => item.i);
}

/** Validate one compact row: [id, fen, "uci uci …", rating, "theme theme …", popularity]. */
export function parsePackRow(row) {
  if (!Array.isArray(row) || row.length < 6) return null;
  const [id, fen, moveText, rating, themeText, popularity] = row;
  if (typeof id !== 'string' || !ID_RE.test(id) || typeof fen !== 'string' || !FEN_RE.test(fen)) return null;
  const moves = typeof moveText === 'string' ? moveText.trim().split(/\s+/) : [];
  if (moves.length < 2 || moves.length > 25 || moves.some(move => !UCI_RE.test(move))) return null;
  const rate = Number(rating);
  if (!Number.isFinite(rate) || rate < 0 || rate > 4000) return null;
  const themes = typeof themeText === 'string' ? themeText.trim().split(/\s+/).filter(theme => THEME_RE.test(theme)).slice(0, 16) : [];
  return { id, fen, moves, rating: Math.round(rate), themes, popularity: Number.isFinite(Number(popularity)) ? Number(popularity) : 0 };
}

/** Training-filter options: themes with at least `minCount` puzzles, most common first, without length/origin tags. */
export function themeOptions(index, minCount = 30) {
  return Object.entries(index?.themes || {})
    .filter(([theme, count]) => !META_THEMES.has(theme) && count >= minCount)
    .map(([theme, count]) => ({ theme, count }))
    .sort((a, b) => b.count - a.count || a.theme.localeCompare(b.theme));
}

/**
 * Turn a pack row into what the puzzle board consumes. The Lichess FEN is the position BEFORE the opponent's
 * move, so that move is played first; the remaining moves alternate player / reply. Returns null if any move is illegal.
 */
export function preparePackEntry(entry, ChessClass) {
  if (!entry || typeof ChessClass !== 'function') return null;
  try {
    const board = new ChessClass(entry.fen);
    const opening = board.move(uciToMove(entry.moves[0]));
    if (!opening) return null;
    const fen = board.fen();
    const solution = entry.moves.slice(1);
    const check = new ChessClass(fen);
    const sanLine = [];
    for (const uci of solution) {
      const made = check.move(uciToMove(uci));
      if (!made) return null;
      sanLine.push(made.san);
    }
    const mate = entry.themes.map(theme => /^mateIn(\d)$/.exec(theme)).find(Boolean);
    return {
      id: entry.id, fen, moves: solution, sanLine, firstMove: solution[0], opponentMove: entry.moves[0],
      rating: entry.rating, plays: 0, popularity: entry.popularity, themes: [...entry.themes], mateIn: mate ? Number(mate[1]) : 0,
      initialPly: 0, gameUrl: `https://lichess.org/training/${encodeURIComponent(entry.id)}`, source: 'lichess', pack: true,
    };
  } catch { return null; }
}

/** Small deterministic string hash (FNV-1a) so the daily puzzle is identical on every device for a given date. */
export function hashString(text) {
  let h = 2166136261;
  for (const ch of String(text)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; }
  return h >>> 0;
}

/**
 * @param {{fetchImpl?:Function, baseUrl?:string, maxCachedBands?:number, retryMs?:number, now?:()=>number}} [options]
 */
export function createPuzzlePack({ fetchImpl = globalThis.fetch, baseUrl = DEFAULT_PACK_URL, maxCachedBands = 6, retryMs = 30_000, now = () => Date.now() } = {}) {
  const base = String(baseUrl).endsWith('/') ? String(baseUrl) : `${baseUrl}/`;
  let indexPromise = null; let indexFailedAt = 0;
  const bands = new Map(); // file -> rows (insertion order = recency)
  const bad = new Set(); // ids whose line failed the chess-rules check on this device

  async function getJson(file) {
    if (typeof fetchImpl !== 'function') return null;
    try {
      const response = await fetchImpl(`${base}${file}`);
      return response?.ok ? await response.json() : null;
    } catch { return null; }
  }

  function loadIndex() {
    if (indexPromise) return indexPromise;
    if (indexFailedAt && now() - indexFailedAt < retryMs) return Promise.resolve(null);
    indexPromise = getJson('index.json').then(raw => {
      const index = normalizePackIndex(raw);
      if (!index) { indexPromise = null; indexFailedAt = now(); }
      return index;
    });
    return indexPromise;
  }

  async function loadBand(band) {
    if (bands.has(band.file)) { const rows = bands.get(band.file); bands.delete(band.file); bands.set(band.file, rows); return rows; }
    const raw = await getJson(band.file);
    const rows = Array.isArray(raw) ? raw.map(parsePackRow).filter(Boolean) : [];
    bands.set(band.file, rows);
    while (bands.size > maxCachedBands) bands.delete(bands.keys().next().value);
    return rows;
  }

  const asSet = seen => (seen instanceof Set ? seen : new Set(Array.isArray(seen) ? seen : []));

  return {
    index: loadIndex,
    async available() { return Boolean(await loadIndex()); },
    async stats() { const index = await loadIndex(); return index ? { total: index.total, bands: index.bands.length, generated: index.generated, verified: index.verified } : null; },
    async themes(minCount = 30) { return themeOptions(await loadIndex(), minCount); },

    /**
     * Pick an unseen puzzle near `rating` (optionally with a theme). Searches the closest bands first and
     * only widens to the whole pack when the neighbourhood is exhausted. Returns null when nothing is left.
     */
    async pick({ rating = 1200, theme = '', seenIds = new Set(), rng = Math.random, ChessClass, difficulty } = {}) {
      const index = await loadIndex();
      if (!index) return null;
      if (theme && Object.keys(index.themes).length && !(index.themes[theme] > 0)) return null;
      const seen = asSet(seenIds);
      const target = difficulty ? ratingForDifficulty(rating, difficulty) : rating;
      const near = bandSearchOrder(index, target, 3);
      const rest = index.bands.map((_, i) => i).filter(i => !near.includes(i)).sort((a, b) => Math.abs(centerOf(index.bands[a]) - target) - Math.abs(centerOf(index.bands[b]) - target));
      for (const i of [...near, ...rest]) {
        const rows = await loadBand(index.bands[i]);
        const candidates = rows.filter(row => !seen.has(row.id) && !bad.has(row.id) && (!theme || row.themes.includes(theme)));
        // Prefer puzzles closest to the target rating, but keep a random choice among the best quarter so sessions differ.
        const ranked = candidates.map(row => ({ row, gap: Math.abs(row.rating - target) })).sort((a, b) => a.gap - b.gap || b.row.popularity - a.row.popularity);
        const pool = ranked.slice(0, Math.max(8, Math.ceil(ranked.length / 4)));
        for (let attempt = 0; attempt < 6 && pool.length; attempt += 1) {
          const at = Math.min(pool.length - 1, Math.floor(rng() * pool.length));
          const [{ row }] = pool.splice(at, 1);
          const prepared = preparePackEntry(row, ChessClass);
          if (prepared) return prepared;
          bad.add(row.id);
        }
      }
      return null;
    },

    /** The same puzzle for everyone on a given date (YYYY-MM-DD), from the mid-rating bands. */
    async daily(dateKey, ChessClass) {
      const index = await loadIndex();
      if (!index) return null;
      const hash = hashString(`vila-daily:${dateKey}`);
      const mid = index.bands.filter(band => band.min >= 1000 && band.min <= 2200);
      const bandList = mid.length ? mid : index.bands;
      for (let shift = 0; shift < bandList.length; shift += 1) {
        const band = bandList[(hash + shift) % bandList.length];
        const rows = (await loadBand(band)).filter(row => row.popularity >= 90 || !row.popularity);
        const usable = rows.length ? rows : await loadBand(band);
        for (let step = 0; step < Math.min(usable.length, 12); step += 1) {
          const row = usable[(Math.floor(hash / bandList.length) + step * 7919) % usable.length];
          const prepared = row && preparePackEntry(row, ChessClass);
          if (prepared) return { ...prepared, dateKey };
        }
      }
      return null;
    },
  };
}

export function loadPackSeen(storage = globalThis.localStorage) {
  try {
    const parsed = JSON.parse(storage?.getItem?.(PACK_SEEN_KEY) || '[]');
    return new Set(Array.isArray(parsed) ? parsed.filter(id => typeof id === 'string' && ID_RE.test(id)).slice(-PACK_SEEN_LIMIT) : []);
  } catch { return new Set(); }
}

/** Add `id` to the seen set (newest last) and persist a bounded copy. Returns the same Set. */
export function rememberPackSeen(storage, seen, id, limit = PACK_SEEN_LIMIT) {
  if (!ID_RE.test(String(id))) return seen;
  seen.delete(id); seen.add(id);
  while (seen.size > limit) seen.delete(seen.values().next().value);
  try { storage?.setItem?.(PACK_SEEN_KEY, JSON.stringify([...seen])); } catch { /* storage full or unavailable: the in-memory set still works */ }
  return seen;
}

/** Forget everything (used when the player has seen the whole pack). */
export function resetPackSeen(storage, seen) {
  seen.clear();
  try { storage?.setItem?.(PACK_SEEN_KEY, '[]'); } catch { /* ignore */ }
  return seen;
}
