import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { normalizeSettings, DEFAULTS } from '../src/settings-schema.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('settings: private analysis server fields are validated and off by default', () => {
  assert.equal(DEFAULTS.analysisServerEnabled, false);
  assert.equal(normalizeSettings({}).analysisServerEnabled, false);
  assert.equal(normalizeSettings({ analysisServerEnabled: true }).analysisServerEnabled, false, 'cannot be enabled without a URL');
  assert.equal(normalizeSettings({ analysisServerEnabled: true, analysisServerUrl: 'http://example.com' }).analysisServerUrl, '', 'plain http is refused for public hosts');
  const lan = normalizeSettings({ analysisServerEnabled: true, analysisServerUrl: 'http://192.168.1.5:8788/path', analysisServerKey: ' ab cd ' });
  assert.equal(lan.analysisServerEnabled, true); assert.equal(lan.analysisServerUrl, 'http://192.168.1.5:8788'); assert.equal(lan.analysisServerKey, 'abcd');
  assert.equal(normalizeSettings({ analysisServerUrl: 'https://user:pw@evil.example' }).analysisServerUrl, '');
});

test('app wiring: review streams to the private server and falls back to the device engine', () => {
  assert.match(main, /startRemoteReview\(reviewSession\)/);
  assert.match(main, /feedRemoteReviewResult/);
  assert.match(main, /receiveReviewInfo\(line\)/);
  assert.match(main, /remote\.controller\?\.abort|remote\?\.controller\?\.abort/);
  assert.match(main, /Chuyển sang Stockfish trên máy/);
  assert.match(main, /settingsRemoteTest/);
});

test('app wiring: puzzle pack is the first source, with daily fallback and theme filter', () => {
  const start = main.indexOf('const packPuzzle = await pickPackPuzzle()');
  const online = main.indexOf('const onlinePuzzle = await loadLichessTrainingPuzzle');
  assert.ok(start > 0 && start < online, 'pack is tried before the network');
  assert.match(main, /puzzlePack\.daily\(dateKey, Chess\)/);
  assert.match(main, /id="puzzlePackTheme"/);
});
