#!/usr/bin/env node
/**
 * Build the bundled VILA puzzle pack from the open Lichess puzzle database (CC0).
 *
 *   1. Download https://database.lichess.org/lichess_db_puzzle.csv.zst  (≈ 5 triệu câu)
 *   2. node scripts/build-puzzle-pack.mjs lichess_db_puzzle.csv.zst --max 40000
 *
 * Output (public/puzzles/):
 *   index.json            – bands, theme counts, totals
 *   band-<min>.json       – compact rows [id, fen, "uci uci …", rating, "theme theme …", popularity]
 *
 * `fen` is the Lichess FEN BEFORE the opponent's first move; moves[0] is that opponent move.
 * The app plays it automatically (see src/puzzle-pack.js → preparePackEntry).
 *
 * Options: --out <dir> (default public/puzzles)  --verify-url <https://server> --verify-key <key> [--verify-quality fast|standard|deep]
 *   [--verify-concurrency 4] [--keep-non-unique]: every selected puzzle is checked by the VILA Stockfish server
 *   (POST /v1/puzzle/verify) and dropped unless the engine confirms the solution.
 *
 * Selection: quality filters (popularity, plays, rating deviation) then a stratified pick per rating band
 * so that rare themes (smothered mate, zugzwang, …) are represented instead of being drowned by forks.
 */
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const BAND_WIDTH = 100;
export const MIN_RATING = 400;
export const MAX_RATING = 3200;
const UCI = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
const FEN_RE = /^[1-8pnbrqkPNBRQK/]{15,80} [wb] (?:-|[KQkq]{1,4}) (?:-|[a-h][36]) \d+ \d+$/;
const THEME_RE = /^[A-Za-z0-9]{2,32}$/;

/** Parse one CSV row of lichess_db_puzzle: PuzzleId,FEN,Moves,Rating,RatingDeviation,Popularity,NbPlays,Themes,GameUrl,OpeningTags */
export function parseRow(line) {
  const c = line.split(',');
  if (c.length < 8 || c[0] === 'PuzzleId') return null;
  const [id, fen, moves, rating, dev, popularity, plays, themes] = c;
  return {
    id, fen, moves: moves.trim().split(/\s+/),
    rating: Number(rating), dev: Number(dev), popularity: Number(popularity), plays: Number(plays),
    themes: themes.trim().split(/\s+/).filter(Boolean),
  };
}

export function passesFilters(p, opts) {
  if (!p || !/^[A-Za-z0-9_-]{3,12}$/.test(p.id) || !FEN_RE.test(p.fen)) return false;
  if (!Number.isFinite(p.rating) || p.rating < MIN_RATING || p.rating >= MAX_RATING + BAND_WIDTH) return false;
  if (!(p.popularity >= opts.minPopularity) || !(p.plays >= opts.minPlays) || !(p.dev <= opts.maxDeviation)) return false;
  // Opponent move + 1..6 player moves (with replies) keeps puzzles quick to solve on a phone.
  if (p.moves.length < 2 || p.moves.length > opts.maxPlies + 1 || p.moves.some(m => !UCI.test(m))) return false;
  if (!p.themes.length || p.themes.some(t => !THEME_RE.test(t))) return false;
  return true;
}

export const bandOf = rating => Math.max(MIN_RATING, Math.min(MAX_RATING, Math.floor(rating / BAND_WIDTH) * BAND_WIDTH));
export const fenKey = fen => fen.split(' ').slice(0, 4).join(' ');

/** Stream a .csv / .csv.gz / .csv.zst file line by line. */
export async function* readLines(file) {
  let input;
  if (file.endsWith('.zst')) {
    if (typeof zlib.createZstdDecompress === 'function') {
      input = fs.createReadStream(file).pipe(zlib.createZstdDecompress());
    } else {
      const child = spawn('zstd', ['-dc', file], { stdio: ['ignore', 'pipe', 'inherit'] });
      child.on('error', () => { console.error('Cần Node ≥ 22.15 hoặc lệnh `zstd`. Hoặc giải nén trước: zstd -d file.csv.zst'); process.exit(1); });
      input = child.stdout;
    }
  } else if (file.endsWith('.gz')) input = fs.createReadStream(file).pipe(zlib.createGunzip());
  else input = fs.createReadStream(file);
  for await (const line of readline.createInterface({ input, crlfDelay: Infinity })) yield line;
}

/**
 * Pass 2 helper: pick up to `cap` puzzles for one band, round-robin over each puzzle's rarest theme
 * so every theme gets coverage, highest popularity first inside a theme.
 */
export function selectBand(candidates, themeRank, cap) {
  const buckets = new Map();
  for (const p of candidates) {
    const key = p.themes.reduce((best, t) => ((themeRank.get(t) ?? Infinity) < (themeRank.get(best) ?? Infinity) ? t : best), p.themes[0]);
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(p);
  }
  const lists = [...buckets.entries()].sort((a, b) => a[1].length - b[1].length).map(([, list]) => list.sort((a, b) => (b.popularity - a.popularity) || (b.plays - a.plays) || a.id.localeCompare(b.id)));
  const picked = [];
  for (let round = 0; picked.length < cap; round += 1) {
    let any = false;
    for (const list of lists) {
      if (round < list.length) { picked.push(list[round]); any = true; if (picked.length >= cap) break; }
    }
    if (!any) break;
  }
  return picked;
}

export function packRow(p) {
  return [p.id, p.fen, p.moves.join(' '), p.rating, p.themes.join(' '), p.popularity];
}


/**
 * Ask the private Stockfish server to confirm each puzzle. Returns { kept, checked, dropped, errors }.
 * Network/engine errors never silently keep or drop a puzzle: an errored puzzle is dropped and counted.
 */
export async function verifyPicked(picks, { url, key, quality = 'standard', concurrency = 4, requireUnique = true, fetchImpl = globalThis.fetch, onProgress } = {}) {
  const base = String(url || '').replace(/\/+$/, '');
  const kept = []; let checked = 0; let errors = 0; let cursor = 0;
  const worker = async () => {
    while (cursor < picks.length) {
      const p = picks[cursor++];
      try {
        const response = await fetchImpl(`${base}/v1/puzzle/verify`, {
          method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
          body: JSON.stringify({ fen: p.fen, moves: p.moves, opponentFirst: true, quality, requireUnique }),
        });
        if (response.status === 401) throw Object.assign(new Error('Khóa máy chủ phân tích không đúng.'), { fatal: true });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const result = await response.json();
        if (result?.ok === true) kept.push(p);
      } catch (error) { if (error.fatal) throw error; errors += 1; }
      checked += 1; onProgress?.(checked, picks.length);
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, concurrency) }, worker));
  return { kept, checked, dropped: checked - kept.length, errors };
}

async function main() {
  const args = process.argv.slice(2);
  const valueFlags = new Set(['max', 'min-popularity', 'min-plays', 'max-deviation', 'max-plies', 'out', 'verify-url', 'verify-key', 'verify-quality', 'verify-concurrency']);
  const positional = [];
  const named = new Map();
  for (let i = 0; i < args.length; i += 1) {
    if (args[i].startsWith('--')) { const name = args[i].slice(2); if (valueFlags.has(name)) { named.set(name, args[i + 1]); i += 1; } else named.set(name, true); } else positional.push(args[i]);
  }
  const file = positional[0];
  const flag = (name, fallback) => (named.has(name) && Number.isFinite(Number(named.get(name))) ? Number(named.get(name)) : fallback);
  if (!file || !fs.existsSync(file)) {
    console.error('Cách dùng: node scripts/build-puzzle-pack.mjs <lichess_db_puzzle.csv[.zst|.gz]> [--max 40000] [--min-popularity 90] [--min-plays 1000] [--max-deviation 85] [--max-plies 12] [--out thư-mục] [--verify-url https://… --verify-key … [--verify-quality standard] [--verify-concurrency 4] [--keep-non-unique]]');
    process.exit(1);
  }
  const opts = {
    max: flag('max', 40000), minPopularity: flag('min-popularity', 90), minPlays: flag('min-plays', 1000),
    maxDeviation: flag('max-deviation', 85), maxPlies: flag('max-plies', 12),
  };
  const defaultOut = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public', 'puzzles');
  const outDir = named.get('out') ? path.resolve(String(named.get('out'))) : defaultOut;
  const verifyUrl = named.get('verify-url') ? String(named.get('verify-url')) : '';
  const verifyKey = named.get('verify-key') || process.env.ANALYSIS_API_KEY || '';
  if (verifyUrl && !verifyKey) { console.error('Thiếu --verify-key (hoặc biến môi trường ANALYSIS_API_KEY).'); process.exit(1); }
  const bandCount = (MAX_RATING - MIN_RATING) / BAND_WIDTH + 1;
  const cap = Math.ceil(opts.max / bandCount);

  // Pass 1: theme frequency over the filtered set (rarest theme decides the bucket).
  const themeCounts = new Map();
  let scanned = 0; let kept = 0;
  for await (const line of readLines(file)) {
    scanned += 1;
    const p = parseRow(line);
    if (!passesFilters(p, opts)) continue;
    kept += 1;
    for (const t of p.themes) themeCounts.set(t, (themeCounts.get(t) || 0) + 1);
  }
  console.log(`Pass 1: đọc ${scanned.toLocaleString()} dòng, ${kept.toLocaleString()} câu đạt bộ lọc, ${themeCounts.size} chủ đề.`);
  const themeRank = new Map([...themeCounts.entries()].sort((a, b) => a[1] - b[1]).map(([t], i) => [t, i]));

  // Pass 2: keep a bounded candidate list per band (3× the cap) so memory stays small.
  const perBand = new Map();
  const seen = new Set();
  for await (const line of readLines(file)) {
    const p = parseRow(line);
    if (!passesFilters(p, opts)) continue;
    const key = fenKey(p.fen);
    if (seen.has(key)) continue;
    seen.add(key);
    const band = bandOf(p.rating);
    if (!perBand.has(band)) perBand.set(band, []);
    const list = perBand.get(band);
    list.push(p);
    if (list.length > cap * 12) { list.sort((a, b) => b.popularity - a.popularity || b.plays - a.plays); list.length = cap * 6; }
  }

  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });
  const bands = []; const themeTotals = {}; let total = 0;
  const verifyStats = { checked: 0, kept: 0 };
  for (const band of [...perBand.keys()].sort((a, b) => a - b)) {
    let picked = selectBand(perBand.get(band), themeRank, cap);
    if (verifyUrl) {
      const result = await verifyPicked(picked, { url: verifyUrl, key: verifyKey, quality: String(named.get('verify-quality') || 'standard'), concurrency: flag('verify-concurrency', 4), requireUnique: !named.has('keep-non-unique') });
      verifyStats.checked += result.checked; verifyStats.kept += result.kept.length;
      console.log(`Dải ${band}: Stockfish giữ ${result.kept.length}/${result.checked} câu${result.errors ? ` (${result.errors} lỗi kết nối bị loại)` : ''}.`);
      picked = result.kept;
    }
    if (!picked.length) continue;
    picked.sort((a, b) => a.rating - b.rating || a.id.localeCompare(b.id));
    const name = `band-${band}.json`;
    fs.writeFileSync(path.join(outDir, name), JSON.stringify(picked.map(packRow)));
    for (const p of picked) for (const t of p.themes) themeTotals[t] = (themeTotals[t] || 0) + 1;
    bands.push({ min: band, max: band + BAND_WIDTH - 1, file: name, count: picked.length });
    total += picked.length;
  }
  const index = {
    version: 1, generated: new Date().toISOString().slice(0, 10), source: 'database.lichess.org lichess_db_puzzle (CC0)',
    bandWidth: BAND_WIDTH, total, filters: opts, bands, themes: themeTotals,
    ...(verifyUrl ? { verified: { ...verifyStats, engine: 'VILA Stockfish server' } } : {}),
  };
  fs.writeFileSync(path.join(outDir, 'index.json'), JSON.stringify(index));
  fs.writeFileSync(path.join(outDir, 'LICENSE.txt'), 'Puzzle data: Lichess puzzle database, released under Creative Commons CC0 (https://database.lichess.org/#puzzles).\n');
  const bytes = bands.reduce((s, b) => s + fs.statSync(path.join(outDir, b.file)).size, 0);
  console.log(`Xong: ${total.toLocaleString()} câu · ${bands.length} dải rating · ${(bytes / 1048576).toFixed(1)} MB (chưa nén) → ${outDir}`);
  if (!total) { console.error('Không có câu nào đạt yêu cầu.'); process.exit(1); }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main();
