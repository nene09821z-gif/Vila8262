# VILA Chess – drag, premove và Device Tier

Bản nâng cấp áp dụng cho dự án Vanilla JS + Vite 7 + Capacitor 7.4.3 hiện có. Không chuyển sang React/Canvas và không thay đổi chess.js, backend hoặc state quản lý ván.

## Thay đổi chính

- `src/device-tier.js`: phân loại LOW/MEDIUM/HIGH, đọc Android native RAM/CPU/API/Battery Saver; dùng Capacitor Device và browser hints làm fallback; hỗ trợ `deviceTier.setTier('auto'|'low'|'medium'|'high')`.
- `src/haptics.js`: wrapper Capacitor Haptics, chỉ gọi khi quality cho phép; ưu tiên AndroidBridge.vibrate() vì VILA hiện dùng custom Compose WebView thay vì Capacitor BridgeActivity.
- `src/board-interact.js`: pointer capture sớm, tính legal moves ở pointerdown, pointermove được gom bằng RAF và chỉ cập nhật transform/hover; thả quân dựa theo tâm quân; hủy khi mất focus/background/đổi orientation.
- `src/board-drag-fx.js`: offset-preserving ghost, WAAPI pickup/landing/return và capture fade 120ms.
- `src/premove.js`: premove square-based, tối đa 5 nước, cấm thêm khi đến lượt mình, revalidate với position thật và hủy toàn bộ queue nếu nước đầu không còn hợp lệ.
- `src/main.js`: nối lại drag của bàn Play, hit-test theo tâm quân, SVG premove arrows, chip số premove, cancel queue, capture/castling/promotion và mất kết nối.
- `src/sound.js`: dùng Capacitor Haptics thay `navigator.vibrate`, giữ preference âm thanh/rung độc lập.
- `src/perf-governor.js`: khởi tạo Device plugin không chặn first paint, nghe override và tự kiểm tra lại khi app foreground.
- `src/board-motion.css` và bundle `src/vila-professional.css`: touch-action, overscroll, hạn chế will-change vào active piece, tắt filter/shadow nặng ở LOW.
- `vite.config.js`: `base: './'`, build target ES2020.
- `package.json`/`package-lock.json`: thêm `@capacitor/device` và `@capacitor/haptics` phiên bản 7.0.5.

## Các điểm gọi chính

```js
import { deviceTier, setTier, useDeviceTier } from './device-tier.js';
import { hapticLight, hapticMedium, hapticHeavy } from './haptics.js';

const { tier, isLowEnd } = useDeviceTier();
setTier('auto'); // hoặc 'low', 'medium', 'high' từ Settings

if (deviceTier.useShadow) {
  // Chỉ tạo shadow cho active ghost trên MEDIUM/HIGH.
}
```

## Kiểm tra đã chạy

- `node --check` trên các file JavaScript đã sửa: đạt.
- JSON parse cho `package.json`, `package-lock.json`, `capacitor.config.json`: đạt.
- `node scripts/check-sync.mjs`: đạt.
- Bộ test độc lập không cần node_modules: 50/50 đạt (DeviceTier, Capacitor/Android haptics fallback, FPS governor, board drag FX, mobile drag invariants, premove queue guard, project smoke, CSS bundle sync).

## Chưa xác minh

- Chưa chạy Vite production build hoặc Android APK trong môi trường sửa file này vì dependencies chưa được cài (`node_modules` không có và registry install bị timeout).
- `tests/premove.test.js` và test tích hợp `smooth-main-thread` cần `chess.js` trong `node_modules`, do đó chưa được chạy ở đây.
- 60 FPS, RAM, pin, nhiệt độ và cảm giác thực tế vẫn cần đo trên thiết bị Android thật; không thể suy ra từ test Node.

Sau khi tải ZIP:

```bash
npm install
npm run test:static
npm run build
```

Android project hiện tại là Gradle/Compose module `:app` với WebView tùy biến, không phải thư mục Capacitor `android/` sinh bởi `cap add`. Mở thư mục dự án gốc (có `settings.gradle.kts`) bằng Android Studio rồi build module `app`; task Gradle stage `dist/` vào `app/src/main/assets`. Không chạy `npx cap sync android` như một bước bắt buộc cho host hiện tại. Haptic ưu tiên `AndroidBridge.vibrate()` có sẵn trong host này; `@capacitor/haptics` là fallback khi chạy bằng Capacitor Bridge thật.
