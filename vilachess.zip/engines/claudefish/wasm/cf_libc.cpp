// cf_libc.cpp — the few libc / runtime symbols claudefish.cpp needs when linked with -nostdlib for wasm32.
// Compile with -fno-builtin so the compiler never turns these loops back into calls to themselves.
#include <stddef.h>
#include <stdint.h>

extern "C" {

void* memcpy(void* d, const void* s, size_t n) {
    unsigned char* dp = (unsigned char*)d; const unsigned char* sp = (const unsigned char*)s;
    if ((((uintptr_t)dp | (uintptr_t)sp) & 3) == 0) {
        while (n >= 16) {
            ((uint32_t*)dp)[0] = ((const uint32_t*)sp)[0]; ((uint32_t*)dp)[1] = ((const uint32_t*)sp)[1];
            ((uint32_t*)dp)[2] = ((const uint32_t*)sp)[2]; ((uint32_t*)dp)[3] = ((const uint32_t*)sp)[3];
            dp += 16; sp += 16; n -= 16;
        }
        while (n >= 4) { *(uint32_t*)dp = *(const uint32_t*)sp; dp += 4; sp += 4; n -= 4; }
    }
    while (n--) *dp++ = *sp++;
    return d;
}

void* memmove(void* d, const void* s, size_t n) {
    unsigned char* dp = (unsigned char*)d; const unsigned char* sp = (const unsigned char*)s;
    if (dp == sp || n == 0) return d;
    if (dp < sp || dp >= sp + n) return memcpy(d, s, n);
    while (n--) dp[n] = sp[n];
    return d;
}

void* memset(void* d, int c, size_t n) {
    unsigned char* dp = (unsigned char*)d; unsigned char b = (unsigned char)c;
    if (((uintptr_t)dp & 3) == 0) {
        uint32_t w = b * 0x01010101u;
        while (n >= 16) { ((uint32_t*)dp)[0] = w; ((uint32_t*)dp)[1] = w; ((uint32_t*)dp)[2] = w; ((uint32_t*)dp)[3] = w; dp += 16; n -= 16; }
        while (n >= 4) { *(uint32_t*)dp = w; dp += 4; n -= 4; }
    }
    while (n--) *dp++ = b;
    return d;
}

int memcmp(const void* a, const void* b, size_t n) {
    const unsigned char* x = (const unsigned char*)a; const unsigned char* y = (const unsigned char*)b;
    for (; n; n--, x++, y++) if (*x != *y) return *x < *y ? -1 : 1;
    return 0;
}

size_t strlen(const char* s) { size_t n = 0; while (s[n]) n++; return n; }

// ---- allocator: first-fit free list over a bump region that grows with memory.grow --------------------------------
extern unsigned char __heap_base;
struct Hdr { uint32_t size; uint32_t pad0; Hdr* next; uint32_t pad1; };   // 16 bytes
static Hdr* g_free = nullptr;
static unsigned char* g_top = nullptr;
static unsigned char* g_limit = nullptr;

void* malloc(size_t n) {
    n = (n + 15) & ~(size_t)15; if (!n) n = 16;
    for (Hdr** pp = &g_free; *pp; pp = &(*pp)->next) {
        Hdr* h = *pp;
        if (h->size >= n) {
            if (h->size >= n + 32) {   // split
                Hdr* r = (Hdr*)((unsigned char*)(h + 1) + n);
                r->size = (uint32_t)(h->size - n - sizeof(Hdr)); r->next = h->next; h->size = (uint32_t)n; *pp = r;
            } else *pp = h->next;
            return h + 1;
        }
    }
    if (!g_top) {
        g_top = (unsigned char*)(((uintptr_t)&__heap_base + 15) & ~(uintptr_t)15);
        g_limit = (unsigned char*)((uintptr_t)__builtin_wasm_memory_size(0) * 65536u);
    }
    size_t need = n + sizeof(Hdr);
    if (g_top + need > g_limit) {
        size_t missing = (size_t)(g_top + need - g_limit);
        size_t pages = (missing + 65535) / 65536; if (pages < 16) pages = 16;   // grow in >= 1 MB steps
        if (__builtin_wasm_memory_grow(0, pages) == (size_t)-1) {
            pages = (missing + 65535) / 65536;
            if (__builtin_wasm_memory_grow(0, pages) == (size_t)-1) return nullptr;
        }
        g_limit = (unsigned char*)((uintptr_t)__builtin_wasm_memory_size(0) * 65536u);
    }
    Hdr* h = (Hdr*)g_top; g_top += need; h->size = (uint32_t)n; h->next = nullptr;
    return h + 1;
}

void free(void* p) {
    if (!p) return;
    Hdr* h = (Hdr*)p - 1;
    h->next = g_free; g_free = h;
}

// ---- natural logarithm (only used to build the LMR table) --------------------------------------------------------
double log(double x) {
    if (!(x > 0)) return x == 0 ? -1.0 / 0.0 : 0.0 / 0.0;
    union { double d; uint64_t u; } v; v.d = x;
    int e = (int)((v.u >> 52) & 0x7ff) - 1023;
    v.u = (v.u & 0x000fffffffffffffULL) | 0x3ff0000000000000ULL;
    double m = v.d;
    if (m > 1.4142135623730951) { m *= 0.5; e += 1; }
    double f = (m - 1.0) / (m + 1.0), f2 = f * f;
    double s = f * (2.0 + f2 * (2.0 / 3 + f2 * (2.0 / 5 + f2 * (2.0 / 7 + f2 * (2.0 / 9 + f2 * (2.0 / 11 + f2 * (2.0 / 13 + f2 * (2.0 / 15 + f2 * (2.0 / 17 + f2 * (2.0 / 19))))))))));
    return s + e * 0.6931471805599453;
}

// ---- C++ runtime stubs ----------------------------------------------------------------------------------------
void* __dso_handle = nullptr;
int __cxa_atexit(void (*)(void*), void*, void*) { return 0; }
void abort(void) { __builtin_trap(); }
void __cxa_pure_virtual(void) { __builtin_trap(); }

}  // extern "C"

void* operator new(size_t n) { return malloc(n); }
void* operator new[](size_t n) { return malloc(n); }
void operator delete(void* p) noexcept { free(p); }
void operator delete[](void* p) noexcept { free(p); }
void operator delete(void* p, size_t) noexcept { free(p); }
void operator delete[](void* p, size_t) noexcept { free(p); }
