// cf_mini_std.h — just enough of the C++ standard library for claudefish.cpp when it is built
// freestanding for WebAssembly (-DCF_WASM, clang --target=wasm32, no libc / libc++ / emscripten).
//
// Only what the engine core actually uses is provided: min/max/swap/abs, string, istringstream (FEN parsing),
// vector, atomic (single threaded), chrono::steady_clock (backed by the host's clock_time_get) and a few <cctype>
// helpers.  stdout output (printf) is compiled away: the browser worker talks to the engine through cf_* exports.
#pragma once
#include <stddef.h>
#include <stdint.h>

// Placement new for the containers below (must be visible before the templates).
inline void* operator new(size_t, void* p) noexcept { return p; }

extern "C" {
void* memcpy(void*, const void*, size_t);
void* memset(void*, int, size_t);
void* memmove(void*, const void*, size_t);
int memcmp(const void*, const void*, size_t);
size_t strlen(const char*);
void* malloc(size_t);
void free(void*);
double log(double);
// Host clock (WASI): id 1 = monotonic. The worker implements it with performance.now().
__attribute__((import_module("wasi_snapshot_preview1"), import_name("clock_time_get")))
int cf_host_clock_time_get(int id, long long precision, unsigned long long* out);
}

// stdout is silent in the browser build.
#define printf(...) 0
#define fflush(x) 0
#define stdout 0

static inline int isdigit(int c) { return c >= '0' && c <= '9'; }
static inline int isupper(int c) { return c >= 'A' && c <= 'Z'; }
static inline int islower(int c) { return c >= 'a' && c <= 'z'; }
static inline int toupper(int c) { return islower(c) ? c - 32 : c; }
static inline int tolower(int c) { return isupper(c) ? c + 32 : c; }
static inline int atoi(const char* s) {
    int sign = 1, v = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { sign = -1; s++; } else if (*s == '+') s++;
    while (isdigit(*s)) v = v * 10 + (*s++ - '0');
    return sign * v;
}

namespace std {

template <class T> constexpr const T& min(const T& a, const T& b) { return b < a ? b : a; }
template <class T> constexpr const T& max(const T& a, const T& b) { return a < b ? b : a; }
template <class T> inline void swap(T& a, T& b) { T t = a; a = b; b = t; }
inline int abs(int x) { return x < 0 ? -x : x; }
inline long abs(long x) { return x < 0 ? -x : x; }
inline long long abs(long long x) { return x < 0 ? -x : x; }

enum memory_order { memory_order_relaxed, memory_order_acquire, memory_order_release, memory_order_acq_rel, memory_order_seq_cst };

// One thread only: a plain value is a correct "atomic".
template <class T> struct atomic {
    T v;
    constexpr atomic() : v() {}
    constexpr atomic(T x) : v(x) {}
    T load(memory_order = memory_order_seq_cst) const { return v; }
    void store(T x, memory_order = memory_order_seq_cst) { v = x; }
    T operator=(T x) { v = x; return x; }
    operator T() const { return v; }
};

// ---------------------------------------------------------------- string
class string {
    char* p_ = nullptr;
    size_t n_ = 0, cap_ = 0;
    void reserve(size_t want) {
        if (want + 1 <= cap_) return;
        size_t c = cap_ ? cap_ * 2 : 16;
        while (c < want + 1) c *= 2;
        char* q = (char*)malloc(c);
        if (p_) { memcpy(q, p_, n_); free(p_); }
        p_ = q; cap_ = c; p_[n_] = 0;
    }
public:
    string() {}
    string(const char* s) { size_t l = strlen(s); reserve(l); memcpy(p_, s, l); n_ = l; p_[n_] = 0; }
    string(const string& o) { reserve(o.n_); if (o.n_) memcpy(p_, o.p_, o.n_); n_ = o.n_; if (p_) p_[n_] = 0; }
    string(string&& o) : p_(o.p_), n_(o.n_), cap_(o.cap_) { o.p_ = nullptr; o.n_ = o.cap_ = 0; }
    ~string() { free(p_); }
    string& operator=(const string& o) { if (this != &o) { n_ = 0; reserve(o.n_); if (o.n_) memcpy(p_, o.p_, o.n_); n_ = o.n_; if (p_) p_[n_] = 0; } return *this; }
    string& operator=(string&& o) { if (this != &o) { free(p_); p_ = o.p_; n_ = o.n_; cap_ = o.cap_; o.p_ = nullptr; o.n_ = o.cap_ = 0; } return *this; }
    string& operator=(const char* s) { string t(s); return *this = static_cast<string&&>(t); }
    size_t size() const { return n_; }
    bool empty() const { return n_ == 0; }
    const char* c_str() const { return p_ ? p_ : ""; }
    char& operator[](size_t i) { return p_[i]; }
    const char& operator[](size_t i) const { return p_[i]; }
    const char* begin() const { return c_str(); }
    const char* end() const { return c_str() + n_; }
    string& operator+=(char c) { reserve(n_ + 1); p_[n_++] = c; p_[n_] = 0; return *this; }
    string& operator+=(const char* s) { size_t l = strlen(s); reserve(n_ + l); memcpy(p_ + n_, s, l); n_ += l; p_[n_] = 0; return *this; }
    string& operator+=(const string& o) { return *this += o.c_str(); }
    friend string operator+(string a, const string& b) { a += b; return a; }
    friend string operator+(string a, const char* b) { a += b; return a; }
    friend string operator+(string a, char b) { a += b; return a; }
    friend string operator+(char a, const string& b) { string r; r += a; r += b; return r; }
    friend bool operator==(const string& a, const string& b) { return a.n_ == b.n_ && (a.n_ == 0 || memcmp(a.p_, b.p_, a.n_) == 0); }
    friend bool operator==(const string& a, const char* b) { return a.n_ == strlen(b) && (a.n_ == 0 || memcmp(a.p_, b, a.n_) == 0); }
    friend bool operator!=(const string& a, const string& b) { return !(a == b); }
    friend bool operator!=(const string& a, const char* b) { return !(a == b); }
};

inline string to_string(int v) {
    char buf[16]; int i = 16; bool neg = v < 0; unsigned u = neg ? 0u - (unsigned)v : (unsigned)v;
    do { buf[--i] = char('0' + u % 10); u /= 10; } while (u);
    if (neg) buf[--i] = '-';
    string s; for (; i < 16; i++) s += buf[i];
    return s;
}

// Reads whitespace separated tokens; the fail state is sticky like the real thing.
class istringstream {
    string s_; size_t i_ = 0; bool ok_ = true;
public:
    explicit istringstream(const string& s) : s_(s) {}
    istringstream& operator>>(string& out) {
        while (i_ < s_.size() && (s_[i_] == ' ' || s_[i_] == '\t' || s_[i_] == '\n' || s_[i_] == '\r')) i_++;
        if (!ok_ || i_ >= s_.size()) { ok_ = false; return *this; }
        string t; while (i_ < s_.size() && s_[i_] != ' ' && s_[i_] != '\t' && s_[i_] != '\n' && s_[i_] != '\r') t += s_[i_++];
        out = static_cast<string&&>(t); return *this;
    }
    istringstream& operator>>(int& out) {
        string t; *this >> t;
        if (!ok_) return *this;
        int sign = 1; size_t k = 0; if (t[0] == '-') { sign = -1; k = 1; }
        if (k >= t.size() || !isdigit(t[k])) { ok_ = false; return *this; }
        int v = 0; for (; k < t.size() && isdigit(t[k]); k++) v = v * 10 + (t[k] - '0');
        out = sign * v; return *this;
    }
    explicit operator bool() const { return ok_; }
};

// ---------------------------------------------------------------- vector
template <class T> class vector {
    T* p_ = nullptr; size_t n_ = 0, cap_ = 0;
    void grow(size_t want) {
        if (want <= cap_) return;
        size_t c = cap_ ? cap_ * 2 : 8; while (c < want) c *= 2;
        T* q = (T*)malloc(c * sizeof(T));
        for (size_t i = 0; i < n_; i++) new (&q[i]) T(p_[i]);
        for (size_t i = 0; i < n_; i++) p_[i].~T();
        free(p_); p_ = q; cap_ = c;
    }
public:
    vector() {}
    explicit vector(size_t n) { grow(n); for (size_t i = 0; i < n; i++) new (&p_[i]) T(); n_ = n; }
    vector(size_t n, const T& v) { grow(n); for (size_t i = 0; i < n; i++) new (&p_[i]) T(v); n_ = n; }
    vector(const vector&) = delete;
    vector& operator=(const vector&) = delete;
    ~vector() { for (size_t i = 0; i < n_; i++) p_[i].~T(); free(p_); }
    size_t size() const { return n_; }
    bool empty() const { return n_ == 0; }
    T* data() { return p_; }
    T& operator[](size_t i) { return p_[i]; }
    const T& operator[](size_t i) const { return p_[i]; }
    T* begin() { return p_; }
    T* end() { return p_ + n_; }
    const T* begin() const { return p_; }
    const T* end() const { return p_ + n_; }
    void push_back(const T& v) { grow(n_ + 1); new (&p_[n_]) T(v); n_++; }
};

// ---------------------------------------------------------------- chrono
namespace chrono {
struct milliseconds { long long ms; long long count() const { return ms; } };
struct duration { long long ns; };
struct time_point {
    long long ns;
    duration operator-(const time_point& o) const { return duration{ns - o.ns}; }
};
struct steady_clock {
    typedef ::std::chrono::time_point time_point;
    static time_point now() {
        unsigned long long t = 0;
        cf_host_clock_time_get(1, 1000, &t);
        return time_point{(long long)t};
    }
};
template <class To> To duration_cast(const duration& d) { return To{d.ns / 1000000}; }
}  // namespace chrono

}  // namespace std

