# Premium 2.5D board upgrade

- Preserved the existing main board renderer and its 64 square buttons; no canvas or alternate board DOM was introduced.
- Added a final `premium-board.css` layer with a square 8×8 grid, premium frame depth, cream/green default squares, legal-move dots, capture rings, drag hover, check gradient, 92% artwork sizing and calibrated 1.15 scale.
- Reused the existing board palette system: `classic` (green), `walnut` (wood) and `ocean` (blue). Other saved board themes remain supported.
- Integrated all 42 folders (500 SVG files) from `piece.zip`; `mono` maps to its six shared monochrome file names. The app selector now contains 59 styles: 17 existing generated sets plus all 42 supplied SVG sets.
- Removed the Illustrator-only `foreignObject` stubs from `minimal-warmth` SVGs; no script, event-handler, embedded-image or external-URL content remains in bundled piece SVGs.
- Rasterized all 12 pieces per SVG style to measure their alpha bounds, then added per-style X/Y/scale calibration profiles to correct uneven SVG padding and vertical balance. `flat`/generated sets retain the default 1.15 scale and -2% vertical offset.
- Piece theme changes wait for the selected set's 12 image decodes before rerendering; this retains the old set while new assets warm. The existing PNG fallback remains. Drag ghosts receive a silhouette-shaped SVG drop-shadow rather than a square wrapper shadow.
- The service worker caches assets on first request; selecting a set preloads its pieces so that set becomes available offline after it has been opened once.
- Additional sets in the supplied archive do not include author/license manifests. Confirm their redistribution terms before publishing a public release.

## Validation

Run `npm test` and `npm run build` from the project root. `tests/premium-board-assets.test.js` verifies the 42 × 6/12 file inventory, SVG safety, registration, piece preload behavior and premium CSS. Actual Android device rendering/FPS was not measured in this environment.
