import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: { target: 'es2020' },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8787', changeOrigin: true }
    }
  }
});
