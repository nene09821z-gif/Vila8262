import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { layers } from '../scripts/build-professional-css.mjs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');

test('mobile ChessPlus shell is bundled right before the scroll-smoothness layer (the last layer)', () => {
  assert.equal(layers.at(-1), 'scroll-smooth.css');
  assert.equal(layers.at(-2), 'mobile-chessplus.css');
  assert.ok(read('src/vila-professional.css').includes('/* Professional stylesheet layer: mobile-chessplus.css */'));
});

test('shared header carries the ChessPlus brand and an Elo chip on every screen', () => {
  const html = read('index.html');
  assert.match(html, /class="cp-top-brand"/);
  assert.match(html, /id="accountShortcutElo"/);
  assert.match(html, /id="cpTopTitle"/);
  assert.match(read('src/main.js'), /function syncTopbarProfile\(/);
});

test('hamburger sheet and cards use the home navy theme on all pages', () => {
  const css = read('src/mobile-chessplus.css');
  assert.match(css, /#mainMenu\.tabs\.menu-open\s*\{/);
  assert.match(css, /Tất cả chức năng/);
  assert.match(css, /\.panel/);
  assert.match(css, /#vilaAccountGate/);
});

test('home hero styles no longer hijack the puzzle page .cp-hero', () => {
  const css = read('src/home-chessplus.css');
  assert.doesNotMatch(css, /\n\.cp-hero \{/);
  assert.match(css, /\.cp-home \.cp-hero \{/);
});

test('scrolling stays cheap: no fixed background attachment and no blur on sticky/fixed bars', () => {
  const bundle = read('src/vila-professional.css').replace(/\/\*[\s\S]*?\*\//g, '');
  assert.ok(!/background-attachment\s*:\s*fixed/.test(bundle), 'background-attachment: fixed repaints every scroll frame');
  assert.match(read('src/mobile-chessplus.css'), /html::before\s*\{[^}]*position:\s*fixed/);
  const homeNav = read('src/home-chessplus.css').match(/html body #bottomNav \{[^}]*\}/)?.[0] || '';
  assert.ok(homeNav && !/backdrop-filter/.test(homeNav), 'bottom nav must not blur the scrolling page');
  assert.match(read('src/scroll-smooth.css'), /\.topbar[\s\S]*backdrop-filter:\s*none\s*!important/);
});
