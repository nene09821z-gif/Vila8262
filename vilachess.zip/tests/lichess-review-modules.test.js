import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateWinProbability, classifyMove, calculateAccuracy } from '../src/services/chess-math.js';
import { configureLichessApi, clearLichessEvalCache, fetchEval } from '../src/services/lichess-api.js';

const okResponse = payload => ({
  status: 200,
  ok: true,
  json: async () => payload
});

test('win probability follows Lichess logistic curve and mate sign', () => {
  assert.equal(calculateWinProbability(0), 50);
  assert.ok(calculateWinProbability(500) > 85);
  assert.ok(calculateWinProbability(-500) < 15);
  assert.equal(calculateWinProbability(0, 3), 100);
  assert.equal(calculateWinProbability(0, -2), 0);
});

test('move classification only calls a confirmed best-move sacrifice brilliant', () => {
  assert.equal(classifyMove(70, 70, true).key, 'good');
  assert.equal(classifyMove(70, 70, true, { isSacrifice: true }).key, 'brilliant');
  assert.equal(classifyMove(70, 45, false).key, 'blunder');
  assert.equal(classifyMove(null, 50, false).key, 'unrated');
});

test('ACPL proxy is bounded and declines as ACPL rises', () => {
  assert.equal(calculateAccuracy(0), 100);
  assert.ok(calculateAccuracy(50) < 100);
  assert.ok(calculateAccuracy(100) < calculateAccuracy(50));
  assert.equal(calculateAccuracy(-1), null);
});

test('Cloud Eval parser returns White-perspective cp and the first UCI move', async () => {
  clearLichessEvalCache();
  configureLichessApi({ minIntervalMs: 0, retry429DelayMs: 0, timeoutMs: 1000, fetchImpl: async () => okResponse({
    depth: 37, knodes: 1234, pvs: [{ cp: 24, moves: 'e7e5 g1f3 b8c6' }]
  }) });
  const result = await fetchEval('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  assert.equal(result.status, 'OK');
  assert.equal(result.cp, 24);
  assert.equal(result.mate, null);
  assert.equal(result.bestMove, 'e7e5');
  assert.equal(result.depth, 37);
  assert.deepEqual(result.pv.slice(0, 2), ['e7e5', 'g1f3']);
});

test('Cloud Eval maps HTTP 404 to NOT_FOUND', async () => {
  clearLichessEvalCache();
  configureLichessApi({ minIntervalMs: 0, fetchImpl: async () => ({ status: 404, ok: false }) });
  const result = await fetchEval('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1');
  assert.deepEqual(result, { status: 'NOT_FOUND' });
});

test('Cloud Eval retries one 429 and returns RATE_LIMIT if the retry is also limited', async () => {
  clearLichessEvalCache();
  let calls = 0;
  configureLichessApi({ minIntervalMs: 0, retry429DelayMs: 0, retry429Once: true, fetchImpl: async () => {
    calls += 1;
    return { status: 429, ok: false };
  } });
  const result = await fetchEval('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 1 1');
  assert.equal(calls, 2);
  assert.deepEqual(result, { status: 'RATE_LIMIT' });
});

test('Cloud Eval queue serializes callers and spaces outgoing requests', async () => {
  clearLichessEvalCache();
  const started = [];
  let active = 0;
  let maxActive = 0;
  configureLichessApi({ minIntervalMs: 15, timeoutMs: 1000, fetchImpl: async () => {
    started.push(Date.now());
    active += 1;
    maxActive = Math.max(maxActive, active);
    await new Promise(resolve => setTimeout(resolve, 5));
    active -= 1;
    return okResponse({ depth: 20, pvs: [{ cp: 0, moves: 'e2e4' }] });
  } });
  const fens = [
    'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 2 1',
    'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 2 1'
  ];
  const results = await Promise.all(fens.map(fen => fetchEval(fen)));
  assert.equal(results.length, 2);
  assert.equal(maxActive, 1);
  assert.ok(started[1] - started[0] >= 12);
});

test('Cloud Eval aborts a stalled fetch at the configured timeout', async () => {
  clearLichessEvalCache();
  configureLichessApi({ minIntervalMs: 0, timeoutMs: 20, fetchImpl: async (_url, { signal }) => new Promise((_resolve, reject) => {
    signal.addEventListener('abort', () => {
      const error = new Error('aborted');
      error.name = 'AbortError';
      reject(error);
    }, { once: true });
  }) });
  const result = await fetchEval('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 3 1');
  assert.deepEqual(result, { status: 'TIMEOUT' });
});
