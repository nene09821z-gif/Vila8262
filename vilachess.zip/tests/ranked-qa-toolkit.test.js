import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = path => fs.readFileSync(new URL(path, import.meta.url), 'utf8');

test('ranked QA runner targets the real REST contract and verifies two-client FEN parity', () => {
  const script = read('../scripts/qa-ranked-matchmaking.mjs');
  assert.match(script, /\/ranked\/queue/);
  assert.match(script, /\/ranked\/status/);
  assert.match(script, /\/ranked\/matches\/\$\{encodeURIComponent\(activeMatchId\)\}\/move/);
  assert.match(script, /expectedPly/);
  assert.match(script, /game\.fen\(\) === sent\.data\.match\.fen/);
  assert.match(script, /TARGET_PLIES/);
  assert.match(script, /process\.memoryUsage\(\)/);
});

test('Capacitor resume example reconciles server status and never abandons on background', () => {
  const source = read('../src/ranked-reconnect.example.js');
  assert.match(source, /App\.addListener\('appStateChange'/);
  assert.match(source, /visibilitychange/);
  assert.match(source, /addEventListener\('online'/);
  assert.match(source, /syncRankedFromServer/);
  assert.match(source, /do not send resign\/abandon merely because the app is backgrounded/);
  assert.doesNotMatch(source, /\/ranked\/matches\/.*\/abandon/);
});

test('QA report includes 15 manual cases and the verified transport/rate-limit findings', () => {
  const report = read('../docs/QA_RANKED_ONLINE.md');
  assert.match(report, /Cloudflare Worker \+ Durable Object/);
  assert.match(report, /Không thấy Socket\.IO/);
  assert.match(report, /120 request\/phút/);
  assert.match(report, /pagehide/);
  for (let n = 1; n <= 15; n += 1) assert.match(report, new RegExp(`\\| ${String(n).padStart(2, '0')} \\|`));
});
