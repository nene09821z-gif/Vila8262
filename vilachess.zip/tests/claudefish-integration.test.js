import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { LegacyUciEngine } from '../src/legacy-uci-engine.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const source = path.join(root, 'engines', 'claudefish', 'claudefish.cpp');
const binary = path.join(process.env.TMPDIR || '/tmp', 'claudefish-single-test');
const hasGpp = spawnSync('g++', ['--version']).status === 0;
const wasmPath = path.join(root, 'public', 'claudefish', 'cf-engine.wasm');

test('Arena registers ClaudeFish with its own worker, fallback and stop handling', () => {
  const main = read('src/main.js');
  assert.match(main, /id: 'claudefish'.*ClaudeFish/);
  assert.match(main, /type: 'claudefish'/);
  assert.match(main, /claudefish\/claudefish-worker\.js/);
  assert.match(main, /label: 'ClaudeFish'/);
  assert.match(main, /claudeFishEngine\?\.stop\(\)/);
  assert.match(main, /getClaudeFishEngine\(\)\.newGame\(\)/);
  assert.match(read('src/bot-personas.js'), /claudefish:\s*\{ openingNames/);
});

test('ClaudeFish never falls back to Stockfish (arena and normal games)', () => {
  const main = read('src/main.js');
  const start = main.indexOf("if (player.type === 'claudefish') {");
  const end = main.indexOf("if (player.type === 'stockfish-legacy') {", start);
  assert.ok(start > 0 && end > start, 'ClaudeFish arena branch not found');
  const branch = main.slice(start, end);
  assert.doesNotMatch(branch, /requestStockfishUci|chooseStockfishBackedOfflineUci/);
  assert.match(branch, /chooseAlternateMoveAsync/);
  const fn = main.slice(main.indexOf('async function chooseClaudeFishPlayUci'), main.indexOf('async function requestClaudeFishUci'));
  assert.ok(fn.length > 100, 'chooseClaudeFishPlayUci not found');
  assert.doesNotMatch(fn, /requestStockfishUci|chooseStockfishBackedOfflineUci/);
  // normal games: ClaudeFish is an "AI đa phong cách" profile and skips the Stockfish-assisted path
  assert.match(main, /const independent = profile === 'claudefish'/);
  assert.match(main, /\(neural \|\| independent\) \? null : await chooseStockfishBackedOfflineUci/);
  assert.match(read('src/alternate-engine-core.js'), /id: 'claudefish'/);
  assert.match(main, /OFFLINE_ENGINE_CATALOG\.filter\(item => item\.id !== 'claudefish'\)/);
});

test('Worker loads the prebuilt WASM module and the service worker precaches both files', async () => {
  const worker = read('public/claudefish/claudefish-worker.js');
  assert.match(worker, /cf-engine\.wasm/);
  assert.match(worker, /cf_best/);
  const code = worker.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');   // comments may mention Stockfish; code must not
  assert.doesNotMatch(code, /importScripts|stockfish/i);
  const bytes = fs.readFileSync(wasmPath);
  assert.equal(bytes.subarray(0, 4).toString('hex'), '0061736d', 'cf-engine.wasm has an invalid WebAssembly header');
  assert.ok(bytes.length > 20_000, 'cf-engine.wasm is unexpectedly small');
  const exported = new Set(WebAssembly.Module.exports(new WebAssembly.Module(bytes)).map(item => item.name));
  for (const name of ['memory', 'cf_init', 'cf_newgame', 'cf_io', 'cf_usenn', 'cf_best']) assert.ok(exported.has(name), `wasm export ${name} missing`);
  const sw = read('public/sw.js');
  assert.match(sw, /claudefish\/claudefish-worker\.js/);
  assert.match(sw, /claudefish\/cf-engine\.wasm/);
  // The freestanding clang build (no emscripten / WASI SDK) writes exactly the file the worker loads.
  const script = read('scripts/build-claudefish-wasm.sh');
  assert.match(script, /public\/claudefish\/cf-engine\.wasm/);
  assert.match(script, /engines\/claudefish\/claudefish\.cpp/);
  assert.match(script, /-DCF_WASM/);
  const src = fs.readFileSync(source, 'utf8');
  assert.match(src, /ClaudeFish 3\.0/);
  assert.match(src, /#ifdef CF_WASM/);
  assert.match(src, /wasm\/cf_api\.inc/);
  for (const name of ['cf_init', 'cf_newgame', 'cf_io', 'cf_iosize', 'cf_best', 'cf_depth', 'cf_nodes', 'cf_usenn', 'cf_netbuf', 'cf_loadnet', 'cf_perft']) {
    assert.ok(exported.has(name), `wasm export ${name} missing`);
  }
  // Only the clock is imported: no WASI file/process surface and no emscripten glue.
  const imported = WebAssembly.Module.imports(new WebAssembly.Module(bytes)).map(item => `${item.module}.${item.name}`);
  assert.deepEqual(imported, ['wasi_snapshot_preview1.clock_time_get']);
});

/** Runs the real worker file in a vm sandbox (Node has no classic Worker): postMessage <-> onmessage like a browser. */
function sandboxWorkerFactory({ wasmStatus = 200 } = {}) {
  const code = read('public/claudefish/claudefish-worker.js');
  return () => {
    const w = { onmessage: null, onerror: null, terminate() {}, postMessage(line) { sandbox.onmessage({ data: line }); } };
    const sandbox = {
      postMessage: line => queueMicrotask(() => w.onmessage?.({ data: line })),
      fetch: async () => wasmStatus !== 200 ? { ok: false, status: wasmStatus } : {
        ok: true, status: 200,
        arrayBuffer: async () => { const b = fs.readFileSync(wasmPath); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }
      },
      // the worker rethrows load errors from a timer so Worker.onerror fires; emulate that here
      setTimeout: fn => { try { fn(); } catch (error) { queueMicrotask(() => w.onerror?.({ message: error.message })); } },
      WebAssembly, TextEncoder, TextDecoder, URL, performance, Date, Math, BigInt, DataView, Uint8Array, Promise, Error, Number, String, console
    };
    sandbox.self = sandbox;
    sandbox.location = { href: 'http://localhost/claudefish/claudefish-worker.js' };
    vm.createContext(sandbox);
    vm.runInContext(code, sandbox);
    return w;
  };
}

test('ClaudeFish WASM worker plays strong, legal moves through LegacyUciEngine (no Stockfish involved)', async () => {
  const engine = new LegacyUciEngine(sandboxWorkerFactory(), { label: 'ClaudeFish', initTimeoutMs: 15_000 });
  try {
    engine.newGame();
    const start = await engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.match(start.uci, /^[a-h][1-8][a-h][1-8][qrbn]?$/);
    assert.ok(['e2e4', 'd2d4', 'g1f3', 'b1c3', 'c2c4', 'e2e3', 'd2d3', 'g2g3'].includes(start.uci), `odd opening move ${start.uci}`);
    const mate = await engine.bestMove('6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(mate.uci, 'a1a8');                       // back-rank mate in one
    const win = await engine.bestMove('rnb1kbnr/pppp1ppp/8/4p3/4P2q/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(win.uci, 'f3h4');                        // takes the hanging queen
    const promo = await engine.bestMove('8/P6k/8/8/8/8/8/K7 w - - 0 1', { moveTimeMs: 300, depth: 20 });
    assert.equal(promo.uci, 'a7a8q');                     // promotes to a queen
    const black = await engine.bestMove('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1', { moveTimeMs: 300, depth: 20 });
    assert.match(black.uci, /^[a-h][1-8][a-h][1-8]/);
    await assert.rejects(engine.bestMove('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1', { moveTimeMs: 200, depth: 6 }), /không trả về nước đi/);  // stalemate
  } finally { engine.dispose(); }
});

test('A missing cf-engine.wasm fails fast with a clear error so the arena can use its JS fallback', async () => {
  const engine = new LegacyUciEngine(sandboxWorkerFactory({ wasmStatus: 404 }), { label: 'ClaudeFish', initTimeoutMs: 15_000 });
  try {
    await assert.rejects(engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 200, depth: 6 }), /cf-engine\.wasm/);
  } finally { engine.dispose(); }
});

test('LegacyUciEngine labels errors with the engine name', async () => {
  const engine = new LegacyUciEngine(() => { throw new Error('boom'); }, { label: 'ClaudeFish' });
  await assert.rejects(engine.bestMove('bad fen'), /FEN không hợp lệ cho ClaudeFish/);
  engine.dispose();
  await assert.rejects(engine.ensureReady(), /ClaudeFish session was disposed/);
});

/** Drives the worker directly (raw UCI lines) and collects what it posts back. */
function rawWorker() {
  const code = read('public/claudefish/claudefish-worker.js');
  const out = [];
  const sandbox = {
    postMessage: line => out.push(line),
    fetch: async url => String(url).endsWith('.wasm')
      ? { ok: true, status: 200, arrayBuffer: async () => { const b = fs.readFileSync(wasmPath); return b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); } }
      : { ok: false, status: 404 },
    setTimeout: fn => { fn(); },
    WebAssembly, TextEncoder, TextDecoder, URL, performance, Date, Math, BigInt, DataView, Uint8Array, Promise, Error, Number, String, console
  };
  sandbox.self = sandbox;
  sandbox.location = { href: 'http://localhost/claudefish/claudefish-worker.js' };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox);
  const send = async line => { sandbox.onmessage({ data: line }); await new Promise(resolve => setTimeout(resolve, 0)); };
  const waitFor = async (re, ms = 8000) => {
    const end = Date.now() + ms;
    while (Date.now() < end) { const hit = out.find(l => re.test(l)); if (hit) return hit; await new Promise(resolve => setTimeout(resolve, 10)); }
    throw new Error(`timeout waiting for ${re}; got ${JSON.stringify(out.slice(-4))}`);
  };
  return { out, send, waitFor };
}

test('ClaudeFish 3.0 worker reports real depth, nodes and mate scores', async () => {
  const w = rawWorker();
  await w.send('uci'); await w.waitFor(/^uciok/);
  assert.ok(w.out.some(l => /id name ClaudeFish 3\.0/.test(l)));
  await w.send('isready'); await w.waitFor(/^readyok/);
  await w.send('position fen 6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1');
  await w.send('go movetime 300 depth 20');
  const mate = await w.waitFor(/^info depth \d+ score mate/);
  assert.match(mate, /score mate 1 /);
  assert.match(mate, /pv a1a8$/);
  await w.waitFor(/^bestmove a1a8$/);
  w.out.length = 0;
  await w.send('position startpos');
  await w.send('go depth 8');
  const info = await w.waitFor(/^info depth \d+ score cp/);
  const depth = Number(info.match(/depth (\d+)/)[1]);
  assert.ok(depth >= 8, `expected depth >= 8, got ${depth}`);
  assert.match(info, /nodes [1-9]\d* nps \d+ time \d+ pv [a-h][1-8][a-h][1-8]/);
  await w.waitFor(/^bestmove [a-h][1-8][a-h][1-8]/);
});

test('ClaudeFish 3.0 worker understands "position ... moves ..." and rejects an illegal move list', async () => {
  const w = rawWorker();
  await w.send('uci'); await w.waitFor(/^uciok/);
  // Black to move after 1.e4 e5 2.Nf3: any legal black reply is fine, but it must be a black move (rank 7/8 start).
  await w.send('position startpos moves e2e4 e7e5 g1f3');
  await w.send('go depth 6');
  const best = (await w.waitFor(/^bestmove /)).split(' ')[1];
  assert.match(best, /^[a-h][1-8][a-h][1-8][qrbn]?$/);
  assert.notEqual(best, '0000');
  w.out.length = 0;
  await w.send('position startpos moves e2e5');
  await w.send('go depth 4');
  await w.waitFor(/danh sách nước đi không hợp lệ/);
  await w.waitFor(/^bestmove 0000$/);
});

test('ClaudeFish 3.0 wasm is node-for-node identical to a native build of the same source', { skip: !hasGpp && 'g++ not available' }, async () => {
  const bin = path.join(process.env.TMPDIR || '/tmp', 'claudefish-native-cmp');
  const build = spawnSync('g++', ['-O2', '-std=c++17', '-pthread', '-o', bin, source], { encoding: 'utf8' });
  assert.equal(build.status, 0, build.stderr);
  const fens = [
    'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
    'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1',
    '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1'
  ];
  const native = fen => new Promise(resolve => {
    const child = spawn(bin);
    let out = '';
    child.stdout.on('data', chunk => { out += chunk; if (/bestmove/.test(out)) child.stdin.write('quit\n'); });   // quit early would abort the search
    child.on('close', () => {
      const lines = out.split('\n');
      const info = lines.filter(l => l.startsWith('info depth')).pop();
      resolve({ nodes: Number(info.match(/nodes (\d+)/)[1]), best: lines.find(l => l.startsWith('bestmove')).split(' ')[1] });
    });
    child.stdin.write(`setoption name Hash value ${16}\nucinewgame\nposition fen ${fen}\ngo depth 9\n`);
  });
  const w = rawWorker();
  await w.send('uci'); await w.waitFor(/^uciok/);
  for (const fen of fens) {
    const expected = await native(fen);
    w.out.length = 0;
    await w.send('ucinewgame'); await w.send(`position fen ${fen}`); await w.send('go depth 9');
    const info = await w.waitFor(/^info depth/);
    const best = (await w.waitFor(/^bestmove /)).split(' ')[1];
    assert.equal(Number(info.match(/nodes (\d+)/)[1]), expected.nodes, `node count differs for ${fen}`);
    assert.equal(best, expected.best, `best move differs for ${fen}`);
  }
});

test('Native ClaudeFish 3.0 passes perft (move generator is exact)', { skip: !hasGpp && 'g++ not available' }, async () => {
  const bin = path.join(process.env.TMPDIR || '/tmp', 'claudefish-native-perft');
  const build = spawnSync('g++', ['-O2', '-std=c++17', '-pthread', '-o', bin, source], { encoding: 'utf8' });
  assert.equal(build.status, 0, build.stderr);
  const run = spawnSync(bin, { input: 'position startpos\nperft 5\nquit\n', encoding: 'utf8' });
  assert.match(run.stdout, /Nodes: 4865609/);
  const kiwi = spawnSync(bin, { input: 'position fen r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1\nperft 4\nquit\n', encoding: 'utf8' });
  assert.match(kiwi.stdout, /Nodes: 4085603/);
});

test('ClaudeFish single-thread build plays legal moves through LegacyUciEngine', { skip: !hasGpp && 'g++ not available' }, async () => {
  const build = spawnSync('g++', ['-O2', '-std=c++17', '-pthread', '-o', binary, source], { encoding: 'utf8' });
  assert.equal(build.status, 0, build.stderr);
  // Worker-shaped shim: postMessage(line) -> child stdin, stdout lines -> onmessage({data}).
  const factory = () => {
    const child = spawn(binary);
    const w = { onmessage: null, onerror: null, postMessage: line => child.stdin.write(`${line}\n`), terminate: () => child.kill() };
    let buf = '';
    child.stdout.on('data', chunk => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); w.onmessage?.({ data: line }); }
    });
    return w;
  };
  const engine = new LegacyUciEngine(factory, { label: 'ClaudeFish', initTimeoutMs: 10_000 });
  try {
    engine.newGame();
    const start = await engine.bestMove('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', { moveTimeMs: 300, depth: 8 });
    assert.match(start.uci, /^[a-h][1-8][a-h][1-8]$/);
    assert.ok(start.depth >= 1);
    // Mate in one for white: Qxf7#
    const mate = await engine.bestMove('r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1', { moveTimeMs: 300, depth: 6 });
    assert.equal(mate.uci, 'f3f7');
  } finally { engine.dispose(); }
});
