import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const read = file => fs.readFileSync(new URL(`../${file}`, import.meta.url), 'utf8');
const main = read('src/main.js');
const css = read('src/style.css');
const pkg = JSON.parse(read('package.json'));

test('drag input stays integrated with the existing board event lifecycle', () => {
  assert.match(main, /function wireBoardPointerDrag\(board\)/);
  assert.match(main, /dragMoveFrame = requestAnimationFrame/);
  assert.match(main, /offsetX: event\.clientX - sourceRect\.left/);
  assert.match(main, /pieceCenter = \{ x: point\.x - current\.offsetX/);
  assert.match(main, /lostpointercapture/);
  assert.match(main, /isMoveContextCurrent\(state/);
  assert.match(main, /landPieceFromPoint\(/);
});

test('premove remains on the project queue and normal move/clock pipeline', () => {
  assert.match(main, /function queuePremove\(/);
  assert.match(main, /appendPremove\(game, humanColor, Chess, premoveQueue/);
  assert.match(main, /function executeNextPremove\(/);
  assert.match(main, /takeNextPremove\(game, queue, humanColor\)/);
  assert.match(main, /playMove\(move\.from, move\.to, move\.promotion, \{ premove: true, slideDuration: 100 \}\)/);
  assert.match(main, /clockState\.remaining\[mover\].*100/);
  assert.match(css, /\.square\.premove-to/);
});

test('the standalone overlay controller is not installed as a competing input system', () => {
  assert.equal(fs.existsSync(new URL('../src/interactions/drag.js', import.meta.url)), false);
  assert.equal(fs.existsSync(new URL('../src/interactions/premove.js', import.meta.url)), false);
  assert.equal(fs.existsSync(new URL('../src/interactions/animate.js', import.meta.url)), false);
});

test('static test command includes the merge regression test', () => {
  assert.match(pkg.scripts['test:static'], /tests\/drag-premove-merge\.test\.js/);
});
