import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { effectivePlan, grantPlan, revokePlan } from '../src/plans.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
const workerSrc = fs.readFileSync(new URL('../cloudflare/src/index.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');

test('profile links open through one delegated listener and are guarded against double taps', () => {
  assert.match(main, /document\.addEventListener\('click', event => \{[\s\S]{0,300}closest\('\[data-open-profile\]'\)/);
  assert.match(main, /let profileOpenBusy = false/);
  assert.match(main, /finally \{ profileOpenBusy = false; \}/);
  assert.match(css, /\[data-open-profile\]\{[^}]*touch-action:manipulation/);
});

test('tier badges are server-computed, expiry-aware and rendered in every player list', () => {
  assert.match(workerSrc, /tier: tierOf\(user\)/);
  assert.match(workerSrc, /effectivePlan\(normalizeEntitlement\(user\.entitlement\)\)/);
  for (const marker of ['tierBadge(user)', 'tierBadge(u)', 'tierBadge(friend)', 'tierBadge(data.user)']) assert.ok(main.includes(marker), marker);
  assert.match(css, /\.tier-pro\{/); assert.match(css, /\.tier-premium\{/); assert.match(css, /\.tier-admin\{/);
  const now = Date.now();
  assert.equal(effectivePlan(grantPlan({}, 'pro'), now), 'pro');
  assert.equal(effectivePlan({ proExpiresAt: now - 1 }, now), 'free');
  assert.equal(effectivePlan(grantPlan({}, 'premium'), now), 'premium');
  assert.equal(effectivePlan(revokePlan(grantPlan({}, 'premium'), 'all'), now), 'free');
});

test('admin discovery endpoint prefers online admins and purchase requests route to it', () => {
  assert.match(workerSrc, /function findSupportAdmin\(db\)/);
  assert.match(workerSrc, /path === '\/support\/admin'/);
  assert.match(workerSrc, /const admin = findSupportAdmin\(this\.db\);\s*\n\s*if \(!admin\) return fail\('Máy chủ chưa cấu hình/);
  assert.match(main, /socialApi\('\/support\/admin'\)/);
  assert.match(main, /data-find-admin/);
});

test('admin can grant and revoke Pro/Premium with server-side validation and a notice to the player', () => {
  assert.match(workerSrc, /days < 1 \|\| days > 366/);
  assert.match(workerSrc, /action === 'revoke'\) target\.entitlement = revokePlan/);
  assert.match(workerSrc, /grant-premium/);
  assert.match(workerSrc, /if \(target\.banned\) return fail\('Không thể đổi gói/);
  assert.match(workerSrc, /user\.role !== 'admin'\) return fail\('Bạn không có quyền quản trị\.', 403\);\s*\n\s*const target = this\.db\.users\.find\(item => item\.id === params\[2\]\); if \(!target\) return fail\('Không tìm thấy tài khoản\.', 404\);\s*\n\s*const action/);
  assert.match(main, /data-admin-revoke="all"/);
  assert.match(main, /dataset\.planBound === '1'\) return; button\.dataset\.planBound = '1'/);
});

// ---- Runtime checks against the real Worker + Durable Object code (in-memory SQL harness) ----
import worker, { ChessState } from '../cloudflare/src/index.js';

function createHarness(env = {}) {
  const records = new Map();
  const sql = { exec(statement, ...args) {
    if (/^CREATE TABLE/i.test(statement)) return [];
    if (/^SELECT key, value FROM vila_records/i.test(statement)) return [...records.entries()].map(([key, value]) => ({ key, value }));
    if (/^INSERT INTO vila_records/i.test(statement)) { records.set(String(args[0]), String(args[1])); return []; }
    if (/^DELETE FROM vila_records/i.test(statement)) { records.delete(String(args[0])); return []; }
    throw new Error(`SQL statement not covered by test harness: ${statement}`);
  } };
  const state = { storage: { sql, transactionSync: cb => cb() }, blockConcurrencyWhile: cb => cb() };
  const object = new ChessState(state, env);
  return { binding: { idFromName: () => 'v368', get: () => ({ fetch: request => object.fetch(request) }) } };
}
async function call(harness, path, { method = 'GET', token = '', body } = {}) {
  const headers = {}; if (token) headers.Authorization = `Bearer ${token}`; if (body !== undefined) headers['Content-Type'] = 'application/json';
  const response = await worker.fetch(new Request(`https://vila-test.workers.dev${path}`, { method, headers, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) }), { CHESS_STATE: harness.binding });
  return { status: response.status, data: await response.json() };
}

test('runtime: find admin, buy request goes to admin, admin grants/revokes Pro & Premium and badges follow', async () => {
  const h = createHarness({ ADMIN_USERNAME: 'vila_admin', ADMIN_PASSWORD: 'Safe-Admin-Password-1234' });
  const reg = async (username, password) => (await call(h, '/api/social/auth/register', { method: 'POST', body: { username, displayName: username, password, initialElo: 800 } })).data;
  const alice = await reg('buyer_alice', 'Alice-Password-123');
  const bob = await reg('viewer_bob', 'Bob-Password-1234');
  const admin = (await call(h, '/api/social/auth/login', { method: 'POST', body: { username: 'vila_admin', password: 'Safe-Admin-Password-1234' } })).data;
  assert.ok(admin.token, 'admin can log in');

  // Unauthenticated callers cannot look up admins; players can.
  assert.equal((await call(h, '/api/social/support/admin')).status, 401);
  const found = await call(h, '/api/social/support/admin', { token: alice.token });
  assert.equal(found.status, 200);
  assert.equal(found.data.admin.username, 'vila_admin');
  assert.equal(found.data.admin.tier, 'premium');
  assert.equal('email' in found.data.admin, false);

  // A purchase request is routed to that admin.
  const req = await call(h, '/api/social/me/purchase-requests', { method: 'POST', token: alice.token, body: { plan: 'diamond', amountVnd: 99000 } });
  assert.equal(req.status, 201, JSON.stringify(req.data));
  assert.equal(req.data.admin.id, found.data.admin.id);

  // Players cannot grant plans; admin can, with days.
  const aliceId = alice.user.id;
  assert.equal((await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: bob.token, body: { action: 'grant', plan: 'premium' } })).status, 403);
  assert.equal((await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: admin.token, body: { action: 'grant', plan: 'pro', days: 0 } })).status, 400);
  assert.equal((await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: admin.token, body: { action: 'grant', plan: 'premium', days: 5 } })).status, 400);
  const pro = await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: admin.token, body: { action: 'grant', plan: 'pro', days: 30 } });
  assert.equal(pro.status, 200, JSON.stringify(pro.data));
  assert.equal(pro.data.user.tier, 'pro');
  const left = pro.data.user.entitlement.proExpiresAt - Date.now();
  assert.ok(left > 29.9 * 86_400_000 && left < 30.1 * 86_400_000);

  // Other players see the badge on the public profile and in search.
  assert.equal((await call(h, '/api/social/users/buyer_alice', { token: bob.token })).data.user.tier, 'pro');
  assert.equal((await call(h, '/api/social/users/search?q=buyer', { token: bob.token })).data.users[0].tier, 'pro');

  const prem = await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: admin.token, body: { action: 'grant', plan: 'premium' } });
  assert.equal(prem.data.user.tier, 'premium');
  const revoked = await call(h, `/api/social/admin/users/${aliceId}/plan`, { method: 'PATCH', token: admin.token, body: { action: 'revoke', plan: 'all' } });
  assert.equal(revoked.data.user.tier, 'free');

  // The player is told about each change in the admin conversation.
  const inbox = await call(h, `/api/social/messages/${admin.user.id}`, { token: alice.token });
  assert.ok(inbox.data.messages.some(m => /thu hồi/.test(m.text)) && inbox.data.messages.some(m => /được cấp gói Premium/.test(m.text)));

  // Admin can also grant Premium straight from a Premium inquiry.
  const inquiry = await call(h, '/api/social/me/purchase-requests', { method: 'POST', token: bob.token, body: { plan: 'premium', amountVnd: 100000 } });
  assert.equal(inquiry.status, 201);
  const pending = await call(h, '/api/social/admin/purchase-requests', { token: admin.token });
  const row = pending.data.requests.find(item => item.plan === 'premium');
  const decided = await call(h, `/api/social/admin/purchase-requests/${row.id}/decision`, { method: 'POST', token: admin.token, body: { action: 'grant-premium' } });
  assert.equal(decided.status, 200, JSON.stringify(decided.data));
  assert.equal(decided.data.user.tier, 'premium');
});

test('runtime: offline-admin bot panel data, one auto-reply per hour, and it never grants plans', async () => {
  const h = createHarness({ ADMIN_USERNAME: 'vila_admin', ADMIN_PASSWORD: 'Safe-Admin-Password-1234' });
  const alice = (await call(h, '/api/social/auth/register', { method: 'POST', body: { username: 'bot_alice', displayName: 'Alice', password: 'Alice-Password-123', initialElo: 800 } })).data;
  const admin = (await call(h, '/api/social/auth/login', { method: 'POST', body: { username: 'vila_admin', password: 'Safe-Admin-Password-1234' } })).data;
  await call(h, '/api/social/me', { token: admin.token }); // heartbeat: admin is online now
  let info = await call(h, '/api/social/support/admin', { token: alice.token });
  assert.equal(info.data.assistant.active, false, 'bot stays hidden while an admin is online');

  const realNow = Date.now; Date.now = () => realNow() + 10 * 60_000; // admin goes offline
  try {
    info = await call(h, '/api/social/support/admin', { token: alice.token });
    assert.equal(info.data.assistant.active, true);
    assert.equal(info.data.assistant.canGrantPlans, false);
    await call(h, '/api/social/me/purchase-requests', { method: 'POST', token: alice.token, body: { plan: 'premium', amountVnd: 100000 } });
    info = await call(h, '/api/social/support/admin', { token: alice.token });
    assert.equal(info.data.assistant.pendingRequests, 1);
    assert.equal(info.data.assistant.yourPending[0].position, 1);

    await call(h, `/api/social/messages/${admin.user.id}`, { method: 'POST', token: alice.token, body: { text: 'Admin ơi?' } });
    await call(h, `/api/social/messages/${admin.user.id}`, { method: 'POST', token: alice.token, body: { text: 'Còn đó không?' } });
    const thread = await call(h, `/api/social/messages/${admin.user.id}`, { token: alice.token });
    assert.equal(thread.data.messages.filter(m => m.text.startsWith('VILA Trợ lý (bot):')).length, 1, 'only one bot reply per hour');
    const me = await call(h, '/api/social/me', { token: alice.token });
    assert.notEqual(me.data.user?.tier, 'pro', 'the bot never activates a plan');
  } finally { Date.now = realNow; }
});

test('bot gets a 3D label, chat shows it for bot replies, and music plays as one small pill', () => {
  assert.match(main, /const botLabel3d = /);
  assert.match(main, /chatMessageBodyHtml\(message\.text\)/);
  assert.match(css, /\.bot-label-3d\{[^}]*box-shadow:inset 0 1px rgba\(255,255,255,\.4\),0 3px 0/);
  assert.match(css, /\.yt-music-card\.is-collapsed\{[^}]*border-radius:999px/);
  assert.match(css, /\.yt-music-card\.is-collapsed #vilaYtPrev,\.yt-music-card\.is-collapsed #vilaYtNext\{display:none\}/);
});
