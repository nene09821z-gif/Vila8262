import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { soundKindForMove, playBoardSound, playGameSound, soundEnabledForTier } from '../src/sound.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('soundKindForMove picks a distinct sound per move type, mate beating check beating the rest', () => {
  const none = { isCheck: () => false, isCheckmate: () => false };
  assert.equal(soundKindForMove({ flags: 'n' }, none), 'move');
  assert.equal(soundKindForMove({ flags: 'c', captured: 'p' }, none), 'capture');
  assert.equal(soundKindForMove({ flags: 'e', captured: 'p' }, none), 'capture');
  assert.equal(soundKindForMove({ flags: 'k' }, none), 'castle');
  assert.equal(soundKindForMove({ flags: 'q' }, none), 'castle');
  assert.equal(soundKindForMove({ flags: 'np', promotion: 'q' }, none), 'promote');
  assert.equal(soundKindForMove({ flags: 'c', captured: 'p' }, { isCheck: () => true, isCheckmate: () => false }), 'check');
  assert.equal(soundKindForMove({ flags: 'n' }, { isCheck: () => true, isCheckmate: () => true }), 'checkmate');
  assert.equal(soundKindForMove(null, none), null);
});

test('sound helpers are silent no-ops when disabled or when Web Audio is unavailable (Node)', () => {
  assert.equal(playBoardSound({ flags: 'n' }, null, false), false);
  assert.equal(playBoardSound(null, null, true), false);
  assert.equal(playGameSound('win', false), false);
  assert.equal(playGameSound('win', true), false); // no AudioContext in Node: must not throw
  assert.equal(playGameSound('', true), false);
});

test('LOW silences sound by default but allows an explicit user opt-in', () => {
  assert.equal(soundEnabledForTier(true, 'low', false), false);
  assert.equal(soundEnabledForTier(true, 'low', true), true);
  assert.equal(soundEnabledForTier(true, 'medium', false), true);
  assert.equal(soundEnabledForTier(true, 'high', false), true);
  assert.equal(soundEnabledForTier(false, 'high', true), false);
});

test('game events are wired to sounds and respect the sound setting', () => {
  for (const kind of ['start', 'flag', 'illegal', 'lowtime']) {
    assert.match(main, new RegExp(`playGameSound\\('${kind}', settings\\.soundEnabled\\)`), `missing ${kind} sound`);
  }
  assert.match(main, /playGameSound\(jingle, settings\.soundEnabled\)/);
  assert.match(main, /import \{ playBoardSound, playGameSound,/);
});
