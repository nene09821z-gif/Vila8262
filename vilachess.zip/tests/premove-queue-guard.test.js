import test from 'node:test';
import assert from 'node:assert/strict';
import { appendPremove, takeNextPremove, MAX_PREMOVE_QUEUE } from '../src/premove.js';

test('premove queue rejects a sixth entry without replaying a virtual board', () => {
  const chess = { turn: () => 'b' };
  const queue = Array.from({ length: MAX_PREMOVE_QUEUE }, (_, index) => ({ from: `a${index + 1}`, to: `b${index + 1}` }));
  assert.equal(MAX_PREMOVE_QUEUE, 5);
  assert.equal(appendPremove(chess, 'w', null, queue, 'e2', 'e4'), null);
});

test('premove cannot be added when it is already the player turn', () => {
  const chess = { turn: () => 'w' };
  assert.equal(appendPremove(chess, 'w', null, [], 'e2', 'e4'), null);
});

test('a stale first premove cancels the whole queue', () => {
  const chess = { turn: () => 'w', moves: () => [] };
  const queue = [{ from: 'e2', to: 'e4' }, { from: 'g1', to: 'f3' }];
  const result = takeNextPremove(chess, queue, 'w');
  assert.equal(result.move, null);
  assert.deepEqual(result.rest, []);
  assert.deepEqual(result.cancelled, queue);
});
