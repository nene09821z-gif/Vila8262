import test from 'node:test';
import assert from 'node:assert/strict';
import { detectDeviceTier, androidApiFromUserAgent, iosVersionFromUserAgent, useDeviceTier, publishDeviceTier } from '../src/device-tier.js';

const gb = value => value * 1024 ** 3;

test('detects low RAM, limited CPU, older Android API, and system battery saver', () => {
  const win = { navigator: { userAgent: 'Android 14', deviceMemory: 8, hardwareConcurrency: 8 } };
  assert.equal(detectDeviceTier(win, { totalRamBytes: gb(2), cpuCores: 8, androidApiLevel: 34 }).tier, 'low');
  assert.equal(detectDeviceTier(win, { totalRamBytes: gb(4), cpuCores: 4, androidApiLevel: 34 }).tier, 'low');
  assert.equal(detectDeviceTier(win, { totalRamBytes: gb(4), cpuCores: 8, androidApiLevel: 28 }).tier, 'low');
  assert.equal(detectDeviceTier(win, { totalRamBytes: gb(8), cpuCores: 8, androidApiLevel: 34, powerSaveMode: true }).tier, 'low');
});

test('classifies mid-range and high-end devices without assuming unknown mobile RAM is high-end', () => {
  const android = ua => ({ navigator: { userAgent: ua } });
  assert.equal(detectDeviceTier(android('Android 14'), { totalRamBytes: gb(4), cpuCores: 8, androidApiLevel: 34 }).tier, 'medium');
  assert.equal(detectDeviceTier(android('Android 14'), { totalRamBytes: gb(8), cpuCores: 8, androidApiLevel: 34 }).tier, 'high');
  assert.equal(detectDeviceTier(android('Android 14')).tier, 'medium');
});

test('parses Android API and iOS fallback versions', () => {
  assert.equal(androidApiFromUserAgent('Mozilla/5.0 (Linux; Android 9; Device)'), 28);
  assert.equal(androidApiFromUserAgent('Mozilla/5.0 (Linux; Android 14; Device)'), 34);
  assert.equal(iosVersionFromUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 13_6 like Mac OS X)'), 13.6);
  assert.equal(iosVersionFromUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 16_2 like Mac OS X)'), 16.2);
});

test('useDeviceTier snapshot follows published quality changes', () => {
  publishDeviceTier('high');
  assert.deepEqual(useDeviceTier(), { tier: 'high', isLowEnd: false });
  publishDeviceTier('low');
  assert.deepEqual(useDeviceTier(), { tier: 'low', isLowEnd: true });
  publishDeviceTier('medium'); // restore the module default for unrelated tests
});
