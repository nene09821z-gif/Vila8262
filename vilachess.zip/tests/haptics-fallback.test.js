import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const source = readFileSync(new URL('../src/haptics.js', import.meta.url), 'utf8');

test('haptics are tier-gated and use native bridge before Capacitor plugin fallback', () => {
  assert.match(source, /from ['"]@capacitor\/haptics['"]/);
  assert.match(source, /deviceTier\.useHaptic\s*!==\s*true/);
  assert.match(source, /bridge\.vibrate\(androidDurationMs\)/);
  assert.match(source, /Haptics\.impact\(\{\s*style\s*\}\)/);
  assert.match(source, /export function hapticLight\(/);
  assert.match(source, /export function hapticMedium\(/);
  assert.match(source, /export function hapticHeavy\(/);
});
