import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { summarizeFrames, createPerfGovernor, PERF_KEY, PERF_MODE_KEY, nextLowerTier } from '../src/perf-governor.js';

const smooth = n => Array.from({ length: n }, () => 16.7);
const janky = n => Array.from({ length: n }, (_, i) => (i % 3 === 0 ? 70 : 17));

test('smooth 60 fps is not janky; stalls are', () => {
  const a = summarizeFrames(smooth(40));
  assert.equal(a.jankRatio, 0); assert.ok(a.fps > 55);
  const b = summarizeFrames(janky(40));
  assert.ok(b.jankRatio > 0.3 && b.p95Ms >= 70);
});

test('frame summaries remain refresh-rate neutral for 120 Hz and 30 Hz samples', () => {
  assert.equal(summarizeFrames(Array(40).fill(8.3)).jankRatio, 0);
  assert.equal(summarizeFrames(Array(40).fill(33.3)).jankRatio, 0);
  assert.equal(nextLowerTier('high'), 'medium');
  assert.equal(nextLowerTier('medium'), 'low');
  assert.equal(nextLowerTier('low'), 'low');
});

function fakeEnv(search = '', navigator = {}) {
  const frames = []; let id = 0; const store = new Map();
  const doc = {
    documentElement: { dataset: {} }, body: null, hidden: false,
    addEventListener() {}, createElement: () => ({ style: {}, setAttribute() {} })
  };
  const win = { location: { search }, navigator };
  return {
    doc, win, frames, store,
    storage: { getItem: k => store.get(k) ?? null, setItem: (k, v) => store.set(k, v), removeItem: k => store.delete(k) },
    raf: cb => { frames.push(cb); id += 1; return id; }, caf: () => {},
    runFrames(count, delta = 16.7) {
      let t = 1000;
      for (let i = 0; i < count; i += 1) {
        const cb = frames.shift();
        if (!cb) break;
        t += delta;
        cb(t);
      }
    }
  };
}

test('auto starts with hardware-based quality and publishes both quality DOM attributes', () => {
  const env = fakeEnv('', { userAgent: 'Android 14', deviceMemory: 8, hardwareConcurrency: 8 });
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, deviceInfo: { totalRamBytes: 8 * 1024 ** 3, cpuCores: 8, androidApiLevel: 34, powerSaveMode: false }, dev: true });
  assert.equal(gov.mode, 'auto');
  assert.equal(gov.tier, 'high');
  assert.equal(env.doc.documentElement.dataset.quality, 'high');
  assert.equal(env.doc.documentElement.dataset.perf, 'full');
});

test('FPS below 45 for a full three-second drag window lowers one tier only', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: true });
  assert.equal(gov.tier, 'high');
  assert.ok(gov.begin('drag'));
  env.runFrames(125, 25); // approximately 40 fps for just over three seconds
  assert.equal(gov.tier, 'medium');
  assert.equal(env.store.get(PERF_KEY), 'medium');
  assert.equal(env.store.get(PERF_MODE_KEY), undefined, 'automatic downgrade must not become a manual preference');
  gov.end('drag');
});

test('manual LOW/MEDIUM/HIGH override auto-detection and persist independently from the detected tier', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: true });
  gov.setMode('low');
  assert.equal(gov.mode, 'low'); assert.equal(gov.tier, 'low');
  assert.equal(env.store.get(PERF_MODE_KEY), 'low');
  gov.setMode('high');
  assert.equal(gov.tier, 'high');
  assert.equal(env.store.get(PERF_MODE_KEY), 'high');
  gov.setMode('auto');
  assert.equal(gov.mode, 'auto');
  assert.equal(env.store.get(PERF_MODE_KEY), 'auto');
});

test('manual HIGH is not automatically changed by the FPS guard', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: true });
  gov.setMode('high');
  gov.begin('drag');
  env.runFrames(125, 25);
  assert.equal(gov.tier, 'high');
  gov.end('drag');
});


test('production build does not start an FPS requestAnimationFrame monitor', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: false });
  assert.equal(gov.begin('drag'), false);
  assert.equal(gov.sampleStartup(), false);
  assert.equal(env.frames.length, 0);
});

test('auto mode rechecks hardware and power saver when the app returns to foreground', () => {
  let nativeInfo = { totalRamBytes: 8 * 1024 ** 3, cpuCores: 8, androidApiLevel: 34, powerSaveMode: true };
  const env = fakeEnv('', { userAgent: 'Android 14', deviceMemory: 8, hardwareConcurrency: 8 });
  env.win.AndroidBridge = { getDeviceTierInfo: () => JSON.stringify(nativeInfo) };
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: true });
  assert.equal(gov.tier, 'low');
  nativeInfo = { ...nativeInfo, powerSaveMode: false };
  assert.equal(gov.refreshDeviceInfo().tier, 'high');
  assert.equal(gov.tier, 'high');
});

test('URL override supports legacy lite/full and the new three quality tiers', () => {
  const legacy = fakeEnv('?perf=lite');
  const low = createPerfGovernor({ win: legacy.win, doc: legacy.doc, storage: legacy.storage, raf: legacy.raf, caf: legacy.caf });
  assert.equal(low.tier, 'low');
  assert.equal(legacy.store.has(PERF_KEY), false);
  const mediumEnv = fakeEnv('?perf=medium');
  const medium = createPerfGovernor({ win: mediumEnv.win, doc: mediumEnv.doc, storage: mediumEnv.storage, raf: mediumEnv.raf, caf: mediumEnv.caf });
  assert.equal(medium.tier, 'medium');
});

test('labelled session end is guarded and smooth sessions keep the current tier', () => {
  const env = fakeEnv();
  const gov = createPerfGovernor({ win: env.win, doc: env.doc, storage: env.storage, raf: env.raf, caf: env.caf, dev: true });
  assert.ok(gov.begin('drag'));
  assert.equal(gov.end('slide'), null);
  env.runFrames(40, 16.7);
  const summary = gov.end('drag');
  assert.ok(summary);
  assert.ok(summary.fps > 55);
  assert.equal(gov.tier, 'high');
});

test('main.js wires adaptive quality into drag, slide, settings and a testable Board quality argument', () => {
  const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.match(main, /perfGovernor\.begin\('drag'\)/);
  assert.match(main, /perfGovernor\.begin\('slide'\)/);
  assert.match(main, /function renderBoard\(\{ quality = perfGovernor\.tier \} = \{\}\)/);
  assert.match(main, /dragGhost\.style\.transform = ghostTransformAtOffset\(/);
  assert.match(main, /qualityTierSetting/);
  assert.match(main, /hapticsEnabledSetting/);
  const css = fs.readFileSync(new URL('../src/vila-professional.css', import.meta.url), 'utf8');
  assert.match(css, /html\[data-quality="low"\]/);
  assert.match(css, /html\[data-quality="high"\]/);
});
