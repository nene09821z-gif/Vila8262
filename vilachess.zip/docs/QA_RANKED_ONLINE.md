# ChessPlus — QA ghép trận và đồng bộ online (source 3.69.1)

## 1. Kiến trúc được xác minh từ ZIP

Ứng dụng phát hành mặc định gọi `https://bitter-sun-751a.nene09821z.workers.dev` (`src/settings-schema.js`). Backend triển khai được mô tả trong `cloudflare/README_VI.md` và `cloudflare/wrangler.toml`: **Cloudflare Worker + Durable Object `ChessState` + SQLite storage**. Có `server/index.js`/Express làm backend Node cho phát triển hoặc self-host, nhưng cấu hình app đang trỏ Worker mặc định.

**Không thấy Socket.IO, Firebase Realtime, Supabase Realtime hay WebSocket trong luồng ranked hiện tại.** Giao tiếp thực tế là HTTP REST:

- `POST /api/social/ranked/queue`
- `GET /api/social/ranked/status`
- `POST /api/social/ranked/matches/:id/move`
- `POST /api/social/ranked/matches/:id/resign` và `/abandon`

`src/main.js` dò trạng thái bằng polling thích ứng: khoảng 400 ms khi đang chờ đối thủ, 1.200 ms khi đến lượt mình, 250 ms khi đang có premove xếp hàng, và 3.000 ms khi trang ẩn. Đây là đồng bộ gần thời gian thực theo chu kỳ polling, không phải push đồng thời. Hai máy có thể thấy nước đi lệch nhau một khoảng bằng thời gian polling + độ trễ mạng.

Worker chuyển toàn bộ `/api/social/*` tới một Durable Object có tên cố định `vila-global-community-v1`. `ChessState.fetch()` đưa request vào một promise queue (`this.serial`), vì vậy các request được xử lý tuần tự trong một đối tượng. Điều này giúp tránh hai nước cùng ghi đè trạng thái, nhưng tạo điểm nghẽn chung cho toàn bộ tài khoản, tin nhắn và trận đấu.

## 2. Đánh giá logic và rủi ro

### Đã có biện pháp bảo vệ tốt

- Server không nhận FEN do client tự quyết. Client gửi `from`, `to`, `promotion`, `expectedPly`; server tự dựng `Chess(match.fen)` và gọi `chess.move(...)` để xác minh luật.
- Server xác minh người chơi có thuộc trận, đúng lượt và `expectedPly` đúng với số nước đã lưu.
- Các request được tuần tự hóa trong `ChessState`; request đến sau với cùng `expectedPly` sẽ bị từ chối sau khi request đầu cập nhật ply.
- Đồng hồ và kết quả xếp hạng được xử lý ở server; client chỉ hiển thị đồng hồ dựa trên snapshot server.
- Match có `startFen`, `fen`, `moves` và `currentPly`, đủ để khôi phục bàn cờ mà không phải yêu cầu PGN.

### Rủi ro cần ưu tiên xử lý

| Mức | Phát hiện | Ảnh hưởng / xử lý đề xuất |
|---|---|---|
| P1 | **Polling nhanh hơn giới hạn rate limit.** `cloudflare/src/index.js` giới hạn `/ranked/*` ở 120 request/phút theo IP. Client chờ đối thủ poll 400 ms (~150/phút); premove poll 250 ms (~240/phút). Hai điện thoại cùng Wi‑Fi còn dùng chung IP Cloudflare. | Có thể nhận HTTP 429 trong ván đang chạy. Cần đặt ngân sách polling dưới ngưỡng; tốt hơn là tăng/đổi giới hạn status riêng theo userId + IP, có `Retry-After`, và client backoff khi 429. Không dùng giới hạn hiện tại như một con số “an toàn” khi stress test. |
| P1 | **`pagehide` gửi `/abandon`** trong `src/main.js`. Endpoint này kết thúc trận như bỏ cuộc và có thể trừ Elo sau khi đủ hai bên đã đi. | Sự kiện `pagehide` không phải tín hiệu chắc chắn rằng người chơi chủ động đầu hàng; reload, điều hướng document hoặc lifecycle bất thường có thể tạo kết quả giả. Chỉ gửi resign khi người chơi xác nhận nút Đầu hàng/Thoát. `pagehide` chỉ nên lưu trạng thái cục bộ; timeout server xử lý thiết bị mất hẳn. |
| P1 | **Reconnect sau 90 giây không đảm bảo giữ trận.** Worker xử thua nếu presence của người chơi quá 90.000 ms; polling có thể bị OS tạm dừng khi app background. | Quay lại trước 90 giây có thể đồng bộ lại; quá thời hạn thì server đã kết thúc trận. Cần ghi rõ grace period trong UX và chỉ tăng thời hạn khi đã xem xét tác động đồng hồ/abuse. Daily được miễn timeout presence. |
| P1 | **Một Durable Object toàn cục xử lý mọi API cộng đồng.** `this.serial` tuần tự hóa cả các request không liên quan đến cùng trận. | Tải tăng sẽ làm queue request dài, tăng latency cho ghép trận và nhắn tin. Tách matchmaker / per-match state DO hoặc shard theo khu vực/nhóm; giữ một authority duy nhất cho từng trận. |
| P2 | **`ranked/status` là GET nhưng có side effect.** Nó cập nhật presence, settle clock và có thể kết thúc trận. | Retry/refresh GET làm thay đổi DB và ghi SQLite. Về semantics REST nên xem đây là “đọc trạng thái có heartbeat”; tốt hơn tách heartbeat/lease khỏi status snapshot. |
| P2 | **Client khôi phục bàn cờ bằng replay lịch sử nhưng chưa so sánh cuối với `match.fen`.** `rankedSyncChess()` dừng replay nếu có move lỗi, rồi vẫn gán bàn cờ clone. | Một dữ liệu lịch sử lỗi có thể để UI hiện vị trí thiếu nước. Sau replay, so sánh `clone.fen()` với `match.fen`; nếu lệch thì load trực tiếp FEN server và ghi telemetry. |
| P2 | **Không có idempotency key cho move POST.** `expectedPly` chặn áp dụng trùng, nhưng nếu server nhận move rồi response rơi mạng, retry sẽ nhận stale 409. | Client phải GET `/ranked/status` trước khi thử lại, không gửi lại nước cũ mù quáng. Nên bổ sung `clientMoveId` lưu kết quả đã xử lý để trả cùng response cho retry. |
| P2 | **Premove lưu ở trạng thái client.** Không có API lưu queue; catch của submit lỗi sẽ xóa premove. | Không thể bảo đảm premove tồn tại sau app bị kill/mất RAM. Khi offline/background nên hủy premove cũ; sau khi resume đồng bộ FEN/ply rồi cho người chơi xếp lại. Không gửi premove lên server như lệnh đi trước lượt. |
| P2 | **Đồng hồ hiển thị dùng `Date.now()` trên điện thoại.** Server mới là bên quyết định hết giờ, nhưng clock display tính thời gian từ `clockUpdatedAt` bằng đồng hồ local. | Điện thoại lệch giờ có thể hiển thị nhanh/chậm dù kết quả server đúng. Tính `serverOffset` từ các snapshot có `clockUpdatedAt` + RTT, dùng server-adjusted time cho UI; server vẫn quyết định flag. |
| P3 | **Hai client không nhận event cùng lúc.** Client chờ đối thủ phụ thuộc polling; background poll chậm hơn. | Tăng độ trễ hiển thị. Khi muốn push realtime thật, thêm WebSocket qua Durable Object (hoặc dịch vụ realtime khác) và giữ REST status làm cơ chế resync dự phòng. |
| P3 | Fair-play focus data do client gửi (`focusLostMs`, `focusCount`) có thể bị giả mạo. | Chỉ dùng làm tín hiệu hỗ trợ rà soát; không dùng làm bằng chứng hoặc tự động xử phạt. |

### Tranh chấp hai nước cùng lúc

Hiện tại, quyết định đúng là “request hợp lệ đầu tiên được Durable Object xử lý theo thứ tự tuần tự”. Request kế tiếp với `expectedPly` cũ nhận 409 hoặc sai lượt. Không nên ưu tiên theo timestamp client vì đồng hồ thiết bị và độ trễ không đáng tin. Server phải là nơi gán thứ tự chuẩn.

### Có cần phát lại toàn bộ PGN khi reconnect?

Không cần yêu cầu PGN. Với giao thức hiện tại, gọi `GET /ranked/status`, lấy `startFen`, `moves`, `fen`, `currentPly`; replay `moves` bằng `chess.js` là đủ để phục hồi lịch sử. Có thể tải FEN snapshot + delta moves nếu lịch sử dài. Nên xác thực `replayedFen === serverFen`, nếu không thì dùng `serverFen` làm vị trí phục hồi và báo lỗi dữ liệu.

## 3. Kịch bản kiểm thử thủ công — 15 test cases

Dùng hai điện thoại, hai tài khoản test riêng. Trước mỗi case ghi lại match ID, time control và trạng thái mạng. Không chạy thử nghiệm rớt mạng trên tài khoản Elo thật.

| TC | Mức | Thao tác | Kết quả mong đợi |
|---|---|---|---|
| 01 | Cơ bản | Hai tài khoản chọn cùng time control và tìm trận. | Cùng `matchId`, màu khác nhau, `startFen` và `fen` giống nhau. |
| 02 | Cơ bản | Chọn hai time control khác nhau (ví dụ 3+0 và 5+0). | Không ghép nhầm; mỗi người ở đúng hàng đợi. |
| 03 | Cơ bản | Trắng đi một nước hợp lệ. | Server trả 200; `moves.length` tăng đúng 1; Đen thấy nước mới sau một chu kỳ poll. |
| 04 | Bảo mật | Sửa request để gửi nước không hợp lệ hoặc sai tọa độ. | Server trả 400; FEN, moves và clock state không bị áp dụng nước giả. |
| 05 | Bảo mật | Tài khoản thứ ba gọi move trong match không thuộc về mình. | Server trả 403; dữ liệu trận không đổi. |
| 06 | Đồng bộ | Gửi hai POST cùng `expectedPly` gần như đồng thời từ hai phiên của cùng người chơi. | Tối đa một request được chấp nhận; request còn lại stale/409; server chỉ có một ply mới. |
| 07 | Đồng bộ | Tắt mạng ngay sau khi nhấn đi, bật lại sau vài giây. | Không tự gửi lại nước cũ; GET status xác định server đã nhận hay chưa; bàn cờ trở lại đúng FEN. |
| 08 | Lifecycle | Đưa app xuống background 10–30 giây rồi mở lại. | Không bị tự đầu hàng; status được lấy ngay khi resume; đồng hồ phản ánh thời gian server đã trôi qua. |
| 09 | Lifecycle | Để app background quá 90 giây (trên staging). | Xác nhận chính sách hiện tại: timeout disconnect có thể kết thúc trận; UX hiển thị đúng lý do. |
| 10 | Mạng | Chuyển Wi‑Fi sang 4G trong lúc chờ đối thủ. | Request lỗi tạm thời có retry/backoff; app đồng bộ lại cùng match ID và không tạo trận thứ hai. |
| 11 | Mạng | Chuyển Wi‑Fi sang 4G đúng lúc submit nước đi. | Sau reconnect, status có đúng 0 hoặc 1 ply mới; không có nước trùng. |
| 12 | Premove | Xếp premove, để đối thủ đi, giữ app foreground. | Premove chỉ thực thi khi đến lượt; server xác minh như nước đi bình thường. |
| 13 | Premove | Xếp premove rồi tắt mạng/kill app trước khi đối thủ đi. | Premove không được tự phát khi khôi phục trạng thái cũ; sau resync phải xếp lại nếu cần. |
| 14 | Đồng hồ | Đổi giờ hệ thống điện thoại nhanh/chậm vài phút, rồi để một bên hết giờ trên staging. | Server quyết định kết quả; chỉnh giờ local không thể kéo dài thời gian thật. Clock hiển thị có thể lệch nếu chưa triển khai server offset. |
| 15 | Độ bền | Khởi động lại Worker/DO hoặc đóng/mở app sau vài chục nước. | Match ID, FEN, moves, clock và kết quả còn nhất quán từ SQLite; không mất hoặc nhân đôi nước. |

## 4. Chạy script giả lập 2 người

Script đi theo đúng API REST trong source, đăng nhập hai tài khoản, tìm trận cùng time control, sinh nước hợp lệ bằng `chess.js`, gửi 50 plies mặc định với khoảng cách 1 giây và thỉnh thoảng xác minh status của client còn lại.

```bash
# Node.js 20+ tại thư mục gốc dự án
P1_USERNAME=qa_player_one P1_PASSWORD='your-test-password' \
P2_USERNAME=qa_player_two P2_PASSWORD='your-test-password' \
TARGET_PLIES=50 MOVE_INTERVAL_MS=1000 CLEANUP=1 \
npm run qa:ranked-online
```

PowerShell:

```powershell
$env:P1_USERNAME='qa_player_one'
$env:P1_PASSWORD='your-test-password'
$env:P2_USERNAME='qa_player_two'
$env:P2_PASSWORD='your-test-password'
$env:TARGET_PLIES='50'
$env:MOVE_INTERVAL_MS='1000'
$env:CLEANUP='1'
npm run qa:ranked-online
```

Tạo tài khoản QA tự động (chỉ dùng Worker staging):

```bash
AUTO_REGISTER=1 TARGET_PLIES=50 CLEANUP=1 npm run qa:ranked-online
```

`TARGET_PLIES=50` nghĩa là 50 nửa nước (ply), không phải 50 cặp nước. `CLEANUP=1` mặc định cho P1 đầu hàng sau khi test để không để lại trận active; thao tác này làm thay đổi kết quả/Elo của **tài khoản QA**. Đặt `CLEANUP=0` thì phải tự xử lý trận sau test; nếu bỏ đó, timeout presence có thể xử thua một bên.

Script đo RTT của request và RSS/heap của tiến trình Node chạy test. **Nó không thể đo RAM của Cloudflare Worker hoặc Durable Object từ phía client.** Để đo memory leak server cần Cloudflare Observability/Workers Logs/Metrics hoặc chạy backend Node tự host và giám sát process server, đồng thời soak test nhiều match/user trong thời gian dài. Hai client chỉ là integration smoke test, không phải load test tải lớn.

## 5. Reconnect trong Capacitor 7 (REST polling)

Dự án hiện chưa có dependency `@capacitor/app`. Cài plugin 7.x tương thích Capacitor 7:

```bash
npm install @capacitor/app@^7
npx cap sync android
```

Ví dụ module `src/ranked-reconnect.example.js` đính kèm dùng `App.addListener('appStateChange')`, `visibilitychange`, `online` và `pageshow`. Khi app quay lại foreground hoặc mạng hoạt động lại, gọi `GET /ranked/status`, cập nhật state server, sau đó tiếp tục polling hiện có. Nó không cố “replay nước offline” hoặc gửi lại POST nước cũ.

Trong `main.js`, truyền callback `syncRankedFromServer` gọi `await refreshRankedStatus(false); startRankedPolling();`. Đổi tên callback theo hàm hiện có của dự án. Bỏ listener `pagehide` đang POST `/abandon` khi chỉ đóng/ẩn document; hành động đầu hàng chỉ nên gắn với nút xác nhận. Backend hiện có presence timeout 90 giây cho Bullet/Blitz/Rapid; Daily không áp dụng timeout này.

## 6. Giới hạn xác minh của báo cáo

- Đã đọc source ZIP 3.69.1, Cloudflare Worker, Node Express backend, client ranked polling và test Cloudflare harness.
- Chưa triển khai Worker, chưa gửi request lên tài khoản Cloudflare thực, chưa thử hai điện thoại và chưa chạy soak/load test thật.
- Môi trường tạo báo cáo không có `node_modules`; script được kiểm tra cú pháp Node, nhưng chưa thể chạy `chess.js` hoặc xác minh endpoint đang deploy.
