# ChessPlus — mobile board/theme hotfix (v3.69.1 fix14)

## What changed

- The real play-board wrapper is `.board-frame > .board-surface > #board.chessboard`; the project does not use `.app-container` or `.board-container`. The mobile rules now size this structure from its parent content box (`width: 100%`) and cap the board at 500px. There are no `95vw` board-width rules in the final premium layer.
- `.board-frame` and `.board-surface` are square, the grid is 8 × 8 with `minmax(0, 1fr)` tracks, and both wrapper levels clip overflow. `aspect-ratio: 1 / 1` lets the browser derive the height from the available width while preserving equal square dimensions without a JS resize calculation.
- Board colors are the Chess.com-style green pair `#EBECD0` / `#739552`. Piece wrappers are centered flex containers; piece art is 82% × 82% with `object-fit: contain`. Only the active drag ghost is promoted with `will-change`, not all 64 static pieces.
- The user-selected piece style now updates mounted `.piece` nodes via `updateBoardTheme()`. It preloads image-backed sets before patching, writes a debug record containing `sampleUrl` and `failed` piece codes, and falls back to the local flat PNG for failed themed assets.
- Vite public asset URLs are resolved through `import.meta.env.BASE_URL`, which is `./` for this project's Capacitor/Vite configuration.
- LOW quality keeps the small raster shortcut only for the default flat theme. Other piece styles render normally so the selection is not ignored on low-end devices.
- Main play squares expose `data-piece="wK"` / `data-piece="bP"`, etc. so the renderer can identify each piece without guessing from the child image.
- Main-board pointer listeners are now scoped to an `AbortController`; a view replacement aborts them. Backgrounding cancels a gesture, and resize/orientation changes cancel stale geometry then schedule a fresh board layout measurement.
- The service worker cache key changed to `chessplus-v3.69.1-fix14` so installed PWA/WebView shells pick up the updated source bundle.

## Existing interaction architecture retained

No duplicate `src/interactions/*` package was added. ChessPlus already has an integrated implementation:

- `src/main.js`: main-play Pointer Events pipeline, RAF-coalesced ghost `transform`, move application and animation queue.
- `src/board-interact.js`: shared delegated drag helper and WAAPI slides for secondary boards.
- `src/board-drag-fx.js` / `src/board-motion.js`: pickup, landing, return, capture and move keyframes/easing.
- `src/premove.js`: bounded 5-intent premove queue, virtual preview and re-validation against the actual chess position.

This avoids two competing drag handlers or two separate premove queues.

## Debugging piece sets

1. Open Chrome DevTools (desktop: F12). For an Android Capacitor WebView, enable USB debugging, connect the phone, then open `chrome://inspect/#devices` in desktop Chrome and inspect the ChessPlus WebView.
2. In **Console**, change the piece set and look for `[ChessPlus] Piece theme applied`. Check `themeId`, `updated`, `failed`, and `sampleUrl`.
3. In **Network**, filter by `svg` or `piece-sets`. A file-based set should return HTTP 200. Inline generated styles (`royal`, `neon`, etc.) do not need an SVG network request.
4. In **Elements**, inspect `#board .piece`. The wrapper should carry a `data-piece` such as `wK`; its child should be the selected `img.piece-svg` or inline `svg.piece-svg`.
5. Quick Console checks:

   ```js
   document.querySelectorAll('#board .square').length
   document.querySelectorAll('#board .piece[data-piece]').length
   document.querySelector('#board .piece img')?.currentSrc
   document.documentElement.dataset.pieceTheme
   ```

## Validation performed

- `node --check` passed for `src/main.js`, `src/pieces.js`, and `public/sw.js`.
- Targeted Node tests passed: piece assets/theme switching, CSS bundle sync, mobile layout regression, drag effects and premove queue guard (27 tests).
- The complete Vite/Capacitor build was not run in this workspace because `node_modules` is not included in the supplied source archive.
