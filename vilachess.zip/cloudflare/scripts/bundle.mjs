// Gộp Worker (cloudflare/src + các tệp ../../src dùng chung) thành MỘT tệp cloudflare/index.js.
// Lý do: deploy từ điện thoại/GitHub web rất hay thiếu thư mục lồng nhau (src/, ../../src/) và wrangler báo
// "không tìm thấy tệp điểm vào". Tệp phẳng này chỉ cần nằm cạnh wrangler.toml + package.json.
//   npm run bundle        (cần: npm install; esbuild đi kèm wrangler)
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const OUT = path.join(root, 'index.js');
export const BANNER = '// TỆP TỰ SINH từ cloudflare/src/index.js bằng `npm run bundle` — đừng sửa tay, hãy sửa nguồn rồi chạy lại.\n';

export async function bundleWorker({ write = true } = {}) {
  const esbuild = await import('esbuild');
  const result = await esbuild.build({
    absWorkingDir: root, entryPoints: ['src/index.js'],
    bundle: true, format: 'esm', platform: 'neutral', target: 'es2022', logLevel: 'warning',
    external: ['chess.js'],           // wrangler tự gộp chess.js từ node_modules khi deploy
    banner: { js: BANNER.trimEnd() },
    write: false, outfile: OUT
  });
  const text = result.outputFiles[0].text;
  if (write) (await import('node:fs')).writeFileSync(OUT, text);
  return text;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const text = await bundleWorker();
  console.log(`Đã ghi cloudflare/index.js (${(text.length / 1024).toFixed(0)} KB).`);
  process.exit(0);
}
