// Kiểm tra nhanh TRƯỚC khi deploy Worker: bắt các lỗi hay gặp mà Cloudflare chỉ báo sau khi build xong.
//   npm run check   (trong thư mục cloudflare)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const problems = [];
const notes = [];
const fail = msg => problems.push(msg);

// 1) wrangler.toml
const toml = fs.readFileSync(path.join(root, 'wrangler.toml'), 'utf8').replace(/^\s*#.*$/gm, '');
const main = (toml.match(/^main\s*=\s*"([^"]+)"/m) || [])[1];
if (!main || !fs.existsSync(path.join(root, main))) fail(`wrangler.toml: main = "${main}" không tồn tại`);
const date = (toml.match(/^compatibility_date\s*=\s*"(\d{4}-\d{2}-\d{2})"/m) || [])[1];
if (!date) fail('wrangler.toml thiếu compatibility_date');
else if (date > new Date().toISOString().slice(0, 10)) fail(`compatibility_date ${date} nằm trong tương lai`);
const bindings = [...toml.matchAll(/\[\[durable_objects\.bindings\]\][^\[]*?class_name\s*=\s*"([^"]+)"/g)].map(m => m[1]);
const exportsCls = [...toml.matchAll(/^\[exports\.([A-Za-z0-9_]+)\]/gm)].map(m => m[1]);
const hasMigrations = /^\[\[migrations\]\]/m.test(toml);
if (hasMigrations && exportsCls.length) fail('wrangler.toml dùng đồng thời [[migrations]] và [exports.*] — Cloudflare không cho trộn, chỉ giữ một kiểu.');
for (const cls of bindings) {
  if (!hasMigrations && !exportsCls.includes(cls)) fail(`Durable Object ${cls} chưa được khai báo: thêm [exports.${cls}] (wrangler >= 4.107) hoặc [[migrations]] new_sqlite_classes.`);
}

// 2) wrangler đủ mới cho [exports.*]
if (exportsCls.length) {
  const pkgPath = path.join(root, 'node_modules', 'wrangler', 'package.json');
  if (fs.existsSync(pkgPath)) {
    const v = JSON.parse(fs.readFileSync(pkgPath, 'utf8')).version;
    const [maj, min] = v.split('.').map(Number);
    if (maj < 4 || (maj === 4 && min < 107)) fail(`wrangler ${v} quá cũ cho [exports.*] (cần >= 4.107.0). Chạy: npm install wrangler@latest`);
    else notes.push(`wrangler ${v}: ok`);
  } else notes.push('chưa cài node_modules nên chưa kiểm tra được phiên bản wrangler (npm install trước).');
}

// 3) cú pháp + import tương đối của Worker
const seen = new Set();
const visit = file => {
  if (seen.has(file)) return; seen.add(file);
  const check = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (check.status !== 0) fail(`lỗi cú pháp ${path.relative(root, file)}:\n${check.stderr.trim()}`);
  const text = fs.readFileSync(file, 'utf8');
  for (const m of text.matchAll(/^\s*(?:import|export)\s[^'"]*?from\s+['"](\.[^'"]+)['"]/gm)) {
    const target = path.resolve(path.dirname(file), m[1]);
    if (!fs.existsSync(target)) fail(`${path.relative(root, file)} import "${m[1]}" nhưng tệp không tồn tại (cloudflare/ phải nằm trong toàn bộ repo, đừng deploy riêng thư mục này).`);
    else visit(target);
  }
  if (/from\s+['"]node:|require\(|\bwindow\.|\blocalStorage\b/.test(text) && !/nodejs_compat/.test(toml)) notes.push(`${path.relative(root, file)}: có API Node/trình duyệt — kiểm tra nodejs_compat nếu build báo lỗi.`);
};
if (main) visit(path.join(root, main));
for (const cls of bindings) {
  const text = fs.readFileSync(path.join(root, main), 'utf8');
  const direct = new RegExp(`export\\s+class\\s+${cls}\\b`).test(text);
  const listed = [...text.matchAll(/export\s*\{([^}]*)\}/g)].some(m => new RegExp(`(^|[\\s,])${cls}([\\s,]|$)`).test(m[1]));
  if (!direct && !listed) fail(`${main} không export class ${cls} (tên phải khớp class_name).`);
}

for (const n of notes) console.log('· ' + n);
if (problems.length) { console.error('\nPREFLIGHT THẤT BẠI:\n- ' + problems.join('\n- ')); process.exit(1); }
console.log(`PREFLIGHT OK (${seen.size} tệp, ${bindings.length} Durable Object).`);
