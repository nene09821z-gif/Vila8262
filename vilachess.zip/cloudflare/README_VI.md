# Backend Cloudflare cho ViLa Chess

Backend này phục vụ tài khoản cộng đồng và ghép trận xếp hạng ngẫu nhiên qua **Cloudflare Worker + Durable Object SQLite**. Ứng dụng đã đóng gói sẵn địa chỉ `https://bitter-sun-751a.nene09821z.workers.dev`; người chơi không nhập URL Worker, API key hay mã phòng.

## Cấu hình đã chốt

- Worker name: `bitter-sun-751a`.
- URL app sử dụng: `https://bitter-sun-751a.nene09821z.workers.dev`.
- Gói Free/Pro/Premium: `POST /api/social/me/review-access`, `PATCH /api/social/admin/users/:id/plan`; Worker **không còn cần** thư mục `src/` hay `../../src/`: `wrangler.toml` trỏ `main = "index.js"`, một tệp phẳng đã gộp sẵn.
- Health check: `/api/health` và `/api/social/health`.
- API cộng đồng: `/api/social/*`.
- Kho lưu trữ: Durable Object `ChessState`, mỗi tài khoản/trận/bản ghi lịch sử được lưu thành dòng SQLite riêng.
- Server xác thực phiên đăng nhập, nước đi, lượt đi, đồng hồ, kết quả và Elo. Worker không lưu nguyên cả cơ sở dữ liệu vào một tệp trên hệ thống tệp cục bộ.


## Bảo vệ API và cấu hình origin

Worker áp dụng CORS allowlist; mặc định chỉ cho origin native `https://localhost` / `capacitor://localhost` / `ionic://localhost`. Nếu chạy giao diện web ở domain khác hoặc phát triển bằng Vite trên localhost, vào **Workers & Pages → Worker → Settings → Variables and Secrets**, thêm biến dạng văn bản `CORS_ORIGINS` với các origin chính xác, phân tách bằng dấu phẩy (ví dụ `https://ten-mien-giao-dien.example,http://localhost:5173`). Các origin native mặc định vẫn được giữ. Không đặt giá trị `*`. API không dùng cookie phiên; ứng dụng phải tiếp tục gửi bearer token và không nhúng bí mật quản trị vào client.

Bản hardening thêm security headers, giới hạn đăng nhập theo IP và theo định danh tài khoản (định danh được băm trước khi lưu giới hạn), kiểm tra kích thước JSON, và throttle bổ sung cho proxy. Throttle proxy trong bộ nhớ chỉ là lớp phụ trợ; cần bật thêm Rate Limiting/WAF rules trên Cloudflare cho `/api/lichess/*`, `/api/openings/explorer`, `/api/puzzles/next`, `/api/social/auth/login` và `/api/social/auth/register`. Xem `../docs/guides/SECURITY_HARDENING_V3_68.md` để biết giới hạn và checklist triển khai.

## Triển khai một lần qua giao diện Cloudflare (không cần Termux)

Điều kiện: source có thư mục `cloudflare/` đã được đẩy lên repository GitHub/GitLab. Chỉ triển khai vào Worker `bitter-sun-751a` nếu chắc chắn script cũ của Worker không cần giữ lại; deploy sẽ thay mã Worker đang chạy.

1. Cloudflare Dashboard → **Workers & Pages** → chọn Worker `bitter-sun-751a`.
2. Vào **Settings → Builds → Connect**, rồi kết nối repository chứa source. Cloudflare xác nhận Workers Builds có thể kết nối Worker hiện có với repository và triển khai khi có commit mới: [Cloudflare Workers Builds](https://developers.cloudflare.com/workers/ci-cd/builds/).
3. Chọn đúng repository/branch; đặt **Root directory** là `cloudflare`. Tên Worker ở `cloudflare/wrangler.toml` phải khớp `bitter-sun-751a`.
4. Đặt **Deploy command** thành `npm run deploy`. Nếu form yêu cầu **Build command**, đặt `npm install`; nếu Cloudflare đã tự cài dependencies thì có thể để trống build command.
5. Lưu cấu hình và push/commit source để chạy build. Chỉ coi deploy thành công khi tab Deployments báo thành công.

Nếu chưa có source trên GitHub, cần tải ZIP source app rồi đưa toàn bộ nội dung project lên repository, giữ thư mục `cloudflare/` ngay dưới root. Không upload mật khẩu, token phiên, Cloudflare API token hoặc secret quản trị vào Git.

### Tùy chọn CLI (không dùng khi làm trên điện thoại)

Ở máy tính đã cài Node.js:

```sh
cd cloudflare
npm install
npx wrangler login
npm run deploy
```

Không cần giữ máy tính hoặc điện thoại bật sau khi Worker đã triển khai thành công.

## Lỗi "Không tìm thấy tệp điểm vào" (entry-point) — chỉ cần 3 tệp

Nguyên nhân thường gặp: repo GitHub thiếu thư mục lồng nhau (`cloudflare/src/`, `src/`) vì tải lên từ điện thoại. Cách sửa: trong thư mục **`cloudflare/`** của repo chỉ cần có đúng 3 tệp này (tải từng tệp lên là được):

1. `index.js` — toàn bộ Worker, đã gộp sẵn (193 KB)
2. `wrangler.toml` — có dòng `main = "index.js"`
3. `package.json` — để Cloudflare cài `chess.js` và `wrangler`

Trong Cloudflare → Worker → Settings → Build: **Root directory = `cloudflare`**, Build command để trống hoặc `npm install`, Deploy command `npx wrangler deploy`.

Khi sửa mã nguồn trong `cloudflare/src/` hoặc `src/*.js` dùng chung, chạy `npm run bundle` trong `cloudflare/` để sinh lại `index.js` (test sẽ báo nếu quên).

## Deploy Worker bị lỗi? Tra theo thông báo

Chạy `npm run preflight` trong thư mục `cloudflare` trước: nó kiểm tra `wrangler.toml`, cú pháp, các import `../../src/*` và phiên bản wrangler.

| Thông báo trong log build | Nguyên nhân | Cách sửa |
| --- | --- | --- |
| `Unexpected fields found ... "exports"` hoặc `code: 10074` / thiếu migration cho `ChessState` | wrangler cũ hơn 4.107 không hiểu `[exports.ChessState]` | `package.json` đã đặt `wrangler ^4.107.0`; nếu có `package-lock.json` cũ thì xoá rồi `npm install`, hoặc build lại không dùng cache |
| `Cannot mix migrations and exports` / lỗi về migration tag | Worker đã deploy bằng `[[migrations]]`, file cấu hình lại có cả hai | Chỉ giữ MỘT kiểu: `[exports.ChessState]` (hiện tại) **hoặc** `[[migrations]]` |
| `Không tìm thấy tệp điểm vào` / `entry-point ... not found` | Thiếu `index.js` (hoặc `src/index.js` ở bản cũ) trong repo | Xem mục ngay phía trên: đủ 3 tệp trong `cloudflare/` |
| `Could not resolve "chess.js"` | Chưa chạy `npm install` trong `cloudflare/` | Build command: `npm install`; deploy command: `npx wrangler deploy` |
| `Script startup exceeded CPU time limit` / `code: 10021` | Có lệnh chạy nặng ở cấp module | Chạy `npm run preflight`; không để vòng lặp/khởi tạo nặng ngoài `fetch()` |
| `compatibility_date ... in the future` | Ngày tương lai | Đặt về ngày hôm nay hoặc sớm hơn |

Nếu vẫn lỗi, gửi **đúng dòng báo lỗi đỏ đầu tiên** trong tab *Deployments → Build log* để biết chính xác nguyên nhân.

## Kiểm tra bắt buộc sau khi deploy

1. Mở `https://bitter-sun-751a.nene09821z.workers.dev/api/health`; phải trả JSON có `ok: true`.
2. Mở `https://bitter-sun-751a.nene09821z.workers.dev/api/social/health`; phải trả `status: "online"` và `service: "Cờ Vua ViLa social"`.
3. Kiểm thử trên hai thiết bị và hai mạng riêng: tạo hai tài khoản thử, chọn cùng mốc thời gian, nhấn tìm đối thủ gần nhau; cả hai phải vào cùng trận, màu khác nhau.
4. Kiểm tra nước sai lượt/sai luật bị từ chối, nước hợp lệ cập nhật ở cả hai máy, hủy hàng chờ, đầu hàng, hết giờ, cập nhật Elo một lần và dữ liệu vẫn còn sau khi mở lại app.

## Giới hạn được ghi rõ

- Backend này chưa được triển khai vào tài khoản Cloudflare từ môi trường tạo ZIP, và chưa xác nhận ghép trận giữa hai thiết bị thật. Worker cũ ở trạng thái Active không đồng nghĩa đã chạy mã này.
- Khôi phục mật khẩu qua email trả `503` đến khi chủ dự án cấu hình và kiểm thử một nhà cung cấp email thật; không giả lập gửi email.
- Một Durable Object cộng đồng toàn cục tuần tự hóa hàng chờ, phù hợp thử nghiệm/ra mắt nhỏ; không phải cam kết tải lớn vô hạn.
- Nếu đổi Worker name hoặc subdomain, phải sửa `DEFAULT_BACKEND_URL` trong `src/settings-schema.js`, cập nhật test/docs và build lại app.
