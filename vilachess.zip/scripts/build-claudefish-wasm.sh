#!/usr/bin/env bash
# Builds ClaudeFish 3.x for the browser / Android WebView: public/claudefish/cf-engine.wasm
#
# Needs only clang (>= 15) with the wasm32 target and wasm-ld (Ubuntu: apt install clang lld).
# No emscripten and no WASI SDK: engines/claudefish/wasm/ holds a tiny freestanding libc + std subset.
# The module exports cf_init / cf_newgame / cf_io / cf_iosize / cf_best / cf_depth / cf_nodes / cf_usenn / cf_netbuf /
# cf_loadnet / cf_perft and imports a single host function (wasi_snapshot_preview1.clock_time_get).
#
# Usage: bash scripts/build-claudefish-wasm.sh [output.wasm]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-public/claudefish/cf-engine.wasm}"
CXX="${CXX:-clang++}"
command -v "$CXX" >/dev/null || { echo "clang++ not found (apt install clang lld)" >&2; exit 1; }
command -v wasm-ld >/dev/null || command -v wasm-ld-18 >/dev/null || command -v wasm-ld-17 >/dev/null || command -v wasm-ld-16 >/dev/null || command -v wasm-ld-15 >/dev/null \
  || { echo "wasm-ld not found (apt install lld)" >&2; exit 1; }
RES="$("$CXX" -print-resource-dir)/include"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

COMMON=(--target=wasm32-unknown-unknown -mcpu=mvp -msign-ext -ffreestanding -nostdinc -isystem "$RES"
        -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-stack-protector -DNDEBUG -DCF_WASM -Wno-unused-value)

"$CXX" "${COMMON[@]}" -std=c++17 -O3 -c engines/claudefish/claudefish.cpp -o "$TMP/engine.o"
"$CXX" "${COMMON[@]}" -std=c++17 -O2 -fno-builtin -c engines/claudefish/wasm/cf_libc.cpp -o "$TMP/libc.o"

mkdir -p "$(dirname "$OUT")"
"$CXX" --target=wasm32-unknown-unknown -nostdlib -fuse-ld=lld "$TMP/engine.o" "$TMP/libc.o" -o "$OUT" \
  -Wl,--no-entry -Wl,--gc-sections -Wl,--strip-all -Wl,--stack-first -Wl,-z,stack-size=1048576 \
  -Wl,--initial-memory=25165824 -Wl,--max-memory=268435456 -Wl,--export-memory \
  -Wl,--export=__heap_base
ls -l "$OUT"
