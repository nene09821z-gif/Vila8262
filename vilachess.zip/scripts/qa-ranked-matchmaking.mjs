#!/usr/bin/env node
/**
 * ChessPlus ranked-online QA runner.
 * Simulates two authenticated players against the real REST API (not WebSocket).
 * Requires Node 20+ and the project's chess.js dependency.
 *
 * Required env:
 *   P1_USERNAME, P1_PASSWORD, P2_USERNAME, P2_PASSWORD
 * Optional env:
 *   API_BASE=https://bitter-sun-751a.nene09821z.workers.dev
 *   AUTO_REGISTER=1       Create the accounts if login returns 401.
 *   TARGET_PLIES=50       Number of half-moves (plies), not full move pairs.
 *   MOVE_INTERVAL_MS=1000 Delay after each accepted ply.
 *   TIME_CONTROL=3+0
 *   VERIFY_EVERY=2        Check the other client every N plies (default 2).
 *   CLEANUP=1              Resign with P1 at the end (affects QA-account Elo).
 *
 * Use dedicated test accounts and a staging Worker. Do not run against rated
 * production accounts unless you accept a rated result and Elo changes.
 */
import { randomBytes } from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';
import { Chess } from 'chess.js';

const API_BASE = (process.env.API_BASE || 'https://bitter-sun-751a.nene09821z.workers.dev').replace(/\/$/, '');
const API_ROOT = `${API_BASE}/api/social`;
const TARGET_PLIES = Math.max(1, Math.min(400, Number.parseInt(process.env.TARGET_PLIES || '50', 10) || 50));
const MOVE_INTERVAL_MS = Math.max(0, Math.min(60_000, Number.parseInt(process.env.MOVE_INTERVAL_MS || '1000', 10) || 0));
const TIME_CONTROL = process.env.TIME_CONTROL || '3+0';
const VERIFY_EVERY = Math.max(1, Math.min(20, Number.parseInt(process.env.VERIFY_EVERY || '2', 10) || 2));
const AUTO_REGISTER = process.env.AUTO_REGISTER === '1';
const CLEANUP = process.env.CLEANUP !== '0';
const REQUEST_TIMEOUT_MS = Math.max(2_000, Math.min(60_000, Number(process.env.REQUEST_TIMEOUT_MS) || 15_000));
const timings = [];
let requestCount = 0;
let activeMatchId = '';
let p1 = null;
let p2 = null;
let tokenByColor = null;

function assert(condition, message) {
  if (!condition) throw new Error(message);
}
function percentile(values, p) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.ceil(p * sorted.length) - 1)];
}
function reportMemory() {
  const m = process.memoryUsage();
  return { rssMB: +(m.rss / 1024 / 1024).toFixed(1), heapUsedMB: +(m.heapUsed / 1024 / 1024).toFixed(1) };
}
function makeGeneratedIdentity(label) {
  const suffix = `${Date.now().toString(36)}${randomBytes(3).toString('hex')}`.toLowerCase();
  return {
    username: `qa${label}${suffix}`.slice(0, 24),
    password: `QA-${randomBytes(18).toString('base64url')}-9x`,
    displayName: `QA ${label.toUpperCase()} ${suffix}`.slice(0, 40)
  };
}

async function request(path, { token = '', method = 'GET', body, allowError = false } = {}) {
  const url = `${API_ROOT}${path}`;
  const headers = { Accept: 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const started = performance.now();
  let response;
  try {
    response = await fetch(url, {
      method,
      headers,
      cache: 'no-store',
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS)
    });
  } catch (error) {
    throw new Error(`${method} ${path}: network/timeout error: ${error.message || error}`);
  }
  const rttMs = performance.now() - started;
  requestCount += 1;
  timings.push(rttMs);
  let data;
  try { data = await response.json(); }
  catch { data = { error: `Invalid JSON response (HTTP ${response.status})` }; }
  if (!response.ok && !allowError) {
    const retryAfter = response.headers.get('Retry-After');
    throw new Error(`${method} ${path}: HTTP ${response.status}: ${data?.error || 'unknown error'}${retryAfter ? `; Retry-After=${retryAfter}s` : ''}`);
  }
  return { status: response.status, data, rttMs };
}

async function authenticate(label) {
  let username = process.env[`${label}_USERNAME`]?.trim();
  let password = process.env[`${label}_PASSWORD`];
  let displayName = process.env[`${label}_DISPLAY_NAME`]?.trim();
  let generated = false;

  if ((!username || !password) && AUTO_REGISTER) {
    const fresh = makeGeneratedIdentity(label === 'P1' ? 'one' : 'two');
    username ||= fresh.username;
    password ||= fresh.password;
    displayName ||= fresh.displayName;
    generated = true;
  }
  assert(username && password, `Thiếu ${label}_USERNAME / ${label}_PASSWORD. Hoặc đặt AUTO_REGISTER=1 để tạo tài khoản QA mới.`);

  const login = await request('/auth/login', { method: 'POST', body: { username, password }, allowError: true });
  if (login.status === 200 && login.data?.token) {
    return { label, username, token: login.data.token, created: false };
  }
  if (AUTO_REGISTER && login.status === 401) {
    const created = await request('/auth/register', {
      method: 'POST',
      body: { username, password, displayName: displayName || username, initialElo: 1000 },
      allowError: true
    });
    if (created.status === 201 && created.data?.token) {
      if (generated) {
        console.log(`\nTÀI KHOẢN QA MỚI (${label}) — lưu lại để dùng lần sau:\n  username: ${username}\n  password: ${password}\n`);
      }
      return { label, username, token: created.data.token, created: true };
    }
    throw new Error(`${label}: đăng ký thất bại HTTP ${created.status}: ${created.data?.error || 'unknown error'}`);
  }
  throw new Error(`${label}: đăng nhập thất bại HTTP ${login.status}: ${login.data?.error || 'unknown error'}`);
}

function replayMatch(match) {
  const game = new Chess(match.startFen || undefined);
  for (const item of match.moves || []) {
    const move = game.move({ from: item.from, to: item.to, ...(item.promotion ? { promotion: item.promotion } : {}) });
    assert(move, `Server history contains an illegal move at ply ${(game.history().length || 0) + 1}`);
  }
  assert(game.fen() === match.fen, 'Server FEN does not match replayed server move history.');
  return game;
}

function repetitionKey(fen) {
  return String(fen || '').split(' ').slice(0, 4).join(' ');
}
function chooseNonTerminalMove(game, seenPositions) {
  const candidates = game.moves({ verbose: true });
  const safe = [];
  for (const candidate of candidates) {
    const probe = new Chess(game.fen());
    const played = probe.move({ from: candidate.from, to: candidate.to, ...(candidate.promotion ? { promotion: candidate.promotion } : {}) });
    if (!played || probe.isGameOver()) continue;
    const key = repetitionKey(probe.fen());
    // Avoid creating a threefold repetition in this bounded smoke game.
    if ((seenPositions.get(key) || 0) >= 2) continue;
    safe.push({ from: played.from, to: played.to, promotion: played.promotion || '', san: played.san });
  }
  if (!safe.length) {
    if (!candidates.length) return null;
    const fallback = candidates[Math.floor(Math.random() * candidates.length)];
    return { from: fallback.from, to: fallback.to, promotion: fallback.promotion || '', san: fallback.san };
  }
  return safe[Math.floor(Math.random() * safe.length)];
}

async function waitForSharedMatch() {
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    const [s1, s2] = await Promise.all([
      request('/ranked/status', { token: p1.token }),
      request('/ranked/status', { token: p2.token })
    ]);
    const m1 = s1.data?.match;
    const m2 = s2.data?.match;
    if (m1?.id && m1.id === m2?.id && m1.status === 'active' && m2.status === 'active') {
      assert(m1.color !== m2.color, 'Two clients were assigned the same color.');
      assert(m1.fen === m2.fen, 'Clients received different initial FENs.');
      return { one: m1, two: m2 };
    }
    await sleep(500);
  }
  throw new Error('Hai tài khoản không nhận được cùng một trận trong 30 giây. Kiểm tra Elo và time control.');
}

async function run() {
  console.log('ChessPlus ranked-online QA runner');
  console.log(`API: ${API_BASE}`);
  console.log(`Time control: ${TIME_CONTROL}; target: ${TARGET_PLIES} plies; interval: ${MOVE_INTERVAL_MS} ms`);
  console.log('Transport phát hiện từ source: REST/HTTP polling (không phải Socket.IO/WebSocket).');
  console.log(`Runner memory before: ${JSON.stringify(reportMemory())}`);

  const health = await request('/health');
  assert(health.data?.status === 'online' || health.data?.ok === true, 'Social API health check failed.');

  [p1, p2] = await Promise.all([authenticate('P1'), authenticate('P2')]);
  assert(p1.username !== p2.username, 'P1 and P2 must be different accounts.');
  console.log(`Đăng nhập: ${p1.username} và ${p2.username}`);

  const q1 = await request('/ranked/queue', { token: p1.token, method: 'POST', body: { timeControl: TIME_CONTROL }, allowError: true });
  assert([200, 201, 202].includes(q1.status), `P1 queue failed: HTTP ${q1.status}`);
  const q2 = await request('/ranked/queue', { token: p2.token, method: 'POST', body: { timeControl: TIME_CONTROL }, allowError: true });
  assert([200, 201, 202].includes(q2.status), `P2 queue failed: HTTP ${q2.status}`);
  const joined = await waitForSharedMatch();
  activeMatchId = joined.one.id;
  console.log(`Ghép trận thành công: ${activeMatchId}; P1=${joined.one.color}, P2=${joined.two.color}`);

  const game = replayMatch(joined.one);
  const startFen = joined.one.startFen;
  const playedMoves = [...(joined.one.moves || [])];
  const seenPositions = new Map();
  // Rebuild repetition counts using the authoritative starting position and moves.
  const positionTracker = new Chess(startFen || undefined);
  seenPositions.set(repetitionKey(positionTracker.fen()), 1);
  for (const item of playedMoves) {
    positionTracker.move({ from: item.from, to: item.to, ...(item.promotion ? { promotion: item.promotion } : {}) });
    const key = repetitionKey(positionTracker.fen());
    seenPositions.set(key, (seenPositions.get(key) || 0) + 1);
  }

  const initialPly = playedMoves.length;
  for (let index = initialPly; index < initialPly + TARGET_PLIES; index += 1) {
    assert(!game.isGameOver(), `Game ended naturally after ${index - initialPly} test plies; cannot reach target ${TARGET_PLIES}.`);
    const color = game.turn();
    const mover = color === joined.one.color ? p1 : p2;
    const move = chooseNonTerminalMove(game, seenPositions);
    assert(move, `No legal move available at ply ${index + 1}.`);
    const expectedPly = playedMoves.length;
    const sent = await request(`/ranked/matches/${encodeURIComponent(activeMatchId)}/move`, {
      token: mover.token,
      method: 'POST',
      body: { from: move.from, to: move.to, promotion: move.promotion, expectedPly }
    });
    assert(sent.data?.match?.id === activeMatchId, 'Move response belongs to a different match.');
    assert(sent.data.match.moves?.length === expectedPly + 1, `Server ply mismatch after ${move.san}.`);

    const applied = game.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) });
    assert(applied, `Local chess.js rejected generated move ${move.san}.`);
    playedMoves.push({ from: applied.from, to: applied.to, promotion: applied.promotion || '' });
    assert(game.fen() === sent.data.match.fen, `FEN mismatch after ply ${playedMoves.length}.`);
    const posKey = repetitionKey(game.fen());
    seenPositions.set(posKey, (seenPositions.get(posKey) || 0) + 1);
    assert(sent.data.match.status === 'active' || index === initialPly + TARGET_PLIES - 1, 'Server ended the game earlier than the requested test window.');

    // Verify that the non-moving client can read the accepted server state.
    if ((playedMoves.length - initialPly) % VERIFY_EVERY === 0) {
      const observer = mover === p1 ? p2 : p1;
      const observed = await request('/ranked/status', { token: observer.token });
      assert(observed.data?.match?.id === activeMatchId, 'Opponent status did not return the same match.');
      assert(observed.data.match.fen === sent.data.match.fen, `Opponent observed a different FEN at ply ${playedMoves.length}.`);
      assert(observed.data.match.moves?.length === playedMoves.length, `Opponent observed a different ply count at ply ${playedMoves.length}.`);
    }

    if ((index - initialPly + 1) % 5 === 0 || index === initialPly + TARGET_PLIES - 1) {
      console.log(`Ply ${index - initialPly + 1}/${TARGET_PLIES}: ${applied.san}; RTT ${sent.rttMs.toFixed(0)} ms; FEN parity OK`);
    }
    if (MOVE_INTERVAL_MS > 0 && index < initialPly + TARGET_PLIES - 1) await sleep(MOVE_INTERVAL_MS);
  }

  const finalStatuses = await Promise.all([
    request('/ranked/status', { token: p1.token }),
    request('/ranked/status', { token: p2.token })
  ]);
  assert(finalStatuses[0].data?.match?.id === activeMatchId && finalStatuses[1].data?.match?.id === activeMatchId, 'Final status lost match identity.');
  assert(finalStatuses[0].data.match.fen === finalStatuses[1].data.match.fen, 'Final clients do not agree on FEN.');
  assert(finalStatuses[0].data.match.fen === game.fen(), 'Final server FEN differs from chess.js local position.');
  console.log(`Hoàn tất ${TARGET_PLIES} test plies; final ply=${finalStatuses[0].data.match.moves.length}; FEN đồng nhất ở cả hai client.`);
}

async function cleanup() {
  if (!CLEANUP || !activeMatchId || !p1?.token) return;
  try {
    const status = await request('/ranked/status', { token: p1.token, allowError: true });
    if (status.data?.match?.id === activeMatchId && status.data.match.status === 'active') {
      const result = await request(`/ranked/matches/${encodeURIComponent(activeMatchId)}/resign`, {
        token: p1.token, method: 'POST', body: {}, allowError: true
      });
      console.log(`Cleanup: P1 resign; status=${result.status}. Chỉ dùng tài khoản QA vì Elo có thể thay đổi.`);
    }
  } catch (error) {
    console.error(`Cleanup warning: ${error.message || error}`);
  }
}

try {
  await run();
  console.log('\nKẾT QUẢ: PASS — matchmaking, legal moves, expectedPly, FEN parity và status của đối thủ đã được kiểm tra.');
} catch (error) {
  console.error(`\nKẾT QUẢ: FAIL — ${error.stack || error.message || error}`);
  process.exitCode = 1;
} finally {
  await cleanup();
  const sorted = timings;
  console.log('\n--- Metrics ---');
  console.log(JSON.stringify({
    requests: requestCount,
    latencyMs: {
      average: sorted.length ? +(sorted.reduce((sum, value) => sum + value, 0) / sorted.length).toFixed(1) : 0,
      p50: +percentile(sorted, 0.50).toFixed(1),
      p95: +percentile(sorted, 0.95).toFixed(1),
      max: sorted.length ? +Math.max(...sorted).toFixed(1) : 0
    },
    runnerMemory: reportMemory(),
    matchId: activeMatchId || null
  }, null, 2));
  if (activeMatchId && !CLEANUP) console.warn('CẢNH BÁO: trận QA vẫn active; nếu không tiếp tục, presence timeout 90 giây có thể xử thua một bên.');
  console.warn('Lưu ý: runnerMemory chỉ đo tiến trình Node giả lập; không phải RAM của Cloudflare Worker/Durable Object.');
}
