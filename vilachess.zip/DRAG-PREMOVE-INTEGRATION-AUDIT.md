# Drag & Premove integration audit

## Decision: preserve the original implementation; do not overlay the supplied modules

The original v3.69.2 project already contains a more deeply integrated drag/premove system than
`chessplus-drag-premove.zip`. The supplied `DragController`, `PremoveManager`, `animate.js`, and
`board.css` are standalone modules and their documented `main.js` wiring does not match this
project's state, event, rendering, clock, promotion, annotation, and online-game architecture.

Blindly copying them would create competing pointer handlers and premove queues, or bypass existing
game-state and network paths. In particular, the original implementation already has:

- delegated board input and explicit tap fallback for Android WebView;
- pointer capture, cached geometry/legal moves, pointer-event coalescing with `requestAnimationFrame`,
  transform-based ghost movement, and center-based drop hit-testing;
- cancellation on pointer loss, blur, backgrounding, orientation and viewport changes;
- stale-position protection using game epoch + FEN before applying a drag;
- integrated promotion choice, capture/castling rendering, offline disconnect guard and move animation;
- a five-move virtual premove queue, legal revalidation against the real position, queue cancellation,
  click/right-click/Esc cancellation, arrows/chips, and the existing clock penalty;
- performance-tier-aware drag effects and haptics.

## Merge applied

No existing production source file or feature was replaced or deleted. The incompatible standalone
modules and their CSS were intentionally not copied. This avoids duplicate controllers, duplicate
premove state, selector/style collisions, and bypassing the original `playMove()` / `onMoveComplete()`
pipeline.

A regression test was added to `tests/drag-premove-merge.test.js` and included in `test:static`.
It asserts the original integrated pathways remain present and that the standalone competing
controller is not accidentally introduced.

## Validation

- `node --check src/main.js`: expected to pass.
- `node --test tests/drag-premove-merge.test.js`: expected to pass.
- Full production build and Android device smoothness are not claimed as verified by this merge.
