/**
 * Shared interaction helpers for ranked and puzzle boards.
 *
 * Pointer movement is deliberately DOM-only: it writes one transform per animation frame and
 * never re-renders the board or changes application state. The main play board has its own delegated
 * handler in main.js; this module keeps secondary boards on the same low-cost drag behaviour.
 */
import { slideDurationMs, SLIDE_EASING, slideKeyframes } from './board-motion.js';
import {
  ghostTransform, ghostTransformAtOffset, landPieceFromPoint, returnGhost,
  animatePiecePickup, animateCapturedPiece
} from './board-drag-fx.js';
import { deviceTier } from './device-tier.js';
import { hapticLight, hapticHeavy } from './haptics.js';

const FILES_W = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

/** Square under a viewport point, honouring board orientation. '' when outside the board. */
export function squareAtPoint(clientX, clientY, rect, orientation = 'w') {
  if (!rect?.width || !rect?.height || clientX < rect.left || clientY < rect.top || clientX >= rect.right || clientY >= rect.bottom) return '';
  const col = Math.max(0, Math.min(7, Math.floor((clientX - rect.left) / rect.width * 8)));
  const row = Math.max(0, Math.min(7, Math.floor((clientY - rect.top) / rect.height * 8)));
  const white = orientation !== 'b';
  const file = white ? FILES_W[col] : FILES_W[7 - col];
  const rank = white ? 8 - row : row + 1;
  return `${file}${rank}`;
}

function cellOf(board, attr, square) {
  return square ? board.querySelector(`[${attr}="${square}"]`) : null;
}

/** Slide the piece now standing on `to` from the cell it came from. Castling passes `extra` for the rook. */
export function slideBoardPiece(board, attr, slide) {
  if (!board || !slide || !slide.from || !slide.to) return;
  if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) return;
  for (const part of [slide, slide.extra]) {
    if (!part?.from || !part?.to) continue;
    const fromCell = cellOf(board, attr, part.from);
    const toCell = cellOf(board, attr, part.to);
    const piece = toCell?.querySelector('.piece');
    if (!fromCell || !toCell || !piece || typeof piece.animate !== 'function') continue;
    const a = fromCell.getBoundingClientRect();
    const b = toCell.getBoundingClientRect();
    const dx = a.left - b.left;
    const dy = a.top - b.top;
    if (!dx && !dy) continue;
    toCell.classList.add('sliding');
    piece.classList.add('is-sliding');
    const quality = document.documentElement?.dataset?.quality || 'high';
    const duration = quality === 'low' ? 100 : quality === 'medium' ? 120 : slideDurationMs(dx, dy, { min: 150, max: 260, base: 140 });
    const easing = quality === 'low' ? 'cubic-bezier(0,0,0.2,1)' : SLIDE_EASING;
    const animation = piece.animate(slideKeyframes(dx, dy), { duration, easing, fill: 'none' });
    const done = () => { toCell.classList.remove('sliding'); piece.classList.remove('is-sliding'); };
    animation.addEventListener('finish', done, { once: true });
    animation.addEventListener('cancel', done, { once: true });
  }
}

/** Slide descriptor for a chess.js verbose move (adds the rook for castling). */
export function slideFromMove(move) {
  if (!move?.from || !move?.to) return null;
  const slide = { from: move.from, to: move.to, extra: null };
  const flags = String(move.flags || '');
  if (/[kq]/.test(flags)) {
    const rank = move.to[1];
    const kingSide = flags.includes('k');
    slide.extra = { from: `${kingSide ? 'h' : 'a'}${rank}`, to: `${kingSide ? 'f' : 'd'}${rank}` };
  }
  return slide;
}

/**
 * Tap-to-select + drag-and-drop on a delegated board element (survives innerHTML rebuilds).
 * cfg: attr, orientation(), getPiece(), canDrag(), getLegal(), onTap(), onDrop(), pieceMarkup(),
 *      optional onDragStart()/onDragEnd()/onSound(). `onDrop` is the only place game logic is invoked.
 */
export function attachBoardDrag(board, cfg) {
  if (!board || board.dataset.dragAttached === 'true') return () => {};
  board.dataset.dragAttached = 'true';
  const { attr } = cfg;
  const win = board.ownerDocument?.defaultView || (typeof window !== 'undefined' ? window : null);
  const doc = board.ownerDocument || (typeof document !== 'undefined' ? document : null);
  const raf = win?.requestAnimationFrame?.bind(win) || (callback => setTimeout(() => callback(Date.now()), 16));
  const caf = win?.cancelAnimationFrame?.bind(win) || clearTimeout;
  let drag = null;
  let ghost = null;
  let frame = 0;
  let latest = null;
  let disposed = false;

  const clearHover = () => {
    board.querySelectorAll('.drag-over,.drag-source').forEach(node => node.classList.remove('drag-over', 'drag-source'));
  };
  const restoreSource = state => {
    if (!state?.sourcePiece) return;
    state.sourcePiece.style.opacity = state.sourceOpacity;
    state.sourcePiece.classList.remove('is-dragging');
    state.sourcePiece.style.willChange = state.sourceWillChange;
  };
  const removeGhost = () => {
    if (frame) { caf(frame); frame = 0; }
    ghost?.remove();
    ghost = null;
    doc?.body?.classList.remove('board-dragging');
  };
  const onPointerDown = event => {
    if (disposed || (event.pointerType === 'mouse' && event.button !== 0)) return;
    const cell = event.target?.closest?.(`[${attr}]`);
    if (!cell || !board.contains(cell)) return;
    // Capture at the beginning of pointerdown so Android WebView preserves the drag stream off-board.
    try { board.setPointerCapture(event.pointerId); } catch { /* Virtual/synthetic pointers may not be capturable. */ }
    const from = cell.getAttribute(attr);
    const piece = cfg.getPiece?.(from) || null;
    const draggable = Boolean(piece && cfg.canDrag?.(piece, from));
    const cellRect = cell.getBoundingClientRect();
    const boardRect = board.getBoundingClientRect();
    const sourcePiece = cell.querySelector('.piece');

    // Pre-compute legal moves on pointerdown, never inside pointermove. chess.js work is bounded to
    // one selected square and keeps repeated move generation out of the frame-critical path.
    let moves = [];
    if (draggable) {
      try { moves = cfg.getLegal?.(from) || []; } catch { moves = []; }
    }
    drag = {
      pointerId: event.pointerId,
      from,
      piece,
      draggable: draggable && moves.length > 0,
      moves,
      x: event.clientX,
      y: event.clientY,
      offsetX: Math.max(0, Math.min(cellRect.width, event.clientX - cellRect.left)),
      offsetY: Math.max(0, Math.min(cellRect.height, event.clientY - cellRect.top)),
      sourcePiece,
      sourceOpacity: sourcePiece?.style.opacity || '',
      sourceWillChange: sourcePiece?.style.willChange || '',
      cellRect,
      boardRect,
      moved: false,
      hover: '',
      pointerType: event.pointerType || 'touch'
    };
    if (event.pointerType === 'mouse') event.preventDefault?.();
  };

  const onPointerMove = event => {
    const state = drag;
    if (!state || state.pointerId !== event.pointerId || !state.draggable) return;
    if (!state.moved) {
      const threshold = event.pointerType === 'mouse' ? 3 : 5;
      if (Math.hypot(event.clientX - state.x, event.clientY - state.y) < threshold) return;
      state.moved = true;
      // Selection/highlights are updated once at drag start; the original square remains a dim ghost
      // only on tiers with enough GPU budget. LOW hides it and avoids duplicate piece paint.
      cfg.onDragStart?.(state.from, state.moves);
      const sourceCell = cellOf(board, attr, state.from);
      sourceCell?.classList.add('drag-source');
      state.sourcePiece = sourceCell?.querySelector('.piece') || state.sourcePiece;
      if (state.sourcePiece) {
        state.sourceWillChange = state.sourcePiece.style.willChange;
        state.sourceOpacity = state.sourcePiece.style.opacity;
        state.sourcePiece.classList.add('is-dragging');
        state.sourcePiece.style.opacity = deviceTier.useGhost ? '.3' : '0';
        state.sourcePiece.style.willChange = 'opacity';
      }

      const size = state.boardRect.width / 8;
      ghost = doc.createElement('span');
      ghost.className = `drag-ghost dragging piece ${state.piece.color === 'w' ? 'white-piece' : 'black-piece'}`;
      ghost.innerHTML = typeof cfg.pieceMarkup === 'function' ? cfg.pieceMarkup(state.piece) : '';
      const initialTransform = Number.isFinite(size) && size > 0
        ? ghostTransformAtOffset(event.clientX, event.clientY, state.offsetX, state.offsetY, size)
        : ghostTransform(event.clientX, event.clientY, state.pointerType);
      ghost.style.cssText = `position:fixed;left:0;top:0;z-index:999;pointer-events:none;width:${size.toFixed(2)}px;height:${size.toFixed(2)}px;will-change:transform;transform:${initialTransform}`;
      // The child SVG supplies a silhouette drop-shadow; keep the overlay wrapper transparent.
      doc.body.appendChild(ghost);
      doc.body.classList.add('board-dragging');
      // WAAPI changes only the scale compositor property; LOW skips it entirely.
      animatePiecePickup(ghost, deviceTier.tier);
      if (deviceTier.useHaptic && cfg.hapticsEnabled?.() !== false) void hapticLight();
      cfg.onSound?.('pickup');
    }

    event.preventDefault?.();
    latest = { x: event.clientX, y: event.clientY };
    // One transform + one hover calculation per display frame; pointermove never reads layout or
    // calls game/state callbacks, which is the main protection against low-end WebView frame drops.
    if (!frame) frame = raf(() => {
      frame = 0;
      const current = drag;
      const point = latest;
      if (!current?.moved || !ghost || !point) return;
      const size = current.boardRect.width / 8;
      ghost.style.transform = ghostTransformAtOffset(point.x, point.y, current.offsetX, current.offsetY, size);
      const centerX = point.x + size / 2 - current.offsetX;
      const centerY = point.y + size / 2 - current.offsetY;
      const hover = squareAtPoint(centerX, centerY, current.boardRect, cfg.orientation?.() || 'w');
      if (hover !== current.hover) {
        if (current.hover) cellOf(board, attr, current.hover)?.classList.remove('drag-over');
        current.hover = hover;
        if (hover && current.moves.some(move => move.to === hover)) cellOf(board, attr, hover)?.classList.add('drag-over');
      }
    });
  };

  const finish = event => {
    const state = drag;
    if (!state || state.pointerId !== event.pointerId) return;
    drag = null;
    const releasedGhost = ghost;
    ghost = null;
    if (frame) { caf(frame); frame = 0; }
    doc?.body?.classList.remove('board-dragging');
    board.querySelectorAll('.drag-over').forEach(node => node.classList.remove('drag-over'));

    const dispose = () => { releasedGhost?.remove(); restoreSource(state); clearHover(); };
    if (event.type === 'pointercancel' || event.type === 'lostpointercapture') {
      const home = cellOf(board, attr, state.from)?.getBoundingClientRect();
      const done = () => { dispose(); if (state.moved) cfg.onDragEnd?.(); };
      if (state.moved && releasedGhost && home) returnGhost(releasedGhost, home, { offsetMode: true, onDone: done });
      else done();
      return;
    }

    if (!state.moved) {
      dispose();
      const upCell = squareAtPoint(event.clientX, event.clientY, state.boardRect, cfg.orientation?.() || 'w') || state.from;
      cfg.onTap?.(upCell);
      return;
    }

    const size = state.boardRect.width / 8;
    const center = {
      x: event.clientX + size / 2 - state.offsetX,
      y: event.clientY + size / 2 - state.offsetY
    };
    const target = squareAtPoint(center.x, center.y, state.boardRect, cfg.orientation?.() || 'w');
    const matching = target ? state.moves.filter(move => move.to === target) : [];
    if (matching.length) {
      dispose();
      if (deviceTier.useHaptic && cfg.hapticsEnabled?.() !== false) void hapticLight();
      cfg.onSound?.(matching.some(move => move.captured) ? 'capture' : 'move');
      // Game logic is invoked only at release; the actual board remains owned by the existing caller.
      cfg.onDrop?.(state.from, target, matching);
      // The supplied point is the visible piece centre, so use a centred landing offset (mouse mode).
      landPieceFromPoint(() => cellOf(board, attr, target), center, { pointerType: 'mouse' });
    } else {
      if (deviceTier.useHaptic && cfg.hapticsEnabled?.() !== false) void hapticHeavy();
      cfg.onSound?.('error');
      const home = cellOf(board, attr, state.from)?.getBoundingClientRect();
      const restore = () => { dispose(); cfg.onDragEnd?.(); cfg.onTap?.(state.from); };
      if (home && releasedGhost) returnGhost(releasedGhost, home, { offsetMode: true, onDone: restore });
      else restore();
    }
  };

  const cancelForLifecycle = () => {
    const state = drag;
    if (!state) return;
    drag = null;
    const releasedGhost = ghost;
    ghost = null;
    if (frame) { caf(frame); frame = 0; }
    doc?.body?.classList.remove('board-dragging');
    const home = cellOf(board, attr, state.from)?.getBoundingClientRect();
    const done = () => { releasedGhost?.remove(); restoreSource(state); clearHover(); if (state.moved) cfg.onDragEnd?.(); };
    if (releasedGhost && home && state.moved && doc?.visibilityState !== 'hidden') {
      returnGhost(releasedGhost, home, { offsetMode: true, onDone: done });
    } else done();
  };

  const onKeyClick = event => {
    if (event.detail !== 0) return;
    const cell = event.target?.closest?.(`[${attr}]`);
    if (cell && board.contains(cell)) cfg.onTap?.(cell.getAttribute(attr));
  };
  const onVisibility = () => { if (doc?.hidden) cancelForLifecycle(); };
  const onOrientation = () => cancelForLifecycle();

  board.addEventListener('pointerdown', onPointerDown, { passive: false });
  board.addEventListener('pointermove', onPointerMove, { passive: false });
  board.addEventListener('pointerup', finish, { passive: false });
  board.addEventListener('pointercancel', finish, { passive: true });
  board.addEventListener('lostpointercapture', finish, { passive: true });
  board.addEventListener('click', onKeyClick);
  doc?.addEventListener('visibilitychange', onVisibility, { passive: true });
  win?.addEventListener('orientationchange', onOrientation, { passive: true });
  win?.addEventListener('blur', cancelForLifecycle, { passive: true });

  // Returning a disposer supports remounts/navigation without stacking duplicate listeners.
  return () => {
    if (disposed) return;
    disposed = true;
    cancelForLifecycle();
    board.removeEventListener('pointerdown', onPointerDown);
    board.removeEventListener('pointermove', onPointerMove);
    board.removeEventListener('pointerup', finish);
    board.removeEventListener('pointercancel', finish);
    board.removeEventListener('lostpointercapture', finish);
    board.removeEventListener('click', onKeyClick);
    doc?.removeEventListener('visibilitychange', onVisibility);
    win?.removeEventListener('orientationchange', onOrientation);
    win?.removeEventListener('blur', cancelForLifecycle);
    delete board.dataset.dragAttached;
  };
}

// Re-exported for optional callers animating capture targets without changing chess.js ownership.
export { animateCapturedPiece };
