/**
 * Drag & drop feel for every board (practice, ranked, puzzles).
 *
 * - Pointer movement is coalesced to one transform write per animation frame.
 * - Touch lifts the piece above the fingertip; a mouse keeps it centred under the cursor.
 * - After a drop the real piece "lands" from where the ghost was released (short FLIP animation)
 *   instead of teleporting to the middle of the square.
 * - A rejected drop glides the ghost back to its origin square.
 *
 * Pure geometry helpers are exported separately so they can be unit-tested in Node.
 */

export const DRAG_SCALE = 1.15;
/** Fraction of the piece height placed ABOVE the pointer. 0.5 = centred, 0.62 = lifted. */
export const LIFT_TOUCH = 0.62;
export const LIFT_MOUSE = 0.5;
export const LAND_EASING = 'cubic-bezier(0.2, 0.9, 0.25, 1)';
const LOW_EASING = 'cubic-bezier(0, 0, 0.2, 1)';
const SNAP_EASING = 'cubic-bezier(0.25, 0.1, 0.25, 1)';

function currentQuality() {
  try { return document.documentElement?.dataset?.quality || 'high'; } catch { return 'high'; }
}

export function liftFor(pointerType) {
  return pointerType === 'mouse' ? LIFT_MOUSE : LIFT_TOUCH;
}

/** CSS transform that centres a ghost horizontally on the pointer and lifts it vertically. */
export function ghostTransform(x, y, pointerType = 'touch', scale, quality = currentQuality()) {
  // LOW keeps the dragged sprite at its natural size; this avoids a second compositing scale operation.
  const resolvedScale = quality === 'low' ? 1 : Number.isFinite(scale) ? scale : quality === 'medium' ? 1.1 : DRAG_SCALE;
  const lift = liftFor(pointerType) * 100;
  return `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) translate(-50%,-${lift}%) scale(${resolvedScale})`;
}


/**
 * Position a square-sized ghost while preserving the exact point inside the source square where
 * the finger landed. This prevents the familiar jump-to-centre effect on Android touch screens.
 */
export function ghostTransformAtOffset(x, y, offsetX, offsetY, size, quality = currentQuality()) {
  const maxOffset = Math.max(0, Number(size) || 0);
  const dx = Math.min(maxOffset, Math.max(0, Number(offsetX) || 0));
  const dy = Math.min(maxOffset, Math.max(0, Number(offsetY) || 0));
  return `translate3d(${(x - dx).toFixed(1)}px,${(y - dy).toFixed(1)}px,0)`;
}

/** Start a short compositor-friendly pickup animation without animating layout properties. */
export function animatePiecePickup(element, quality = currentQuality()) {
  if (!element || quality === 'low' || reducedMotion() || typeof element.animate !== 'function') return null;
  const target = quality === 'medium' ? 1.1 : 1.15;
  return element.animate([{ scale: 1 }, { scale: String(target) }], {
    duration: 80,
    easing: 'cubic-bezier(0.2, 0.9, 0.25, 1)',
    fill: 'forwards'
  });
}

/** Capture fade helper; caller owns the board repaint and removal of the captured DOM node. */
export function animateCapturedPiece(piece, { duration = 120 } = {}) {
  if (!piece || reducedMotion() || typeof piece.animate !== 'function') return null;
  return piece.animate(
    [{ opacity: 1, scale: 1 }, { opacity: 0, scale: 0.8 }],
    { duration, easing: SNAP_EASING, fill: 'forwards' }
  );
}

/** Viewport centre of a ghost of `size` px whose pointer is at (x, y). */
export function ghostCenter(x, y, size, pointerType = 'touch') {
  return { x, y: y + (0.5 - liftFor(pointerType)) * size };
}

/** Offset (dx, dy) that moves a piece resting in `rect` back to a viewport point. */
export function offsetFromPoint(rect, point) {
  if (!rect || !point) return { dx: 0, dy: 0 };
  return { dx: point.x - (rect.left + rect.width / 2), dy: point.y - (rect.top + rect.height / 2) };
}

/** Landing duration: tiny when the piece is dropped almost on the square, a bit longer when far. */
export function landDurationMs(dx, dy, size = 48) {
  const dist = Math.hypot(dx, dy);
  const rel = size > 0 ? dist / size : 0;
  return Math.round(Math.min(170, Math.max(90, 90 + rel * 38)));
}

function reducedMotion() {
  return typeof window !== 'undefined' && Boolean(window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches);
}

/**
 * Animate the piece standing in `cell` from the viewport point where the ghost was released.
 * `getCell` is re-evaluated for up to `tries` animation frames because some boards repaint
 * asynchronously after a drop (ranked boards wait for the server, puzzles wait for validation).
 */
export function landPieceFromPoint(getCell, point, { pointerType = 'touch', tries = 4, onStart } = {}) {
  if (!point || reducedMotion() || typeof requestAnimationFrame !== 'function') return;
  const attempt = left => {
    const cell = getCell();
    const piece = cell?.querySelector?.('.piece');
    if (!cell || !piece || typeof piece.animate !== 'function') {
      if (left > 0) requestAnimationFrame(() => attempt(left - 1));
      return;
    }
    if (piece.dataset.landed === '1') return;
    const rect = cell.getBoundingClientRect();
    if (!rect.width) return;
    const center = ghostCenter(point.x, point.y, rect.width, pointerType);
    const { dx, dy } = offsetFromPoint(rect, center);
    piece.dataset.landed = '1';
    if (Math.abs(dx) < 1.5 && Math.abs(dy) < 1.5) return;
    const quality = currentQuality();
    const low = quality === 'low';
    const duration = low ? 100 : quality === 'medium' ? 120 : 150;
    cell.classList.add('sliding');
    piece.classList.add('is-landing');
    onStart?.(cell, piece);
    const from = low
      ? { translate: `${dx.toFixed(1)}px ${dy.toFixed(1)}px` }
      : { translate: `${dx.toFixed(1)}px ${dy.toFixed(1)}px`, scale: quality === 'medium' ? '1.04' : String(DRAG_SCALE) };
    const to = low ? { translate: '0px 0px' } : { translate: '0px 0px', scale: '1' };
    const animation = piece.animate([from, to], { duration, easing: low ? LOW_EASING : LAND_EASING, fill: 'none' });
    const done = () => { cell.classList.remove('sliding'); piece.classList.remove('is-landing'); delete piece.dataset.landed; };
    animation.addEventListener('finish', done);
    animation.addEventListener('cancel', done);
  };
  attempt(tries);
}

/** Glide a ghost back to the centre of `targetRect`, then remove it. */
export function returnGhost(ghost, targetRect, { pointerType = 'touch', offsetLeft = 0, offsetTop = 0, offsetMode = false, onDone } = {}) {
  const finish = () => { ghost?.remove(); onDone?.(); };
  if (!ghost || !targetRect || reducedMotion() || typeof ghost.animate !== 'function') { finish(); return; }
  const size = targetRect.width;
  const cx = targetRect.left + size / 2 - offsetLeft;
  const cy = targetRect.top + size / 2 - offsetTop;
  const lift = liftFor(pointerType);
  const from = ghost.style.transform;
  // Fixed body-level ghosts use top-left positioning; the legacy main-board ghost retains its
  // finger-centred transform so existing local-coordinate callers remain backwards compatible.
  const to = offsetMode
    ? `translate3d(${(targetRect.left - offsetLeft).toFixed(1)}px,${(targetRect.top - offsetTop).toFixed(1)}px,0) scale(1)`
    : `translate3d(${cx.toFixed(1)}px,${(cy + (lift - 0.5) * size).toFixed(1)}px,0) translate(-50%,-${(lift * 100).toFixed(0)}%) scale(1)`;
  const quality = currentQuality();
  const duration = quality === 'low' ? 150 : quality === 'medium' ? 180 : 200;
  const animation = ghost.animate([{ transform: from }, { transform: to }], { duration, easing: quality === 'low' ? LOW_EASING : LAND_EASING, fill: 'forwards' });
  animation.addEventListener('finish', finish);
  animation.addEventListener('cancel', finish);
}
