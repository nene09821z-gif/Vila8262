# ChessPlus Cloud-Eval Review modules

Bộ module độc lập:

- `lichess-api.js`: hàng đợi request Cloud Eval, timeout, cache, 404 và 429.
- `chess-math.js`: xác suất thắng, phân loại nước đi, ACPL proxy.
- `review-renderer.js`: SVG arrow theo rect thực tế của từng ô, banner và danh sách nước.
- `review-controller.js`: dựng FEN timeline, phân tích tuần tự, progress, globalAnalysisData và điều hướng.

## Lưu ý quan trọng trước khi tích hợp

1. Lichess Cloud Eval là **cache lookup**, không phải engine chạy phân tích mọi FEN. Vị trí chưa có trong dữ liệu trả 404. Cần cấu hình `fallbackEval` dùng Stockfish local/analysis-server nếu muốn mọi nước đều có đánh giá.
2. Tài liệu API Lichess yêu cầu chỉ chạy một request tại một thời điểm và chờ đủ một phút sau HTTP 429. Vì vậy code retry một lần sau 60 giây, không retry sau 3 giây.
3. `cp` và `mate` của Cloud Eval là từ góc nhìn Trắng. Controller đổi dấu/xác suất cho Đen trước khi phân loại.
4. Chess.com không công bố công thức chính xác CAPS2. `calculateAccuracy(acpl)` trong gói là proxy minh bạch theo ACPL, không được gọi là điểm CAPS2 chính thức. Controller ưu tiên `computeWinPercentAccuracy(rows)` sẵn có trong `src/game-review.js` khi có đủ điểm CP từ các thế cờ kề nhau; nếu thiếu dữ liệu CP (ví dụ chỉ có mate score/cache miss), controller mới dùng ACPL proxy khi tính được.
5. `!!` chỉ được gắn khi caller xác nhận `isSacrifice` bằng dữ liệu vật chất/PV. Chỉ đi trùng bestMove không đủ để kết luận Brilliant.
6. Overlay SVG được đặt `position:absolute`, nên không trở thành ô thứ 65 của CSS Grid. `drawArrow()` lấy tâm mỗi ô từ `getBoundingClientRect()`, do đó hỗ trợ cả bàn đảo màu nếu thứ tự DOM đã được đảo đúng.

## Cấu trúc entrypoint trong source hiện tại

Không có root `index.js` làm entrypoint. `index.html` đang nạp `./src/main.js`:

```html
<script type="module" src="./src/main.js"></script>
```

Source hiện tại đã có Game Review chạy Stockfish: `startFullGameReview()` trong `src/main.js`, `game-review.js`, `review-arrows.js`, `review-screen.js`. **Không gắn handler Cloud Eval thứ hai lên `#reviewGameBtn`**, vì nút đó đã được dùng. Hãy dùng nút riêng `#reviewCloudEvalBtn` hoặc tích hợp Cloud Eval vào luồng review đang có.

## Gắn vào `src/main.js` (chế độ riêng, không đụng flow Stockfish)

Thêm import:

```js
import {
  configureReviewController,
  startGameReview as startCloudGameReview,
  navigateToStep as navigateCloudReviewToStep,
  stopGameReview as stopCloudGameReview
} from './services/review-controller.js';
```

Khi màn review đã được render, cấu hình selector và callback để app tự render FEN bằng renderer hiện có:

```js
configureReviewController({
  boardSelector: '#reviewReplayBoard',
  moveListSelector: '#reviewMoveAnalysis',
  bannerSelector: '#reviewBanner',
  progressSelector: '#reviewProgress',
  // Reuse the app's own renderer so the selected SVG piece set is preserved.
  renderPosition: (fen, ply, position) => {
    const board = $('#reviewReplayBoard');
    if (!board) return;
    const lastMove = ply > 0 ? { from: position.from, to: position.to } : null;
    board.innerHTML = renderReplayBoardMarkup(fen, lastMove);
    board.dataset.reviewPly = String(ply);
  },
  // Open the app's replay view after all positions have been processed.
  onComplete: () => setReviewScreen('replay', 0),
  // Optional: return { cp, mate, bestMove, depth, pv, source:'stockfish-fallback' }.
  // Scores MUST use White's point of view, matching Lichess Cloud Eval.
  fallbackEval: null
});
```

Gắn một nút riêng vào markup của màn review (không dùng lại `reviewGameBtn`):

```html
<button type="button" id="reviewCloudEvalBtn">Thử phân tích bằng Lichess Cloud</button>
```

Sau đó wire nút bên trong `wireReviewActions()` của `src/main.js` (hàm này được gọi sau mỗi lần dựng màn review):

```js
$('#reviewCloudEvalBtn')?.addEventListener('click', async event => {
  const button = event.currentTarget;
  button.disabled = true;
  try {
    const result = await startCloudGameReview(game.history({ verbose: true }), {
      startFen: gameStartFen
    });
    if (result.status !== 'OK') toast(`Cloud Review: ${result.error || result.status}`);
  } finally {
    button.disabled = false;
  }
});
```

Có thể điều hướng khi người dùng nhấn nút bước riêng:

```js
navigateCloudReviewToStep(12); // 12 nửa nước
stopCloudGameReview();         // hủy phân tích đang chạy
```

Với `renderPosition: (_fen, ply) => setReviewReplayPly(ply)`, app hiện tại sẽ dùng renderer bàn cờ/ảnh quân cờ hiện hữu. Nếu chạy độc lập không cấu hình callback, controller có renderer Unicode dự phòng; renderer đó không nhằm thay thế bộ quân SVG thương mại của ChessPlus.

## Chạy test

```bash
node --test tests/lichess-review-modules.test.js
```

Để kiểm tra Vite build trên project đầy đủ:

```bash
npm ci
npm run build
```
