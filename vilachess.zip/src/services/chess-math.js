/** Pure scoring helpers for ChessPlus review. All win-probability values are 0..100. */

const WIN_CURVE_K = 0.00368208;
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

/**
 * Convert a centipawn or mate evaluation to expected win probability for White.
 *
 * Lichess' logistic curve:
 *   50 + 50 * (2 / (1 + exp(-k * cp)) - 1)
 *
 * Math.exp(x) computes e^x. As cp becomes strongly positive, the exponent tends
 * toward zero and the result approaches 100; strongly negative cp approaches 0.
 * Lichess Cloud Eval supplies cp/mate from White's point of view, so callers must
 * invert the resulting probability for Black when scoring Black's move.
 */
export function calculateWinProbability(cp, mate = null) {
  if (mate != null && Number.isFinite(Number(mate))) {
    const mateIn = Number(mate);
    if (mateIn > 0) return 100;
    if (mateIn < 0) return 0;
    // A mate value of zero is ambiguous for generic callers; do not invent a winner.
    return 50;
  }

  if (cp == null || cp === '') return null;
  const score = Number(cp);
  if (!Number.isFinite(score)) return null;
  // Clamp to avoid needless extreme exponent values while preserving the curve's useful range.
  const safeCp = clamp(score, -10000, 10000);
  const expValue = Math.exp(-WIN_CURVE_K * safeCp);
  const probability = 50 + 50 * (2 / (1 + expValue) - 1);
  return clamp(probability, 0, 100);
}

const MOVE_LABELS = Object.freeze({
  brilliant: { label: 'XUẤT SẮC', color: '#81b64c', icon: '!!' },
  good: { label: 'TỐT', color: '#81b64c', icon: '✓' },
  inaccuracy: { label: 'KHÔNG CHÍNH XÁC', color: '#e6b94a', icon: '?!' },
  mistake: { label: 'SAI LẦM', color: '#e58a36', icon: '?' },
  blunder: { label: 'TỒI', color: '#d94b4b', icon: '??' },
  unrated: { label: 'CHƯA ĐÁNH GIÁ', color: '#8993a5', icon: '—' }
});

/**
 * Classify one move using win probability from the mover's perspective.
 *
 * @param {number} epBefore Win probability of the mover before the move (0..100).
 * @param {number} epAfter Win probability of the same mover after the move (0..100).
 * @param {boolean} isBestMove Whether the played UCI move equals the cloud best move.
 * @param {{isSacrifice?:boolean}} [context] Must be confirmed by material/PV analysis.
 */
export function classifyMove(epBefore, epAfter, isBestMove = false, context = {}) {
  const before = epBefore == null || epBefore === '' ? NaN : Number(epBefore);
  const after = epAfter == null || epAfter === '' ? NaN : Number(epAfter);
  if (!Number.isFinite(before) || !Number.isFinite(after)) {
    return { key: 'unrated', ...MOVE_LABELS.unrated, loss: null, isBestMove: Boolean(isBestMove) };
  }

  const safeBefore = clamp(before, 0, 100);
  const safeAfter = clamp(after, 0, 100);
  const loss = Math.max(0, safeBefore - safeAfter);
  const isSacrifice = context?.isSacrifice === true;

  // A best move is not automatically brilliant. The sacrifice flag must come from
  // a material/PV check (for example detectSacrifice() in review-brilliance.js).
  if (isBestMove === true && isSacrifice && safeAfter >= 50) {
    return { key: 'brilliant', ...MOVE_LABELS.brilliant, loss, isBestMove: true, isSacrifice: true };
  }

  if (loss <= 2) return { key: 'good', ...MOVE_LABELS.good, loss, isBestMove: Boolean(isBestMove), isSacrifice };
  if (loss <= 7) return { key: 'inaccuracy', ...MOVE_LABELS.inaccuracy, loss, isBestMove: Boolean(isBestMove), isSacrifice };
  if (loss <= 18) return { key: 'mistake', ...MOVE_LABELS.mistake, loss, isBestMove: Boolean(isBestMove), isSacrifice };
  return { key: 'blunder', ...MOVE_LABELS.blunder, loss, isBestMove: Boolean(isBestMove), isSacrifice };
}

/**
 * ACPL-only accuracy proxy (0..100), NOT Chess.com's proprietary CAPS2.
 *
 * Chess.com publicly describes CAPS2 but does not publish its exact formula, weights,
 * or engine settings. An ACPL scalar cannot reproduce CAPS2 because it discards move
 * context and sequence information. This transparent exponential proxy is provided
 * only for displays where no per-move win-probability data exists.
 * Prefer the project's computeWinPercentAccuracy(rows) when full review rows are available.
 */
export function calculateAccuracy(acpl, options = {}) {
  const value = Number(acpl);
  if (!Number.isFinite(value) || value < 0) return null;
  const scale = Number.isFinite(Number(options.scale)) ? clamp(Number(options.scale), 20, 1000) : 170;
  // 0 ACPL => 100%; increasing ACPL reduces the score smoothly without negative values.
  return Math.round(clamp(100 * Math.exp(-value / scale), 0, 100) * 10) / 10;
}

export const REVIEW_MOVE_LABELS = MOVE_LABELS;
