/**
 * Lichess Cloud Evaluation client.
 *
 * Important:
 * - Cloud Eval is a cache lookup, not an engine search. Many positions return 404.
 * - Requests are serialized and spaced by at least 250ms.
 * - Lichess API guidance says to wait a full minute after HTTP 429. We retry once
 *   after 60 seconds (rather than 3 seconds) to avoid immediately hitting the limit again.
 * - Every attempt has its own 5s timeout; queued requests never run concurrently.
 */

const API_URL = 'https://lichess.org/api/cloud-eval';
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;

let queueTail = Promise.resolve();
let lastRequestStartedAt = 0;
const evalCache = new Map();
const CACHE_LIMIT = 256;

const runtime = {
  fetchImpl: (...args) => globalThis.fetch(...args),
  minIntervalMs: 250,
  timeoutMs: 5000,
  retry429DelayMs: 60000,
  retry429Once: true
};

const now = () => (globalThis.performance?.now?.() ?? Date.now());
function delay(ms, signal = null) {
  return new Promise(resolve => {
    if (signal?.aborted) { resolve(false); return; }
    const timer = setTimeout(() => {
      signal?.removeEventListener?.('abort', abort);
      resolve(true);
    }, Math.max(0, ms));
    const abort = () => {
      clearTimeout(timer);
      signal?.removeEventListener?.('abort', abort);
      resolve(false);
    };
    signal?.addEventListener?.('abort', abort, { once: true });
  });
}

function rememberCache(key, value) {
  evalCache.delete(key);
  evalCache.set(key, value);
  while (evalCache.size > CACHE_LIMIT) evalCache.delete(evalCache.keys().next().value);
}

function normalizeResponse(data) {
  const pv = Array.isArray(data?.pvs) ? data.pvs[0] : null;
  if (!pv || typeof pv !== 'object') return { status: 'EMPTY' };

  const cpValue = Number(pv.cp);
  const mateValue = pv.mate == null ? null : Number(pv.mate);
  const depth = Number(data.depth);
  const pvMoves = String(pv.moves || '').trim().toLowerCase().split(/\s+/).filter(move => UCI_RE.test(move));
  const bestMove = pvMoves[0] || '';

  if ((pv.cp != null && !Number.isFinite(cpValue)) ||
      (mateValue != null && !Number.isFinite(mateValue)) ||
      !Number.isFinite(depth)) {
    return { status: 'INVALID_RESPONSE' };
  }

  return {
    status: 'OK',
    // Lichess documents cp and mate as being from White's point of view.
    cp: pv.cp == null ? 0 : cpValue,
    mate: mateValue,
    bestMove,
    depth,
    pv: pvMoves,
    knodes: Number.isFinite(Number(data.knodes)) ? Number(data.knodes) : 0,
    fen: typeof data.fen === 'string' ? data.fen : ''
  };
}

async function fetchOneAttempt(fen, externalSignal) {
  const controller = new AbortController();
  let timedOut = false;
  let externalAborted = false;
  let timeoutId = null;
  const relayAbort = () => {
    externalAborted = true;
    controller.abort();
  };

  if (externalSignal?.aborted) return { status: 'CANCELLED' };
  externalSignal?.addEventListener?.('abort', relayAbort, { once: true });
  timeoutId = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, runtime.timeoutMs);

  try {
    const url = new URL(API_URL);
    url.searchParams.set('fen', fen);
    url.searchParams.set('multiPv', '1');
    const response = await runtime.fetchImpl(url.toString(), {
      method: 'GET',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
      signal: controller.signal
    });

    if (response.status === 404) return { status: 'NOT_FOUND' };
    if (response.status === 429) return { status: 'HTTP_429' };
    if (!response.ok) return { status: 'HTTP_ERROR', httpStatus: response.status };

    let data;
    try { data = await response.json(); }
    catch { return { status: 'INVALID_JSON' }; }
    return normalizeResponse(data);
  } catch (error) {
    if (externalAborted || externalSignal?.aborted) return { status: 'CANCELLED' };
    if (timedOut || error?.name === 'AbortError') return { status: 'TIMEOUT' };
    return { status: 'NETWORK_ERROR', error: String(error?.message || error) };
  } finally {
    if (timeoutId != null) clearTimeout(timeoutId);
    externalSignal?.removeEventListener?.('abort', relayAbort);
  }
}

async function fetchEvalTask(fen, options = {}) {
  const cached = evalCache.get(fen);
  if (cached) return { ...cached, cached: true, pv: [...(cached.pv || [])] };

  if (options.signal?.aborted) return { status: 'CANCELLED' };
  let result = await fetchOneAttempt(fen, options.signal);

  if (result.status === 'HTTP_429') {
    if (!runtime.retry429Once) return { status: 'RATE_LIMIT' };
    // Follow Lichess API usage guidance: pause for a full minute after 429.
    const resumed = await delay(runtime.retry429DelayMs, options.signal);
    if (!resumed || options.signal?.aborted) return { status: 'CANCELLED' };
    result = await fetchOneAttempt(fen, options.signal);
    if (result.status === 'HTTP_429') return { status: 'RATE_LIMIT' };
  }

  if (result.status === 'OK') rememberCache(fen, result);
  return result;
}

/** Serialize all callers and enforce the minimum gap between request start times. */
function enqueue(task) {
  const job = queueTail.then(async () => {
    const elapsed = now() - lastRequestStartedAt;
    const waitMs = Math.max(0, runtime.minIntervalMs - elapsed);
    if (lastRequestStartedAt > 0 && waitMs > 0) await delay(waitMs);
    lastRequestStartedAt = now();
    return task();
  });
  // A failed task must not poison the queue for later requests.
  queueTail = job.catch(() => undefined);
  return job;
}

/**
 * Fetch a cached evaluation for a FEN.
 * @param {string} fen Full standard-chess FEN.
 * @param {{signal?:AbortSignal}} [options]
 * @returns {Promise<{status:string,cp?:number,mate?:number|null,bestMove?:string,depth?:number,pv?:string[]}>}
 */
export function fetchEval(fen, options = {}) {
  const cleanFen = String(fen || '').trim();
  if (!cleanFen || cleanFen.split(/\s+/).length < 4) {
    return Promise.resolve({ status: 'INVALID_FEN' });
  }
  // Cache hits do not consume a request slot.
  const cached = evalCache.get(cleanFen);
  if (cached) return Promise.resolve({ ...cached, cached: true, pv: [...(cached.pv || [])] });
  return enqueue(() => fetchEvalTask(cleanFen, options));
}

/** Optional runtime tuning; useful for tests and controlled deployments. */
export function configureLichessApi(options = {}) {
  if (typeof options.fetchImpl === 'function') runtime.fetchImpl = options.fetchImpl;
  if (Number.isFinite(options.minIntervalMs)) runtime.minIntervalMs = Math.max(0, options.minIntervalMs);
  if (Number.isFinite(options.timeoutMs)) runtime.timeoutMs = Math.max(100, options.timeoutMs);
  if (Number.isFinite(options.retry429DelayMs)) runtime.retry429DelayMs = Math.max(0, options.retry429DelayMs);
  if (typeof options.retry429Once === 'boolean') runtime.retry429Once = options.retry429Once;
}

/** Clear in-memory cache; does not cancel an in-flight request. */
export function clearLichessEvalCache() {
  evalCache.clear();
}
