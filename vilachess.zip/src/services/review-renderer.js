/** DOM renderer for Cloud-Eval game review. Does not create or remove board squares. */

const SVG_NS = 'http://www.w3.org/2000/svg';
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;

let selectors = {
  board: '#reviewReplayBoard',
  moveList: '#reviewMoveAnalysis',
  banner: '#reviewBanner'
};

const TONE_BY_KEY = Object.freeze({
  brilliant: 'brilliant', good: 'good', inaccuracy: 'unclear', mistake: 'mistake',
  blunder: 'blunder', unrated: 'none'
});

export function configureReviewRenderer(options = {}) {
  selectors = { ...selectors, ...options };
}

function getElement(ref, fallbackSelector) {
  if (ref && typeof ref === 'object' && ref.nodeType === 1) return ref;
  const selector = typeof ref === 'string' ? ref : fallbackSelector;
  try { return document.querySelector(selector); } catch { return null; }
}

function getBoard(boardRef) {
  return getElement(boardRef, selectors.board);
}

/** Get center coordinates in SVG pixels relative to the rendered board. */
export function getSquareCenter(square, boardRef = null) {
  const name = String(square || '').toLowerCase();
  if (!/^[a-h][1-8]$/.test(name) || typeof document === 'undefined') return null;
  const board = getBoard(boardRef);
  if (!board) return null;
  const cell = board.querySelector(`[data-square="${name}"]`);
  if (!cell) return null;

  const boardRect = board.getBoundingClientRect();
  const cellRect = cell.getBoundingClientRect();
  if (!boardRect.width || !boardRect.height || !cellRect.width || !cellRect.height) return null;
  return {
    x: cellRect.left - boardRect.left + cellRect.width / 2,
    y: cellRect.top - boardRect.top + cellRect.height / 2
  };
}

function safeColor(input) {
  const value = String(input || '#35d06f').trim();
  if (/^#[0-9a-f]{3,8}$/i.test(value)) return value;
  if (/^rgba?\([\d\s.,%/+-]+\)$/i.test(value)) return value;
  return '#35d06f';
}

function getArrowSvg(board) {
  let svg = board.querySelector('svg[data-cloud-review-arrow="1"]');
  if (!svg) {
    svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('data-cloud-review-arrow', '1');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.style.position = 'absolute';
    svg.style.inset = '0';
    svg.style.width = '100%';
    svg.style.height = '100%';
    svg.style.overflow = 'visible';
    svg.style.pointerEvents = 'none';
    svg.style.zIndex = '20';
    board.appendChild(svg); // Absolutely positioned: does not become a 65th grid cell.
  }
  return svg;
}

/** Draw a pixel-aligned SVG arrow using the actual rendered square locations. */
export function drawArrow(fromSquare, toSquare, color = '#35d06f', boardRef = null) {
  try {
    const board = getBoard(boardRef);
    if (!board) return false;
    const from = getSquareCenter(fromSquare, board);
    const to = getSquareCenter(toSquare, board);
    const rect = board.getBoundingClientRect();
    if (!from || !to || !rect.width || !rect.height) return false;

    // Ensure absolute overlay is anchored to the board. Existing board layout stays intact.
    if (typeof getComputedStyle === 'function' && getComputedStyle(board).position === 'static') {
      board.style.position = 'relative';
    }
    const svg = getArrowSvg(board);
    svg.setAttribute('viewBox', `0 0 ${rect.width} ${rect.height}`);
    svg.setAttribute('width', String(rect.width));
    svg.setAttribute('height', String(rect.height));
    svg.replaceChildren();

    const stroke = safeColor(color);
    const markerId = `cloud-review-head-${Math.random().toString(36).slice(2, 9)}`;
    const defs = document.createElementNS(SVG_NS, 'defs');
    const marker = document.createElementNS(SVG_NS, 'marker');
    marker.setAttribute('id', markerId);
    marker.setAttribute('markerWidth', '10');
    marker.setAttribute('markerHeight', '10');
    marker.setAttribute('refX', '8.5');
    marker.setAttribute('refY', '5');
    marker.setAttribute('orient', 'auto');
    marker.setAttribute('markerUnits', 'userSpaceOnUse');
    const head = document.createElementNS(SVG_NS, 'path');
    head.setAttribute('d', 'M0 0 L10 5 L0 10 Z');
    head.setAttribute('fill', stroke);
    marker.appendChild(head);
    defs.appendChild(marker);
    svg.appendChild(defs);

    const line = document.createElementNS(SVG_NS, 'line');
    line.setAttribute('x1', String(from.x));
    line.setAttribute('y1', String(from.y));
    line.setAttribute('x2', String(to.x));
    line.setAttribute('y2', String(to.y));
    line.setAttribute('stroke', stroke);
    line.setAttribute('stroke-width', String(Math.max(4, Math.min(6, rect.width / 90))));
    line.setAttribute('stroke-linecap', 'round');
    line.setAttribute('stroke-opacity', '0.86');
    line.setAttribute('marker-end', `url(#${markerId})`);
    svg.appendChild(line);

    const origin = document.createElementNS(SVG_NS, 'circle');
    origin.setAttribute('cx', String(from.x));
    origin.setAttribute('cy', String(from.y));
    origin.setAttribute('r', String(Math.max(3, rect.width / 100)));
    origin.setAttribute('fill', stroke);
    origin.setAttribute('fill-opacity', '0.72');
    svg.appendChild(origin);
    return true;
  } catch (error) {
    console.warn('[ChessPlus review] drawArrow failed:', error?.message || error);
    return false;
  }
}

export function clearReviewArrow(boardRef = null) {
  try { getBoard(boardRef)?.querySelector('svg[data-cloud-review-arrow="1"]')?.remove(); } catch { /* UI-only cleanup */ }
}

function createMoveButton(move, classification) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'review-cloud-move';
  button.dataset.reviewPly = String(move.ply);
  const san = document.createElement('span');
  san.className = 'review-cloud-san';
  san.textContent = move.san || move.uci || `Nước ${move.ply}`;
  const badge = document.createElement('span');
  badge.className = 'review-cloud-badge';
  badge.textContent = classification?.icon || '';
  button.append(san, badge);
  return button;
}

/** Update pre-existing move buttons (or build a compact fallback list when none exist). */
export function updateMoveListUI(moveHistory = [], analysisResults = [], options = {}) {
  try {
    const root = getElement(options.container, selectors.moveList);
    if (!root) return false;
    const moves = Array.isArray(moveHistory) ? moveHistory : [];
    const results = Array.isArray(analysisResults) ? analysisResults : [];
    const byPly = new Map(results.map(row => [Number(row?.ply), row]));
    const existing = root.querySelectorAll('[data-review-ply]');

    if (!existing.length && moves.length) {
      const fragment = document.createDocumentFragment();
      for (const move of moves) {
        const ply = Number(move?.ply);
        if (!Number.isInteger(ply) || ply < 1) continue;
        const result = byPly.get(ply);
        fragment.appendChild(createMoveButton(move, result?.classification));
      }
      root.replaceChildren(fragment);
    }

    root.querySelectorAll('[data-review-ply]').forEach(button => {
      const ply = Number(button.dataset.reviewPly);
      const row = byPly.get(ply);
      const judgement = row?.classification;
      button.classList.remove('review-cloud-good', 'review-cloud-inaccuracy', 'review-cloud-mistake', 'review-cloud-blunder', 'review-cloud-brilliant', 'review-cloud-unrated');
      if (judgement?.key) button.classList.add(`review-cloud-${judgement.key}`);
      if (judgement?.color) button.style.setProperty('--review-quality-color', safeColor(judgement.color));
      button.dataset.reviewQuality = judgement?.key || 'unrated';
      button.title = judgement ? `${judgement.label} · mất ${Number(judgement.loss || 0).toFixed(1)} điểm xác suất thắng` : 'Chưa có đánh giá Cloud Eval';

      let badge = button.querySelector('.review-cloud-badge, .rv2-badge');
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'review-cloud-badge';
        badge.setAttribute('aria-hidden', 'true');
        button.appendChild(badge);
      }
      badge.textContent = judgement?.icon || '';
      badge.style.color = judgement?.color || '';
      if (Number.isInteger(options.activePly)) {
        const active = ply === options.activePly;
        button.classList.toggle('is-active', active);
        if (active) button.setAttribute('aria-current', 'step');
        else button.removeAttribute('aria-current');
      }
    });
    return true;
  } catch (error) {
    console.warn('[ChessPlus review] updateMoveListUI failed:', error?.message || error);
    return false;
  }
}

/** Set the current review banner without injecting untrusted text as HTML. */
export function updateTopBanner(classification, moveName = '', bannerRef = null) {
  try {
    const root = getElement(bannerRef, selectors.banner);
    if (!root) return false;
    const item = classification || { key: 'unrated', label: 'CHƯA PHÂN TÍCH', color: '#8993a5', icon: '—' };
    const tone = TONE_BY_KEY[item.key] || 'none';
    root.className = `rv2-banner t-${tone}`;
    let icon = root.querySelector('.rv2-banner-ico');
    let label = root.querySelector('b');
    let chip = root.querySelector('.rv2-banner-chip');
    if (!icon) { icon = document.createElement('span'); icon.className = 'rv2-banner-ico'; root.prepend(icon); }
    if (!label) { label = document.createElement('b'); root.appendChild(label); }
    if (!chip) { chip = document.createElement('span'); chip.className = 'rv2-banner-chip'; root.appendChild(chip); }
    icon.textContent = item.icon || '•';
    label.textContent = item.label || 'CHƯA PHÂN TÍCH';
    chip.textContent = String(moveName || '');
    chip.hidden = !moveName;
    root.style.setProperty('--review-quality-color', safeColor(item.color));
    root.setAttribute('aria-live', 'polite');
    return true;
  } catch (error) {
    console.warn('[ChessPlus review] updateTopBanner failed:', error?.message || error);
    return false;
  }
}
