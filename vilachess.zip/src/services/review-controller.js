/**
 * Cloud-Eval Game Review controller.
 *
 * This module is intentionally separate from ChessPlus' existing Stockfish review flow.
 * It can be used as a lightweight cached-evaluation source or as a fallback/preview.
 * Cloud Eval only knows cached positions; configure `fallbackEval` to fill cache misses.
 */

import { Chess } from 'chess.js';
import { fetchEval } from './lichess-api.js';
import { calculateAccuracy, calculateWinProbability, classifyMove } from './chess-math.js';
import { configureReviewRenderer, clearReviewArrow, drawArrow, updateMoveListUI, updateTopBanner } from './review-renderer.js';
import { detectSacrifice } from '../review-brilliance.js';
import { computeWinPercentAccuracy } from '../game-review.js';

const DEFAULT_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/i;
const GLYPH = Object.freeze({
  wk: '♔', wq: '♕', wr: '♖', wb: '♗', wn: '♘', wp: '♙',
  bk: '♚', bq: '♛', br: '♜', bb: '♝', bn: '♞', bp: '♟'
});

/** Public result array. Mutated in place so other modules can keep the same reference. */
export const globalAnalysisData = [];
if (typeof window !== 'undefined') window.globalAnalysisData = globalAnalysisData;

let controllerOptions = {
  boardSelector: '#reviewReplayBoard',
  moveListSelector: '#reviewMoveAnalysis',
  bannerSelector: '#reviewBanner',
  progressSelector: '#reviewProgress',
  renderPosition: null,
  fallbackEval: null,
  onProgress: null,
  onComplete: null
};
let activeSession = null;
let activeReviewState = null;
let sessionCounter = 0;

export function configureReviewController(options = {}) {
  controllerOptions = { ...controllerOptions, ...options };
  configureReviewRenderer({
    board: controllerOptions.boardSelector,
    moveList: controllerOptions.moveListSelector,
    banner: controllerOptions.bannerSelector
  });
}

const yieldToUi = () => new Promise(resolve => setTimeout(resolve, 0));

function readUci(item) {
  if (typeof item === 'string') return item.trim().toLowerCase();
  if (typeof item?.uci === 'string') return item.uci.trim().toLowerCase();
  if (item?.from && item?.to) return `${item.from}${item.to}${item.promotion || ''}`.toLowerCase();
  return '';
}

function applyMove(chess, item) {
  try {
    if (typeof item === 'string') {
      const uci = item.trim().toLowerCase();
      if (UCI_RE.test(uci)) return chess.move({
        from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {})
      });
      return chess.move(item);
    }
    if (item && typeof item === 'object') {
      if (item.from && item.to) return chess.move({
        from: String(item.from), to: String(item.to), ...(item.promotion ? { promotion: String(item.promotion) } : {})
      });
      if (item.san) return chess.move(String(item.san));
      const uci = readUci(item);
      if (UCI_RE.test(uci)) return chess.move({
        from: uci.slice(0, 2), to: uci.slice(2, 4), ...(uci[4] ? { promotion: uci[4] } : {})
      });
    }
  } catch { /* rejected illegal or malformed move */ }
  return null;
}

/** Rebuild the complete FEN timeline from verbose chess.js history or UCI/SAN moves. */
function createTimeline(gameMoves, startFen = DEFAULT_FEN) {
  if (!Array.isArray(gameMoves)) throw new TypeError('gameMoves phải là một mảng nước đi.');
  const chess = new Chess(startFen || DEFAULT_FEN);
  const positions = [{ ply: 0, fen: chess.fen(), mover: '', san: '', uci: '', from: '', to: '' }];
  const moves = [];

  for (let index = 0; index < gameMoves.length; index += 1) {
    const beforeFen = chess.fen();
    const mover = chess.turn();
    const made = applyMove(chess, gameMoves[index]);
    if (!made) throw new Error(`Nước đi ${index + 1} không hợp lệ hoặc không thể đọc.`);
    const move = {
      ply: index + 1,
      mover,
      san: made.san,
      uci: `${made.from}${made.to}${made.promotion || ''}`.toLowerCase(),
      from: made.from,
      to: made.to,
      promotion: made.promotion || '',
      captured: made.captured || '',
      beforeFen,
      afterFen: chess.fen()
    };
    moves.push(move);
    positions.push({ ...move, fen: chess.fen() });
  }
  return { positions, moves };
}

function whiteProbability(evaluation) {
  if (!evaluation || evaluation.status !== 'OK') return null;
  return calculateWinProbability(evaluation.cp, evaluation.mate);
}

function moverProbability(whitePct, mover) {
  if (!Number.isFinite(whitePct)) return null;
  return mover === 'w' ? whitePct : 100 - whitePct;
}

function moverCentipawns(evaluation, mover) {
  if (!evaluation || evaluation.status !== 'OK' || evaluation.mate != null) return null;
  const cp = Number(evaluation.cp);
  if (!Number.isFinite(cp)) return null;
  return mover === 'w' ? cp : -cp;
}

function setProgress(done, total, statusText = '') {
  const safeTotal = Math.max(0, Number(total) || 0);
  const safeDone = Math.max(0, Math.min(safeTotal, Number(done) || 0));
  const percent = safeTotal ? Math.round((safeDone / safeTotal) * 100) : 0;
  try {
    const root = document.querySelector(controllerOptions.progressSelector);
    if (root) {
      root.hidden = false;
      let bar = root.querySelector('.rv2-progress-bar span, [data-review-progress-fill]');
      if (!bar) {
        const track = document.createElement('div');
        track.className = 'rv2-progress-bar';
        bar = document.createElement('span');
        track.appendChild(bar);
        root.appendChild(track);
      }
      bar.style.width = `${percent}%`;
      let label = root.querySelector('[data-review-progress-label], small');
      if (!label) {
        label = document.createElement('small');
        label.dataset.reviewProgressLabel = '1';
        root.appendChild(label);
      }
      label.textContent = statusText || `Đang phân tích ${safeDone}/${safeTotal} thế cờ · ${percent}%`;
      root.setAttribute('aria-valuemin', '0');
      root.setAttribute('aria-valuemax', '100');
      root.setAttribute('aria-valuenow', String(percent));
    }
  } catch (error) {
    console.warn('[ChessPlus review] progress rendering skipped:', error?.message || error);
  }
  try { controllerOptions.onProgress?.({ done: safeDone, total: safeTotal, percent, status: statusText }); } catch { /* callbacks must not crash review */ }
}

async function evaluatePosition(position, signal) {
  let result = await fetchEval(position.fen, { signal });
  if (result.status === 'NOT_FOUND' && typeof controllerOptions.fallbackEval === 'function') {
    try {
      const fallback = await controllerOptions.fallbackEval(position.fen, { signal, position });
      if (fallback && Number.isFinite(Number(fallback.cp)) && fallback.status !== 'ERROR') {
        result = {
          status: 'OK',
          cp: Number(fallback.cp),
          mate: fallback.mate == null ? null : Number(fallback.mate),
          bestMove: String(fallback.bestMove || '').toLowerCase(),
          depth: Number(fallback.depth) || 0,
          pv: Array.isArray(fallback.pv) ? fallback.pv : [],
          source: fallback.source || 'fallback'
        };
      }
    } catch (error) {
      return { status: 'FALLBACK_ERROR', error: String(error?.message || error) };
    }
  }
  return result;
}

function classifyTimeline(moves, positions) {
  const rows = [];
  const cpLosses = [];
  for (const move of moves) {
    const beforeEval = positions[move.ply - 1]?.evaluation;
    const afterEval = positions[move.ply]?.evaluation;
    const beforeWhite = whiteProbability(beforeEval);
    const afterWhite = whiteProbability(afterEval);
    const epBefore = moverProbability(beforeWhite, move.mover);
    const epAfter = moverProbability(afterWhite, move.mover);
    const isBestMove = Boolean(beforeEval?.status === 'OK' && beforeEval.bestMove && beforeEval.bestMove === move.uci);

    let isSacrifice = false;
    if (beforeEval?.status === 'OK' && afterEval?.status === 'OK' && Array.isArray(afterEval.pv) && afterEval.pv.length) {
      isSacrifice = detectSacrifice({
        fenBefore: move.beforeFen,
        playedUci: move.uci,
        pvAfterUci: afterEval.pv,
        mover: move.mover,
        ChessConstructor: Chess
      });
    }

    const classification = classifyMove(epBefore, epAfter, isBestMove, { isSacrifice });
    const beforeCp = moverCentipawns(beforeEval, move.mover);
    const afterCp = moverCentipawns(afterEval, move.mover);
    const lossCp = beforeCp == null || afterCp == null ? null : Math.max(0, beforeCp - afterCp);
    if (lossCp != null) cpLosses.push(lossCp);

    rows.push({
      ply: move.ply,
      moveNumber: Math.ceil(move.ply / 2),
      mover: move.mover,
      san: move.san,
      uci: move.uci,
      from: move.from,
      to: move.to,
      fenBefore: move.beforeFen,
      fenAfter: move.afterFen,
      epBefore,
      epAfter,
      loss: classification.loss,
      lossCp,
      isBestMove,
      isSacrifice,
      bestMove: beforeEval?.bestMove || '',
      bestMoveAtCurrentPosition: afterEval?.bestMove || '',
      depthBefore: beforeEval?.depth || 0,
      depthAfter: afterEval?.depth || 0,
      sourceBefore: beforeEval?.source || 'lichess-cloud',
      sourceAfter: afterEval?.source || 'lichess-cloud',
      beforeStatus: beforeEval?.status || 'NOT_FOUND',
      afterStatus: afterEval?.status || 'NOT_FOUND',
      classification
    });
  }
  const acpl = cpLosses.length ? cpLosses.reduce((sum, loss) => sum + loss, 0) / cpLosses.length : null;
  // Prefer the project's move-by-move win-percent accuracy when both adjacent
  // positions have centipawn scores. Mate-only/cache-miss positions are excluded.
  const winPercentRows = moves.map(move => {
    const before = positions[move.ply - 1]?.evaluation;
    const after = positions[move.ply]?.evaluation;
    return {
      ply: move.ply,
      mover: move.mover,
      scoreBeforeWhiteCp: before?.status === 'OK' && before.mate == null ? before.cp : null,
      scoreWhiteCp: after?.status === 'OK' && after.mate == null ? after.cp : null
    };
  });
  const winPercentAccuracy = computeWinPercentAccuracy(winPercentRows);
  const accuracy = winPercentAccuracy.combined ?? (acpl == null ? null : calculateAccuracy(acpl));
  const accuracyMethod = winPercentAccuracy.combined != null ? 'win-percent' : (acpl == null ? 'unavailable' : 'acpl-proxy');
  return { rows, acpl, accuracy, accuracyMethod, accuracyBySide: winPercentAccuracy };
}

/**
 * Analyze a game sequentially. A request is awaited before the next FEN is fetched;
 * fetchEval also enforces the shared 250ms request queue and 5s timeout.
 *
 * `gameMoves`: chess.js `history({ verbose:true })`, UCI strings, or SAN strings.
 * `options.startFen`: starting position for Chess960/custom FEN games if supported upstream.
 */
export async function startGameReview(gameMoves, options = {}) {
  stopGameReview();
  const sessionId = ++sessionCounter;
  const abortController = new AbortController();
  activeSession = { id: sessionId, abortController };
  globalAnalysisData.splice(0, globalAnalysisData.length);
  activeReviewState = null;
  if (typeof window !== 'undefined') window.globalAnalysisData = globalAnalysisData;

  try {
    const { positions, moves } = createTimeline(gameMoves, options.startFen || DEFAULT_FEN);
    const total = positions.length;
    positions.forEach(position => { position.evaluation = null; });
    setProgress(0, total, `Bắt đầu phân tích ${moves.length} nước đi…`);

    let index = 0;
    for (const position of positions) {
      if (abortController.signal.aborted || activeSession?.id !== sessionId) {
        return { status: 'CANCELLED', done: index, total };
      }
      try { position.evaluation = await evaluatePosition(position, abortController.signal); }
      catch (error) { position.evaluation = { status: 'ERROR', error: String(error?.message || error) }; }
      const done = index + 1;
      setProgress(done, total, `Đang phân tích thế cờ ${done}/${total}…`);
      // Yield one task to the WebView after each result so progress/gestures can paint.
      await yieldToUi();
      index += 1;
    }

    if (abortController.signal.aborted || activeSession?.id !== sessionId) {
      return { status: 'CANCELLED', done: positions.filter(p => p.evaluation).length, total };
    }

    const summary = classifyTimeline(moves, positions);
    globalAnalysisData.push(...summary.rows);
    activeReviewState = { positions, moves, results: summary.rows, acpl: summary.acpl, accuracy: summary.accuracy, startFen: positions[0]?.fen || DEFAULT_FEN };
    setProgress(total, total, `Hoàn tất · ${summary.rows.length} nước · ${summary.accuracy == null ? 'chưa đủ dữ liệu' : `độ chính xác ước lượng ${summary.accuracy.toFixed(1)}%`}`);
    try { controllerOptions.onComplete?.({ ...summary, positions, moves }); } catch { /* external UI callback is optional */ }
    navigateToStep(0);
    return { status: 'OK', ...summary, positions, moves };
  } catch (error) {
    if (activeSession?.id === sessionId) setProgress(0, 0, `Không thể phân tích: ${error?.message || 'lỗi không xác định'}`);
    return { status: 'ERROR', error: String(error?.message || error) };
  } finally {
    if (activeSession?.id === sessionId) activeSession = null;
  }
}

export function stopGameReview() {
  try { activeSession?.abortController?.abort(); } catch { /* ignore */ }
  activeSession = null;
}

/** Minimal fallback renderer. Production ChessPlus integration should pass renderPosition. */
function renderFenFallback(fen) {
  try {
    const board = document.querySelector(controllerOptions.boardSelector);
    if (!board) return false;
    const chess = new Chess(fen);
    const snapshot = chess.board();
    for (let row = 0; row < 8; row += 1) {
      for (let file = 0; file < 8; file += 1) {
        const square = `${String.fromCharCode(97 + file)}${8 - row}`;
        const cell = board.querySelector(`[data-square="${square}"]`);
        if (!cell) continue;
        cell.replaceChildren();
        const piece = snapshot[row][file];
        if (!piece) continue;
        const span = document.createElement('span');
        span.className = `review-cloud-piece ${piece.color === 'w' ? 'piece-white' : 'piece-black'}`;
        span.dataset.piece = `${piece.color}${piece.type}`;
        span.textContent = GLYPH[`${piece.color}${piece.type}`] || '';
        cell.appendChild(span);
      }
    }
    return true;
  } catch { return false; }
}

/** Navigate to a FEN ply, update best-move arrow, banner and move list. */
export function navigateToStep(index) {
  const state = activeReviewState;
  if (!state) return null;
  const safeIndex = Math.max(0, Math.min(state.positions.length - 1, Math.trunc(Number(index) || 0)));
  const position = state.positions[safeIndex];
  const row = safeIndex > 0 ? state.results[safeIndex - 1] : null;

  try {
    if (typeof controllerOptions.renderPosition === 'function') {
      controllerOptions.renderPosition(position.fen, safeIndex, position);
    } else {
      renderFenFallback(position.fen);
    }
  } catch (error) {
    console.warn('[ChessPlus review] renderPosition callback failed:', error?.message || error);
    renderFenFallback(position.fen);
  }

  clearReviewArrow();
  const bestUci = String(position.evaluation?.bestMove || '').toLowerCase();
  if (position.evaluation?.status === 'OK' && UCI_RE.test(bestUci)) {
    drawArrow(bestUci.slice(0, 2), bestUci.slice(2, 4), '#35d06f');
  }

  if (row) updateTopBanner(row.classification, row.san);
  else updateTopBanner({ key: 'unrated', label: 'THẾ CỜ BẮT ĐẦU', color: '#7586b5', icon: '♙' }, '');
  updateMoveListUI(state.moves, state.results, { activePly: safeIndex });
  return { index: safeIndex, fen: position.fen, evaluation: position.evaluation, move: row };
}

/** For a separate button in apps that do not already have a Game Review handler. */
export function bindReviewButton({
  selector = '#reviewCloudEvalBtn',
  getMoves,
  getStartFen = () => DEFAULT_FEN,
  options = {}
} = {}) {
  const button = document.querySelector(selector);
  if (!button || typeof getMoves !== 'function') return false;
  if (button.dataset.cloudReviewBound === '1') return true;
  button.dataset.cloudReviewBound = '1';
  button.addEventListener('click', async () => {
    button.disabled = true;
    try { await startGameReview(getMoves(), { ...options, startFen: getStartFen() }); }
    finally { button.disabled = false; }
  });
  return true;
}

// Optional console/debug hooks. Importing the module in Node remains safe.
if (typeof window !== 'undefined') {
  window.startChessPlusCloudReview = startGameReview;
  window.navigateChessPlusReviewToStep = navigateToStep;
  window.stopChessPlusCloudReview = stopGameReview;
}
