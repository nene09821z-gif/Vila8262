/** Capacitor Haptics wrapper with fallback for VILA's existing custom Android WebView host. */
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { deviceTier } from './device-tier.js';

async function impact(style, androidDurationMs) {
  // LOW keeps the input path to transforms only; no native feedback bridge work is scheduled.
  if (deviceTier.useHaptic !== true) return false;

  // VILA's current Android shell is a Compose WebView exposing AndroidBridge, not BridgeActivity.
  // Prefer its native Vibrator bridge when present; a real Capacitor host uses the Haptics plugin.
  try {
    const bridge = globalThis.window?.AndroidBridge || globalThis.AndroidBridge;
    if (typeof bridge?.vibrate === 'function') {
      bridge.vibrate(androidDurationMs);
      return true;
    }
  } catch {
    // Fall through to the official Capacitor plugin if this host does not expose the VILA bridge.
  }

  try {
    await Haptics.impact({ style });
    return true;
  } catch {
    // Ordinary browsers and WebViews without either native bridge simply omit the haptic cue.
    return false;
  }
}

export function hapticLight() { return impact(ImpactStyle.Light, 12); }
export function hapticMedium() { return impact(ImpactStyle.Medium, 24); }
export function hapticHeavy() { return impact(ImpactStyle.Heavy, 42); }
