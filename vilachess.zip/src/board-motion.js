/**
 * Board motion helpers — pure functions for slide timing and premove ghosts.
 * Safe for Node tests and browser.
 */
import { stepPremovePreview } from './premove.js';

/**
 * Duration (ms) for a piece slide based on travel distance in pixels.
 * Short steps stay snappy; long slides get a bit more time without feeling slow.
 */
export function slideDurationMs(dx = 0, dy = 0, {
  min = 160,
  max = 280,
  base = 150,
  pxPerMs = 2.4
} = {}) {
  const dist = Math.hypot(Number(dx) || 0, Number(dy) || 0);
  const raw = base + dist / pxPerMs;
  return Math.round(Math.min(max, Math.max(min, raw)));
}

/** Cubic-bezier string used by the main board slide. */
export const SLIDE_EASING = 'cubic-bezier(0.25, 0.6, 0.35, 1)';

/**
 * Ghost pieces for a premove queue: map of destination square → piece snapshot
 * { type, color } after each intent is applied on the planned board.
 */
export function premoveGhostPieces(chess, color, queue, ChessConstructor) {
  const ghosts = new Map();
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return ghosts;
  const list = Array.isArray(queue) ? queue : [];
  if (!list.length) return ghosts;

  try {
    const fenParts = String(chess.fen()).split(' ');
    if (fenParts.length < 4) return ghosts;
    fenParts[1] = color;
    fenParts[3] = '-';
    let preview = new ChessConstructor(fenParts.join(' '));

    for (const intent of list) {
      if (!intent?.from || !intent?.to) continue;
      if (!preview.get(intent.from)) continue;
      // Same rules as the queue itself: legal moves plus chess.com-style pseudo-legal premoves (captures onto
      // squares the opponent may reach, sliding through enemy pieces, diagonal pawn steps, castling).
      const next = stepPremovePreview(preview, color, intent, ChessConstructor);
      if (!next) break;
      const landed = next.get(intent.to);
      if (!landed) break;
      ghosts.set(intent.to, { type: landed.type, color: landed.color });
      preview = next;
    }
  } catch {
    return new Map();
  }
  return ghosts;
}

/**
 * Keyframes for a FLIP-style translate slide (from offset → rest).
 */
export function slideKeyframes(dx, dy) {
  return [
    { translate: `${dx}px ${dy}px`, offset: 0 },
    { translate: '0px 0px', offset: 1 }
  ];
}
