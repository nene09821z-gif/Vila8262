/**
 * Chess.com-style premoves.
 *
 * A premove queue is an ordered list of intents `{ from, to, promotion }` that the player
 * entered while the opponent was still thinking. Each intent is planned on a *virtual* board in
 * which the earlier queued moves were already played and the opponent did nothing. Nothing is
 * ever trusted at play time: every intent is revalidated against the real position, and the
 * whole queue is cancelled as soon as one intent is no longer legal (for example because the
 * opponent captured or moved the piece involved).
 */
const SQUARE = /^[a-h][1-8]$/;
const PROMOTIONS = ['q', 'r', 'b', 'n'];
export const MAX_PREMOVE_QUEUE = 5;

/** FEN with `color` to move and no en-passant right (those expire after the opponent's reply). */
function plannedFen(fen, color) {
  const fields = String(fen).split(' ');
  if (fields.length < 6) return null;
  fields[1] = color;
  fields[3] = '-';
  return fields.join(' ');
}

function normalizePromotion(candidates, requested) {
  if (!candidates.some(move => move.promotion)) return { ok: true, promotion: null };
  const promotion = PROMOTIONS.includes(requested) ? requested : 'q';
  return { ok: candidates.some(move => move.promotion === promotion), promotion };
}

const FILES = 'abcdefgh';
const squareAt = (file, rank) => (file < 0 || file > 7 || rank < 0 || rank > 7 ? null : `${FILES[file]}${rank + 1}`);
const ALL_SQUARES = Array.from({ length: 64 }, (_, i) => squareAt(i % 8, Math.floor(i / 8)));
const KNIGHT_STEPS = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]];
const KING_STEPS = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
const ROOK_DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const BISHOP_DIRS = [[1, 1], [1, -1], [-1, 1], [-1, -1]];

/**
 * Chess.com / Lichess style *pseudo-legal* premove targets.
 * While the opponent is still thinking, the player may queue any move their piece could make if the
 * opponent's pieces were not in the way and checks did not matter: capture a piece that may arrive
 * on a square, slide through enemy pieces that will probably move, push a pawn diagonally onto an
 * empty square, castle. Only the player's own pieces block. The real position decides at fire time
 * (resolveQueuedPremove), so an impossible move is simply cancelled.
 * `position` only needs get(square) and fen() (a chess.js instance works).
 */
export function pseudoPremoveMoves(position, color, only = null) {
  if (!position || typeof position.get !== 'function' || !['w', 'b'].includes(color)) return [];
  const moves = [];
  const squares = only ? [only] : ALL_SQUARES;
  for (const from of squares) {
    if (!SQUARE.test(String(from || ''))) continue;
    const piece = position.get(from);
    if (!piece || piece.color !== color) continue;
    const file = FILES.indexOf(from[0]);
    const rank = Number(from[1]) - 1;
    const landable = to => { const target = position.get(to); return !(target && (target.color === color || target.type === 'k')); };
    const add = (to, promotion) => {
      const target = position.get(to);
      moves.push({ color, from, to, piece: piece.type, flags: target ? 'c' : 'n', ...(target ? { captured: target.type } : {}), ...(promotion ? { promotion } : {}) });
    };
    const addPawn = to => {
      if (to[1] === (color === 'w' ? '8' : '1')) PROMOTIONS.forEach(promotion => add(to, promotion));
      else add(to);
    };
    if (piece.type === 'n' || piece.type === 'k') {
      for (const [df, dr] of piece.type === 'n' ? KNIGHT_STEPS : KING_STEPS) {
        const to = squareAt(file + df, rank + dr);
        if (to && landable(to)) add(to);
      }
      if (piece.type === 'k') {
        const home = color === 'w' ? '1' : '8';
        const rights = String(position.fen?.() || '').split(' ')[2] || '';
        const hasRook = sq => { const rook = position.get(sq); return Boolean(rook && rook.type === 'r' && rook.color === color); };
        const free = list => list.every(sq => { const p = position.get(sq); return !(p && p.color === color); });
        if (from === `e${home}`) {
          if (rights.includes(color === 'w' ? 'K' : 'k') && hasRook(`h${home}`) && free([`f${home}`, `g${home}`])) add(`g${home}`);
          if (rights.includes(color === 'w' ? 'Q' : 'q') && hasRook(`a${home}`) && free([`b${home}`, `c${home}`, `d${home}`])) add(`c${home}`);
        }
      }
    } else if (piece.type === 'p') {
      const dir = color === 'w' ? 1 : -1;
      const one = squareAt(file, rank + dir);
      if (one && !position.get(one)) {
        addPawn(one);
        const two = squareAt(file, rank + 2 * dir);
        if (two && rank === (color === 'w' ? 1 : 6) && !position.get(two)) add(two);
      }
      for (const df of [-1, 1]) {
        const to = squareAt(file + df, rank + dir);
        if (to && landable(to)) addPawn(to);
      }
    } else {
      const dirs = piece.type === 'r' ? ROOK_DIRS : piece.type === 'b' ? BISHOP_DIRS : [...ROOK_DIRS, ...BISHOP_DIRS];
      for (const [df, dr] of dirs) {
        for (let step = 1; step < 8; step += 1) {
          const to = squareAt(file + df * step, rank + dr * step);
          if (!to) break;
          const target = position.get(to);
          if (target && (target.color === color || target.type === 'k')) break; // own piece (or a king) stops the slide
          add(to); // enemy pieces do not: they will probably have moved by the time the premove fires
        }
      }
    }
  }
  return moves;
}

const sameMove = (a, b) => a.from === b.from && a.to === b.to && (a.promotion || null) === (b.promotion || null);

/** chess.js legal moves for `from` plus the extra pseudo-legal premove targets. */
function premoveCandidates(preview, color, from) {
  const legal = preview.moves({ square: from, verbose: true });
  if (typeof preview.get !== 'function') return legal;
  return [...legal, ...pseudoPremoveMoves(preview, color, from).filter(move => !legal.some(item => sameMove(item, move)))];
}

/**
 * Play one queued intent on a virtual position (opponent passes). Returns a NEW chess instance with
 * `color` to move again, or null when the intent is impossible even as a premove.
 */
export function stepPremovePreview(preview, color, intent, ChessConstructor) {
  try {
    const candidates = premoveCandidates(preview, color, intent?.from).filter(move => move.to === intent?.to);
    if (!candidates.length) return null;
    const { ok, promotion } = normalizePromotion(candidates, intent.promotion);
    if (!ok) return null;
    const legal = preview.moves({ square: intent.from, verbose: true }).some(move => move.to === intent.to && (move.promotion || null) === (promotion || null));
    if (legal) {
      if (!preview.move({ from: intent.from, to: intent.to, ...(promotion ? { promotion } : {}) })) return null;
    } else {
      const piece = preview.get(intent.from);
      if (!piece) return null;
      const castle = piece.type === 'k' && Math.abs(FILES.indexOf(intent.to[0]) - FILES.indexOf(intent.from[0])) === 2;
      preview.remove(intent.from);
      if (!preview.put({ type: promotion || piece.type, color }, intent.to)) return null;
      if (castle) {
        const home = intent.from[1];
        const kingside = intent.to[0] === 'g';
        preview.remove(`${kingside ? 'h' : 'a'}${home}`);
        preview.put({ type: 'r', color }, `${kingside ? 'f' : 'd'}${home}`);
      }
    }
    const fen = plannedFen(preview.fen(), color);
    return fen ? new ChessConstructor(fen) : null;
  } catch {
    return null;
  }
}

/**
 * Virtual position after playing every queued intent for `color` while the opponent passes.
 * Returns a chess instance (with `color` to move) or null when an intent cannot be replayed.
 */
export function buildPremovePosition(chess, color, queue, ChessConstructor) {
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return null;
  try {
    const fen = plannedFen(chess.fen(), color);
    if (!fen) return null;
    let preview = new ChessConstructor(fen);
    for (const intent of Array.isArray(queue) ? queue : []) {
      preview = stepPremovePreview(preview, color, intent, ChessConstructor);
      if (!preview) return null;
    }
    return preview;
  } catch {
    return null;
  }
}

/**
 * Legal premove destinations for the next queued move. With an empty queue this is the player's
 * move list as if it were already their turn; with a queue it is evaluated on the virtual board.
 */
export function getPremoveLegalMoves(chess, color, ChessConstructor, square = null, queue = []) {
  if (!chess || !['w', 'b'].includes(color) || typeof ChessConstructor !== 'function') return [];
  try {
    const preview = queue && queue.length
      ? buildPremovePosition(chess, color, queue, ChessConstructor)
      : new ChessConstructor(plannedFen(chess.fen(), color) || '');
    if (!preview) return [];
    const legal = square ? preview.moves({ square, verbose: true }) : preview.moves({ verbose: true });
    if (typeof preview.get !== 'function') return legal;
    const extra = pseudoPremoveMoves(preview, color, square || null).filter(move => !legal.some(item => sameMove(item, move)));
    return [...legal, ...extra];
  } catch {
    return [];
  }
}

/** Validates and appends one intent. Returns the new queue, or null when the intent is illegal. */
export function appendPremove(chess, color, ChessConstructor, queue, from, to, promotion = null) {
  if (!SQUARE.test(String(from || '')) || !SQUARE.test(String(to || ''))) return null;
  const current = Array.isArray(queue) ? queue : [];
  // A premove is only an intent queued while the opponent owns the current turn. Enforcing this
  // here protects every caller (main play and ranked) instead of relying only on UI visibility.
  if (typeof chess?.turn === 'function' && chess.turn() === color) return null;
  // A hard cap bounds virtual-board replay and repaint cost on low-memory Android WebViews.
  if (current.length >= MAX_PREMOVE_QUEUE) return null;
  const preview = buildPremovePosition(chess, color, current, ChessConstructor);
  if (!preview) return null;
  try {
    const piece = preview.get(from);
    if (!piece || piece.color !== color) return null;
    const candidates = premoveCandidates(preview, color, from).filter(move => move.to === to);
    if (!candidates.length) return null;
    const { ok, promotion: chosen } = normalizePromotion(candidates, promotion);
    if (!ok) return null;
    return [...current, { from, to, promotion: chosen }];
  } catch {
    return null;
  }
}

/** Resolve a stored premove against the actual post-opponent position. */
export function resolveQueuedPremove(chess, intent, color) {
  if (!chess || !intent || chess.turn?.() !== color || !SQUARE.test(String(intent.from || '')) || !SQUARE.test(String(intent.to || ''))) return null;
  try {
    const candidates = chess.moves({ verbose: true }).filter(move => move.from === intent.from && move.to === intent.to);
    if (!candidates.length) return null;
    const isPromotion = candidates.some(move => Boolean(move.promotion));
    const promotion = isPromotion ? (PROMOTIONS.includes(intent.promotion) ? intent.promotion : 'q') : null;
    const move = candidates.find(candidate => (candidate.promotion || null) === promotion);
    return move ? { from: move.from, to: move.to, ...(move.promotion ? { promotion: move.promotion } : {}) } : null;
  } catch {
    return null;
  }
}

/**
 * Take the first intent of the queue and resolve it on the real board.
 * `{ move, rest }` — when the first intent is no longer legal the whole queue is dropped
 * (`move: null, rest: []`), exactly like chess.com cancels premoves after a different reply.
 */
export function takeNextPremove(chess, queue, color) {
  const list = Array.isArray(queue) ? queue : [];
  if (!list.length) return { move: null, rest: [], cancelled: [] };
  const move = resolveQueuedPremove(chess, list[0], color);
  if (!move) return { move: null, rest: [], cancelled: list };
  return { move, rest: list.slice(1), cancelled: [] };
}

/** Square sets used to paint the queue (origin and destination of every queued move). */
export function premoveSquares(queue) {
  const from = new Set();
  const to = new Set();
  const list = Array.isArray(queue) ? queue : [];
  for (const intent of list) { from.add(intent.from); to.add(intent.to); }
  return { from, to };
}

/** True when `square` is the origin or destination of any queued move. */
export function isPremoveSquare(queue, square) {
  return (Array.isArray(queue) ? queue : []).some(intent => intent.from === square || intent.to === square);
}

/** Short Vietnamese summary for the status line / screen readers. */
export function describePremoveQueue(queue) {
  const list = Array.isArray(queue) ? queue : [];
  if (!list.length) return '';
  const text = list.map(intent => `${intent.from}→${intent.to}${intent.promotion ? `=${intent.promotion.toUpperCase()}` : ''}`).join(', ');
  return `${list.length} nước đi trước: ${text}`;
}
