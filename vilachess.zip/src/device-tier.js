/**
 * Device quality detection for VILA Chess (Vanilla JS + Capacitor).
 *
 * Device.getInfo() supplies reliable platform/model/OS metadata; Android's native bridge supplies
 * exact RAM/CPU/API/power-saver data when available. Browser hints remain a fallback. Keeping this
 * service framework-free avoids adding React state or work to the board's 60 Hz pointer path.
 */
export const DEVICE_QUALITY = Object.freeze(['low', 'medium', 'high']);
const GB = 1024 ** 3;
const OVERRIDE_KEY = 'vila.perfMode';

const TIER_CONFIG = Object.freeze({
  low: Object.freeze({ useShadow: false, useGhost: false, useHaptic: false, snapDuration: 100, dragScale: 1 }),
  medium: Object.freeze({ useShadow: true, useGhost: true, useHaptic: true, snapDuration: 150, dragScale: 1.1 }),
  high: Object.freeze({ useShadow: true, useGhost: true, useHaptic: true, snapDuration: 150, dragScale: 1.15 })
});

let activeTier = 'medium';
let manualTier = null;
let latestDeviceInfo = Object.freeze({});
const listeners = new Set();

function finitePositive(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function majorVersion(value) {
  const parsed = Number.parseFloat(String(value ?? '').replace(/_/g, '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

export function androidApiFromUserAgent(userAgent = '') {
  const match = String(userAgent).match(/Android\s([\d.]+)/i);
  if (!match) return null;
  const version = match[1].split('.').map(Number);
  const major = version[0] || 0;
  const minor = version[1] || 0;
  if (major < 5) return 19;
  if (major === 5) return minor >= 1 ? 22 : 21;
  if (major === 6) return 23;
  if (major === 7) return minor >= 1 ? 25 : 24;
  if (major === 8) return minor >= 1 ? 27 : 26;
  if (major === 9) return 28;
  if (major === 10) return 29;
  if (major === 11) return 30;
  if (major === 12) return minor >= 1 ? 32 : 31;
  if (major === 13) return 33;
  if (major === 14) return 34;
  if (major === 15) return 35;
  if (major >= 16) return 36;
  return null;
}

export function iosVersionFromUserAgent(userAgent = '') {
  const match = String(userAgent).match(/(?:iPhone|iPad|iPod).*?OS\s([\d_]+)/i)
    || String(userAgent).match(/CPU (?:iPhone )?OS\s([\d_]+)/i);
  if (!match) return null;
  const parsed = Number(match[1].replace(/_/g, '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

/** Android native bridge is more precise than browser memory hints and remains available offline. */
export function readNativeDeviceInfo(win = typeof window !== 'undefined' ? window : null) {
  try {
    const raw = win?.AndroidBridge?.getDeviceTierInfo?.();
    if (!raw) return {};
    const parsed = typeof raw === 'string' ? JSON.parse(raw) : raw;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

/**
 * Synchronous detector used at startup/tests. LOW triggers when any hard low-end constraint is met:
 * RAM <= 3 GB, CPU <= 4 cores, pre-Android-10, iOS < 14, or system power saver enabled.
 */
export function detectDeviceTier(
  win = typeof window !== 'undefined' ? window : null,
  nativeInfo = readNativeDeviceInfo(win),
  capacitorInfo = latestDeviceInfo
) {
  const nav = win?.navigator || {};
  const ua = String(nav.userAgent || '');
  const platform = String(capacitorInfo?.platform || '').toLowerCase();
  const model = String(capacitorInfo?.model || '');
  const manufacturer = String(capacitorInfo?.manufacturer || '');
  const osVersionText = String(capacitorInfo?.osVersion || '');
  const totalRamBytes = finitePositive(nativeInfo?.totalRamBytes);
  const reportedRamGb = finitePositive(nav.deviceMemory);
  const ramGb = totalRamBytes ? totalRamBytes / GB : reportedRamGb;
  const cores = finitePositive(nativeInfo?.cpuCores) || finitePositive(nav.hardwareConcurrency);
  const androidApi = finitePositive(nativeInfo?.androidApiLevel) || androidApiFromUserAgent(ua);
  const iosVersion = iosVersionFromUserAgent(ua) ?? (platform === 'ios' ? majorVersion(osVersionText) : null);
  const powerSaveMode = nativeInfo?.powerSaveMode === true;
  const modelKey = `${manufacturer} ${model}`.toLowerCase();
  // These model families are commonly sold in 2 GB configurations; treat them conservatively when
  // Android does not expose total RAM to WebView. Exact device RAM from the native bridge wins.
  const conservativeLowModel = /\b(sm-a015|sm-a022|galaxy a01|galaxy a02|redmi 9a|m2006c3l[gi])\b/i.test(modelKey);
  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(ua)
    || platform === 'android' || platform === 'ios'
    || Boolean(win?.matchMedia?.('(pointer: coarse)')?.matches);

  const low = powerSaveMode
    || (ramGb !== null && ramGb <= 3)
    || (cores !== null && cores <= 4)
    || (androidApi !== null && androidApi < 29)
    || (iosVersion !== null && iosVersion < 14)
    || (!totalRamBytes && conservativeLowModel);
  if (low) return {
    tier: 'low', isLowEnd: true, ramGb, cores, androidApi, iosVersion, powerSaveMode,
    model, manufacturer, platform, osVersion: osVersionText
  };

  const medium = (ramGb !== null && ramGb < 6)
    || (cores !== null && cores <= 6)
    || (androidApi !== null && androidApi < 33)
    || (iosVersion !== null && iosVersion < 16)
    || Boolean(nav.connection?.saveData)
    || (isMobile && (ramGb === null || cores === null));
  return {
    tier: medium ? 'medium' : 'high', isLowEnd: false, ramGb, cores, androidApi, iosVersion,
    powerSaveMode, model, manufacturer, platform, osVersion: osVersionText
  };
}

export function useDeviceTier() {
  // Keep the historical snapshot shape stable for existing callers/tests; live feature flags are
  // exposed by the `deviceTier` getter object below so consumers never hold stale config copies.
  return Object.freeze({ tier: activeTier, isLowEnd: activeTier === 'low' });
}

export function subscribeDeviceTier(listener) {
  if (typeof listener !== 'function') return () => {};
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function publishDeviceTier(tier) {
  if (!DEVICE_QUALITY.includes(tier) || tier === activeTier) return false;
  activeTier = tier;
  const snapshot = useDeviceTier();
  for (const listener of [...listeners]) {
    try { listener(snapshot); } catch { /* A subscriber must never break board input. */ }
  }
  return true;
}

/**
 * User override for Settings. 'auto' clears the override; LOW/MEDIUM/HIGH update the live config.
 * The perf governor listens to the event so the setting and its DOM quality attributes stay in sync.
 */
export function setTier(tier) {
  const next = tier === 'auto' ? 'auto' : DEVICE_QUALITY.includes(tier) ? tier : null;
  if (!next) return false;
  manualTier = next === 'auto' ? null : next;
  try { localStorage.setItem(OVERRIDE_KEY, next); } catch { /* The in-memory preference still applies. */ }
  if (manualTier) publishDeviceTier(manualTier);
  try {
    if (typeof window !== 'undefined' && typeof window.CustomEvent === 'function') {
      window.dispatchEvent(new window.CustomEvent('vila:quality-override', { detail: { tier: next } }));
    }
  } catch { /* Settings must also work in restricted WebViews. */ }
  return true;
}

export function getTierOverride() { return manualTier; }
export function getTierConfig(tier = activeTier) { return TIER_CONFIG[DEVICE_QUALITY.includes(tier) ? tier : 'medium']; }
export function getDeviceSnapshot() { return { ...latestDeviceInfo }; }

/** Read Capacitor Device metadata asynchronously without blocking the first frame or board gestures. */
export async function initializeDeviceTier({
  win = typeof window !== 'undefined' ? window : null,
  nativeInfo = readNativeDeviceInfo(win)
} = {}) {
  let capacitorInfo = {};
  try {
    // Dynamic import keeps Node-side pure tests and ordinary browsers usable when the native plugin
    // has not been installed/registered; Vite still bundles the declared Capacitor dependency.
    const { Device } = await import('@capacitor/device');
    capacitorInfo = await Device.getInfo();
  } catch { /* Browser fallback and AndroidBridge remain valid when Capacitor is unavailable. */ }
  latestDeviceInfo = Object.freeze({
    model: String(capacitorInfo?.model || ''),
    manufacturer: String(capacitorInfo?.manufacturer || ''),
    platform: String(capacitorInfo?.platform || ''),
    operatingSystem: String(capacitorInfo?.operatingSystem || ''),
    osVersion: String(capacitorInfo?.osVersion || ''),
    isVirtual: Boolean(capacitorInfo?.isVirtual)
  });
  const detection = detectDeviceTier(win, nativeInfo, latestDeviceInfo);
  if (!manualTier) publishDeviceTier(detection.tier);
  return { ...detection, overridden: Boolean(manualTier), tier: manualTier || detection.tier };
}

/** Live configuration object: consumers can read the effective values without copying stale state. */
export const deviceTier = Object.freeze({
  get tier() { return activeTier; },
  get isLowEnd() { return activeTier === 'low'; },
  get useShadow() { return TIER_CONFIG[activeTier].useShadow; },
  get useGhost() { return TIER_CONFIG[activeTier].useGhost; },
  get useHaptic() { return TIER_CONFIG[activeTier].useHaptic; },
  get snapDuration() { return TIER_CONFIG[activeTier].snapDuration; },
  get dragScale() { return TIER_CONFIG[activeTier].dragScale; },
  setTier,
  get config() { return TIER_CONFIG[activeTier]; }
});
