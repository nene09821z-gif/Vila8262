/** Three-level adaptive quality governor. Keeps the legacy data-perf attribute for older CSS. */
import { DEVICE_QUALITY, detectDeviceTier, publishDeviceTier, readNativeDeviceInfo, initializeDeviceTier } from './device-tier.js';

export const PERF_KEY = 'vila.perfTier'; // Last effective tier, retained for diagnostics/migration only.
export const PERF_MODE_KEY = 'vila.perfMode'; // auto | low | medium | high
export const MIN_FRAMES = 14;
export const JANK_RATIO = 0.2;
export const STARTUP_JANK_RATIO = 0.3;
export const FPS_FLOOR = 45;
export const FPS_WINDOW_MS = 3000;

const median = list => { const s = [...list].sort((a, b) => a - b); return s.length ? s[Math.floor(s.length / 2)] : 0; };

/** Frame deltas (ms) -> { count, medianMs, p95Ms, jankRatio, fps }. */
export function summarizeFrames(deltas) {
  const list = (deltas || []).filter(d => Number.isFinite(d) && d > 0 && d < 1000);
  if (!list.length) return { count: 0, medianMs: 0, p95Ms: 0, jankRatio: 0, fps: 0 };
  const med = median(list);
  const limit = Math.max(24, med * 1.8);
  const sorted = [...list].sort((a, b) => a - b);
  const p95 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))];
  const janky = list.filter(d => d > limit).length;
  return { count: list.length, medianMs: med, p95Ms: p95, jankRatio: janky / list.length, fps: 1000 / (list.reduce((a, b) => a + b, 0) / list.length) };
}

export function nextLowerTier(current) {
  const index = DEVICE_QUALITY.indexOf(current);
  return index <= 0 ? 'low' : DEVICE_QUALITY[index - 1];
}

function readUrlOverride(search) {
  try {
    const value = new URLSearchParams(search || '').get('perf');
    if (DEVICE_QUALITY.includes(value)) return value;
    if (value === 'lite') return 'low';
    if (value === 'full') return 'high';
    return value === '1' ? 'probe' : '';
  } catch { return ''; }
}

function isDevBuild() {
  try { return Boolean(import.meta.env?.DEV); } catch { return false; }
}

export function createPerfGovernor({
  win = typeof window !== 'undefined' ? window : null,
  doc = typeof document !== 'undefined' ? document : null,
  storage = (() => { try { return win?.localStorage || null; } catch { return null; } })(),
  raf = win?.requestAnimationFrame?.bind(win),
  caf = win?.cancelAnimationFrame?.bind(win),
  now = () => (win?.performance?.now ? win.performance.now() : Date.now()),
  deviceInfo = readNativeDeviceInfo(win),
  dev = isDevBuild()
} = {}) {
  let history = [];
  let session = null;
  let probe = null;
  const override = readUrlOverride(win?.location?.search);
  let mode = '';
  try { mode = storage?.getItem(PERF_MODE_KEY) || 'auto'; } catch { mode = 'auto'; }
  if (!['auto', ...DEVICE_QUALITY].includes(mode)) mode = 'auto';
  if (override && override !== 'probe') mode = override;
  let locked = override !== '' && override !== 'probe' || mode !== 'auto';
  let detection = detectDeviceTier(win, deviceInfo);
  let tier = override && override !== 'probe' ? override : mode === 'auto' ? detection.tier : mode;
  const logChange = (previous, next, reason) => {
    if (previous === next || !isDevBuild()) return;
    try { console.info(`[VILA quality] ${previous} -> ${next} (${reason})`); } catch { /* dev diagnostics only */ }
  };

  const apply = (next, reason = 'manual', persist = true) => {
    if (!DEVICE_QUALITY.includes(next)) return false;
    const previous = tier;
    tier = next;
    if (doc?.documentElement) {
      doc.documentElement.dataset.quality = next;
      // Old visual layer still keys off data-perf="lite"; keep it compatible while adding three tiers.
      doc.documentElement.dataset.perf = next === 'low' ? 'lite' : 'full';
    }
    publishDeviceTier(next);
    if (persist && storage && !override) {
      try { storage.setItem(PERF_KEY, next); } catch { /* Private browsing may disable storage. */ }
    }
    logChange(previous, next, reason);
    if (previous !== next && win?.dispatchEvent && typeof win.CustomEvent === 'function') {
      try { win.dispatchEvent(new win.CustomEvent('vila:quality-changed', { detail: { previous, tier: next, reason } })); } catch { /* Older WebViews may not expose CustomEvent on window. */ }
    }
    return previous !== next;
  };

  const lowerOne = reason => {
    if (locked || tier === 'low') return false;
    return apply(nextLowerTier(tier), reason);
  };

  const showProbe = summary => {
    if (!dev || override !== 'probe' || !doc?.body) return;
    if (!probe) {
      probe = doc.createElement('div');
      probe.setAttribute('aria-hidden', 'true');
      probe.style.cssText = 'position:fixed;left:6px;top:calc(env(safe-area-inset-top,0px) + 4px);z-index:2147483000;padding:4px 7px;border-radius:8px;background:rgba(0,0,0,.78);color:#9f9;font:11px/1.3 monospace;pointer-events:none;white-space:pre';
      doc.body.appendChild(probe);
    }
    probe.textContent = `quality ${tier} · ${summary.label}\nfps ${summary.fps.toFixed(0)} · p95 ${summary.p95Ms.toFixed(0)}ms · jank ${(summary.jankRatio * 100).toFixed(0)}% · n=${summary.count}`;
  };

  apply(tier, 'startup', false);

  // Capacitor Device metadata is read asynchronously so it cannot delay the first board paint.
  // Exact Android RAM/CPU/API/power-saver hints continue to come from the native bridge.
  if (mode === 'auto' && !locked) {
    void initializeDeviceTier({ win, nativeInfo: deviceInfo }).then(info => {
      detection = info;
      if (mode === 'auto' && !session) apply(info.tier, 'capacitor-device-info');
    }).catch(() => {});
  }

  function begin(label = 'drag') {
    // Frame sampling is deliberately dev-only; production should not keep an RAF loop alive.
    if (!dev || session || !raf) return false;
    session = { label, deltas: [], last: 0, windowStart: 0, windowFrames: 0, id: 0 };
    const tick = stamp => {
      const active = session;
      if (!active) return;
      if (!active.last) {
        active.last = stamp;
        active.windowStart = stamp;
      } else {
        active.deltas.push(stamp - active.last);
        active.windowFrames += 1;
        active.last = stamp;
      }
      if (active.windowStart && stamp - active.windowStart >= FPS_WINDOW_MS) {
        const elapsed = stamp - active.windowStart;
        const fps = active.windowFrames * 1000 / elapsed;
        if (fps < FPS_FLOOR) lowerOne(`fps<${FPS_FLOOR} for ${FPS_WINDOW_MS}ms`);
        active.windowStart = stamp;
        active.windowFrames = 0;
      }
      active.id = raf(tick);
    };
    session.id = raf(tick);
    return true;
  }

  /** `onlyLabel` lets a timed session (a slide) end without cutting a drag that started meanwhile. */
  function end(onlyLabel) {
    if (!session || (onlyLabel && session.label !== onlyLabel)) return null;
    const done = session; session = null;
    try { caf?.(done.id); } catch { /* ignore */ }
    const summary = { ...summarizeFrames(done.deltas), label: done.label };
    if (summary.count >= MIN_FRAMES) history = [...history, summary].slice(-6);
    showProbe(summary);
    return summary;
  }

  /** Startup probe uses the same 3-second, 45-fps floor; no visual FPS overlay is enabled in production. */
  function sampleStartup(durationMs = FPS_WINDOW_MS) {
    if (!dev || !raf || locked || session || override === 'probe') return false;
    const deltas = []; let last = 0; let first = 0; let id = 0;
    const tick = stamp => {
      if (!first) first = stamp;
      if (last) deltas.push(stamp - last);
      last = stamp;
      if (stamp - first < durationMs) { id = raf(tick); return; }
      const summary = summarizeFrames(deltas.slice(3));
      if (summary.count >= 24 && summary.fps < FPS_FLOOR) lowerOne(`startup fps<${FPS_FLOOR}`);
      showProbe({ ...summary, label: 'startup' });
    };
    id = raf(tick);
    return () => { try { caf?.(id); } catch { /* ignore */ } };
  }

  function setMode(nextMode) {
    const valid = ['auto', ...DEVICE_QUALITY].includes(nextMode) ? nextMode : 'auto';
    mode = valid;
    locked = mode !== 'auto' || (override !== '' && override !== 'probe');
    if (storage && !override) {
      try { storage.setItem(PERF_MODE_KEY, mode); } catch { /* Storage is optional. */ }
    }
    if (mode === 'auto') {
      detection = detectDeviceTier(win, readNativeDeviceInfo(win));
      return apply(detection.tier, 'auto-detect');
    }
    return apply(mode, 'user-override');
  }

  function refreshDeviceInfo() {
    if (mode !== 'auto' || locked) return detection;
    detection = detectDeviceTier(win, readNativeDeviceInfo(win));
    // Re-check on foreground: turning Android Battery Saver off may safely restore the detected tier.
    if (!session) apply(detection.tier, 'device-refresh');
    return detection;
  }

  if (doc?.addEventListener) {
    doc.addEventListener('visibilitychange', () => { if (!doc.hidden) refreshDeviceInfo(); }, { passive: true });
  }
  // Expose the shared deviceTier.setTier() API to the existing Settings/performance governor.
  const qualityOverrideListener = event => {
    const requested = event?.detail?.tier;
    if (requested === 'auto' || DEVICE_QUALITY.includes(requested)) setMode(requested);
  };
  win?.addEventListener?.('vila:quality-override', qualityOverrideListener);

  return {
    begin, end, sampleStartup, setMode, refreshDeviceInfo,
    get tier() { return tier; },
    get mode() { return mode; },
    get isLowEnd() { return tier === 'low'; },
    get detection() { return { ...detection }; },
    get history() { return history.slice(); },
    force: (next, reason = 'forced') => apply(next, reason),
    _now: now
  };
}
