/**
 * Example Capacitor 7 lifecycle bridge for ChessPlus ranked games.
 * Install first: npm install @capacitor/app@^7 && npx cap sync android
 *
 * This project uses REST polling, not Socket.IO/WebSocket. The callback must
 * GET /api/social/ranked/status, reconcile the authoritative server state,
 * and restart the existing ranked poll timer. Never replay an unconfirmed move.
 */
import { App } from '@capacitor/app';

export function installRankedReconnect({
  isRankedSessionActive,
  syncRankedFromServer,
  onConnectionChange = () => {}
} = {}) {
  if (typeof isRankedSessionActive !== 'function' || typeof syncRankedFromServer !== 'function') {
    throw new TypeError('installRankedReconnect requires isRankedSessionActive and syncRankedFromServer callbacks.');
  }

  let disposed = false;
  let nativeActive = true;
  let syncing = false;
  let pendingReason = '';
  let retryTimer = null;
  let retryAttempt = 0;
  let lastSyncAt = 0;
  let appListenerHandle = null;

  const clearRetry = () => {
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = null;
  };

  const scheduleRetry = () => {
    clearRetry();
    if (disposed || !nativeActive || document.hidden || !navigator.onLine || !isRankedSessionActive()) return;
    const delay = Math.min(15_000, 1_000 * (2 ** Math.min(retryAttempt, 4)));
    retryAttempt += 1;
    retryTimer = setTimeout(() => {
      retryTimer = null;
      void reconcile('retry');
    }, delay);
  };

  async function reconcile(reason = 'resume') {
    if (disposed || !nativeActive || document.hidden || !navigator.onLine || !isRankedSessionActive()) return;
    if (syncing) {
      pendingReason = reason;
      return;
    }
    // Several lifecycle signals can fire together. Coalesce them into one request.
    if (Date.now() - lastSyncAt < 500) return;
    syncing = true;
    lastSyncAt = Date.now();
    clearRetry();
    try {
      await syncRankedFromServer({ reason });
      retryAttempt = 0;
      onConnectionChange({ online: true, reason });
    } catch (error) {
      onConnectionChange({ online: false, reason, error });
      scheduleRetry();
    } finally {
      syncing = false;
      if (pendingReason) {
        const nextReason = pendingReason;
        pendingReason = '';
        void reconcile(nextReason);
      }
    }
  }

  const handleVisibility = () => {
    if (!document.hidden) void reconcile('visibilitychange');
  };
  const handleOnline = () => void reconcile('online');
  const handlePageShow = () => void reconcile('pageshow');
  const handleOffline = () => {
    clearRetry();
    onConnectionChange({ online: false, reason: 'offline' });
  };

  document.addEventListener('visibilitychange', handleVisibility, { passive: true });
  window.addEventListener('online', handleOnline, { passive: true });
  window.addEventListener('offline', handleOffline, { passive: true });
  window.addEventListener('pageshow', handlePageShow, { passive: true });

  const listenerPromise = App.addListener('appStateChange', ({ isActive }) => {
    nativeActive = Boolean(isActive);
    if (nativeActive) void reconcile('capacitor-app-resume');
    else clearRetry(); // do not send resign/abandon merely because the app is backgrounded
  });
  void listenerPromise.then(handle => { appListenerHandle = handle; }).catch(error => {
    // Browser/PWA fallback remains available when the native plugin is unavailable.
    onConnectionChange({ online: navigator.onLine, reason: 'capacitor-listener-unavailable', error });
  });

  return {
    syncNow: (reason = 'manual') => reconcile(reason),
    dispose() {
      if (disposed) return;
      disposed = true;
      clearRetry();
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('pageshow', handlePageShow);
      if (appListenerHandle) void appListenerHandle.remove();
      else void listenerPromise.then(handle => handle.remove()).catch(() => {});
    }
  };
}
