import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessState } from '../cloudflare/src/index.js';

function createHarness() {
  const records = new Map();
  const sql = {
    exec(statement, ...args) {
      if (/^CREATE TABLE/i.test(statement)) return [];
      if (/^SELECT key, value FROM vila_records/i.test(statement)) {
        return [...records.entries()].map(([key, value]) => ({ key, value }));
      }
      if (/^INSERT INTO vila_records/i.test(statement)) {
        records.set(String(args[0]), String(args[1]));
        return [];
      }
      if (/^DELETE FROM vila_records/i.test(statement)) {
        records.delete(String(args[0]));
        return [];
      }
      throw new Error(`SQL statement not covered by test harness: ${statement}`);
    }
  };
  const makeState = () => ({
    storage: { sql, transactionSync: callback => callback() },
    blockConcurrencyWhile: callback => callback()
  });
  let object = new ChessState(makeState(), {});
  const binding = {
    idFromName: () => 'vila-global-test',
    get: () => ({ fetch: request => object.fetch(request) })
  };
  return {
    binding,
    records,
    restart() { object = new ChessState(makeState(), {}); }
  };
}

function makeRequest(path, { method = 'GET', token = '', body } = {}) {
  const headers = {};
  if (token) headers.Authorization = `Bearer ${token}`;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  return new Request(`https://vila-test.workers.dev${path}`, {
    method,
    headers,
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
}

async function call(harness, path, options = {}) {
  const response = await worker.fetch(makeRequest(path, options), { CHESS_STATE: harness.binding });
  const data = await response.json();
  return { status: response.status, data };
}

test('Cloudflare backend runtime: health, auth, random matchmaking, legal move, persistence and resign', async () => {
  const harness = createHarness();
  let result = await call(harness, '/api/health');
  assert.equal(result.status, 200);
  assert.equal(result.data.ok, true);

  result = await call(harness, '/api/social/health');
  assert.equal(result.status, 200);
  assert.equal(result.data.status, 'online');

  result = await call(harness, '/api/social/ranked/status');
  assert.equal(result.status, 401, 'ranked endpoints require an authenticated account');

  const alice = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'alice', displayName: 'Alice', password: 'Password!1', initialElo: 1200 }
  });
  assert.equal(alice.status, 201, JSON.stringify(alice.data));
  assert.ok(alice.data.token);
  assert.equal(alice.data.user.username, 'alice');

  const bob = await call(harness, '/api/social/auth/register', {
    method: 'POST', body: { username: 'bob', displayName: 'Bob', password: 'Password!2', initialElo: 1200 }
  });
  assert.equal(bob.status, 201, JSON.stringify(bob.data));
  assert.ok(bob.data.token);

  const queued = await call(harness, '/api/social/ranked/queue', {
    method: 'POST', token: alice.data.token, body: { timeControl: '3+2' }
  });
  assert.equal(queued.status, 202);
  assert.equal(queued.data.queued, true);

  const paired = await call(harness, '/api/social/ranked/queue', {
    method: 'POST', token: bob.data.token, body: { timeControl: '3+2' }
  });
  assert.equal(paired.status, 201, JSON.stringify(paired.data));
  assert.ok(paired.data.match?.id);

  const aliceStatus = await call(harness, '/api/social/ranked/status', { token: alice.data.token });
  const bobStatus = await call(harness, '/api/social/ranked/status', { token: bob.data.token });
  assert.equal(aliceStatus.data.match.id, bobStatus.data.match.id);
  assert.notEqual(aliceStatus.data.match.color, bobStatus.data.match.color);

  const white = aliceStatus.data.match.color === 'w' ? alice : bob;
  const black = aliceStatus.data.match.color === 'b' ? alice : bob;
  const matchId = aliceStatus.data.match.id;

  const illegal = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: white.data.token, body: { from: 'e2', to: 'e5', expectedPly: 0 }
  });
  assert.equal(illegal.status, 400, 'server rejects an illegal chess move');

  const accepted = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: white.data.token, body: { from: 'e2', to: 'e4', expectedPly: 0 }
  });
  assert.equal(accepted.status, 200, JSON.stringify(accepted.data));
  assert.equal(accepted.data.match.moves.length, 1);
  assert.equal(accepted.data.match.fen.split(' ')[1], 'b');

  const stale = await call(harness, `/api/social/ranked/matches/${matchId}/move`, {
    method: 'POST', token: black.data.token, body: { from: 'e7', to: 'e5', expectedPly: 0 }
  });
  assert.equal(stale.status, 409, 'stale ply is rejected rather than overwriting a move');

  // Recreate the Durable Object from persisted rows to emulate a cold start.
  harness.restart();
  const persisted = await call(harness, '/api/social/auth/me', { token: alice.data.token });
  assert.equal(persisted.status, 200, JSON.stringify(persisted.data));
  assert.equal(persisted.data.user.username, 'alice');

  const resigned = await call(harness, `/api/social/ranked/matches/${matchId}/resign`, {
    method: 'POST', token: white.data.token, body: {}
  });
  assert.equal(resigned.status, 200, JSON.stringify(resigned.data));
  assert.equal(resigned.data.match.status, 'finished');
  assert.ok(harness.records.size > 0, 'the DO storage persisted account and match rows');
});
