import test from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULTS, DEFAULT_BACKEND_URL, normalizeSettings } from '../src/settings-schema.js';

test('empty or malformed storage falls back to safe offline chess defaults', () => {
  assert.equal(normalizeSettings(null).botEngine, DEFAULTS.botEngine);
  assert.equal(normalizeSettings([]).clockPreset, DEFAULTS.clockPreset);
  assert.equal(normalizeSettings({ botEngine: 'not-an-engine' }).botEngine, 'auto');
});

test('legacy AI provider credentials, endpoint and chat profiles are discarded on migration', () => {
  const value = normalizeSettings({
    apiKey: 'do-not-keep-this', endpoint: 'https://old-provider.example/v1', model: 'old-model', aiMode: 'gemini',
    temperature: 0.4, aiProfiles: [{ id: 'old', apiKey: 'also-secret', endpoint: 'https://old.example/v1' }],
    botSkill: 16, openingBookEnabled: false
  });
  for (const key of ['apiKey', 'endpoint', 'model', 'aiMode', 'temperature', 'aiProfiles']) assert.equal(key in value, false, `${key} must be removed`);
  assert.equal(value.botSkill, 16);
  assert.equal(value.openingBookEnabled, false);
});

test('numeric chess-engine settings are clamped to supported ranges', () => {
  const value = normalizeSettings({ botSkill: -2, botElo: 99999, botDepth: 0, botMoveTimeMs: 10, analysisMoveTimeMs: 90000 });
  assert.equal(value.botSkill, 0);
  assert.equal(value.botElo, 3200);
  assert.equal(value.botDepth, 5);
  assert.equal(value.botMoveTimeMs, 500);
  assert.equal(value.analysisMoveTimeMs, 8000);
});

test('engine choice migrations keep valid explicit preferences and reject unknown profiles', () => {
  assert.equal(normalizeSettings({ botEngine: 'lite-single' }).botEngine, 'auto');
  assert.equal(normalizeSettings({ botEngine: 'lite-single', botEnginePreferenceSet: true }).botEngine, 'lite-single');
  assert.equal(normalizeSettings({ botEngine: 'mystery' }).botEngine, 'auto');
  assert.equal(normalizeSettings({ alternativeEngine: 'mystery' }).alternativeEngine, DEFAULTS.alternativeEngine);
});

test('community backend uses the baked-in cloud URL while preserving safe custom URLs', () => {
  assert.equal(DEFAULT_BACKEND_URL, 'https://bitter-sun-751a.nene09821z.workers.dev');
  assert.equal(normalizeSettings({}).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: '' }).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'file:///etc/passwd' }).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'https://user:pass@example.com' }).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'https://example.com/vila/' }).backendUrl, 'https://example.com/vila');
  assert.equal(normalizeSettings({ backendUrl: 'https://old.trycloudflare.com' }).backendUrl, DEFAULT_BACKEND_URL);
  assert.equal(normalizeSettings({ backendUrl: 'http://localhost:8787' }).backendUrl, DEFAULT_BACKEND_URL, 'migrate an old Termux/local API endpoint');
  assert.equal(normalizeSettings({ backendUrl: 'https://test.ngrok-free.app' }).backendUrl, DEFAULT_BACKEND_URL, 'migrate an old temporary tunnel');
});

test('clock and strength settings normalize safely', () => {
  const normal = normalizeSettings({ botStrengthMode: 'elo', botElo: 500, clockPreset: '3+2', soundEnabled: false });
  assert.equal(normal.botStrengthMode, 'elo');
  assert.equal(normal.botElo, 500);
  assert.equal(normal.clockPreset, '3+2');
  assert.equal(normal.soundEnabled, false);
  assert.equal(normalizeSettings({ clockPreset: 'broken' }).clockPreset, '10+0');
});

test('default chess strength is improved and implicit LC0-style fallback migrates to tactical VILA fallback', () => {
  assert.equal(DEFAULTS.botDepth, 30);
  assert.equal(DEFAULTS.botMoveTimeMs, 2600);
  assert.equal(DEFAULTS.alternativeEngine, 'ethereal');
  assert.equal(normalizeSettings({ alternativeEngine: 'lc0' }).alternativeEngine, 'ethereal');
  assert.equal(normalizeSettings({ alternativeEngine: 'lc0', alternativeEnginePreferenceSet: true }).alternativeEngine, 'lc0');
  assert.equal(normalizeSettings({ botDepth: 18, botMoveTimeMs: 1200 }).botDepth, 30, 'migrate old implicit search defaults');
  assert.equal(normalizeSettings({ botDepth: 18, botMoveTimeMs: 1200 }).botMoveTimeMs, 2600, 'migrate old implicit search time');
  assert.equal(normalizeSettings({ botDepth: 22, botMoveTimeMs: 1600 }).botDepth, 30, 'upgrade prior implicit defaults');
  assert.equal(normalizeSettings({ botDepth: 22, botMoveTimeMs: 1600 }).botMoveTimeMs, 2600, 'upgrade prior implicit time');
  assert.equal(normalizeSettings({ botDepth: 12, botMoveTimeMs: 1200 }).botDepth, 12, 'preserve tuned depth');
  assert.equal(normalizeSettings({ botDepth: 18, botMoveTimeMs: 1200, botSearchSettingsPreferenceSet: true }).botDepth, 18, 'respect explicit preference');
});
