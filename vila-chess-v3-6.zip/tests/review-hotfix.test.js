import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { PHASE_ICONS } from '../src/review-screen.js';
import { detectDeviceTier } from '../src/device-tier.js';

const main = fs.readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');

test('reviewKeyboardShortcutsBound is declared before use (fixes "is not defined" on review screen)', () => {
  const decl = main.search(/let reviewKeyboardShortcutsBound\s*=\s*false/);
  const use = main.indexOf('if (!reviewKeyboardShortcutsBound)');
  assert.ok(decl >= 0 && use > decl);
});

test('phase icons are inline SVG, not platform glyph characters', () => {
  for (const key of ['opening', 'middlegame', 'endgame']) {
    assert.match(PHASE_ICONS[key], /^<svg[\s\S]*<path/);
    assert.doesNotMatch(PHASE_ICONS[key], /[♔-♟]/);
  }
  const src = fs.readFileSync(new URL('../src/review-screen.js', import.meta.url), 'utf8');
  assert.doesNotMatch(src, /\['opening', 'Khai cuộc', '[♔-♟]'\]/);
});

test('weak devices start in the low tier, strong ones do not, and a missing window is safe', () => {
  const win = (extra = {}, coarse = true) => ({ navigator: { deviceMemory: 4, hardwareConcurrency: 8, ...extra }, matchMedia: q => ({ matches: q.includes('coarse') ? coarse : false }) });
  const tier = w => detectDeviceTier(w, null, null).tier;
  assert.equal(tier(win({ deviceMemory: 2 })), 'low');
  assert.equal(tier(win({ hardwareConcurrency: 4 })), 'low');
  assert.equal(tier(win()), 'medium');
  assert.equal(tier(win({ deviceMemory: 16, hardwareConcurrency: 16 }, false)), 'high');
  assert.notEqual(tier(null), 'low');
});
