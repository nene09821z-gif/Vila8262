// Đội chuyên gia cờ vua chạy trên Cloudflare Workers AI.
//
// Nguyên tắc: ENGINE QUYẾT ĐỊNH, BOT GIẢI THÍCH. Nước đi tốt nhất và điểm đánh giá do Stockfish
// trên máy người chơi tính; các bot chỉ diễn giải bằng tiếng Việt nên không "bịa" nước đi.
// Module này không import chess.js: Worker truyền lớp `Chess` vào để kiểm tra FEN/nước đi.

export const DEFAULT_TEAM_MODEL = '@cf/meta/llama-3.1-8b-instruct-fp8';
export const MAX_QUESTION_CHARS = 500;
export const MAX_SPECIALISTS_PER_QUESTION = 3;
export const MAX_REPLY_CHARS = 900;
export const TEAM_MAX_TOKENS = 260;

/** Số câu hỏi mỗi ngày (theo ngày UTC) cho từng gói. Giữ nhỏ để 10.000 Neuron miễn phí/ngày đủ cho nhiều người. */
export const DAILY_QUESTION_LIMITS = Object.freeze({ free: 5, pro: 30, diamond: 60, premium: 100, admin: 500 });

export const SPECIALISTS = Object.freeze([
  {
    id: 'opening', name: 'Chuyên gia khai cuộc', icon: '♞',
    keywords: ['khai cuộc', 'khai cuoc', 'opening', 'sicilian', 'ruy lopez', 'gambit', 'phòng thủ', 'phong thu', 'eco', 'nước đầu', 'nuoc dau', 'sách khai', 'repertoire'],
    focus: 'khai cuộc: ý tưởng của thế cờ, kế hoạch phát triển quân, bẫy thường gặp, khi nào nên rời lý thuyết'
  },
  {
    id: 'tactics', name: 'Chuyên gia chiến thuật', icon: '⚔',
    keywords: ['chiến thuật', 'chien thuat', 'đòn', 'don chien', 'fork', 'ghim', 'pin', 'skewer', 'chiếu', 'chieu', 'bắt đôi', 'bat doi', 'sai lầm', 'sai lam', 'blunder', 'mất quân', 'mat quan', 'ăn quân', 'an quan', 'tactic', 'hy sinh', 'hi sinh'],
    focus: 'chiến thuật: đòn đôi, ghim, nhử quân, nguy cơ mất quân, vì sao nước đi tốt nhất của engine hiệu quả'
  },
  {
    id: 'endgame', name: 'Chuyên gia tàn cuộc', icon: '♚',
    keywords: ['tàn cuộc', 'tan cuoc', 'endgame', 'tốt thông', 'tot thong', 'phong cấp', 'phong cap', 'đối vua', 'doi vua', 'hòa', 'hoa co', 'zugzwang', 'xe tàn', 'ít quân', 'it quan'],
    focus: 'tàn cuộc: vị trí vua, tốt thông, đối vua, quy tắc hòa, kỹ thuật chuyển hóa lợi thế'
  },
  {
    id: 'coach', name: 'Huấn luyện viên', icon: '🎓',
    keywords: ['tại sao', 'tai sao', 'vì sao', 'vi sao', 'giải thích', 'giai thich', 'học', 'hoc', 'cải thiện', 'cai thien', 'luyện', 'luyen', 'điểm yếu', 'diem yeu', 'lời khuyên', 'loi khuyen', 'ván vừa', 'van vua', 'phân tích', 'phan tich'],
    focus: 'huấn luyện: giải thích dễ hiểu, chỉ ra một lỗi tư duy chính và một bài tập nhỏ để luyện'
  },
  {
    id: 'positional', name: 'Chuyên gia thế trận', icon: '♜',
    keywords: ['thế trận', 'the tran', 'cấu trúc tốt', 'cau truc tot', 'ô yếu', 'o yeu', 'cột mở', 'cot mo', 'vị trí quân', 'vi tri quan', 'kế hoạch', 'ke hoach', 'tượng xấu', 'mã đẹp', 'positional', 'strategy', 'chiến lược', 'chien luoc'],
    focus: 'thế trận: cấu trúc tốt, ô yếu, cột mở, quân hoạt động và kế hoạch dài hạn'
  }
]);

const SPECIALIST_BY_ID = new Map(SPECIALISTS.map(item => [item.id, item]));

export function dailyLimitFor(tier) {
  return DAILY_QUESTION_LIMITS[tier] ?? DAILY_QUESTION_LIMITS.free;
}

/** Ngày UTC dạng YYYY-MM-DD; hạn mức Workers AI cũng reset lúc 00:00 UTC. */
export function utcDay(now = Date.now()) {
  return new Date(now).toISOString().slice(0, 10);
}

/**
 * Đếm câu hỏi trong ngày và lưu ngay trên bản ghi người dùng (được Durable Object lưu bền).
 * Trả { allowed, used, limit, remaining, resetsAt } và chỉ tăng bộ đếm khi cho phép.
 */
export function consumeDailyQuestion(user, tier, now = Date.now()) {
  const day = utcDay(now);
  const limit = dailyLimitFor(tier);
  const usage = user.teamUsage && user.teamUsage.day === day ? user.teamUsage : { day, count: 0 };
  const next = new Date(now); next.setUTCHours(24, 0, 0, 0);
  const resetsAt = next.toISOString();
  if (usage.count >= limit) {
    user.teamUsage = usage;
    return { allowed: false, used: usage.count, limit, remaining: 0, resetsAt };
  }
  usage.count += 1;
  user.teamUsage = usage;
  return { allowed: true, used: usage.count, limit, remaining: limit - usage.count, resetsAt };
}

/** Hoàn lại 1 lượt khi bot lỗi để người chơi không bị mất lượt vì lỗi của máy chủ. */
export function refundDailyQuestion(user, now = Date.now()) {
  if (user.teamUsage && user.teamUsage.day === utcDay(now) && user.teamUsage.count > 0) user.teamUsage.count -= 1;
}

function cleanText(value, max) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

/**
 * Kiểm tra và chuẩn hóa dữ liệu client gửi lên. Ném lỗi có `message` tiếng Việt khi dữ liệu sai.
 * `Chess` là lớp chess.js do Worker truyền vào.
 */
export function parseTeamRequest(body, { Chess } = {}) {
  const question = cleanText(body?.question, MAX_QUESTION_CHARS);
  if (question.length < 2) throw new TeamInputError('Hãy nhập câu hỏi cho đội chuyên gia.');
  const out = { question, fen: '', sideToMove: '', legalMoveCount: 0, engine: null, history: '', specialists: [] };
  const fen = cleanText(body?.fen, 100);
  if (fen) {
    if (!Chess) throw new TeamInputError('Máy chủ chưa sẵn sàng kiểm tra thế cờ.');
    let game;
    try { game = new Chess(fen); } catch { throw new TeamInputError('Thế cờ (FEN) không hợp lệ.'); }
    out.fen = fen;
    out.sideToMove = game.turn() === 'w' ? 'Trắng' : 'Đen';
    out.legalMoveCount = game.moves().length;
    const engine = body?.engine;
    if (engine && typeof engine === 'object') {
      const e = { evalCp: null, mate: null, bestMove: '', depth: 0 };
      if (Number.isFinite(Number(engine.evalCp))) e.evalCp = Math.max(-10000, Math.min(10000, Math.round(Number(engine.evalCp))));
      if (Number.isFinite(Number(engine.mate)) && Number(engine.mate) !== 0) e.mate = Math.max(-99, Math.min(99, Math.round(Number(engine.mate))));
      if (Number.isFinite(Number(engine.depth))) e.depth = Math.max(0, Math.min(99, Math.round(Number(engine.depth))));
      const best = cleanText(engine.bestMove, 8).toLowerCase();
      if (/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(best)) {
        // Chỉ nhận nước engine nếu nó hợp lệ trong thế cờ này; nếu không thì bỏ qua thay vì tin client.
        try {
          const probe = new Chess(fen);
          const move = probe.move({ from: best.slice(0, 2), to: best.slice(2, 4), promotion: best[4] });
          if (move) e.bestMove = move.san;
        } catch { /* nước không hợp lệ: bỏ */ }
      }
      if (e.evalCp !== null || e.mate !== null || e.bestMove) out.engine = e;
    }
  }
  out.history = cleanText(body?.history, 400);
  return out;
}

export class TeamInputError extends Error {
  constructor(message) { super(message); this.name = 'TeamInputError'; this.status = 400; }
}

/** Điều phối viên: chọn tối đa 3 chuyên gia bằng từ khóa (không tốn lượt AI); luôn có ít nhất một người. */
export function pickSpecialists(request) {
  const text = request.question.toLowerCase();
  const scored = SPECIALISTS.map((item, index) => {
    let score = 0;
    for (const word of item.keywords) if (text.includes(word)) score += word.length > 6 ? 2 : 1;
    return { item, score, index };
  }).filter(entry => entry.score > 0).sort((a, b) => b.score - a.score || a.index - b.index);
  const chosen = scored.slice(0, MAX_SPECIALISTS_PER_QUESTION).map(entry => entry.item);
  if (!chosen.length) chosen.push(SPECIALIST_BY_ID.get(request.fen ? 'tactics' : 'coach'));
  // Có thế cờ + engine mà chưa có huấn luyện viên: thêm để có lời khuyên dễ hiểu (vẫn tối đa 3 người).
  if (request.fen && request.engine && !chosen.some(item => item.id === 'coach') && chosen.length < MAX_SPECIALISTS_PER_QUESTION) chosen.push(SPECIALIST_BY_ID.get('coach'));
  return chosen;
}

function describeEval(engine) {
  if (!engine) return '';
  const parts = [];
  if (engine.mate !== null) parts.push(`chiếu hết sau ${Math.abs(engine.mate)} nước (${engine.mate > 0 ? 'bên đi được lợi' : 'bên đi bị lợi'})`);
  else if (engine.evalCp !== null) parts.push(`điểm engine ${engine.evalCp >= 0 ? '+' : ''}${(engine.evalCp / 100).toFixed(2)} tốt cho ${engine.evalCp >= 0 ? 'bên đi' : 'bên kia'}`);
  if (engine.bestMove) parts.push(`nước tốt nhất theo engine: ${engine.bestMove}`);
  if (engine.depth) parts.push(`độ sâu ${engine.depth}`);
  return parts.join('; ');
}

export function buildMessages(specialist, request) {
  const system = [
    `Bạn là "${specialist.name}" trong đội chuyên gia cờ vua của ứng dụng ViLa.`,
    `Lĩnh vực của bạn: ${specialist.focus}.`,
    'Luôn trả lời bằng tiếng Việt, tối đa 4 câu ngắn, dễ hiểu cho người chơi trên điện thoại.',
    'Chỉ nói về lĩnh vực của bạn. Không dùng markdown phức tạp, không lặp lại câu hỏi.',
    'Quy tắc quan trọng: KHÔNG tự bịa nước đi hay điểm số. Chỉ nhắc nước cờ có trong dữ liệu engine được cung cấp. Nếu thiếu dữ liệu thì nói rõ là chưa đủ thông tin.'
  ].join(' ');
  const lines = [`Câu hỏi: ${request.question}`];
  if (request.fen) {
    lines.push(`Thế cờ (FEN): ${request.fen}`, `Bên đi: ${request.sideToMove}; số nước hợp lệ: ${request.legalMoveCount}.`);
    const engine = describeEval(request.engine);
    lines.push(engine ? `Dữ liệu engine (đáng tin): ${engine}.` : 'Không có dữ liệu engine cho thế cờ này.');
  }
  if (request.history) lines.push(`Các nước gần đây: ${request.history}`);
  return [{ role: 'system', content: system }, { role: 'user', content: lines.join('\n') }];
}

/** Workers AI trả `{response}` (định dạng cũ) hoặc kiểu OpenAI `{choices:[{message:{content}}]}`. */
export function extractText(result) {
  if (typeof result === 'string') return result;
  if (typeof result?.response === 'string') return result.response;
  const content = result?.choices?.[0]?.message?.content;
  return typeof content === 'string' ? content : '';
}

export function tidyReply(text) {
  return cleanText(String(text || '').replace(/[*_#`>]+/g, ''), MAX_REPLY_CHARS);
}

/** Lỗi do hết hạn mức Workers AI (gói Free dừng cứng khi hết 10.000 Neuron/ngày). */
export function isQuotaError(error) {
  return /quota|limit|neuron|exceed|capacity|too many|429|10000|4006/i.test(String(error?.message || error || ''));
}

/**
 * Chạy đội: mỗi chuyên gia một lượt gọi AI, chạy song song, rồi gộp xác định (không tốn thêm lượt AI).
 * `ai` là binding env.AI. Trả { answers:[{id,name,icon,text}], failed:[id], combined }.
 */
export async function runTeam({ ai, model = DEFAULT_TEAM_MODEL, request, specialists }) {
  if (!ai || typeof ai.run !== 'function') throw new TeamUnavailableError('Đội chuyên gia chưa được bật trên máy chủ.');
  const settled = await Promise.allSettled(specialists.map(async specialist => {
    const result = await ai.run(model, { messages: buildMessages(specialist, request), max_tokens: TEAM_MAX_TOKENS, temperature: 0.4 });
    const text = tidyReply(extractText(result));
    if (!text) throw new Error('empty reply');
    return { id: specialist.id, name: specialist.name, icon: specialist.icon, text };
  }));
  const answers = [];
  const failed = [];
  let quota = false;
  settled.forEach((entry, index) => {
    if (entry.status === 'fulfilled') answers.push(entry.value);
    else { failed.push(specialists[index].id); if (isQuotaError(entry.reason)) quota = true; }
  });
  if (!answers.length) {
    throw new TeamUnavailableError(quota
      ? 'Đội chuyên gia đã dùng hết lượt miễn phí hôm nay và nghỉ đến 7 giờ sáng mai (giờ Việt Nam).'
      : 'Đội chuyên gia đang bận. Hãy thử lại sau ít phút.', quota);
  }
  const combined = answers.map(item => `${item.icon} ${item.name}: ${item.text}`).join('\n\n');
  return { answers, failed, combined };
}

export class TeamUnavailableError extends Error {
  constructor(message, quota = false) { super(message); this.name = 'TeamUnavailableError'; this.status = 503; this.quota = quota; }
}
