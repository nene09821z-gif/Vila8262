// Đội chuyên gia cờ vua — giao diện trong app (nút nổi + bảng trượt từ dưới lên).
// Tự chứa: tự chèn CSS, chỉ dùng textContent cho nội dung từ máy chủ nên không có nguy cơ chèn HTML.
// main.js chỉ cần gọi mountExpertTeam({ socialApi, getFen, getUser, getEngine? }) một lần.

export const QUICK_QUESTIONS = Object.freeze([
  'Thế cờ này ai đang tốt hơn và vì sao?',
  'Có đòn chiến thuật nào không?',
  'Tôi nên lên kế hoạch gì tiếp theo?',
  'Giải thích nước đi tốt nhất cho tôi.'
]);

const STYLE_ID = 'expert-team-style';
const CSS = `
.et-fab{position:fixed;right:14px;bottom:calc(86px + env(safe-area-inset-bottom,0px));z-index:60;width:48px;height:48px;border-radius:50%;border:0;background:#2d6cdf;color:#fff;font-size:22px;box-shadow:0 4px 14px rgba(0,0,0,.35);cursor:pointer}
.et-sheet{position:fixed;left:0;right:0;bottom:0;z-index:70;max-height:78vh;display:none;flex-direction:column;background:#1d2230;color:#eef1f7;border-radius:18px 18px 0 0;box-shadow:0 -6px 24px rgba(0,0,0,.45);padding:12px 14px calc(14px + env(safe-area-inset-bottom,0px))}
.et-sheet.is-open{display:flex}
.et-head{display:flex;align-items:center;justify-content:space-between;font-weight:700;margin-bottom:8px}
.et-close{background:none;border:0;color:inherit;font-size:22px;padding:4px 8px}
.et-chips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}
.et-chip{background:#2a3146;border:0;color:inherit;border-radius:14px;padding:6px 10px;font-size:13px}
.et-input{width:100%;min-height:54px;border-radius:10px;border:1px solid #3a4260;background:#141824;color:inherit;padding:8px;font-size:15px;box-sizing:border-box;resize:none}
.et-row{display:flex;align-items:center;justify-content:space-between;margin:8px 0;gap:8px}
.et-send{background:#2d6cdf;color:#fff;border:0;border-radius:10px;padding:10px 18px;font-weight:700}
.et-send:disabled{opacity:.55}
.et-meta{font-size:12px;opacity:.75}
.et-out{overflow:auto;-webkit-overflow-scrolling:touch}
.et-card{background:#252c40;border-radius:12px;padding:10px;margin-bottom:8px;font-size:14px;line-height:1.45}
.et-card b{display:block;margin-bottom:4px}
.et-err{color:#ffb4a8;font-size:14px;margin:6px 0}
`;

function ensureStyle(doc) {
  if (doc.getElementById(STYLE_ID)) return;
  const style = doc.createElement('style');
  style.id = STYLE_ID;
  style.textContent = CSS;
  doc.head.appendChild(style);
}

function el(doc, tag, className, text) {
  const node = doc.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

/** Gọi máy chủ; tách riêng để test được. */
export async function askTeam(socialApi, { question, fen, engine, history }) {
  const body = { question };
  if (fen) body.fen = fen;
  if (engine) body.engine = engine;
  if (history) body.history = history;
  return socialApi('/team/ask', { method: 'POST', body: JSON.stringify(body) });
}

export function mountExpertTeam({ socialApi, getFen, getUser, getEngine, doc = typeof document !== 'undefined' ? document : null } = {}) {
  if (!doc || typeof socialApi !== 'function' || doc.getElementById('expertTeamFab')) return null;
  ensureStyle(doc);

  const fab = el(doc, 'button', 'et-fab', '🎓');
  fab.id = 'expertTeamFab';
  fab.type = 'button';
  fab.setAttribute('aria-label', 'Đội chuyên gia cờ vua');

  const sheet = el(doc, 'section', 'et-sheet');
  sheet.id = 'expertTeamSheet';
  sheet.setAttribute('role', 'dialog');
  sheet.setAttribute('aria-label', 'Đội chuyên gia cờ vua');

  const head = el(doc, 'div', 'et-head');
  head.appendChild(el(doc, 'span', '', '🎓 Đội chuyên gia'));
  const close = el(doc, 'button', 'et-close', '×');
  close.type = 'button';
  close.setAttribute('aria-label', 'Đóng');
  head.appendChild(close);

  const chips = el(doc, 'div', 'et-chips');
  const input = el(doc, 'textarea', 'et-input');
  input.maxLength = 500;
  input.placeholder = 'Hỏi đội chuyên gia về thế cờ hiện tại…';
  QUICK_QUESTIONS.forEach(text => {
    const chip = el(doc, 'button', 'et-chip', text);
    chip.type = 'button';
    chip.addEventListener('click', () => { input.value = text; input.focus(); });
    chips.appendChild(chip);
  });

  const row = el(doc, 'div', 'et-row');
  const meta = el(doc, 'span', 'et-meta', '');
  const send = el(doc, 'button', 'et-send', 'Hỏi');
  send.type = 'button';
  row.append(meta, send);

  const out = el(doc, 'div', 'et-out');
  sheet.append(head, chips, input, row, out);
  doc.body.append(fab, sheet);

  const showError = message => { out.replaceChildren(el(doc, 'div', 'et-err', message)); };

  async function refreshInfo() {
    try {
      const info = await socialApi('/team/info');
      meta.textContent = info.enabled ? `Còn ${info.remaining}/${info.limit} câu hôm nay` : 'Đội chuyên gia chưa được bật';
    } catch { meta.textContent = ''; }
  }

  async function submit() {
    if (!getUser?.()) return showError('Hãy đăng nhập để hỏi đội chuyên gia.');
    const question = input.value.trim();
    if (question.length < 2) return showError('Hãy nhập câu hỏi.');
    send.disabled = true;
    out.replaceChildren(el(doc, 'div', 'et-meta', 'Các chuyên gia đang trao đổi…'));
    try {
      let fen = '';
      try { fen = String(getFen?.() || ''); } catch { fen = ''; }
      let engine = null;
      try { engine = getEngine?.() || null; } catch { engine = null; }
      const result = await askTeam(socialApi, { question, fen, engine });
      out.replaceChildren(...result.answers.map(item => {
        const card = el(doc, 'div', 'et-card');
        card.appendChild(el(doc, 'b', '', `${item.icon} ${item.name}`));
        card.appendChild(doc.createTextNode(item.text));
        return card;
      }));
      if (result.usage) meta.textContent = `Còn ${result.usage.remaining}/${result.usage.limit} câu hôm nay`;
    } catch (error) {
      showError(error?.message || 'Đội chuyên gia gặp lỗi. Hãy thử lại sau.');
    } finally { send.disabled = false; }
  }

  const open = () => { sheet.classList.add('is-open'); refreshInfo(); };
  const shut = () => sheet.classList.remove('is-open');
  fab.addEventListener('click', () => (sheet.classList.contains('is-open') ? shut() : open()));
  close.addEventListener('click', shut);
  send.addEventListener('click', submit);
  return { fab, sheet, open, close: shut, submit };
}
