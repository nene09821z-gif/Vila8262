import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  SPECIALISTS, DEFAULT_TEAM_MODEL, MAX_QUESTION_CHARS, parseTeamRequest, pickSpecialists, buildMessages, extractText,
  runTeam, consumeDailyQuestion, refundDailyQuestion, dailyLimitFor, utcDay, TeamInputError, TeamUnavailableError
} from '../cloudflare/src/team.js';
import { askTeam, mountExpertTeam } from '../src/expert-team-panel.js';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

// Dùng chess.js thật khi có (CI đã cài); nếu không thì dùng bản giả tối thiểu để test logic thuần.
async function loadChess() {
  try { return (await import('chess.js')).Chess; } catch {
    return class FakeChess {
      constructor(fen) { if (!/^[rnbqkpRNBQKP1-8/]+ [wb] /.test(fen)) throw new Error('Invalid FEN'); this.fen = fen; }
      turn() { return this.fen.split(' ')[1]; }
      moves() { return new Array(20).fill('x'); }
      move({ from, to }) { if (from === 'e2' && to === 'e4') return { san: 'e4' }; throw new Error('Invalid move'); }
    };
  }
}
const Chess = await loadChess();

test('request parsing trims input, rejects bad FEN and only trusts engine moves that are legal', () => {
  assert.throws(() => parseTeamRequest({ question: '' }, { Chess }), TeamInputError);
  assert.throws(() => parseTeamRequest({ question: 'ok?', fen: 'not a fen' }, { Chess }), /FEN/);
  const long = parseTeamRequest({ question: 'a'.repeat(MAX_QUESTION_CHARS + 200) }, { Chess });
  assert.equal(long.question.length, MAX_QUESTION_CHARS);
  const good = parseTeamRequest({ question: 'Ai tốt hơn?', fen: START, engine: { evalCp: 35, bestMove: 'e2e4', depth: 18 } }, { Chess });
  assert.equal(good.sideToMove, 'Trắng');
  assert.equal(good.engine.bestMove, 'e4');
  const forged = parseTeamRequest({ question: 'Ai tốt hơn?', fen: START, engine: { evalCp: 35, bestMove: 'e2e5' } }, { Chess });
  assert.equal(forged.engine.bestMove, '', 'an illegal engine move from the client is dropped, not trusted');
  assert.equal(parseTeamRequest({ question: 'x?', fen: START, engine: { evalCp: 1e9 } }, { Chess }).engine.evalCp, 10000, 'eval is clamped');
});

test('router picks at most three specialists by keyword and always returns one', () => {
  const pick = question => pickSpecialists(parseTeamRequest({ question }, { Chess })).map(item => item.id);
  assert.ok(pick('Khai cuộc Sicilian nên chơi sao?').includes('opening'));
  assert.ok(pick('Tàn cuộc xe và tốt thông').includes('endgame'));
  assert.deepEqual(pick('xin chào'), ['coach']);
  const many = pick('khai cuộc tàn cuộc chiến thuật thế trận giải thích tại sao');
  assert.ok(many.length >= 1 && many.length <= 3);
  assert.equal(new Set(many).size, many.length);
  const withBoard = pickSpecialists(parseTeamRequest({ question: 'xin chào', fen: START }, { Chess })).map(item => item.id);
  assert.deepEqual(withBoard, ['tactics']);
});

test('daily limits are per tier, reset on a new UTC day and can be refunded', () => {
  assert.ok(dailyLimitFor('free') < dailyLimitFor('pro') && dailyLimitFor('pro') < dailyLimitFor('premium'));
  assert.equal(dailyLimitFor('unknown'), dailyLimitFor('free'));
  const user = {};
  const day1 = Date.UTC(2026, 10, 5, 12, 0, 0);
  for (let i = 0; i < dailyLimitFor('free'); i += 1) assert.equal(consumeDailyQuestion(user, 'free', day1).allowed, true);
  const blocked = consumeDailyQuestion(user, 'free', day1);
  assert.equal(blocked.allowed, false);
  assert.equal(blocked.remaining, 0);
  assert.equal(blocked.resetsAt, '2026-11-06T00:00:00.000Z');
  assert.equal(consumeDailyQuestion(user, 'free', Date.UTC(2026, 10, 6, 0, 0, 1)).allowed, true, 'a new UTC day resets the counter');
  refundDailyQuestion(user, Date.UTC(2026, 10, 6, 1));
  assert.equal(user.teamUsage.count, 0);
  assert.equal(utcDay(day1), '2026-11-05');
});

test('prompts tell the model not to invent moves and include engine data when present', () => {
  const request = parseTeamRequest({ question: 'Giải thích giúp mình', fen: START, engine: { evalCp: 120, bestMove: 'e2e4' } }, { Chess });
  const [system, user] = buildMessages(SPECIALISTS[0], request);
  assert.equal(system.role, 'system');
  assert.match(system.content, /KHÔNG tự bịa/);
  assert.match(user.content, /nước tốt nhất theo engine: e4/);
  assert.match(user.content, /\+1\.20/);
  const noEngine = buildMessages(SPECIALISTS[0], parseTeamRequest({ question: 'hi?', fen: START }, { Chess }))[1];
  assert.match(noEngine.content, /Không có dữ liệu engine/);
});

test('extractText understands both Workers AI response shapes', () => {
  assert.equal(extractText({ response: 'a' }), 'a');
  assert.equal(extractText({ choices: [{ message: { content: 'b' } }] }), 'b');
  assert.equal(extractText(null), '');
});

test('runTeam calls the model once per specialist in parallel and merges without extra AI calls', async () => {
  const calls = [];
  const ai = { run: async (model, input) => { calls.push({ model, input }); return { response: `**Trả lời** ${calls.length}` }; } };
  const request = parseTeamRequest({ question: 'khai cuộc và chiến thuật' }, { Chess });
  const specialists = pickSpecialists(request);
  const team = await runTeam({ ai, request, specialists });
  assert.equal(calls.length, specialists.length);
  assert.equal(calls[0].model, DEFAULT_TEAM_MODEL);
  assert.ok(calls.every(call => call.input.max_tokens <= 300));
  assert.equal(team.answers.length, specialists.length);
  assert.ok(!team.answers[0].text.includes('*'), 'markdown noise is stripped');
  assert.match(team.combined, /Chuyên gia/);
});

test('runTeam survives one failing specialist and reports a friendly error when all fail or quota is out', async () => {
  const request = parseTeamRequest({ question: 'khai cuộc chiến thuật' }, { Chess });
  const specialists = pickSpecialists(request);
  let n = 0;
  const flaky = { run: async () => { n += 1; if (n === 1) throw new Error('boom'); return { response: 'ok' }; } };
  const partial = await runTeam({ ai: flaky, request, specialists });
  assert.equal(partial.failed.length, 1);
  assert.equal(partial.answers.length, specialists.length - 1);
  const quotaAi = { run: async () => { throw new Error('4006: you have used up your daily free allocation of 10,000 neurons'); } };
  await assert.rejects(runTeam({ ai: quotaAi, request, specialists }), error => error instanceof TeamUnavailableError && error.quota && /7 giờ sáng/.test(error.message));
  await assert.rejects(runTeam({ ai: { run: async () => { throw new Error('x'); } }, request, specialists }), error => error instanceof TeamUnavailableError && !error.quota);
  await assert.rejects(runTeam({ ai: null, request, specialists }), TeamUnavailableError);
});

test('Worker wiring: AI binding, authenticated routes, per-IP limit and refund on failure', () => {
  const wrangler = read('cloudflare/wrangler.toml');
  assert.match(wrangler, /\[ai\]\s+binding = "AI"/);
  const worker = read('cloudflare/src/index.js');
  assert.match(worker, /from '\.\/team\.js'/);
  for (const route of ["path === '/team/info'", "path === '/team/ask'"]) assert.ok(worker.includes(route), route);
  const ask = worker.slice(worker.indexOf("path === '/team/ask'"), worker.indexOf("path === '/me/review-access'"));
  assert.match(ask, /needUser\(user\)/, 'asking requires a signed-in account');
  assert.match(ask, /consumeDailyQuestion/);
  assert.match(ask, /refundDailyQuestion/);
  assert.match(worker, /path\.startsWith\('\/team\/'\)\) policies\.push\(\['team'/);
});

test('client: askTeam posts JSON and the panel is mounted once from main.js', async () => {
  let seen;
  const result = await askTeam(async (path, options) => { seen = { path, options }; return { answers: [] }; }, { question: 'Hi?', fen: START });
  assert.equal(seen.path, '/team/ask');
  assert.equal(seen.options.method, 'POST');
  assert.deepEqual(JSON.parse(seen.options.body), { question: 'Hi?', fen: START });
  assert.deepEqual(result, { answers: [] });
  assert.equal(mountExpertTeam({ socialApi() {}, doc: null }), null, 'no document: nothing mounted');
  const main = read('src/main.js');
  assert.match(main, /import \{ mountExpertTeam \} from '\.\/expert-team-panel\.js'/);
  assert.equal((main.match(/mountExpertTeam\(/g) || []).length, 1);
  const panel = read('src/expert-team-panel.js');
  assert.ok(!/innerHTML/.test(panel), 'server text is only ever inserted with textContent');
});
