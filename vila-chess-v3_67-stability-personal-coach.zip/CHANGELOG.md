## v3.67.0 — Stability, Chess Intelligence & Personal Mistake Training

- Preserve FEN before/after each analyzed move so review lines can be replayed and converted into legal training positions.
- Add a local-first spaced-repetition module for the player's own inaccuracies, mistakes, blunders and missed wins; filters engine-suggested moves through legal-move validation.
- Add a touch-first training board in the review page with move selection, legal validation, hints, reset, next-item flow, persistent attempts and mastery after three correct spaced responses.
- Bound the Elo 500 search to 5 plies / 260 ms and add a larger but still legal-only move-deviation handicap in both primary and offline-rescue engine paths. Elo remains a training target, not a match-calibrated rating.
- Add unit and static regression tests, mobile styling, and release-script registration.
- Full engine/browser integration is still subject to a complete npm dependency install and device testing.

## v3.66.0 — Xem lại có mũi tên, bàn học trực tuyến và bot dễ hơn

- Thêm lớp phủ SVG trên bàn xem lại: mũi tên vàng cho nước đã đi, cyan cho nước tốt nhất Stockfish đề xuất tại vị trí hiện tại; hỗ trợ tua bằng phím mũi tên và Home/End.
- Sửa luồng nhập mã trên di động để không render lại toàn trang trước khi gửi khiến ô nhập mất focus; nút hiện/ẩn mã đồng bộ với trạng thái ban đầu.
- Thêm bàn học trực tuyến tra thống kê khai cuộc qua backend `/api/openings/explorer`, kèm thông báo khi mạng/backend không sẵn sàng.
- Tăng giới hạn kho câu đố ngoại tuyến lên 500 và nút tải theo lô tối đa 50 câu từ API Lichess; từng câu vẫn được kiểm tra luật và loại trùng trước khi lưu. Không nhúng toàn bộ cơ sở dữ liệu câu đố vào gói phát hành.
- Làm mức bot Elo 500–600 yếu hơn có chủ đích bằng ngân sách tìm kiếm thấp hơn và xác suất chọn nước hợp lệ khác; đây là handicap huấn luyện, không phải Elo được hiệu chuẩn.
- Nâng `versionName` Android lên 3.66.0; cập nhật báo cáo QA và regression tests.
- Kiểm thử `test:static`: 351/356 đạt; 5 bài không khởi chạy do môi trường thiếu `express`/`chess.js`. Chưa xác nhận build web/APK và thử nghiệm E2E trên điện thoại trong môi trường này.

## v3.65.0 — Mã dùng thử bảo mật và intro quân mã VILA

- Thêm trang nhập mã riêng, dùng thử Pro 5 ngày và Premium 1 phút theo thời hạn máy chủ.
- Mã được xác minh bằng HMAC-SHA-256 ở máy chủ; không nhúng mã thô trong giao diện. Cần cấu hình secret trước khi bật sử dụng trên production.
- Giới hạn mỗi tài khoản chỉ đổi một lần cho từng loại thử nghiệm; giới hạn tốc độ endpoint và ghi nhật ký kiểm toán.
- Thêm intro quân mã VILA bằng SVG nội tuyến và CSS 3D, chạy một lần trong 5 giây; không tải ảnh ngoài.
- Tăng Android versionCode lên 13, versionName lên 3.65.0.
- Lưu ý: thời gian Premium 1 phút là thời gian hết hạn entitlement, UI vẫn cần tải lại trạng thái nếu ứng dụng đang mở sau khi hết hạn.

# ViLa Chess v3.63.0 — Admin Messenger & Plans — 2026-10-24

- Added server-backed Pro/Premium purchase requests, admin-only decision queue, rate limits and audit entries in both Node and Cloudflare backends.
- Pro requests are fixed at VND 1,000 for three hours and require explicit admin confirmation; Premium proposal range is VND 1,000–100,000 and is not automatically sold or granted.
- Local Pro trial costs 50,000 coins for three hours. Cloudflare Durable Object record serialization now persists direct messages and purchase requests across restart.
- Added plan-assistant panel in the admin chat and real admin dashboard actions; no ban-evasion mechanism was added.
- Targeted UI/plan tests (36/36) and Worker route/persistence integration passed. The broader static set reports 338/343; five tests cannot load because `express`/`chess.js` are absent. Node integration and clean Vite/APK builds remain unverified because dependencies could not be installed in this environment; see `TEST_REPORT_V3_63_0.md`.



- Fixed a global 560px app-width cap that squeezed the full application on larger layout viewports.
- Improved leaderboard and direct-message contrast, card hierarchy, and touch targets.
- Local Vite development now routes default community API calls through the local `/api` proxy to the paired Express server.
- Direct-message send now renders the server-confirmed message immediately instead of depending on a potentially busy poll.

# Changelog Cờ Vua ViLa

## v3.64.0 — Cài đặt nâng cao, kết quả mang thương hiệu và ghép trận 3D

- Thiết kế lại Cài đặt thành các nhóm giao diện, di chuyển, bot/phân tích và âm thanh; bổ sung tùy chọn tọa độ, premove, quân đã ăn, xác nhận đầu hàng, depth/time, engine, chất lượng phân tích, đồng hồ và kho khai cuộc.
- Bảng chọn sức mạnh bot có các nút mức nhanh Elo 500–3200 và lựa chọn tối đa; giá trị áp dụng cho ván mới, không âm thầm thay engine giữa ván.
- Thêm các kiểu âm thanh Êm/Gỗ/Neon/Tắt, lưu lựa chọn hợp lệ.
- Chuyển xác nhận thoát/đầu hàng sang modal VILA có logo, hỗ trợ phím Escape và nút ở lại; bổ sung thương hiệu vào bảng kết quả.
- Thay icon ghép trận bằng SVG 3D màu cyan, không dùng biểu tượng kiếm đỏ.
- Chuẩn hóa SAN khi nhận diện khai cuộc, bỏ dấu chiếu/chiếu hết/ký hiệu chú thích và chuẩn hóa nhập thành kiểu 0-0.
- Yêu cầu Pro/Premium tiếp tục gửi về API máy chủ và mở cuộc trò chuyện với admin; yêu cầu không tự kích hoạt gói khi chưa được admin xác nhận.

## v3.62.0 — Professional Edition, thống nhất hệ thống giao diện

- Gom các stylesheet đang dùng thành một entrypoint duy nhất `src/vila-professional.css`; giữ nguyên quy tắc component theo thứ tự cũ và áp dụng design system cuối cùng thống nhất.
- Dùng bảng màu navy/xanh dương/cyan/vàng thống nhất, tăng tương phản chữ và chuẩn hóa thẻ, biểu mẫu, hồ sơ, xếp hạng, chat và màn đấu.
- Chuẩn hóa nhãn/huy hiệu kiểu 3D với gradient vật liệu, cạnh sáng và bóng đổ; huy chương Top 3 dùng hiệu ứng kim loại vàng/bạc/đồng.
- Cải thiện bố cục responsive, vùng an toàn Android, chat trên màn nhỏ, toast và trình phát nhạc nổi để giảm che nội dung.
- Không thay đổi logic luật cờ, engine, tài khoản, backend, ghép trận hoặc schema dữ liệu.
- Đã kiểm tra cú pháp và các test tĩnh mục tiêu; chưa xác minh Vite/APK build sạch vì `npm ci` timeout khi lấy dependency. Chi tiết: `TEST_REPORT_V3_62_PRO_UI.md`.

## v3.61.0 — ổn định thiết lập xếp hạng và rà soát fair-play

- Dùng chung danh mục time control cho giao diện, Node và Cloudflare Worker; khi tải lại trang trong lúc chờ, khôi phục đúng loại Elo và mốc thời gian đang ghép.
- Nếu client cũ không gửi time control, backend mặc định Daily 1d nhất quán.
- Anti-cheat ghi nhận tín hiệu từ thời gian mỗi lượt do server đo và số nước hợp lệ ở vị trí trước khi đi; giới hạn dữ liệu lưu, cho admin rà soát thủ công, không tự động khóa tài khoản.
- Sửa avatar hồ sơ Cloudflare dùng ID ổn định thay vì đổi ngẫu nhiên mỗi lần API trả về.
- Đồng bộ phiên bản web, Service Worker, backend và Android lên 3.61.0; tăng Android versionCode lên 10.
- Thêm bảng admin rà soát tín hiệu fair-play: từng trận, loại thời gian, số tín hiệu, số lượt nhanh ở thế phức tạp và sự kiện gần nhất; API mới không làm hỏng dashboard khi backend đang dùng chưa có endpoint này.
- Cải thiện giao diện mobile cho thẻ review, badge mức độ và danh sách sự kiện, đồng thời giữ nguyên nguyên tắc không tự động kết tội/khóa từ tín hiệu thời gian.
- Kiểm thử mục tiêu 56/56 đạt và cú pháp JS bốn module hợp lệ. Giới hạn: chưa coi đây là build APK hoặc kiểm thử ghép trận Internet thật khi chưa có cài đặt npm hoàn chỉnh và triển khai Worker; xem `TEST_REPORT_V3_61_0.md`.


### Ghi chú triển khai backend Cloudflare (bản gốc v3.52.0, 2026-10-22)

- Đặt backend cộng đồng mặc định thành `https://bitter-sun-751a.nene09821z.workers.dev`; URL trống, localhost/loopback và tunnel tạm thời cũ tự chuyển về địa chỉ này.
- Giao diện không còn yêu cầu người chơi nhập Worker URL hay mã truy cập.
- Thêm mã Cloudflare Worker + Durable Object SQLite cho tài khoản, bạn bè, bảng xếp hạng, lịch sử và ghép trận ngẫu nhiên; máy chủ xác thực nước đi và cập nhật Elo.
- Lưu các mục thành bản ghi riêng trong SQLite và ghi thay đổi bằng transaction đồng bộ; không ghi toàn bộ dữ liệu cộng đồng vào một giá trị dễ vượt giới hạn.
- Lưu ý phát hành: mã nguồn đã được chuẩn bị, nhưng Worker phải được triển khai vào tài khoản Cloudflare trước khi tính năng online hoạt động thực tế. Kiểm tra hai thiết bị sau triển khai. Khôi phục tài khoản qua email cần cấu hình nhà cung cấp gửi thư.

## v3.52.0 — tài khoản VILA riêng, hồ sơ và hộp thư

- Thêm màn hình đăng nhập/tạo tài khoản xuất hiện trước khi vào app; đăng nhập bằng email hoặc biệt danh cùng mật khẩu VILA.
- Loại bỏ hoàn toàn luồng đăng nhập và cấu hình Firebase/Google/GitHub khỏi mã chạy và Gradle.
- Thêm lựa chọn Elo xuất phát theo trình độ, 1.000 tổ hợp avatar cute, tìm bạn bè, hộp thư admin và thông báo chuỗi hoạt động.
- Thêm mã khôi phục 6 chữ số dùng một lần, hết hạn sau 10 phút; cần cấu hình Resend bằng biến môi trường bí mật của backend đã triển khai để email thật được gửi.
- Ghi chú công bằng: không cung cấp engine/hint trong trận xếp hạng online; không thể bảo đảm tuyệt đối rằng nền tảng bên ngoài sẽ không khóa tài khoản.
- Tài khoản, ghép trận, tìm kiếm và hộp thư online yêu cầu máy chủ VILA chạy và có thể truy cập từ Internet.
- Sửa fixture của test tích hợp ghép trận: Alice và Bob dùng cùng Elo khởi điểm để đáp ứng quy tắc matchmaking hiện hành, thay vì kỳ vọng ghép ngay khi lệch 300 Elo.
- Bổ sung kiểm tra hồi quy: chênh lệch 300 Elo bị từ chối lúc đầu và chỉ được ghép sau khi cửa sổ Elo mở rộng đủ theo thời gian chờ.

## v3.51.1 — bàn cờ mượt hơn, đồng bộ phiên bản

- Quân cờ trượt theo khoảng cách (160–280 ms), có bóng khi kéo và tô sáng ô thả; thêm module `board-motion` kèm test.
- Sửa quân đi trước (premove): quân xếp hàng giờ hiện mờ ở ô đích; trước đó nhánh vẽ bóng không bao giờ chạy đúng và có thể vẽ thừa một quân khi xếp nhiều nước.
- Hiệu ứng nháy vàng khi quân hạ cánh chỉ chạy ngay sau nước đi, không lặp lại mỗi lần bàn cờ được vẽ lại (lật bàn, đổi cài đặt, xếp nước đi trước); ô đang trượt giữ z-index 9; bỏ bóng đổ nặng của quân đang trượt trên màn hình nhỏ.
- Sửa test premove của patch: test cũ gọi `e7e5` ở lượt Trắng nên lỗi ngay khi có `chess.js`; thay bằng test logic thật (một nước, chuỗi nước, nước sai dừng chuỗi, phong cấp) và báo *skipped* thay vì pass giả khi thiếu `chess.js`.
- Đồng bộ phiên bản `3.51.1` ở `package.json`, `package-lock.json`, tiêu đề web và Android, `public/sw.js` (khóa cache), `/api/health`, user-agent proxy câu đố; `versionCode` Android 8. Các test ghim phiên bản được cập nhật theo.
- Chưa xác minh trên điện thoại hoặc build APK thật.

## v3.50.0 — ổn định kéo quân, engine offline và quy trình phát hành

- Đồng bộ phiên bản web, Android, API, avatar và service-worker cache lên `3.50.0`; tăng `versionCode` lên 6.
- Bỏ qua thao tác nhấc tay/nhả chuột cũ nếu ván đấu hoặc FEN đã đổi trong lúc pointer còn được giữ, tránh chọn nhầm quân ở ván mới.
- Thêm kiểm tra tài nguyên engine có đối chiếu manifest, chữ ký WASM, giấy phép Stockfish 10 và chế độ Full NNUE trong build release.
- Thêm smoke test chạy Stockfish 19 Lite thật bằng UCI trên Node: xác nhận `uciok`, `readyok` và `bestmove` hợp lệ từ vị trí đầu.
- Giữ công cụ phân tích nằm trong menu chuột/menu trận; kiểm tra hồi quy công cụ vẽ, xem lại, mini-game và avatar offline.
- Chưa xác minh build APK hoặc thao tác trên điện thoại: npm registry không phân giải được DNS ở môi trường làm việc này. Cần kiểm tra artifact GitHub Actions trước khi cài.

## v3.49.5 — công cụ bút vẽ được ghim vào menu, không nổi đè bàn cờ

- Bỏ bảng công cụ phân tích dạng `position: fixed` nổi trên bàn cờ.
- Đưa một bộ điều khiển bút vẽ dùng chung vào menu Chuột ảo và tab Phân tích của menu trận đấu ☰; hai lối mở dùng chung cùng một widget, không tạo bản sao ID hay listener.
- Menu bút vẽ xuống dòng theo chiều rộng, bảng chuột giới hạn chiều cao và cuộn nội bộ khi mở nhiều công cụ.
- Chế độ Di chuyển quân vẫn là lựa chọn riêng; đóng bảng công cụ hoặc chọn lại ♟ sẽ không để chế độ vẽ chặn đường kéo quân.
- Tăng Android versionCode lên 5, versionName lên 3.49.5.

# Changelog


## v3.49.4 — thao tác bàn cờ mượt hơn, bảng phân tích và mini-game gọn hơn

- Tinh chỉnh ngưỡng kéo chuột/ngón tay và tiếp tục gom cập nhật vị trí quân theo khung hình để hạn chế giật khi kéo.
- Tách công cụ bàn cờ thành Di chuyển quân, Mũi tên, Bút chì tự do, Đường chữ L quân Mã và Khoanh ô; thêm màu nét, preview nét tự do và cuộn ngang thanh công cụ trên màn nhỏ.
- Chuyển về Di chuyển quân ngay khi chọn công cụ tương ứng; khi đang dùng chuột ảo, đổi công cụ sẽ thả trạng thái giữ chuột để không mắc kẹt trong chế độ kéo/vẽ.
- Bổ sung mini-game ngoại tuyến Phản xạ tọa độ với điểm, chuỗi liên tiếp và kỷ lục lưu trên thiết bị.
- Thêm avatar SVG thương hiệu VILA tối giản; được cache cho khởi động offline.
- Giảm khoảng cách/padding ở trang xem lại, làm gọn các khối biểu đồ, phát lại và nút hành động.
- Giữ Stockfish 19 NNUE Full/Lite và nhánh ASM-JS dự phòng trong GitHub Actions; không thay bằng một bản Leela WebAssembly thử nghiệm chưa tích hợp và kiểm chứng.
- Kiểm thử tĩnh liên quan đến kéo quân/chuột ảo, bảng vẽ, xem lại, engine profile và mini-game đã chạy. Build Android/đo độ trễ trên OPPO A17k chưa xác minh được trong môi trường này.

## Chưa phát hành — Đấu trường AI toàn lực, 4 khai cuộc riêng cho mỗi bot

- **Sửa lỗi nghiêm trọng (phát hiện khi chạy giao diện thật):** nút **Đấu trận** trong Đấu trường AI báo `drawArenaSides is not defined` nên không chạy được; đã thêm hàm bốc thăm màu theo tùy chọn “Đảo màu ngẫu nhiên”.
- **Sửa lỗi:** `LOCAL_GAME_RECOVERY_KEY` chưa được khai báo nên tính năng khôi phục ván đang chơi không bao giờ hoạt động (lỗi bị `try/catch` nuốt im lặng); đã khai báo khóa lưu `vila.chess.local-game-recovery.v1`.
- **Giao diện:** thanh đầu ván có 4 nút nhưng lưới chỉ 3 cột nên nút Menu rơi xuống và đè lên avatar đối thủ; đã sửa lưới.
- **Đấu trường:** thu gọn đoạn giải thích dài thành mục mở rộng để bàn cờ lên cao hơn trên điện thoại; thêm nút “Chọn bot & tùy chỉnh”; Tạm dừng/Dừng nằm cùng hàng; cỡ chữ nút 12,5px; xóa ghi chú “đang tính nước đi…” cũ khi ván kết thúc; hộp kết quả không lặp “80 nửa nước”.
- **Câu đố:** đoạn giới thiệu 7 dòng thu gọn còn 1 dòng, phần giải thích chuyển vào mục “Cách hoạt động”.
- Đồng bộ test Đấu trường với kho 4 khai cuộc riêng và thêm test hồi quy `tests/v3-49-ui-regressions.test.js`.
- Mỗi hồ sơ trong Đấu trường AI có đúng 4 biến khai cuộc đã lưu riêng (21 bộ hồ sơ gồm các bot VILA, Stockfish 19 và Stockfish 10); tên các biến được hiển thị ngay trong danh sách bot để người dùng kiểm tra.
- Mặc định, giải bắt đầu từ vị trí ban đầu để từng bot tự sử dụng kho 4 khai cuộc riêng; tuỳ chọn “Khai cuộc ghép cặp” vẫn có thể bật để benchmark cùng một khai cuộc rồi đổi màu.
- Giữ điều kiện engine công bằng: chung độ sâu, Skill Level và ngân sách thời gian mỗi nước. Kho khai cuộc đổi phong cách/độ đa dạng, không tăng ngân sách suy nghĩ của bot.
- Stockfish 19, Stockfish 10 và các profile VILA nhận giới hạn độ sâu/thời gian chung; profile VILA là phong cách chọn nước từ các biến thể Stockfish gần ngang điểm, không phải engine neural độc lập hay Elo đã benchmark. Nhánh cứu hộ offline vẫn giới hạn thời gian và ghi nhận khi được dùng.
- Kiểm thử mục tiêu: 34/34 bài về repertoire riêng, chọn bot, arena và lịch giải đạt. Bộ test tĩnh lớn: 291/292 đạt; test premove không khởi chạy do môi trường thiếu package `chess.js`. Build chưa xác minh vì môi trường hiện cũng thiếu binary/dependency Vite; chưa khẳng định APK hoặc thiết bị thật đã chạy. Chi tiết ở `TEST_REPORT_ARENA_4_OPENINGS.md`.

## Chưa phát hành — sửa hồi quy test dự phòng Stockfish
- Đồng bộ kiểm thử hồi quy với nhánh độ sâu tìm kiếm theo sức mạnh: cấu hình Elo/skill thấp giữ giới hạn cứu hộ, còn chế độ sức mạnh tối đa dùng ngân sách sâu hơn trong giới hạn engine.
- Tách tính toán độ sâu cứu hộ khỏi cấu hình ngân sách để dễ đọc và giảm nguy cơ kiểm thử phụ thuộc vào một dòng mã dài.
- Xác minh nước đi fallback là hợp lệ, cập nhật đồng hồ và chỉ dùng nước khẩn cấp khi tìm kiếm offline thất bại.

## Chưa phát hành — Chuột ảo PC và bảng vẽ phân tích nổi
- Thêm chuột ảo nhỏ gọn điều khiển bằng vùng trượt cảm ứng; con trỏ có thể nhấn, giữ và kéo-thả quân bằng chính luồng Pointer Events của bàn cờ, tránh thay thế đường kéo quân tối ưu sẵn có.
- Bảng chuột ảo có thể di chuyển, thu nhỏ, mở lại hoặc tắt; con trỏ được cập nhật theo `requestAnimationFrame` và dùng `transform` để hạn chế tái bố cục.
- Thêm tùy chọn nhận diện ngón trỏ qua camera: chụm ngón cái + ngón trỏ để giữ/kéo quân, tách để thả; nhận diện chạy trong Worker, ảnh không được gửi lên máy chủ. Tải thư viện/mô hình từ mạng khi bật camera (có thể tải lại khi bộ nhớ đệm hết hạn); vùng trượt cảm ứng vẫn là phương án dự phòng ngoại tuyến.
- Chuyển công cụ vẽ phân tích thành bảng nổi có tay nắm kéo, thu gọn, ẩn/hiện và chọn trực tiếp bốn màu xanh lá/đỏ/vàng/xanh dương; giữ thao tác mũi tên, khoanh ô và xóa dấu vẽ.
- Thêm kiểm thử hồi quy cho luồng chuột ảo và bảng phân tích nổi. Chưa chạy build Vite/Gradle hoặc đo độ trễ trên OPPO A17k vì cài dependencies bị treo trong môi trường; không khẳng định đã kiểm thử thiết bị thật.

## Chưa phát hành — giao diện v4: phòng đấu kiểu chess.com, nhạc nền mạng
- Màn bàn cờ chỉ còn: thanh trên, 2 thanh người chơi + đồng hồ, bàn cờ, thanh nút dưới. Thanh điều hướng/nhãn ẩn trong trận; nút ← về trang Thiết lập trận đấu (nơi có các nhãn Chơi/Bot/Câu đố...).
- Menu trận trượt lên (Nước đi · Phân tích · Thiết lập · Trang khác); trên máy tính là cột bên cố định.
- Bỏ toàn bộ nhạc ngoại tuyến (synth). Nhạc nền stream qua YouTube: remix / nhạc buồn TikTok / slowed; tự phát khi vào app, bài bị chặn nhúng tự chuyển bài kế, mini-player (trước/dừng/sau/tắt).
- Giao diện mới: header tối, thanh dưới nổi, trang thiết lập tối, thư viện nhạc.

## Chưa phát hành — sửa lỗi, đi trước vô hạn, giao diện dễ đọc
- Sửa 2 test fail: bản ZIP GitHub gọn không có `app/src/main/assets/sw.js`; test nay đọc `public/sw.js` khi bản sao Android vắng.
- Đi trước (premove) kiểu chess.com: xếp hàng vô hạn, nối nhiều nước (kể cả nhập thành, đi cùng quân hai lần); tự đi lần lượt, tự hủy cả hàng đợi khi đối thủ đi khác làm nước đầu không còn hợp lệ. Hủy bằng chuột phải, Esc, nút "Hủy n nước đi trước" hoặc chạm ô đã xếp.
- Nhập thành: bỏ nhãn O-O/O-O-O 8px đè lên ô; danh sách nước đi không xuống dòng, nhập thành dùng chữ đơn cách, nước gần nhất được tô.
- Quân trượt mượt khi bấm đi/bot đi (cả xe khi nhập thành), thả kéo quân vẫn tức thì; tôn trọng giảm chuyển động.
- Bảng màu navy/xanh dương/cyan thống nhất (`src/vila-polish.css`); số chỗ chữ thiếu tương phản giảm từ ~1.460 xuống ~130 (chủ yếu tọa độ trang trí trên bàn cờ).
- Viền xanh quanh nước bạn vừa đi, viền đỏ quanh nước đối thủ vừa đi (hai ô đi/đến, ô đến nháy nhẹ). Màu đi trước chuyển sang vàng hổ phách để không lẫn với viền đỏ.
- Nhãn phân tích kiểu chess.com theo xác suất thắng: Thiên tài (!!), Tuyệt vời (!), Tốt nhất, Xuất sắc, Tốt, Khai cuộc, Thiếu chính xác, Sai lầm, Bỏ lỡ, Sai lầm nghiêm trọng; huy hiệu tròn có màu. Thiên tài = hy sinh quân thật sự theo biến Stockfish; Tuyệt vời = nước duy nhất (MultiPV 2) hoặc lật ngược thế cờ.
- Mức phân tích ván mới "Cao nhất" (mặc định): Stockfish 19 Lite 8 giây/nước, MultiPV 2, Hash 64MB; có thể chọn Sâu/Chuẩn trong Cài đặt. Chưa có bản Full NNUE trong gói (cần tải ở bước build).
- Thêm: tự động phong Hậu, thông báo nước đi cho trình đọc màn hình (aria-live).
- Nâng chất lượng câu đố: nhánh dự phòng Stockfish phân tích MultiPV 3 và chỉ nhận đề khi nước giải hợp lệ, mang tính chiến thuật, điểm đủ tốt và vượt phương án kế tiếp tối thiểu 180 cp; bỏ qua đề mơ hồ/thông tin engine chưa đủ sâu.
- Đề Lichess có chủ đề chiếu hết trong 1 chấp nhận mọi nước đi hợp lệ dẫn đến chiếu hết, tránh đánh sai khi thế cờ có nhiều cách chiếu hết.
- Huy hiệu đề hiển thị độ khó/chủ đề thay vì số nửa nước của ván ngẫu nhiên; bổ sung kiểm thử cho các ngưỡng chất lượng.
- Sửa lỗi lộ đáp án: thẻ thông tin không còn hiển thị UCI của nước cần tìm trước khi người chơi đi; các chủ đề Lichess phổ biến được Việt hóa.

## v3.47.2 — Stockfish 10 nhanh hơn và gói GitHub gọn hơn

- Đấu trường: giới hạn thời gian Stockfish 10 khoảng 0,2–0,6 giây/nước; giảm timeout để dự phòng nhanh hơn.
- Đấu người: giới hạn Stockfish 10 ở tối đa 0,5 giây/nước; rút watchdog riêng cho engine cũ.
- Giữ Stockfish 10 và các fallback; không đổi cấu hình phân tích mạnh nhất.
- Giữ bản ZIP AI Studio trong `public/assets/aistudio`; Gradle tự khôi phục bản sao Android trong giai đoạn `preBuild`.
- Tăng versionName/versionCode, làm mới Service Worker và cache asset.

## v3.47.1 — giảm độ trễ Đấu trường AI và bỏ Stockfish 10 khỏi mặc định
- Đấu trường mặc định ghép Stockfish 19 với ViLa Rookie, không còn tự chọn Stockfish 10 cổ điển.
- Giảm ngân sách suy nghĩ mỗi nước của Đấu trường: Stockfish 19 dùng giới hạn 0,7–1,5 giây/nước; Stockfish 10 legacy dùng 0,3–1,2 giây/nước. Giảm nhịp nghỉ mặc định giữa nước còn 0,15 giây.
- Stockfish 10 vẫn có thể chọn thủ công để so sánh, được ghi nhãn là bản cũ/chậm hơn; không xóa tệp engine hoặc giấy phép.
- Đồng bộ thay đổi quan trọng trong JS bundle Android có sẵn, tăng version và Service Worker cache lên v3.47.1.
- QA tập trung: xem `TEST_REPORT_V3_47_1.md`. Chưa có build Vite/Gradle sạch do thiếu dependencies trong môi trường; không tuyên bố đã kiểm thử trên điện thoại thật.

## v3.47.0 — online cờ ngày, giao diện sáng và bot luyện người mới
- Thêm mốc 1 ngày và 2 ngày vào hàng đợi đấu trực tuyến; không thêm các mốc này vào thiết lập ván cục bộ.
- Thêm lựa chọn luyện người mới dựa trên Skill Level thấp của Stockfish, không giả lập Elo chính xác.
- Làm sáng giao diện câu đố/xem lại và tăng khả năng nhận chạm ở nút Đấu trường AI.
- Giữ nguyên Stockfish 19 Lite WASM và Stockfish 10 ASM.js hiện có; chưa có bản Full NNUE trong manifest.

## v3.46.4 — thiết lập trận riêng, vào bàn cờ sau khi bắt đầu

- Tách luồng chơi thành trang **Thiết lập trận đấu** và màn bàn cờ. Khi mới vào Chơi cờ, người dùng không còn phải cuộn qua bàn cờ để tìm phần thiết lập.
- Chọn chế độ, phong cách bot, màu quân, mức sức mạnh, thời gian trước khi tạo ván.
- Nút **Ván mới**, **Chơi lại**, **Thiết lập trận** và **Chơi nhanh** đưa người dùng về màn thiết lập; thao tác engine và đồng hồ được dừng khi rời trận.
- Giảm vùng cuộn thừa trên màn thiết lập di động; ẩn phần cài đặt trùng lặp trong cột phụ khi đang đấu.
- Tăng phiên bản/cache lên v3.46.4 để giảm nguy cơ giữ UI cũ trên thiết bị đã cài.

## v3.46.3 — đồng bộ bảng màu xanh dương/cyan, cache và Docker

- Đồng bộ màu giao diện theo logo: navy, xanh dương, cyan; giữ vàng cho phần thưởng.
- Sửa CSS bàn cờ để các theme do người dùng chọn tiếp tục áp dụng qua `--board-*`.
- Tăng phiên bản và Service Worker cache lên v3.46.3; đổi cache-bust biểu tượng lên v349.
- Thêm Dockerfile và `.dockerignore`; cập nhật test giao diện theo palette mới.
- Kiểm thử offline: chỉ xác nhận các bài test có thể chạy với dependency sẵn có; các bài cần `chess.js`/`express` phải được chạy ở môi trường cài dependency.

# Changelog

## v3.46.2 — logo thương hiệu mới và kỷ vật trong Cài đặt
- Dùng biểu tượng vương miện + mã xanh từ ảnh nguồn người dùng làm brand icon, favicon, PWA/app icon và các mật độ mipmap Android; giữ ảnh logo đầy đủ làm wordmark trong Cài đặt.
- Thêm ảnh tượng đài kỷ niệm vào riêng mục Cài đặt, tối ưu sang WebP và cache offline.
- Cập nhật cache key Service Worker để tránh icon cũ còn hiển thị trên Android/WebView; thêm manifest PWA và test hồi quy thương hiệu.
- QA: `test:static` 264/264; cú pháp JS/MJS 131/131; full test 266/270 do 4 test không nạp được dependency thiếu; `npm run build` chặn ở prebuild vì thiếu `chess.js`. Chi tiết tại `TEST_REPORT_V3_46_2.md`; chưa xác nhận APK.

## v3.46.1 — đối chiếu audit, dữ liệu khai cuộc dự phòng và cache đồng bộ
- Đồng bộ phiên bản ứng dụng/package/server và tăng cache-bust favicon để tránh dùng tài nguyên cũ sau cập nhật.
- Thay danh mục khai cuộc rỗng bằng 338 dòng khai cuộc dự phòng đã khử trùng lặp từ kho curation trong mã nguồn. Đây chỉ là bộ dự phòng, không giả làm dữ liệu Lichess đầy đủ; build phát hành vẫn bắt buộc nạp và xác thực ít nhất 3.000 dòng.
- Sửa thông báo khi danh mục JSON chỉ lặp lại biến đã có: ứng dụng vẫn cập nhật số liệu/chẩn đoán và báo thiếu dữ liệu thay vì âm thầm trả về.
- Sửa thứ tự lịch sử changelog/README, cập nhật nguồn câu đố và liên kết báo cáo QA hiện tại.
- QA: `npm run test:static` 261/261 đạt; 130/130 tệp JS/MJS qua `node --check`; `npm test` 263/267 với 4 test bị chặn do thiếu `chess.js`/`express`. `npm install` lỗi DNS `EAI_AGAIN`; production build/APK chưa xác minh. Xem `TEST_REPORT_V3_46_1.md`.

## v3.46.0 — giao diện mobile, đồng hồ nhanh và nhạc cờ vua
- Gom thiết lập trận, danh sách nước đi, phân tích và khai cuộc vào một menu Công cụ, tránh dàn hàng nút dài trên điện thoại.
- Bỏ dòng nhận diện khai cuộc bên dưới bàn cờ và thẻ gợi ý màu vàng; nước gợi ý vẫn được vẽ trực tiếp trên bàn cờ và hiển thị bằng thông báo ngắn.
- Thêm các nút chọn nhanh Siêu chớp 30 giây, Bullet 1+0, Blitz 3+2 và Rapid 10+0; vẫn giữ toàn bộ mốc thời gian trong danh sách thiết lập.
- Làm gọn thanh điều hướng trên màn hình hẹp, cải thiện thao tác kéo quân trên WebView và thêm lối tắt ghép trận người thật.
- Bỏ bản ghi Gymnopédie cũ khỏi nhạc tích hợp; các nhạc nền tích hợp là giai điệu tổng hợp nguyên bản chạy offline, còn nhạc từ YouTube chỉ phát khi người dùng chọn.
- Tăng version/cache key lên v3.46.0 và cập nhật kiểm thử hồi quy.
- QA bản này: `npm run test:static` 254/254; kiểm tra cú pháp 131/131 tệp JavaScript/MJS. `npm test` đạt 256/260; bốn test không khởi chạy vì môi trường thiếu `chess.js`/`express`. Chưa xác minh build APK hoặc thao tác trên thiết bị thật; xem `TEST_REPORT_V3_46_0.md`.

## v3.45.0 — độ an toàn đồng hồ và thao tác phong cấp
- Tính thời gian mỗi tick bằng hàm thuần có kiểm thử riêng; chặn giá trị thời gian `NaN`, không cho đồng hồ chạy tiếp trong ván đã kết thúc và không cộng thời gian khi đồng hồ bị rollback.
- Sửa race trong hộp chọn phong cấp: chụp ô xuất phát, FEN và epoch của ván trước khi mở hộp thoại; hủy nước đi nếu vị trí hoặc ván đã thay đổi thay vì dùng biến chọn quân có thể đã đổi.
- Khi Worker tìm nước ngoại tuyến bị treo/quá hạn, kết thúc Worker, dọn timeout của yêu cầu đang chờ và dùng tìm kiếm dự phòng nông có giới hạn thay vì để các yêu cầu sau mắc kẹt.
- Đưa avatar mã vương miện vào danh sách cache lõi của Service Worker để giao diện thương hiệu sẵn sàng ngoại tuyến ngay sau cài đặt.
- Xóa tệp tạm rỗng `public/test.tmp`; đồng bộ metadata package, giao diện, API health, user-agent và cache key lên v3.45.0.
- Kiểm thử: `test:static` 251/251 đạt; 128/128 tệp JS/MJS kiểm tra cú pháp đạt. Test tập trung đồng hồ, phong cấp bất đồng bộ và phục hồi Worker 9/9 đạt. `npm test` có 253/257 bài đạt, 4 bài không khởi chạy do thiếu `chess.js`/`express`; registry npm không phân giải được DNS trong môi trường này. Chưa xác nhận build APK hoặc thao tác trên thiết bị/máy chủ thật.

## v3.44.0 — nhận diện ViLa và giao diện màu sắc nhẹ
- Thêm ảnh mã đội vương miện do người dùng cung cấp làm dấu hiệu thương hiệu và avatar hồ sơ trên trang chủ.
- Thêm chuyển động màu bằng CSS nhẹ; không tải video và tôn trọng cài đặt giảm chuyển động của thiết bị.
- Giữ nguyên các luồng chơi cờ, đồng hồ xếp hạng, bạn bè/tìm kiếm, đấu trường, phân tích, câu đố, nhiệm vụ, cửa hàng và mini-game.
- Bổ sung CSS thích ứng cho avatar và hiệu ứng màu sắc.

## v3.43.0 — Stockfish 10 UCI handshake and mobile polish
- Parse each line of UCI output independently in the main Stockfish worker path. This handles legacy worker events that bundle `uciok`, `readyok`, and other lines into one event, with exact handshake matching and a longer startup watchdog.
- Added regression coverage for bundled/multiline UCI output, object-wrapped worker events and engine-health state; included engine-health tests in the static suite.
- Refined the analysis panel for small screens and mobile review metadata; kept the action toolbar in normal flow so it no longer obscures the lower match screen.
- The release workflow requires Stockfish 10, Stockfish 19 Lite/ASM and Full NNUE assets plus the Stockfish 10 license notice. Actual engine execution still must be confirmed by the GitHub build and a device run; the package dependency install could not complete in this offline environment.

## v3.42.0 — Engine recovery, puzzle service and mobile layout
- Stockfish 10 is a required dependency for release packaging; GitHub Actions fails early if the script or GPL notice is absent.
- Arena Stockfish 10 opponents retry using Stockfish 19 and then the VILA offline search core while validating every returned move against legal moves.
- Added a public puzzle proxy to the user's own backend with bounded recently-served puzzle IDs and daily-puzzle caching; client uses this server when configured and falls back to Lichess.
- Increased offline puzzle pool to 150 positions, remembered puzzle history to 15,000 positions, and puzzle pack downloads to 20 validated puzzles per batch.
- Fixed the mobile match action bar being cropped/overlaying content by placing it back into normal document flow; improved contrast of player cards and clock surfaces.
- Added five board cosmetics and four offline generated background music choices plus the optional online classical recording.
- Validation caveats for this line of work are consolidated in TEST_REPORT_V3_43_0.md; device-side play still needs GitHub APK build and a real-device run.

## v3.41.0 — VILA Atelier: thiết kế lại toàn bộ giao diện

- Thay ngôn ngữ giao diện tối xanh cũ bằng không gian sáng, phong cách editorial/studio: nền giấy, panel rõ cấp bậc, xanh lá làm màu hành động và điểm nhấn vàng cho phần giải đấu.
- Làm mới header, menu chức năng, thanh điều hướng mobile, màn chủ, bảng cờ, panel đồng hồ, danh sách nước đi, câu đố, khai cuộc, đấu trường, biểu đồ và cài đặt bằng lớp CSS riêng `src/vila-atelier.css`; giữ lại toàn bộ ID và bộ xử lý thao tác hiện có.
- Thiết kế lại thanh hành động ván cờ thành cụm 5 nút cảm ứng đồng đều; ẩn bottom navigation trong màn chơi trên điện thoại để không chồng lấp với thanh hành động.
- Bỏ Google Fonts tải từ xa để giảm yêu cầu mạng và tránh làm chậm khởi động offline; sử dụng font hệ thống.
- Đồng bộ metadata, API health, Service Worker, favicon cache-busting và test phiên bản lên 3.41.0.
- Bổ sung kiểm thử tĩnh cho lớp giao diện mới, breakpoint di động, offline-first typography và bảo toàn các hook chức năng.
- Đồng bộ các màn chuyên biệt vốn còn giữ tông cũ: phân tích và xem lại ván, lịch sử/PGN, ranked và câu đố, tiến trình/nhiệm vụ/cửa hàng, mạng xã hội, inbox, bảng xếp hạng/admin và hộp kết quả.
- Bổ sung kiểm thử tĩnh riêng cho các màn chuyên biệt; giữ nguyên module xử lý luật, engine và dữ liệu, tránh thay logic cờ chỉ để phục vụ thiết kế.
- QA cuối: test tĩnh 239/239; cú pháp 126/126 JS/MJS; 0 lỗi parse trong hai stylesheet. Full suite 241/245, 4 test không khởi chạy do thiếu dependency trong môi trường; không tuyên bố APK/device đã được nghiệm thu.

## v3.40.0 — kiểm tra UCI thật và khôi phục ván có kiểm chứng

- Thêm state machine kiểm tra khởi động Stockfish: chỉ đánh dấu sẵn sàng khi nhận `uciok` rồi `readyok`; `readyok` lạc chỗ và `bestmove` đến sớm không được tính là handshake thành công.
- Nút mã góc trên hiển thị thời gian khởi động trong tooltip, tên profile engine và thông báo lỗi cụ thể; trạng thái này phản ánh UCI handshake thật chứ không phải một nhãn giao diện đơn thuần.
- Bản lưu ván đang chơi dùng schema v3 kèm checksum FNV-1a, kiểm tra thời gian lưu, mode, nước đi, hướng quân, FEN, đồng hồ và kích thước snapshot trước khi replay. Snapshot v2 cũ vẫn được chấp nhận để khôi phục tương thích; nước đi vẫn được replay và FEN cuối phải khớp.
- Đồng bộ phiên bản package, giao diện, API health, cache Service Worker, tài liệu build và kiểm thử về 3.40.0. Sửa các kỳ vọng phiên bản cũ trong test để test hồi quy còn có thể chạy khi phát hành mới.
- Kiểm thử tĩnh 228/228 và cú pháp 121/121 đạt. Bộ test đầy đủ 230/234; bốn tệp test không khởi chạy do các dependency `chess.js`/`express` không có vì `npm install` bị timeout. Không tuyên bố build APK hoặc test thiết bị khi chưa thực hiện được.

## v3.38.0 — màn chọn người chơi, bàn công cụ gọn, kho câu đố và Cúp ViLa

- Đưa lựa chọn “Mới chơi / Đã hiểu luật” ra ngoài phần cài đặt thu gọn để hiển thị ngay trước bàn cờ trên điện thoại.
- Thanh bút chì được cố định trong luồng bố cục; bỏ lưu tọa độ kéo-thả cũ, gom mũi tên, khoanh ô, đổi màu và xóa vào cùng một cụm.
- Thu gọn thanh nút thao tác để nhãn không tràn và không bị kéo giãn trên màn hình nhỏ.
- Thêm biểu tượng mã Stockfish có trạng thái tải/sẵn sàng/lỗi; hiển thị tên phiên bản đầy đủ, trong đó đường tải Stockfish 10 vẫn dùng gói riêng và chuỗi fallback an toàn.
- Thêm bảng Cúp đấu trường, lưu bảng điểm giải vòng tròn và nhiệm vụ liên quan.
- Thêm mini-game Cờ ca-rô offline với bot tìm kiếm minimax tối ưu.
- Thêm kho câu đố Lichess đã xác minh, tải theo lô 10 đề và lưu tối đa 50 đề hợp lệ trên máy; không nhúng cả cơ sở dữ liệu nhiều triệu dòng vào APK.
- Cập nhật nhãn ký hiệu phân tích và thêm nhiệm vụ luyện tập/đấu trường/mini-game.

## v3.37.2 — sửa bố cục trận đấu Android

- Hiển thị bàn cờ rõ ngay cả trước khi bắt đầu; chuyển lựa chọn kinh nghiệm và nút bắt đầu thành thẻ nhỏ phía trên bàn cờ.
- Đặt lại vị trí cuộn khi chuyển màn hình để tránh thẻ đối thủ bị che bởi thanh đầu trang dính.
- Bổ sung vùng đệm nội dung phía dưới cho thanh thao tác cố định trên WebView di động.
- Tăng cache key Service Worker để lấy CSS/JS mới.

## v3.37.1 — sửa vòng đời Stockfish 10 trong Đấu trường

- Bổ sung hàng rào UCI `isready`/`readyok` trước mỗi tìm kiếm, reset `ucinewgame` đúng một lần mỗi ván thay vì mỗi nửa nước.
- Tách callback theo đúng Worker, tách từng dòng UCI nếu wrapper gộp nhiều dòng, huỷ Worker lỗi/timeout an toàn và cho phép khởi tạo lại ở lượt tiếp theo.
- Lỗi Stockfish 10 nay được ghi vào trạng thái Đấu trường trong khi nước dự phòng hợp lệ vẫn giúp ván đấu tiếp tục.
- Tăng phiên bản cache Service Worker lên 3.37.1 để tránh giữ mã cũ.
- Kiểm thử giả lập nhiều nước liên tiếp, vị trí sau bắt quân, dòng UCI gộp, timeout/khởi động lại và lỗi tạo Worker đồng bộ. Chưa tuyên bố engine thật đã chạy trên thiết bị Android trong môi trường này.

## v3.37.0 — Stockfish 10 Arena, review page tách riêng, thêm bộ quân

- Thêm đối thủ Stockfish 10 (gói npm alias `stockfish-10` / `10.0.2`) dùng worker UCI riêng để thi đấu ở Đấu trường, không tranh worker với Stockfish 19. Build Android bắt buộc kiểm tra script và giấy phép engine cũ trước khi đóng gói.
- Trang kết quả/xem lại được tách thành route riêng, chia bố cục bàn cờ phát lại và biến engine với biểu đồ lợi thế, biên bản theo cặp, nhãn nước đi, thống kê Trắng/Đen và tải PGN. Không tuyên bố dùng CAPS2 của Chess.com.
- Bổ sung 3 palette quân gốc VILA (Amethyst, Sapphire, Bronze) và 4 bộ quân được cấp phép từ Lichess (`kiwen-suwi`, `firi`, `totoy`, `shapes`), kèm credit/license khi build.
- Chốt phiên bản app/package/server/workflow ở 3.37.0; thêm test cho giao thức UCI giả lập, cổng build Stockfish 10, route review và gradient SVG.
- Các bài test tĩnh được chạy trong môi trường sửa đổi; `npm install`, test tích hợp phụ thuộc `chess.js`/`express`, Gradle và chạy trên Android vẫn phải được xác nhận qua GitHub Actions/thiết bị. Không đánh dấu APK đã build nếu chưa có artifact.


## v3.36.0 — Bot mạnh hơn, đánh giá minh bạch và xem lại có gợi ý

- Android build thêm Stockfish 19 Full NNUE cùng Lite và ASM-JS dự phòng; thiết bị có bộ nhớ/CPU phù hợp tự ưu tiên Full. Máy yếu giữ Lite để giảm rủi ro tràn bộ nhớ; vẫn có thể chọn Full thủ công.
- Mặc định nghĩ sâu hơn (độ sâu trần 30, đến 2,6 giây mỗi nước); cài đặt tùy chỉnh của người dùng được giữ nguyên khi cập nhật.
- Gỡ nhánh tự bỏ qua Stockfish bằng nước heuristic/ngẫu nhiên trong chế độ Elo thấp. Dưới ngưỡng UCI_Elo của Stockfish, engine dùng Skill Level 0–7 theo từng mức; số Elo thấp được ghi rõ là preset luyện tập, không phải xếp hạng benchmark.
- Phân tích toàn ván dùng ngân sách thời gian hợp lý hơn, ghi lại nước tốt nhất engine tìm thấy trước từng nước thật, lưu SAN gợi ý, độ sâu, điểm trước/sau và mức điểm đã mất. Biên bản nay ghép nước Trắng/Đen theo lượt, hỗ trợ nhảy tới thế cờ và tổng hợp nhãn riêng cho mỗi bên.
- Xử lý vị trí chiếu hết/hòa cuối ván và quy đổi mate score; không còn tự gắn nhãn “Thiên tài” chỉ vì một quân có thể bị ăn. Chỉ đánh dấu nước khai cuộc khi mức mất điểm vẫn nhỏ. Changelog ghi lại các thay đổi theo từng phiên bản; ZIP phát hành chỉ kèm báo cáo tương ứng với phiên bản hiện tại.
- Bỏ các báo cáo cũ khỏi ZIP phát hành; giữ bộ test hồi quy lịch sử cần thiết.


## v3.35.0 — sảnh Trang chủ, câu đố Lichess và trải nghiệm Android

- Sửa lỗi khởi động sai: ứng dụng nay mở ở **Trang chủ/Sảnh VILA**, không mở thẳng vào bàn cờ. “Chơi ngay” mới bắt đầu ván, còn tùy chỉnh ván đấu đi tới thiết lập.
- Thiết kế lại trang chủ thành dashboard có thẻ hồ sơ/Elo cục bộ, thanh lối tắt 5 chế độ, hero chơi cờ, thẻ câu đố ngày, các chế độ AI/câu đố/bài học/phân tích/online, khu luyện tập và mini-game. Điều hướng gọn, responsive và safe-area cho Android.
- Kết nối Lichess Daily Puzzle qua `/api/puzzle/daily` và câu đố huấn luyện lần lượt qua `/api/puzzle/next` với 5 mức độ; kiểm tra PGN và toàn bộ dòng giải bằng `chess.js`, cache theo ngày, timeout và phương án dự phòng ngoại tuyến. Câu đố nhiều nước tự chơi nước đáp của đối thủ và chuyển câu tiếp sau khi giải.
- Giữ/chỉnh sửa lại hồ sơ Đấu trường AI, trang phân tích/xem lại, kho khai cuộc, chơi offline bằng Stockfish, luồng online qua backend/Lichess. Giữ rõ khác biệt giữa engine thật và profile phong cách.
- Bổ sung test hồi quy ngăn việc quay lại mở trực tiếp vào bàn cờ, test dữ liệu câu đố và validate cache.
- Ghi lại giới hạn: nếu không có mạng, daily cache chỉ hoạt động sau lần tải thành công trước đó; nếu không có cache, tự dùng thế đố sinh ngoại tuyến. APK phải build trên GitHub Actions trước khi coi là phát hành.

## v3.34.0 — VILA mobile-first refresh

- Thay shell điều hướng bằng thanh chế độ 5 mục, menu chức năng gọn và bottom navigation dành cho Android. Bản 3.34.0 mở thẳng vào phòng chơi; đây là lỗi đã được sửa ở v3.35.0 để app khởi động tại Sảnh Trang chủ.
- Thiết kế lại Đấu trường AI theo bố cục dọc: hồ sơ hai bot, bàn cờ lớn, biên bản nước đi và thiết lập nâng cao có thể thu gọn. Giữ nguyên Stockfish, luật chess.js, chế độ đấu trận/giải vòng tròn và tải PGN.
- Thêm trung tâm Mini-game ngoại tuyến: Rubik 3×3 với trạng thái sticker thật, xoay mặt qua swipe/nút U/D/L/R/F/B, xáo trộn, hoàn tác và kiểm tra đã giải; thêm 2048 (phím/swipe/nút hướng), lật thẻ ghi nhớ và Trượt số 15 với xáo trộn bằng các bước hợp lệ.
- Câu đố Luyện tự do, Puzzle Rush và Sinh tồn tự động chuyển bài sau khi giải đúng; thử thách hằng ngày vẫn giữ nguyên chính sách một đề mỗi ngày.
- Thêm kiểm thử thuần Node cho xoay Rubik/đảo ngược/xáo trộn và logic 2048.
- Các bot phong cách vẫn là profile tìm kiếm VILA dựa trên engine cục bộ, không được quảng cáo là các engine neural độc lập. Cần hoàn tất npm test và GitHub Actions để xác nhận build APK trước phát hành.


## v3.33.0 — giao diện phòng đấu và độ trễ thao tác
- Làm mới phòng đấu theo tông xanh đêm, thẻ người chơi/đồng hồ, thanh chức năng riêng và thanh thao tác năm nút trên điện thoại.
- Giảm chi phí chọn quân: chỉ cập nhật các ô cờ đổi trạng thái; chỉ tính nước hợp lệ khi cử chỉ đã thành thao tác kéo.
- Dùng hình học bàn cờ đã cache để xác định ô thả, tránh hit-test DOM qua `elementFromPoint()` trong lúc kéo.
- Giữ các view/chức năng cũ; thêm nút hủy lựa chọn nước đi.
- Pin phiên bản cụ thể cho các dependency trực tiếp; ZIP phát hành hiện tại kèm báo cáo `TEST_REPORT_V3_37_0.md`; báo cáo của phiên bản cũ không được đóng gói lại.

## v3.32.0 — kiểm thử và độ tin cậy
- Sửa lỗi cú pháp trong `tests/visual-settings.test.js` khiến bộ kiểm thử tĩnh không thể khởi chạy đầy đủ.
- Chuẩn hóa kỳ vọng của test: `normalizeVisualSettings` chỉ giữ các tùy chọn giao diện mà module thực sự hỗ trợ; không giả định module này quản lý kiểu quân cờ.
- Đồng bộ phiên bản package, tiêu đề, API health, service-worker cache và nhận diện tác vụ tải tài nguyên sang 3.32.0.
- Thêm cổng kiểm tra cú pháp JavaScript toàn bộ `src`, `server`, `scripts`, `tests` vào quy trình nghiệm thu thủ công.
- Xác minh lại 169 test tĩnh và ghi rõ bốn test tích hợp bị chặn bởi dependency chưa cài trong môi trường.

## v3.31.0 — phòng đấu hợp nhất, thương hiệu mới và luyện tập mở rộng

- Tái thương hiệu toàn bộ giao diện web/Android thành **Cờ Vua ViLa**, icon mới và bảng màu xanh ngọc–vàng.
- Phòng đấu gom thao tác nhanh, thiết lập đối thủ, khai cuộc, danh sách nước và phân tích vào một màn hình.
- Sửa hoàn tác để khôi phục đúng clock snapshot trước nước đi; thêm Làm lại và lịch sử đồng hồ theo từng nửa nước đi.
- Có 18 profile bot offline cấu hình được chọn (bao gồm 6 profile mới: Mentor, Hunter, Sentinel, Strategist, Endgame Pro, Chaos), ngoài engine Stockfish; phân biệt rõ profile cấu hình với engine neural được train độc lập.
- Mở rộng lên 19 kiểu quân cờ: 14 kiểu nội bộ (1 PNG + 13 phối màu vector) và 5 bộ SVG nguồn mở được tải, kiểm tra giấy phép, đóng gói offline trong release GitHub.
- Thêm Luyện tự do, Đề hôm nay xác định theo ngày, Puzzle Rush 3 phút và Sinh tồn 3 mạng; chống kết quả Worker cũ ghi đè lượt hết giờ.
- Test: 166/167 bài kiểm thử tĩnh đạt; full suite 168/173 đạt (5 lỗi khởi tạo trong môi trường hiện tại).

## Lịch sử trước đó

Các thay đổi lịch sử từ các bản v3.x trước được gom vào các tệp nguồn, commit và kiểm thử hiện tại. Báo cáo audit/changelog lặp theo từng phiên bản cũ đã được loại khỏi ZIP để giảm nhiễu.

## 3.47.3 — Sửa test lỗi + nâng cấp chuột ảo
- Sửa test cũ `piece-artwork` (đang đòi thanh vẽ cố định, mâu thuẫn thiết kế v4 thanh vẽ nổi/kéo được).
- Chuột ảo: chạm nhanh trên bàn di = nhấn; chạm 2 lần rồi kéo = giữ/kéo quân; tăng tốc theo vận tốc ngón tay (chậm = chính xác, nhanh = đi xa); kẹp lại vị trí khi xoay/đổi kích thước màn hình; bỏ qua ngón tay thứ hai.

## 3.47.3 (tiếp) — Sửa bot Elo 500, nâng bot VILA, dựng lại Đấu trường AI
- **Bot Elo 500 (chế độ "luyện người mới") không chạy**: `scheduleBotMove` chỉ gọi Stockfish khi `mode === 'stockfish'`, nên chế độ `stockfish-beginner` không bao giờ nhận được nước đi. Đã sửa; thêm `resolveBotStrength` (luôn ép Elo 500, không phụ thuộc cài đặt đã lưu), watchdog và nước dự phòng cũng áp dụng cho chế độ này (dự phòng dùng bot yếu `rookie`/`mentor`, không dùng bot mạnh), tìm kiếm ngắn hơn ở Elo thấp, và trả lại cài đặt Stockfish cũ khi rời chế độ luyện người mới.
- **Bot VILA mạnh hơn**: mọi profile +1 độ sâu mặc định, ×1.5 số nút, ×1.3 thời gian; trần tìm kiếm 12 tầng / 600k nút; bảng chuyển vị lớn hơn; giảm sâu thêm cho nước yên lặng rất muộn (LMR); ngân sách `resolveOfflineSearchBudget` cao hơn; bot phong cách bám sát nước tốt nhất của Stockfish hơn (dung sai hẹp hơn).
- **Đấu trường AI dựng lại** (`src/arena-tournament.js`): 4 thể thức (1-1, vòng tròn, thách đấu, loại trực tiếp), 2–10 ván mỗi cặp, khai cuộc ghép cặp đổi màu, tạm dừng/tiếp tục, thanh tiến độ + thời gian còn lại, bảng xếp hạng trực tiếp (điểm, T/H/B, %, Elo tương đối) và bảng đối đầu, xử ván dài theo vật chất, PGN có Round/Date/Opening, tối đa 8 bot.

